// seraphina-train-deterministic.js
// Deterministic training stub for Seraphina AI instance, mirroring miner approach.
// Uses imagination outcomes + trading signals digest to produce candidate evaluation.
// No randomness; all ordering via SHA256 of vectors.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const SIGNALS_PATH = process.env.SERAPHINA_TRAIN_SIGNALS || 'trading-signals.jsonl';
const IMAGINATION_LEDGER = process.env.SERAPHINA_IMAG_LEDGER || 'imagination-ledger.jsonl';
const OUT_SCOREBOARD = process.env.SERAPHINA_TRAIN_SCOREBOARD || 'seraphina-train-scoreboard.json';
const OUT_WEIGHTS = process.env.SERAPHINA_WEIGHTS_OUT || 'seraphina-weights-trained.json';
const IN_WEIGHTS = process.env.SERAPHINA_WEIGHTS_IN || 'seraphina-weights.json';
const LEDGER_PATH = process.env.SERAPHINA_TRAIN_LEDGER || 'seraphina-train-ledger.jsonl';
const CANDIDATE_COUNT = parseInt(process.env.SERAPHINA_TRAIN_CANDIDATES || '20',10);
const IMPROVE_MIN = parseFloat(process.env.SERAPHINA_TRAIN_IMPROVE_MIN || '0.02');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x : JSON.stringify(x)).digest('hex'); }

function readJsonLines(path, limit){
  if(!fs.existsSync(path)) return [];
  let lines = fs.readFileSync(path,'utf8').trim().split(/\n+/);
  if(limit && lines.length>limit) lines = lines.slice(-limit);
  const out=[]; for(const l of lines){ try{ out.push(JSON.parse(l)); }catch(_){} }
  return out;
}

function loadWeights(){
  if(!fs.existsSync(IN_WEIGHTS)) return { version:'seraphina-base', features:['projectionGain','geometryPenalty','netProjection','spread','volatility'], vector:[0.5,-0.2,0.3,0.15,0.1] };
  try { return JSON.parse(fs.readFileSync(IN_WEIGHTS,'utf8')); } catch(e){ return { version:'seraphina-fallback', features:['projectionGain','geometryPenalty','netProjection','spread','volatility'], vector:[0.5,-0.2,0.3,0.15,0.1] }; }
}

function extractFeatures(signalEntry, imaginationOutcome){
  // fallback zeros when missing
  const sig = signalEntry?.signal || {};
  return [
    imaginationOutcome?.projectedGain || 0,
    imaginationOutcome?.geometryPenalty || 0,
    imaginationOutcome?.netProjection || 0,
    sig.spread || 0,
    sig.volatility || 0
  ];
}

function scoreVector(vec, signals, imagination){
  let gain=0, penalty=0, churn=0;
  const imaginationByScenario = {};
  for(const o of imagination){ imaginationByScenario[o.scenarioId] = o; }
  for(const entry of signals){
    // map by deterministic scenario id if available (use coin+timestamp bucket)
    const scenarioId = entry.signal && entry.signal.coin ? 'scn:'+entry.signal.coin : 'scn:generic';
    const outcome = imaginationByScenario[scenarioId] || null;
    const feats = extractFeatures(entry, outcome);
    let raw=0; for(let i=0;i<vec.length;i++){ raw += vec[i]*feats[i]; }
    const norm = 1/(1+Math.exp(-raw));
    // interpret norm as probability weight for capturing netProjection vs penalty accumulation
    gain += (outcome? outcome.netProjection : (entry.signal?.adjustedSpread || 0)) * norm;
    penalty += (outcome? outcome.geometryPenalty:0) * (1-norm);
    if(entry.signal?.action === 'swap') churn++;
  }
  const score = gain - penalty - (churn*0.0005);
  return { score:Number(score.toFixed(8)), gain:Number(gain.toFixed(8)), penalty:Number(penalty.toFixed(8)), churn };
}

function generateCandidates(base){
  const steps=[-0.08,-0.04,-0.02,0,0.02,0.04,0.08];
  const list=[];
  for(const s0 of steps){
    for(const s1 of steps){
      for(const s2 of steps){
        for(const s3 of steps){
          for(const s4 of steps){
            list.push([
              Number((base[0]+s0).toFixed(6)),
              Number((base[1]+s1).toFixed(6)),
              Number((base[2]+s2).toFixed(6)),
              Number((base[3]+s3).toFixed(6)),
              Number((base[4]+s4).toFixed(6))
            ]);
          }
        }
      }
    }
  }
  // Dedup + order
  const seen=new Set(); const uniq=[];
  for(const v of list){ const h=sha256(v); if(!seen.has(h)){ seen.add(h); uniq.push(v);} }
  uniq.sort((a,b)=> sha256(a).slice(0,16).localeCompare(sha256(b).slice(0,16)) );
  return uniq.slice(0,CANDIDATE_COUNT);
}

function appendLedger(entry){
  try{
    let prev='GENESIS';
    if(fs.existsSync(LEDGER_PATH)){
      const lines=fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/); if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch(_){} }
    }
    entry.prevHash=prev; entry.chainHash=sha256(entry); fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n');
  }catch(e){ /* ignore */ }
}

function runSeraphinaTraining(){
  const weights = loadWeights();
  const signals = readJsonLines(SIGNALS_PATH, 4000);
  const imaginationSessions = readJsonLines(IMAGINATION_LEDGER, 50);
  // Flatten imagination outcomes (latest only)
  const latestImag = imaginationSessions.length? imaginationSessions[imaginationSessions.length-1].outcomes || [] : [];
  const signalsDigest = sha256(signals);
  const imagDigest = sha256(latestImag);
  const baseScore = scoreVector(weights.vector, signals, latestImag);
  const candidates = generateCandidates(weights.vector);
  const results=[];
  for(const vec of candidates){ results.push({ vec, res: scoreVector(vec, signals, latestImag) }); }
  results.sort((a,b)=> b.res.score === a.res.score ? sha256(a.vec).slice(0,8).localeCompare(sha256(b.vec).slice(0,8)) : b.res.score - a.res.score );
  const best = results[0];
  const improvement = baseScore.score===0? (best.res.score>0?1:0) : (best.res.score - baseScore.score)/Math.abs(baseScore.score);
  const scoreboard = {
    ts: new Date().toISOString(),
    signalsDigest,
    imaginationDigest: imagDigest,
    candidateCount: candidates.length,
    base: { vector: weights.vector, ...baseScore },
    best: { vector: best.vec, ...best.res },
    improvementPct: Number(improvement.toFixed(8))
  };
  fs.writeFileSync(OUT_SCOREBOARD, JSON.stringify(scoreboard,null,2));
  let updated=false;
  if (improvement >= IMPROVE_MIN){
    const newWeights = { version: 'seraphina-trained-'+scoreboard.ts.replace(/[:T\-]/g,'').slice(0,15), features: weights.features, vector: best.vec };
    fs.writeFileSync(OUT_WEIGHTS, JSON.stringify(newWeights,null,2));
    updated=true;
  }
  appendLedger({ t:Date.now(), updated, improvementPct: Number(improvement.toFixed(8)), baseScore: baseScore.score, bestScore: best.res.score, bestVec: best.vec });
  return scoreboard;
}

if(require.main === module){
  const sb = runSeraphinaTraining();
  process.stdout.write(JSON.stringify({ updated: sb.improvementPct >= IMPROVE_MIN, improvementPct: sb.improvementPct, scoreboard: OUT_SCOREBOARD }, null,2)+'\n');
}

module.exports = { runSeraphinaTraining };
