"use strict";
// seraphina-REAL-mining.js fully purged. Use `aurrelia-pico-mesh-miner.js`.
module.exports = { deprecated: true };