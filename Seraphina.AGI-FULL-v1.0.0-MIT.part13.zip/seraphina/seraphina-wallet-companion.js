// seraphina-wallet-companion.js
// Deterministic Wallet Companion for Aurrelia / Seraphina environment.
// Responsibilities:
//  - Validate configured wallet addresses (BTC, RVN, FREN, KAS optional)
//  - Produce deterministic optimization suggestions (JSON) based on recent income, latency, and recommendation info
//  - Never mutate state directly; returns advisory objects only
//  - Deterministic: all randomness replaced by seeded hash (CONFIG_HMAC_KEY or SERAPHINA_SEED fallback)
//  - Defensive prompt injection shield if external model invoked (reuses global __AUR_AGENT_INVOKE__ if present)
//
// Environment Flags:
//  WALLET_COMPANION=1             Enable integration by miner
//  COMPANION_LAT_SAMPLE_PATH      Path to latency snapshot JSON (pool-latency.json) for advisory context
//  COMPANION_INCOME_SOURCE_JSON   Path to miner economic summary JSON if exported
//  COMPANION_SUGGEST_MAX          Max number of suggestions (default 5)
//  COMPANION_STRICT=1             Fail validation if any required wallet invalid
//
// Exposed API:
//  validateAll(env) -> { issues:[], details:{BTC:{ok,...},...} }
//  deriveContext(env, extras) -> deterministic context object (subset for suggestion hashing)
//  suggest(context) -> { suggestions:[{id,type,action,confidence,note}], digest }
//  companionCycle(env, extras) -> { validation, suggestion }
//
// Suggestion Types (advisory):
//  adjust_bias   -> Propose tweak to ECON bias multipliers (requires manual approval)
//  switch_coin   -> Reinforce or question current recommended coin
//  verify_wallet -> Highlight missing/invalid wallet
//  latency_probe -> Advise deeper latency sampling when spread small but latency high
//  noop          -> No action (low confidence)
//
// Security: suggestions NEVER executed automatically.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function stableHash(str){ return crypto.createHash('sha256').update(str).digest('hex'); }
function seedKey(){ return process.env.CONFIG_HMAC_KEY || process.env.SERAPHINA_SEED || 'companion-seed'; }

function hmacFold(label, data){
  const key = seedKey();
  return crypto.createHmac('sha256', key).update(label+JSON.stringify(data)).digest('hex');
}

function loadJsonSafe(p){ try { if(fs.existsSync(p)){ return JSON.parse(fs.readFileSync(p,'utf8')); } } catch(_){ } return null; }

function validateBTC(addr){ return /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(addr||''); }
function validateRVN(addr){ return /^R[a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(addr||''); }
function validateFREN(addr){ return /^F[a-km-zA-HJ-NP-Z1-9]{20,60}$/.test(addr||''); }
function validateKAS(addr){ return /^kaspa:[0-9a-z]{60,70}$/.test((addr||'').toLowerCase()); }

function validateAll(env){
  const map = {
    BTC: { key:'WALLET_BTC', fn: validateBTC, required:true },
    RVN: { key:'WALLET_RVN', fn: validateRVN, required:true },
    FREN:{ key:'WALLET_FREN', fn: validateFREN, required:true },
    KAS: { key:'KAS_WALLET', fn: validateKAS, required:false }
  };
  const issues=[]; const details={};
  Object.entries(map).forEach(([coin, info])=>{
    const val = env[info.key];
    if(!val){ if(info.required){ issues.push(`${coin}:missing`); details[coin]={ ok:false, reason:'missing' }; } else { details[coin]={ ok:true, optional:true }; }
      return; }
    const ok = info.fn(val);
    details[coin] = { ok, address: val };
    if(!ok){ issues.push(`${coin}:invalid`); }
  });
  return { issues, details };
}

function deriveContext(env, extras={}){
  const econBias = {
    fren: parseFloat(env.ECON_FREN_BIAS||'1.08'),
    rvn: parseFloat(env.ECON_RVN_BIAS||'1.04'),
    btc: parseFloat(env.ECON_BTC_BIAS||'1.0'),
    kas: parseFloat(env.ECON_KAS_BIAS||'1.0')
  };
  let latency = null; if(extras.latencyPath){ latency = loadJsonSafe(extras.latencyPath); }
  let income = null; if(extras.incomePath){ income = loadJsonSafe(extras.incomePath); }
  const ctx = {
    ts: Date.now(),
    econBias,
    recommend: extras.recommend || null,
    incomeRecent: income && income.results ? income.results : null,
    latencySnapshot: latency ? latency.results : null,
    walletSummary: extras.validation ? extras.validation.details : null
  };
  return ctx;
}

function rankActions(base){
  // Base deterministic priority: verify_wallet > latency_probe > adjust_bias > switch_coin > noop
  const order = { verify_wallet:10, latency_probe:8, adjust_bias:6, switch_coin:4, noop:0 };
  return base.sort((a,b)=> order[b.type]-order[a.type] || a.id.localeCompare(b.id));
}

function suggest(context){
  const suggestions=[]; const max = parseInt(process.env.COMPANION_SUGGEST_MAX||'5',10);
  const wallets = context.walletSummary || {};
  Object.entries(wallets).forEach(([coin, info])=>{
    if(!info.ok){ suggestions.push({ id:'wallet-'+coin.toLowerCase(), type:'verify_wallet', action:'replace_or_fix', confidence:0.95, note:`Wallet ${coin} missing/invalid` }); }
  });
  // Latency probe suggestion: if recommend present and latency snapshot shows any failed connects
  if (context.recommend && Array.isArray(context.latencySnapshot)){
    const fails = context.latencySnapshot.filter(r=>!r.ok);
    if(fails.length){ suggestions.push({ id:'lat-probe', type:'latency_probe', action:'resample', confidence:0.7, note:`${fails.length} pool endpoints failed connect` }); }
  }
  // Bias adjustment: if recommended coin not FREN or RVN and fren bias <=1.08 propose small increase (bounded)
  if (context.recommend && !['fren','rvn'].includes(context.recommend)){
    if (context.econBias.fren <= 1.1){
      suggestions.push({ id:'bias-fren', type:'adjust_bias', action:'increase_fren_bias', delta:0.01, confidence:0.55, note:'Slight FREN bias raise to test income edge' });
    }
  }
  // Switch reinforcement: if recommend is rvn or fren emit reinforcement advisory
  if (['rvn','fren'].includes(context.recommend||'')){
    suggestions.push({ id:'switch-ok', type:'switch_coin', action:'maintain', confidence:0.6, note:`Maintain ${context.recommend.toUpperCase()} focus (income-biased)` });
  }
  if(!suggestions.length){ suggestions.push({ id:'noop', type:'noop', action:'none', confidence:0.0, note:'No actionable changes' }); }
  const ranked = rankActions(suggestions).slice(0,max);
  // Deterministic digest of suggestion set
  const digest = hmacFold('suggestions', ranked);
  return { suggestions: ranked, digest };
}

function companionCycle(env, extras={}){
  const validation = validateAll(env);
  if (env.COMPANION_STRICT==='1' && validation.issues.length){
    return { validation, suggestion: { suggestions:[], digest: hmacFold('empty',validation) }, error:'validation_failed' };
  }
  const ctx = deriveContext(env, { ...extras, validation });
  const suggestion = suggest(ctx);
  return { validation, suggestion };
}

module.exports = { validateAll, deriveContext, suggest, companionCycle };

if (require.main === module){
  const latencyPath = process.env.COMPANION_LAT_SAMPLE_PATH || 'pool-latency.json';
  const incomePath = process.env.COMPANION_INCOME_SOURCE_JSON || null;
  const recommend = process.env.ECON_RECOMMEND || null;
  const res = companionCycle(process.env, { latencyPath, incomePath, recommend });
  console.log(JSON.stringify(res, null, 2));
}
