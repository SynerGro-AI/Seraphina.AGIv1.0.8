/**
 * Seraphina Reality Check / Environment Guardian
 * ------------------------------------------------
 * 1. Audits environment (re-uses environment-audit)
 * 2. Verifies snapshot chain integrity
 * 3. Scans root for any lingering '.env' file and deletes ONLY if ALLOW_ENV_PURGE=1 and REAL_STRICT=1
 * 4. Exits non-zero if violations found
 */
const fs = require('fs');
const path = require('path');
const { auditEnvironment, verifyChain } = require('./environment-audit');
const crypto = require('crypto');

function main(){
  const strict = process.env.REAL_STRICT === '1';
  const projectRoot = __dirname;
  const envPath = path.join(projectRoot,'.env');
  const exists = fs.existsSync(envPath);
  if (strict && exists) {
    if (process.env.ALLOW_ENV_PURGE === '1') {
      try { fs.unlinkSync(envPath); console.log('[REALITY] Removed .env file under REAL_STRICT purge policy.'); } catch (e) { console.error('[REALITY] Failed to remove .env:', e.message); process.exit(2); }
    } else {
      console.error('[REALITY] .env present under REAL_STRICT and purge not allowed. ABORT');
      process.exit(2);
    }
  }
  const audit = auditEnvironment();
  const chain = verifyChain();
  if (!chain.ok) {
    console.error('[REALITY] Snapshot chain integrity FAIL');
    console.error(JSON.stringify(chain,null,2));
    process.exit(3);
  }
  // Verify latest octa hash signature if available
  try {
    const chainFile = path.join(__dirname,'persistent_data','environment_snapshot.chain');
    const lines = fs.readFileSync(chainFile,'utf8').trim().split('\n').filter(Boolean);
    const last = JSON.parse(lines[lines.length-1]);
    if (last.data && last.data.octaHashes) {
      const octaConcat = Object.entries(last.data.octaHashes).sort((a,b)=>a[0].localeCompare(b[0]))
        .map(([f,h])=>f+':'+h).join('|');
      if (last.data.octaHashSignature) {
        const label = process.env.VAULT_SIGN_LABEL || process.env.VAULT_OCTA_SIGN_LABEL;
        if (label && process.env.VAULT_PASS) {
          const { loadVaultSafe } = require('./seraphina-key-vault');
          const vault = loadVaultSafe(process.env.VAULT_PASS);
          const rec = vault[label];
            if (rec && rec.publicHex && rec.type==='ed25519') {
              try {
                const pubKey = crypto.createPublicKey({ key: Buffer.from(rec.publicHex,'hex'), format:'der', type:'spki' });
                const verified = crypto.verify(null, Buffer.from(JSON.stringify(last.data)), pubKey, Buffer.from(last.sig||audit.signature||'', 'hex'));
                const octaVerified = crypto.verify(null, Buffer.from(octaConcat), pubKey, Buffer.from(last.data.octaHashSignature,'hex'));
                console.log('[REALITY] Octa signature verify data='+verified+' octa='+octaVerified);
                if (!octaVerified) {
                  console.error('[REALITY] Octa hash signature mismatch!');
                  process.exit(5);
                }
              } catch (e) {
                console.error('[REALITY] Octa verification failed:', e.message);
              }
            }
        }
      }
    }
  } catch (e) {
    console.error('[REALITY] Octa signature verification skipped:', e.message);
  }
  console.log('[REALITY] Chain integrity OK. Entries='+chain.total);
  console.log('[REALITY] Latest snapshot hash='+audit.hash);
}

if (require.main === module) {
  try { main(); } catch (e) { console.error('[REALITY] Fatal:', e.message); process.exit(1); }
}

module.exports = { main };