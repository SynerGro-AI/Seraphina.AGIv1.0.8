/**
 * SERAPHINA UNIFIED DASHBOARD
 * --------------------------------------------------
 * Aggregates:
 *  - Mining stats (from real mining process - polled)
 *  - RVN→BTC swaps (reads swap state file)
 *  - BTC transfer daemon state (reads btc state + queue)
 *  - Dynamic fee optimization (sat/vB heuristic browsing mempool API)
 *  - WebSocket push updates
 *  - JWT-protected admin endpoints
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const express = require('express');
const jwt = require('jsonwebtoken');
const WebSocket = require('ws');

// ---------- CONFIG ----------
const PORT = parseInt(process.env.UNIFIED_PORT || '8990', 10);
const JWT_SECRET = process.env.UNIFIED_JWT_SECRET || 'change_me_dev_secret';
const FEE_TARGET_BLOCKS = parseInt(process.env.FEE_TARGET_BLOCKS || '6',10); // aim ~ 1 hr default
const FEE_MIN = parseInt(process.env.FEE_MIN_SATVBYTE || '5',10);
const FEE_MAX = parseInt(process.env.FEE_MAX_SATVBYTE || '60',10);
const REFRESH_INTERVAL_MS = parseInt(process.env.UNIFIED_REFRESH_MS || '20000',10);

// File paths (reuse existing services' state)
const SWAP_STATE_FILE = path.join(__dirname, 'persistent_data', 'rvn_swap_state.json');
const BTC_STATE_FILE = path.join(__dirname, 'persistent_data', 'btc_transfer_state.json');
const BTC_QUEUE_FILE = path.join(__dirname, 'persistent_data', 'btc_incoming_queue.json');

// Mining stats are not persisted yet - we'll poll a local HTTP endpoint if mining app exposes one (future) or stub.
// For now, provide a pluggable fetch stub.
async function fetchMiningStats() {
  // Placeholder: If future mining server exposes /api/mining we can fetch it.
  return {
    activeClones: null,
    totalClones: null,
    btcHashrateTHs: null,
    rvnHashrateGHs: null,
    note: 'Mining stats endpoint not yet wired; integrate later.'
  };
}

// Load JSON safely
function loadJSONSafe(p) { try { return JSON.parse(fs.readFileSync(p,'utf8')); } catch { return null; } }

// Fee optimization heuristic
async function fetchRecommendedFees() {
  return new Promise((resolve) => {
    const req = https.request({ host: 'mempool.space', path: '/api/v1/fees/recommended', method:'GET', headers:{'User-Agent':'SeraphinaUnified/1.0'}}, res => {
      let data='';
      res.on('data', c=> data+=c);
      res.on('end', ()=> { try { resolve(JSON.parse(data)); } catch { resolve(null); } });
    });
    req.on('error', ()=> resolve(null));
    req.end();
  });
}

function computeDynamicFee(feesJson) {
  if (!feesJson) return { chosen: FEE_MIN, source: 'fallback' };
  // feesJson: { fastestFee, halfHourFee, hourFee, economyFee, minimumFee }
  let target = feesJson.hourFee || feesJson.halfHourFee || feesJson.fastestFee || FEE_MIN;
  // Bound
  target = Math.max(FEE_MIN, Math.min(FEE_MAX, target));
  // Adjust if aiming certain block target
  if (FEE_TARGET_BLOCKS > 6 && feesJson.economyFee) {
    target = Math.min(target, feesJson.economyFee);
  }
  return { chosen: target, reference: feesJson };
}

// JWT Middleware
function auth(req,res,next) {
  const hdr = req.headers.authorization || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ ok:false, error:'missing_token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ ok:false, error:'invalid_token' });
  }
}

// Issue token (for dev only) - in production require manual secret distribution
function issueDevToken() {
  return jwt.sign({ role:'admin', iat: Math.floor(Date.now()/1000) }, JWT_SECRET, { expiresIn: '12h' });
}

const app = express();
app.use(express.json());

// Public endpoint: token (dev convenience)
app.get('/auth/dev-token', (req,res)=> {
  res.json({ token: issueDevToken() });
});

// Aggregated status (public minimal)
app.get('/status/summary', async (req,res)=> {
  const swap = loadJSONSafe(SWAP_STATE_FILE);
  const btc = loadJSONSafe(BTC_STATE_FILE);
  const queue = loadJSONSafe(BTC_QUEUE_FILE) || [];
  res.json({
    ok:true,
    swap: swap ? { pending: swap.pendingSwap, lastAlert: swap.lastAlert } : null,
    btc: btc ? { lastTx: btc.lastTx } : null,
    queueDepth: queue.length
  });
});

// Admin aggregated (JWT)
app.get('/admin/aggregate', auth, async (req,res)=> {
  const swap = loadJSONSafe(SWAP_STATE_FILE);
  const btc = loadJSONSafe(BTC_STATE_FILE);
  const queue = loadJSONSafe(BTC_QUEUE_FILE) || [];
  const mining = await fetchMiningStats();
  const feesJson = await fetchRecommendedFees();
  const feeChoice = computeDynamicFee(feesJson);
  res.json({
    ok:true,
    mining,
    swap,
    btc,
    queue,
    dynamicFee: feeChoice,
    ts: new Date().toISOString()
  });
});

// Admin set fee bounds
app.post('/admin/fee-bounds', auth, (req,res)=> {
  const { min, max } = req.body || {};
  if (typeof min === 'number') process.env.FEE_MIN_SATVBYTE = String(min);
  if (typeof max === 'number') process.env.FEE_MAX_SATVBYTE = String(max);
  res.json({ ok:true, applied:{ min: process.env.FEE_MIN_SATVBYTE, max: process.env.FEE_MAX_SATVBYTE } });
});

// Serve a simple HTML dashboard
app.get('/', (req,res)=> {
  res.setHeader('Content-Type','text/html');
  res.end(`<!DOCTYPE html><html><head><title>Seraphina Unified Dashboard</title><style>body{background:#0d1117;color:#e6edf3;font-family:Arial;padding:20px}h1{color:#58a6ff}section{margin-bottom:30px}pre{background:#161b22;padding:12px;border-radius:8px;max-height:300px;overflow:auto}code{color:#ffa657}.pill{display:inline-block;padding:4px 10px;border-radius:20px;background:#238636;color:#fff;font-size:12px;margin-right:8px}</style></head><body><h1>Seraphina Unified Dashboard</h1><div id='top'></div><section><h2>Live Aggregate</h2><pre id='agg'>Loading...</pre></section><section><h2>WebSocket Feed</h2><pre id='wslog'></pre></section><script>async function load(){const r=await fetch('/status/summary');const j=await r.json();document.getElementById('agg').textContent=JSON.stringify(j,null,2);}setInterval(load,5000);load();const ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws');ws.onmessage=e=>{const el=document.getElementById('wslog');el.textContent=e.data+'\n'+el.textContent.split('\n').slice(0,200).join('\n');};</script></body></html>`);
});

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  wss.clients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(msg); });
}

async function periodicPush() {
  const swap = loadJSONSafe(SWAP_STATE_FILE);
  const btc = loadJSONSafe(BTC_STATE_FILE);
  const queue = loadJSONSafe(BTC_QUEUE_FILE) || [];
  const fees = await fetchRecommendedFees();
  const feeChoice = computeDynamicFee(fees);
  broadcast({ type:'update', ts: Date.now(), swap, btc, queueDepth: queue.length, dynamicFee: feeChoice });
  setTimeout(periodicPush, REFRESH_INTERVAL_MS);
}
periodicPush();

server.listen(PORT, () => {
  console.log(`[UNIFIED] Dashboard listening http://localhost:${PORT}`);
  console.log(`[UNIFIED] Dev JWT (DO NOT USE IN PROD):`, issueDevToken());
});
