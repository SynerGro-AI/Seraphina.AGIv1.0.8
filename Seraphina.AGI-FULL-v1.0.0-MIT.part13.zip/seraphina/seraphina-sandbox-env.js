// seraphina-sandbox-env.js
// Deterministic sandbox self-play environment to generate intrinsic motivation metrics.
// Cycles through knowledge shards applying intrinsic motivation engine and logs a sandbox-ledger.

'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { computeMetrics } = require('./intrinsic-motivation-engine.js');

const LEDGER = process.env.SANDBOX_LEDGER_PATH || 'sandbox-ledger.jsonl';
const CACHE_FILE = process.env.SANDBOX_CACHE_PATH || 'sandbox-cache.json';

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x : JSON.stringify(x)).digest('hex'); }

function appendLedger(entry){
  let prev='GENESIS';
  if(fs.existsSync(LEDGER)){
    try { const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/); if(lines.length){ const last=JSON.parse(lines[lines.length-1]); prev = last.chainHash || 'GENESIS'; } } catch(_){ }
  }
  entry.prevHash = prev;
  entry.chainHash = sha256(entry);
  fs.appendFileSync(LEDGER, JSON.stringify(entry)+'\n');
}

function loadCache(){
  if(!fs.existsSync(CACHE_FILE)) return null;
  try { return JSON.parse(fs.readFileSync(CACHE_FILE,'utf8')); } catch(_){ return null; }
}

function saveCache(cache){
  try { fs.writeFileSync(CACHE_FILE, JSON.stringify(cache,null,2)); } catch(_){ }
}

function runSandboxSession(options={}){
  const steps = options.steps || parseInt(process.env.SANDBOX_STEPS||'3',10);
  let state = { seenFacts:new Set(), recentShardHashes:[] };
  let cumulative = { curiosity:0, novelty:0, empowerment:0 };
  let cumulativeIntegration = 0;
  let lastDiversityHash=null;
  const cache = loadCache();
  if(cache && cache.steps===steps && cache.diversityHash && cache.session){
    // Reuse cached session result
    return cache.session;
  }
  for(let i=0;i<steps;i++){
    const metrics = computeMetrics(state);
    state = metrics.state;
    cumulative.curiosity += metrics.curiosity;
    cumulative.novelty += metrics.novelty;
    cumulative.empowerment += metrics.empowerment;
    cumulativeIntegration += metrics.integration||0;
    lastDiversityHash = metrics.diversityHash;
  }
  const avg = {
    curiosity: cumulative.curiosity/steps,
    novelty: cumulative.novelty/steps,
    empowerment: cumulative.empowerment/steps,
    integration: cumulativeIntegration/steps
  };
  const session = {
    ts: new Date().toISOString(),
    steps,
    avgCuriosity: Number(avg.curiosity.toFixed(6)),
    avgNovelty: Number(avg.novelty.toFixed(6)),
    avgEmpowerment: Number(avg.empowerment.toFixed(6)),
    avgIntegration: Number(avg.integration.toFixed(6)),
    diversityHash: lastDiversityHash
  };
  appendLedger(session);
  saveCache({ steps, diversityHash: lastDiversityHash, session });
  return session;
}

if(require.main === module){
  const res = runSandboxSession();
  process.stdout.write(JSON.stringify(res,null,2)+'\n');
}

module.exports = { runSandboxSession };
