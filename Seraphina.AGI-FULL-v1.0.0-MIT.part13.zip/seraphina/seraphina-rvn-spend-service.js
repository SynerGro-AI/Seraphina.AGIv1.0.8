if (process.env.REAL_STRICT !== '1' && process.env.DISABLE_DOTENV !== '1') { try { require('dotenv').config(); } catch {} }
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }
/**
 * RVN UTXO Spend Builder (Triad Gated)
 * Scans RVN address UTXOs (placeholder API) and builds unsigned transaction.
 * To fully realize: integrate Ravencoin RPC or authoritative explorer for UTXOs.
 */
const https=require('https');
const fs=require('fs');
const path=require('path');
let runProtectedAction=null;try{({runProtectedAction}=require('./triad-consensus-loader'))}catch{}

const RVN_ADDRESS = process.env.RVN_LOCAL_ADDRESS || 'RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7';
const DEST_ADDRESS = process.env.RVN_PAYOUT_ADDRESS || 'RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7';
const MIN_THRESHOLD_RVN = parseFloat(process.env.RVN_SPEND_THRESHOLD || '50');
const POLL_MS = parseInt(process.env.RVN_SPEND_POLL_MS || '600000',10); // 10m
const STATE_FILE = path.join(__dirname,'persistent_data','rvn_spend_state.json');

function loadState(){try{return JSON.parse(fs.readFileSync(STATE_FILE,'utf8'))}catch{return{ last:null }}}
function saveState(s){try{fs.writeFileSync(STATE_FILE, JSON.stringify(s,null,2))}catch{}}

function rvnGet(pathUrl){return new Promise((res,rej)=>{const opt={host:'api.ravencoin.org',path:pathUrl,method:'GET'};const r=https.request(opt,m=>{let d='';m.on('data',c=>d+=c);m.on('end',()=>{try{res(JSON.parse(d))}catch(e){rej(e)}})});r.on('error',rej);r.end();});}

async function fetchUTXOs(){
  if (typeof rvnListUnspent === 'function') { try { return await rvnListUnspent(RVN_ADDRESS,1); } catch {} }
  try {
    const json=await rvnGet('/api/address/'+RVN_ADDRESS);
    return (json.utxos||[]).map(u=>({ txid:u.txid, vout:u.vout, value:u.value }));
  } catch { return []; }
}

function buildUnsigned(utxos){
  const total=utxos.reduce((a,b)=>a+b.value,0);
  return { unsigned:true, total, inputs:utxos.length, to:DEST_ADDRESS, change:null, feeEstimate: Math.floor(utxos.length*180+34)/10 }; // placeholder
}

async function loop(){
  const st=loadState();
  const utxos=await fetchUTXOs();
  const total=utxos.reduce((a,b)=>a+b.value,0);
  const rvnValue= total/100000000;
  console.log('[RVN_SPEND] Balance', rvnValue.toFixed(4),'RVN (utxos='+utxos.length+')');
  if(rvnValue>=MIN_THRESHOLD_RVN && utxos.length){
    const attempt=()=>{ const plan=buildUnsigned(utxos); st.last= { ts:Date.now(), plan }; saveState(st); console.log('[RVN_SPEND] Prepared unsigned RVN tx plan'); return plan; };
    if(runProtectedAction){ try{ await runProtectedAction('rvn_spend_prepare',{ total:rvnValue }, attempt);}catch(e){ console.error('[RVN_SPEND] triad block', e.message);} }
    else attempt();
  }
  setTimeout(loop, POLL_MS).unref();
}
loop();
