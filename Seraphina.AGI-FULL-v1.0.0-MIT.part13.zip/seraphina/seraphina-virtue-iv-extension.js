"use strict";
// seraphina-virtue-iv-extension.js
// Causal extension stub: two-stage least squares (2SLS) estimation for truthfulness -> truthPassRate
// using an instrument 'infoQualityIndex' assumed to affect truthfulness but not directly outcome except via truthfulness.
// Deterministic generation; NO external dependencies.

const crypto = require('crypto');

function seedRng(seed){ return crypto.createHash('sha256').update(seed).digest(); }
let rngBuf; let rngOffset=0;
function init(seed){ rngBuf = seedRng(seed); rngOffset=0; }
function rand(){ if(rngOffset >= rngBuf.length){ rngBuf = crypto.createHash('sha256').update(rngBuf).digest(); rngOffset=0; } return rngBuf[rngOffset++] / 255; }
function randn(){ let u1=rand(); if(u1<=0) u1=1e-12; const u2=rand(); return Math.sqrt(-2*Math.log(u1))*Math.cos(2*Math.PI*u2); }

function genDataset(n=1500, seed='iv-seed'){
  init(seed);
  const rows=[];
  for(let i=0;i<n;i++){
    const infoQualityIndex = rand(); // instrument ∈ [0,1]
    const baseTruthfulness = (infoQualityIndex*0.6 + rand()*0.4); // instrument influence + idiosyncratic component
    const truthfulness = 1/(1+Math.exp(- (baseTruthfulness*3 - 1.5)));
    // Outcome truthPassRate depends on truthfulness plus noise; instrument affects outcome only through truthfulness
    const noise = randn()*0.25;
    const truthPassRate = Math.max(0, Math.min(1, 0.4 + 0.5*truthfulness + noise));
    rows.push({ infoQualityIndex, truthfulness, truthPassRate });
  }
  return rows;
}

// First stage: regress truthfulness on instrument (simple linear OLS)
function olsFit(x,y){
  const n=x.length; const mx=x.reduce((a,b)=>a+b,0)/n; const my=y.reduce((a,b)=>a+b,0)/n;
  let num=0, den=0; for(let i=0;i<n;i++){ num += (x[i]-mx)*(y[i]-my); den += (x[i]-mx)*(x[i]-mx); }
  const beta1 = den? num/den : 0; const beta0 = my - beta1*mx;
  return { beta0, beta1 };
}

function twoStageLeastSquares(rows){
  const Z = rows.map(r=> r.infoQualityIndex);
  const T = rows.map(r=> r.truthfulness);
  const Y = rows.map(r=> r.truthPassRate);
  const stage1 = olsFit(Z,T);
  const T_hat = Z.map(z=> stage1.beta0 + stage1.beta1*z);
  const stage2 = olsFit(T_hat, Y);
  // Naive standard error (not robust): residual variance / sum((T_hat - mean)^2)
  const meanThat = T_hat.reduce((a,b)=>a+b,0)/T_hat.length;
  let rss=0; for(let i=0;i<Y.length;i++){ rss += Math.pow(Y[i] - (stage2.beta0 + stage2.beta1*T_hat[i]),2); }
  const sigma2 = rss / (Y.length - 2);
  let denom=0; for(const th of T_hat){ denom += Math.pow(th - meanThat,2); }
  const seBeta1 = denom? Math.sqrt(sigma2 / denom) : NaN;
  const tStat = seBeta1? stage2.beta1 / seBeta1 : NaN;
  return { stage1, stage2, seBeta1, tStat };
}

function runIV(n=1500, seed='iv-seed'){
  const rows = genDataset(n, seed);
  const result = twoStageLeastSquares(rows);
  return { n, seed, ...result };
}

if(require.main === module){
  const nArg = process.argv.find(a=> /^--n=/.test(a));
  const seedArg = process.argv.find(a=> /^--seed=/.test(a));
  const n = nArg? parseInt(nArg.split('=')[1],10) : 1500;
  const seed = seedArg? seedArg.split('=')[1] : 'iv-seed';
  const res = runIV(n, seed);
  console.log('[IV2SLS]', JSON.stringify(res));
}

module.exports = { genDataset, twoStageLeastSquares, runIV };