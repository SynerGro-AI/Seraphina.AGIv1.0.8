/**
 * SERAPHINA TRIAD LATTICE GUARDIAN
 * -------------------------------------------------------------
 * 8-Point Crystal Lattice Tamper Detection + Self-Healing Hash Layer
 *
 * Conceptual mapping of the OctaLang crystal lattice & triad validators
 * into a practical Node.js integrity monitor for critical state files.
 *
 * Core Ideas Implemented:
 *  - 8-Point hashing per file (domain separated) → point_1 .. point_8
 *  - Consensus hash (sha256 of concatenated 8 point digests)
 *  - Triad validator fingerprints (Alpha/Beta/Gamma seeded hashes)
 *  - 2-of-3 consensus simulation (all three recompute; if consensusHash
 *    differs from stored, treat as anomaly & self-heal baseline)
 *  - Self-healing = accept new on-disk state as canonical after logging
 *  - Anomaly burst quarantine trigger (writes quarantine flag file)
 *  - Append-only audit ledger (logs/lattice-audit.log)
 *
 * This is NOT a cryptographically authoritative HSM, but provides a
 * structured integrity framework aligned with the user's OctaLang core.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// -------------------- Configuration --------------------
const DATA_DIR = path.join(__dirname, 'persistent_data');
const LOG_DIR = path.join(__dirname, 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const MANIFEST_FILE = path.join(DATA_DIR, 'lattice_manifest.json');
const QUARANTINE_FLAG = path.join(DATA_DIR, 'lattice_quarantine.flag');
const AUDIT_LOG = path.join(LOG_DIR, 'lattice-audit.log');

const DEFAULT_FILES = [
  'wallet_earnings.json',
  'wallet_backup.json',
  'session_log.json',
  'rvn_swap_state.json',
  'btc_transfer_state.json',
  'btc_incoming_queue.json',
  'wallet_seed.enc',
  'share_log_roots.chain'
].map(f => path.join(DATA_DIR, f));

// Allow override via env (semicolon separated absolute or relative paths)
const MONITORED_FILES = (process.env.TAMPER_FILES ? process.env.TAMPER_FILES.split(/;+/).map(f => path.resolve(__dirname, f.trim())) : DEFAULT_FILES);

const SCAN_INTERVAL_MS = parseInt(process.env.LATTICE_SCAN_MS || '30000', 10); // 30s
const ANOMALY_WINDOW_MS = parseInt(process.env.LATTICE_ANOMALY_WINDOW_MS || '600000', 10); // 10m
const MAX_ANOMALIES_IN_WINDOW = parseInt(process.env.LATTICE_MAX_ANOMALIES || '5', 10);

// Triad validator seeds (would normally be secret / external)
const VALIDATOR_SEEDS = {
  alpha: process.env.LATTICE_ALPHA_SEED || 'SERAPHINA_ALPHA_SEED_V1',
  beta: process.env.LATTICE_BETA_SEED || 'SERAPHINA_BETA_SEED_V1',
  gamma: process.env.LATTICE_GAMMA_SEED || 'SERAPHINA_GAMMA_SEED_V1'
};

// -------------------- Helpers --------------------
function sha256Hex(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function hashPoint(label, contentBuffer) {
  // domain separation: label + 0x00 + content
  return sha256Hex(Buffer.concat([Buffer.from(label + '\0'), contentBuffer]));
}

function loadManifest() {
  try {
    return JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf8'));
  } catch {
    return { version: 1, created: Date.now(), files: {}, anomalies: [] };
  }
}

function saveManifest(m) {
  try { fs.writeFileSync(MANIFEST_FILE, JSON.stringify(m, null, 2)); } catch {}
}

function logAudit(event) {
  const line = JSON.stringify({ ts: Date.now(), ...event });
  try { fs.appendFileSync(AUDIT_LOG, line + '\n'); } catch {}
}

function computeLatticeForFile(filePath) {
  const exists = fs.existsSync(filePath);
  if (!exists) return { missing: true };
  const stat = fs.statSync(filePath);
  const content = fs.readFileSync(filePath);
  // 8-point hashing (crystal lattice)
  const points = {
    point_1_north: hashPoint('NORTH_INTEGRITY', content),
    point_2_northeast: hashPoint('NORTHEAST_MALWARE', content),
    point_3_east: hashPoint('EAST_VIRUS', content),
    point_4_southeast: hashPoint('SOUTHEAST_HACK', content),
    point_5_south: hashPoint('SOUTH_CORRUPTION', content),
    point_6_southwest: hashPoint('SOUTHWEST_ACCESS', content),
    point_7_west: hashPoint('WEST_MEMORY', content),
    point_8_northwest: hashPoint('NORTHWEST_LOYALTY', content)
  };
  const consensusHash = sha256Hex(Buffer.from(Object.values(points).join(':')));
  const validatorFingerprints = {};
  for (const [k, seed] of Object.entries(VALIDATOR_SEEDS)) {
    validatorFingerprints[k] = sha256Hex(Buffer.from(seed + '::' + consensusHash));
  }
  return {
    missing: false,
    size: stat.size,
    mtimeMs: stat.mtimeMs,
    points,
    consensusHash,
    validatorFingerprints
  };
}

function withinWindow(ts, now) { return (now - ts) <= ANOMALY_WINDOW_MS; }

function recordAnomaly(manifest, detail) {
  manifest.anomalies.push({ ts: Date.now(), ...detail });
  // Trim old
  const now = Date.now();
  manifest.anomalies = manifest.anomalies.filter(a => withinWindow(a.ts, now));
}

function anomalyCount(manifest) {
  const now = Date.now();
  return manifest.anomalies.filter(a => withinWindow(a.ts, now)).length;
}

function checkQuarantine(manifest) {
  if (anomalyCount(manifest) > MAX_ANOMALIES_IN_WINDOW) {
    if (!fs.existsSync(QUARANTINE_FLAG)) {
      fs.writeFileSync(QUARANTINE_FLAG, 'QUARANTINE_ACTIVE ' + new Date().toISOString());
      logAudit({ type: 'quarantine_activated', reason: 'ANOMALY_THRESHOLD_EXCEEDED' });
      console.error('[LATTICE] QUARANTINE ACTIVATED');
    }
    return true;
  }
  return false;
}

// -------------------- Self-Healing Logic --------------------
function selfHeal(manifest, fileKey, newFingerprint) {
  const entry = manifest.files[fileKey];
  const previous = entry ? { consensusHash: entry.consensusHash, healedAt: Date.now() } : null;
  manifest.files[fileKey] = {
    ...newFingerprint,
    baselineTs: Date.now(),
    previousChain: entry && entry.previousChain ? [...entry.previousChain, previous] : (previous ? [previous] : [])
  };
  manifest.files[fileKey].lastHealed = Date.now();
  logAudit({ type: 'self_heal', file: fileKey, newConsensus: newFingerprint.consensusHash });
}

// -------------------- Main Scan Cycle --------------------
function scan() {
  const manifest = loadManifest();
  const now = Date.now();
  let changed = false;

  for (const f of MONITORED_FILES) {
    const lattice = computeLatticeForFile(f);
    const key = path.relative(__dirname, f);
    const baseline = manifest.files[key];

    if (lattice.missing) {
      if (baseline && !baseline.missing) {
        recordAnomaly(manifest, { type: 'file_missing', file: key });
        logAudit({ type: 'file_missing', file: key });
      }
      continue; // skip establishing baseline for missing files
    }

    if (!baseline) {
      // Establish baseline
      manifest.files[key] = { ...lattice, baselineTs: now };
      logAudit({ type: 'baseline_initialized', file: key, consensus: lattice.consensusHash });
      changed = true;
      continue;
    }

    if (baseline.consensusHash !== lattice.consensusHash) {
      // Tamper or legitimate change → treat as anomaly then self-heal
      recordAnomaly(manifest, { type: 'consensus_mismatch', file: key, old: baseline.consensusHash, new: lattice.consensusHash });
      logAudit({ type: 'consensus_mismatch_detected', file: key, old: baseline.consensusHash, new: lattice.consensusHash });
      selfHeal(manifest, key, lattice);
      changed = true;
      console.warn(`[LATTICE] MISMATCH & HEALED: ${key}`);
    }
  }

  checkQuarantine(manifest);
  if (changed) saveManifest(manifest);
}

// -------------------- Startup --------------------
console.log('[LATTICE] Seraphina Triad Lattice Guardian starting...');
console.log('[LATTICE] Monitoring files:', MONITORED_FILES.map(f => path.relative(__dirname, f)).join(', '));
scan();
setInterval(scan, SCAN_INTERVAL_MS).unref();

// Expose minimal HTTP status (optional)
if (process.env.LATTICE_STATUS_PORT) {
  const http = require('http');
  const port = parseInt(process.env.LATTICE_STATUS_PORT, 10);
  http.createServer((req, res) => {
    if (req.url === '/lattice-status') {
      const manifest = loadManifest();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: !fs.existsSync(QUARANTINE_FLAG),
        quarantine: fs.existsSync(QUARANTINE_FLAG),
        anomalyCount: anomalyCount(manifest),
        files: Object.keys(manifest.files),
        ts: Date.now()
      }));
    } else {
      res.writeHead(404); res.end();
    }
  }).listen(port, () => console.log(`[LATTICE] Status endpoint http://localhost:${port}/lattice-status`));
}

process.on('SIGINT', () => { console.log('\n[LATTICE] Shutting down'); process.exit(0); });
process.on('SIGTERM', () => { console.log('\n[LATTICE] Shutting down'); process.exit(0); });
