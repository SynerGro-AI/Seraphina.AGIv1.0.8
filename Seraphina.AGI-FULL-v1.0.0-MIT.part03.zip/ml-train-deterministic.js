// ml-train-deterministic.js
// Deterministic offline weight optimization for ML advisor.
// Performs grid search around current weights, evaluates candidates against historical trading signals.
// No randomness; candidate ordering and selection use stable hashes.
// Usage: node ml-train-deterministic.js
// Env:
//  TRAIN_DATA_SIGNALS_PATH (default trading-signals.jsonl)
//  TRAIN_DATA_LEARNED_PATH (default trading-learned-state.jsonl)
//  ML_WEIGHTS_IN (default ml-advisor-weights.json)
//  ML_TRAIN_OUTPUT (default ml-advisor-weights-trained.json)
//  ML_TRAIN_SCOREBOARD (default ml-train-scoreboard.json)
//  ML_TRAIN_CANDIDATES (default 24)
//  ML_TRAIN_IMPROVE_MIN (default 0.015)
//  ML_TRAIN_FEES_MODE (netSpread or adjustedSpread) selects scoring basis
//  ML_TRAIN_METRIC (default netGain) future extensibility
// Produces:
//  - scoreboard JSON with candidate scores & chosen improvement
//  - trained weights file (if improvement >= threshold)
//  - append-only ledger ml-train-ledger.jsonl (hash-chained)

'use strict';
const fs = require('fs');
const crypto = require('crypto');

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }
function readJsonLines(path, limit){
  if(!fs.existsSync(path)) return [];
  const lines = fs.readFileSync(path,'utf8').trim().split(/\n+/);
  if(limit && lines.length>limit) lines = lines.slice(-limit);
  const out=[]; for(const l of lines){ try{ out.push(JSON.parse(l)); } catch(_){} }
  return out;
}

const SIGNALS_PATH = process.env.TRAIN_DATA_SIGNALS_PATH || 'trading-signals.jsonl';
const LEARNED_PATH = process.env.TRAIN_DATA_LEARNED_PATH || 'trading-learned-state.jsonl';
const WEIGHTS_IN = process.env.ML_WEIGHTS_IN || 'ml-advisor-weights.json';
const OUT_WEIGHTS = process.env.ML_TRAIN_OUTPUT || 'ml-advisor-weights-trained.json';
const OUT_SCOREBOARD = process.env.ML_TRAIN_SCOREBOARD || 'ml-train-scoreboard.json';
const LEDGER_PATH = 'ml-train-ledger.jsonl';
const CANDIDATE_COUNT = parseInt(process.env.ML_TRAIN_CANDIDATES || '24',10);
const ENABLE_DIRECTIONAL = (process.env.ML_TRAIN_DIRECTIONAL || '0') === '1';
const ENABLE_SHRINK = (process.env.ML_TRAIN_SHRINK || '0') === '1';
const IMPROVE_MIN = parseFloat(process.env.ML_TRAIN_IMPROVE_MIN || '0.015');
const FEES_MODE = process.env.ML_TRAIN_FEES_MODE || 'netSpread';
const METRIC = process.env.ML_TRAIN_METRIC || 'netGain';

function loadWeights(){
  if(!fs.existsSync(WEIGHTS_IN)) return { version:'base', features:['acceptRatio','latencyMedian','incomeSpread','biasFREN','biasRVN'], vector:[0.35,-0.15,0.25,0.18,0.07] };
  try { return JSON.parse(fs.readFileSync(WEIGHTS_IN,'utf8')); } catch(e){ return { version:'fallback', features:['acceptRatio','latencyMedian','incomeSpread','biasFREN','biasRVN'], vector:[0.35,-0.15,0.25,0.18,0.07] }; }
}

function extractFeatureVector(entry){
  // Map trading signal + learned file context into advisor features
  const sig = entry.signal || {};
  const acceptRatio = typeof sig.spread === 'number'? Math.min(1, Math.max(0, sig.spread)) : 0; // proxy if no direct accept ratio in signal
  const latencyMedian = typeof sig.volatility === 'number'? sig.volatility : 0; // placeholder if actual latency not in structured signal
  const incomeSpread = typeof sig.spread === 'number'? sig.spread : 0;
  const biasFREN = 1; // unknown from signals; assume neutral
  const biasRVN = 1;
  return [acceptRatio, latencyMedian, incomeSpread, biasFREN, biasRVN];
}

function scoreCandidate(vec, signals){
  let netGain=0, churn=0, missed=0;
  for(const entry of signals){
    const feats = extractFeatureVector(entry);
    let score=0; for(let i=0;i<vec.length;i++){ score += vec[i]*feats[i]; }
    const norm = 1/(1+Math.exp(-score));
    const sig = entry.signal||{};
    const basis = FEES_MODE==='netSpread'? (sig.netSpread||0) : (sig.adjustedSpread||0);
    // Hypothetical action: if norm < 0.4 encourage bias increase -> treat as potential swap capture; if norm > 0.85 bias reduce -> caution hold.
    // Deterministic simple mapping:
    const wouldSwap = norm < 0.4 && basis > 0; // candidate recommends aggressive capture
    const actualSwap = sig.action === 'swap';
    if (wouldSwap && actualSwap){ netGain += basis; }
    else if (wouldSwap && !actualSwap){ missed += basis; }
    if (actualSwap){ churn += 1; }
  }
  // Penalize missed opportunities and churn
  const score = netGain - (missed * 0.5) - (churn * 0.001);
  return { score: Number(score.toFixed(8)), netGain: Number(netGain.toFixed(8)), missed: Number(missed.toFixed(8)), churn };
}

function generateCandidates(base){
  const deltas = [-0.05, -0.02, 0, 0.02, 0.05];
  const cands=[];
  // Grid neighborhood
  for(const d0 of deltas){
    for(const d1 of deltas){
      for(const d2 of deltas){
        for(const d3 of deltas){
          for(const d4 of deltas){
            const vec = [
              Number((base[0]+d0).toFixed(6)),
              Number((base[1]+d1).toFixed(6)),
              Number((base[2]+d2).toFixed(6)),
              Number((base[3]+d3).toFixed(6)),
              Number((base[4]+d4).toFixed(6))
            ];
            cands.push(vec);
          }
        }
      }
    }
  }
  // Directional single-feature nudges (if enabled)
  if(ENABLE_DIRECTIONAL){
    const dirSteps = [-0.08,-0.04,-0.02,0.02,0.04,0.08];
    for(let i=0;i<base.length;i++){
      for(const step of dirSteps){
        const vec = base.slice();
        vec[i] = Number((vec[i]+step).toFixed(6));
        cands.push(vec);
      }
    }
  }
  // Shrink (L2 magnitude reduction) strategy (if enabled): scale vector by factors
  if(ENABLE_SHRINK){
    const factors = [0.92,0.96,0.98,1.02,1.04,1.08]; // include slight expansion options
    for(const f of factors){
      const vec = base.map(v => Number((v*f).toFixed(6)));
      cands.push(vec);
    }
  }
  // Deduplicate deterministically
  const uniq=[]; const seen=new Set();
  for(const v of cands){ const h=stableHash(v); if(!seen.has(h)){ seen.add(h); uniq.push(v); } }
  uniq.sort((a,b)=>{ const ha=stableHash(a).slice(0,16); const hb=stableHash(b).slice(0,16); return ha.localeCompare(hb); });
  return uniq.slice(0, CANDIDATE_COUNT);
}

function appendLedger(entry){
  try {
    let prev='GENESIS';
    if(fs.existsSync(LEDGER_PATH)){
      try { const lines=fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/); const obj=JSON.parse(lines[lines.length-1]); prev = obj.chainHash||'GENESIS'; } catch(_){}
    }
    entry.prevHash = prev;
    entry.chainHash = stableHash(entry);
    fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+"\n");
  } catch(e){ /* ignore */ }
}

function main(){
  const weights = loadWeights();
  const signals = readJsonLines(SIGNALS_PATH, 5000);
  const signalsDigest = stableHash(signals);
  const baseScore = scoreCandidate(weights.vector, signals);
  const candidates = generateCandidates(weights.vector);
  const results=[];
  for(const vec of candidates){ results.push({ vec, res: scoreCandidate(vec, signals) }); }
  results.sort((a,b)=>{
    if (b.res.score === a.res.score){ const ha=stableHash(a.vec).slice(0,8); const hb=stableHash(b.vec).slice(0,8); return ha.localeCompare(hb); }
    return b.res.score - a.res.score;
  });
  const best = results[0];
  const improvement = baseScore.score===0? (best.res.score>0? 1:0) : (best.res.score - baseScore.score)/Math.abs(baseScore.score);
  const scoreboard = {
    ts: new Date().toISOString(),
    metric: METRIC,
    feesMode: FEES_MODE,
    candidateCount: candidates.length,
    base: { vector: weights.vector, ...baseScore },
    best: { vector: best.vec, ...best.res },
    improvementPct: Number(improvement.toFixed(8)),
    signalsDigest,
    improvementAccepted: improvement >= IMPROVE_MIN
  };
  fs.writeFileSync(OUT_SCOREBOARD, JSON.stringify(scoreboard,null,2));
  let updated=false;
  if (improvement >= IMPROVE_MIN){
    const newWeights = { version: 'trained-'+scoreboard.ts.replace(/[:T\-]/g,'').slice(0,15), features: weights.features, vector: best.vec };
    fs.writeFileSync(OUT_WEIGHTS, JSON.stringify(newWeights,null,2));
    updated=true;
  }
  appendLedger({ t:Date.now(), updated, improvementPct: Number(improvement.toFixed(8)), baseScore: baseScore.score, bestScore: best.res.score, bestVec: best.vec });
  console.log(JSON.stringify({ updated, improvementPct: Number(improvement.toFixed(8)), outWeights: updated? OUT_WEIGHTS : null, scoreboard: OUT_SCOREBOARD }, null,2));
}

main();
