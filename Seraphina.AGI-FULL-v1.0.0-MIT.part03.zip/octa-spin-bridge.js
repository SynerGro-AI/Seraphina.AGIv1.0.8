#!/usr/bin/env node
// octa-spin-bridge.js
// Generates an OctaLang aggregate spin hash using Seraphina AdvancedLanguageEngine and persists it
// Usage:
//   node octa-spin-bridge.js <path-to-language-engine.js> [octa-file or inline snippet]
// Env:
//   OCTA_SNIPPET   Inline OctaLang code if no file provided
//   OUTPUT_FILE    (default octa-spin.txt) where hex spin is written
//   ECHO_CMD=1     Print a miner CLI command suggestion (set-spin <hex>)

const fs = require('fs');
const path = require('path');

(async ()=>{
  try {
    const enginePath = process.argv[2] || path.join(__dirname,'..','Seraphina-Smart-Assistant','SynerGro.AI_Client_8.0.1','AI_core','language-engine.js');
    if (!fs.existsSync(enginePath)) {
      console.error('[Bridge] language-engine.js not found at', enginePath);
      process.exit(2);
    }
    const AdvancedLanguageEngine = require(enginePath);
    const eng = new AdvancedLanguageEngine();
    // Wait a short moment for async initialization (translation tables, etc.)
    await new Promise(r=>setTimeout(r,150));
    let octaCode = null;
    const userFile = process.argv[3];
    if (userFile && fs.existsSync(userFile)) {
      octaCode = fs.readFileSync(userFile,'utf8');
    } else if (process.env.OCTA_SNIPPET) {
      octaCode = process.env.OCTA_SNIPPET;
    } else {
      // Minimal default snippet
      octaCode = `lattice spin: 🌀 ⬣\nnode(1,2,3)=> { qentangle() 🔵 }\nfn fuse(a,b)->c: 🛠️ { qsuperpose(a,b); }\nqdot(a,b);`;
    }
    const spinRes = await eng.computeOctaSpin(octaCode);
    if (spinRes.error){ console.error('[Bridge] computeOctaSpin error', spinRes.error); process.exit(3); }
    const hex = spinRes.aggregate_spin;
    const outFile = process.env.OUTPUT_FILE || path.join(process.cwd(),'octa-spin.txt');
    fs.writeFileSync(outFile, hex + '\n');
    console.log('[Bridge] Wrote spin', hex, 'to', outFile, 'nodes=', spinRes.nodes, 'funcs=', spinRes.functions, 'qops=', spinRes.quantum_ops);
    if (process.env.ECHO_CMD==='1') {
      console.log('\nCLI apply: set-spin', hex);
      console.log('Env apply: set OCTA_SPIN_HASH='+hex);
    }
  } catch(e){
    console.error('[Bridge] failure:', e.message);
    process.exit(1);
  }
})();
