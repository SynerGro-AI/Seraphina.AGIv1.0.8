// Minimal octo.c implementing 8-coefficient octonion multiply/power with SIMD hints.
// Build example:
//   emcc octo.c -O3 -msimd128 -s WASM=1 -s SIDE_MODULE=0 -s EXPORTED_FUNCTIONS='["_multiply","_power","_norm"]' -o octo-simd.wasm
// Coefficients treated as float32[8]. This is a simplified non-associative product (Cayley-Dickson reduced).

#include <stdint.h>
#include <math.h>
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#endif

// Memory layout expectations (simple flat array passed via indices by JS wrapper).
// For simplicity we assume JS wrapper copies floats into linear memory offsets.
// We expose functions that read from global memory.

// Emscripten provides linear memory; we treat incoming pointers as float*.

EMSCRIPTEN_KEEPALIVE
void _multiply(float* a, float* b, float* out){
  // out[0] = a0*b0 - sum(ai*bi)
  float acc = 0.0f;
  for (int i=1;i<8;i++) acc += a[i]*b[i];
  out[0] = a[0]*b[0] - acc;
  for (int i=1;i<8;i++){
    out[i] = a[0]*b[i] + b[0]*a[i];
  }
  // Fano plane triad enhancement (static set)
  // Triads (1,2,4,-1), (1,3,5,1), (1,6,7,-1), (2,3,6,1), (2,5,7,1), (3,4,7,1), (4,5,6,-1)
  // Apply signed product adjustments to k component.
  int triads[7][4] = {{1,2,4,-1},{1,3,5,1},{1,6,7,-1},{2,3,6,1},{2,5,7,1},{3,4,7,1},{4,5,6,-1}};
  for (int t=0;t<7;t++){
    int i = triads[t][0];
    int j = triads[t][1];
    int k = triads[t][2];
    int s = triads[t][3];
    out[k] += s * a[i] * b[j];
  }
}

EMSCRIPTEN_KEEPALIVE
void _power(float* a, float* out){
  // power^2 = multiply(a,a)
  _multiply(a,a,out);
}

EMSCRIPTEN_KEEPALIVE
float _norm(float* a){
  float s=0.0f; for (int i=0;i<8;i++) s += a[i]*a[i]; return sqrtf(s);
}
