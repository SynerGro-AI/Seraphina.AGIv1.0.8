// pareto-multi-metric-optimizer.js
// Deterministic multi-metric Pareto front computation for imaginationGain, curiosityGain, integrationNorm, and optionally empowermentGain.
// Generates weighted candidate configurations and selects non-dominated set.
// Output ledger: pareto-front-ledger.jsonl with chain hashing.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const LEDGER = 'pareto-front-ledger.jsonl';

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function generateWeightGrid(res, dims){
  // Grid over "dims" metrics; normalize to sum=1.
  const steps=[]; for(let i=0;i<res;i++){ steps.push(i/(res-1)); }
  const candidates=[];
  // Recursive generation for variable dimension count (small res so combinatorial okay)
  function rec(prefix, depth){
    if(depth === dims){
      const sum = prefix.reduce((a,b)=>a+b,0);
      if(sum === 0) return;
      const w = prefix.map(x=> x/sum);
      candidates.push(w);
      return;
    }
    for(const s of steps){ rec(prefix.concat([s]), depth+1); }
  }
  rec([],0);
  // Deterministic sort by hash
  candidates.sort((x,y)=> sha256(x).localeCompare(sha256(y)) );
  return candidates;
}

function computeGains(weights, metrics){
  // metrics: { imaginationGain, curiosityGain, integrationNorm }
  return weights[0]*metrics.imaginationGain + weights[1]*metrics.curiosityGain + weights[2]*metrics.integrationNorm;
}

function isDominated(point, others){
  // point: { w, metrics } where metrics is array [imagGain, curGain, intGain]
  for(const o of others){
    if(o === point) continue;
    const dominate = (o.metrics[0] >= point.metrics[0]) && (o.metrics[1] >= point.metrics[1]) && (o.metrics[2] >= point.metrics[2])
      && ( (o.metrics[0] > point.metrics[0]) || (o.metrics[1] > point.metrics[1]) || (o.metrics[2] > point.metrics[2]) );
    if(dominate) return true;
  }
  return false;
}

function buildParetoFront(metrics){
  const res = parseInt(process.env.PARETO_GRID_RES || '5',10);
  const includeEmp = process.env.PARETO_INCLUDE_EMPOWERMENT === '1';
  const includeNovel = process.env.PARETO_INCLUDE_NOVELTY === '1';
  const dims = 3 + (includeEmp?1:0) + (includeNovel?1:0);
  const grid = generateWeightGrid(res, dims);
  const maxCandidates = parseInt(process.env.PARETO_MAX_CANDIDATES || '0',10);
  const candidateGrid = maxCandidates > 0 ? grid.slice(0, maxCandidates) : grid;
  const noveltyGainRaw = metrics.noveltyGain||0;
  const noveltySparseThreshold = parseFloat(process.env.NOVELTY_SPARSE_THRESHOLD||'0');
  const noveltyGain = noveltyGainRaw < noveltySparseThreshold ? 0 : noveltyGainRaw;
  const base = [metrics.imaginationGain, metrics.curiosityGain, metrics.integrationNorm];
  const withEmp = includeEmp ? base.concat([metrics.empowermentGain||0]) : base;
  const full = includeNovel ? withEmp.concat([noveltyGain]) : withEmp;
  const points = candidateGrid.map(w=> ({ w, metrics: full }));
  const frontRaw = points.filter(p=> !isDominated(p, points));
  // Epsilon pruning
  const epsUnified = parseFloat(process.env.PARETO_EPSILON || '0');
  const epsImag = parseFloat(process.env.PARETO_EPSILON_IMAGINATION || epsUnified || '0');
  const epsCurio = parseFloat(process.env.PARETO_EPSILON_CURIOSITY || epsUnified || '0');
  const epsInt = parseFloat(process.env.PARETO_EPSILON_INTEGRATION || epsUnified || '0');
  const epsEmp = includeEmp ? parseFloat(process.env.PARETO_EPSILON_EMPOWERMENT || epsUnified || '0') : 0;
  const epsNovel = includeNovel ? parseFloat(process.env.PARETO_EPSILON_NOVELTY || epsUnified || '0') : 0;
  const eps = [epsImag, epsCurio, epsInt].concat(includeEmp?[epsEmp]:[]).concat(includeNovel?[epsNovel]:[]);
  let pruned = [];
  if(eps.some(e=> e>0)){
    for(const p of frontRaw){
      let near = false;
      for(const q of pruned){
        let allWithin = true;
        for(let i=0;i<q.metrics.length;i++){
          if(Math.abs(p.metrics[i]-q.metrics[i]) > eps[i]){ allWithin = false; break; }
        }
        if(allWithin){ near = true; break; }
      }
      if(!near) pruned.push(p);
    }
  } else {
    pruned = frontRaw;
  }
  return { front: pruned, originalFrontSize: frontRaw.length };
}

function appendLedger(entry){
  let prev='GENESIS';
  if(fs.existsSync(LEDGER)){
    try { const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/); if(lines.length){ const obj=JSON.parse(lines[lines.length-1]); prev = obj.chainHash || 'GENESIS'; } } catch(_){ }
  }
  entry.prevHash = prev;
  entry.chainHash = sha256(entry);
  fs.appendFileSync(LEDGER, JSON.stringify(entry)+'\n');
}

function selectRepresentative(front){
  if(!front.length) return [];
  const dims = front[0].w.length;
  const mode = process.env.PARETO_REP_MODE || 'median';
  if(mode === 'average'){
    const avg = new Array(dims).fill(0);
    front.forEach(p=>{ for(let i=0;i<dims;i++){ avg[i]+=p.w[i]; } });
    return avg.map(v=> v/front.length);
  }
  if(mode === 'median'){
    const comps = new Array(dims).fill(null).map(()=>[]);
    front.forEach(p=>{ for(let i=0;i<dims;i++){ comps[i].push(p.w[i]); } });
    comps.forEach(arr=> arr.sort((a,b)=> a-b));
    return comps.map(arr=> arr[Math.floor(arr.length/2)]);
  }
  if(mode === 'gov-nearest'){
    // Governance baseline env weights choose closest vector in L2; extend with empowerment weight if dims=4
    const baseGw = [
      parseFloat(process.env.IMAGINATION_GAIN_WEIGHT||'0'),
      parseFloat(process.env.CURIOSITY_GAIN_WEIGHT||'0'),
      parseFloat(process.env.INTEGRATION_GAIN_WEIGHT||'0')
    ];
    const gw = (dims===4) ? baseGw.concat([parseFloat(process.env.EMPOWERMENT_GAIN_WEIGHT||'0')]) : baseGw;
    let best = front[0].w, bestDist = Infinity;
    for(const p of front){
      let dSum=0; for(let i=0;i<dims;i++){ dSum += (p.w[i]-gw[i])**2; }
      const d = Math.sqrt(dSum);
      if(d < bestDist){ bestDist = d; best = p.w; }
    }
    return best;
  }
  // Fallback: average
  const avg = new Array(dims).fill(0);
  front.forEach(p=>{ for(let i=0;i<dims;i++){ avg[i]+=p.w[i]; } });
  return avg.map(v=> v/front.length);
}

function runPareto(metrics){
  const built = buildParetoFront(metrics);
  const front = built.front;
  const representative = selectRepresentative(front);
  const entry = { ts: Date.now(), metrics, frontSize: front.length, originalFrontSize: built.originalFrontSize, representative: representative.map(v=> Number(v.toFixed(6))), repMode: process.env.PARETO_REP_MODE || 'median', dims: front.length? front[0].w.length : (3 + (process.env.PARETO_INCLUDE_EMPOWERMENT==='1'?1:0) + (process.env.PARETO_INCLUDE_NOVELTY==='1'?1:0)) };
  entry.epsilon = {
    imagination: parseFloat(process.env.PARETO_EPSILON_IMAGINATION || process.env.PARETO_EPSILON || '0'),
    curiosity: parseFloat(process.env.PARETO_EPSILON_CURIOSITY || process.env.PARETO_EPSILON || '0'),
    integration: parseFloat(process.env.PARETO_EPSILON_INTEGRATION || process.env.PARETO_EPSILON || '0'),
  empowerment: (process.env.PARETO_INCLUDE_EMPOWERMENT === '1') ? parseFloat(process.env.PARETO_EPSILON_EMPOWERMENT || process.env.PARETO_EPSILON || '0') : undefined,
  novelty: (process.env.PARETO_INCLUDE_NOVELTY === '1') ? parseFloat(process.env.PARETO_EPSILON_NOVELTY || process.env.PARETO_EPSILON || '0') : undefined
  };
  appendLedger(entry);
  return entry;
}

if(require.main === module){
  // Expect environment to provide current gains (defaults 0)
  const metrics = {
    imaginationGain: parseFloat(process.env.CURRENT_IMAGINATION_GAIN || '0'),
    curiosityGain: parseFloat(process.env.CURRENT_CURIOSITY_GAIN || '0'),
    integrationNorm: parseFloat(process.env.CURRENT_INTEGRATION_NORM || '0')
  };
  const res = runPareto(metrics);
  process.stdout.write(JSON.stringify(res,null,2)+'\n');
}

module.exports = { runPareto };
