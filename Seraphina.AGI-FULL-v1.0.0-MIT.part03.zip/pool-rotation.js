"use strict";
// pool-rotation.js – switch active coin (and stratum) based on econ recommendation
// Exports: attachPoolRotation(pipeline, hookFn)
// Requirements: coin-config.js & RealStratumClient

const { HASH_STRATEGIES } = require('./hash-strategies.js');

function attachPoolRotation(pipeline){
  let rotating = false; let attempt=0; let nextAllowed=0;
  async function rotateTo(coin){
    const now=Date.now();
    if (!pipeline || rotating) return; if (pipeline.selectedCoin === coin) return;
    if (now < nextAllowed) return;
    rotating = true;
    try {
      const COINS = require('./coin-config.js');
      const cfg = COINS[coin]; if (!cfg){ console.warn('[Rotate] unsupported coin', coin); attempt++; scheduleRetry(); return; }
      console.log('[Rotate] Switching from', pipeline.selectedCoin, 'to', coin);
      if (pipeline.stratum){ try { pipeline.stratum.close(); } catch(_){ } }
      pipeline.selectedCoin = coin;
      pipeline.hashStrategy = HASH_STRATEGIES[cfg.algo] || HASH_STRATEGIES.sha256d;
      const { RealStratumClient } = require('./real-stratum-client.js');
      pipeline.stratum = new RealStratumClient({ coin: coin });
      await pipeline.stratum.connect().catch(e=>{ throw e; });
      pipeline.wire();
      attempt=0; // reset on success
    } catch(e){
      attempt++; console.error('[Rotate] error', e.message, 'attempt', attempt); scheduleRetry();
    } finally { rotating=false; }
  }
  function scheduleRetry(){
    const maxDelay = parseInt(process.env.AUR_ROTATE_MAX_BACKOFF_MS || '600000',10);
    const base = 2000;
    const delay = Math.min(maxDelay, base * Math.pow(2, attempt));
    nextAllowed = Date.now() + delay;
    console.log('[Rotate] next allowed attempt in', delay,'ms');
  }
  pipeline.rotateToCoin = rotateTo;
  return rotateTo;
}

module.exports = { attachPoolRotation };
