# Packaging & Distribution

## Goals
Provide a deterministic, integrity-verifiable portable bundle (USB / SD card / Pi image) containing only required runtime modules, ledgers, audit tools, and manifest of hashes.

## Artifacts Included
- Core orchestrator: `aurrelia-pico-mesh-miner.js`
- Portable entry: `seraphina-mining-portable.js`
- Integrity tools: `integrity-audit.js`, `environment-audit.js`
- Governance ledger: `governance-ledger.jsonl` (optional if exists)
- Economic ledgers: `share-ledger.jsonl`, `swap-ledger.jsonl`, `parity-ledger.jsonl`, `econ-realization-ledger.jsonl`, `price-ledger.jsonl`
- Tests: `tests/run-tests.js`
- Manifest script: `generate-usb-manifest.js`
- Minimal `package.json` (dependency pinning)
- README excerpt / this file

## Manifest Generation
Prefer the automated pipeline: `npm run full:package` which performs:
1. `integrity-audit.js` (emits timestamped `audit-YYYY-MM-DD-HH-MM-SS.json`)
2. `generate-usb-manifest.js` (now also embeds `auditMerkleRoot` from latest audit file)
3. `verify-manifest.js` validation pass

Manual invocation (if needed): `node generate-usb-manifest.js`

`artifact-hashes.json` contains:
```json
{
  "generated": 1730000000000,
  "artifacts": [ { "file":"aurrelia-pico-mesh-miner.js","size":12345,"sha256":"..." } ],
  "merkleRoot": "<root>",
  "auditMerkleRoot": "<latest-ledger-audit-root>",
  "hmacSeal": "<optional>"
}
```

## USB Preparation (Windows PowerShell)
```powershell
# Assume USB mounted at E:\
$target = 'E:\seraphina-runtime'
New-Item -ItemType Directory -Force -Path $target
Copy-Item aurrelia-pico-mesh-miner.js,seraphina-mining-portable.js,integrity-audit.js,environment-audit.js,package.json -Destination $target
Copy-Item *.jsonl -Destination $target -ErrorAction SilentlyContinue
Copy-Item tests -Destination $target -Recurse
Copy-Item artifact-hashes.json -Destination $target -ErrorAction SilentlyContinue
Copy-Item PACKAGING.md -Destination $target
Set-Location $target
node ..\generate-usb-manifest.js > artifact-hashes.json
```

## Raspberry Pi / BigTreeTech Pi (BTT) Notes
See `PI-INTEGRATION.md` for systemd unit, performance flags, thermal guidance.

## Determinism Checklist
- No `Math.random()` for integrity-critical paths
- All fallback values derived via SHA256 of stable inputs
- Ledger entries contain chain_hash with previous hash linking
- Audit Merkle root reproducible for same ledger set

## Optional HMAC
Set `USB_MANIFEST_HMAC_KEY` before running `npm run full:package` (or `node generate-usb-manifest.js`) to embed a `hmacSeal` derived from the manifest Merkle root. Example (PowerShell):
```powershell
$env:USB_MANIFEST_HMAC_KEY = 'YOUR-SECRET-256-BIT-KEY-HEX'
npm run full:package
```
Keep the key offline; rotate if any artifact changes unexpectedly.

### Vault-Based Key Retrieval
If you prefer not placing the HMAC key directly in environment variables, you can store it in the lightweight vault file consumed by `seraphina-key-vault`.

1. Add the record to your vault (label must be unique):
```jsonc
{
  "manifest_hmac_key": { "value": "<64-128 hex characters>", "purpose": "usb-manifest-hmac" }
}
```
2. Export `VAULT_PASS` (unlock password) and `VAULT_MANIFEST_KEY_LABEL` (record label) prior to generation:
```powershell
$env:VAULT_PASS = 'your-vault-pass'
$env:VAULT_MANIFEST_KEY_LABEL = 'manifest_hmac_key'
npm run full:package
```
`generate-usb-manifest.js` will attempt vault retrieval if `USB_MANIFEST_HMAC_KEY` is unset.

## Automated Nightly Audits
Use `cron-setup.sh` on Linux (Pi) to schedule nightly integrity audits and log rotation:
```bash
sudo bash cron-setup.sh pi
```
This installs a 02:15 UTC audit cron and logrotate rules for `*-ledger.jsonl` and `audit-log.jsonl`.

### Continuous Monitoring Script
You can run a lightweight monitoring wrapper that:
- Regenerates integrity audit + manifest verification
- Produces chain tips diff vs previous snapshot
- Emits concise status line and exit codes

Invoke manually:
```powershell
npm run audit:monitor
```
Sample output fragments:
```
[CHAIN_TIPS_DIFF] { "changed": false }
[AUDIT_MONITOR] verification=OK auditMatch=1 envChainOk=1 hmac=1 snapshots=42
```
Exit codes: 0 (OK), 1 (generic fail), 2 (audit root mismatch).

For a rapid diff only (after two runs):
```powershell
npm run diff:tips
```
This compares `chain-tips-prev.json` vs current `chain-tips.json`.

### Prometheus Textfile Export
After running `audit:monitor` or `audit:all`, export chain tip metrics:
```powershell
npm run export:tips:prom
```
This generates `chain-tips.prom` (or path in `CHAIN_TIPS_PROM_PATH`) with:
- `aur_chain_tip_last_hash_length{ledger="..."}` per ledger
- `aur_chain_tip_fingerprint{ledger="...",fingerprint="<first12hex>"}` constant gauge
- Export timestamp metric
Configure node_exporter: `--collector.textfile.directory=/var/lib/node_exporter/textfile` and move the `.prom` file on Ubuntu.

### Systemd Timer Install (Ubuntu)
Deploy automated audit monitor + export:
```bash
sudo bash install-monitor-systemd.sh /opt/seraphina
```
Environment variables:
- `MONITOR_INTERVAL_SEC` override default 300s.
- `AUDIT_MONITOR_MIN_INTERVAL_MS` rate limit guard (defaults 240000 ms).
Service runs `audit-monitor.js` then `export-chain-tips-prom.js`.

## Chain Tips Quick Diff
`npm run audit:all` now emits `chain-tips.json` summarizing the latest `chain_hash` for each ledger:
```json
{
  "ts": 1730000000000,
  "tips": {
    "share-ledger.jsonl": "<hash>",
    "swap-ledger.jsonl": "<hash>"
  }
}
```
Store successive versions and diff the hashes for rapid anomaly detection without parsing full ledgers.
Monitoring (`audit:monitor`) automatically maintains `chain-tips-prev.json` for diffs.

## Updating Bundle
1. Regenerate manifest.
2. Run integrity audit and store latest audit file alongside manifest.
3. Record Merkle root + governance proposal count externally (operations log).

## Verification Command
```powershell
node -e "const fs=require('fs');const m=JSON.parse(fs.readFileSync('artifact-hashes.json'));for(const a of m.artifacts){const h=require('crypto').createHash('sha256').update(fs.readFileSync(a.file)).digest('hex');if(h!==a.sha256){throw new Error('Mismatch '+a.file)} }; console.log('All match')"
```
