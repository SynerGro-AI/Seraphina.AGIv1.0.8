// preflight-guard.js
// Runs midstate self-test; exits non-zero if mismatches found.
const { spawnSync } = require('child_process');
const res = spawnSync(process.execPath, ['midstate_selftest.js'], { encoding:'utf8' });
if (res.error){ console.error('[Preflight] spawn error', res.error); process.exit(1); }
const out = (res.stdout||'').trim().split(/\n/).pop();
try {
  const parsed = JSON.parse(out);
  if (parsed.mismatches && parsed.mismatches > 0){
    console.error('[Preflight] midstate mismatch detected:', parsed);
    process.exit(1);
  }
  console.log('[Preflight] midstate self-test OK:', parsed);
} catch(e){
  console.error('[Preflight] parse failure; raw output:\n', res.stdout);
  process.exit(1);
}