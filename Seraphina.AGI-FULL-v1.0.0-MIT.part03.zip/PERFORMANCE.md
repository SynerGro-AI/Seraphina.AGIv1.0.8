# Performance & Throughput Optimization

## 1. Goals
Maximize accepted shares per watt with deterministic, auditable behavior. Avoid non-deterministic tuning (no random jitter). All adaptive decisions are rule / hash driven.

## 2. Hash Pipeline Overview
- Stratum event loop (I/O bound) feeds job templates.
- Compute layer: modular strategies (sha256d, kawpow, scrypt placeholder). Optional native addon (kawpow) for GPU acceleration.
- Parity digest chain collects normalized difficulty for cross-coin efficiency comparisons.

## 3. Key Environment Levers
| Variable | Impact |
|----------|--------|
| BATCH_SIZE / dynamic internal ramp | Larger batches reduce per-share overhead but increase latency variance. |
| BALANCE_ACCRUE_MS | Frequency of balance credit flush; too low wastes I/O, too high increases credit burstiness. |
| ECON_INTERVAL_MS | Economic update cadence; raising reduces API load; lowering increases responsiveness for coin switch. |
| SWAP_AUTO_INTERVAL_MS | Frequency of evaluating swap thresholds; set >= accrual period to avoid thrash. |
| KRAKEN_TIMEOUT_MS | Tighten to fail fast into deterministic fallback; balance between latency & live data freshness. |
| SWAP_RISK_WINDOW_MS / SWAP_MAX_WINDOW_COUNT | Controls swap throughput per hour. |

## 4. CPU Considerations
- Use Node.js 18+ (improved V8 performance & crypto).
- Pin process to dedicated cores (OS scheduling / taskset) when latency critical.
- Enable `UV_THREADPOOL_SIZE` > default if heavy crypto / file hashing concurrency appears (monitor event loop lag).

## 5. GPU / Native Addon
- Rebuild with matching Node ABI after upgrades.
- Validate checksum of native module before loading in REAL_STRICT mode (future enhancement suggestion).
- Monitor power draw; expose GPU metrics (future: integrate NVML or vendor API).

## 6. I/O & Ledgers
- Append-only writes are sequential; place ledger files on SSD for minimal fsync latency.
- Consider batching parity + share ledger appends (micro-buffer) if fs latency spikes; must preserve deterministic order (strict flush before process exit).
- Rotate large ledgers to keep tail scanning (readiness / reporting) < O(n) huge cost.

## 7. Memory
- Avoid retaining full ledger lines in memory; only chain tips & minimal caches.
- Explorer cache TTL (`EXPLORER_CACHE_MS`) should balance call reduction & staleness risk.

## 8. Pricing & Econ
- Kraken + Coingecko blending performed each econ cycle; ensure rate-limiting not exceeded.
- If API latency > interval, consider staggering (e.g. alternate provider fetch each cycle). Deterministic schedule: modulo of cycle counter.

## 9. Swap Path Efficiency
- Quote then immediate execute introduces two sequential network calls; parallelize with caution (must keep deterministic ordering). Current design prioritizes clarity + ledger alignment.
- Consider cached indicative rates; ledger must mark them as indicative vs final.

## 10. Latency Metrics
Expose (future additions):
- Event loop lag histogram.
- Hash computation wall-time per batch.
- Swap lifecycle timing (quote->execute->settle).

## 11. Benchmarking Procedure
1. Disable live swaps `SIMPLESWAP_LIVE=0`, set deterministic fallback only.
2. Run synthetic share injection (`/debug/add-shares` if enabled) with controlled accepted increments.
3. Measure ledger append throughput (lines/sec) and event loop delay.
4. Adjust batch sizing & accrual intervals; re-run.

## 12. Hot Paths Audit
- appendShareLedger / appendParityDigest: crypto SHA256 + HMAC (optional) dominate CPU for each accepted share.
  - If CPU bound, switch to incremental stream hashing or native addon.
- Kraken snapshot: network bound, use concurrent pair fetch (possible future improvement) but maintain deterministic final merge order (stable pair list sort).

## 13. Scaling Out
- Horizontal scaling multiplies share throughput; central verification: recompute per-rig chain tips then build higher-level Merkle root tree of tips.
- Price & econ computations can centralize; rigs subscribe to signed recommendation messages (future: governance-validated config pushes).

## 14. Future Enhancements (Performance)
- Add memory-mapped ring buffer for share events to reduce per-append syscall overhead.
- Introduce binary ledger variant (length-prefixed entries) with periodic digest bridging to JSON for external audit compatibility.
- GPU offload of SHA256 batching (if parity / share hashing saturates CPU).

---
End Performance Guide.
