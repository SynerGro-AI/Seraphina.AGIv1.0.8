"use strict";
// multiworker-controller.js – coordinated multiworker with threshold broadcast
// Parent process acts as controller; workers run the same file with WORKER_CHILD=1.

const WORKERS = parseInt(process.env.WORKERS || '1',10);
if (WORKERS > 1 && process.env.WORKER_CHILD !== '1'){
  const { Worker } = require('worker_threads');
  const path = require('path');
  const workers=[]; let nextBroadcast=Date.now()+3000; let guidanceThreshold=2.5;
  const stats = { accepted:0, attempts:0, norms:[] };
  for (let i=0;i<WORKERS;i++){
    const w = new Worker(path.resolve(__dirname,'aurrelia-pico-mesh-miner.fixed.js'), { env: { ...process.env, WORKER_CHILD:'1', WORKERS:'1', MW_INDEX:String(i) } });
    w.on('message', m=>{
      if (m && m.type==='PRUNE_SAMPLE'){
        stats.attempts++; if (m.ok) stats.accepted++; if (m.norm!=null){ stats.norms.push(m.norm); if (stats.norms.length>1024) stats.norms.shift(); }
      }
    });
    w.on('exit', code=> console.log('[Controller] worker', i,'exit',code));
    workers.push(w);
  }
  function broadcast(){
    if (Date.now() < nextBroadcast) return setTimeout(broadcast,500).unref();
    nextBroadcast = Date.now()+5000;
    // Simple percentile target: aim for approx 30-40% acceptance; adjust guidanceThreshold heuristically
    const ratio = stats.attempts? stats.accepted / stats.attempts : 0;
    if (ratio < 0.25) guidanceThreshold += 0.05; else if (ratio > 0.45) guidanceThreshold -= 0.05;
    guidanceThreshold = Math.max(1.0, Math.min(5.0, guidanceThreshold));
    for (const w of workers) w.postMessage({ type:'PRUNE_GUIDANCE', threshold: guidanceThreshold });
    setTimeout(broadcast,500).unref();
  }
  broadcast();
}
