#!/usr/bin/env node
// peer-endpoint-helper.js
// Simple local peer info HTTP server for BTT exporter (returns { "peers": N }).
// Usage: node peer-endpoint-helper.js 0.0.0.0:9456

const http = require('http');
const os = require('os');

const bind = process.argv[2] || '0.0.0.0:9456';
const [host, portStr] = bind.split(':');
const port = parseInt(portStr,10);

// Mock peer discovery; replace with real client integration (e.g., RPC call) later
function samplePeers(){
  // Base peers derived from CPU cores + random jitter
  const base = os.cpus().length * 3;
  const { deriveInt } = require('./deterministic-util');
  return base + deriveInt('peer-epsilon', 5, base, host);
}

http.createServer((req,res)=>{
  if (req.url === '/peers'){
    const peers = samplePeers();
    res.writeHead(200, { 'Content-Type':'application/json' });
    return res.end(JSON.stringify({ peers, ts: Date.now() }));
  }
  res.writeHead(404); res.end('not found');
}).listen(port, host, ()=>{
  console.log('[PeerHelper] listening on', bind);
});
