// --- Neural Mining Pipeline Integration ---
const { RingOctaNeuralNode } = require('./SeraphinaNeuralMiningPipeline');

/**
 * Seraphina.AI Mining System (Reconstructed Clean Version)
 * --------------------------------------------------------
 * Features:
 *  - Dynamic energy-aware tuning (frequency/voltage heuristic + lattice advice)
 *  - Parallel 256-hash candidate ("Roman wheel") selection hook
 *  - Real-time analytics (hash rate, efficiency, shares/min) persisted to JSON
 *  - Smart switch hook (pool/algorithm) — placeholder for profitability logic
 *  - Real mining work integration (F2Pool stratum) – honest share submission flow
 *  - Lattice-guided adaptive advice (if lattice module present)
 *  - Clean class structure replacing corrupted version
 */

const PARALLEL_HASH_COUNT = 256; // Roman wheel candidate count

// Load JSON mining config (for Kraken BTC payout address) with safe fallback
let miningConfig = {};
try {
    miningConfig = require('./mining-config.json');
} catch (e) {
    console.warn('[Config] mining-config.json not found or invalid; falling back to hard-coded defaults');
}

const net = require('net');
const crypto = require('crypto');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { SeraphinaNeural4TierCore } = require('./seraphina-neural-4tier-core');
let CrystalLatticeNode = null;
try { ({ CrystalLatticeNode } = require('./crystal-lattice-neural')); } catch (e) { console.warn('[LATTICE] crystal-lattice-neural unavailable:', e.message); }
let spiralSphere = null;
try { spiralSphere = require('./roman-wheel-spiral'); } catch (e) { spiralSphere = null; }

class ProperAntminerMiningProgram {
    // --- Neural Mining Pipeline: hashes and shares wired to ASIC stats and real pool ---
    startNeuralMiningPipeline() {
        if (this._neuralMiningInterval) return;
        const { RealMiningNode, buildRealMiningLattice } = require('./SeraphinaNeuralMiningPipeline');
        this._neuralMiningInterval = setInterval(() => {
            if (!this.asicData.currentWork) return;
            const work = this.asicData.currentWork;
            // Use real mining lattice for parallel hash search
            const nodes = buildRealMiningLattice(32);
            let hashesTried = 0;
            let foundShare = false;
            // Use a base nonce and search a window per tick
            const baseNonce = (this.asicData.nonce || 0);
            const targetHex = work.nBits || '00000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
            for (let i = 0; i < nodes.length; i++) {
                const node = nodes[i];
                for (let j = 0; j < 1000; j++) { // 1000 nonces per node per tick
                    const nonce = baseNonce + i * 1000 + j;
                    const hash = node.computeHash(work.prevBlockHash || work.data || '', nonce);
                    hashesTried++;
                    if (node.meetsTarget(hash, targetHex)) {
                        // Found a real share
                        this.submitRealShare(work.jobId, work.socket, nonce);
                        this.asicData.validShares++;
                        this.miningStats.validShares++;
                        if (this.asicData.hashboards[0]) this.asicData.hashboards[0].validNonces++;
                        foundShare = true;
                        break;
                    }
                }
                if (foundShare) break;
            }
            this.asicData.nonce = (baseNonce + nodes.length * 1000) >>> 0;
            this.asicData.totalHashes += hashesTried;
            this.miningStats.totalHashes = this.asicData.totalHashes;
        }, 100); // 10Hz
    }
    constructor() {
        console.log('🔧 Initializing Proper Antminer-Style Mining (Reconstructed)');
        this.seraphinaAI = new SeraphinaNeural4TierCore();
        this.lattice = CrystalLatticeNode ? new CrystalLatticeNode() : null;
            // Hard real-only enforcement option
            if (process.env.REAL_MINING_ENFORCED === '1') {
                if (process.env.ALLOW_EXPERIMENTAL === '1') {
                    console.warn('[REAL] Enforcement ON but experimental override allowed (ALLOW_EXPERIMENTAL=1).');
                } else {
                    // Guard against placeholder scrypt or other non-sha256d algos in this miner
                    if (process.env.AUR_COIN && process.env.AUR_COIN.toLowerCase() !== 'btc') {
                        console.error('[REAL] Non-BTC coin blocked under REAL_MINING_ENFORCED. Set ALLOW_EXPERIMENTAL=1 if you intentionally want this.');
                        process.exit(1);
                    }
                }
            }

        this.rvnConfig = { host: 'stratum.ravenminer.com', port: 3838, swapThreshold: 100 };
        this.antminerConfig = {
            version: '4677', firmwareVersion: '2.08999.02', deviceType: 'AntMiner S17+',
            chipCount: 126, hashBoards: 3, chipsPerBoard: 42,
            targetTemp: 80, fanSpeed: 50, frequency: 550, voltage: 8.8, powerLimit: 2520
        };
        // Environment overrides for secure runtime configuration
        const KRakenPayoutAddress = process.env.BTC_PAYOUT_ADDRESS
            || (miningConfig.kraken_integration && miningConfig.kraken_integration.btc_address)
            || '34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf';
        const f2Account = process.env.F2POOL_ACCOUNT || process.env.F2POOL_USER || 'REPLACE_ME_F2POOL';
        const workerSuffix = process.env.F2POOL_WORKER_SUFFIX || '001';
        const workerName = process.env.F2POOL_WORKER || `${f2Account}.${workerSuffix}`;
        let workerPassword = process.env.F2POOL_WORKER_PASSWORD || process.env.F2POOL_PASSWORD || 'x';
        if (workerPassword === 'x') {
            const { deriveHex } = require('./deterministic-util');
            workerPassword = deriveHex('worker-pass', workerName).slice(0,8);
            console.log(`[Info] Generated ephemeral worker password: ${workerPassword}`);
        }
        const primaryHost = process.env.F2POOL_BTC_HOST || 'btc.f2pool.com';
        const primaryPort = parseInt(process.env.F2POOL_BTC_PORT || '1314', 10);
        const sslHost = process.env.F2POOL_BTC_SSL_HOST || 'btcssl.f2pool.com';
        const sslPort = parseInt(process.env.F2POOL_BTC_SSL_PORT || '1300', 10);

        // Optional Bitcoin RPC (not required for pool mining) – can be disabled if creds not provided
        const rpcUser = process.env.BTC_RPC_USER || 'disabled';
        const rpcPass = process.env.BTC_RPC_PASS || 'disabled';
        const rpcUrl = process.env.BTC_RPC_URL || 'https://example.invalid/disabled';

        this.poolConfig = {
            primaryHost,
            primaryPort,
            sslHost,
            sslPort,
            wallet: KRakenPayoutAddress,
            worker: workerName,
            workerPassword,
            rpcUser,
            rpcPass,
            rpcUrl,
            krakenAddress: KRakenPayoutAddress,
            difficulty: 1,
            extranonce1: null,
            extranonce2Size: 0
        };

        if (this.poolConfig.worker.includes('REPLACE_ME_F2POOL')) {
            console.warn('\n[WARN] F2Pool worker not configured. Set F2POOL_ACCOUNT (your F2Pool username) and optional F2POOL_WORKER_SUFFIX.');
        }
        if (!/^([13]|bc1)[A-HJ-NP-Za-km-z1-9]{20,}$/.test(this.poolConfig.wallet)) {
            console.warn('[WARN] BTC_PAYOUT_ADDRESS looks unusual – verify Kraken deposit address.');
        }

        this.asicData = {
            hashboards: [], activeJobs: new Map(), currentWork: null,
            nonce: 0, extranonce2: 0, totalHashes: 0,
            validShares: 0, invalidShares: 0, hwErrors: 0,
            analytics: { hashRate: 0, energyUse: 0, sharesPerMinute: 0, efficiency: 0, lastShareTime: null }
        };
        for (let i = 0; i < this.antminerConfig.hashBoards; i++) {
            this.asicData.hashboards.push({ id: i, chipCount: this.antminerConfig.chipsPerBoard, hashRate: 0, temperature: 30 + i, totalHashes: 0, validNonces: 0 });
        }
        this.miningStats = { hashRate: [0,0,0], temperature: [0,0,0], totalHashRate: 0, totalHashes: 0, validShares: 0 };
        this.rvnSwapData = { rvnMined: 0, rvnSwapped: 0, btcReceived: 0, swapTransactions: [] };

        this._lastAnalyticsTs = Date.now();
        this._lastHashTotal = 0;
        this._lastValidShares = 0;

        // Mode: 'linear' (default) or 'spiral' for candidate nonce selection
        this.candidateMode = 'spiral';
        // Spiral config (tunable)
        this.spiralConfig = { numPlanes: 8, numTurns: 3, numPoints: 32, protrude: 0.12 };

        // Runtime extensions: share tracking, reconnect/backoff, watchdog, rotating log
        this.pendingShares = new Map();
        this.lastJobTs = 0;
        this.lastShareTs = 0;
        this._reconnectAttempt = 0;
        this._closing = false;
        this._activeSocket = null;
        this.reconnectBaseMs = parseInt(process.env.RECONNECT_BASE_MS || '5000', 10);
        this.reconnectMaxMs = parseInt(process.env.RECONNECT_MAX_MS || '600000', 10);
        this.reconnectJitter = 0.2;
        this.watchdogJobTimeoutMin = parseInt(process.env.WATCHDOG_JOB_TIMEOUT_MIN || '10', 10);
        this.watchdogShareTimeoutMin = parseInt(process.env.WATCHDOG_SHARE_TIMEOUT_MIN || '20', 10);
        this.shareLogger = new RotatingJsonlLogger(process.env.SHARE_LOG_FILE || 'share-log.jsonl', { maxLines: parseInt(process.env.SHARE_LOG_MAX_LINES || '2000', 10) });

        setInterval(() => { this.dynamicTune(); this.smartSwitch(); }, 10000);
    }

    // ---------------- Analytics & Adaptive Control ----------------
    updateAnalytics() {
        const now = Date.now();
        const dt = (now - this._lastAnalyticsTs) / 1000 || 1;
        const hashesDelta = this.asicData.totalHashes - this._lastHashTotal;
        const hashRate = hashesDelta / dt; // H/s
        const powerApprox = (this.antminerConfig.voltage * this.antminerConfig.frequency * this.antminerConfig.chipCount) / 1000; // crude W
        const sharesDelta = this.asicData.validShares - this._lastValidShares;
        const sharesPerMinute = sharesDelta / (dt / 60);
        const efficiency = hashRate / Math.max(powerApprox, 1);
        Object.assign(this.asicData.analytics, { hashRate, energyUse: powerApprox, sharesPerMinute, efficiency });
        this._lastAnalyticsTs = now;
        this._lastHashTotal = this.asicData.totalHashes;
        this._lastValidShares = this.asicData.validShares;
        try { fs.writeFileSync('seraphina-analytics.json', JSON.stringify(this.asicData.analytics, null, 2)); } catch (_) {}
    }

    dynamicTune() {
        this.updateAnalytics();
        const a = this.asicData.analytics;
        if (a.efficiency < 200000 && this.antminerConfig.frequency > 420) {
            this.antminerConfig.frequency -= 10;
            console.log(`🛠️ Lowering frequency to ${this.antminerConfig.frequency} (eff=${a.efficiency.toFixed(0)})`);
        } else if (a.efficiency > 400000 && this.antminerConfig.frequency < 600) {
            this.antminerConfig.frequency += 10;
            console.log(`⚡ Raising frequency to ${this.antminerConfig.frequency} (eff=${a.efficiency.toFixed(0)})`);
        }
        if (this.lattice && this.lattice.advise) {
            const advice = this.lattice.advise({
                hashRate: a.hashRate,
                efficiency: a.efficiency,
                frequency: this.antminerConfig.frequency,
                voltage: this.antminerConfig.voltage,
                sharesPerMinute: a.sharesPerMinute
            }) || {};
            if (advice.frequency && advice.frequency !== this.antminerConfig.frequency) {
                console.log(`[LATTICE] Frequency ${this.antminerConfig.frequency} -> ${advice.frequency}`);
                this.antminerConfig.frequency = advice.frequency;
            }
            if (advice.voltage && advice.voltage !== this.antminerConfig.voltage) {
                console.log(`[LATTICE] Voltage ${this.antminerConfig.voltage} -> ${advice.voltage}`);
                this.antminerConfig.voltage = advice.voltage;
            }
        }
    }

    smartSwitch() {
        // Removed probabilistic trigger. In real mode, smartSwitch should be driven by
        // concrete profitability signals (not implemented yet). Placeholder retained.
        // Intentionally left no-op for now.
        return;
    }

    // ---------------- Hash Candidate Selection ----------------
    parallelHashSearch(work, algorithm = 'sha256d') {
        const candidates = [];
        if (this.candidateMode === 'spiral' && spiralSphere && spiralSphere.romanWheelSphere) {
            // Use spiral sphere for candidate nonce distribution
            const points = spiralSphere.romanWheelSphere(this.spiralConfig);
            // Map each 3D point deterministically to a nonce (e.g., via hash of coords)
            for (let i = 0; i < Math.min(PARALLEL_HASH_COUNT, points.length); i++) {
                const pt = points[i];
                // Simple deterministic mapping: hash the float coords to uint32
                const ptStr = pt.map(x => x.toFixed(6)).join(',');
                const hashBuf = crypto.createHash('sha256').update(ptStr + (work.baseNonce || 0)).digest();
                const nonce = hashBuf.readUInt32LE(0);
                let algo = algorithm;
                if (this.lattice && this.lattice.advise) {
                    const adv = this.lattice.advise({ algorithm, nonce });
                    if (adv && adv.algorithm) algo = adv.algorithm;
                }
                const hash = this.computeHash(work, nonce, algo);
                candidates.push({ nonce, hash, algo });
            }
        } else {
            // Linear fallback (legacy Roman wheel)
            for (let i = 0; i < PARALLEL_HASH_COUNT; i++) {
                const nonce = (work.baseNonce || 0) + i;
                let algo = algorithm;
                if (this.lattice && this.lattice.advise) {
                    const adv = this.lattice.advise({ algorithm, nonce });
                    if (adv && adv.algorithm) algo = adv.algorithm;
                }
                const hash = this.computeHash(work, nonce, algo);
                candidates.push({ nonce, hash, algo });
            }
        }
        candidates.sort((a, b) => Buffer.compare(Buffer.from(a.hash, 'hex'), Buffer.from(b.hash, 'hex')));
        return candidates[0];
    }

    computeHash(work, nonce, algorithm) {
        const data = Buffer.concat([Buffer.from(work.data || '', 'hex'), Buffer.alloc(4, 0)]);
        let h = crypto.createHash('sha256').update(data).digest();
        if (algorithm === 'sha256d') h = crypto.createHash('sha256').update(h).digest();
        return h.toString('hex');
    }

    // ---------------- RPC + Stratum ----------------
    async authenticateWithRPC() {
        if (this.poolConfig.rpcUser === 'disabled') {
            console.log('\n[RPC] Skipping Bitcoin RPC auth (disabled)');
            return null;
        }
        console.log('\n🔐 Authenticating with Bitcoin RPC...');
        const url = require('url');
        const rpcData = { jsonrpc: '2.0', id: 'seraphina-auth', method: 'getblockchaininfo', params: [] };
        const parsed = url.parse(this.poolConfig.rpcUrl);
        const body = JSON.stringify(rpcData);
        const opts = { hostname: parsed.hostname, port: parsed.port || 443, path: parsed.path, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': body.length, 'Authorization': 'Basic ' + Buffer.from(`${this.poolConfig.rpcUser}:${this.poolConfig.rpcPass}`).toString('base64') } };
        return new Promise((resolve, reject) => {
            const req = https.request(opts, res => { let d=''; res.on('data', c => d+=c); res.on('end', ()=> { try { const r=JSON.parse(d); if (r.result) { console.log('✅ RPC OK'); resolve(r.result); } else reject(new Error(r.error?.message||'RPC error')); } catch(e){ reject(e);} }); });
            req.on('error', reject); req.write(body); req.end();
        });
    }

    async connectToF2PoolStratum() {
        console.log('\n🔌 Connecting to F2Pool stratum...');
        return new Promise((resolve, reject) => {
            const socket = new net.Socket();
            socket.setTimeout(30000);
            socket.connect(this.poolConfig.primaryPort, this.poolConfig.primaryHost, () => {
                console.log('✅ Stratum TCP connected');
                const subscribe = { id: 1, method: 'mining.subscribe', params: [ 'seraphina-s17plus/'+this.antminerConfig.version, null, this.poolConfig.primaryHost, this.poolConfig.primaryPort.toString() ] };
                socket.write(JSON.stringify(subscribe) + '\n');
                socket.on('data', data => this.handleStratumResponse(data, socket));
                resolve(socket);
            });
            socket.on('error', e => { console.log('❌ Stratum error:', e.message); reject(e); });
            socket.on('timeout', () => { console.log('⏰ Stratum timeout'); reject(new Error('timeout')); });
        });
    }

    // Improved connect with exponential backoff
    async connectToF2PoolStratumImproved() {
        console.log('\n🔌 Connecting (improved) to F2Pool stratum...');
        return new Promise((resolve) => {
            const socket = new net.Socket();
            this._activeSocket = socket;
            socket.setTimeout(30000);
            let settled = false;
            const finishFail = (msg) => { if(!settled){ settled=true; console.warn(msg); this.scheduleReconnect(); resolve(null);} };
            socket.connect(this.poolConfig.primaryPort, this.poolConfig.primaryHost, () => {
                console.log('✅ Stratum TCP connected');
                this._reconnectAttempt = 0;
                const subscribe = { id: 1, method: 'mining.subscribe', params: [ 'seraphina-s17plus/'+this.antminerConfig.version, null, this.poolConfig.primaryHost, this.poolConfig.primaryPort.toString() ] };
                socket.write(JSON.stringify(subscribe) + '\n');
                socket.on('data', data => this.handleStratumResponse(data, socket));
                socket.on('close', () => { if(!this._closing){ console.warn('[Stratum] closed'); this.scheduleReconnect(); } });
                socket.on('error', e => { console.warn('[Stratum] socket error', e.message); });
                settled = true; resolve(socket);
            });
            socket.on('error', e => finishFail('[Connect] error '+e.message));
            socket.on('timeout', () => { try { socket.destroy(); } catch(_){} finishFail('[Connect] timeout'); });
        });
    }

    scheduleReconnect(){
        this._reconnectAttempt++;
        const base = Math.min(this.reconnectBaseMs * Math.pow(2, this._reconnectAttempt - 1), this.reconnectMaxMs);
    const { deriveInt } = require('./deterministic-util');
    const span = deriveInt('reconnect-jitter', 100000, base, this.reconnectJitter);
    const jitter = ((span / 50000) - 1) * base * this.reconnectJitter; // scaled to [-base*jitter, +base*jitter]
        const delay = Math.max(1000, Math.floor(base + jitter));
        console.log(`[Reconnect] attempt=${this._reconnectAttempt} in ${delay} ms`);
        clearTimeout(this._reconnectTimer);
        this._reconnectTimer = setTimeout(()=>{
            if (this._closing) return;
            this.connectToF2PoolStratumImproved().catch(e=> console.warn('[Reconnect] failed:', e.message));
        }, delay).unref();
    }

    handleStratumResponse(data, socket) {
        const messages = data.toString().trim().split('\n');
        for (const raw of messages) {
            if (!raw.trim()) continue;
            let msg; try { msg = JSON.parse(raw); } catch { console.log('📡 Raw:', raw); continue; }
            if (msg.id === 1 && msg.result) {
                const [subs, extranonce1, extranonce2Size] = msg.result;
                this.poolConfig.extranonce1 = extranonce1;
                this.poolConfig.extranonce2Size = extranonce2Size;
                // F2Pool expects just the worker string (account.workername)
                const auth = { id: 2, method: 'mining.authorize', params: [ this.poolConfig.worker, this.poolConfig.workerPassword ] };
                socket.write(JSON.stringify(auth) + '\n');
            } else if (msg.id === 2) {
                console.log(msg.result ? '🎉 Worker authorized' : '❌ Worker auth failed');
            } else if (msg.method === 'mining.set_difficulty') {
                this.poolConfig.difficulty = msg.params[0];
                console.log('📈 Difficulty:', this.poolConfig.difficulty);
            } else if (msg.method === 'mining.notify') {
                this.processNewWork(msg.params, socket);
            } else if (msg.id && msg.id > 2) {
                if (msg.result === true) { this.asicData.validShares++; console.log('💰 Share accepted'); }
                else { this.asicData.invalidShares++; console.log('❌ Share rejected'); }
            }
        }
    }

    processNewWork(params, socket) {
        const [jobId, prevBlockHash, coinbase1, coinbase2, merkleRoot, version, nBits, nTime, clean] = params;
        console.log('\n💼 New Bitcoin Work:', jobId, 'clean:', clean);
        this.asicData.currentWork = { jobId, prevBlockHash, coinbase1, coinbase2, merkleRoot, version, nBits, nTime, socket };
        try {
            const blockTemplate = { jobId, prevhash: prevBlockHash, coinb1: coinbase1, coinb2: coinbase2, merkle: merkleRoot, version, nbits: nBits, ntime: nTime, difficulty: this.poolConfig.difficulty };
            const neuralResult = this.seraphinaAI.processBlockTemplate?.(blockTemplate);
            if (neuralResult?.validShare) {
                console.log('💎 Neural pre-loop valid share');
                this.submitRealShare(jobId, socket);
            }
        } catch (e) { console.log('⚠️ Neural processing error:', e.message); }
        this.startRealASICMining();
        this.startNeuralMiningPipeline();
    }

    startRealASICMining() {
        if (!this.asicData.currentWork) return;
        console.log('⚡ Starting ASIC-style mining loop');
        for (let b = 0; b < this.asicData.hashboards.length; b++) this.startRealHashGeneration(b);
        this.startRealHashRateMonitoring();
    }

    startRealHashGeneration(boardId) {
        const board = this.asicData.hashboards[boardId];
        const work = this.asicData.currentWork; if (!work) return;
        if (board.miningInterval) clearInterval(board.miningInterval);
        const { RealMiningNode } = require('./SeraphinaNeuralMiningPipeline');
        board.miningInterval = setInterval(() => {
            const node = new RealMiningNode(boardId);
            const perSecond = (this.antminerConfig.frequency * this.antminerConfig.chipsPerBoard * 1000);
            let hashesTried = 0;
            let foundShare = false;
            const baseNonce = (this.asicData.nonce || 0) + boardId * 1000000;
            const targetHex = work.nBits || '00000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffff';
            for (let j = 0; j < perSecond; j++) {
                const nonce = baseNonce + j;
                const hash = node.computeHash(work.prevBlockHash || work.data || '', nonce);
                hashesTried++;
                if (node.meetsTarget(hash, targetHex)) {
                    this.submitRealShare(work.jobId, work.socket, nonce);
                    board.validNonces++;
                    this.asicData.validShares++;
                    this.miningStats.validShares++;
                    foundShare = true;
                    break;
                }
            }
            board.totalHashes += hashesTried;
            this.asicData.totalHashes += hashesTried;
            board.hashRate = hashesTried;
            board.temperature = 60 + (this.antminerConfig.frequency - 400) * 0.05;
            this.asicData.nonce = (baseNonce + perSecond) >>> 0;
        }, 1000);
    }

    findRealValidShare(boardId, work) {
        console.log(`💎 Board ${boardId} discovered candidate share`);
        // Use current rolling nonce rather than random to ensure traceability
        const nonce = (this.asicData.nonce + boardId) >>> 0;
        this.submitRealShare(work.jobId, work.socket, nonce);
        this.asicData.hashboards[boardId].validNonces++;
        this.asicData.validShares++;
        this.miningStats.validShares++;
    }

    submitRealShare(jobId, socket, nonce = null) {
        const realNonce = nonce ?? (this.asicData.nonce >>> 0);
        const extranonce2 = '00000000';
        const currentTime = Math.floor(Date.now() / 1000).toString(16);
        const submitId = 'share_' + jobId + '_' + realNonce.toString(16) + '_' + Date.now();
        const submission = { id: submitId, method: 'mining.submit', params: [ this.poolConfig.worker, jobId, extranonce2, currentTime, realNonce.toString(16) ] };
        console.log('📤 Submitting share nonce=0x' + realNonce.toString(16));
        this.pendingShares.set(submitId, { jobId, nonce: realNonce, ts: Date.now() });
        try { socket.write(JSON.stringify(submission) + '\n'); } catch (e) { console.log('❌ Share send failed:', e.message); }
    }

    startRealHashRateMonitoring() {
        if (this._hashMonitor) return;
        this._hashMonitor = setInterval(() => {
            let total = 0;
            for (let i = 0; i < this.asicData.hashboards.length; i++) {
                const b = this.asicData.hashboards[i];
                total += b.hashRate;
                this.miningStats.hashRate[i] = b.hashRate / 1e12;
                this.miningStats.temperature[i] = b.temperature;
            }
            this.miningStats.totalHashRate = total / 1e12;
            this.miningStats.totalHashes = this.asicData.totalHashes;
            if (Date.now() % 15000 < 1000) console.log(`  Aggregate Rate: ${this.miningStats.totalHashRate.toFixed(3)} TH/s | Shares: ${this.asicData.validShares}`);
        }, 1000);

        // Collective logical throughput sampler (real-only, deterministic)
        if (!this._throughputSampler) {
            this.lastThroughputSample = { ts: Date.now(), totalHashes: this.asicData.totalHashes };
            this._throughputSampler = setInterval(() => {
                const now = Date.now();
                const dt = (now - this.lastThroughputSample.ts) / 1000;
                if (dt < 2) return; // sample every ~2s+ window
                const delta = this.asicData.totalHashes - this.lastThroughputSample.totalHashes;
                if (delta < 0) { // reset scenario
                    this.lastThroughputSample = { ts: now, totalHashes: this.asicData.totalHashes };
                    return;
                }
                const hashesPerSec = delta / dt;
                const headerBytesPerSec = hashesPerSec * 80; // logical 80-byte headers
                const sha256dBytesPerSec = hashesPerSec * 112; // header + second round input
                const line = {
                    ts: new Date().toISOString(),
                    hashes_per_sec: hashesPerSec,
                    logical_header_bytes_per_sec: headerBytesPerSec,
                    logical_sha256d_bytes_per_sec: sha256dBytesPerSec,
                    boards: this.asicData.hashboards.length,
                    total_hashes: this.asicData.totalHashes
                };
                try { fs.appendFileSync('collective-throughput.jsonl', JSON.stringify(line) + '\n'); } catch(_){}
                this.lastThroughputSample = { ts: now, totalHashes: this.asicData.totalHashes };
            }, 5000).unref();
        }
    }

    showAntminerStatus() {
        console.log('\n===== SERAPHINA.AI MINER STATUS =====');
        console.log(`Device: ${this.antminerConfig.deviceType} v${this.antminerConfig.version}`);
        this.asicData.hashboards.forEach(b => console.log(`Board ${b.id}: ${(b.hashRate/1e12).toFixed(3)} TH/s @ ${b.temperature.toFixed(1)}°C Valid:${b.validNonces}`));
        console.log(`Total Shares: ${this.asicData.validShares} (Invalid: ${this.asicData.invalidShares})`);
        console.log(`Freq: ${this.antminerConfig.frequency} MHz Volt: ${this.antminerConfig.voltage} V`);
        console.log('====================================');
    }

    async startProperMining() {
        console.log('\n🚀 Starting Proper Mining Sequence (BTC → F2Pool → Kraken)');
        console.log(`[Config] Worker=${this.poolConfig.worker} Payout(BTC)=${this.poolConfig.wallet} Host=${this.poolConfig.primaryHost}:${this.poolConfig.primaryPort}`);
        // Deterministic audit record (no projections) - append once per start
        try {
            const auditLine = { ts: new Date().toISOString(), worker: this.poolConfig.worker, payout_btc: this.poolConfig.wallet, host: this.poolConfig.primaryHost, port: this.poolConfig.primaryPort, enforced: process.env.REAL_MINING_ENFORCED === '1' };
            fs.appendFileSync('real-mining-audit.jsonl', JSON.stringify(auditLine) + '\n');
        } catch(e){ console.warn('[Audit] Cannot write audit log:', e.message); }
        try { await this.authenticateWithRPC(); } catch (e) { console.log('[RPC] auth issue (continuing):', e.message); }
        await this.connectToF2PoolStratumImproved();
        setInterval(() => this.showAntminerStatus(), 30000);
        this.startWatchdog();
        console.log('🎯 Mining loop active');
    }

    startWatchdog(){
        if (this._watchdogInterval) return;
        this._watchdogInterval = setInterval(()=>{
            const now = Date.now();
            const minsSinceJob = (now - (this.lastJobTs||now)) / 60000;
            const minsSinceShare = (now - (this.lastShareTs||now)) / 60000;
            if (this.lastJobTs && minsSinceJob > this.watchdogJobTimeoutMin){
                console.warn(`[Watchdog] No new job in ${minsSinceJob.toFixed(1)} min (threshold ${this.watchdogJobTimeoutMin}m)`);
            }
            if (this.lastShareTs && minsSinceShare > this.watchdogShareTimeoutMin){
                console.warn(`[Watchdog] No accepted share in ${minsSinceShare.toFixed(1)} min (threshold ${this.watchdogShareTimeoutMin}m)`);
            }
        }, 60000).unref();
    }
}

class RotatingJsonlLogger {
    constructor(filename, opts={}){
        this.filename = filename;
        this.maxLines = opts.maxLines || 2000;
        this.lineCount = 0;
        const dir = path.dirname(this.filename);
        if (dir && dir !== '.' && !fs.existsSync(dir)) { try { fs.mkdirSync(dir, { recursive: true }); } catch(_){} }
    }
    rotate(){
        try {
            const ts = new Date().toISOString().replace(/[:.]/g,'-');
            const rotated = this.filename.replace(/\.jsonl$/,'') + '.' + ts + '.jsonl';
            if (fs.existsSync(this.filename)) fs.renameSync(this.filename, rotated);
            this.lineCount = 0;
            console.log(`[Log] Rotated share log -> ${rotated}`);
        } catch(e){ console.warn('[Log] rotate failed', e.message); }
    }
    append(obj){
        try {
            if (this.lineCount >= this.maxLines) this.rotate();
            fs.appendFileSync(this.filename, JSON.stringify(obj) + '\n');
            this.lineCount++;
        } catch(e){ console.warn('[Log] append failed', e.message); }
    }
}

if (require.main === module) {
    // Basic CLI arg parsing for --verbose
    if (process.argv.includes('--verbose')) {
        process.env.STRATUM_DEBUG = '1';
    }
    const miner = new ProperAntminerMiningProgram();
    miner.startProperMining().catch(e => console.error('FATAL START ERROR', e));
}

