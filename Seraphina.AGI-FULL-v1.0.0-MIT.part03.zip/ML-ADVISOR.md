# Deterministic ML Advisor Stub

## Purpose
Provide a reproducible score guiding strategic bias adjustments using static quantized weights. No stochastic gradients, no remote calls.

## Inputs
- Acceptance ratio (current cycle)
- Latency median (from `pool-latency.json`)
- Income spread (top vs second coin)
- Current FREN & RVN bias multipliers

## Weights
Stored inline in `deterministic-ml-advisor.js`:
```
features: [acceptRatio, latencyMedian, incomeSpread, biasFREN, biasRVN, frenRevenueNorm]
vector:   [0.33, -0.14, 0.24, 0.17, 0.06, 0.34]
```

## Scoring
```
score_raw = Σ (weight_i * feature_i)
score = logistic(score_raw) => 1/(1+exp(-score_raw))
```
Rounded to 8 decimals for determinism. Digest = sha256(JSON({feats,score_raw})).

## Actions
- If score < 0.45 → `suggest_bias_increase` (+0.02)
- If score > 0.85 → `suggest_bias_reduce` (-0.015)
- Else → `noop`
All advisory; policy engine enforces bounds.

## Environment Flags
```
ML_ADVISOR=1
TRADING_ENGINE=1
```

## Metrics
- `aurrelia_ml_advisor_score`
- `aurrelia_ml_advisor_action_code` (noop=0, increase=1, reduce=2)

## Extension Path
1. Replace static vector with external quantized model weights JSON (still deterministic).
2. Add feature normalization ledger for A/B evaluation of model variants.
3. Introduce version hash gauge `aurrelia_ml_advisor_version_hash` (sha256 first 8 hex → int).

## Audit
Repeat run under fixed input values → identical score, action, digest.

### New Feature: frenRevenueNorm
`frenRevenueNorm` supplies a normalized (0-1) representation of smoothed FREN revenue-per-hash (price * blockReward / diff) relative to top current income. This allows the advisor to emphasize FREN strategically when profitability surges without abrupt bias flips.

---
End of ML-ADVISOR.md.
