// midstate_wasm.js
// WASM wrapper for SHA-256 compression (midstate) to accelerate double SHA.
// Fallbacks to JS midstate if wasm build fails. Deterministic.

const fs = require('fs');
const path = require('path');
let wasm = null;
let ready = false;
let jsMid = null;
let initErrorLogged = false; // rate-limit init error logs
let disabled = false; // permanently disable after init failure
// Telemetry counters (updated externally by miner via global metrics object if present)
let stats = { calls:0, pooled:0, mallocs:0, firstHashNs:0, secondHashNs:0 };

// Simple memory pool (one 128-byte slab reused per call to avoid malloc/free churn)
let pool = { base: 0, size: 0 };

try { jsMid = require('./midstate.js'); } catch(_) {}

async function initWasm(){
  if (ready || disabled) return;
  try {
    const wasmPath = path.join(__dirname, 'sha256_mid.wasm');
    if (!fs.existsSync(wasmPath)) throw new Error('sha256_mid.wasm missing');
    const bytes = fs.readFileSync(wasmPath);
    const mod = await WebAssembly.instantiate(bytes, {});
    wasm = mod.instance.exports;
    if (!wasm || !wasm.memory || !wasm.sha256_compress) throw new Error('Invalid WASM exports');
    // allocate a slab once (128 bytes: two blocks + state) if malloc export exists
    try {
      if (wasm.malloc){
        pool.base = wasm.malloc(128);
        pool.size = 128;
      }
    } catch(_){ }
    ready = true;
  } catch (e) {
    if (!initErrorLogged){
      console.warn('[midstate-wasm] init failed:', e.message);
      initErrorLogged = true;
    }
    disabled = true; // stop future attempts to avoid log spam
    throw e; // allow caller one failure path
  }
}

function u32ToBuf(arr){ const b = Buffer.alloc(32); for (let i=0;i<8;i++) b.writeUInt32BE(arr[i]>>>0, i*4); return b; }

function computeMidstateWasm(first64){
  if (!ready) throw new Error('WASM not initialized');
  if (first64.length !== 64) throw new Error('Need 64 bytes');
  const mem = new Uint8Array(wasm.memory.buffer);
  let ptr, hPtr; const usePool = pool.base && pool.size >= 96; // need 64 + 32
  if (usePool){
    ptr = pool.base; hPtr = pool.base + 64; stats.pooled++;
  } else {
    ptr = wasm.malloc(64); hPtr = wasm.malloc(32); stats.mallocs++;
  }
  mem.set(first64, ptr);
  initIv(mem, hPtr); // write initial IV into state buffer
  wasm.sha256_compress(ptr, hPtr);
  const raw = mem.slice(hPtr, hPtr+32);
  const out = Buffer.alloc(32);
  for (let i=0;i<8;i++){
    out.writeUInt32BE(raw[i*4] | (raw[i*4+1]<<8) | (raw[i*4+2]<<16) | (raw[i*4+3]<<24), i*4);
  }
  if (!usePool){ try { wasm.free(ptr); wasm.free(hPtr); } catch(_){ } }
  return out;
}

// Single-block SHA256 using WASM (message must already be padded to 64 bytes).
function sha256SingleBlockWasm(block64){
  if (!ready) throw new Error('WASM not initialized');
  if (block64.length !== 64) throw new Error('Need 64 byte block');
  const mem = new Uint8Array(wasm.memory.buffer);
  let ptr, hPtr; const usePool = pool.base && pool.size >= 96;
  if (usePool){ ptr = pool.base; hPtr = pool.base + 64; stats.pooled++; }
  else { ptr = wasm.malloc(64); hPtr = wasm.malloc(32); stats.mallocs++; }
  mem.set(block64, ptr);
  initIv(mem, hPtr);
  wasm.sha256_compress(ptr, hPtr);
  const digest = stateToDigest(mem.slice(hPtr, hPtr+32));
  if (!usePool){ try { wasm.free(ptr); wasm.free(hPtr); } catch(_){ } }
  return digest;
}

// Compress a 64-byte block with an arbitrary 32-byte initial state (IV or midstate).
function sha256CompressWithState(block64, initState32){
  if (!ready) throw new Error('WASM not initialized');
  if (block64.length !== 64) throw new Error('block64 length');
  if (initState32.length !== 32) throw new Error('initState32 length');
  const mem = new Uint8Array(wasm.memory.buffer);
  const bPtr = wasm.malloc(64);
  const sPtr = wasm.malloc(32);
  mem.set(block64, bPtr);
  mem.set(initState32, sPtr);
  wasm.sha256_compress(bPtr, sPtr);
  const out = Buffer.from(mem.slice(sPtr, sPtr+32));
  wasm.free(bPtr); wasm.free(sPtr);
  return out;
}

function buildPaddedBlock(dataBuf, bitLen){
  // dataBuf length must be <= 55 bytes for single block usage here
  const block = Buffer.alloc(64,0);
  dataBuf.copy(block,0);
  block[dataBuf.length] = 0x80;
  // big-endian 64-bit length
  const hi = Math.floor(bitLen / 0x100000000);
  const lo = bitLen >>> 0;
  block.writeUInt32BE(hi,56);
  block.writeUInt32BE(lo,60);
  return block;
}

function sha256TailFromMidstateWasm(midstateBuf, tail16){
  if (!ready) throw new Error('WASM not initialized');
  if (midstateBuf.length !== 32) throw new Error('midstate len');
  if (tail16.length !== 16) throw new Error('tail16 len');
  // Reconstruct H in WASM memory: allocate a 32-byte region and write midstate
  const mem = new Uint8Array(wasm.memory.buffer);
  let blockPtr, hPtr; const usePool = pool.base && pool.size >= 96;
  if (usePool){ blockPtr = pool.base; hPtr = pool.base + 64; stats.pooled++; for (let i=0;i<96;i++) mem[pool.base+i]=0; }
  else { blockPtr = wasm.malloc(64); hPtr = wasm.malloc(32); stats.mallocs++; for (let i=0;i<64;i++) mem[blockPtr+i]=0; }
  // Build second chunk: tail16 + 0x80 + zero pad + length=640 bits
  mem.set(tail16, blockPtr);
  mem[blockPtr + 16] = 0x80;
  // length: high 32 bits zero, low 32 bits = 640
  mem[blockPtr + 56] = 0; mem[blockPtr + 57] = 0; mem[blockPtr + 58] = 0; mem[blockPtr + 59] = 0;
  mem[blockPtr + 60] = 0; mem[blockPtr + 61] = 0; mem[blockPtr + 62] = 0x02; mem[blockPtr + 63] = 0x80; // 640 decimal
  for (let i=0;i<8;i++){
    const v = midstateBuf.readUInt32BE(i*4);
    mem[hPtr + i*4 + 0] = v & 0xFF;
    mem[hPtr + i*4 + 1] = (v>>>8)&0xFF;
    mem[hPtr + i*4 + 2] = (v>>>16)&0xFF;
    mem[hPtr + i*4 + 3] = (v>>>24)&0xFF;
  }
  wasm.sha256_compress(blockPtr, hPtr);
  const firstHash = stateToDigest(mem.slice(hPtr, hPtr+32));
  if (!usePool){ try { wasm.free(blockPtr); wasm.free(hPtr); } catch(_){ } }
  return firstHash;
}

async function doubleSha256MidWasm(first64, tail16){
  if (disabled) throw new Error('wasm disabled');
  if (!ready) await initWasm();
  const t0 = process.hrtime.bigint();
  const mid = computeMidstateWasm(first64);
  // Tail continuation now fully in WASM
  const first = sha256TailFromMidstateWasm(mid, tail16);
  const tMid = process.hrtime.bigint();
  // Second SHA in WASM (single block: 32 bytes data)
  const secondBlock = buildPaddedBlock(first, 32 * 8);
  const second = sha256SingleBlockWasm(secondBlock);
  const tEnd = process.hrtime.bigint();
  stats.calls++;
  stats.firstHashNs += Number(tMid - t0);
  stats.secondHashNs += Number(tEnd - tMid);
  return second;
}

// --- Helpers for IV & digest encoding ---
const SHA256_IV = [
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
];

function initIv(mem, ptr){
  // Write little-endian so that reading uint32_t yields correct value
  for (let i=0;i<8;i++){
    const v = SHA256_IV[i] >>> 0;
    mem[ptr + i*4 + 0] = v & 0xFF;
    mem[ptr + i*4 + 1] = (v >>> 8) & 0xFF;
    mem[ptr + i*4 + 2] = (v >>> 16) & 0xFF;
    mem[ptr + i*4 + 3] = (v >>> 24) & 0xFF;
  }
}

function stateToDigest(stateSlice){
  // stateSlice: 32 bytes little-endian words -> return 32-byte digest big-endian words
  const out = Buffer.alloc(32);
  for (let i=0;i<8;i++){
    const le0 = stateSlice[i*4+0];
    const le1 = stateSlice[i*4+1];
    const le2 = stateSlice[i*4+2];
    const le3 = stateSlice[i*4+3];
    out[i*4+0] = le3;
    out[i*4+1] = le2;
    out[i*4+2] = le1;
    out[i*4+3] = le0;
  }
  return out;
}

module.exports = {
  initWasm,
  doubleSha256MidWasm,
  // Internal (kept minimal) for future chaining or tests
  _computeMidstateWasm: computeMidstateWasm,
  _stats: stats,
};
