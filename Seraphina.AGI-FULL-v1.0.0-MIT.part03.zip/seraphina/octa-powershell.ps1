# octa-powershell.ps1
<#
  OctaLang / Aurelia remote management & tweak console.
  Usage examples:
    pwsh ./octa-powershell.ps1 --targetHost <IP> --tweak rate=1800
    pwsh ./octa-powershell.ps1 --local --monitor
    pwsh ./octa-powershell.ps1 --targetHost miner --swarm add=5
  Flags are intentionally minimal; extend as needed.
#>

param(
  [string]$TargetHost = "miner",
  [string]$KeyFile = "$HOME/.octa-seal-key",
  [string]$Tweak = "",
  [string]$Swarm = "",
  [string]$Calib = "",
  [switch]$Monitor,
  [switch]$Local,
  [switch]$DryRun,
  [string]$LogFile = "$HOME/octa-powershell.log"
)

function Get-OctaKey {
  if (Test-Path $KeyFile) { return (Get-Content -Raw -Path $KeyFile).Trim() }
  Write-Warning "Key file not found ($KeyFile); using deterministic fallback (NOT SECURE)."
  return ("fallback:" + (Get-Date -Format o))
}
$Key = Get-OctaKey

# Validate target host early (user sometimes passed angle brackets like <msi-ip>)
if ($TargetHost -match '[<>]') {
  Write-Error "TargetHost contains angle brackets ('<' or '>'). Supply plain hostname or IP, e.g. --targetHost <IP>"
  exit 1
}
if (-not $Local -and ([string]::IsNullOrWhiteSpace($TargetHost))) {
  Write-Error "TargetHost is required unless --local is specified"
  exit 1
}

function New-OctaSeal {
  param([string]$Cmd)
  $phi = (1 + [Math]::Sqrt(5)) / 2
  $h = New-Object System.Security.Cryptography.HMACSHA256([Text.Encoding]::UTF8.GetBytes($Key + ':' + $phi))
  $bytes = [Text.Encoding]::UTF8.GetBytes($Cmd)
  $seal = [Convert]::ToBase64String($h.ComputeHash($bytes))
  [pscustomobject]@{cmd=$Cmd; seal=$seal}
}

function Invoke-OctaRemote {
  param([string]$Command)
  if ($DryRun) { Write-Host "[DRY] $Command"; return }
  if ($Local) { Invoke-Expression $Command; return }
  $sess = New-PSSession -HostName $TargetHost -UserName root -SSHTransportArgs "-o StrictHostKeyChecking=no" -ErrorAction SilentlyContinue
  if ($sess) {
    try { Invoke-Command -Session $sess -ScriptBlock { param($c) bash -lc $c } -ArgumentList $Command } finally { Remove-PSSession $sess }
    return
  }
  Write-Warning "PowerShell SSH remoting failed; attempting raw ssh fallback..."
  if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) { Write-Error "ssh client not available for fallback"; return }
  $escaped = $Command.Replace('"','\"')
  & ssh -o StrictHostKeyChecking=no root@$TargetHost "bash -lc \"$escaped\"" 2>&1 | ForEach-Object { Write-Host $_ }
}

function Write-OctaLog { param([string]$Line) Add-Content -Path $LogFile -Value ("$(Get-Date -Format o) " + $Line) }
Write-OctaLog "START host=$TargetHost tweak=$Tweak swarm=$Swarm calib=$Calib monitor=$Monitor local=$Local"

function Get-TweakCommand {
  param([string]$Spec)
  if (-not $Spec) { return $null }
  $p = $Spec.Split('='); if ($p.Count -lt 2) { return "echo 'bad tweak'" }
  switch ($p[0]) {
    'rate'   { return "/usr/bin/node /boot/octalang/aurelia_miner.js --set-rate $($p[1]) --restart" }
    'temp'   { return "nvidia-smi -pl $($p[1])" }
    'backup' { $ts = (Get-Date -UFormat %s); return "rsync -a /boot/octalang/ $($p[1])/octalang-backup-$ts/" }
    default  { return "echo 'unknown tweak'" }
  }
}
function Get-SwarmCommand {
  param([string]$Spec)
  if (-not $Spec) { return $null }
  $p = $Spec.Split('='); if ($p.Count -lt 2) { return "echo 'bad swarm'" }
  switch ($p[0]) {
    'add'    { return "/usr/bin/node /boot/octalang/scripts/pi_auto.js --provision --add-nodes $($p[1]) --keyless" }
    'remove' { return "/usr/bin/node /boot/octalang/scripts/lemon_node_auto.js --remove $($p[1]) --mdns" }
    default  { return "echo 'unknown swarm op'" }
  }
}
function Get-CalibCommand {
  param([string]$Spec)
  if (-not $Spec) { return $null }
  $p = $Spec.Split('='); if ($p.Count -lt 2) { return "echo 'bad calib'" }
  return "/usr/bin/node /boot/octalang/seraphina-calibration-retrain.js --virtue-delta $($p[1]) --logistic && /usr/bin/node /boot/octalang/aurelia_miner.js --retrain-complete"
}
function Get-MonitorCommand {
  if (-not $Monitor) { return $null }
  @"
( nvidia-smi --query-gpu=temperature.gpu,utilization.gpu,power.draw --format=csv,noheader,nounits | head -n 5 || echo 'GPU metrics unavailable' );
journalctl -u aurelia-miner -n 12 --no-pager || true;
/usr/bin/node /boot/octalang/aurelia_miner.js --status 2>/dev/null | grep -E 'η boost|TH/s' || true
"@
}

$cmds = @()
$tweakCmd = Get-TweakCommand $Tweak; if ($tweakCmd) { $cmds += $tweakCmd }
$swarmCmd = Get-SwarmCommand $Swarm; if ($swarmCmd) { $cmds += $swarmCmd }
$calibCmd = Get-CalibCommand $Calib; if ($calibCmd) { $cmds += $calibCmd }
$monitorCmd = Get-MonitorCommand; if ($monitorCmd) { $cmds += $monitorCmd }

if ($cmds.Count -eq 0) { Write-Host "No operations specified"; exit 0 }

foreach ($c in $cmds) {
  $sealed = New-OctaSeal $c
  Write-OctaLog "EXEC cmd=$c seal=$($sealed.seal.Substring(0,12))"
  Write-Host "[Exec] $c"; Write-Host "[Seal] $($sealed.seal)"
  Invoke-OctaRemote $sealed.cmd
}

Write-OctaLog "COMPLETE"
Write-Host "OctaPowershell operations finished."
