// Octonion-based Neural Lattice Node (Octa-8) for inward fractal refinement
// Provides an 8D hypercomplex representation inspired by octonion algebra.
// Simplified multiplication; placeholder for full Fano-plane implementation.
// Author: SynerGroAI / Wilson of Orange

const crypto = require('crypto');

class Octonion {
    constructor(coeffs) {
        if (coeffs.length !== 8) throw new Error('Octonion requires 8 coefficients');
        this.c = coeffs.map(v => typeof v === 'number' ? v : 0);
    }
    clone() { return new Octonion([...this.c]); }
    get norm() { return Math.hypot(...this.c); }
    add(o) { return new Octonion(this.c.map((v,i) => v + o.c[i])); }
    // Simplified multiplication using quaternion-like part for first 4 components
    multiply(o) {
        const a0 = this.c[0], a = this.c.slice(1,4);
        const b0 = o.c[0], b = o.c.slice(1,4);
        const scalar = a0 * b0 - (a[0]*b[0] + a[1]*b[1] + a[2]*b[2]);
        const cross = [
            a0*b[0] + b0*a[0] + (a[1]*b[2] - a[2]*b[1]),
            a0*b[1] + b0*a[1] + (a[2]*b[0] - a[0]*b[2]),
            a0*b[2] + b0*a[2] + (a[0]*b[1] - a[1]*b[0])
        ];
        // Pass-through remaining 4 dims (placeholder)
        const tail = [
            this.c[4]*o.c[4],
            this.c[5]*o.c[5],
            this.c[6]*o.c[6],
            this.c[7]*o.c[7]
        ];
        return new Octonion([scalar, ...cross, ...tail]);
    }
    square() { return this.multiply(this); }
    power(d=2) {
        if (d === 2) return this.square();
        let result = this.clone();
        for (let i=1;i<d;i++) result = result.multiply(this);
        return result;
    }
    toJSON() { return this.c; }
}

function hashToOctonion(str, scale=1.0) {
    const h = crypto.createHash('sha256').update(str).digest();
    const coeffs = [];
    for (let i=0;i<8;i++) {
        const chunk = h.slice(i*4,(i+1)*4);
        const val = chunk.readUInt32BE(0);
        // Map to [-1,1] then scale
        const mapped = ((val / 0xffffffff) * 2 - 1) * scale;
        coeffs.push(mapped);
    }
    return new Octonion(coeffs);
}

class OctonionLatticeNode {
    constructor(dataHash, parent=null, depth=0, maxDepth=5) {
        this.parent = parent;
        this.depth = depth;
        this.maxDepth = maxDepth;
        this.hash = dataHash;
        this.octo = hashToOctonion(dataHash, 1.0);
        this.children = [];
        this.created = Date.now();
        this.energy = 1.0;
        this.bounded = this.octo.norm <= 2.0; // Basic escape horizon like Mandelbrot
        // Internal logic weights (emerge via chaos-mirroring learn loop)
        this.logicWeights = [];
    }

    forward(otherNode) {
        const z = this.octo.multiply(otherNode.octo);
        return z.add(this.octo); // affine transform stub
    }

    // Multibrot-style gating in 8D reduced to scalar norm evolution using power(d) on octonion coefficients
    gatedRefine(shareHash, { order=2, maxIter=64, spawn=8 } = {}) {
        if (this.depth >= this.maxDepth) return { spawned:0, reason:'max-depth' };
        const c = hashToOctonion(shareHash, 1.0);
        let z = new Octonion([0,0,0,0,0,0,0,0]);
        let escaped = false, iter=0;
        for (; iter<maxIter; iter++) {
            // z = z^d + c (approx power)
            z = z.power(order).add(c);
            if (z.norm > 2) { escaped = true; break; }
        }
        if (escaped) {
            return { spawned:0, reason:'escaped', iter };
        }
        // Bounded: inward expansion (children) limited by spawn parameter
        let spawned = 0;
        for (let i=0;i<spawn;i++) {
            const childHash = this.hash + `::${shareHash}::${i}`;
            const child = new OctonionLatticeNode(childHash, this, this.depth+1, this.maxDepth);
            child.energy = this.energy * 0.9;
            this.children.push(child);
            spawned++;
        }
        return { spawned, iter, reason:'bounded' };
    }

    serialize() {
        return {
            hash: this.hash,
            depth: this.depth,
            coeffs: this.octo.toJSON(),
            children: this.children.length,
            created: this.created,
            energy: this.energy,
            logicWeights: this.logicWeights
        };
    }
}

/* ===================== E8 Projection & Chaos Learning Extensions ===================== */

// Minimal placeholder subset of E8 roots for projection (real implementation should load all 240 roots)
// Each root in full E8 has either: (±1, ±1, 0^6) with even # of negative signs (and permutations) OR 1/2*(±1,...±1) with even # negatives.
// Here we include a compact orthonormal-ish scaffold for stable PCA-like projection.
const E8_BASIS_STUB = [
    [1,0,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0],
    [0,0,1,0,0,0,0,0],
    [0,0,0,1,0,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,0,1,0,0],
    [0,0,0,0,0,0,1,0],
    [0,0,0,0,0,0,0,1]
];

function e8Project(vec8, dim=2) {
    // vec8: array length 8
    // Using stub basis acts as identity; future: compute PCA / Gram-Schmidt on full root set
    if (dim >= 8) return [...vec8];
    return vec8.slice(0, dim);
}

function computeAssociator(oA, oB, oC) {
    // (A*B)*C - A*(B*C) using current simplified multiplication
    const AB = oA.multiply(oB);
    const BC = oB.multiply(oC);
    const left = AB.multiply(oC);
    const right = oA.multiply(BC);
    // Return L2 norm difference as scalar measure of non-associativity
    let sum = 0;
    for (let i=0;i<8;i++) {
        const d = left.c[i] - right.c[i];
        sum += d*d;
    }
    return Math.sqrt(sum);
}

// Attach learning capability via prototype (keeps constructor lean)
OctonionLatticeNode.prototype.chaosLearnLoop = function(inputHashes, opts = {}) {
    /*
        Chaos-mirroring logic loop:
        - Project node + inputs to low-D (dim=2 default)
        - Iterate z_{n+1} = z_n^order + c (component-wise) for each input projection c
        - Boundedness + associator magnitude influence weight updates
        - Emergent logic weights approximate AND/OR gating
    */
    const {
        epochs = 5,
        order = 2,
        dim = 2,
        innerIter = 48,
        target = 'AND', // 'AND' | 'OR' | 'MAJ'
        lr = 0.12,
        assocScale = 0.05,
        normBailout = 2.0
    } = opts;

    if (!Array.isArray(inputHashes) || inputHashes.length === 0) {
        return { updated:false, reason:'no-inputs' };
    }

    // Initialize weights if first pass
    if (this.logicWeights.length !== inputHashes.length) {
        this.logicWeights = inputHashes.map(() => 0.5);
    }

    const selfProj = e8Project(this.octo.c, dim);

    for (let ep=0; ep<epochs; ep++) {
        inputHashes.forEach((h, idx) => {
            const tempNode = new OctonionLatticeNode(h); // ephemeral
            const proj = e8Project(tempNode.octo.c, dim);
            // Chaotic forward iteration in projected space (treat each component as independent complex real axis placeholder)
            let z = selfProj.map(v => v); // copy
            for (let k=0; k<innerIter; k++) {
                // z^order + c (component-wise real power for simplicity)
                for (let dIdx=0; dIdx<z.length; dIdx++) {
                    const val = z[dIdx];
                    z[dIdx] = Math.sign(val) * Math.pow(Math.abs(val), order) + proj[dIdx];
                }
                // Bail if norm exceeds horizon
                const nrm = Math.sqrt(z.reduce((s,v)=>s+v*v,0));
                if (nrm > normBailout) break;
            }
            const finalNorm = Math.sqrt(z.reduce((s,v)=>s+v*v,0));
            const bounded = finalNorm <= normBailout;
            // Associator feedback: pick three octonions (self, temp, root) approximated by repeating
            const assoc = computeAssociator(this.octo, tempNode.octo, this.octo); // symmetrical echo
            // Target activation for this input under logic objective
            let targetActivation;
            if (target === 'AND') {
                targetActivation = 1; // refine collectively later
            } else if (target === 'OR') {
                targetActivation = bounded ? 1 : 0;
            } else { // MAJ placeholder
                targetActivation = bounded ? 1 : 0;
            }
            const current = this.logicWeights[idx];
            // Error integrates boundedness and associator anomaly (higher assoc -> dampen)
            const desired = bounded ? targetActivation : 0;
            const assocPenalty = 1 / (1 + assoc * assocScale);
            const error = (desired - current) * assocPenalty;
            this.logicWeights[idx] = Math.min(1, Math.max(0, current + lr * error));
        });
    }

    // Collapse weights into emergent gate output
    let gateOutput;
    if (target === 'AND') {
        gateOutput = this.logicWeights.every(w => w > 0.55) ? 1 : 0;
    } else if (target === 'OR') {
        gateOutput = this.logicWeights.some(w => w > 0.45) ? 1 : 0;
    } else { // MAJ
        const active = this.logicWeights.filter(w => w > 0.5).length;
        gateOutput = active >= Math.ceil(this.logicWeights.length / 2) ? 1 : 0;
    }

    // Embed logic result subtly back into octonion (feedback) distributing into first dim coefficients
    const embedAmt = 0.02 * (gateOutput ? 1 : -1);
    this.octo.c = this.octo.c.map((v,i) => i < dim ? v + embedAmt : v);

    return {
        updated:true,
        gateOutput,
        weights:[...this.logicWeights],
        depth:this.depth
    };
};

OctonionLatticeNode.prototype.associatorMetric = function(otherHashA, otherHashB) {
    const A = new OctonionLatticeNode(otherHashA).octo;
    const B = new OctonionLatticeNode(otherHashB).octo;
    return computeAssociator(this.octo, A, B);
};

module.exports.e8Project = e8Project;
module.exports.computeAssociator = computeAssociator;

module.exports.Octonion = Octonion;
module.exports.OctonionLatticeNode = OctonionLatticeNode;
module.exports.hashToOctonion = hashToOctonion;
