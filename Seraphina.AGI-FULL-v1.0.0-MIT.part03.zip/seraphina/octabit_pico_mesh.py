#!/usr/bin/env python3
"""
OctaBit Pico Mesh Integration
Embeds OctaBit wheel-lattice encryption into distributed mesh nodes.
Each pico node holds encrypted lattice shards, routed by harmonic frequency.
Mesh gossips shard presence via mDNS; queries reconstruct lattice on-demand.
"""

import hashlib
import json
import socket
import threading
import time
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import os

@dataclass
class WheelSymbol:
    """Language wheel tier symbol"""
    tier: str  # 'keyboard' / 'symbol' / 'emoji'
    value: str
    type: str  # 'node' / 'bond' / 'data' / 'harmonic'
    harmonic: float = 1.0

class OctaBitWheelLattice:
    """Base wheel-lattice encryption (SHA-256 + AES-256 GCM)"""
    def __init__(self):
        self.wheel = {'keyboard': [], 'symbol': [], 'emoji': []}
        self.lattice = {}  # (x,y,z): {'data': encrypted, 'hash': sha256, 'bonds': [], 'harmonic': float}
        self.master_key = None
        self.nonce_size = 16  # 128-bit nonce for GCM
        self.iterations = 986
        self.hash_alg = hashes.SHA256()

    def build_wheel(self, input_str: str):
        """Parse input to wheel tiers"""
        keyboard = [c for c in input_str if c.isalnum()]
        self.wheel['keyboard'] = [{'tier': 'keyboard', 'value': c, 'type': 'node', 'harmonic': 512.0} for c in keyboard]
        
        symbols = ['=>', '->', '~', '❓', '⊶']
        self.wheel['symbol'] = [{'tier': 'symbol', 'value': s, 'type': 'bond', 'harmonic': 4.32} for s in symbols if s in input_str]
        
        emoji_map = {'🔴': 432.0, '🟠': 458.0, '🟡': 484.0, '🟢': 512.0, '🔵': 542.0, '🟣': 574.0}
        emojis = [e for e in input_str if e in emoji_map]
        self.wheel['emoji'] = [{'tier': 'emoji', 'value': e, 'type': 'harmonic', 'harmonic': emoji_map[e]} for e in emojis]
        
        print(f"🌀 Wheel Built: Keyboard={len(keyboard)} nodes, Symbols={len(self.wheel['symbol'])} bonds, Emoji={len(emojis)} harmonics")

    def forge_key(self, wheel_hash: str) -> bytes:
        """Derive AES-256 key from wheel SHA-256 (PBKDF2, 986 iters)"""
        salt = b"octabit_wheel_salt_2025"
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,  # AES-256 = 32B
            salt=salt,
            iterations=986,
            backend=default_backend()
        )
        self.master_key = kdf.derive(wheel_hash.encode())
        print(f"🔐 Key Forged: AES-256 from wheel hash (986 iters)")
        return self.master_key

    def build_lattice(self):
        """Build 8x8x8 crystal from wheel symbols"""
        for i in range(512):
            x, y, z = (i % 8, (i // 8) % 8, i // 64)
            self.lattice[(x, y, z)] = {'data': None, 'hash': None, 'bonds': [], 'harmonic': 1.0}
        
        # Map wheel to lattice
        node_idx = 0
        for sym in self.wheel['keyboard'] + self.wheel['symbol'] + self.wheel['emoji']:
            if node_idx < 512:
                pos = (node_idx % 8, (node_idx // 8) % 8, node_idx // 64)
                self.lattice[pos]['data'] = sym['value']
                self.lattice[pos]['harmonic'] = sym.get('harmonic', 1.0)
                node_idx += 1
        
        # Bonds: sequential connections
        for i in range(1, 512):
            prev = ((i-1) % 8, ((i-1) // 8) % 8, (i-1) // 64)
            curr = (i % 8, (i // 8) % 8, i // 64)
            self.lattice[curr]['bonds'].append(prev)
        
        print(f"💎 Lattice Built: 512 nodes, {sum(len(n['bonds']) for n in self.lattice.values())} bonds")

    def encrypt_lattice(self):
        """SHA-256 data fragments, AES-256 GCM encrypt"""
        wheel_hash = hashlib.sha256(json.dumps(self.wheel).encode()).hexdigest()
        key = self.forge_key(wheel_hash)
        
        for pos, cell in self.lattice.items():
            if cell['data']:
                data_hash = hashlib.sha256(cell['data'].encode()).hexdigest()
                cell['hash'] = data_hash
                
                # Generate 128-bit nonce from harmonic
                nonce = hashlib.sha256(str(cell.get('harmonic', 1.0)).encode()).digest()[:self.nonce_size]
                aead = AESGCM(key)
                ciphertext = aead.encrypt(nonce, cell['data'].encode(), None)
                cell['data'] = ciphertext.hex()
                
        print(f"🔒 Lattice Encrypted: SHA-256 leaves + AES-256 shards (nonce={self.nonce_size}B)")

    def rebuild_from_wheel(self, input_str: str):
        """Full rebuild: Wheel → Lattice → Encrypt"""
        self.build_wheel(input_str)
        self.build_lattice()
        self.encrypt_lattice()
        return self.lattice

@dataclass
class OctaShard:
    """Encrypted lattice shard for mesh node storage"""
    pos: Tuple[int, int, int]  # (x, y, z) coordinate
    data_enc: str  # Hex-encoded ciphertext
    hash_sha256: str  # Data hash (leaf)
    harmonic: float  # Frequency for routing
    bonds: List[Tuple[int, int, int]]  # Connected nodes
    shard_id: str = ""  # UUID-ish (hash(pos + harmonic))

    def __post_init__(self):
        if not self.shard_id:
            self.shard_id = hashlib.sha256(f"{self.pos}{self.harmonic}".encode()).hexdigest()[:16]

class PicoMeshNode:
    """Pico mesh node: stores encrypted shards, routes by harmonic"""
    def __init__(self, node_id: str, port: int = 0):
        self.node_id = node_id
        self.port = port
        self.shards: Dict[str, OctaShard] = {}  # shard_id → OctaShard
        self.peers: Dict[str, str] = {}  # peer_id → address
        self.lock = threading.Lock()
        print(f"📡 PicoMesh Node {node_id} initialized (port={port})")

    def store_shard(self, shard: OctaShard):
        """Store encrypted shard locally"""
        with self.lock:
            self.shards[shard.shard_id] = shard
        print(f"  💾 Shard {shard.shard_id} stored at {shard.pos} (harmonic={shard.harmonic})")

    def get_shard(self, shard_id: str) -> Optional[OctaShard]:
        """Retrieve shard"""
        with self.lock:
            return self.shards.get(shard_id)

    def gossip_shards(self) -> Dict[str, str]:
        """Advertise shard presence (gossip protocol stub)"""
        with self.lock:
            return {sid: f"{s.pos}:{s.harmonic}" for sid, s in self.shards.items()}

    def ingest_lattice(self, lattice: Dict, mesh_id: str):
        """Ingest OctaBit lattice, distribute shards across pico mesh"""
        print(f"🔄 Ingesting lattice into mesh {mesh_id}")
        shard_count = 0
        for pos, cell in lattice.items():
            if cell['data']:  # Only encrypted nodes
                shard = OctaShard(
                    pos=pos,
                    data_enc=cell['data'],
                    hash_sha256=cell.get('hash', ''),
                    harmonic=cell.get('harmonic', 1.0),
                    bonds=cell.get('bonds', [])
                )
                self.store_shard(shard)
                shard_count += 1
        print(f"✅ Ingested {shard_count} shards into {self.node_id}")

class OctaBitPicoMesh:
    """Distributed OctaBit mesh: wheel-lattice encrypted shards across pico nodes"""
    def __init__(self, mesh_id: str, num_nodes: int = 4):
        self.mesh_id = mesh_id
        self.nodes: Dict[str, PicoMeshNode] = {}
        self.lattice_root: Optional[Dict] = None
        self.master_key: Optional[bytes] = None
        self.shard_distribution: Dict[str, List[str]] = {}  # pos → [node_ids]
        
        # Create pico nodes
        for i in range(num_nodes):
            nid = f"{mesh_id}-pico-{i}"
            self.nodes[nid] = PicoMeshNode(nid, port=9000 + i)
        print(f"🌐 OctaBit Pico Mesh '{mesh_id}' initialized with {num_nodes} nodes")

    def distribute_lattice_shards(self, lattice: Dict):
        """Distribute encrypted lattice shards across mesh nodes (harmonic-aware)"""
        self.lattice_root = lattice
        node_list = list(self.nodes.values())
        
        print(f"📊 Distributing lattice shards across {len(node_list)} nodes...")
        shard_idx = 0
        for pos, cell in lattice.items():
            if cell['data']:
                # Route shard to node based on harmonic (freq-based distribution)
                harmonic = cell.get('harmonic', 1.0)
                node_idx = int(harmonic * shard_idx) % len(node_list)
                node = node_list[node_idx]
                
                shard = OctaShard(
                    pos=pos,
                    data_enc=cell['data'],
                    hash_sha256=cell.get('hash', ''),
                    harmonic=harmonic,
                    bonds=cell.get('bonds', [])
                )
                node.store_shard(shard)
                self.shard_distribution.setdefault(str(pos), []).append(node.node_id)
                shard_idx += 1
        
        print(f"✅ Distributed {shard_idx} shards: {len(self.shard_distribution)} unique positions")

    def query_shard(self, pos: Tuple[int, int, int]) -> Optional[OctaShard]:
        """Query shard across mesh by position"""
        pos_str = str(pos)
        if pos_str in self.shard_distribution:
            node_id = self.shard_distribution[pos_str][0]  # Primary replica
            if node_id in self.nodes:
                # Scan all shards in that node to find match
                for shard in self.nodes[node_id].shards.values():
                    if shard.pos == pos:
                        return shard
        return None

    def mesh_stats(self) -> Dict:
        """Gather mesh statistics"""
        total_shards = sum(len(n.shards) for n in self.nodes.values())
        stats = {
            'mesh_id': self.mesh_id,
            'num_nodes': len(self.nodes),
            'total_shards': total_shards,
            'shards_per_node': {nid: len(n.shards) for nid, n in self.nodes.items()},
            'unique_positions': len(self.shard_distribution),
        }
        return stats

    def verify_mesh_integrity(self) -> bool:
        """Spot-check shard hashes for integrity"""
        if not self.lattice_root:
            return False
        
        errors = 0
        for pos, cell in list(self.lattice_root.items())[:10]:  # Sample first 10
            shard = self.query_shard(pos)
            if shard and cell.get('hash') and shard.hash_sha256 != cell['hash']:
                print(f"❌ Hash mismatch at {pos}")
                errors += 1
        
        if errors == 0:
            print(f"✅ Integrity check passed ({min(10, len(self.lattice_root))} sampled)")
        return errors == 0

# Demo: Full OctaBit → Pico Mesh Integration
if __name__ == "__main__":
    print("=" * 60)
    print("OctaBit Wheel → Lattice → Pico Mesh Encryption Flow")
    print("=" * 60)
    
    # 1. Build encrypted wheel-lattice
    ob = OctaBitWheelLattice()
    lattice = ob.rebuild_from_wheel("OctaBit: node (0,0,0) => 🔴 data ~ harmonic 🟢 mesh")
    
    # 2. Initialize pico mesh
    mesh = OctaBitPicoMesh("octabit-mining-mesh-alpha", num_nodes=4)
    
    # 3. Distribute shards across mesh
    mesh.distribute_lattice_shards(lattice)
    
    # 4. Show mesh stats
    stats = mesh.mesh_stats()
    print(f"\n📈 Mesh Stats:")
    for key, val in stats.items():
        if key != 'shards_per_node':
            print(f"  {key}: {val}")
    print(f"  Shard Distribution:")
    for nid, count in stats['shards_per_node'].items():
        print(f"    {nid}: {count} shards")
    
    # 5. Query a shard
    print(f"\n🔍 Sample Query:")
    sample_pos = list(lattice.keys())[0]
    shard = mesh.query_shard(sample_pos)
    if shard:
        print(f"  Position {shard.pos}: Hash={shard.hash_sha256[:16]}... Harmonic={shard.harmonic}")
    
    # 6. Integrity check
    mesh.verify_mesh_integrity()
    
    print(f"\n✨ OctaBit Pico Mesh Ready for Mining Deployment")
