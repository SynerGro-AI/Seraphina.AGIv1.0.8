// prometheus-exporter.js
// Exposes metrics from aurrelia-metrics.jsonl (tail) as Prometheus text format.
const http = require('http');
const fs = require('fs');
const PORT = process.env.PROM_PORT || 9464;
const METRICS_FILE = process.env.METRICS_LOG || 'aurrelia-metrics.jsonl';

function tailLastLine(path){
  try {
    const data = fs.readFileSync(path,'utf8').trim();
    const line = data.split(/\n/).filter(Boolean).pop();
    if (!line) return null;
    return JSON.parse(line);
  } catch { return null; }
}

function renderMetrics(rec){
  if (!rec) return '# no data yet\n';
  const lines = [];
  const push = l=>lines.push(l);
  push('# HELP aurrelia_hashes_total Total hashes observed');
  push('# TYPE aurrelia_hashes_total counter');
  push(`aurrelia_hashes_total ${rec.hashes||0}`);
  push('# HELP aurrelia_shares_total Accepted shares submitted');
  push('# TYPE aurrelia_shares_total counter');
  push(`aurrelia_shares_total ${rec.shares||0}`);
  if (rec.attempted != null){
    push('# HELP aurrelia_attempted_headers_total Total candidate headers attempted (pre-hash flush)');
    push('# TYPE aurrelia_attempted_headers_total counter');
    push(`aurrelia_attempted_headers_total ${rec.attempted}`);
  }
  if (rec.oppAttempts != null){
    push('# HELP aurrelia_opportunity_attempts_total Total opportunity attempts (pre-gating iterations)');
    push('# TYPE aurrelia_opportunity_attempts_total counter');
    push(`aurrelia_opportunity_attempts_total ${rec.oppAttempts}`);
  }
  if (rec.lastFlushTotal != null){
    push('# HELP aurrelia_last_flush_total_headers Cumulative headers flushed since last tuning window');
    push('# TYPE aurrelia_last_flush_total_headers counter');
    push(`aurrelia_last_flush_total_headers ${rec.lastFlushTotal}`);
  }
  if (rec.hashEff != null){
    push('# HELP aurrelia_hash_efficiency_ratio Hash realization efficiency (hashes/attempted)');
    push('# TYPE aurrelia_hash_efficiency_ratio gauge');
    push(`aurrelia_hash_efficiency_ratio ${rec.hashEff}`);
  }
  if (rec.hashEffDeriv != null){
    push('# HELP aurrelia_hash_efficiency_derivative Efficiency derivative (hashEff * attempted_per_sec)');
    push('# TYPE aurrelia_hash_efficiency_derivative gauge');
    push(`aurrelia_hash_efficiency_derivative ${rec.hashEffDeriv}`);
  }
  if (rec.stall != null){
    push('# HELP aurrelia_watchdog_stall_flag 1 if watchdog currently considers system stalled');
    push('# TYPE aurrelia_watchdog_stall_flag gauge');
    push(`aurrelia_watchdog_stall_flag ${rec.stall}`);
  }
  if (rec.watchdogFusedDisableCount != null){
    push('# HELP aurrelia_watchdog_fused_disable_total Total times watchdog disabled fused path');
    push('# TYPE aurrelia_watchdog_fused_disable_total counter');
    push(`aurrelia_watchdog_fused_disable_total ${rec.watchdogFusedDisableCount}`);
  }
  if (rec.dynModulus != null){
    push('# HELP aurrelia_dynamic_worker_modulus Current dynamic worker modulus');
    push('# TYPE aurrelia_dynamic_worker_modulus gauge');
    push(`aurrelia_dynamic_worker_modulus ${rec.dynModulus}`);
  }
  if (rec.dynFlushMs != null){
    push('# HELP aurrelia_dynamic_flush_interval_ms Current dynamic worker batch flush age threshold (ms)');
    push('# TYPE aurrelia_dynamic_flush_interval_ms gauge');
    push(`aurrelia_dynamic_flush_interval_ms ${rec.dynFlushMs}`);
  }
  push('# HELP aurrelia_nodes Nodes constructed');
  push('# TYPE aurrelia_nodes gauge');
  push(`aurrelia_nodes ${rec.nodes||0}`);
  if (rec.avgInterference != null){
    push('# HELP aurrelia_avg_interference Average interference amplitude');
    push('# TYPE aurrelia_avg_interference gauge');
    push(`aurrelia_avg_interference ${rec.avgInterference}`);
  }
  if (rec.avgInterferenceGain != null){
    push('# HELP aurrelia_avg_interference_gain Average interference gain');
    push('# TYPE aurrelia_avg_interference_gain gauge');
    push(`aurrelia_avg_interference_gain ${rec.avgInterferenceGain}`);
  }
  if (rec.partitions && rec.partitions.ratios){
    for (const k of Object.keys(rec.partitions.ratios)){
      const v = rec.partitions.ratios[k];
      push(`# HELP aurrelia_partition_ratio Acceptance ratio for partition ${k}`);
      push('# TYPE aurrelia_partition_ratio gauge');
      push(`aurrelia_partition_ratio{partition="${k}"} ${v}`);
    }
  }
  if (rec.planeShareCounts){
    rec.planeShareCounts.forEach((v,i)=>{
      push('# HELP aurrelia_plane_shares Plane share counts');
      push('# TYPE aurrelia_plane_shares counter');
      push(`aurrelia_plane_shares{plane="${i}"} ${v}`);
    });
  }
  if (rec.planeWeights){
    rec.planeWeights.forEach((w,i)=>{
      push('# HELP aurrelia_plane_weight Current plane weight');
      push('# TYPE aurrelia_plane_weight gauge');
      push(`aurrelia_plane_weight{plane="${i}"} ${w}`);
    });
  }
  if (rec.coin){
    push('# HELP aurrelia_coin_info Coin selection (value is always 1, label identifies coin)');
    push('# TYPE aurrelia_coin_info gauge');
    push(`aurrelia_coin_info{coin="${rec.coin}"} 1`);
  }
  if (rec.algo){
    push('# HELP aurrelia_algo_info Algorithm selection (value is always 1, label identifies algorithm)');
    push('# TYPE aurrelia_algo_info gauge');
    push(`aurrelia_algo_info{algo="${rec.algo}"} 1`);
  }
  if (rec.wasm){
    // Backward compat: midAvailable, fusedAvailable
    if (rec.wasm.midAvailable != null){
      push('# HELP aurrelia_wasm_mid_available 1 if midstate WASM path available');
      push('# TYPE aurrelia_wasm_mid_available gauge');
      push(`aurrelia_wasm_mid_available ${rec.wasm.midAvailable?1:0}`);
    }
    if (rec.wasm.fusedAvailable != null){
      push('# HELP aurrelia_wasm_fused_available 1 if fused WASM path available');
      push('# TYPE aurrelia_wasm_fused_available gauge');
      push(`aurrelia_wasm_fused_available ${rec.wasm.fusedAvailable?1:0}`);
    }
    if (rec.wasm.mismatches != null){
      push('# HELP aurrelia_wasm_mismatches Total midstate self-test mismatches detected');
      push('# TYPE aurrelia_wasm_mismatches counter');
      push(`aurrelia_wasm_mismatches ${rec.wasm.mismatches}`);
    }
    if (rec.wasm.fallbacks != null){
      push('# HELP aurrelia_wasm_fallbacks Total fallbacks from WASM to JS hashing');
      push('# TYPE aurrelia_wasm_fallbacks counter');
      push(`aurrelia_wasm_fallbacks ${rec.wasm.fallbacks}`);
    }
    if (rec.wasm.mid){
      const m = rec.wasm.mid;
      push('# HELP aurrelia_wasm_mid_calls Total midstate WASM hashing calls');
      push('# TYPE aurrelia_wasm_mid_calls counter');
      push(`aurrelia_wasm_mid_calls ${m.calls||0}`);
      push('# HELP aurrelia_wasm_mid_avg_first_ns Average first-phase ns per call (midstate)');
      push('# TYPE aurrelia_wasm_mid_avg_first_ns gauge');
      push(`aurrelia_wasm_mid_avg_first_ns ${m.avgFirstNs||0}`);
      push('# HELP aurrelia_wasm_mid_avg_second_ns Average second-phase ns per call (midstate)');
      push('# TYPE aurrelia_wasm_mid_avg_second_ns gauge');
      push(`aurrelia_wasm_mid_avg_second_ns ${m.avgSecondNs||0}`);
    }
    if (rec.wasm.fused){
      const f = rec.wasm.fused;
      push('# HELP aurrelia_wasm_fused_calls Total fused WASM headers processed (including batches)');
      push('# TYPE aurrelia_wasm_fused_calls counter');
      push(`aurrelia_wasm_fused_calls ${f.totalHeaders||0}`);
      push('# HELP aurrelia_wasm_fused_batches Total fused WASM batch calls');
      push('# TYPE aurrelia_wasm_fused_batches counter');
      push(`aurrelia_wasm_fused_batches ${f.batches||0}`);
      push('# HELP aurrelia_wasm_fused_avg_ns_per_header Average ns per header in fused batches');
      push('# TYPE aurrelia_wasm_fused_avg_ns_per_header gauge');
      push(`aurrelia_wasm_fused_avg_ns_per_header ${f.avgNsPerHeader||0}`);
      if (f.speedupEst != null){
        push('# HELP aurrelia_wasm_fused_speedup_est Estimated speedup vs JS double SHA-256 (EWMA)');
        push('# TYPE aurrelia_wasm_fused_speedup_est gauge');
        push(`aurrelia_wasm_fused_speedup_est ${f.speedupEst}`);
      }
      if (f.currentBatchSize != null){
        push('# HELP aurrelia_wasm_fused_batch_size Current adaptive fused batch size');
        push('# TYPE aurrelia_wasm_fused_batch_size gauge');
        push(`aurrelia_wasm_fused_batch_size ${f.currentBatchSize}`);
      }
      if (f.jsBaselineNs != null){
        push('# HELP aurrelia_wasm_js_baseline_ns Recent JS baseline ns per double hash (avg)');
        push('# TYPE aurrelia_wasm_js_baseline_ns gauge');
        push(`aurrelia_wasm_js_baseline_ns ${f.jsBaselineNs}`);
      }
      if (f.latencyBuckets){
        // Emit cumulative buckets for Prometheus histogram semantics
        push('# HELP aurrelia_wasm_fused_latency_bucket Cumulative count of fused header latency (ns) buckets');
        push('# TYPE aurrelia_wasm_fused_latency_bucket histogram');
        const bounds = Object.keys(f.latencyBuckets).filter(k=>k!== 'inf').map(k=>parseInt(k,10)).sort((a,b)=>a-b);
        let cumulative = 0;
        for (const b of bounds){
          cumulative += f.latencyBuckets[b] || 0;
          push(`aurrelia_wasm_fused_latency_bucket{le="${b}",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${cumulative}`);
        }
        cumulative += f.latencyBuckets['inf'] || 0;
        push(`aurrelia_wasm_fused_latency_bucket{le="+Inf",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${cumulative}`);
        // _count & _sum
        if (f.latencyCount != null){
          push(`aurrelia_wasm_fused_latency_count{algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${f.latencyCount}`);
        }
        if (f.latencyTotalNs != null){
          push(`aurrelia_wasm_fused_latency_sum{algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${f.latencyTotalNs}`);
        }
      }
      if (f.recoverAttempts != null){
        push('# HELP aurrelia_wasm_fused_recover_attempts_total Fused recovery attempts');
        push('# TYPE aurrelia_wasm_fused_recover_attempts_total counter');
        push(`aurrelia_wasm_fused_recover_attempts_total ${f.recoverAttempts}`);
      }
      if (f.recoverSuccesses != null){
        push('# HELP aurrelia_wasm_fused_recover_success_total Fused recovery successes');
        push('# TYPE aurrelia_wasm_fused_recover_success_total counter');
        push(`aurrelia_wasm_fused_recover_success_total ${f.recoverSuccesses}`);
      }
      if (f.recoverFailures != null){
        push('# HELP aurrelia_wasm_fused_recover_fail_total Fused recovery failures');
        push('# TYPE aurrelia_wasm_fused_recover_fail_total counter');
        push(`aurrelia_wasm_fused_recover_fail_total ${f.recoverFailures}`);
      }
      if (f.lastRecoverTs != null){
        push('# HELP aurrelia_wasm_fused_last_recover_timestamp_ms Last successful fused recovery wall-clock ms');
        push('# TYPE aurrelia_wasm_fused_last_recover_timestamp_ms gauge');
        push(`aurrelia_wasm_fused_last_recover_timestamp_ms ${f.lastRecoverTs}`);
      }
      if (f.parityInterval != null){
        push('# HELP aurrelia_wasm_fused_parity_interval Current adaptive parity sampling interval (batches)');
        push('# TYPE aurrelia_wasm_fused_parity_interval gauge');
        push(`aurrelia_wasm_fused_parity_interval ${f.parityInterval}`);
      }
      if (f.parityAnomalies != null){
        push('# HELP aurrelia_wasm_fused_parity_anomalies_total Total parity/latency anomalies that tightened interval');
        push('# TYPE aurrelia_wasm_fused_parity_anomalies_total counter');
        push(`aurrelia_wasm_fused_parity_anomalies_total ${f.parityAnomalies}`);
      }
      if (f.latencyCv != null){
        push('# HELP aurrelia_wasm_fused_latency_cv Coefficient of variation of recent fused per-header latency');
        push('# TYPE aurrelia_wasm_fused_latency_cv gauge');
        push(`aurrelia_wasm_fused_latency_cv ${f.latencyCv}`);
      }
      if (f.rampActive != null){
        push('# HELP aurrelia_wasm_fused_ramp_active 1 if ramping batch size toward target');
        push('# TYPE aurrelia_wasm_fused_ramp_active gauge');
        push(`aurrelia_wasm_fused_ramp_active ${f.rampActive}`);
      }
      if (f.varianceAnomalies != null){
        push('# HELP aurrelia_wasm_fused_variance_anomalies_total Total variance (CV) anomalies tightening parity');
        push('# TYPE aurrelia_wasm_fused_variance_anomalies_total counter');
        push(`aurrelia_wasm_fused_variance_anomalies_total ${f.varianceAnomalies}`);
      }
      if (f.parityMismatchAnomalies != null){
        push('# HELP aurrelia_wasm_fused_parity_mismatch_anomalies_total Total parity mismatch anomalies');
        push('# TYPE aurrelia_wasm_fused_parity_mismatch_anomalies_total counter');
        push(`aurrelia_wasm_fused_parity_mismatch_anomalies_total ${f.parityMismatchAnomalies}`);
      }
      if (f.eventHorizon != null){
        push('# HELP aurrelia_wasm_fused_event_horizon_flag 1 if recent throughput slope crossed from negative to positive with node growth');
        push('# TYPE aurrelia_wasm_fused_event_horizon_flag gauge');
        push(`aurrelia_wasm_fused_event_horizon_flag ${f.eventHorizon}`);
      }
      if (f.throughputSlope != null){
        push('# HELP aurrelia_wasm_fused_throughput_slope_bytes_per_sec Linear regression slope of bytes processed over time');
        push('# TYPE aurrelia_wasm_fused_throughput_slope_bytes_per_sec gauge');
        push(`aurrelia_wasm_fused_throughput_slope_bytes_per_sec ${f.throughputSlope}`);
      }
      if (f.eventHorizonTriggers != null){
        push('# HELP aurrelia_wasm_fused_event_horizon_triggers_total Total event horizon trigger count since start or reset');
        push('# TYPE aurrelia_wasm_fused_event_horizon_triggers_total counter');
        push(`aurrelia_wasm_fused_event_horizon_triggers_total ${f.eventHorizonTriggers}`);
      }
      if (f.projectedNextDoubleNs != null){
        push('# HELP aurrelia_wasm_fused_projected_next_double_ns Projected total ns if batch size doubled (mean * 2 * currentBatchSize)');
        push('# TYPE aurrelia_wasm_fused_projected_next_double_ns gauge');
        push(`aurrelia_wasm_fused_projected_next_double_ns ${f.projectedNextDoubleNs}`);
      }
      if (f.rampTarget != null){
        push('# HELP aurrelia_wasm_fused_ramp_target Final target batch size for active ramp');
        push('# TYPE aurrelia_wasm_fused_ramp_target gauge');
        push(`aurrelia_wasm_fused_ramp_target ${f.rampTarget}`);
      }
    }
    // Scrypt backend metrics (if present)
    if (rec.algo === 'scrypt' || rec.wasm.scryptAvailable){
      if (rec.wasm.scryptAvailable != null){
        push('# HELP aurrelia_scrypt_available 1 if scrypt backend (WASM) available');
        push('# TYPE aurrelia_scrypt_available gauge');
        push(`aurrelia_scrypt_available ${rec.wasm.scryptAvailable?1:0}`);
      }
      if (rec.wasm.scryptCalls != null){
        push('# HELP aurrelia_scrypt_calls_total Total scrypt header hash calls (WASM)');
        push('# TYPE aurrelia_scrypt_calls_total counter');
        push(`aurrelia_scrypt_calls_total ${rec.wasm.scryptCalls}`);
      }
      if (rec.wasm.scryptFallbacks != null){
        push('# HELP aurrelia_scrypt_fallbacks_total Total scrypt fallback header hashes (non-WASM)');
        push('# TYPE aurrelia_scrypt_fallbacks_total counter');
        push(`aurrelia_scrypt_fallbacks_total ${rec.wasm.scryptFallbacks}`);
      }
    }
  }
  // Per-worker fused histograms if emitted
  if (rec.wasm && rec.wasm.fused && Array.isArray(rec.wasm.fused.workerHists)){
    // Worker count gauge
    if (rec.wasm.fused.workerCount != null){
      push('# HELP aurrelia_wasm_fused_worker_count Active worker shards contributing to fused metrics');
      push('# TYPE aurrelia_wasm_fused_worker_count gauge');
      push(`aurrelia_wasm_fused_worker_count ${rec.wasm.fused.workerCount}`);
    }
    for (const wh of rec.wasm.fused.workerHists){
      const buckets = wh.buckets || {};
      const bounds = Object.keys(buckets).filter(k=>k!=='inf').map(k=>parseInt(k,10)).sort((a,b)=>a-b);
      let cumulative=0;
      for (const b of bounds){ cumulative += buckets[b]||0; push(`# HELP aurrelia_wasm_fused_worker_latency_bucket Cumulative header latency buckets per worker (ns)`); push('# TYPE aurrelia_wasm_fused_worker_latency_bucket histogram'); push(`aurrelia_wasm_fused_worker_latency_bucket{shard="${wh.shard}",le="${b}",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${cumulative}`); }
      cumulative += buckets['inf']||0; push(`aurrelia_wasm_fused_worker_latency_bucket{shard="${wh.shard}",le="+Inf",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${cumulative}`);
      push(`aurrelia_wasm_fused_worker_latency_bucket_count{shard="${wh.shard}",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${wh.count||0}`);
      push(`aurrelia_wasm_fused_worker_latency_bucket_sum{shard="${wh.shard}",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${wh.totalNs||0}`);
      if (wh.latencyCv != null){
        push('# HELP aurrelia_wasm_fused_worker_latency_cv Coefficient of variation of per-header latency for worker shard');
        push('# TYPE aurrelia_wasm_fused_worker_latency_cv gauge');
        push(`aurrelia_wasm_fused_worker_latency_cv{shard="${wh.shard}",algo="${rec.algo||'sha256d'}",coin="${rec.coin||'btc'}"} ${wh.latencyCv}`);
      }
    }
  }
  // Global gating summary (norm acceptance & guidance)
  if (rec.gatingSummary){
    const g = rec.gatingSummary;
    push('# HELP aurrelia_norm_accept_rate Current aggregated norm acceptance rate');
    push('# TYPE aurrelia_norm_accept_rate gauge');
    push(`aurrelia_norm_accept_rate ${g.normAccRate||0}`);
    push('# HELP aurrelia_norm_guided_threshold Last coordinator broadcast norm threshold');
    push('# TYPE aurrelia_norm_guided_threshold gauge');
    push(`aurrelia_norm_guided_threshold ${g.lastGuidedThreshold!=null?g.lastGuidedThreshold:0}`);
    push('# HELP aurrelia_norm_samples_total Total norm samples tracked in coordinator ring');
    push('# TYPE aurrelia_norm_samples_total gauge');
    push(`aurrelia_norm_samples_total ${g.sampleCount||0}`);
    push('# HELP aurrelia_norm_accept_total Global norm accept cumulative');
    push('# TYPE aurrelia_norm_accept_total counter');
    push(`aurrelia_norm_accept_total ${g.normAccept||0}`);
    push('# HELP aurrelia_norm_reject_total Global norm reject cumulative');
    push('# TYPE aurrelia_norm_reject_total counter');
    push(`aurrelia_norm_reject_total ${g.normReject||0}`);
  }
  // Collective metrics if present
  if (rec.collective){
    const c = rec.collective;
    if (c.bytesPerSec != null){
      push('# HELP aurrelia_collective_bytes_per_sec Aggregate bytes per second processed (multi-worker)');
      push('# TYPE aurrelia_collective_bytes_per_sec gauge');
      push(`aurrelia_collective_bytes_per_sec ${c.bytesPerSec}`);
    }
    if (c.hashRateThs != null){
      push('# HELP aurrelia_collective_hashrate_ths Aggregate hash rate (TH/s)');
      push('# TYPE aurrelia_collective_hashrate_ths gauge');
      push(`aurrelia_collective_hashrate_ths ${c.hashRateThs}`);
    }
    if (c.throughputSlope != null){
      push('# HELP aurrelia_collective_throughput_slope_bytes_per_sec Regression slope of bytes over time');
      push('# TYPE aurrelia_collective_throughput_slope_bytes_per_sec gauge');
      push(`aurrelia_collective_throughput_slope_bytes_per_sec ${c.throughputSlope}`);
    }
    if (c.nodeGrowthRate != null){
      push('# HELP aurrelia_collective_node_growth_rate Nodes per second growth rate');
      push('# TYPE aurrelia_collective_node_growth_rate gauge');
      push(`aurrelia_collective_node_growth_rate ${c.nodeGrowthRate}`);
    }
    if (c.eventHorizon != null){
      push('# HELP aurrelia_collective_event_horizon_flag Event horizon detection flag');
      push('# TYPE aurrelia_collective_event_horizon_flag gauge');
      push(`aurrelia_collective_event_horizon_flag ${c.eventHorizon}`);
    }
  }
  return lines.join('\n') + '\n';
}

http.createServer((req,res)=>{
  if (req.url !== '/metrics'){ res.writeHead(404); return res.end('Not found'); }
  const rec = tailLastLine(METRICS_FILE);
  const body = renderMetrics(rec);
  res.writeHead(200, { 'Content-Type':'text/plain; version=0.0.4' });
  res.end(body);
}).listen(PORT, ()=> console.log('[Prometheus] exporter listening on', PORT));