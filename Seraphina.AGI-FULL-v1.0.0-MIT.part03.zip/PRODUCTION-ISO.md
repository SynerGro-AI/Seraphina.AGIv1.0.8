# Production ISO Packaging

## Goal
Create a portable, deterministic snapshot of the Aurrelia miner + Seraphina deterministic language engine for deployment / archival.

## Contents
- app/ core runtime JS modules (miner, deterministic AI core, reproducibility harness, multi-coin config, final test script)
- docs/ determinism & packaging documentation
- config/env-sample.txt baseline environment template
- manifest-hashes.json (SHA256 integrity of all staged files)
- reproducibility-summary.json (auto-generated digest bundle)
- (optional) manifest-hashes.json.asc (GPG detached signature)

## Build Script
Use `build-production-iso.ps1` to stage files and optionally create an ISO if `oscdimg` (Windows ADK) or `mkisofs` is available.

### Example (Unsigned)
```powershell
powershell -ExecutionPolicy Bypass -File .\build-production-iso.ps1 -StageDir .\iso_stage -IsoName Aurrelia-Deterministic.iso
```

### Example (Signed + Summary)
```powershell
powershell -ExecutionPolicy Bypass -File .\build-production-iso.ps1 -StageDir .\iso_stage -IsoName Aurrelia-Deterministic.iso -SignManifest -GpgKeyId 'release@aurrelia'
```

If you need a passphrase: supply `-GpgPassphrase (Read-Host -AsSecureString 'Passphrase')`.

## Determinism Guidance
1. Set stable seeds: `SERAPHINA_SEED`, `GLOBAL_OCTO_SEED`.
2. Fix cycle limits for reproducibility tests: `AUR_REPRO_CYCLE_LIMIT`.
3. Disable fast mode for actual mining runs (`AUR_REPRO_FAST=0`).
4. Keep pool endpoints explicit; consider using stable stratum proxies if upstream variance threatens digest comparisons.
5. Persist miner state across runs using `AUR_REPRO_STATE_IN` / `AUR_REPRO_STATE_OUT` if resumed determinism is required.

## Multi-Coin Considerations
- BTC real mining enforced; experimental coins (RVN,FREN) may need `ALLOW_EXPERIMENTAL=1` depending on enforcement scripts.
- Ensure wallet addresses are valid before distribution (replace placeholders).
- For RVN/FREN deterministic testing, restrict test window size to minimize upstream job changes.

## Integrity Verification
After ISO creation, mount or extract and recompute hashes:
```powershell
Get-ChildItem -Recurse .\iso_stage | Where-Object { -not $_.PSIsContainer } | ForEach-Object { Get-FileHash $_.FullName -Algorithm SHA256 }
```
Compare with `manifest-hashes.json` entries.

## Updating
When any runtime file changes, rebuild ISO and regenerate manifest to avoid drift. Treat manifest as authoritative fingerprint.

## Prometheus Export (Optional)
Set during final mining test:
```powershell
$env:EXPORT_PROM='1'
$env:PROM_PORT='9309'
node .\final-mining-test.js
```
Metrics:
- `aur_finaltest_meta_digest` numeric fold of meta digest (lower 32 bits)
- `aur_finaltest_coin_digest{coin="BTC"}` per-coin digest fold (lower 32 bits)
- `aur_finaltest_meta_digest64` 64-bit fold (first 16 hex chars) for higher collision resistance (monitoring only)
- `aur_finaltest_coin_digest64{coin="RVN"}` 64-bit per-coin fold
Income-based recommendation (inside miner runtime): raw & biased income values exposed via adaptive gauges if configured.

## Holodeck Exclusion
Production ISO and CI scripts do not enable Holodeck. Ensure environment does not set:
```
HOLODECK_ENABLE=1
HOLODECK_DNS_ENABLE=1
```
when performing real mining or packaging. Holodeck-specific files remain for test purposes but are inert unless explicitly activated.

## CI Integration
Use `ci-deterministic-build.ps1` for a one-shot pipeline:
1. `system-repro-verify.js` (two-run determinism gate)
2. `final-mining-test.js` (multi-coin digest & optional wallet validation)
3. `build-production-iso.ps1` (manifest + summary + optional GPG)

Example:
```powershell
powershell -ExecutionPolicy Bypass -File .\ci-deterministic-build.ps1 -IsoName Aurrelia-Deterministic.iso -SignManifest -GpgKeyId release@aurrelia -Coins BTC,RVN -CycleLimit 6 -WalletValidate
```
Artifacts to publish:
- `manifest-hashes.json` (+ `.asc` if signed)
- `reproducibility-summary.json`
- Extracted `metaDigest` from final test output
- `sbom.json` (deterministic security-focused file inventory + aggregate hash)
- `pool-latency.json` (connect snapshot for BTC/RVN/FREN/KAS endpoints)

## Validators & Wallet Pre-Flight
The pipeline includes optional wallet validation (`VALIDATE_WALLETS=1`) using scripts:
- `verify-btc-address.js`
- `verify-rvn-address.js`
- `verify-fren-address.js`
Failures mark CI test as non-zero to avoid packaging with invalid addresses.

## SBOM Generation
`sbom-generate.js` produces `sbom.json` containing curated runtime file hashes and an `aggregateSha256`. Included automatically in ISO if present; re-run whenever critical scripts change. Strict mode (`SBOM_STRICT=1`) can enforce presence.

## Pool Latency Snapshot
`pool-latency-snapshot.js` captures deterministic TCP connect times to configured pool endpoints. The resulting `pool-latency.json` aids deployment site comparison and early connectivity diagnostics.

## Income-Based Coin Selection
Miner now computes per-coin raw income = (blockReward * price)/difficulty and applies deterministic bias multipliers favoring FREN and RVN (tunable via `ECON_FREN_BIAS`, `ECON_RVN_BIAS`). Hysteresis prevents thrashing. Switch events log raw/biased income vectors for audit.

## Extended Metrics
64-bit digest fold gauges supplement existing 32-bit folds for stronger collision detection in monitoring dashboards. JavaScript numeric precision retains ~53 bits; primary use is alerting, not cryptographic proof.

## Future Enhancements
- Multi-arch build matrix (Linux minimal rootfs + Windows ISO) with identical manifest logic.
- SBOM signing and attestation chain.
- Latency trend aggregation (quantiles over multiple snapshots).
- Automated pool connectivity pre-flight risk scoring.

---
End of PRODUCTION-ISO.md
