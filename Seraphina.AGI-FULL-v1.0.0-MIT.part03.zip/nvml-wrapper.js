// nvml-wrapper.js
// Attempts to provide GPU telemetry (temp, power, utilization, memory) via NVML addon or nvidia-smi CLI.
// Deterministic fallback: returns fixed null metrics if neither available.
// No randomness; errors counted for driver error classification upstream.

const { execSync } = require('child_process');

let backend = null;
let backendName = null;
const tried = [];

function tryRequire(name){
  try { const mod = require(name); tried.push({ name, ok:true }); return mod; } catch(e){ tried.push({ name, ok:false, err:e.message }); return null; }
}

if (process.env.GPU_NVML_FORCE_SMI !== '1'){
  backend = tryRequire('nvml-addon') || tryRequire('node-nvml') || tryRequire('@nvidia/nvml');
  if (backend) backendName = 'nvml';
  if (backend && backend.nvmlInit && !backend._inited){
    try { backend.nvmlInit(); backend._inited = true; } catch(e){ backend = null; backendName=null; }
  }
}

function queryNvml(){
  if (!backend) return null;
  try {
    // Assume first GPU index 0
    const idx = 0;
    let temp, power, util, memUsedMB, memTotalMB;
    if (backend.getDeviceTemp) temp = backend.getDeviceTemp(idx);
    if (backend.getDevicePowerUsage) power = backend.getDevicePowerUsage(idx); // Watts
    if (backend.getDeviceUtilizationRates){
      const u = backend.getDeviceUtilizationRates(idx);
      util = u.gpu; // percentage
    }
    if (backend.getMemoryInfo){
      const m = backend.getMemoryInfo(idx); // bytes
      memUsedMB = m.used / (1024*1024);
      memTotalMB = m.total / (1024*1024);
    }
    return { temp, power, util, memUsedMB, memTotalMB };
  } catch(e){ return { error: e.message }; }
}

function querySmi(){
  try {
    // utilization.gpu,memory.total,memory.used,temperature.gpu,power.draw
    const cmd = 'nvidia-smi --query-gpu=utilization.gpu,memory.total,memory.used,temperature.gpu,power.draw --format=csv,noheader,nounits';
    const out = execSync(cmd, { stdio: ['ignore','pipe','ignore'], timeout: 3000 }).toString().trim();
    const parts = out.split(/[,\n]/).map(x=> x.trim()).filter(Boolean);
    if (parts.length < 5) return null;
    const util = parseFloat(parts[0]);
    const memTotalMB = parseFloat(parts[1]);
    const memUsedMB = parseFloat(parts[2]);
    const temp = parseFloat(parts[3]);
    const power = parseFloat(parts[4]);
    return { temp, power, util, memUsedMB, memTotalMB };
  } catch(e){ return null; }
}

function getStats(){
  let stats = queryNvml();
  if (!stats || stats.error){ stats = querySmi(); }
  if (!stats) return { temp:null, power:null, util:null, memUsedMB:null, memTotalMB:null, backend: backendName, available:false, tried };
  return { ...stats, backend: backendName || 'smi', available:true, tried };
}

module.exports = { getStats };
