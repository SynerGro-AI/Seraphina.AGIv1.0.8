// model-sig-gauge.js
// Prometheus gauge for model adapter signature + ledger
'use strict';
const crypto = require('crypto');
const fs = require('fs');
let prom=null; try { prom = require('prom-client'); } catch(_){ }
const MODEL_ID = process.env.AUR_AGENT_MODEL_ID || 'seraphina-stub-v1';
const LEDGER_PATH = process.env.MODEL_SIG_LEDGER || 'model-sig-ledger.jsonl';

function forgeSig(){
  const sig = crypto.createHash('sha256').update(MODEL_ID).digest('hex').slice(0,8);
  return sig;
}

function appendLedger(entry){
  try {
    let prev='GENESIS';
    if(fs.existsSync(LEDGER_PATH)){
      const lines=fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/).filter(Boolean); if(lines.length){ try{ prev=JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch(_){} }
    }
    entry.prevHash=prev; entry.chainHash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n');
  } catch(e){ console.warn('[ModelSigLedger] append error', e.message); }
}

function saveSig(){
  const sig = forgeSig();
  if(prom){
    if(!global.__AUR_METRICS_REG__) global.__AUR_METRICS_REG__ = { registry: prom.register, gauges:{} };
    if(!global.__AUR_METRICS_REG__.gauges.modelSig){
      global.__AUR_METRICS_REG__.gauges.modelSig = new prom.Gauge({ name:'aurrelia_agent_model_sig', help:'Model signature hash short (hex substring)' });
    }
    global.__AUR_METRICS_REG__.gauges.modelSig.set(parseInt(sig,16));
  }
  appendLedger({ ts:Date.now(), modelId: MODEL_ID, sig });
  console.log('[ModelSig] forged sig='+sig+' modelId='+MODEL_ID);
  return sig;
}

if(require.main === module){ saveSig(); }
module.exports = { saveSig };
