// MSI RTX Queen optimization helper script
// This script validates presence of optional WASM SIMD module, suggests build commands,
// and can patch environment variables for a performance run.
// Usage: node msirtx-optimize.js --apply

const fs = require('fs');
const path = process.env.OCTO_WASM_PATH || 'octo-simd.wasm';

function suggestBuild(){
  console.log('Suggested WASM SIMD build (Emscripten example):');
  console.log(' emcc octo.c -O3 -msimd128 -s WASM=1 -s EXPORTED_FUNCTIONS="[\"_multiply\",\"_power\",\"_norm\"]" -o octo-simd.wasm');
  console.log('Ensure octo.c implements float32 operations on 8-coefficient octonions.');
}

function applyEnv(){
  process.env.HYPERCUBE_ROTATE_HASHES = process.env.HYPERCUBE_ROTATE_HASHES || '5000';
  process.env.HYPERCUBE_BLEND = process.env.HYPERCUBE_BLEND || '0.07';
  process.env.SPIN_TORQUE = '1';
  process.env.SPIN_RASHBA = '1';
  process.env.ISHE_ENABLED = '1';
  process.env.RASHBA_TARGET_GAP = process.env.RASHBA_TARGET_GAP || '0.35';
  process.env.HYPERCUBE_RESEED = '1';
  console.log('[Optimize] Environment tuned for performance run');
}

(function main(){
  if (!fs.existsSync(path)){
    console.warn('[Optimize] WASM module not found at', path);
    suggestBuild();
  } else {
    console.log('[Optimize] Found WASM module at', path);
  }
  if (process.argv.includes('--apply')) applyEnv();
})();
