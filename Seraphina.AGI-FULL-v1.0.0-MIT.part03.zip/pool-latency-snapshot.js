// pool-latency-snapshot.js
// Deterministic pool latency snapshot script.
// Measures TCP connect time (ms) to mining pool endpoints for configured coins.
// Output: pool-latency.json with schema { ts, results:[{coin,host,port,connectMs,ok,error}] , aggregateSha256 }
// Environment:
//   LATENCY_COINS   Comma list override (default BTC,RVN,FREN,KAS)
//   *_POOL / *_POOL_HOST / *_POOL_PORT environment same as miner (BTC_POOL, RVN_POOL, etc.)
//   LATENCY_TIMEOUT_MS  Connection timeout per attempt (default 4000)
//   LATENCY_ATTEMPTS    Attempts per host (default 1)
//   LATENCY_OUT         Output file path (default pool-latency.json)
//   LATENCY_SHOW=1      Print JSON to stdout
// Deterministic notes: ordering of results is lexical by coin then host; connect times measured via process.hrtime.bigint.

const net = require('net');
const fs = require('fs');
const crypto = require('crypto');

function parseUrl(u){
  if(!u) return null;
  try {
    if(!/^\w+:\/\//.test(u)) u = 'stratum+tcp://'+u; // ensure scheme
    const url = new URL(u);
    return { host:url.hostname, port: parseInt(url.port||'0',10)||0 };
  } catch(e){ return null; }
}

function coinPool(coin){
  const upper = coin.toUpperCase();
  const envUrl = process.env[upper+'_POOL'];
  const envHost = process.env[upper+'_POOL_HOST'];
  const envPort = process.env[upper+'_POOL_PORT'];
  if(envHost){ return { host: envHost, port: parseInt(envPort||'0',10)|| (coin==='RVN'?3636:coin==='BTC'?3333:coin==='FREN'?3333:coin==='KAS'?16110:0) }; }
  if(envUrl){ const parsed = parseUrl(envUrl); if(parsed) return parsed; }
  // Primary default
  switch(coin){
    case 'BTC': return { host:'pool.ckpool.org', port:3333 };
    case 'RVN': return { host:'raven.f2pool.com', port:3636 };
    case 'FREN': return { host:'fren.aikapool.com', port:3333 };
    case 'KAS': return { host:'pool.kaspamining.com', port:16110 };
    default: return null;
  }
}

// Fallback pool lists (deterministic ordering). Override via *_POOL_FALLBACKS comma separated host:port list.
const FALLBACKS = {
  BTC: (process.env.BTC_POOL_FALLBACKS || 'solo.ckpool.org:3333,btc.vipor.net:3333').split(',').map(s=>s.trim()).filter(Boolean),
  RVN: (process.env.RVN_POOL_FALLBACKS || 'raven.f2pool.com:3636,stratum.ravenminer.com:3838').split(',').map(s=>s.trim()).filter(Boolean),
  FREN: (process.env.FREN_POOL_FALLBACKS || 'fren.aikapool.com:3333').split(',').map(s=>s.trim()).filter(Boolean),
  KAS: (process.env.KAS_POOL_FALLBACKS || 'pool.kaspamining.com:16110,kaspahub.minerpool.com:11000').split(',').map(s=>s.trim()).filter(Boolean)
};

function hrtimeMs(start){ const diff = process.hrtime.bigint() - start; return Number(diff/1000000n); }

function attempt(host, port, timeoutMs){
  return new Promise(resolve=>{
    const start = process.hrtime.bigint();
    let finished=false;
    const sock = net.createConnection({ host, port });
    const done = (ok, err)=>{ if(finished) return; finished=true; try{ sock.destroy(); }catch(_){} resolve({ connectMs: ok? hrtimeMs(start) : null, ok, error: err||null }); };
    sock.on('connect', ()=> done(true,null));
    sock.on('error', e=> done(false,e.message));
    sock.setTimeout(timeoutMs, ()=> done(false,'timeout')); // ensure deterministic timeout
  });
}

async function measureHost(coin, host, port, attempts, timeoutMs){
  const res=[];
  for(let i=0;i<attempts;i++){
    const r = await attempt(host, port, timeoutMs);
    res.push(r);
  }
  // Aggregate: take first successful connectMs or null; average if multiple successes
  const successTimes = res.filter(r=>r.ok && typeof r.connectMs==='number').map(r=>r.connectMs);
  const connectMs = successTimes.length? Number((successTimes.reduce((a,b)=>a+b,0)/successTimes.length).toFixed(3)) : null;
  const error = successTimes.length? null : res[res.length-1].error;
  return { coin, host, port, connectMs, ok: !!successTimes.length, error, attempts: res.length };
}

async function main(){
  const coins = (process.env.LATENCY_COINS || 'BTC,RVN,FREN,KAS').split(',').map(c=>c.trim()).filter(Boolean);
  const timeoutMs = parseInt(process.env.LATENCY_TIMEOUT_MS || '4000',10);
  const attempts = parseInt(process.env.LATENCY_ATTEMPTS || '1',10);
  const outPath = process.env.LATENCY_OUT || 'pool-latency.json';
  const results=[];
  for(const c of coins){
    const primary = coinPool(c);
    const list = [];
    if(primary) list.push(primary);
    const fb = FALLBACKS[c.toUpperCase()] || [];
    fb.forEach(entry=>{
      const m = /^([^:]+):(\d+)$/.exec(entry); if(m){ list.push({ host:m[1], port:parseInt(m[2],10) }); }
    });
    if(!list.length){ results.push({ coin:c, host:null, port:null, connectMs:null, ok:false, error:'no-pool-config'}); continue; }
    // Deterministic order already by insertion; measure each
    for(const pool of list){
      try {
        const r = await measureHost(c, pool.host, pool.port, attempts, timeoutMs);
        results.push(r);
        console.log('[LATENCY]', c, pool.host+':'+pool.port, 'ok='+r.ok, 'ms='+ (r.connectMs==null?'NA':r.connectMs));
      } catch(e){ results.push({ coin:c, host:pool.host, port:pool.port, connectMs:null, ok:false, error:e.message }); }
    }
  }
  // Deterministic ordering
  results.sort((a,b)=> a.coin.localeCompare(b.coin) || (a.host||'').localeCompare(b.host||''));
  const concat = results.map(r=> `${r.coin}|${r.host||'NA'}|${r.port||0}|${r.connectMs==null?'NA':r.connectMs}|${r.ok?'1':'0'}|${r.error||'NONE'}\n`).join('');
  const aggregateSha256 = crypto.createHash('sha256').update(concat).digest('hex');
  const payload = { ts: new Date().toISOString(), results, aggregateSha256 };
  try { fs.writeFileSync(outPath, JSON.stringify(payload, null, 2)); console.log('[LATENCY] wrote', outPath, 'aggregateSha256=', aggregateSha256); } catch(e){ console.error('[LATENCY] write failed', e.message); process.exit(3); }
  if(process.env.LATENCY_SHOW==='1'){ console.log(JSON.stringify(payload, null, 2)); }
}

main();
