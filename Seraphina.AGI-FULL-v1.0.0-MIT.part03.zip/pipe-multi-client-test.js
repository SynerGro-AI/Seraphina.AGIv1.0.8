#!/usr/bin/env node
'use strict';
// pipe-multi-client-test.js : Spawn N clients to read from existing health pipe if available.
// For Windows named pipe broadcasting. Each client logs first M messages then exits.
const fs = require('fs');
const net = require('net');
const os = require('os');

const PIPE_PATH_WIN = (process.env.SERAPHINA_HEALTH_PIPE || '\\.?\pipe\seraphina-health').replace('\\?\pipe','\\.\pipe');
const CLIENTS = parseInt(process.env.PIPE_CLIENTS || '3',10);
const MESSAGES = parseInt(process.env.PIPE_MESSAGES || '5',10);

function makeClient(id){
  const path = PIPE_PATH_WIN;
  const received = [];
  const socket = net.createConnection(path, () => {
    console.log('[Client'+id+'] connected');
  });
  socket.on('data', buf => {
    const chunks = buf.toString('utf8').split(/\n+/).filter(Boolean);
    for(const c of chunks){
      received.push(c);
      console.log('[Client'+id+']', c.slice(0,160));
      if(received.length>=MESSAGES){
        console.log('[Client'+id+'] reached message limit, ending');
        socket.destroy();
      }
    }
  });
  socket.on('error', err => {
    console.error('[Client'+id+'] error', err.message);
  });
  socket.on('close', () => {
    console.log('[Client'+id+'] closed totalMessages='+received.length);
  });
}

function main(){
  if(os.platform()!=='win32'){
    console.error('This test currently targets Windows named pipe only.');
    process.exit(1);
  }
  console.log('Starting multi-client pipe test clients='+CLIENTS+' messagesEach='+MESSAGES+' pipe='+PIPE_PATH_WIN);
  for(let i=0;i<CLIENTS;i++) makeClient(i+1);
}

if(require.main===module) main();
