#!/usr/bin/env node
// onnx-to-tensorrt.js
// Deterministic ONNX -> TensorRT engine converter wrapper around trtexec.
// Provides FP16 by default, optional INT8 (future), and produces a JSON summary with signature.
// Usage:
//   node onnx-to-tensorrt.js --onnx=model.onnx --out=model.engine [--no-fp16] [--workspace=4096] [--verbose]
// Environment:
//   TRTEXEC_PATH: optional explicit path to trtexec binary
// Output:
//   Writes engine file, prints JSON summary to stdout.
//   Creates .ml-engine-env.json with { "TRT_ENGINE_PATH": "..." } unless --no-env.

const { spawn } = require('child_process');
const fs = require('fs');
const crypto = require('crypto');

function arg(name, def){
  const a = process.argv.find(x=>x.startsWith('--'+name+'='));
  if (!a) return def;
  return a.split('=')[1];
}
function flag(name){ return process.argv.includes('--'+name); }

(async function main(){
  const onnxPath = arg('onnx');
  const outPath = arg('out');
  if (!onnxPath || !outPath){
    console.error('Usage: node onnx-to-tensorrt.js --onnx=model.onnx --out=model.engine [--no-fp16] [--workspace=MB]');
    process.exit(2);
  }
  if (!fs.existsSync(onnxPath)){
    console.error('[Convert] ONNX path missing:', onnxPath);
    process.exit(3);
  }
  const trtexec = process.env.TRTEXEC_PATH || 'trtexec';
  const args = ['--onnx='+onnxPath, '--saveEngine='+outPath];
  const ws = arg('workspace');
  if (ws) args.push('--workspace='+parseInt(ws,10));
  const useFp16 = !flag('no-fp16');
  if (useFp16) args.push('--fp16');
  // deterministic tactic timing cache optional
  const timingCache = outPath + '.tcache';
  args.push('--timingCacheFile='+timingCache);
  if (flag('verbose')) args.push('--verbose');
  console.log('[Convert] Invoking', trtexec, 'args=', args.join(' '));
  const start = Date.now();
  const proc = spawn(trtexec, args, { stdio: ['ignore','pipe','pipe'] });
  let stdout=''; let stderr='';
  proc.stdout.on('data', d=>{ stdout += d.toString(); if (flag('verbose')) process.stdout.write(d); });
  proc.stderr.on('data', d=>{ stderr += d.toString(); if (flag('verbose')) process.stderr.write(d); });
  proc.on('error', e=>{ console.error('[Convert] spawn error', e.message); process.exit(4); });
  proc.on('close', code=>{
    const durMs = Date.now() - start;
    if (code !== 0){
      console.error('[Convert] trtexec exited code', code);
      console.log(JSON.stringify({ ok:false, code, durMs, stderrHead: stderr.slice(0,500) }));
      process.exit(code);
    }
    if (!fs.existsSync(outPath)){
      console.error('[Convert] Engine file not produced');
      process.exit(5);
    }
    const engBuf = fs.readFileSync(outPath);
    const sig = crypto.createHash('sha256').update(engBuf).digest('hex');
    let cacheSig = null;
    if (fs.existsSync(timingCache)){
      cacheSig = crypto.createHash('sha256').update(fs.readFileSync(timingCache)).digest('hex');
    }
    const summary = {
      ok: true,
      engine: outPath,
      sizeBytes: engBuf.length,
      sha256: sig,
      fp16: useFp16,
      timingCache: cacheSig,
      durMs,
      stdoutTail: stdout.slice(-800),
    };
    if (!flag('no-env')){
      try { fs.writeFileSync('.ml-engine-env.json', JSON.stringify({ TRT_ENGINE_PATH: outPath }, null, 2)); } catch(e){ /* ignore */ }
    }
    // Print JSON summary
    console.log(JSON.stringify(summary));
    process.exit(0);
  });
})();
