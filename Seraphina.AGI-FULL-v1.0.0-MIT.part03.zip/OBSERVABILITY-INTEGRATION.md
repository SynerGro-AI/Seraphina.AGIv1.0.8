# Seraphina Observability & Deep Multi-Scale Trace Analytics

## 1. Overview
This document explains how to wire Seraphina's training metrics (`seraphina_*` Prometheus gauges) with a full observability stack: Prometheus + Tempo (deep TraceQL subquery chaining), Loki (log correlation), Mimir (long-term metrics), Parca/Pyroscope (profiling), and legacy APM bridges (Jaeger / Zipkin / Elastic / Datadog / New Relic). It also covers extreme subquery nesting patterns (undecuple → unvigintuple) and practical strategies to keep performance stable.

## 2. Prometheus Rules Loading
Add the existing rules file to `prometheus.yml`:
```yaml
rule_files:
  - mining/prometheus-seraphina-rules.yml
```
Reload (Prometheus started with `--web.enable-lifecycle`):
```powershell
Invoke-WebRequest -Uri http://localhost:9090/-/reload -Method POST
```
Validate:
- UI → Status → Rules: groups `seraphina_performance`, `seraphina_accuracy`, `seraphina_anomaly`, `seraphina_wasm` present.
- Query examples:
  - `seraphina_wasm_epoch_avg_ms`
  - `avg_over_time(seraphina_accuracy_current[30m])`

## 3. Metrics Exposed (Training Script)
Core gauges (names may appear as series with single sample value at scrape time):
- `seraphina_wasm_epoch_first_ms`
- `seraphina_wasm_epoch_avg_ms`
- `seraphina_wasm_warm_delta_ms`
- `seraphina_accuracy_current`
- `seraphina_accuracy_ethical_current`
- `seraphina_ema_vs_median_delta_current`
- `seraphina_epoch_avg_ms`
- Plus existing histogram/delta gauges (if present): `seraphina_noise_level_pct`, `seraphina_ema_vs_median_delta_hist`
Ledger enrichment adds fields: `warmStartFirstMs`, `warmStartAvgMs`, `warmStartDeltaMs` for audit queries (outside Prometheus).

## 4. Tempo Configuration (Deep TraceQL Nested Subqueries)
Tempo config excerpt (`tempo.yaml`) enabling experimental nested depth beyond native (≤4) up to 21:
```yaml
search:
  # Native limit ≤4; raise cautiously. Each increment multiplies query planning complexity.
  experimental_nested_depth: 21

metrics_generator:
  spans_metrics:
    histogram_buckets: [0.001, 0.005, 0.01]  # Fine-grained latency buckets
```
Restart Tempo after changes. Confirm via Grafana Tempo DS settings → “Features” / search debug logs.

### Safety & Performance Considerations
- Each additional nesting level expands AST size & evaluation phases; expect non-linear CPU growth.
- Avoid running the deepest chains on global services; restrict with `{ .service = "target" }` filters early.
- Use recording rules to pre-compute long window aggregates instead of recomputing inside nested queries.

## 5. Extreme Multi-Scale Patterns
The provided patterns escalate window chaining to highlight micro → macro trend fusion. Examples:
- Undecuple (11): latency “ultra-mega-acceleration”
- Duodecuple (12) … up to Unvigintuple (21): “lambda-acceleration”

### General Structure Template
```
rate( rate( … rate( unwrap .duration [baseRange] )[w1:baseRange] )[w2:w1] … )[wN:w_{N-1}] > THRESH
```
Where each `[outerRange:innerRange]` widens temporal perspective.

### Practical Recommendation
Limit production dashboards to ≤8 nested levels. Use scheduled offline queries or precomputed series for deeper analytic explorations.

## 6. Optimization Strategies for Deep Queries
1. Pre-Record Outer Windows:
   - Example Prometheus recording rule: `record: traces_duration_rate_6h` → `rate(unwrap .duration[6h])`
   - Then reuse `traces_duration_rate_6h` inside TraceQL; reduces raw span scans.
2. Early Filtering:
   - Put attribute filters (`{ .service = "api", .error != true }`) before expensive functions.
3. Window Geometry:
   - Favor logarithmic growth (e.g., *x6* expansion) vs linear to reduce count of layers.
4. Caching / Query Frontend:
   - Enable Tempo query frontend caching if large repeated analytics.
5. Progressive Validation:
   - Start with 3 levels; diff result sets after adding each level to ensure signal improvement.

## 7. Grafana Panels
### Latency Multi-Scale (TraceQL)
Panel Query (moderate depth):
```
{ .service = "api" } | rate(rate(rate(unwrap .duration [2s])[1m:2s])[10m:1m])[1h:10m]
```
Visualization: Time-series line; add transform to rename series to `api_latency_multiscale`.

### Training Performance Dashboard
PromQL panel examples:
- Epoch Avg: `seraphina_wasm_epoch_avg_ms`
- Warm Delta Trend: `avg_over_time(seraphina_wasm_warm_delta_ms[30m])`
- Advisory Accuracy: `avg_over_time(seraphina_accuracy_current[15m])`
- Ethical Accuracy: `avg_over_time(seraphina_accuracy_ethical_current[15m])`
- EMA Drift: `avg_over_time(seraphina_ema_vs_median_delta_current[30m])`
Add threshold annotations using alert rule numeric boundaries.

### Combined Trace + Training
Use Grafana “Mixed” query: Tempo TraceQL & Prometheus PromQL side-by-side; correlate latency spikes vs warm delta regressions.

## 8. Loki Integration
`promtail` pipeline to capture trace IDs:
```yaml
pipeline_stages:
  - regex:
      expression: 'trace_id=(?P<traceID>[0-9a-f]{32})'
  - labels:
      traceID: traceID
```
Query examples:
- Error bursts tied to latency: `{app="trainer"} |= "ERROR" | traceID="<id>"`
- Per-trace log count (LogQL): `count_over_time({app="trainer", traceID=~"[0-9a-f]+"}[5m])`

## 9. Mimir Long-Term Metrics
Prometheus `remote_write` → Mimir for retention beyond local Prometheus horizon:
```yaml
remote_write:
  - url: http://mimir:9009/api/v1/push
```
Query in Grafana (Mimir DS):
- Throughput: `sum(rate(traces_service_requests_total[5m])) by (service)`
Retention advantage: run deep nested historical queries without stressing live Tempo.

## 10. Profiling (Parca & Pyroscope)
- Parca: correlate CPU hotspots during slow epochs; query by `traceID` label.
- Pyroscope: capture application profile series; join by instance or pod label; add panels showing CPU time vs `seraphina_epoch_avg_ms`.

## 11. Legacy / External APM Bridges
Use OpenTelemetry Collector to route spans from Jaeger / Zipkin / Elastic / Datadog / New Relic exporters into Tempo:
```yaml
receivers:
  jaeger:
  zipkin:
  otlp:
exporters:
  otlp/tempo:
    endpoint: tempo:4317
service:
  pipelines:
    traces:
      receivers: [jaeger, zipkin, otlp]
      exporters: [otlp/tempo]
```
Ensure unified attribute naming (e.g., normalize service names) to make deep TraceQL chains consistent.

## 12. Alert Validation Runbook
1. Warm Delta Negative:
   - Inspect recent training ledger entries for abnormal `warmStartFirstMs` vs `warmStartAvgMs` ratio.
2. Accuracy Drop:
   - Compare advisory vs ethical accuracy; if ethical remains stable, investigate bias in head A data slice.
3. WASM Metrics Missing:
   - Fallback detection; verify WASM module load logs; if absent, switch to native mode alert downgrade.
4. EMA Drift High:
   - Recompute median on recent window; confirm no single outlier weight vector.
5. Epoch Slow:
   - Profile with Parca; look for GC pressure or memory copy overhead.

## 13. PowerShell Quick Start
```powershell
# Start Prometheus (assuming binary extracted to .\prometheus)
./prometheus/prometheus.exe --config.file=prometheus.yml --web.enable-lifecycle

# Start Tempo (Docker example)
docker run --name tempo -v ${PWD}\tempo.yaml:/etc/tempo/tempo.yaml -p 3200:3200 -p 4317:4317 grafana/tempo:latest --config.file=/etc/tempo/tempo.yaml

# Start Loki (Docker example)
docker run --name loki -v ${PWD}\loki-config.yaml:/etc/loki/local-config.yaml -p 3100:3100 grafana/loki:latest -config.file=/etc/loki/local-config.yaml

# Start Mimir (simplified single-binary dev)
docker run --name mimir -p 9009:9009 grafana/mimir:latest -config.expand-env=true -config.file=/etc/mimir/mimir.yaml

# Query a metric
iwr http://localhost:9090/api/v1/query?query=seraphina_accuracy_current | Select-Object -ExpandProperty Content
```

## 14. Best Practices Summary
- Cap nested depth for routine dashboards.
- Precompute long windows via recording rules.
- Always early-filter service scope.
- Correlate latency spikes with profiling and log context before adjusting prune/growth heuristics.
- Maintain audit ledger integrity—never mutate historical entries.

## 15. Future Enhancements
- Add epoch duration histogram for percentile alerts (`histogram_quantile` on custom buckets).
- Introduce structured agent action counters (e.g., prune adjustments) as Prometheus counters.
- Grafana dashboard JSON export committed to repo for reproducibility.
- Query cost budgeting (total nested depth * raw span scan factor) logged per request.

## 16. Ultra-Extreme Nesting (>21 Levels: Duovigintuple & Beyond)
When pushing past 21 nested subqueries (duovigintuple, trestrigintuple 33), the naive approach becomes computationally explosive. Use these strategies:

### 16.1 Decomposition by Rings
Break the chain into conceptual "rings" of growth:
- Ring 1 (micro): raw unwrap + first 3–4 rate/agg layers.
- Ring 2 (meso): mid windows producing stabilized per-minute/per-hour derivatives.
- Ring 3 (macro): day-scale consolidation.
- Ring 4 (mega): multi-day / multi-week drift trend.
Record each ring separately as Prometheus series or Tempo derived metrics, then compose final analytics with ≤6 TraceQL functions instead of 20–30.

Example decomposition:
1. TraceQL recording rule (Tempo metrics-generator or synthetic): `rate(unwrap .duration [0.1s])` → `trace_latency_rate_micro`.
2. Prometheus recording: `avg_over_time(trace_latency_rate_micro[1m])` → `trace_latency_rate_1m`.
3. Higher window: `avg_over_time(trace_latency_rate_1m[15m])` → `trace_latency_rate_15m`.
4. Day macro: `avg_over_time(trace_latency_rate_15m[24h])` → `trace_latency_rate_day`.
Final dashboard metric: combine micro vs day: `trace_latency_rate_micro / trace_latency_rate_day` for acceleration ratio.

### 16.2 Conditional Expansion Heuristic
Only add another nesting level if variance reduction > threshold (e.g., outer_window_stddev < inner_window_stddev * 0.7). Maintain a small script to test incremental benefit; abort at diminishing returns.

### 16.3 Span Pre-Segmentation
Tag spans with coarse bucket labels (e.g., `lat_bucket="subms|1_5ms|5_20ms|20ms_plus"`) during ingestion. Aggregations over labeled subsets reduce need for ultra-deep temporal stacking.

### 16.4 Query Cost Guard
Implement a sidecar estimator: cost = depth * (distinct_services * window_span_factor). Refuse queries if cost > policy limit (e.g., > 800). Log refusal with reason and suggest recorded series alternatives.

### 16.5 Memory & CPU Safeguards
- Enable Tempo query timeout (e.g., 30s) and max bytes per result.
- Use Grafana panel repeating over small service sets rather than multi-service deep chain.

### 16.6 Fallback Pattern (Depth Collapse)
Replace last 8 nested windows by two pre-aggregated series:
```
{ .service = "api" } | rate(rate(unwrap .duration [0.1s])[1m:0.1s])[15m:1m]
```
Then compare with separately recorded day-level statistic.

### 16.7 Why 33 Is Rarely Justified
Past ~16 layers diminishing improvements typically < 2–3% stability gain while query latency may 3–10x. Prefer ring decomposition or probabilistic sampling (sample 1/10 spans for micro layers; full set for macro).

### 16.8 Automated Recommendation Engine (Future)
Plan: maintain metrics `trace_query_depth_requested` and `trace_query_depth_executed`. If executed < requested due to collapse, expose a Prometheus counter with reason label (`reason="depth_guard"`).

## 17. Alternative Patterns to Replace Deep Chains
1. Multi-Resolution Join: Maintain separate series: micro_rate_1m, macro_rate_24h; compute ratio rather than nested chain.
2. EWMA + Median Hybrid: Combine short-term EWMA of latency with long-term median; alert on divergence rather than constructing 10 windows of avg_over_time.
3. Quantile Sketches: Use t-digest / HDR hist ports (if integrated) to derive quantiles over large windows without layering.
4. Fourier / Wavelet Preprocessing: Transform latency series to frequency domain for trend shift detection—dramatically fewer temporal layers needed.
5. Percentile Drift Vector: Construct vector [p50,p90,p95,p99] at micro and macro windows; compute cosine distance as anomaly metric.

## 18. Example Guardrail Configuration Snippet
Tempo (hypothetical future setting):
```yaml
limits:
  max_nested_depth: 24        # Hard ceiling
  depth_soft_limit: 16        # Above this log advisory
  max_concurrent_deep_queries: 2
  query_timeout: 30s
  partial_response: true
```
Prometheus rule to monitor usage:
```yaml
- record: trace_deep_query_usage_pct
  expr: (sum(rate(tempo_query_depth_requested_total{depth>16}[5m])) / sum(rate(tempo_query_requests_total[5m]))) * 100
```
Alert if >20% requests exceed soft limit.

## 19. Practical Decision Matrix
| Goal | Recommended Depth | Strategy |
|------|-------------------|----------|
| Quick latency health | ≤4 | Direct TraceQL chain |
| Dashboard multi-scale | 5–8 | Pre-record meso windows |
| Investigate rare spike | 9–12 | Temporary deep query + profile correlations |
| Research / offline batch | 13–20 | Ring decomposition + cost guard |
| Extreme experiment | 21–24 | Simulated; avoid production |
| 25+ request | Reject/Collapse | Provide alternatives |

## 20. Summary
For duovigintuple (22) or trestrigintuple (33) chains, prefer decomposition, recording rules, and guardrails over raw nesting. Production resilience depends on bounding computational cost, reusing pre-aggregated windows, and surfacing ratio/drift metrics rather than brute-force temporal expansion.

## 21. Depth Guard Module Usage
To prevent runaway ultra-deep TraceQL chains, use the helper in `traceql-depth-guard.js`.

Example (Node.js helper for constructing safe query):
```js
const { buildNestedRateQuery, registerGuardMetrics, guardDepth } = require('./traceql-depth-guard');
const client = require('prom-client');
registerGuardMetrics(client);

const windows = ['0.0075m','0.075m','0.0125h','0.1125h','0.0375d','0.3d','1.875d','3.75d','7.5d','15d'];
const result = buildNestedRateQuery({
  service: 'api',
  baseRange: '0.05s',
  windows,
  maxDepth: 16,
  softDepth: 12,
  windowSpanFactor: 6 // approximate growth factor
});

// Record metrics
guardDepth({ requestedDepth: windows.length, executedDepth: result.executedDepth, reason: result.reason });

console.log('Safe TraceQL:', result.final);
console.log('Depth collapse reason:', result.reason);
```
PromQL monitoring:
- `trace_query_depth_requested_total`
- `trace_query_depth_executed_total`
- `trace_query_depth_collapses_total{reason="soft_cap_collapse"}`
- Derived recording rule: `trace_deep_query_usage_pct`

Alert (see rules file): `TraceDeepQueryExcessiveCollapses` triggers if collapses >20% over 15m.

Recommended policy values:
- Soft depth ≤12 for live dashboards
- Hard depth ≤16 for interactive queries
- Offline analysis may raise to 24 with ring decomposition

## 22. Tempo Lua Pipe Library
Reference file: `tempo-lua-pipes-examples.lua` provides guarded, performance-focused pipes.

Included examples:
- `pipe_latency_bucket` – Buckets span durations with pcall guard.
- `pipe_event_latency_avg` – Aggregates event latencies with xpcall fallback.
- `pipe_severity_classifier` – Regex-based severity labeling.
- `pipe_batch_event_processing` – Safe per-event transformation with error aggregation.
- `pipe_latency_acceleration` – Computes micro vs macro acceleration ratio (requires pre-ingested labels).
- `pipe_drop_slow_errors` – Conditional drop for slow error spans.
- `pipe_structured_log` – Emits structured JSON logs to Loki via Tempo.
- `pipe` – Master dispatcher composing selected pipes.

### 22.1 Enabling
`tempo.yaml` snippet:
```yaml
distributor:
  receivers:
    otlp:
      protocols:
        grpc: {}
query_extensions:
  lua_script: "mining/tempo-lua-pipes-examples.lua"  # adjust path if needed
```

### 22.2 Best Practices
- Keep master `pipe` minimal; avoid heavy loops if depth-chained TraceQL functions are used.
- Use `pcall` / `xpcall` for all mutation logic to prevent query-wide failures.
- Emit diagnostic collapse correlation: when depth guard collapses a query, append a synthetic span label `collapsed_depth="true"` at ingestion (Collector processor) to allow filtering.

### 22.3 Observability of Pipes
Add Loki queries:
- Error rate: `count_over_time({job="tempo"} |= "pipe_latency_bucket failure"[5m])`
- Dropped slow error spans: `count_over_time({job="tempo"} |= "dropping slow error span"[5m])`

Prometheus custom exporter (future): increment `tempo_pipe_errors_total` when logs contain `pipe_* failure` patterns.

### 22.4 Integration with Depth Guard Metrics
Correlate collapse percentage vs pipe classification anomalies:
```
(trace_deep_query_usage_pct > 10) and (count_over_time({job="tempo"} |= "pipe_latency_bucket failure"[5m]) > 0)
```
Investigate if deep query reductions alter latency bucket distributions.

## 23. Acceleration Ratio Validation
The acceleration ratio (`accel_ratio`) quantifies micro vs macro latency acceleration (value range [0,1]). To prevent cardinality inflation from malformed labels:

### 23.1 Node Schema Validation
File: `accel-validator/accel_validator.js` uses Ajv enforcing numeric [0,1]. Integration within depth guard:
```js
const { buildNestedRateQuery } = require('./traceql-depth-guard');
const { validateAccelRatio } = require('./accel-validator/accel_validator');

try { validateAccelRatio({ accel_ratio: 0.72 }); } catch (e) { /* handle */ }
```
Queries can pass `accelRatio` option; invalid ratios logged with reason `accel_ratio_invalid`.

### 23.2 Lua Pipe Guard
In `tempo-lua-pipes-examples.lua` master `pipe` strips invalid numeric or out-of-range values and logs:
```
PIPE_ERR type=accel_invalid msg=accel_ratio out of [0,1] range value=<raw>
```
Promtail regex extracts `pipe_type=accel_invalid` feeding `pipe_errors_total` counter.

### 23.3 Prometheus Rules
Group `accel_guard` alert `SeraphinaInvalidAccelRatio` triggers if invalid labels detected over 10m. Recording rule placeholders can be refined once `pipe_errors_total` metric pipeline is active.

### 23.4 Best Practices
- Never format ratio with excessive precision; 4 decimal places recommended.
- Avoid dynamic string labels representing ratio buckets; use numeric histograms instead.
- If ratio persistent >0.95, investigate micro window volatility or macro starvation.

---
This document complements `prometheus-seraphina-rules.yml` and serves as a runbook + design rationale for advanced multi-scale analytics across the Seraphina training lifecycle.
