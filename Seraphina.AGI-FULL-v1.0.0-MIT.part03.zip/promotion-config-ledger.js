// promotion-config-ledger.js
// Dedicated hash-chained & rotating ledger for model promotion configuration snapshots.
'use strict';
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');

const PROMO_LEDGER_PATH = process.env.SERAPHINA_PROMO_CONFIG_LEDGER || 'seraphina-promotion-config-ledger.jsonl';
const PROMO_MAX_MB = parseInt(process.env.SERAPHINA_PROMO_LEDGER_MAX_MB || '3',10); // smaller threshold (MB)
const PROMO_CHUNK_BYTES = PROMO_MAX_MB * 1024 * 1024;

function canonicalize(entry){
  const keys = Object.keys(entry).sort();
  return JSON.stringify(entry, keys);
}
function chainHash(entry, prev='GENESIS'){
  return crypto.createHash('sha256').update(prev + canonicalize(entry)).digest('hex');
}
function rotateIfNeeded(){
  try {
    if(!fs.existsSync(PROMO_LEDGER_PATH)) return false;
    const st = fs.statSync(PROMO_LEDGER_PATH);
    if(st.size <= PROMO_CHUNK_BYTES) return false;
    const gzPath = PROMO_LEDGER_PATH + '.gz.' + Date.now();
    return new Promise((resolve,reject)=>{
      fs.createReadStream(PROMO_LEDGER_PATH)
        .pipe(zlib.createGzip())
        .pipe(fs.createWriteStream(gzPath))
        .on('finish',()=>{ try{ fs.unlinkSync(PROMO_LEDGER_PATH); }catch(_e){} resolve(gzPath); })
        .on('error',reject);
    });
  } catch(e){ console.warn('[PromotionLedgerRotateError]', e.message); return false; }
}
function appendPromotion(entry){
  try {
    let prev='GENESIS';
    if(fs.existsSync(PROMO_LEDGER_PATH)){
      const lines = fs.readFileSync(PROMO_LEDGER_PATH,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){} }
    }
    entry.prevHash = prev;
    entry.chainHash = chainHash(entry, prev);
    fs.appendFileSync(PROMO_LEDGER_PATH, JSON.stringify(entry)+'\n');
    const rot = rotateIfNeeded(); if(rot && rot.then) rot.then(()=>{}).catch(()=>{});
    return entry.chainHash;
  } catch(e){ console.warn('[PromotionLedgerAppendError]', e.message); return null; }
}
module.exports = { appendPromotion };
