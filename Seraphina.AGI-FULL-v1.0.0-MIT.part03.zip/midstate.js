// midstate.js
// Minimal SHA-256 midstate + continuation utilities for 80-byte Bitcoin headers.
// Deterministic, pure JS. Not micro-optimized; intended for structural midstate integration.
// If MIDSTATE_OPT=1 and a mismatch is detected vs full hash, caller should disable midstate.

const crypto = require('crypto');

// SHA-256 constants
const K = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]);

function rotr(x,n){ return (x>>>n) | (x << (32-n)); }

function sha256Compress(words, H){
  // words: Uint32Array length 16 (first 512-bit chunk) BEFORE message schedule expansion
  const W = new Uint32Array(64);
  for (let i=0;i<16;i++) W[i] = words[i];
  for (let i=16;i<64;i++){
    const s0 = rotr(W[i-15],7) ^ rotr(W[i-15],18) ^ (W[i-15]>>>3);
    const s1 = rotr(W[i-2],17) ^ rotr(W[i-2],19) ^ (W[i-2]>>>10);
    W[i] = (W[i-16] + s0 + W[i-7] + s1) >>> 0;
  }
  let a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
  for (let i=0;i<64;i++){
    const S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
    const ch = (e & f) ^ (~e & g);
    const temp1 = (h + S1 + ch + K[i] + W[i]) >>> 0;
    const S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
    const maj = (a & b) ^ (a & c) ^ (b & c);
    const temp2 = (S0 + maj) >>> 0;
    h = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
  }
  H[0] = (H[0] + a) >>> 0;
  H[1] = (H[1] + b) >>> 0;
  H[2] = (H[2] + c) >>> 0;
  H[3] = (H[3] + d) >>> 0;
  H[4] = (H[4] + e) >>> 0;
  H[5] = (H[5] + f) >>> 0;
  H[6] = (H[6] + g) >>> 0;
  H[7] = (H[7] + h) >>> 0;
}

function wordsFromBuffer(buf){
  const w = new Uint32Array(16);
  for (let i=0;i<16;i++) w[i] = buf.readUInt32BE(i*4);
  return w;
}

function bufferFromWords(words){
  const b = Buffer.alloc(32);
  for (let i=0;i<8;i++) b.writeUInt32BE(words[i], i*4);
  return b;
}

function computeMidstate(first64BytesBuf){
  if (first64BytesBuf.length !== 64) throw new Error('Need first 64 bytes');
  const H = new Uint32Array([
    0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
    0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
  ]);
  const W = wordsFromBuffer(first64BytesBuf);
  sha256Compress(W, H);
  return bufferFromWords(H); // midstate buffer
}

// Continue hashing with midstate for remaining tail (16 bytes) + padding for 80-byte message.
function sha256FromMidstate(midstateBuf, tail16Buf){
  if (midstateBuf.length !== 32) throw new Error('midstate must be 32 bytes');
  if (tail16Buf.length !== 16) throw new Error('tail must be 16 bytes');
  // Reconstruct H as Uint32Array
  const H = new Uint32Array(8);
  for (let i=0;i<8;i++) H[i] = midstateBuf.readUInt32BE(i*4);
  // Build second 512-bit chunk = last 16 bytes + 0x80 + zeros + length (640 bits)
  const chunk = Buffer.alloc(64,0);
  tail16Buf.copy(chunk,0);
  chunk[16] = 0x80;
  // last 8 bytes store big-endian bit length = 80 * 8 = 640
  chunk.writeUInt32BE(0,56);
  chunk.writeUInt32BE(640,60);
  const words = wordsFromBuffer(chunk);
  sha256Compress(words, H);
  return bufferFromWords(H); // first SHA256 result (32 bytes)
}

function doubleSha256WithMidstate(first64Buf, tail16Buf){
  const mid = computeMidstate(first64Buf);
  const first = sha256FromMidstate(mid, tail16Buf);
  const second = crypto.createHash('sha256').update(first).digest();
  return second; // Buffer 32 bytes
}

module.exports = {
  computeMidstate,
  sha256FromMidstate,
  doubleSha256WithMidstate,
};
