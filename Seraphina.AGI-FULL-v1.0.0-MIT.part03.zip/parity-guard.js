"use strict";
// parity-guard.js – KawPow & sha256d parity monitoring & disable logic
// Exports: initKawpowParity(pipeline, options), initShaParity(pipeline, options)
// options: { interval, maxMismatches, onDisable }

let prom=null; try { prom=require('prom-client'); } catch(_){}

function initKawpowParity(pipeline, opts={}){
  if (!pipeline || !pipeline.hashStrategy || pipeline.hashStrategy.id !== 'kawpow') return;
  const kawpowMirror = (function(){ try { return require('./kawpow_js_parity.js').kawpowLightJs; } catch(_){ return null; } })();
  if (!kawpowMirror) return; // nothing to do
  const interval = parseInt(process.env.KAWPOW_PARITY_INTERVAL || opts.interval || '90',10);
  const maxMis = parseInt(process.env.KAWPOW_PARITY_MAX_MISMATCH || opts.maxMismatches || '3',10);
  let mismatches = 0; let checks=0; let disabled=false;
  let gauges=null;
  if (prom){
    try {
      gauges = {
        checks: new prom.Counter({ name:'aurrelia_kawpow_parity_checks_total', help:'Total KawPow parity samples' }),
        mismatches: new prom.Counter({ name:'aurrelia_kawpow_parity_mismatches_total', help:'Total KawPow parity mismatches' }),
        enabled: new prom.Gauge({ name:'aurrelia_kawpow_parity_enabled', help:'1 if parity guard active (native enabled)' })
      };
      gauges.enabled.set(1);
    } catch(_){ gauges=null; }
  }
  function sample(){
    if (disabled) return;
    const job = pipeline.currentJob;
    if (!job) return;
    // Build synthetic header sample using current extranonce2 counter and ntime
    const nonceHex = (pipeline._parityNonceCounter = ((pipeline._parityNonceCounter||0)+1) % 0xffffffff).toString(16).padStart(8,'0');
    const headerHex = buildHeader(job, nonceHex);
    let nativeHash, jsHash;
    try { nativeHash = pipeline.hashStrategy.hashHeader(headerHex, job.height || 0, job.seed || job.prevhash || ''); } catch(_){ return; }
    try { jsHash = kawpowMirror(headerHex, job.height || 0, job.seed || job.prevhash || ''); } catch(_){ return; }
    checks++;
    if (gauges) gauges.checks.inc();
    if (!nativeHash || !jsHash) return;
    if (nativeHash.slice(0,32) !== jsHash.slice(0,32)){
      mismatches++; if (gauges) gauges.mismatches.inc();
      console.warn(`[KawPow][Parity] mismatch ${mismatches}/${maxMis} native=${nativeHash.slice(0,16)} js=${jsHash.slice(0,16)}`);
      if (mismatches >= maxMis){
        disabled=true; if (gauges) gauges.enabled.set(0);
        if (typeof opts.onDisable === 'function') opts.onDisable();
        console.error('[KawPow][Parity] DISABLING native path due to mismatches');
      }
    }
  }
  function buildHeader(job, nonceHex){
    // Simplified Block header assembly (swap little endian fields) – sufficient for parity sampling determinism
    function rev(h){ return (h||'').match(/.{2}/g)?.reverse().join('') || ''; }
    const ver = rev((job.version||'').padStart(8,'0'));
    const prev = rev(job.prevhash||'');
    const merk = rev((job.merkleRoot||job.prevhash||'').padEnd(64,'0'));
    const time = rev((job.ntime||'00000000').padStart(8,'0'));
    const nbits = rev((job.nbits||'ffffffff').padStart(8,'0'));
    const nonce = rev(nonceHex);
    return ver + prev + merk + time + nbits + nonce;
  }
  const timer = setInterval(sample, interval*1000).unref();
  pipeline._kawpowParityTimer = timer;
}

function initShaParity(pipeline, opts={}){
  if (!pipeline || pipeline.hashStrategy.id !== 'sha256d') return;
  let wasm=null; try { wasm=require('./fused_wasm.js'); } catch(_){ }
  if (!wasm || typeof wasm.hashHeaders !== 'function') return;
  const interval = parseInt(process.env.SHA_PARITY_INTERVAL || opts.interval || '120',10);
  const maxMis = parseInt(process.env.SHA_PARITY_MAX_MISMATCH || opts.maxMismatches || '4',10);
  let mismatches=0; let checks=0; let disabled=false; let prom=null; try { prom=require('prom-client'); } catch(_){ }
  let gauges=null; if (prom){ try { gauges={ enabled:new prom.Gauge({ name:'aurrelia_sha_parity_enabled', help:'1 if sha256d parity active'}), mismatches:new prom.Counter({ name:'aurrelia_sha_parity_mismatches_total', help:'sha256d parity mismatches'}), checks:new prom.Counter({ name:'aurrelia_sha_parity_checks_total', help:'sha256d parity checks'}) }; gauges.enabled.set(1);} catch(_){ gauges=null; } }
  function sample(){ if (disabled) return; const job=pipeline.currentJob; if (!job){ return; }
  const { deriveHex } = require('./deterministic-util');
  const header = deriveHex('parity-header', Date.now(), i, this.guardCycle).repeat(2).slice(0,160); // deterministic pseudo-header
    let jsH, wasmH; try { jsH = pipeline.hashStrategy.hashHeader(header); } catch(_){ return; }
    try { wasmH = wasm.hashHeaders([header])[0]; } catch(_){ return; }
    checks++; if (gauges) gauges.checks.inc();
    if (jsH.slice(0,32) !== wasmH.slice(0,32)){
      mismatches++; if (gauges) gauges.mismatches.inc();
      console.warn('[SHA][Parity] mismatch', mismatches,'/',maxMis, jsH.slice(0,16), wasmH.slice(0,16));
      if (mismatches >= maxMis){ disabled=true; if (gauges) gauges.enabled.set(0); console.error('[SHA][Parity] disabling fused wasm path'); if (typeof opts.onDisable==='function') opts.onDisable(); }
    }
  }
  const timer=setInterval(sample, interval*1000).unref(); pipeline._shaParityTimer = timer;
}

module.exports = { initKawpowParity, initShaParity };
