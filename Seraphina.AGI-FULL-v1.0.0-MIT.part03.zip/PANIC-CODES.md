# Seraphina Bare-Metal / Micro-Init Panic Codes

This document enumerates deterministic panic / exit codes emitted by the micro-init wrapper (`micro-init-wrapper.sh`) and future OctaLang PID1 implementation. Codes are stable; adding new codes will use unused gaps to preserve existing semantics.

## Code Table

| Code | Symbolic Name | Condition | Action Taken | Suggested Remediation |
|------|---------------|-----------|--------------|-----------------------|
| 0    | SUCCESS       | Normal successful initialization; all integrity checks passed. | Miner spawn proceeds (unless explicitly skipped). | None. Continue boot. |
| 20   | MANIFEST_MISSING | `manifest.json` not found or unreadable. | Spawn skipped. JSON report integrity.manifestMissing=true. | Ensure manifest is present in initramfs or rootfs; rebuild image. |
| 21   | SEAL_MISSING  | `manifest.seal` missing while manifest present. | Spawn skipped. Report integrity.sealMissing=true. | Provide `manifest.seal` or disable seal requirement for test. |
| 22   | MANIFEST_HASH_MISMATCH | Recomputed SHA256 over manifest content differs from `manifestSha256` field. | Spawn skipped; integrity.manifestHashValid=false. | Investigate tampering or corruption; regenerate manifest and seal. |
| 23   | SEAL_HMAC_INVALID | HMAC verification failed (openssl available and VAULT_PASS provided) after HKDF derivation. | Spawn skipped; integrity.sealValid=false. | Confirm HKDF inputs (salt/info) and secret; regenerate seal. |
| 27   | HKDF_DERIVE_FAILURE | HKDF extract or expand phase produced empty result. | Spawn skipped; integrity.hkdfError=true. | Verify openssl presence and VAULT_PASS validity; retry build. |
| 28   | CHAIN_VERIFY_FAIL | `chainDigest` in seal mismatches expected sha256(chain:prevNonce:manifestSha256). | Spawn skipped; integrity.chainValid=false. | Regenerate seal with correct prevNonce or reset chain file. |
| 24   | SPAWN_FAILURE | Miner executable failed to launch or non-zero exit code on initial probe. | Boot continues without miner; JSON includes spawnError field. | Inspect binary permissions, dependencies, and logs. |

Reserved range for future integrity / attestation expansion: 25–39.

## JSON Report Fields
Produced at `/boot/seraphina-boot-report.json` (example path) or stdout:
- `version`: micro-init wrapper version string
- `timestamp`: UTC ISO8601
- `panicCode`: integer code as above
- `integrity` object:
  - `manifestMissing` (bool)
  - `sealMissing` (bool)
  - `manifestHashValid` (bool)
  - `sealValid` (bool)
  - `computedManifestSha256` (hex string)
  - `declaredManifestSha256` (hex string or null)
- `spawned`: boolean if miner attempted
- `spawnSkip`: boolean if spawning intentionally skipped due to panic
- `spawnError`: optional string describing failure
- `nonce`: deterministic digest used for attestation chaining
- `notes`: optional free-form advisory (<=200 chars)

## Deterministic Nonce Derivation
Currently: `SHA256("seraphina:" + version + ":" + buildTimestamp)[0:32]` (hex truncation). Future enhancement will incorporate kernel build signature and HKDF expansion.

## HKDF + HMAC / Seal Verification
Algorithm (RFC 5869, SHA256):
1. Extract: `PRK = HMAC(salt="seraphina.init.v1", IKM=VAULT_PASS)`.
2. Expand: `OKM = HMAC(PRK, info="manifest:<manifestSha256>" || 0x01)`.
3. Key = first 32 bytes (64 hex chars) of `OKM`.
4. Seal HMAC: `HMAC(key, manifestSha256)` stored as `manifestHmac`.
Failure in steps 1 or 2 triggers panic code 27.
Mismatch of computed vs stored HMAC triggers panic code 23.
If `chainDigest` present in seal and previous nonce file exists, wrapper recomputes
`sha256("chain:" + prevNonce + ":" + manifestSha256)`; mismatch triggers panic code 28.

## Failure Handling Principles
- No retries for integrity mismatches; determinism preserved.
- All failures produce structured JSON; never silent.
- Panic codes >0 always skip miner spawn (except code 24 which occurs post-spawn attempt).
- Additional side-channel metrics (IMA measurement presence, etc.) will append fields but not alter existing panic semantics.

## Extensibility Guidelines
When adding a new panic code:
1. Select next unused code in reserved range.
2. Update this document and micro-init source simultaneously.
3. Ensure JSON includes a distinct boolean or diagnostic string for the condition.
4. Maintain backward compatibility (do not repurpose existing code values).

## Example Success Output
```json
{
  "version": "micro-init-wrapper/0.3.0",
  "timestamp": "2025-11-13T12:00:00Z",
  "panicCode": 0,
  "integrity": {
    "manifestMissing": false,
    "sealMissing": false,
    "manifestHashValid": true,
    "sealValid": true,
    "computedManifestSha256": "1f8c3a...",
    "declaredManifestSha256": "1f8c3a..."
  },
  "spawned": true,
  "spawnSkip": false,
  "nonce": "8b5e9d0c1e4a6f25b807d3c36d7a1ef3",
  "notes": "OK"
}
```

## Future Codes (Planned)
- 25: IMA_POLICY_MISSING (policy file absent when enforcement required)
- 26: IMA_MEASURE_FAILURE (kernel log indicates measurement errors)

These codes are speculative; not yet implemented.

---
Document version: 1.0.0
Chain specification version: 0.1.0

## Usage Snippets

Generate a seal (HKDF-style placeholder) matching wrapper verification:

```
setx VAULT_PASS testsecret   # Windows PowerShell use: $env:VAULT_PASS='testsecret'
./generate-seal.sh baremetal-build/initramfs-root/rootfs-manifest.json > baremetal-build/initramfs-root/rootfs-manifest.seal.json
```

Run QEMU (after building kernel + initramfs):

```
ARCH=x86_64 ./qemu-run-seraphina.sh
```

Inspect boot report inside initramfs environment (once system up, if shell available):

```
cat /opt/SeraphinaMiner/micro-init-report.json
```

Force an integrity failure example (alter manifest after seal):

```
echo 'tamper' >> baremetal-build/initramfs-root/rootfs-manifest.json
ARCH=x86_64 ./qemu-run-seraphina.sh
```

You should observe panicCode 22 for hash mismatch.
