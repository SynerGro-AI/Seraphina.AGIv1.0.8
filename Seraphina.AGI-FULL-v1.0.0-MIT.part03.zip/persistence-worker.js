// persistence-worker.js
// Asynchronous persistence + deterministic pseudo-CID hashing
const { parentPort } = require('worker_threads');
const fs = require('fs');
const crypto = require('crypto');

// Optional dynamic requires (guarded)
let ipfsClientFactory = null;
let Web3StorageClient = null;
let arweave = null;
try { ipfsClientFactory = require('ipfs-http-client'); } catch(_){}
try { Web3StorageClient = (require('web3.storage').Web3Storage) || require('web3.storage'); } catch(_){}
try { const Arweave = require('arweave'); arweave = Arweave.init({ host:'arweave.net', port:443, protocol:'https'}); } catch(_){ }

function pseudoCid(obj) {
  // Deterministic pseudo CID (not real IPFS CID) used for audit binding when async persisted
  const h = crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex');
  return 'cid-' + h.slice(0,46); // mimic length
}

async function offloadIpfs(batch, opts){
  if (!ipfsClientFactory || !opts || !opts.ipfsEndpoint) throw new Error('IPFS not available');
  const endpoint = opts.ipfsEndpoint;
  let client;
  if (endpoint.startsWith('http')){
    const url = new URL(endpoint);
    client = ipfsClientFactory.create({ host: url.hostname, port: url.port || 5001, protocol: url.protocol.replace(':','') });
  } else {
    client = ipfsClientFactory.create({ url: endpoint });
  }
  const buf = Buffer.from(JSON.stringify({ t: Date.now(), batch }));
  const added = await client.add(buf, { pin:true });
  return added.cid.toString();
}

async function offloadFilecoin(batch){
  if (!Web3StorageClient || !process.env.WEB3_STORAGE_TOKEN) throw new Error('Filecoin not available');
  const client = new Web3StorageClient({ token: process.env.WEB3_STORAGE_TOKEN });
  const fileName = `crystals-${Date.now()}.json`;
  const file = new (class FakeFile { constructor(buf,name){ this.buf=buf; this.name=name; this.size=buf.length; this.type='application/json'; } stream(){ const {Readable}=require('stream'); return Readable.from(this.buf);} arrayBuffer(){ return Promise.resolve(this.buf);} text(){ return Promise.resolve(this.buf.toString()); } get [Symbol.toStringTag](){ return 'File'; } })(Buffer.from(JSON.stringify(batch)), fileName);
  return await client.put([file], { name:fileName });
}

async function offloadArweave(batch){
  if (!arweave || !process.env.ARWEAVE_WALLET_JSON) throw new Error('Arweave not available');
  const walletPath = process.env.ARWEAVE_WALLET_JSON;
  if (!fs.existsSync(walletPath)) throw new Error('Arweave wallet missing');
  const walletKey = JSON.parse(fs.readFileSync(walletPath,'utf8'));
  const tx = await arweave.createTransaction({ data: JSON.stringify(batch) }, walletKey);
  await arweave.transactions.sign(tx, walletKey);
  const res = await arweave.transactions.post(tx);
  if (res.status && res.status >= 400) throw new Error('Arweave post failed '+res.status);
  return tx.id;
}

parentPort.on('message', async (msg) => {
  if (msg.type === 'CRYSTALS_BATCH') {
    try {
      const record = { t: Date.now(), crystals: msg.batch };
      let finalCid = null; let kind = 'pseudo';
      const backends = (msg.backends)||{};
      // Try IPFS
      if (backends.ipfs && !finalCid){
        try { finalCid = await offloadIpfs(msg.batch, msg.opts); kind='ipfs'; } catch(e){ /* fallthrough */ }
      }
      // Try Filecoin
      if (backends.filecoin && !finalCid){
        try { finalCid = await offloadFilecoin(msg.batch); kind='filecoin'; } catch(e){ }
      }
      // Try Arweave
      if (backends.arweave && !finalCid){
        try { finalCid = await offloadArweave(msg.batch); kind='arweave'; } catch(e){ }
      }
      if (!finalCid){ finalCid = pseudoCid(record); }
      fs.appendFileSync(msg.path || 'crystal-async-ring.jsonl', JSON.stringify({ cid: finalCid, kind, count: msg.batch.length, t: record.t }) + '\n');
      parentPort.postMessage({ type: 'PERSIST_OK', cid: finalCid, count: msg.batch.length, kind });
    } catch (e) {
      parentPort.postMessage({ type: 'PERSIST_ERR', error: e.message });
    }
  } else if (msg.type === 'STOP') {
    process.exit(0);
  }
});
