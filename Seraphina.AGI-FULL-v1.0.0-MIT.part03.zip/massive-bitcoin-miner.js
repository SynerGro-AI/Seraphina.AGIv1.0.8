// REAL_ONLY_NEUTRALIZED: massive-bitcoin-miner.js
'use strict';
const path = require('path');
const REAL_MINERS = [
  'proper-antminer-mining.js',
  'zero-simulation-real-miner.js'
];

function locateRealMiner() {
  for (const rel of REAL_MINERS) {
    const p = path.join(__dirname, rel);
    try { require.resolve(p); return p; } catch (_) {}
  }
  throw new Error('No real miner module found among: ' + REAL_MINERS.join(', '));
}

module.exports = {
  launchReal(options = {}) {
    const minerPath = locateRealMiner();
    const mod = require(minerPath);
    const entry = mod.ProperAntminerMiningProgram || mod.ZeroSimulationRealMiner || mod.default || null;
    if (!entry) throw new Error('Real miner entry point not found in ' + minerPath);
    const instance = new entry(options);
    if (instance.connectToF2PoolStratum) instance.connectToF2PoolStratum();
    else if (instance.connectToRealF2Pool) instance.connectToRealF2Pool();
    else if (instance.startNeuralMiningPipeline) instance.startNeuralMiningPipeline();
    else if (typeof instance.start === 'function') instance.start();
    return instance;
  }
};

if (require.main === module) {
  if (process.env.REAL_MODE === '1') {
    console.log('[REAL] Delegating to canonical miner from massive-bitcoin-miner wrapper');
    module.exports.launchReal();
  } else {
    console.error('Direct execution disabled. Set REAL_MODE=1 to delegate to a real miner.');
    process.exit(1);
  }
}