// price-oracle.js
// Deterministic-friendly price oracle scaffold with pluggable fetchers.
// Avoids direct network calls unless PRICE_ORACLE_LIVE=1; otherwise produces
// pseudo prices derived from SHA256(seed+symbol) for deterministic dev.

'use strict';
const crypto = require('crypto');

const DEFAULT_SYMBOLS = ['BTC','RVN','FREN','LTC','KAS','USDT'];

async function fetchLive(symbol){
  // Placeholder: integrate real exchange APIs (Kraken, Binance, Coinbase) with REST.
  // For now throw to fallback unless explicitly allowed.
  throw new Error('live-fetch-not-implemented:'+symbol);
}

function pseudoPrice(symbol, seed){
  const h = crypto.createHash('sha256').update((seed||'seed')+symbol).digest();
  // Map first 4 bytes to a price range; each symbol gets stable pseudo-rate per seed run.
  const val = h.readUInt32BE(0);
  // Scale differently for categories
  let base;
  if (/BTC/i.test(symbol)) base = 20000 + (val % 30000); // 20k - 50k
  else if (/RVN|FREN|KAS/i.test(symbol)) base = 0.005 + ((val % 100000)/1000000); // 0.005 - 0.105 approx
  else if (/LTC/i.test(symbol)) base = 50 + (val % 150); // 50 - 200
  else if (/USDT/i.test(symbol)) base = 1.0; else base = 10 + (val % 1000)/10;
  return Number(base.toFixed(8));
}

async function getPrices(opts={}){
  const { symbols = DEFAULT_SYMBOLS, seed = 'aurrelia', live = process.env.PRICE_ORACLE_LIVE==='1' } = opts;
  const out = {};
  for (const s of symbols){
    if (live){
      try { out[s] = await fetchLive(s); continue; } catch(e){ /* fallback */ }
    }
    out[s] = pseudoPrice(s, seed);
  }
  return out;
}

function bestMiningTarget(prices, hashRates, difficultyHints){
  // Simplistic revenue proxy: price * (hashRate / difficulty)
  let best=null; let bestScore=-1;
  for (const sym of Object.keys(prices)){
    const hr = hashRates[sym] || 0;
    const diff = difficultyHints[sym] || 1;
    const score = prices[sym] * (hr / diff);
    if (score > bestScore){ bestScore = score; best = { coin: sym, score }; }
  }
  return best;
}

module.exports = { getPrices, bestMiningTarget };
