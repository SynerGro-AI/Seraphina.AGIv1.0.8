"use strict";
// mining-core.js – simple adaptive prune aware mining loop for single worker
// Uses current pipeline.job; if absent, waits.
// Exports: startMining(pipeline)

const crypto = require('crypto');
const { buildPlaneSeeds } = require('./geometry-octo.js');
const { doubleSha256 } = require('./hash-strategies.js');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
let _cfgDet;
try { _cfgDet = require('./deterministic-config.js'); }
catch(_){ _cfgDet = { SKIP_VAR_THRESH:0.90, SKIP_EMA_ALPHA:0.90, RANK_BUCKET_EDGES:[0.8,0.9,1.0,1.1,1.2,1.3], CHERN_VAR_ALPHA:0.85, CHERN_ALERT:0.02 }; }
const { SKIP_VAR_THRESH, SKIP_EMA_ALPHA, RANK_BUCKET_EDGES, CHERN_VAR_ALPHA, CHERN_ALERT } = _cfgDet;
let coralAdvisor;
try { coralAdvisor = require('./coral-advisor.js'); }
catch(_){ coralAdvisor = { advise: async(feats)=>({ digest: require('crypto').createHash('sha256').update(JSON.stringify(feats)).digest('hex').slice(0,8), deltaPrune:0 }) }; }
// Optional hypercube rank integration
let generateHypercube = null; try { ({ generateHypercube } = require('./hypercube-48d.js')); } catch(_){ /* optional */ }
let promClient=null; try { promClient = require('prom-client'); } catch(_){ }
let hbusCluster=null; try { hbusCluster = require('./hbus-cluster.js'); } catch(_){ }

function nbitsToTarget(nbits){
  const n = parseInt(nbits,16); const exp = n >>> 24; const mant = n & 0xffffff; return BigInt(mant) << (8n*(BigInt(exp)-3n));
}

function startMining(p){
  if (!p) return;
  if (p._miningStarted) return; p._miningStarted=true;
  p.currentEx2 = 0;
  // External GPU hasher integration (optional)
  let gpuProc=null; let gpuProto='stdin-json'; let gpuReady=false; let gpuLineBuf='';
  let _gpuCmdParts=null; let _gpuLastRestart=0; p._gpuLastShareTs=Date.now();
  const GPU_IDLE_MS = parseInt(process.env.GPU_HASHER_IDLE_MS || '90000',10);
  const GPU_MIN_UPTIME_MS = parseInt(process.env.GPU_HASHER_MIN_UPTIME_MS || '10000',10);
  const GPU_RESTART_BACKOFF_MS = parseInt(process.env.GPU_HASHER_RESTART_BACKOFF_MS || '5000',10);
  function spawnGpu(){
    if (!process.env.GPU_HASHER_CMD) return;
    try {
      _gpuCmdParts = process.env.GPU_HASHER_CMD.split(/\s+/);
      gpuProto = process.env.GPU_HASHER_PROTO || 'stdin-json';
      gpuProc = spawn(_gpuCmdParts[0], _gpuCmdParts.slice(1), { stdio:['pipe','pipe','pipe'] });
      gpuReady=false; gpuLineBuf='';
      p._gpuSpawnTs = Date.now();
      console.log('[GPU] Spawned external hasher:', process.env.GPU_HASHER_CMD);
      gpuProc.stdout.on('data', d=>{
        gpuLineBuf += d.toString();
        let idx; while((idx = gpuLineBuf.indexOf('\n'))>=0){
          const line = gpuLineBuf.slice(0,idx); gpuLineBuf = gpuLineBuf.slice(idx+1);
          if (!line.trim()) continue;
          if (gpuProto==='stdin-json'){
            try {
              const msg = JSON.parse(line);
              if (msg.type==='ready'){ gpuReady=true; }
              else if (msg.type==='share' && msg.jobId && msg.ex2 && msg.ntime && msg.nonce){
                p._gpuLastShareTs = Date.now();
                if (p.job && p.job.jobId === msg.jobId){
                  try { p.stratum && p.stratum.submitShare({ jobId: msg.jobId, extranonce2: msg.ex2, ntime: msg.ntime, nonce: msg.nonce, mixHash: msg.mixHash }); p.stats.sharesGPU = (p.stats.sharesGPU||0)+1; } catch(_){ }
                }
              } else if (msg.type==='difficulty' && msg.target){
                // Streaming difficulty / target feedback from external miner (optional future use)
                p._gpuSuggestedTarget = msg.target; // hex target string (BigInt parse later if needed)
              }
            } catch(e){ console.warn('[GPU] Bad JSON line', e.message); }
          }
        }
      });
      gpuProc.stderr.on('data', d=>{ const s=d.toString(); if (/error/i.test(s)) console.warn('[GPU][stderr]', s.trim()); });
      gpuProc.on('exit', (c)=>{ console.warn('[GPU] process exited code', c); gpuProc=null; });
    } catch(e){ console.warn('[GPU] spawn failed', e.message); }
  }
  function restartGpu(reason){
    if (!gpuProc || !_gpuCmdParts) return;
    const now = Date.now();
    if (now - _gpuLastRestart < GPU_RESTART_BACKOFF_MS) return; // backoff
    _gpuLastRestart = now;
    console.warn('[GPU][Watchdog] Restarting external hasher:', reason);
    try { gpuProc.kill(); } catch(_){ }
    setTimeout(()=>{ spawnGpu(); }, 1000).unref();
  }
  if (process.env.GPU_HASHER_CMD){ spawnGpu(); }
  if (process.env.GPU_HASHER_WATCHDOG !== '0'){
    setInterval(()=>{
      if (!gpuProc) return;
      // Idle if ready + has job + no shares for idle window and has been up longer than min uptime
      if (gpuReady && p.job && (Date.now()-p._gpuLastShareTs > GPU_IDLE_MS) && (Date.now()-p._gpuSpawnTs > GPU_MIN_UPTIME_MS)){
        restartGpu('idle_timeout');
      }
    }, Math.min(GPU_IDLE_MS/2, 15000)).unref();
  }
  // Hypercube state
  let hc = null; let lastHcJob=null; let lastHcTs=0;
  const hcIntervalMs = parseInt(process.env.HC_REFRESH_MS || '15000',10);
  // Metrics gauges (guard against duplicate registration)
  let gauges = null;
  if (promClient && process.env.METRICS==='1'){
    try {
      const reg = promClient.register;
      gauges = {
        rankProxy: reg.getSingleMetric('aurrelia_rank_proxy') || new promClient.Gauge({ name:'aurrelia_rank_proxy', help:'Hypercube rank proxy (1-corr residual)' }),
        signVar: reg.getSingleMetric('aurrelia_sign_variance') || new promClient.Gauge({ name:'aurrelia_sign_variance', help:'Hypercube sign variance' }),
        pruneThrEff: reg.getSingleMetric('aurrelia_prune_threshold_effective') || new promClient.Gauge({ name:'aurrelia_prune_threshold_effective', help:'Adaptive prune threshold after rank modulation' }),
        skipRate: reg.getSingleMetric('aurrelia_nonce_skip_rate') || new promClient.Gauge({ name:'aurrelia_nonce_skip_rate', help:'EMA of nonce skip rate due to low sign variance' }),
        realShares: reg.getSingleMetric('aurrelia_real_shares_total') || new promClient.Counter({ name:'aurrelia_real_shares_total', help:'Shares meeting actual target (non-simulated)' }),
        simulatedShares: reg.getSingleMetric('aurrelia_simulated_shares_total') || new promClient.Counter({ name:'aurrelia_simulated_shares_total', help:'Shares accepted only via DEBUG_EASY_TARGET prefix simulation' }),
        gpuShares: reg.getSingleMetric('aurrelia_gpu_shares_total') || new promClient.Counter({ name:'aurrelia_gpu_shares_total', help:'Shares submitted originating from external GPU process' }),
        shareAcceptRatio: reg.getSingleMetric('aurrelia_share_accept_ratio') || new promClient.Gauge({ name:'aurrelia_share_accept_ratio', help:'Accepted / Submitted ratio (approx from real shares vs total candidates submitted)' })
      };
      // Histograms (bucket edges inclusive, final +Inf)
  // Keep mutable copies for dynamic extension
  p._rankBuckets = Array.isArray(RANK_BUCKET_EDGES) ? [...RANK_BUCKET_EDGES] : [0.8,0.9,1.0,1.1,1.2,1.3];
  gauges.rankProxyHist = reg.getSingleMetric('aurrelia_rank_proxy_hist') || new promClient.Histogram({ name:'aurrelia_rank_proxy_hist', help:'Rank proxy distribution', buckets:p._rankBuckets });
  gauges.signVarHist = reg.getSingleMetric('aurrelia_sign_variance_hist') || new promClient.Histogram({ name:'aurrelia_sign_variance_hist', help:'Sign variance distribution', buckets:p._rankBuckets });
      gauges.chernVar = reg.getSingleMetric('aurrelia_chern_proxy_var') || new promClient.Gauge({ name:'aurrelia_chern_proxy_var', help:'Rolling variance (EWMA) of rankProxy' });
  gauges.hbusDamp = reg.getSingleMetric('aurrelia_hbus_damp_factor') || new promClient.Gauge({ name:'aurrelia_hbus_damp_factor', help:'Cluster harmonic damp factor (1=none)' });
  gauges.rankProxyP95 = reg.getSingleMetric('aurrelia_rank_proxy_p95') || new promClient.Gauge({ name:'aurrelia_rank_proxy_p95', help:'Approx P95 of recent rankProxy samples' });
  gauges.rankProxyOverflow = reg.getSingleMetric('aurrelia_rank_proxy_overflow_ratio') || new promClient.Gauge({ name:'aurrelia_rank_proxy_overflow_ratio', help:'Fraction samples above last bucket edge' });
  gauges.rankBucketExtend = reg.getSingleMetric('aurrelia_rank_bucket_extend_recommend') || new promClient.Gauge({ name:'aurrelia_rank_bucket_extend_recommend', help:'1 if P95 exceeds last bucket edge' });
    } catch(_){ gauges=null; }
  }
  if (process.env.WORKER_CHILD === '1'){
    process.on('message', msg=>{
      if (msg && msg.type==='PRUNE_GUIDANCE' && p.adaptivePrune){
        // Blend controller guidance into local threshold (light smoothing)
        const g = msg.threshold;
        p.adaptivePrune.state.threshold = (p.adaptivePrune.state.threshold*3 + g)/4;
      }
    });
  }
  function tick(){
  if (!p.job || !p.extranonce1){ setTimeout(tick,500); return; }
    const job = p.job;
    // Forward job to GPU hasher once per new job
    if (gpuProc && gpuProto==='stdin-json' && !p._lastGpuJobIdSent || p._lastGpuJobIdSent !== job.jobId){
      try {
        const jobMsg = { type:'job', jobId: job.jobId, nbits: job.nbits, ntime: job.ntime, prevhash: job.prevhash, merkle: job.merkleBranches || job.merkle_branch || [], extranonce1: p.extranonce1, ex2Size: job.extranonce2Size||8 };
        gpuProc.stdin.write(JSON.stringify(jobMsg)+'\n');
        p._lastGpuJobIdSent = job.jobId;
      } catch(_){ }
    }
    // Build plane seeds once per cycle (cache)
    if (!p._planeCache || p._planeCacheJobId !== job.jobId){ p._planeCache = buildPlaneSeeds(job, p.extranonce1); p._planeCacheJobId = job.jobId; }
    // Refresh / generate hypercube metrics deterministically per job or interval
    if (generateHypercube && ((lastHcJob !== job.jobId) || (Date.now() - lastHcTs > hcIntervalMs))){
      try {
  hc = generateHypercube(job, { extranonce1: p.extranonce1, count: 256 });
        lastHcJob = job.jobId; lastHcTs = Date.now();
        if (gauges){
          gauges.rankProxy.set(hc.rankProxy); gauges.signVar.set(hc.signVar);
          gauges.rankProxyHist && gauges.rankProxyHist.observe(hc.rankProxy);
            gauges.signVarHist && gauges.signVarHist.observe(hc.signVar);
        }
        // Collect for P95 / overflow analytics
        p._rankSamples = p._rankSamples || [];
        p._rankSamples.push(hc.rankProxy);
        if (p._rankSamples.length > 240) p._rankSamples.shift();
        if (gauges && p._rankSamples.length > 20){
          const sorted=[...p._rankSamples].sort((a,b)=>a-b);
          const p95 = sorted[Math.min(sorted.length-1, Math.max(0, Math.floor(sorted.length*0.95)-1))];
          const lastEdge = (p._rankBuckets||RANK_BUCKET_EDGES)[(p._rankBuckets||RANK_BUCKET_EDGES).length-1];
          const overflow = p._rankSamples.filter(v=>v>lastEdge).length / p._rankSamples.length;
          gauges.rankProxyP95.set(p95);
          gauges.rankProxyOverflow.set(overflow);
          gauges.rankBucketExtend.set(p95 > lastEdge ? 1 : 0);
          // Dynamic bucket extension (deterministic given observed sequences). Extend when p95 > lastEdge * 1.01 AND overflow > 0.02
          if (p95 > lastEdge*1.01 && overflow > 0.02 && !p._rankBucketLock){
            p._rankBucketLock = true;
            const newEdge = parseFloat((Math.ceil(p95*100)/100).toFixed(2));
            if (newEdge > lastEdge){
              try {
                // Persist extended edge list
                p._rankBuckets.push(newEdge);
                fs.writeFileSync(path.join(process.cwd(),'rank-buckets.json'), JSON.stringify(p._rankBuckets));
                if (promClient){
                  const reg = promClient.register;
                  // remove and recreate histograms with new buckets
                  try { reg.removeSingleMetric('aurrelia_rank_proxy_hist'); } catch(_){ }
                  try { reg.removeSingleMetric('aurrelia_sign_variance_hist'); } catch(_){ }
                  gauges.rankProxyHist = new promClient.Histogram({ name:'aurrelia_rank_proxy_hist', help:'Rank proxy distribution', buckets:p._rankBuckets });
                  gauges.signVarHist = new promClient.Histogram({ name:'aurrelia_sign_variance_hist', help:'Sign variance distribution', buckets:p._rankBuckets });
                  console.log('[BUCKET] extended rank buckets ->', p._rankBuckets.join(','));
                }
              } catch(e){ console.warn('[BUCKET] extension failed', e.message); }
            }
            setTimeout(()=>{ p._rankBucketLock=false; }, 10_000).unref();
          }
        }
      } catch(e){ /* ignore */ }
    }
    let target = nbitsToTarget(job.nbits||'ffffffff');
    // DEBUG_EASY_TARGET: inflate target (make it easier) for local functional testing
    // Modes:
    //  - Integer (e.g. 24): bit shift left by that many bits (cap applied)
    //  - '1': default shift 32
    //  - 'mul:<float>': multiply target by float factor
    //  - 'prefix:<hex>' enables simulated share acceptance when digest starts with prefix (no real target change)
    if (process.env.DEBUG_EASY_TARGET){
      const val = process.env.DEBUG_EASY_TARGET;
      let modeLogged=false;
      const maxShift = parseInt(process.env.DEBUG_EASY_TARGET_MAX_SHIFT || '160',10);
      if (/^mul:/i.test(val)){
        const f = parseFloat(val.split(':')[1]);
        if (!isNaN(f) && f>1){
          try { target = target * BigInt(Math.floor(f)); modeLogged=true; console.warn(`[DEBUG] EASY_TARGET mul factor ${f} applied`); } catch(_){ }
        }
      } else if (/^prefix:/i.test(val)){
        p._debugSharePrefix = val.split(':')[1]||'0000';
        modeLogged=true; if (!p._loggedEasyTarget){ console.warn(`[DEBUG] EASY_TARGET prefix mode active: treating hashes starting with ${p._debugSharePrefix} as shares (local only)`); p._loggedEasyTarget=true; }
      } else {
        const dbg = val === '1' ? 32 : parseInt(val,10);
        if (!isNaN(dbg) && dbg>0){
          const applied = Math.min(dbg, maxShift);
          try { target = target << BigInt(applied); modeLogged=true; if (!p._loggedEasyTarget){ console.warn(`[DEBUG] EASY_TARGET bitshift ${applied} (requested ${dbg}) target inflated`); p._loggedEasyTarget=true; } } catch(_){ }
        }
      }
      if (!modeLogged && !p._loggedEasyTarget){ console.warn('[DEBUG] EASY_TARGET specified but no valid mode parsed'); p._loggedEasyTarget=true; }
    }
    const batch = p.fusedBatch ? p.fusedBatch.stats().batchSize : 64;
    const headers = []; const metas=[];
    // Rank proxy & sign variance modulation of prune threshold & nonce usage
    let rankProxy = (hc && typeof hc.rankProxy==='number') ? hc.rankProxy : 1;
    let signVar = (hc && typeof hc.signVar==='number') ? hc.signVar : 1;
    if (p.adaptivePrune){
      // Ensure bounds exist
      if (typeof p.adaptivePrune.state.min !== 'number') p.adaptivePrune.state.min = 0.2;
      if (typeof p.adaptivePrune.state.max !== 'number') p.adaptivePrune.state.max = 5.0;
    }
    let baseThr = p.adaptivePrune ? p.adaptivePrune.state.threshold : 999;
    const lowTarget = parseFloat(process.env.RANK_PROXY_LOW || '1.00');
    const highTarget = parseFloat(process.env.RANK_PROXY_HIGH || '1.15');
    const thrBeforeAdjust = baseThr;
    if (p.adaptivePrune){
      if (rankProxy < lowTarget){ baseThr = Math.max(p.adaptivePrune.state.min, baseThr - 0.10); }
      else if (rankProxy > highTarget){ baseThr = Math.min(p.adaptivePrune.state.max, baseThr + 0.05); }
      // Econ-aware loosening: if current recommended coin (pipeline.econ?.state.recommend) is Kaspa and rankProxy strong (>1.10)
      try {
        const coinRec = p.econ && p.econ.state && p.econ.state.recommend;
        if (coinRec === 'kas' && rankProxy > parseFloat(process.env.RANK_PROXY_KAS_LOOSEN_MIN || '1.10')){
          const delta = parseFloat(process.env.RANK_PROXY_KAS_LOOSEN_DELTA || '0.10');
          baseThr = Math.min(p.adaptivePrune.state.max, baseThr + delta);
        }
      } catch(_){ }
      // Apply cluster damp bias: damp only positive loosening deltas
      const grossDelta = baseThr - thrBeforeAdjust;
      if (grossDelta > 0 && p._lastHbusDamp && p._lastHbusDamp < 1){
        baseThr = thrBeforeAdjust + grossDelta * p._lastHbusDamp;
      }
      // Persist updated threshold to feed controller smoothing & persistence
      p.adaptivePrune.state.threshold = baseThr;
    }
    const effectiveThreshold = baseThr;
    const skipEvery = signVar < SKIP_VAR_THRESH ? 2 : 1; // configurable skip
    if (gauges && p.adaptivePrune){ gauges.pruneThrEff.set(effectiveThreshold); }
    let skipped=0, accepted=0;
    // Optional extranonce bias via wheel aggregate (stable deterministic XOR / LCG blend)
    let wheelAgg = null;
    try {
      const w = (global.__AUR_LANGUAGE_ENGINE__ && global.__AUR_LANGUAGE_ENGINE__.wheelCoder && global.__AUR_LANGUAGE_ENGINE__.wheelCoder._lastEncoded) || null;
      if (w && typeof w.aggregate === 'number') wheelAgg = w.aggregate >>> 0;
    } catch(_wa){}
  // Bias mode may be dynamically adjusted by adaptive controller (global override)
  const biasMode = (global.__AUR_ADAPTIVE_BIAS_MODE) || process.env.AUR_WHEEL_EXTRANONCE_BIAS || 'xor';
    for (let i=0;i<batch;i++){
      let ex2Raw = (p.currentEx2++ & 0xffffffff);
      if (wheelAgg != null){
        if (biasMode === 'xor') ex2Raw = ex2Raw ^ (wheelAgg & 0xffffffff);
        else if (biasMode === 'add') ex2Raw = (ex2Raw + (wheelAgg & 0xffff)) & 0xffffffff;
        else if (biasMode === 'mix') {
          ex2Raw = (ex2Raw ^ ((wheelAgg>>>1) & 0x7fffffff)) + ((wheelAgg & 0xffff) << 1);
          ex2Raw = ex2Raw >>> 0;
        }
      }
      const ex2 = ex2Raw >>> 0; const ex2Hex = ex2.toString(16).padStart((job.extranonce2Size||8)*2,'0');
      const coinbaseTx = (job.coinb1||job.part1||'') + p.extranonce1 + ex2Hex + (job.coinb2||job.part2||'');
      let merkle = doubleSha256(coinbaseTx);
  const branches = job.merkleBranches || job.merkle_branch || [];
  for (const b of branches) merkle = doubleSha256(merkle + b);
      const nTime = (parseInt(job.ntime,16) + i).toString(16).padStart(8,'0');
      const headerHex = buildHeader(job, merkle, nTime, job.nonce || '00000000');
      // Norm heuristic: use first plane seed xor digest entropy to approximate geometry norm
      const seed = p._planeCache.planeSeeds[ i % p._planeCache.planeSeeds.length ];
      const norm = approxNorm(seed, headerHex);
      const thr = effectiveThreshold;
      const ok = norm <= thr;
      if (process.env.DEBUG_NONCE_LOG==='1'){
        const freq = parseInt(process.env.DEBUG_NONCE_FREQ||'500',10);
        if ((p.stats.hashes + i) % freq === 0){
          console.log(`[NonceLoop] ex2=${ex2Hex} nTime=${nTime} norm=${norm.toFixed(3)} thr=${thr.toFixed?thr.toFixed(3):thr} ok=${ok} rankProxy=${rankProxy?.toFixed?rankProxy.toFixed(3):rankProxy} signVar=${signVar?.toFixed?signVar.toFixed(3):signVar}`);
        }
      }
      p.adaptivePrune && p.adaptivePrune.record(norm, ok);
      if (process.env.WORKER_CHILD==='1' && !(p.stats.hashes % 97)){
        try { process.send && process.send({ type:'PRUNE_SAMPLE', norm, ok }); } catch(_){ }
      }
      if (ok){
  if (skipEvery > 1 && (i % skipEvery) !== 0){ skipped++; } else { headers.push(headerHex); metas.push({ ex2Hex, nTime, nonceHex: job.nonce||'00000000', target, norm, rankProxy, signVar, ok }); accepted++; }
      }
    }
    // Skip rate EMA
    if (!p._skipRateEMA) p._skipRateEMA = 0;
    const batchSkipRate = (skipped + accepted) ? (skipped / (skipped + accepted)) : 0;
    const alpha = SKIP_EMA_ALPHA; // heavy smoothing configurable
    p._skipRateEMA = p._skipRateEMA*alpha + batchSkipRate*(1-alpha);
    if (gauges){ gauges.skipRate.set(p._skipRateEMA); }
  // Chern proxy variance (EWMA of squared deviation) to detect turbulence
  if (!p._chern){ p._chern = { mean: rankProxy, var:0 }; }
  const dev = rankProxy - p._chern.mean;
  p._chern.mean = p._chern.mean*CHERN_VAR_ALPHA + rankProxy*(1-CHERN_VAR_ALPHA);
  p._chern.var = p._chern.var*CHERN_VAR_ALPHA + (dev*dev)*(1-CHERN_VAR_ALPHA);
    if (gauges){ gauges.chernVar.set(p._chern.var); }
    if (p._chern.var > CHERN_ALERT && !(p._chern._lastAlertTs && Date.now()-p._chern._lastAlertTs<60000)){
      p._chern._lastAlertTs = Date.now();
      console.warn(`[CHERN] turbulence var=${p._chern.var.toFixed(5)} > alert=${CHERN_ALERT}`);
    }
  // HBUS damp logic (cluster aware)
  let hbusDamp = 1.0;
  if (hbusCluster){
    try { hbusDamp = hbusCluster.getDampFactor(p._chern.mean); } catch(_){ }
  } else if (p._chern.mean < 1.05){ hbusDamp = 0.97; }
  p._lastHbusDamp = hbusDamp;
  if (gauges){ gauges.hbusDamp.set(hbusDamp); }
    // Persist ring log on hypercube refresh cycle
    if (lastHcTs && (Date.now() - lastHcTs) < 100){
      try {
  const deltaPrune = baseThr - thrBeforeAdjust;
  const kasDelta = (p.econ && p.econ.state && p.econ.state.recommend==='kas') ? 1 : 0;
  const line = JSON.stringify({ t: Date.now(), proxy: rankProxy, signVar, deltaPrune: +deltaPrune.toFixed(4), skipPct: +(batchSkipRate*100).toFixed(2), kasDelta, chernVar:+p._chern.var.toFixed(5) }) + '\n';
        const file = path.join(process.cwd(), 'rule-stats-ring.jsonl');
        fs.appendFileSync(file, line);
        // crude ring trim: if file > 1.2MB trim last 500 lines
        const maxBytes = parseInt(process.env.RULE_RING_MAX_BYTES || '1200000',10);
        const st = fs.statSync(file);
        if (st.size > maxBytes){
          const data = fs.readFileSync(file,'utf8').trim().split(/\n/);
            const trimmed = data.slice(-500).join('\n') + '\n';
            fs.writeFileSync(file, trimmed);
        }
      } catch(_){ }
    }
    if (p.adaptivePrune) p.adaptivePrune.maybeAdjust();
    // Coral advisory (non-blocking) with provenance
    if (process.env.ML_CORAL==='1'){
      const feat = { rankProxy, signVar, skipEma:p._skipRateEMA, pruneThr: p.adaptivePrune ? p.adaptivePrune.state.threshold : null, chernVar:p._chern?.var, acceptRatio: p.shareStats ? p.shareStats.acceptanceRatio : null };
      coralAdvisor.advise(feat).then(r=>{
        if (!r) return;
        if (typeof r.deltaPrune==='number' && p.adaptivePrune){
          const before = p.adaptivePrune.state.threshold;
          const bounded = Math.min(p.adaptivePrune.state.max, Math.max(p.adaptivePrune.state.min, before + r.deltaPrune));
          p.adaptivePrune.state.threshold = bounded;
          p._lastCoralDelta = r.deltaPrune; p._lastCoralProv='coral';
        }
      }).catch(()=>{});
    }
    // Persist ring log after advisory if hypercube freshly updated
    if (lastHcTs && (Date.now() - lastHcTs) < 100){
      try {
        const deltaPrune = baseThr - thrBeforeAdjust;
        const kasDelta = (p.econ && p.econ.state && p.econ.state.recommend==='kas') ? 1 : 0;
  const line = JSON.stringify({ t:Date.now(), proxy:rankProxy, signVar, deltaPrune:+deltaPrune.toFixed(4), skipPct:+(batchSkipRate*100).toFixed(2), kasDelta, chernVar:+p._chern.var.toFixed(5), coralDelta:+(p._lastCoralDelta||0).toFixed(4), prov: p._lastCoralProv||'internal', accept:p.shareStats ? +p.shareStats.acceptanceRatio.toFixed(4):null })+'\n';
        const file = path.join(process.cwd(), 'rule-stats-ring.jsonl');
        fs.appendFileSync(file, line);
        const maxBytes = parseInt(process.env.RULE_RING_MAX_BYTES || '1200000',10);
        const st = fs.statSync(file);
        if (st.size > maxBytes){ const data=fs.readFileSync(file,'utf8').trim().split(/\n/); fs.writeFileSync(file, data.slice(-500).join('\n')+'\n'); }
        p._lastCoralDelta=0; p._lastCoralProv='internal';
      } catch(_){ }
    }
    if (headers.length){
      if (p.fusedBatch && p.hashStrategy.id === 'sha256d'){
        p.fusedBatch.hashBatch(headers).then(digests=> processDigests(digests, metas));
      } else {
        const digests = headers.map(h=> p.hashStrategy.hashHeader(h));
        processDigests(digests, metas);
      }
    }
    setImmediate(tick);
  }
  const ledgerChain = require('./ledger-hmac-chain.js');
  const shareLedgerFile = process.env.SHARE_LEDGER_PATH || 'share-ledger.jsonl';
  function processDigests(digests, metas){
    const shareCorrSample = parseInt(process.env.SHARE_CORR_SAMPLE || '32',10);
    for (let i=0;i<digests.length;i++){
      const d = digests[i]; const m = metas[i];
  const hashInt = BigInt('0x'+ reverseBytes(d));
  let isRealShare = hashInt <= m.target;
  let isSimulatedShare = false;
  // Simulated prefix mode share acceptance (local only)
  if (!isRealShare && p._debugSharePrefix && d.startsWith(p._debugSharePrefix)){
    isSimulatedShare = true;
  }
      if (isRealShare || isSimulatedShare){
        try { p.stratum && p.stratum.submitShare({ jobId: p.job.jobId, extranonce2: m.ex2Hex, ntime: m.nTime, nonce: m.nonceHex }); } catch(_){ }
        // Append chained ledger record (deterministic fields only)
        try {
          ledgerChain.append(shareLedgerFile, {
            t: Date.now(),
            jobId: p.job.jobId,
            coin: p.job.coin || 'BTC',
            ex2: m.ex2Hex,
            ntime: m.nTime,
            nonce: m.nonceHex,
            real: isRealShare?1:0,
            sim: isSimulatedShare?1:0,
            norm: m.norm,
            rankProxy: m.rankProxy,
            signVar: m.signVar
          });
        } catch(e){ /* ignore ledger errors */ }
        if (isRealShare){ p.stats.shares = (p.stats.shares||0)+1; if (gauges) gauges.realShares.inc(); }
        else if (isSimulatedShare){ p.stats.simShares = (p.stats.simShares||0)+1; if (gauges) gauges.simulatedShares.inc(); }
        // Update accept ratio (real shares vs total submitted from CPU path; GPU path updates separately)
        if (gauges){
          const real = p.stats.shares||0; const sim = p.stats.simShares||0; const gpu = p.stats.sharesGPU||0;
          const submitted = real + sim + gpu;
          if (submitted>0) gauges.shareAcceptRatio.set(real / submitted);
        }
      }
      p.stats.hashes++;
      if (m && ((p.stats.hashes % shareCorrSample)===0)){
        try {
          const rec={ t:Date.now(), norm:m.norm, proxy:m.rankProxy, signVar:m.signVar, ok:m.ok?1:0, real:isRealShare?1:0, sim:isSimulatedShare?1:0 };
          const file=path.join(process.cwd(),'share-corr-ring.jsonl');
          fs.appendFileSync(file, JSON.stringify(rec)+'\n');
          const maxBytes=parseInt(process.env.SHARE_CORR_MAX_BYTES || '2000000',10);
          const st=fs.statSync(file); if (st.size>maxBytes){ const data=fs.readFileSync(file,'utf8').trim().split(/\n/); fs.writeFileSync(file, data.slice(-800).join('\n')+'\n'); }
        } catch(_){ }
      }
    }
  }
  function reverseBytes(hex){ return hex.match(/.{2}/g).reverse().join(''); }
  function buildHeader(job, merkleRoot, nTime, nonceHex){
    function rev(h){ return h.match(/.{2}/g).reverse().join(''); }
    const ver = rev((job.version||'').padStart(8,'0')); const prev = rev(job.prevhash||''); const merk = rev(merkleRoot); const time = rev(nTime); const bits = rev(job.nbits||''); const nonce = rev(nonceHex);
    return ver+prev+merk+time+bits+nonce;
  }
  function approxNorm(seed, header){
    // Cheap numeric dispersion measure: xor nibble sums vs header entropy
    let sum=0; for (let i=0;i<seed.length;i++){ sum += seed.charCodeAt(i) ^ header.charCodeAt(i % header.length); }
    const norm = (sum % 1000)/200; // 0..5 scale
    return norm;
  }
  tick();
}

module.exports = { startMining };

// Lazy start adaptive bias controller after export to avoid circular requires
try {
  if (process.env.ADAPTIVE_BIAS_ENABLED === '1' && !global.__AUR_ADAPTIVE_BIAS_INIT){
    global.__AUR_ADAPTIVE_BIAS_INIT = true;
    require('./adaptive-bias-controller.js').startAdaptiveBiasController();
  }
} catch(e){ console.warn('[AdaptiveBias] init failed', e.message); }
