// midstate_selftest.js
// Compares JS midstate + full double SHA vs WASM fast path over randomized synthetic headers.

const crypto = require('crypto');
const jsMid = require('./midstate.js');
let wasmMid = null;
let wasmAvailable = false;
try {
  wasmMid = require('./midstate_wasm.js');
  (async ()=>{ try { await wasmMid.initWasm(); wasmAvailable = true; } catch(_){} })();
} catch(_){}

function buildHeaderParts(){
  // 80-byte header = version(4) + prevhash(32) + merkle(32) + time(4) + nBits(4) + nonce(4)
  const version = crypto.randomBytes(4);
  const prev = crypto.randomBytes(32);
  const merkle = crypto.randomBytes(32);
  const time = crypto.randomBytes(4);
  const nBits = crypto.randomBytes(4);
  const nonce = crypto.randomBytes(4);
  const header = Buffer.concat([version, prev, merkle, time, nBits, nonce]);
  return header;
}

function refDoubleSha(buf){
  const h1 = crypto.createHash('sha256').update(buf).digest();
  const h2 = crypto.createHash('sha256').update(h1).digest();
  return h2;
}

async function run(iter=100){
  while(!wasmAvailable && iter>0){ await new Promise(r=>setTimeout(r,10)); iter--; }
  const total = 200;
  let mismatches = 0; let wasmTime=0; let refTime=0;
  let firstMismatch = null;
  for (let i=0;i<total;i++){
    const header = buildHeaderParts();
    const first64 = header.subarray(0,64);
    const tail16 = header.subarray(64,80);
    const t0 = process.hrtime.bigint();
    const ref = refDoubleSha(header);
    refTime += Number(process.hrtime.bigint() - t0);
    let fast=null;
    if (wasmAvailable){
      const w0 = process.hrtime.bigint();
      try { fast = await wasmMid.doubleSha256MidWasm(first64, tail16); } catch(_) { fast = ref; }
      wasmTime += Number(process.hrtime.bigint() - w0);
    } else {
      const m0 = process.hrtime.bigint();
      const d = jsMid.doubleSha256WithMidstate(first64, tail16);
      wasmTime += Number(process.hrtime.bigint() - m0); // treat as fast path for comparison
      fast = d;
    }
    if (!fast.equals(ref)) {
      mismatches++;
      if (!firstMismatch) firstMismatch = { i, header: header.toString('hex'), ref: ref.toString('hex'), fast: fast.toString('hex') };
    }
  }
  const out = { total, mismatches, wasmAvailable, avgRefNs: Math.round(refTime/total), avgFastNs: Math.round(wasmTime/total) };
  if (firstMismatch) out.firstMismatch = firstMismatch;
  console.log(JSON.stringify(out));
  if (mismatches) process.exitCode = 1;
}

run();