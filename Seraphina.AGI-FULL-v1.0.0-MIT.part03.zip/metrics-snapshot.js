#!/usr/bin/env node
// metrics-snapshot.js – compact metrics export (selected gauges/counters)
// Usage: node metrics-snapshot.js [--out=file.json]
// Reads in-process prom-client registry if available; otherwise tries HTTP /metrics if METRICS_PORT set.

const fs = require('fs');
const http = require('http');

async function scrapeHttp(port){
  return new Promise(res=>{
    const req = http.get({ host:'127.0.0.1', port, path:'/metrics', timeout: 2000 }, r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=>res(d)); });
    req.on('error',()=>res(null));
  });
}

async function main(){
  let snapshot={ ts: Date.now() };
  let prom=null; try { prom=require('prom-client'); } catch(_){ }
  if (prom){
    try {
      const metrics = await prom.register.getMetricsAsJSON();
      const pick = ['aurrelia_rank_proxy','aurrelia_sign_variance','aurrelia_prune_threshold_effective','aurrelia_nonce_skip_rate','aurrelia_chern_proxy_var','aurrelia_hbus_damp_factor','aurrelia_share_accept_ratio'];
      for (const m of metrics){ if (pick.includes(m.name)){ snapshot[m.name] = m.type==='counter'? (m.values?.reduce((a,v)=>a+v.value,0)) : m.values?.[0]?.value; } }
    } catch(e){ }
  } else if (process.env.METRICS_PORT){
    const raw = await scrapeHttp(parseInt(process.env.METRICS_PORT,10));
    if (raw){
      // crude parse: lines name value
      raw.split(/\n/).forEach(line=>{
        const m = line.match(/^([a-zA-Z0-9_]+) ([-0-9\.eE]+)$/); if (m) snapshot[m[1]] = parseFloat(m[2]);
      });
    }
  }
  const outArg = process.argv.find(a=>a.startsWith('--out='));
  const outFile = outArg ? outArg.split('=')[1] : null;
  if (outFile){ try { fs.writeFileSync(outFile, JSON.stringify(snapshot,null,2)); } catch(e){ console.error('write failed', e.message); } }
  console.log(JSON.stringify(snapshot));
}

if (require.main === module){ main(); }