#!/usr/bin/env bash
# Prepare autoinstall layout (nocloud) and copy miner workspace for custom ISO.
set -euo pipefail
ISO=${1:-ubuntu-22.04.4-live-server-amd64.iso}
MINER_SRC=${2:-$(pwd)}
WORK=iso-work
EXTRACT=iso-extract
mkdir -p "$WORK" "$EXTRACT"
cp "$ISO" "$WORK"/
cd "$WORK"
7z x "$ISO" -o"$EXTRACT"
cd "$EXTRACT"
mkdir -p nocloud
cp "$MINER_SRC"/autoinstall-user-data.yaml nocloud/user-data
cat > nocloud/meta-data <<EOF
instance-id: seraphina-miner-01
local-hostname: seraphina-host
EOF
mkdir -p seraphina
rsync -a --exclude node_modules "$MINER_SRC"/ seraphina/mining/
cp "$MINER_SRC"/install-seraphina.sh seraphina/
cp "$MINER_SRC"/artifact-hashes.json seraphina/ 2>/dev/null || true
# Patch boot config
if grep -q 'grub.cfg' ./boot/grub/grub.cfg; then
  sed -i 's/---/ autoinstall ds=nocloud\;s=\/cdrom\/nocloud ---/' ./boot/grub/grub.cfg
fi
if [ -f isolinux/txt.cfg ]; then
  sed -i 's/---/ autoinstall ds=nocloud\;s=\/cdrom\/nocloud ---/' isolinux/txt.cfg || true
fi
cd ..
NEW_ISO=seraphina-ubuntu-autoinstall.iso
xorriso -as mkisofs -r -V "SERAPHINA_AUTOINSTALL" -J -l -iso-level 3 -o "$NEW_ISO" "$EXTRACT"
echo "[BUILD] Created $NEW_ISO"