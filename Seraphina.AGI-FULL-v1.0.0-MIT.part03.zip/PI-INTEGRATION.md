# Raspberry Pi / BigTreeTech Pi Integration Guide

## Overview
Run the deterministic Aurrelia miner on Raspberry Pi-class hardware (including BigTreeTech Pi variants) with integrity, thermal safety, and USB deployment.

## Hardware Requirements
- Raspberry Pi 4 (4GB+) or Pi 5 recommended. BigTreeTech CB1 / Pi expansion acceptable with active cooling.
- Quality USB 3.0 flash (SLC or pseudo-SLC endurance) for portable bundle.
- Stable 5V 3A+ power (avoid brownouts; use official supply or UPS hat).
- Active cooling: heat sinks + fan (PWM controllable for Pi 5 or external MOSFET driver).

## OS & Base Setup
1. Flash latest Raspberry Pi OS Lite (64-bit) or BigTreeTech tuned image.
2. Enable SSH: `sudo raspi-config` → Interface Options.
3. Update & harden:
   ```bash
   sudo apt update && sudo apt full-upgrade -y
   sudo apt install -y git build-essential nodejs npm jq lm-sensors smartmontools
   ```
4. Pin Node version (example 20.x LTS):
   ```bash
   sudo npm install -g n
   sudo n 20
   node -v
   ```

## Deploy Portable Bundle
Assuming `artifact-hashes.json` generated via `npm run manifest:usb` on build host.
1. Copy bundle to USB root: required files listed in `artifact-hashes.json`.
2. On Pi mount USB (auto or: `sudo mkdir -p /mnt/usb && sudo mount /dev/sda1 /mnt/usb`).
3. Verify manifest:
   ```bash
   cd /mnt/usb
   node verify-manifest.js artifact-hashes.json
   ```
4. Copy to runtime dir (optional):
   ```bash
   mkdir -p ~/aurrelia && rsync -av --checksum /mnt/usb/ ~/aurrelia/
   ```

## Systemd Service
Create `/etc/systemd/system/aurrelia-miner.service`:
```
[Unit]
Description=Aurrelia Deterministic Miner
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/aurrelia
Environment=REAL_STRICT=1
Environment=AUDIT_HMAC_KEY=<redacted>
Environment=USB_MANIFEST_HMAC_KEY=<redacted>
ExecStart=/usr/bin/node seraphina-mining-portable.js --audit --env-audit
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```
Enable & start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable aurrelia-miner
sudo systemctl start aurrelia-miner
sudo systemctl status aurrelia-miner
```

## Thermal & Performance Tuning
- Enable sensors: `sudo apt install -y lm-sensors` then `sensors`.
- Set throttling guard in wrapper (optional script monitors `/sys/class/thermal/thermal_zone0/temp`). Stop mining above 82°C.
- Use `cpufreq-set -g performance` only if cooling robust; otherwise keep `ondemand`.
- BigTreeTech boards: verify voltage regulator cooling; consider external fan via GPIO PWM (use pigpio library) for adaptive RPM.

## Integrity & Audit
- Nightly cron: `crontab -e` add:
  `15 2 * * * cd /home/pi/aurrelia && /usr/bin/node integrity-audit.js >> audit-log.jsonl 2>&1`
- Monitor Prometheus metrics endpoint (if exposed): forward port via reverse proxy or node exporter sidecar.

## Manifest & Verification
- `artifact-hashes.json` contains Merkle root; keep copy offline.
- To regenerate on Pi for comparison:
  ```bash
  USB_MANIFEST_HMAC_KEY=<key> node generate-usb-manifest.js > /tmp/new.json
  diff <(jq -r .merkleRoot artifact-hashes.json) <(jq -r .merkleRoot /tmp/new.json)
  ```

## Logging & Rotation
- Use `logrotate` for ledger and audit logs: create `/etc/logrotate.d/aurrelia` with daily rotation & 14 day retention.
- Ensure `governance-ledger.jsonl` not truncated; rotate with copytruncate only after integrity audit.

## SD / USB Endurance
- Prefer moving write-heavy ledgers to USB flash with high endurance or external SSD.
- Mount with `noatime` option to reduce write amplification.

## Security Hardening
- Restrict SSH to key auth; disable password.
- Use `ufw` to allow mining pool port + metrics (if needed), block others.
- Keep HMAC keys in `/etc/aurrelia/secrets.env` with `chmod 600` and reference via systemd `EnvironmentFile=`.

## Troubleshooting
- High CPU temp: reduce thread count or increase fan duty cycle.
- Ledger chain mismatch on audit: immediately halt service, diff recent appended lines, recompute manually.
- Swap adapter latency: ensure network DNS stable; optionally pin secondary resolver.

## Next Enhancements (Optional)
- GPIO fan adaptive control script.
- Local LLM suggestion container (quantized GGUF) for offline agent hints.
- Prometheus node exporter integration for unified panel.

---
End of PI-INTEGRATION.md.
