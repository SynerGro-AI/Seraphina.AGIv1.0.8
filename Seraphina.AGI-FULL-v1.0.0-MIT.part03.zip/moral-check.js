'use strict';
// moral-check.js – deterministic safety validator for autonomous adjustments.
const GUIDELINES = ['honesty','fairness','stewardship','non_harm','privacy','transparency','integrity','responsibility','respect','security'];
function validateProposal(params){
  for(const [k,v] of Object.entries(params)){
    if(typeof v !== 'number' || !isFinite(v)) return { ok:false, reason:'non-finite' };
    if(v < 0) return { ok:false, reason:'negative-value' };
  }
  return { ok:true, guidelines: GUIDELINES };
}
module.exports = { validateProposal, GUIDELINES };