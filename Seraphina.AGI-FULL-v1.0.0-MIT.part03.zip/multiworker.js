"use strict";
// multiworker.js – placeholder orchestration for WORKERS>1 in modular rebuild phase.
// Current strategy: if WORKERS>1, spawn N basic workers that run the fixed miner logic independently.
// Future: reintegrate coordinated norm threshold & batch guidance.

if (!module.parent){
  // This file is intended to be required (side-effect) from the main miner.
}

const WORKERS = parseInt(process.env.WORKERS || '1',10);
if (WORKERS > 1){
  const { Worker } = require('worker_threads');
  console.log(`[MultiWorker] Launching ${WORKERS} isolated workers (temporary simple mode)`);
  const path = require('path');
  for (let i=0;i<WORKERS;i++){
    const w = new Worker(path.resolve(__dirname, 'aurrelia-pico-mesh-miner.fixed.js'), { env: { ...process.env, WORKERS:'1', MW_INDEX:String(i) } });
    w.on('exit', code=> console.log('[MultiWorker] worker', i, 'exit code', code));
  }
}
