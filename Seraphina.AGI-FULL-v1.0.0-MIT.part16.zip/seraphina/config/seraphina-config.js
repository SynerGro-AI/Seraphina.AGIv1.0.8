// seraphina-config.js
// Central configuration for Seraphina API facade & simulation defaults.
// Modify here to change global defaults without touching logic code.

'use strict';

module.exports = {
  simulation: {
    defaultN: 5000,
    defaultSeed: 'virtue-sim-seed',
    targets: {
      prudenceHarm: -0.25,
      truthfulnessPass: 0.35,
      justiceFairness: 0.30
    },
    bootstrap: 500,
    permutation: 400,
    refine: {
      tol: 0.01,
      maxIter: 4
    },
    bounds: {
      correlationMin: -0.95,
      correlationMax: 0.95,
      nMin: 1,
      nMax: 1000000
    }
  },
  ledger: {
    path: 'seraphina-virtue-corr-ledger.jsonl'
  },
  security: {
    maxTextLength: 16000,
    allowedCorrelationAbs: 0.95
  }
};
