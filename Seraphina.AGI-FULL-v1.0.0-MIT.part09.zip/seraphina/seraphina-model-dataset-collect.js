// seraphina-model-dataset-collect.js
// Aggregates conversational, decision, personality, and economic signals into a hash-chained dataset ledger.
// Output ledger: seraphina-model-dataset.jsonl
// Deterministic digests & redaction of sensitive patterns.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const OUT_PATH = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
const PERSONALITY_LEDGER = process.env.SERAPHINA_PERSONALITY_LEDGER || 'seraphina-personality-ledger.jsonl';
const ECON_STATE_PATH = process.env.SERAPHINA_ECON_STATE_PATH || 'econ-state-snapshot.json';
const DIALOG_LOG_PATH = process.env.SERAPHINA_DIALOG_LOG || 'seraphina-dialog-log.jsonl';
const DECISION_LOG_PATH = process.env.SERAPHINA_DECISION_LOG || 'governance-ledger.jsonl';

const REDACT_PATTERNS = [/(wallet|seed|mnemonic|passphrase|api[_-]?key)/i];

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }
function redact(text){ if(!text) return text; let out=text; for(const r of REDACT_PATTERNS){ out = out.replace(r,'[REDACT]'); } return out; }
function readJsonLines(path, limit){ if(!fs.existsSync(path)) return []; let lines=fs.readFileSync(path,'utf8').trim().split(/\n+/); if(limit && lines.length>limit) lines=lines.slice(-limit); const out=[]; for(const l of lines){ try{ out.push(JSON.parse(l)); }catch(_){} } return out; }

function latestPersonality(){
  const lines = readJsonLines(PERSONALITY_LEDGER, 50);
  if (!lines.length) return null; return lines[lines.length-1].traits || null;
}

function econSnapshot(){
  try { if(fs.existsSync(ECON_STATE_PATH)) return JSON.parse(fs.readFileSync(ECON_STATE_PATH,'utf8')); } catch(_){}
  return {};
}

function collectDialogs(limit){ return readJsonLines(DIALOG_LOG_PATH, limit).map(d=>({ ts:d.ts, role:d.role, text:redact(d.text) })); }
function collectDecisions(limit){ return readJsonLines(DECISION_LOG_PATH, limit).map(d=>({ ts:d.ts||d.t||Date.now(), action:d.action||d.type, digest:d.chainHash||stableHash(d) })); }

function appendEntry(entry){
  try {
    let prev='GENESIS';
    if (fs.existsSync(OUT_PATH)){
      const lines = fs.readFileSync(OUT_PATH,'utf8').trim().split(/\n+/);
      if (lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){ prev='GENESIS'; } }
    }
    entry.prevHash = prev;
    entry.chainHash = stableHash(entry);
    fs.appendFileSync(OUT_PATH, JSON.stringify(entry)+'\n');
  } catch(e){ console.warn('[SeraphinaDataset] append error', e.message); }
}

function runCollect(){
  const personality = latestPersonality();
  const econ = econSnapshot();
  const dialogs = collectDialogs(25);
  const decisions = collectDecisions(25);
  const econSignals = {
    frenRevenueNorm: econ.frenRevenueNorm || 0,
    incomeSpread: econ.incomeSpread || 0,
    acceptRatio: econ.acceptRatio || 0
  };
  const ts = Date.now();
  const entry = {
    ts,
    personality,
    econSignals,
    dialogDigest: stableHash(dialogs),
    decisionDigest: stableHash(decisions),
    dialogs,
    decisions
  };
  appendEntry(entry);
  return entry;
}

if (require.main === module){
  const e = runCollect();
  console.log('[SeraphinaDataset] appended', e.chainHash.slice(0,16));
}

module.exports = { runCollect };