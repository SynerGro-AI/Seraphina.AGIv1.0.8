'use strict';
// seraphina-multilang-ast.js
// Basic multi-language structural parsing (Python / PowerShell) for counts & depth approximations.

function parsePython(code){
  // Count defs, classes, imports; approximate nesting by indentation levels
  const lines = code.split(/\r?\n/);
  let funcCount=0, classCount=0, importCount=0, maxIndent=0;
  for(const l of lines){
    if(/^\s*def\s+[A-Za-z_][A-Za-z0-9_]*\s*\(/.test(l)) funcCount++;
    if(/^\s*class\s+[A-Za-z_][A-Za-z0-9_]*\s*:/.test(l)) classCount++;
    if(/^\s*(import|from)\s+/.test(l)) importCount++;
    const indent = /^\s*/.exec(l)[0].length; if(indent > maxIndent) maxIndent=indent;
  }
  return { lang:'python', funcCount, classCount, importCount, depthApprox: maxIndent };
}

function parsePowerShell(code){
  // Count function declarations and scriptblocks, approximate depth by curly nesting
  let funcCount=0, scriptBlocks=0, depth=0, maxDepth=0;
  for(const l of code.split(/\r?\n/)){
    if(/function\s+[A-Za-z_][A-Za-z0-9_]*/i.test(l)) funcCount++;
    for(const ch of l){
      if(ch === '{'){ depth++; if(depth>maxDepth) maxDepth=depth; }
      else if(ch === '}'){ depth = Math.max(0, depth-1); }
    }
    if(/\{\s*param/i.test(l)) scriptBlocks++; // rough heuristic
  }
  return { lang:'powershell', funcCount, scriptBlocks, depthApprox:maxDepth };
}

function detectAndParse(fileName, code){
  if(/\.py$/i.test(fileName)) return parsePython(code);
  if(/\.ps1$/i.test(fileName)) return parsePowerShell(code);
  return null; // unsupported / JS handled elsewhere
}

module.exports = { detectAndParse, parsePython, parsePowerShell };