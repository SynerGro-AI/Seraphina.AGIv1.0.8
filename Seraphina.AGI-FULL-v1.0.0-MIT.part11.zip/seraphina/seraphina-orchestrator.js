/**
 * SERAPHINA ORCHESTRATOR
 * ---------------------------------------------------------
 * Launches and supervises:
 *  1. Real Mining (seraphina-REAL-mining.js)
 *  2. RVN→BTC Swap Service (rvn-to-btc-swap-service.js)
 *  3. BTC Transfer Daemon (real-btc-transfer-service.js)
 *
 * Features:
 *  - Respawns crashed services (exponential backoff capped)
 *  - Unified log prefixing
 *  - Graceful shutdown on CTRL+C
 *  - Simple health summary endpoint (optional)
 */

const { spawn } = require('child_process');
const path = require('path');
const http = require('http');
const fs = require('fs');

const SERVICES = [
  { name: 'mining', script: 'seraphina-REAL-mining.js', args: [], env: {} },
  { name: 'swap', script: 'rvn-to-btc-swap-service.js', args: [], env: {} },
  { name: 'btc', script: 'real-btc-transfer-service.js', args: [], env: {} },
  { name: 'lattice', script: 'seraphina-triad-lattice-guardian.js', args: [], env: { LATTICE_STATUS_PORT: process.env.LATTICE_STATUS_PORT || '8898' } }
];

const procs = new Map();
const meta = new Map();
const LOG_DIR = path.join(__dirname, 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
const MAX_LOG_BYTES = parseInt(process.env.ORCH_MAX_LOG_BYTES || '1048576',10); // 1MB default

function appendRotating(key, chunk, isErr=false) {
  try {
    const base = path.join(LOG_DIR, `${key}${isErr?'.err':''}.log`);
    if (fs.existsSync(base) && fs.statSync(base).size > MAX_LOG_BYTES) {
      const ts = new Date().toISOString().replace(/[:.]/g,'-');
      fs.renameSync(base, base.replace(/\.log$/, `-${ts}.log`));
    }
    fs.appendFileSync(base, chunk);
  } catch {/* ignore */}
}

function startService(def) {
  const key = def.name;
  const now = Date.now();
  const m = meta.get(key) || { restarts: 0, lastStart: 0, backoff: 1000 };
  m.lastStart = now;
  const scriptPath = path.join(__dirname, def.script);
  const child = spawn(process.execPath, [scriptPath, ...def.args], {
    stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, ...def.env }
  });
  procs.set(key, child);
  meta.set(key, m);
  console.log(`[ORCH] Started ${key} (pid=${child.pid})`);

  child.stdout.on('data', d => { const txt = d.toString(); appendRotating(key, txt); process.stdout.write(`[${key.toUpperCase()}] ${txt}`); });
  child.stderr.on('data', d => { const txt = d.toString(); appendRotating(key, txt, true); process.stderr.write(`[${key.toUpperCase()} ERR] ${txt}`); });

  child.on('exit', (code, signal) => {
    console.log(`[ORCH] ${key} exited code=${code} signal=${signal}`);
    procs.delete(key);
    if (shuttingDown) return;
    // Backoff strategy
    m.restarts += 1;
    m.backoff = Math.min(m.backoff * 2, 60_000);
    setTimeout(() => startService(def), m.backoff);
  });
}

let shuttingDown = false;
function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log('[ORCH] Shutting down all services...');
  for (const [name, cp] of procs.entries()) {
    try { cp.kill('SIGTERM'); } catch {}
  }
  setTimeout(()=>process.exit(0), 3000);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

for (const s of SERVICES) startService(s);

// Optional lightweight health server
const HEALTH_PORT = parseInt(process.env.ORCH_HEALTH_PORT || '8899', 10);
http.createServer((req,res) => {
  if (req.url === '/health') {
    const summary = {};
    for (const s of SERVICES) {
      const m = meta.get(s.name) || {}; 
      const running = procs.has(s.name);
      summary[s.name] = { running, restarts: m.restarts, backoffMs: m.backoff };
    }
    res.writeHead(200, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok:true, services: summary, ts: Date.now() }));
  } else {
    res.writeHead(404); res.end();
  }
}).listen(HEALTH_PORT, () => console.log(`[ORCH] Health endpoint http://localhost:${HEALTH_PORT}/health`));

// Optional Seraphina autonomous model advisory loop
if (process.env.SERAPHINA_MODEL_ADVISORY === '1'){
  try {
  const { infer } = require('./seraphina-model-infer.js');
  const { assess: assessMoral } = require('./seraphina-moral-safety.js');
    const { DriftSentinel } = require('./seraphina-model-drift-sentinel.js');
    const drift = new DriftSentinel({ window: parseInt(process.env.SERAPHINA_DRIFT_WINDOW||'200',10), baselineWindow: parseInt(process.env.SERAPHINA_DRIFT_BASELINE_WINDOW||'1000',10) });
    const personalityLedger = process.env.SERAPHINA_PERSONALITY_LEDGER || 'seraphina-personality-ledger.jsonl';
    const datasetPath = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
    const intervalMs = parseInt(process.env.SERAPHINA_MODEL_ADVISORY_MS || '60000',10);
  const advisoryLedger = process.env.SERAPHINA_ADVISORY_LEDGER || 'seraphina-advisory-ledger.jsonl';
  const driftLedger = process.env.SERAPHINA_DRIFT_LEDGER || 'seraphina-drift-ledger.jsonl';
    const loop = ()=>{
      try {
        let personality=null;
        if (fs.existsSync(personalityLedger)){
          const lines = fs.readFileSync(personalityLedger,'utf8').trim().split(/\n+/);
            if(lines.length){ try { personality = JSON.parse(lines[lines.length-1]).traits || null; } catch(_){} }
        }
        let entry=null;
        if (fs.existsSync(datasetPath)){
          const lines = fs.readFileSync(datasetPath,'utf8').trim().split(/\n+/);
          if(lines.length){ try { entry = JSON.parse(lines[lines.length-1]); } catch(_){} }
        }
        if (entry){ entry.personality = entry.personality || personality; }
        if (entry){
          const moralLedgerEnabled = process.env.SERAPHINA_MORAL_LEDGER==='1';
          const personalityLedgerEnabled = process.env.SERAPHINA_PERSONALITY_APPEND==='1';
          if (personalityLedgerEnabled && personality){
            // Re-append personality traits (optional periodic) to ledger for richer chain
            try {
              const obj = { ts: Date.now(), traits: personality };
              let prev='GENESIS';
              if (fs.existsSync(personalityLedger)){
                const pl = fs.readFileSync(personalityLedger,'utf8').trim().split(/\n+/); if(pl.length){ try{ prev = JSON.parse(pl[pl.length-1]).chainHash || 'GENESIS'; }catch{} }
              }
              obj.prevHash=prev; obj.chainHash=require('crypto').createHash('sha256').update(JSON.stringify(obj)).digest('hex');
              fs.appendFileSync(personalityLedger, JSON.stringify(obj)+'\n');
            } catch(e){ console.warn('[ORCH] personality append error', e.message); }
          }
          const moralAssessment = assessMoral(entry, { ledger: moralLedgerEnabled });
          const res = infer(entry);
          if (!res.error){
            drift.record(res.action);
            const driftSnap = drift.snapshot();
            const v = res.virtues || {};
            const vCond = 'E'+fmt(v.empathy)+' J'+fmt(v.justice)+' I'+fmt(v.integrity)+' P'+fmt(v.prudence);
            const adaptLow = v.adaptive? v.adaptive.lowVirtueThreshold : 'n/a';
            console.log('[SERAPHINA-MODEL-ADVISORY]', 'score='+res.score, 'action='+res.action, 'kl='+driftSnap.kl, 'hR='+driftSnap.hRecent, 'safety='+res.safetyFlag, vCond, 'lowThr='+adaptLow, 'digest='+res.digest.slice(0,16));
            appendChain(advisoryLedger, { ts: Date.now(), score: res.score, action: res.action, safety: res.safetyFlag, virtues: res.virtues, digest: res.digest });
            appendChain(driftLedger, { ts: Date.now(), kl: driftSnap.kl, hRecent: driftSnap.hRecent, hBaseline: driftSnap.hBaseline });
          } else {
            console.log('[SERAPHINA-MODEL-ADVISORY]', 'pending-weights');
          }
        } else {
          console.log('[SERAPHINA-MODEL-ADVISORY] no dataset entry yet');
        }
      } catch(e){ console.warn('[SERAPHINA-MODEL-ADVISORY] error', e.message); }
      setTimeout(loop, intervalMs).unref();
    };
  function fmt(x){ if(typeof x!=='number') return '0.00'; return Number(x).toFixed(2); }
  loop();
  } catch(e){ console.warn('[SERAPHINA-MODEL-ADVISORY] init failed', e.message); }
}

function appendChain(path, obj){
  const crypto = require('crypto');
  try {
    let prev='GENESIS';
    if(require('fs').existsSync(path)){
      const lines = require('fs').readFileSync(path,'utf8').trim().split(/\n+/); if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch{} }
    }
    obj.prevHash=prev; obj.chainHash=crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex');
    require('fs').appendFileSync(path, JSON.stringify(obj)+'\n');
  } catch(e){ console.warn('[ORCH] appendChain error', e.message); }
}
