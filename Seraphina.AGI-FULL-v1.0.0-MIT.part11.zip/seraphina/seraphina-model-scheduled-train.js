// seraphina-model-scheduled-train.js
// Periodically runs model training and emits reproducibility snapshot artifacts.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { run: trainRun } = require('./seraphina-model-train.js');
const { merkleRoot, BASE_VOCAB } = require('./seraphina-model-features.js');

const INTERVAL_MS = parseInt(process.env.SERAPHINA_SCHEDULED_TRAIN_MS || '900000',10); // 15m default
const DATASET = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
const PERSONALITY_LEDGER = process.env.SERAPHINA_PERSONALITY_LEDGER || 'seraphina-personality-ledger.jsonl';
const VOCAB_FILE = process.env.SERAPHINA_VOCAB_FILE || 'seraphina-model-vocab.json';
const SNAP_DIR = process.env.SERAPHINA_SNAPSHOT_DIR || 'seraphina-snapshots';
if(!fs.existsSync(SNAP_DIR)) fs.mkdirSync(SNAP_DIR, { recursive: true });

function stableHashFile(path){
  if(!fs.existsSync(path)) return 'MISSING';
  const data = fs.readFileSync(path,'utf8');
  return crypto.createHash('sha256').update(data).digest('hex');
}

function datasetHash(){
  if(!fs.existsSync(DATASET)) return 'NO-DATASET';
  const lines = fs.readFileSync(DATASET,'utf8').trim().split(/\n+/).filter(Boolean);
  return crypto.createHash('sha256').update(lines.join('\n')).digest('hex');
}

function personalityLastHash(){
  if(!fs.existsSync(PERSONALITY_LEDGER)) return 'NO-PERSONALITY';
  try { const lines = fs.readFileSync(PERSONALITY_LEDGER,'utf8').trim().split(/\n+/); if(!lines.length) return 'NO-PERSONALITY'; const last = JSON.parse(lines[lines.length-1]); return last.chainHash || 'NO-PERSONALITY'; } catch{ return 'NO-PERSONALITY'; }
}

function vocabState(){
  let words = BASE_VOCAB;
  if (fs.existsSync(VOCAB_FILE)){
    try { const data = JSON.parse(fs.readFileSync(VOCAB_FILE,'utf8')); if(Array.isArray(data.words)&&data.words.length){ words = Array.from(new Set(data.words.concat(BASE_VOCAB))); words.sort(); } } catch{}
  }
  const root = merkleRoot(words.map(w=> crypto.createHash('sha256').update(w).digest('hex')));
  return { words, merkle: root };
}

function advisoryDistribution(){
  // Simple histogram of recent advisory actions from model train ledger for drift summary
  const ledgerPath = process.env.SERAPHINA_MODEL_TRAIN_LEDGER || 'seraphina-model-train-ledger.jsonl';
  if(!fs.existsSync(ledgerPath)) return { total:0 };
  const lines = fs.readFileSync(ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean);
  const lastN = lines.slice(-200);
  const dist = { promoted:0, notPromoted:0 };
  for(const l of lastN){ try { const obj = JSON.parse(l); if(obj.promoted) dist.promoted++; else dist.notPromoted++; } catch{} }
  return { total: lastN.length, ...dist };
}

function snapshot(){
  const ts = Date.now();
  const trainResult = trainRun();
  const dsHash = datasetHash();
  const persLast = personalityLastHash();
  const vocab = vocabState();
  const weightsFile = process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json';
  const weightsHash = stableHashFile(weightsFile);
  const advisoryDist = advisoryDistribution();
  const snap = {
    ts,
    iso: new Date(ts).toISOString(),
    datasetHash: dsHash,
    personalityChainHash: persLast,
    vocabMerkle: vocab.merkle,
    vocabCount: vocab.words.length,
    weightsHash,
    advisoryDist,
    trainMeta: trainResult? trainResult.out.meta : null,
    weightsVersion: trainResult? trainResult.out.version : null
  };
  const file = `${SNAP_DIR}/snapshot-${new Date(ts).toISOString().replace(/[:.]/g,'-')}.json`;
  fs.writeFileSync(file, JSON.stringify(snap,null,2));
  console.log('[ScheduledTrain] Snapshot written', file, 'datasetHash='+dsHash.slice(0,12), 'vocabMerkle='+vocab.merkle.slice(0,12));
  return snap;
}

function loop(){
  try { snapshot(); } catch(e){ console.warn('[ScheduledTrain] snapshot error', e.message); }
  setTimeout(loop, INTERVAL_MS).unref();
}

if (require.main === module){
  if(process.env.ONCE==='1'){ snapshot(); } else { loop(); }
}

module.exports = { snapshot };
