// seraphina-model-infer.js
// Loads trained logistic weights and provides personality-conditioned scoring.
// Advisory only; returns structured recommendation object.

'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { extractFeatures } = require('./seraphina-model-features.js');
const { assess: assessMoral } = require('./seraphina-moral-safety.js');
let promClient=null; try { promClient=require('prom-client'); } catch(_e){}

const WEIGHTS_PATH = process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function loadWeights(){
  if(!fs.existsSync(WEIGHTS_PATH)) return null;
  try { return JSON.parse(fs.readFileSync(WEIGHTS_PATH,'utf8')); } catch(e){ return null; }
}

let gaugeSuccessA, gaugeSuccessB, gaugeLossA, gaugeLossB;
function ensureGauges(weights){
  if(!promClient || gaugeSuccessA) return;
  gaugeSuccessA = new promClient.Gauge({ name:'aur_model_success_rate', help:'Model successRate (head A)' });
  gaugeSuccessB = new promClient.Gauge({ name:'aur_model_success_rate_ethical', help:'Model successRate ethical (head B)' });
  gaugeLossA = new promClient.Gauge({ name:'aur_model_loss_headA', help:'Model cross-entropy loss head A' });
  gaugeLossB = new promClient.Gauge({ name:'aur_model_loss_headB', help:'Model cross-entropy loss head B' });
  if(weights && weights.meta){
    if(typeof weights.meta.successRate==='number') gaugeSuccessA.set(weights.meta.successRate);
    if(typeof weights.meta.successRateEthical==='number') gaugeSuccessB.set(weights.meta.successRateEthical);
    if(typeof weights.meta.lossA==='number') gaugeLossA.set(weights.meta.lossA);
    if(typeof weights.meta.lossB==='number') gaugeLossB.set(weights.meta.lossB);
  }
}

function sigmoid(z){ return 1/(1+Math.exp(-z)); }

function personalityMod(vector, personality){
  if(!personality) return vector;
  // Scale certain bins: openness boosts exploratory vocab bins (explore, adapt, optimize, imagine)
  const mod = [...vector];
  const openness = personality.openness||0;
  const stability = personality.stability||0;
  // vector layout: [5 personality][3 econ][15 vocab][1 decisionIntensity]
  const vocabOffset = 5+3; // start of vocab
  const mapWords = ['explore','adapt','optimize','imagine'];
  const vocabIndex = (w)=> mapWords.indexOf(w);
  mapWords.forEach(word=>{
    const idx = vocabIndex(word);
    if (idx>=0){ const pos = vocabOffset + idx; mod[pos] = Number((mod[pos] * (1 + 0.5*openness)).toFixed(6)); }
  });
  // Stability dampens risk & volatility related words if present
  const riskIdx = vocabOffset + 3; // approximate position assuming order; adjust if vocab changes
  if (mod[riskIdx] != null){ mod[riskIdx] = Number((mod[riskIdx] * (1 - 0.4*stability)).toFixed(6)); }
  return mod;
}

function infer(entry){
  const weights = loadWeights();
  if(!weights) return { error:'no-weights' };
  const { vector } = extractFeatures(entry);
  const modVec = personalityMod(vector, entry.personality);
  // Moral safety virtues (deterministic heuristic)
  const moral = assessMoral(entry).virtues;
  ensureGauges(weights);
  // Support both legacy single-head and new multi-head format
  if (weights.w && weights.bias != null){
    let z = weights.bias; for(let i=0;i<weights.w.length && i<modVec.length;i++){ z += weights.w[i]*modVec[i]; }
    const p = sigmoid(z);
    const digest = stableHash({ modVec, z: Number(z.toFixed(12)) });
    let action='noop'; let confidence=p;
    if (p > 0.75) action='suggest_expand'; else if (p < 0.35) action='suggest_conserve';
    const safetyFlag = moral.safetyFlag;
    return { score: Number(p.toFixed(6)), action, confidence: Number(confidence.toFixed(6)), ethicalRisk: null, ethicalFlag: null, virtues: moral, safetyFlag, digest, multi:false };
  }
  if (weights.headA && weights.headB){
    let zA = weights.headA.b; for(let i=0;i<weights.headA.w.length && i<modVec.length;i++){ zA += weights.headA.w[i]*modVec[i]; }
    let zB = weights.headB.b; for(let i=0;i<weights.headB.w.length && i<modVec.length;i++){ zB += weights.headB.w[i]*modVec[i]; }
    const pA = sigmoid(zA); const pB = sigmoid(zB);
    const digest = stableHash({ modVec, zA:Number(zA.toFixed(12)), zB:Number(zB.toFixed(12)) });
    let action='noop';
    if (pA > 0.75) action='suggest_expand'; else if (pA < 0.35) action='suggest_conserve';
    let ethicalFlag = 'stable';
    if (pB > 0.6) ethicalFlag='monitor'; else if (pB > 0.8) ethicalFlag='elevated';
    // Combine moral safety with ethicalFlag for a higher-level safetyFlag
    let safetyFlag = moral.safetyFlag;
    if (ethicalFlag === 'elevated' || safetyFlag === 'elevated') safetyFlag='elevated';
    else if (ethicalFlag === 'monitor' || safetyFlag === 'monitor') safetyFlag='monitor';
    return { score: Number(pA.toFixed(6)), action, confidence: Number(pA.toFixed(6)), ethicalRisk: Number(pB.toFixed(6)), ethicalFlag, virtues: moral, safetyFlag, digest, multi:true };
  }
  return { error:'unrecognized-weight-format' };
}

if (require.main === module){
  // CLI demo: use latest dataset entry if exists
  const path = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
  const w = loadWeights();
  if(w && w.meta){ console.log('[SeraphinaInfer][SuccessMeta]', { successRate: w.meta.successRate, successRateEthical: w.meta.successRateEthical }); }
  if (fs.existsSync(path)){
    try {
      const lines = fs.readFileSync(path,'utf8').trim().split(/\n+/); const last = JSON.parse(lines[lines.length-1]);
      console.log('[SeraphinaInfer]', JSON.stringify(infer(last))); return;
    } catch(e){ console.error('[SeraphinaInfer] read error', e.message); }
  }
  console.log('[SeraphinaInfer] no dataset');
}

module.exports = { infer };