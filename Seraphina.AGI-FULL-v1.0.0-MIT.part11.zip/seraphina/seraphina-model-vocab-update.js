// seraphina-model-vocab-update.js
// Adds new candidate words to dynamic vocab file & appends hash-chained ledger entry.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { BASE_VOCAB, merkleRoot } = require('./seraphina-model-features.js');

const VOCAB_FILE = process.env.SERAPHINA_VOCAB_FILE || 'seraphina-model-vocab.json';
const LEDGER = process.env.SERAPHINA_VOCAB_LEDGER || 'seraphina-model-vocab-ledger.jsonl';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function loadWords(){
  if(!fs.existsSync(VOCAB_FILE)) return [...BASE_VOCAB];
  try { const data = JSON.parse(fs.readFileSync(VOCAB_FILE,'utf8')); if(Array.isArray(data.words)) return data.words; } catch{}
  return [...BASE_VOCAB];
}

function saveWords(words){
  words = Array.from(new Set(words.concat(BASE_VOCAB)));
  words.sort();
  fs.writeFileSync(VOCAB_FILE, JSON.stringify({ words, count: words.length, updated: Date.now() }, null, 2));
  return words;
}

function appendLedger(entry){
  try {
    let prev='GENESIS';
    if (fs.existsSync(LEDGER)){
      const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch{} }
    }
    entry.prevHash = prev; entry.chainHash = stableHash(entry);
    fs.appendFileSync(LEDGER, JSON.stringify(entry)+'\n');
  } catch(e){ console.warn('[VocabUpdate] ledger append failed', e.message); }
}

function addWords(newWords){
  if(!Array.isArray(newWords) || !newWords.length){ console.log('[VocabUpdate] No new words provided'); return; }
  const current = loadWords();
  const beforeSet = new Set(current);
  const merged = current.concat(newWords.map(w=> String(w).toLowerCase().trim()).filter(Boolean));
  const final = Array.from(new Set(merged));
  if (final.length === current.length){ console.log('[VocabUpdate] No changes (all duplicates)'); return; }
  final.sort();
  saveWords(final);
  const added = final.filter(w=> !beforeSet.has(w));
  const root = merkleRoot(final.map(w=> stableHash(w)));
  appendLedger({ ts: Date.now(), added, count: final.length, merkle: root });
  console.log('[VocabUpdate] Added', added.length, 'words. Total=', final.length, 'MerkleRoot=', root.slice(0,16));
}

if (require.main === module){
  const words = process.argv.slice(2);
  addWords(words);
}

module.exports = { addWords };
