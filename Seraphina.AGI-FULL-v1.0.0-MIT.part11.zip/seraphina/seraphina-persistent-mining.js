#!/usr/bin/env node
throw new Error('seraphina-persistent-mining.js removed. Use proper-antminer-mining.js or zero-simulation-real-miner.js');
// (File intentionally empty beyond blocker)