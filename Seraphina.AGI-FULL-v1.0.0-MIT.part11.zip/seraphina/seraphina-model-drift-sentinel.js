// seraphina-model-drift-sentinel.js
// Rolling action distribution monitor with KL divergence against baseline.
'use strict';
const prom = (()=>{ try { return require('prom-client'); } catch{ return null; } })();

class DriftSentinel {
  constructor(opts={}){
    this.window = opts.window || 200; // recent advisory samples
    this.baselineWindow = opts.baselineWindow || 1000; // longer-term
    this.actionsRecent = [];
    this.actionsBaseline = [];
    this.gauges = null;
    this._ensureGauges();
  }
  _ensureGauges(){
    if (!prom || this.gauges) return;
    try {
      this.gauges = {
        kl: new prom.Gauge({ name:'seraphina_advisory_kl', help:'KL divergence recent vs baseline action distribution' }),
        entropyRecent: new prom.Gauge({ name:'seraphina_advisory_entropy_recent', help:'Shannon entropy recent action distribution' }),
        entropyBaseline: new prom.Gauge({ name:'seraphina_advisory_entropy_baseline', help:'Shannon entropy baseline action distribution' })
      };
    } catch{/* ignore */}
  }
  record(action){
    if(!action) return;
    this.actionsRecent.push(action); if(this.actionsRecent.length>this.window) this.actionsRecent.shift();
    this.actionsBaseline.push(action); if(this.actionsBaseline.length>this.baselineWindow) this.actionsBaseline.shift();
    this._updateMetrics();
  }
  _dist(arr){
    const counts = {}; arr.forEach(a=>{ counts[a]=(counts[a]||0)+1; });
    const total = arr.length || 1; const out={}; Object.keys(counts).forEach(k=> out[k]=counts[k]/total);
    return out;
  }
  _entropy(dist){
    let h=0; for(const p of Object.values(dist)){ if(p>0) h -= p*Math.log2(p); }
    return h;
  }
  _kl(p,q){
    // KL(P||Q) with smoothing
    const keys = new Set([...Object.keys(p), ...Object.keys(q)]);
    let d=0; for(const k of keys){ const pk = p[k] || 0; const qk = q[k] || 0; const ps = pk+1e-9; const qs = qk+1e-9; d += ps * Math.log(ps/qs); }
    return d;
  }
  _updateMetrics(){
    if(!this.actionsRecent.length || !this.actionsBaseline.length) return;
    const recent = this._dist(this.actionsRecent);
    const base = this._dist(this.actionsBaseline);
    const kl = this._kl(recent, base);
    const hR = this._entropy(recent);
    const hB = this._entropy(base);
    if(this.gauges){
      try {
        this.gauges.kl.set(Number(kl.toFixed(6)));
        this.gauges.entropyRecent.set(Number(hR.toFixed(6)));
        this.gauges.entropyBaseline.set(Number(hB.toFixed(6)));
      } catch{/* ignore */}
    }
  }
  snapshot(){
    const recent = this._dist(this.actionsRecent);
    const base = this._dist(this.actionsBaseline);
    return { recent, baseline: base, kl: Number(this._kl(recent, base).toFixed(6)), hRecent: Number(this._entropy(recent).toFixed(6)), hBaseline: Number(this._entropy(base).toFixed(6)) };
  }
}

module.exports = { DriftSentinel };