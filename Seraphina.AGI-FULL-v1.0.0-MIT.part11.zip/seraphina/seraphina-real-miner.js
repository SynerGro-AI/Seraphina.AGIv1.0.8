#!/usr/bin/env node
// Minimal Real Miner Entry Point
// - Connects to a Stratum pool
// - Receives jobs and logs them
// - Provides hook points for an external hashing engine (NOT simulated here)
// - Tamper-evident logging of jobs and accepted shares
// Environment:
//   STRATUM_POOL_HOST (default btc.f2pool.com)
//   STRATUM_POOL_PORT (default 1314)
//   STRATUM_WORKER (required or fallback example.worker)
//   STRATUM_PASSWORD (default x)
//   STRATUM_DEBUG=1 for verbose protocol logging
//   LOG_FILE (optional custom chain log filename)

const { StratumCoreClient } = require('./stratum-core');
const { createLogger } = require('./tamper-log');

(async () => {
  const host = process.env.STRATUM_POOL_HOST || 'btc.f2pool.com';
  const port = parseInt(process.env.STRATUM_POOL_PORT || '1314', 10);
  const worker = process.env.STRATUM_WORKER || 'example.worker';
  const password = process.env.STRATUM_PASSWORD || 'x';
  const logName = process.env.LOG_FILE || 'share-log.chain.jsonl';
  const logger = createLogger(logName);

  const client = new StratumCoreClient({ host, port, worker, password });

  const log = (type, data) => {
    try { const entry = logger.append(type, data); if (process.env.STRATUM_DEBUG) console.log('[LOG]', entry); }
    catch(e){ console.error('[LOG_ERROR]', e.message); }
  };

  /**
   * Deprecated: Use `aurrelia-pico-mesh-miner.js`.
   * This stub preserves legacy invocation while enforcing REAL_STRICT env-only configuration.
   */
  if (process.env.REAL_STRICT === '1'){
    console.error('[DEPRECATED] seraphina-real-miner.js is disabled under REAL_STRICT. Use aurrelia-pico-mesh-miner.js');
    process.exit(1);
  }
  console.warn('[DEPRECATED] Falling back to aurrelia-pico-mesh-miner.js');
  require('./aurrelia-pico-mesh-miner.js');

  client.on('connected', info => log('connected', info));
  client.on('subscribed', d => log('subscribed', d));
  client.on('authorized', d => { console.log('[MINER] Authorized worker', d.worker); log('authorized', d); });
  client.on('difficulty', d => { console.log('[MINER] Difficulty', d.difficulty); log('difficulty', d); });
  client.on('job', job => {
    console.log('[MINER] New job', job.jobId, 'clean:', job.clean);
    log('job', { jobId: job.jobId, prevhash: job.prevhash, nbits: job.nbits, ntime: job.ntime, branches: job.merkleBranches.length });
    // NOTE: Hashing intentionally absent. Integrate external hasher here.
  });
  client.on('shareRejected', r => { console.log('\u274c Share rejected', r.id, r.error); log('shareRejected', r); });
  client.on('error', e => { console.error('[STRATUM_ERROR]', e.message); log('error', { message: e.message }); });
  client.on('closed', () => { console.log('[MINER] Connection closed'); log('closed', {}); });

  try {
    await client.connect();
    console.log('[MINER] Connected & authorized. Awaiting jobs...');
  } catch (e) {
    console.error('[FATAL] Unable to start stratum session:', e.message);
    process.exit(2);
  }

  // Periodic chain verification (optional integrity check)
  setInterval(() => {
    const v = logger.verify();
    if (!v.ok) console.error('[CHAIN_VERIFY_FAIL]', v);
  }, 60000).unref();
})();
