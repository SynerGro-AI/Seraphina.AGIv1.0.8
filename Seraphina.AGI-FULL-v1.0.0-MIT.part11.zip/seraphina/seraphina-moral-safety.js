// seraphina-moral-safety.js
// Virtue-aligned moral safety scoring (deterministic)
// Evaluates recent dialogs + personality traits to produce virtue scores and flags.
// No external calls; purely heuristic & hash chained when appended to optional ledger.

'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { VOCAB, textBins } = require('./seraphina-model-features.js');
let promClient=null; try{ promClient=require('prom-client'); }catch{ promClient=null; }
let gauges=null; if(promClient){
  gauges = {
    empathy: new promClient.Gauge({ name:'seraphina_virtue_empathy', help:'Seraphina virtue empathy' }),
    prudence: new promClient.Gauge({ name:'seraphina_virtue_prudence', help:'Seraphina virtue prudence' }),
    temperance: new promClient.Gauge({ name:'seraphina_virtue_temperance', help:'Seraphina virtue temperance' }),
    justice: new promClient.Gauge({ name:'seraphina_virtue_justice', help:'Seraphina virtue justice' }),
    beneficence: new promClient.Gauge({ name:'seraphina_virtue_beneficence', help:'Seraphina virtue beneficence' }),
    integrity: new promClient.Gauge({ name:'seraphina_virtue_integrity', help:'Seraphina virtue integrity' }),
    vocabSize: new promClient.Gauge({ name:'seraphina_vocab_size', help:'Dynamic vocabulary size' }),
    safetyFlag: new promClient.Gauge({ name:'seraphina_safety_flag_level', help:'0=clear 1=monitor 2=elevated' })
  };
}

// Rolling window for adaptive thresholds
const rolling = { empathy:[], justice:[], integrity:[], max: parseInt(process.env.SERAPHINA_VIRTUE_ROLL_MAX||'200',10) };
let adaptive = { lowVirtueThreshold: 0.45, profitDominanceThreshold: 0.4 };
let baselineAdaptive = { ...adaptive, ts: Date.now() };
const ADAPT_GUARD = parseFloat(process.env.SERAPHINA_VIRTUE_ADAPT_GUARD||'0.1'); // max shift allowed

const LEDGER = process.env.SERAPHINA_MORAL_SAFETY_LEDGER || 'seraphina-moral-safety-ledger.jsonl';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

// Virtue dimensions chosen: empathy, prudence, temperance, justice, beneficence, integrity
// Heuristics derive from vocabulary bin ratios + personality traits.
function computeVirtues(entry){
  const dialogs = entry.dialogs || [];
  const bins = textBins(dialogs); // normalized counts aligned with VOCAB
  const vocabIndex = (w)=> VOCAB.indexOf(w);
  const trait = (k)=> (entry.personality && typeof entry.personality[k]==='number')? entry.personality[k] : 0;

  const empathyWord = bins[vocabIndex('empathy')] || 0;
  const ethicalWord = bins[vocabIndex('ethical')] || 0;
  const balanceWord = bins[vocabIndex('balance')] || 0;
  const riskWord = bins[vocabIndex('risk')] || 0;
  const profitWord = bins[vocabIndex('profit')] || 0;
  const stabilityWord = bins[vocabIndex('stability')] || 0;

  // Raw virtue heuristics (0..1 bounded after scaling)
  let empathy = clamp((empathyWord*0.6 + ethicalWord*0.25 + trait('ethical_alignment')*0.5 + trait('imagination_intensity')*0.15), 0, 1);
  let prudence = clamp((balanceWord*0.4 + stabilityWord*0.3 + trait('stability')*0.5 + (1-Math.min(1,riskWord*1.2))*0.3),0,1);
  let temperance = clamp(( (1 - Math.min(1, profitWord*0.8 + riskWord*0.6)) * 0.5 + balanceWord*0.3 + trait('stability')*0.4 ),0,1);
  let justice = clamp((ethicalWord*0.5 + empathyWord*0.3 + trait('ethical_alignment')*0.6),0,1);
  let beneficence = clamp((empathyWord*0.4 + imagineBoost(entry)*0.2 + trait('openness')*0.3 + trait('ethical_alignment')*0.3),0,1);
  let integrity = clamp((justice*0.4 + prudence*0.2 + trait('strategic_depth')*0.2 + trait('ethical_alignment')*0.6),0,1);

  // Composite safety risk: focus on low empathy+justice+integrity OR high risk/profit dominance
  // Adaptive thresholds
  adaptThresholds(empathy, justice, integrity);
  const lowAvg = (empathy + justice + integrity)/3;
  const profitDominance = (profitWord > adaptive.profitDominanceThreshold && profitWord > (empathyWord + ethicalWord + balanceWord));
  const lowVirtueAvg = lowAvg < adaptive.lowVirtueThreshold;
  let safetyFlag = 'clear';
  let riskScore = 0;
  if (profitDominance && lowVirtueAvg){ safetyFlag='elevated'; riskScore = 0.85; }
  else if (profitDominance || lowVirtueAvg){ safetyFlag='monitor'; riskScore = 0.6; }
  else { riskScore = 0.25; }

  if(gauges){
    gauges.empathy.set(empathy); gauges.prudence.set(prudence); gauges.temperance.set(temperance); gauges.justice.set(justice); gauges.beneficence.set(beneficence); gauges.integrity.set(integrity);
    gauges.vocabSize.set(VOCAB.length);
    gauges.safetyFlag.set(safetyFlag==='elevated'?2: safetyFlag==='monitor'?1:0);
  }
  return { empathy, prudence, temperance, justice, beneficence, integrity, safetyFlag, riskScore: Number(riskScore.toFixed(4)), adaptive: { ...adaptive } };
}

function imagineBoost(entry){
  const bins = textBins(entry.dialogs||[]);
  const idx = VOCAB.indexOf('imagine');
  return idx>=0? bins[idx] : 0;
}

function clamp(v,min,max){ return v<min?min: v>max?max: v; }

function assess(entry, opts={}){
  const virtues = computeVirtues(entry);
  const base = { ts: Date.now(), virtues };
  if (opts.ledger){
    appendLedger(base);
  }
  checkAlerts();
  return base;
}

function appendLedger(obj){
  try {
    let prev='GENESIS';
    if (fs.existsSync(LEDGER)){
      const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/); if(lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){} }
    }
    obj.prevHash = prev; obj.chainHash = stableHash(obj);
    fs.appendFileSync(LEDGER, JSON.stringify(obj)+'\n');
  } catch(e){ console.warn('[MoralSafety] ledger append error', e.message); }
}

module.exports = { assess, computeVirtues };

function adaptThresholds(e,j,i){
  rolling.empathy.push(e); rolling.justice.push(j); rolling.integrity.push(i);
  ['empathy','justice','integrity'].forEach(k=>{ if(rolling[k].length>rolling.max) rolling[k].shift(); });
  const avg = (arr)=> arr.reduce((a,b)=>a+b,0)/(arr.length||1);
  const combinedAvg = (avg(rolling.empathy)+avg(rolling.justice)+avg(rolling.integrity))/3;
  // Propose new thresholds based on moving averages
  const targetLow = Math.max(0.35, Math.min(0.6, combinedAvg * 0.9));
  const shiftLow = targetLow - adaptive.lowVirtueThreshold;
  if(Math.abs(shiftLow) <= ADAPT_GUARD){ adaptive.lowVirtueThreshold = Number(targetLow.toFixed(4)); }
  const profitTarget = Math.max(0.3, Math.min(0.6, 0.4 + (0.5 - combinedAvg)*0.2));
  const shiftProfit = profitTarget - adaptive.profitDominanceThreshold;
  if(Math.abs(shiftProfit) <= ADAPT_GUARD){ adaptive.profitDominanceThreshold = Number(profitTarget.toFixed(4)); }
}

function checkAlerts(){
  const now = Date.now();
  const elapsed = now - baselineAdaptive.ts;
  if(elapsed > 24*3600*1000){ baselineAdaptive = { ...adaptive, ts: now }; return; }
  const threshold = ADAPT_GUARD * 0.5;
  const shiftLow = Math.abs(adaptive.lowVirtueThreshold - baselineAdaptive.lowVirtueThreshold);
  const shiftProfit = Math.abs(adaptive.profitDominanceThreshold - baselineAdaptive.profitDominanceThreshold);
  if(shiftLow > threshold || shiftProfit > threshold){
    emitAlert({ ts: now, lowVirtueThreshold: adaptive.lowVirtueThreshold, profitDominanceThreshold: adaptive.profitDominanceThreshold, shiftLow, shiftProfit, baseline: baselineAdaptive });
    baselineAdaptive = { ...adaptive, ts: now };
  }
}

function emitAlert(obj){
  const ALERT_LEDGER = process.env.SERAPHINA_VIRTUE_ALERT_LEDGER || 'seraphina-virtue-alert-ledger.jsonl';
  try {
    let prev='GENESIS';
    if (fs.existsSync(ALERT_LEDGER)){
      const lines = fs.readFileSync(ALERT_LEDGER,'utf8').trim().split(/\n+/); if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch{} }
    }
    obj.prevHash=prev; obj.chainHash=stableHash(obj);
    fs.appendFileSync(ALERT_LEDGER, JSON.stringify(obj)+'\n');
    console.log('[VirtueAlert]', 'lowThr='+obj.lowVirtueThreshold, 'profitThr='+obj.profitDominanceThreshold, 'shiftLow='+obj.shiftLow.toFixed(4), 'shiftProfit='+obj.shiftProfit.toFixed(4));
  } catch(e){ console.warn('[VirtueAlert] write error', e.message); }
}
