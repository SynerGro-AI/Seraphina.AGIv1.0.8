// seraphina-personality-evolve.js
// Deterministic personality trait evolution derived from sandbox & imagination metrics.
// Traits: openness, stability, strategic_depth, ethical_alignment, imagination_intensity
// Inputs (expected): metrics snapshot objects from imagination-ledger / empowerment / emotion maps.
// Ledger: seraphina-personality-ledger.jsonl (append-only, hash-chained)
// Usage: node seraphina-personality-evolve.js (emits new traits and appends ledger entry)

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const LEDGER_PATH = process.env.SERAPHINA_PERSONALITY_LEDGER || 'seraphina-personality-ledger.jsonl';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function bounded(x){ if (!isFinite(x)) return 0; return Math.min(1, Math.max(0, x)); }

// Deterministic trait computation. Provide a metrics object:
// {
//   imagination: { curiosity:0-1, novelty:0-1, empowerment:0-1, integration:0-1 },
//   emotion: { calm:0-1, focus:0-1, resolve:0-1, empathy:0-1, wonder:0-1 },
//   sandbox: { cycles: number, stableRatio:0-1 },
//   ethics: { virtueGauge:0-1 }
// }
// Missing fields default to 0.
function computeTraits(metrics){
  const imag = metrics.imagination || {};
  const emo = metrics.emotion || {};
  const sbox = metrics.sandbox || {};
  const eth = metrics.ethics || {};
  const curiosity = bounded(imag.curiosity||0);
  const novelty = bounded(imag.novelty||0);
  const empowerment = bounded(imag.empowerment||0);
  const integration = bounded(imag.integration||0);
  const calm = bounded(emo.calm||0);
  const focus = bounded(emo.focus||0);
  const resolve = bounded(emo.resolve||0);
  const empathy = bounded(emo.empathy||0);
  const wonder = bounded(emo.wonder||0);
  const stableRatio = bounded(sbox.stableRatio||0);
  const virtueGauge = bounded(eth.virtueGauge||0);
  const cycles = typeof sbox.cycles==='number' && sbox.cycles>0? sbox.cycles : 0;
  // Openness: blend curiosity + novelty + wonder (weighted) dampened by excessive focus (prevents tunnel vision)
  const opennessRaw = (curiosity*0.4 + novelty*0.3 + wonder*0.3) * (0.85 + (1 - focus)*0.15);
  // Stability: calm + resolve + (stableRatio * 0.4)
  const stabilityRaw = (calm*0.45 + resolve*0.35 + stableRatio*0.20);
  // Strategic Depth: integration + focus + (cycles normalized log factor) + empowerment synergy
  const cycleFactor = cycles>0? Math.min(1, Math.log10(cycles+1)/3) : 0; // log scaling
  const strategicRaw = (integration*0.4 + focus*0.25 + empowerment*0.2 + cycleFactor*0.15);
  // Ethical Alignment: virtueGauge + empathy*0.4 + resolve*0.1 (resolve for follow-through)
  const ethicalRaw = (virtueGauge*0.5 + empathy*0.4 + resolve*0.1);
  // Imagination Intensity: empowerment + curiosity + wonder synergy minus calm dampening (if too calm)
  const imaginationRaw = (empowerment*0.35 + curiosity*0.25 + wonder*0.25 + novelty*0.15) * (0.9 + (1 - calm)*0.1);
  const traits = {
    openness: Number(bounded(opennessRaw).toFixed(6)),
    stability: Number(bounded(stabilityRaw).toFixed(6)),
    strategic_depth: Number(bounded(strategicRaw).toFixed(6)),
    ethical_alignment: Number(bounded(ethicalRaw).toFixed(6)),
    imagination_intensity: Number(bounded(imaginationRaw).toFixed(6))
  };
  return traits;
}

function appendLedger(entry){
  try {
    let prev='GENESIS';
    if (fs.existsSync(LEDGER_PATH)){
      try {
        const lines = fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/);
        if (lines.length){ const last = JSON.parse(lines[lines.length-1]); prev = last.chainHash || 'GENESIS'; }
      } catch(_){}
    }
    entry.prevHash = prev;
    entry.chainHash = stableHash(entry);
    fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n');
  } catch(e){ console.warn('[PersonalityLedger] append error', e.message); }
}

function evolve(metrics){
  const traits = computeTraits(metrics);
  const ts = Date.now();
  const digest = stableHash({ traits, ts });
  const entry = { ts, traits, digest };
  appendLedger(entry);
  return entry;
}

// CLI execution: supply metrics JSON via env path or defaults
if (require.main === module){
  let metrics={};
  const path = process.env.SERAPHINA_PERSONALITY_METRICS_PATH || 'imagination-ledger.jsonl';
  try {
    if (fs.existsSync(path)){
      const lines = fs.readFileSync(path,'utf8').trim().split(/\n+/);
      // Take last line imagination snapshot if structured
      for(let i=lines.length-1;i>=0;i--){
        try { const obj=JSON.parse(lines[i]); if (obj.imagination){ metrics.imagination=obj.imagination; break; } } catch(_){}
      }
    }
  } catch(_){}
  // Additional metric sources can be integrated similarly (virtue gauge, emotion state files)
  try {
    if (fs.existsSync('empowerment-stability-state.json')){
      const es = JSON.parse(fs.readFileSync('empowerment-stability-state.json','utf8'));
      metrics.sandbox = { stableRatio: es.stableRatio||0, cycles: es.cycles||0 };
    }
  } catch(_){}
  try {
    if (fs.existsSync('virtue-gauge.json')){
      const vg = JSON.parse(fs.readFileSync('virtue-gauge.json','utf8'));
      metrics.ethics = { virtueGauge: vg.current||0 };
    }
  } catch(_){}
  // Emotion map: derive approximate emotion intensities if file exists
  try {
    if (fs.existsSync('emotion-latest.json')){
      const em = JSON.parse(fs.readFileSync('emotion-latest.json','utf8'));
      metrics.emotion = em;
    }
  } catch(_){}
  const res = evolve(metrics);
  console.log('[PersonalityEvolution]', JSON.stringify(res));
}

module.exports = { computeTraits, evolve };