/**
 * Payout Engine (Proportional) - OFFCHAIN ACCOUNTING STAGE
 * Computes proportional shares from share_contributors.json and prepares
 * (not yet signs) BTC / RVN payout plans. Triad consensus wrapping for execution.
 */
const fs = require('fs');
const path = require('path');
let runProtectedAction=null;try{({runProtectedAction}=require('./triad-consensus-loader'))}catch{}

const DATA_DIR = path.join(__dirname,'persistent_data');
const LEDGER_FILE = path.join(DATA_DIR,'share_contributors.json');
const PLAN_FILE = path.join(DATA_DIR,'payout_plan.json');
const INTERVAL_MS = parseInt(process.env.PAYOUT_INTERVAL_MS || '900000',10); // 15m
const MIN_THRESHOLD_BTC = parseFloat(process.env.PAYOUT_THRESHOLD_BTC || '0.00005');
const MIN_THRESHOLD_RVN = parseFloat(process.env.PAYOUT_THRESHOLD_RVN || '5');

function loadLedger(){try{return JSON.parse(fs.readFileSync(LEDGER_FILE,'utf8'))}catch{return{}}}
function savePlan(p){try{fs.writeFileSync(PLAN_FILE, JSON.stringify(p,null,2))}catch{}}

function computePlan(){
  const ledger=loadLedger();
  const totals={BTC:0,RVN:0};
  Object.values(ledger).forEach(c=>{ totals.BTC+=c.BTC.earnings; totals.RVN+=c.RVN.earnings; });
  const plan={ ts:Date.now(), totals, recipients:[], thresholds:{ BTC:MIN_THRESHOLD_BTC, RVN:MIN_THRESHOLD_RVN } };
  for(const [id,data] of Object.entries(ledger)){
    if(totals.BTC>0){ const shareB = data.BTC.earnings / totals.BTC; plan.recipients.push({ id, coin:'BTC', amount:data.BTC.earnings, ratio:shareB }); }
    if(totals.RVN>0){ const shareR = data.RVN.earnings / totals.RVN; plan.recipients.push({ id, coin:'RVN', amount:data.RVN.earnings, ratio:shareR }); }
  }
  savePlan(plan);
  return plan;
}

function clearDistributed(plan){
  // Placeholder: after actual broadcast, zero out earnings for distributed contributors above thresholds.
  try {
    const ledger=loadLedger();
    for(const r of plan.recipients){
      if(r.coin==='BTC' && r.amount >= MIN_THRESHOLD_BTC){ ledger[r.id].BTC.earnings = 0; ledger[r.id].BTC.shares = 0; }
      if(r.coin==='RVN' && r.amount >= MIN_THRESHOLD_RVN){ ledger[r.id].RVN.earnings = 0; ledger[r.id].RVN.shares = 0; }
    }
    fs.writeFileSync(LEDGER_FILE, JSON.stringify(ledger,null,2));
  } catch {}
}
function autoClearIfBroadcast(){
  try {
    const txFile = path.join(DATA_DIR,'btc_payout_txid.txt');
    if (!fs.existsSync(txFile)) return;
    const plan = JSON.parse(fs.readFileSync(PLAN_FILE,'utf8'));
    clearDistributed(plan);
    fs.unlinkSync(txFile);
    console.log('[PAYOUT] Auto-cleared after broadcast');
  } catch {}
}
setInterval(autoClearIfBroadcast,60000).unref();

async function cycle(){
  const act=()=>{ const plan=computePlan(); console.log('[PAYOUT] plan computed recipients:', plan.recipients.length); return plan; };
  if(runProtectedAction){ try{ await runProtectedAction('payout_plan_cycle', { ts:Date.now() }, act);}catch(e){ console.error('[PAYOUT] triad block', e.message);} }
  else act();
}
setInterval(cycle, INTERVAL_MS).unref();
cycle();
