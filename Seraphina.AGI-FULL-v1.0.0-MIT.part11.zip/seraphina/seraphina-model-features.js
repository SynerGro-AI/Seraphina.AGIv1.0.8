// seraphina-model-features.js
// Deterministic feature extraction from dataset entries + personality traits.
// Outputs: feature manifest & numeric vector; no randomness.

'use strict';
const crypto = require('crypto');

// Base seed vocabulary; can be extended via dynamic vocab ledger.
const BASE_VOCAB = [
  'explore','adapt','optimize','risk','safe','learn','grow','balance','profit','empathy','strategy','ethical','vision','stability','imagine'
];

const VOCAB_FILE = process.env.SERAPHINA_VOCAB_FILE || 'seraphina-model-vocab.json';
let VOCAB = BASE_VOCAB;
try {
  if (require('fs').existsSync(VOCAB_FILE)){
    const data = JSON.parse(require('fs').readFileSync(VOCAB_FILE,'utf8'));
    if (Array.isArray(data.words) && data.words.length){
      // Ensure deterministic order: unique + sorted
      const uniq = Array.from(new Set(data.words.concat(BASE_VOCAB)));
      uniq.sort();
      VOCAB = uniq;
    }
  }
} catch(e){ /* fallback to base */ }

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function textBins(dialogs){
  const counts = new Array(VOCAB.length).fill(0);
  for(const d of dialogs){
    const txt = (d.text||'').toLowerCase();
  VOCAB.forEach((w,i)=>{ const m = txt.match(new RegExp(`(^|\W)${w}(?=$|\W)`,'g')); if(m) counts[i]+=m.length; });
  }
  // Normalize counts by total tokens approximation
  const total = counts.reduce((a,b)=>a+b,0) || 1;
  return counts.map(c=> Number((c/total).toFixed(6)));
}

function personalityVector(traits){
  if(!traits) return [0,0,0,0,0];
  return [
    Number((traits.openness||0).toFixed(6)),
    Number((traits.stability||0).toFixed(6)),
    Number((traits.strategic_depth||0).toFixed(6)),
    Number((traits.ethical_alignment||0).toFixed(6)),
    Number((traits.imagination_intensity||0).toFixed(6))
  ];
}

function econVector(e){
  return [
    Number(((e.frenRevenueNorm||0)).toFixed(6)),
    Number(((e.incomeSpread||0)).toFixed(6)),
    Number(((e.acceptRatio||0)).toFixed(6))
  ];
}

function extractFeatures(entry){
  const pv = personalityVector(entry.personality);
  const ev = econVector(entry.econSignals||{});
  const tb = textBins(entry.dialogs||[]);
  const decisionCount = Number((entry.decisions? entry.decisions.length : 0));
  const decisionIntensity = Number(Math.min(1, decisionCount/50).toFixed(6));
  const vector = [...pv, ...ev, ...tb, decisionIntensity];
  // Merkle root of vocab for reproducibility (simple pairwise hash folding)
  const vocabMerkle = merkleRoot(VOCAB.map(w=> stableHash(w)));
  const manifest = {
    dims: vector.length,
    components: {
      personality: pv.length,
      econ: ev.length,
      vocabBins: tb.length,
      decisionIntensity: 1
    },
    vocab: VOCAB,
    hash: stableHash({ vocab: VOCAB }),
    vocabMerkle
  };
  return { vector, manifest };
}

function merkleRoot(leaves){
  if(!leaves.length) return stableHash('EMPTY');
  let level = leaves.slice();
  while(level.length > 1){
    const next=[];
    for(let i=0;i<level.length;i+=2){
      if(i+1<level.length) next.push(stableHash(level[i]+level[i+1])); else next.push(level[i]);
    }
    level = next;
  }
  return level[0];
}

module.exports = { extractFeatures, VOCAB, textBins, merkleRoot, BASE_VOCAB };