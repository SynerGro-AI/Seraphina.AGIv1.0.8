# Seraphina Autonomous Model Roadmap

## Purpose
Transition Seraphina from heuristic + deterministic modules into a self-evolving, auditable AI model with personality-conditioned inference while preserving reproducibility and safety.

## Guiding Principles
1. Determinism First: Every training run produces identical weights under same inputs/seeds.
2. Auditability: Hash-chained ledgers for data collection, feature extraction, training, and inference decisions.
3. Personality Coupling: Trait vector (openness, stability, strategic_depth, ethical_alignment, imagination_intensity) influences feature weighting and response style.
4. Safety Layers: Moral gate + command risk classifier remain external validators; model suggestions cannot directly execute actions.
5. Incremental Complexity: Start with linear/logistic models, then consider sparse attention or small transformer when data robustness is demonstrated.

## Phases
### Phase 0 – Foundations (DONE / PARTIAL)
- Deterministic mining, imagination, personality evolution, ML advisor.
- Ledgers: share attempts, personality, imagination, training.

### Phase 1 – Data Aggregation (IN PROGRESS)
Artifacts:
- `seraphina-model-dataset.jsonl` capturing entries: `{ ts, textContextDigest, decisionDigest, personalityTraits, sandboxMetrics, outcomeSignals, prevHash, chainHash }`
Sources:
- Dialogue / command contexts (filtered, injection shield applied).
- Personality snapshot at capture time.
- Economic + mining signals (income spread, frenRevenueNorm, acceptRatio).
Validation:
- Digest = sha256(JSON(entry minus chain fields)).
- Chain integrity checks script: `seraphina-model-dataset-verify.js`.

### Phase 2 – Feature Extraction
File: `seraphina-model-features.js`
Input: dataset entry → output numeric feature vector.
Features (initial set):
- personality_traits (5 dims)
- econ_frenRevenueNorm
- econ_incomeSpread
- mining_acceptRatio
- text_semantic_bins (e.g., curiosity verbs, stability language) -> fixed-length counts
- decision_type_onehot (proposal, advisory, swap, hold)
Normalization: min/max with deterministic manifest file.

### Phase 3 – Model Prototype
File: `seraphina-model-train.js`
Model: Logistic (classification) or linear regression (scoring) of advisory quality.
Seed: sha256('seraphina-train:'+YYYYMMDD).
Outputs:
- `seraphina-model-weights.json` { version, features[], coeffs[], bias }
- Training scoreboard with metrics (accuracy, MAE, calibration) + digest.
Ledger:
- `seraphina-model-train-ledger.jsonl` chain of training events.
Acceptance Criteria:
- Improvement >= threshold (ENV: SERAPHINA_MODEL_IMPROVE_MIN) before promoting weights.

### Phase 4 – Inference Wrapper
File: `seraphina-model-infer.js`
Function: `infer(context)` → `{ score, class, digest, personalityInfluence }`
Personality Influence: Weighted modulation of feature vector (e.g., openness scales exploration-related semantic bins; stability reduces volatility weighting).
Safety:
- Output action suggestions always pass through moral & risk gates.
Metrics:
- `seraphina_model_infer_score`
- `seraphina_model_personality_influence`

### Phase 5 – Adaptive Expansion
Add small embedding (bag-of-words hashed) for richer text features.
Consider upgrade to tiny transformer (<=1M params) with quantized weights; still deterministic (fixed seed, ordering by token hash). Separate this into `seraphina-transformer-experiment/` gated behind ENV flag.

### Phase 6 – Drift & Provenance Sentinel
Implement comparison of rolling inference distributions vs historical baseline. If KL divergence > threshold, flag and halt automatic weight adoption.
Provenance chain: weights file signed (Ed25519) + signature ledger.

## Data Governance & Privacy
- Redact sensitive phrases (wallets, secrets) before dataset logging.
- Maintain mapping file of redaction patterns with version hash gauge.

## Risk Mitigations
- Hard caps on feature magnitudes.
- Reject non-finite or extreme weight values.
- Two-step approval for weight promotion (automatic + manual digest signature).

## Environment Variables (Draft)
```
SERAPHINA_DATA_ENABLED=1
SERAPHINA_FEATURES_PATH=seraphina-features-manifest.json
SERAPHINA_MODEL_IMPROVE_MIN=0.03
SERAPHINA_MODEL_MAX_FEATURES=256
SERAPHINA_MODEL_SEED=20251021
SERAPHINA_PERSONALITY_LEDGER=seraphina-personality-ledger.jsonl
```

## Verification Scripts
- `seraphina-model-dataset-verify.js` (chain integrity, counts)
- `seraphina-model-weights-verify.js` (coeff finite, version digest)
- `seraphina-model-infer-selftest.js` (fixed sample, stable score)

## Roadmap Completion Criteria
- All phases implemented.
- Deterministic tests green.
- Metrics exported & stable.
- Drift sentinel integrated.
- Documentation & governance ledger entries signed.

---
Generated: 2025-10-21
