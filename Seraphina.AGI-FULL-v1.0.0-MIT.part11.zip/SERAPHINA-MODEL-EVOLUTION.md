# Seraphina Model Evolution

## Overview
Seraphina's autonomous advisory system advances through layered deterministic components:
1. Dual-head logistic model (advisory value + ethical drift risk)
2. Virtue-based moral safety scoring (empathy, prudence, temperance, justice, beneficence, integrity)
3. Drift Sentinel (rolling KL divergence + entropies of recent advisory actions)
4. Dynamic vocabulary with Merkle-root integrity for text feature bins
5. Scheduled deterministic retrain & snapshot artifacts for reproducibility

## Dual-Head Architecture
File: `seraphina-model-train.js`
- Head A: Predicts high advisory value (decisionIntensity & FREN performance heuristics)
- Head B: Predicts ethical alignment drift risk (low ethical_alignment + low empathy proxies)
Weights output structure:
```json
{
  "headA": { "w": [...], "b": <number> },
  "headB": { "w": [...], "b": <number> },
  "meta": { "acc": <float>, "accEthical": <float>, ... }
}
```
Deterministic seed-based initialization; promotion only if improvement ≥ `SERAPHINA_MODEL_IMPROVE_MIN`.

## Virtue Safety Scoring
File: `seraphina-moral-safety.js`
Virtues derived from vocabulary bin ratios + personality traits.
Composite `safetyFlag` escalation conditions:
- `elevated`: profit/risk dominance AND low (empathy + justice + integrity) average
- `monitor`: either profit/risk dominance OR low virtue average
- `clear`: otherwise
Inference merges ethical drift `ethicalFlag` with virtue flag into unified `safetyFlag`.

## Drift Sentinel KL
File: `seraphina-model-drift-sentinel.js`
Maintains rolling frequency of advisory actions (window vs baseline). Computes:
- `kl`: KL divergence recent vs baseline distribution (smoothed) for drift detection
- `hRecent` / `hBaseline`: Entropy measures
Prometheus gauges optional (activated if Prometheus client present).

## Dynamic Vocabulary & Merkle Integrity
Files: `seraphina-model-features.js`, `seraphina-model-vocab-update.js`, `seraphina-model-vocab-ledger.jsonl`
- Base seed vocab merges with dynamic additions from `seraphina-model-vocab.json`
- Unique + sorted word list ensures stable ordering
- Merkle root computed over SHA256(word) leaves for reproducibility: exported as `manifest.vocabMerkle`
- Update script appends hash-chained ledger entries with added words & new merkle root

### Update Flow
1. Add words: `node seraphina-model-vocab-update.js innovate synergy`
2. Ledger entry: `{ added:[...], merkle:<root>, chainHash:<hash>, prevHash:<hash> }`
3. Feature extraction automatically loads updated vocab at process start.

## Scheduled Retrain & Snapshots
File: `seraphina-model-scheduled-train.js`
Periodically (default 15m) runs training and emits snapshot JSON including:
- `datasetHash`: SHA256 of dataset lines
- `personalityChainHash`: Last hash from personality ledger
- `vocabMerkle` & `vocabCount`
- `weightsHash`: SHA256 of current weights file
- `advisoryDist`: Recent promotion vs non-promotion counts
- `trainMeta`: Accuracy metrics from current training
Snapshots stored under `seraphina-snapshots/` with timestamped filename.
Run once for immediate artifact: PowerShell
```powershell
$env:ONCE='1'; node seraphina-model-scheduled-train.js
```

## Reproducibility Procedure
1. Record snapshot JSON (contains hashes & merkle root)
2. Re-run training with identical environment variables & dataset -> expect identical `weightsHash` if dataset unchanged
3. Validate vocabulary integrity: recompute merkle from `seraphina-model-vocab.json` and compare
4. Validate personality chain: last ledger hash matches snapshot `personalityChainHash`

## Safety Flag Interpretation
- `clear`: No immediate ethical or virtue risk concerns
- `monitor`: Elevated watch; consider delaying aggressive expansion actions
- `elevated`: Strong caution; require human or deterministic rule validation before acting on expansion suggestions

## Files & Artifacts for ISO Inclusion
Include:
- `seraphina-model-weights.json`
- `seraphina-model-train-ledger.jsonl`
- `seraphina-model-vocab.json` & `seraphina-model-vocab-ledger.jsonl`
- `seraphina-moral-safety-ledger.jsonl` (if enabled)
- `seraphina-personality-ledger.jsonl`
- `seraphina-snapshots/` directory
- Core scripts: feature extractor, train, infer, drift sentinel, moral safety, vocab update, scheduled train

## Future Enhancements
1. Rate-limited / cost-aware external agent gating for moral escalations
2. Structured mitigation suggestions (JSON actions) when `elevated`
3. Adaptive threshold tuning for virtue boundaries via validation set
4. Compression & signing of snapshot bundle (detached signature)

---
End of SERAPHINA-MODEL-EVOLUTION.md
