#!/usr/bin/env node
/**
 * Address Validation Script (BTC / LTC / RVN)
 * ------------------------------------------
 * Validates configured mining / payout addresses BEFORE starting miners.
 * Targets variables in current environment (export them first if REAL_STRICT is enabled):
 *   BTC_MINING_ADDRESS, BTC_KRAKEN_ADDRESS, KRAKEN_BTC_ADDRESS
 *   LTC_KRAKEN_ADDRESS
 *   RVN_LOCAL_ADDRESS, RVN_MINING_ADDRESS, RVN_PAYOUT_ADDRESS, RVN_ADDRESS, RVN_WALLET
 * Exit codes: 0 = all pass or absent; 2 = warnings only; 3 = hard failures
 */
const crypto = require('crypto');

const CANDIDATES = [
  'BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','KRAKEN_BTC_ADDRESS',
  'LTC_KRAKEN_ADDRESS','LTC_MINING_ADDRESS',
  'RVN_LOCAL_ADDRESS','RVN_MINING_ADDRESS','RVN_PAYOUT_ADDRESS','RVN_ADDRESS','RVN_WALLET'
];

const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const base58Map = new Map([...base58Alphabet].map((c,i)=>[c,i]));

function decodeBase58(str){
  let num = BigInt(0);
  const base = BigInt(58);
  for (const ch of str){
    const val = base58Map.get(ch);
    if (val == null) throw new Error('Invalid base58 char '+ch);
    num = num * base + BigInt(val);
  }
  // Convert BigInt to byte array
  let bytes = [];
  while (num > 0){ bytes.push(Number(num % BigInt(256))); num = num / BigInt(256); }
  bytes = bytes.reverse();
  // Leading zeros
  for (const ch of str){ if (ch === '1') bytes.unshift(0); else break; }
  return Buffer.from(bytes);
}

function base58CheckDecode(str){
  const buf = decodeBase58(str);
  if (buf.length < 4) throw new Error('Too short');
  const payload = buf.slice(0, -4);
  const checksum = buf.slice(-4);
  const hash = crypto.createHash('sha256').update(crypto.createHash('sha256').update(payload).digest()).digest();
  if (!checksum.equals(hash.slice(0,4))) throw new Error('Checksum mismatch');
  return { version: payload[0], payload: payload.slice(1) };
}

function isBech32(addr){
  return /^(bc1|tb1|bcrt1|ltc1)[0-9ac-hj-np-z]{11,}$/i.test(addr); // simple structural test
}

function classifyBTC(addr){
  if (isBech32(addr)) return { ok:true, type:'bech32', network: addr.startsWith('bc1') ? 'mainnet':'other' };
  const { version } = base58CheckDecode(addr);
  if (version === 0x00) return { ok:true, type:'p2pkh', network:'mainnet' };
  if (version === 0x05) return { ok:true, type:'p2sh', network:'mainnet' };
  return { ok:false, error:'Unknown BTC version byte '+version };
}

function classifyLTC(addr){
  if (/^ltc1/i.test(addr)) return { ok:true, type:'bech32', network:'mainnet' };
  const { version } = base58CheckDecode(addr);
  if (version === 0x30) return { ok:true, type:'p2pkh', network:'mainnet' }; // L
  if (version === 0x32) return { ok:true, type:'p2sh', network:'mainnet' }; // M
  return { ok:false, error:'Unknown LTC version '+version };
}

function classifyRVN(addr){
  if (!/^R[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]{25,33}$/.test(addr)) return { ok:false, error:'Pattern mismatch' };
  const { version } = base58CheckDecode(addr);
  if (version === 0x3c) return { ok:true, type:'p2pkh', network:'mainnet' }; // 60 decimal
  return { ok:false, error:'Unexpected RVN version '+version };
}

function classify(addr, key){
  try {
    if (!addr) return { skipped:true };
    if (key.startsWith('BTC_') || key === 'KRAKEN_BTC_ADDRESS') return classifyBTC(addr);
    if (key.startsWith('LTC_')) return classifyLTC(addr);
    if (key.startsWith('RVN_')) return classifyRVN(addr);
    // Heuristic fallback: decide by first char
    if (addr.startsWith('1')||addr.startsWith('3')||addr.startsWith('b')) return classifyBTC(addr);
    if (addr.startsWith('L')||addr.startsWith('M')||addr.startsWith('l')) return classifyLTC(addr);
    if (addr.startsWith('R')) return classifyRVN(addr);
    return { ok:false, error:'Unrecognized prefix' };
  } catch(e){
    return { ok:false, error:e.message };
  }
}

const results = {};
let failures = 0, warnings = 0;
for (const key of CANDIDATES){
  const val = process.env[key];
  const res = classify(val, key);
  results[key] = { value: val||null, ...res };
  if (res.ok) continue;
  if (res.skipped) continue;
  failures++;
}

const summary = { ts: Date.now(), failures, warnings, results };
console.log(JSON.stringify(summary,null,2));
if (failures>0) process.exit(3);
process.exit(0);
