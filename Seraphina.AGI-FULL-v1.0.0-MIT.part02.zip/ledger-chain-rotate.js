// ledger-chain-rotate.js
// Convergence ledger hash chaining + rotation
'use strict';
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');
const LEDGER_PATH = process.env.CONVERGENCE_LEDGER || 'seraphina-convergence-ledger.jsonl';
const MAX_SIZE_MB = parseInt(process.env.LEDGER_MAX_MB || '5',10);
const CHUNK_SIZE = MAX_SIZE_MB * 1024 * 1024;

function stableChainHash(entry, prevHash='GENESIS'){
  const keys = Object.keys(entry).sort();
  const canonical = JSON.stringify(entry, keys);
  return crypto.createHash('sha256').update(prevHash + canonical).digest('hex');
}

function rotateIfNeeded(){
  try {
    if(!fs.existsSync(LEDGER_PATH)) return false;
    const st = fs.statSync(LEDGER_PATH);
    if(st.size <= CHUNK_SIZE) return false;
    const gzPath = LEDGER_PATH + '.gz.' + Date.now();
    return new Promise((resolve,reject)=>{
      const inp = fs.createReadStream(LEDGER_PATH);
      const out = fs.createWriteStream(gzPath);
      const gz = zlib.createGzip();
      inp.pipe(gz).pipe(out).on('finish',()=>{
        try { fs.unlinkSync(LEDGER_PATH); } catch(_){}
        resolve(gzPath);
      }).on('error',reject);
    });
  } catch(e){ console.warn('[ConvergenceLedgerRotate] error', e.message); return false; }
}

function appendWithChain(entry){
  try {
    let prevHash='GENESIS';
    if(fs.existsSync(LEDGER_PATH)){
      const lines = fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ try { prevHash = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){} }
    }
    entry.prevHash = prevHash;
    entry.chainHash = stableChainHash(entry, prevHash);
    fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n');
    const rot = rotateIfNeeded(); if(rot && typeof rot.then==='function'){ rot.then(()=>{}).catch(()=>{}); }
    return entry.chainHash;
  } catch(e){ console.warn('[ConvergenceLedger] append error', e.message); return null; }
}

module.exports = { appendWithChain };
