// dimension-ledger-verify.js
// Verifies hash chain integrity of dimension-escalation-ledger.jsonl.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const LEDGER = 'dimension-escalation-ledger.jsonl';
function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function verify(){
  if(!fs.existsSync(LEDGER)) return { exists:false, entries:0 };
  const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
  let prev = 'GENESIS';
  for(let i=0;i<lines.length;i++){
    let obj; try { obj = JSON.parse(lines[i]); } catch(e){ return { ok:false, error:'parse-failure', index:i }; }
    const expectedPrev = prev;
    if(obj.prevHash !== expectedPrev) return { ok:false, error:'prev-mismatch', index:i };
    const expectedHash = sha256(obj);
    if(obj.chainHash !== expectedHash) return { ok:false, error:'hash-mismatch', index:i };
    prev = obj.chainHash;
  }
  return { ok:true, entries: lines.length, lastHash: prev };
}

if(require.main === module){
  process.stdout.write(JSON.stringify(verify(),null,2)+'\n');
}

module.exports = { verify };
