#!/usr/bin/env bash
# Build Python from already downloaded tarball (no network) into /opt/python.
# Usage: sudo bash build-python-offline.sh Python-3.12.5.tgz
set -euo pipefail
TB=${1:-Python-3.12.5.tgz}
PREFIX=${PY_PREFIX:-/opt/python}
JOBS=${PY_BUILD_JOBS:-$(nproc || echo 4)}
if [ ! -f "$TB" ]; then echo "[ERR] Tarball $TB not found" >&2; exit 2; fi
mkdir -p /tmp/pybuild
cp "$TB" /tmp/pybuild/
cd /tmp/pybuild
rm -rf build-src
mkdir build-src
cd build-src
tar xf ../$TB
cd Python-*/
./configure --prefix=$PREFIX --enable-optimizations --with-lto || { echo "[ERR] configure failed"; exit 3; }
make -j"$JOBS"
make altinstall
ln -sf $PREFIX/bin/python3.* $PREFIX/bin/python3 || true
$PREFIX/bin/python3 -V || { echo "[ERR] Python build failed"; exit 4; }

# Minimal integrity note
# Minimal integrity note & manifest
sha256sum $(which $PREFIX/bin/python3) | tee $PREFIX/python3.binary.sha256 || true
TARBALL_SHA=$(sha256sum "$TB" | awk '{print $1}')
BIN_PATH=$(readlink -f $PREFIX/bin/python3)
BIN_SHA=$(sha256sum "$BIN_PATH" | awk '{print $1}')
CONFIG_ARGS=$(grep -E "^configured with" config.log 2>/dev/null || echo "")
cat > $PREFIX/python-build-manifest.json <<EOF
{
  "version": "$( $PREFIX/bin/python3 -c 'import sys;print(".".join(map(str, sys.version_info[:3])))' )",
  "tarball": "$TB",
  "tarballSha256": "$TARBALL_SHA",
  "binary": "$BIN_PATH",
  "binarySha256": "$BIN_SHA",
  "buildJobs": "$JOBS",
  "configureArgs": "${CONFIG_ARGS//"/\"}",
  "timestamp": $(date +%s)
}
EOF

echo "[INFO] Generating stdlib hash allowlist";
$PREFIX/bin/python3 - <<'PY'
import os, hashlib, json, sys
pybase = sys.prefix
stdlib = os.path.join(pybase, 'lib', 'python'+'.'.join(map(str, sys.version_info[:2])))
allow = {}
for root, dirs, files in os.walk(stdlib):
	for f in files:
		if f.endswith(('.py','.pyc')):
			p = os.path.join(root,f)
			try:
				with open(p,'rb') as fh:
					h=hashlib.sha256(fh.read()).hexdigest()
				rel = os.path.relpath(p, stdlib)
				allow[rel]=h
			except Exception:
				pass
out = {
  'version': sys.version.split()[0],
  'files': allow,
  'count': len(allow)
}
with open(os.path.join(pybase,'python-stdlib-hashes.json'),'w') as w:
	json.dump(out,w,indent=2)
PY

echo "[OK] Python built at $PREFIX (manifest + stdlib hashes recorded)"
