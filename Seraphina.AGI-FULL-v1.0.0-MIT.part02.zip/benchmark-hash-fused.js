// benchmark-hash-fused.js
// Measures performance of fused single-header and batch double SHA256 vs pure JS double SHA256.
const crypto = require('crypto');
const { performance } = require('perf_hooks');

function doubleSha256Buf(b){ const h1 = crypto.createHash('sha256').update(b).digest(); return crypto.createHash('sha256').update(h1).digest(); }

function randomHeader(){ return crypto.randomBytes(80); }

async function main(){
  const ITER = parseInt(process.env.BENCH_FUSED_ITER || '50000',10);
  const BATCH = parseInt(process.env.BENCH_FUSED_BATCH || '256',10);
  const headers = Array.from({length: ITER}, ()=> randomHeader());
  // JS baseline
  let t0 = performance.now();
  let acc = 0; for (const h of headers){ acc ^= doubleSha256Buf(h)[0]; }
  let t1 = performance.now();
  const jsMs = t1 - t0;
  let fused=null; let fusedAvail=false;
  try { fused = require('./fused_wasm.js'); await fused.initFused(); fusedAvail=true; } catch(e){ console.warn('[bench] fused unavailable:', e.message); }
  if (!fusedAvail){
    console.table([{ mode:'js-double', iter:ITER, ms:jsMs.toFixed(2), khs: (ITER/(jsMs/1000)/1000).toFixed(2) }]);
    return;
  }
  // Single header fused calls
  t0 = performance.now(); acc = 0; for (const h of headers){ acc ^= fused.doubleSha256Header(h)[0]; }
  t1 = performance.now(); const fusedSingleMs = t1 - t0;
  // Batch fused
  t0 = performance.now(); acc = 0; for (let i=0;i<headers.length;i+=BATCH){ const slice = headers.slice(i,i+BATCH); const outs = fused.doubleSha256Batch(slice); for (const d of outs) acc ^= d[0]; }
  t1 = performance.now(); const fusedBatchMs = t1 - t0;
  console.table([
    { mode:'js-double', iter:ITER, ms: jsMs.toFixed(2), khs: (ITER/(jsMs/1000)/1000).toFixed(2) },
    { mode:'fused-single', iter:ITER, ms: fusedSingleMs.toFixed(2), khs: (ITER/(fusedSingleMs/1000)/1000).toFixed(2) },
    { mode:'fused-batch', iter:ITER, batch:BATCH, ms: fusedBatchMs.toFixed(2), khs: (ITER/(fusedBatchMs/1000)/1000).toFixed(2) }
  ]);
  const speedupSingle = (jsMs / fusedSingleMs).toFixed(3);
  const speedupBatch = (jsMs / fusedBatchMs).toFixed(3);
  console.log(`Speedup fused single: ${speedupSingle}x | fused batch: ${speedupBatch}x (batch=${BATCH}) over ${ITER} headers`);
}

if (require.main === module){ main(); }