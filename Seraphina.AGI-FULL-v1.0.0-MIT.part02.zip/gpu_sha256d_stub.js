// gpu_sha256d_stub.js
// Scaffold for GPU acceleration (placeholder). Attempts to load native addon or OpenCL binding.
// Fallback to null if unavailable. Provides parity-tested batch hashing API shape.

let backend = null;
let available = false;

try {
  // Attempt to load optional native module (to be built later): ./build/Release/gpushash.node
  backend = require('./build/Release/gpushash.node');
  if (backend && typeof backend.hashHeaders === 'function') available = true;
} catch(_){
  // Try optional opencl package if user installs it later
  try {
    const opencl = require('opencl');
    // Placeholder: would compile kernel and provide hashHeaders(batchBuffers)
    // Not implemented yet to avoid shipping heavy dependencies.
    backend = null; // mark not implemented
  } catch(_ignored){ }
}

module.exports = {
  available,
  hashHeaders(batch) {
    if (!available || !backend) throw new Error('GPU backend not available');
    return backend.hashHeaders(batch); // expects array<Buffer> -> array<Buffer(32)>
  }
};
