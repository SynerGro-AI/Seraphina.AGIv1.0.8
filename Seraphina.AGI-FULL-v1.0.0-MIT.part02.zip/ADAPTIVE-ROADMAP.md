# Adaptive Roadmap (Deterministic Evolution)

## Phase Summary
| Phase | Focus | Determinism Anchor | Audit Artifacts |
|-------|-------|--------------------|-----------------|
| P0 | Baseline deterministic mining | Seeded PRNG, logical time | Share ledger, reproducibility digest |
| P1 | Economic recommendation + wallet validation | Hysteresis + hash tie-breaker | Income metrics, wallet verify logs |
| P2 | DNS/time sandbox & combined digest | Holodeck virtualization chain | DNS stats digest, merged repro summary |
| P3 | Integrity artifacts (SBOM, latency snapshot) | Hash of curated file set | `sbom.json`, latency hash |
| P4 | Wallet companion advisory | HMAC/digest suggestions | `companion-suggestions.jsonl` ledger |
| P5 | Policy engine gating | Hash-chained decision ledger | Policy decision log (stdout) |
| P6 | Trading advisory module | Signal hash chain | Trade signal logs + metrics |
| P7 | Runtime bias overrides + AB eval | Snapshot + rollback hash events | Bias snapshot log, AB pass/rollback logs |
| P8 | Structured adaptive metrics & future ML hooks | Prometheus registries | Extended gauge set |
| P9 | Strategy A/B (latency-weight) | Deterministic dual-ledger (trade-ab-ledger.jsonl) | A/B trade ledger, spread metrics |
| P10 | Parameter governance | Deterministic quorum hash mod | governance-proposals.jsonl, governance-decisions.jsonl |
| P11 | ML advisor stub | Static quantized weights + hash digest | ML advisor stdout, mlAdvisorScore/action metrics |
| P12 | Ledger chain integrity verify | Hash recompute vs stored chainHash | ledger-verify.json summary, per-ledger ok flags |
| P13 | Dynamic volatility threshold | Rolling spread std dev scaling | Trading signal volatility + threshold metrics |
| P14 | External ML weights versioning | SHA256(version+vector) | mlWeightsVersionHash, weights file SBOM entry |

## Current Completed Phases
Up to P11 implemented (governance engine, trading A/B, ML advisor stub integrated). Future work: full quantized model integration, enhanced governance proposal types.

## Design Principles
1. Deterministic First: Any new adaptive feature must produce identical outputs under identical inputs.
2. Hash Chain Everywhere: Suggestions, decisions, signals form append-only verifiable chains.
3. Human/Policy Mediation: No direct execution of external agent outputs; policy engine enforces bounds.
4. Measured Risk: Adjustments limited by cooldowns, deltas, evaluation windows with rollback criteria.
5. Observable & Exportable: Prometheus metrics for every adaptive dimension (bias, spread, confidence).

## Roadmap Details
### Phase P9 (Planned): Multi-Variant Strategy Evaluation
- Run A/B strategy scoring concurrently (e.g., latency penalty vs raw income).
- Deterministic allocation: fixed cycle alternation; compare acceptance & income; hash summary; promote if sustained > threshold.

### Phase P15 (Planned): Risk Envelope Auto-Tuning
- Acceptance volatility + latency drift models produce envelope; bias deltas narrowed when outside envelope until stability regained.

## Rollback Triggers
| Trigger | Condition | Action |
|---------|-----------|--------|
| Acceptance degradation | acceptanceDelta < threshold | Revert bias snapshot |
| Income collapse | topIncomeRatio < threshold | Revert bias snapshot |
| Excess swap churn | swaps/hour > cap | Force hold for cooldown window |
| Latency route instability | median latency variance > limit | Apply latency penalty multiplier |

## Artifacts & Verification
- Companion Ledger: `companion-suggestions.jsonl`
- Policy Decisions: stdout `[POLICY]` lines (hash prefix)
- Trading Signals: stdout `[TRADING]` lines
- Bias Snapshots / AB: stdout `[RUNTIME_BIAS]` & `[AB]` lines
- Repro Summary: `repro-summary.json` (from existing scripts)
- ISO Manifest: embedded hash manifest + SBOM

## Usage Flags (Recap)
```
WALLET_COMPANION=1
WALLET_COMPANION_POLICY=1
ECON_POLICY_APPLY=1
TRADING_ENGINE=1
ECON_RUNTIME_BIAS_ENABLE=1
ECON_RUNTIME_BIAS_PATH=econ-runtime-bias.json
AB_EVAL_WINDOW_MS=180000
AB_ROLLBACK_ACCEPT_DELTA=-0.04
AB_ROLLBACK_INCOME_RATIO=0.92
```

## Safe Extension Checklist
1. Add feature behind env flag (off by default).
2. Implement deterministic logic with tie-break hashing.
3. Create ledger/metric outputs.
4. Add rollback & cooldown parameters.
5. Document environment variables.
6. Integrate into ISO/SBOM if static code.
7. Re-run reproducibility harness twice to confirm identical digests.

## Open Items
- Governance proposal ledger enhancements (parameter categories, multi-field updates).
- Deterministic full ML model integration (quantized GGUF with version gating).
- Extended A/B multi-strategy evaluation (latency-weight + volatility-adaptive hybrid).

---
End of ADAPTIVE-ROADMAP.md.
