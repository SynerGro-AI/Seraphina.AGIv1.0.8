// autoinstall-pack.js
// Generates a cloud-init seed (user-data/meta-data) and bundles current mining sources for unattended install.
// Usage: node autoinstall-pack.js --out=autoinstall-bundle --pool=stratum+tcp://POOL:3333 --user=WALLET --pass=x

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const args = process.argv.slice(2);
function arg(name, def){ const a=args.find(x=>x.startsWith(`--${name}=`)); return a? a.split('=')[1]: def; }
const outDir = arg('out','autoinstall-bundle');
const pool = arg('pool','stratum+tcp://example:3333');
const user = arg('user','wallet.worker');
const pass = arg('pass','x');
const instances = parseInt(arg('instances','8'),10);
const seed = parseInt(arg('base-seed','7000'),10);

if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive:true });

// Basic SHA512 password hash placeholder (user should replace with secure hash)
function sha512(pass){ return crypto.createHash('sha512').update(pass).digest('hex'); }
const passwordHash = sha512('miner');

const userData = `#cloud-config
autoinstall:
  version: 1
  identity:
    hostname: aurrelia-node
    username: miner
    password: "${passwordHash}"
  ssh:
    install-server: true
    allow-pw: true
  storage:
    layout: { name: direct }
  packages:
    - curl
    - git
    - build-essential
    - ca-certificates
    - nodejs
  late-commands:
    - curtin in-target --target=/target -- bash -c 'curl -fsSL https://deb.nodesource.com/setup_20.x | bash -'
    - curtin in-target --target=/target -- bash -c 'apt-get install -y nodejs'
    - curtin in-target --target=/target -- bash -c 'mkdir -p /opt/aurrelia && chown miner:miner /opt/aurrelia'
    - curtin in-target --target=/target -- bash -c 'tar -xf /cdrom/aurrelia-src.tar -C /opt/aurrelia'
    - curtin in-target --target=/target -- bash -c 'cat >/etc/systemd/system/aurrelia-cluster.service <<EOF\n[Unit]\nDescription=Aurrelia Cluster Miner\nAfter=network-online.target\n[Service]\nUser=miner\nWorkingDirectory=/opt/aurrelia\nEnvironment=AUR_HBUS_UDP=1 HBUS_VOTING=1 MULTI_HARMONIC=1 WORKERS=1\nExecStart=/usr/bin/node aurrelia-cluster.js --instances=${instances} --base-seed=${seed} -- --multi-harmonic --algo=sha256d --url=${pool} --user=${user} --pass=${pass}\nRestart=always\n[Install]\nWantedBy=multi-user.target\nEOF'
    - curtin in-target --target=/target -- bash -c 'systemctl enable aurrelia-cluster.service'
  user-data:
    disable_root: true
`;
const metaData = 'instance-id: aurrelia-1\n';
fs.writeFileSync(path.join(outDir,'user-data'), userData);
fs.writeFileSync(path.join(outDir,'meta-data'), metaData);

// Bundle sources
const tarName = path.join(outDir,'aurrelia-src.tar');
try {
  // Minimal naive tar (no compression) for portability
  const { execSync } = require('child_process');
  execSync(`tar -cf ${tarName} *.js proto *.json`, { stdio:'inherit' });
} catch(e){ console.warn('[Pack] tar creation failed (ensure tar available):', e.message); }

console.log('[Pack] Autoinstall bundle created at', outDir);
