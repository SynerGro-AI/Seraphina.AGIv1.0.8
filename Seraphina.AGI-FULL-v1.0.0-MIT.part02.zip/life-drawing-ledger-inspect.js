// life-drawing-ledger-inspect.js
// Filters session ledger by score/time window.
'use strict';
const fs = require('fs');
const path = require('path');

function loadSessions(){
  const ledgerPath = path.join(__dirname,'life-drawing-session-ledger.jsonl');
  if(!fs.existsSync(ledgerPath)) return [];
  return fs.readFileSync(ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch(_){return null;} }).filter(Boolean);
}

function inspect({ minScore=0, maxScore=Infinity, sinceMs=0, limit=50 }){
  const sessions = loadSessions();
  const filtered = sessions.filter(s=> s.totalScore>=minScore && s.totalScore<=maxScore && s.ts>=sinceMs);
  filtered.sort((a,b)=> b.ts - a.ts);
  return { count: filtered.length, sessions: filtered.slice(0,limit) };
}

if(require.main === module){
  const args = process.argv.slice(2);
  const params = {};
  args.forEach(a=>{
    const [k,v] = a.split('=');
    if(k==='minScore') params.minScore = parseFloat(v);
    if(k==='maxScore') params.maxScore = parseFloat(v);
    if(k==='sinceHours'){ params.sinceMs = Date.now() - (parseFloat(v)||0)*3600000; }
    if(k==='limit') params.limit = parseInt(v,10);
  });
  process.stdout.write(JSON.stringify(inspect(params),null,2)+'\n');
}

module.exports = { inspect };
