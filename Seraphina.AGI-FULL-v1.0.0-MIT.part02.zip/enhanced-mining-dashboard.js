// REAL_ONLY_NEUTRALIZED: enhanced-mining-dashboard.js
'use strict';
module.exports = new Proxy({}, { get(){ throw new Error('enhanced mining dashboard removed (no simulation economics)'); } });