// coral-advisor.js
// Lightweight IPC/ML advisory scaffold. Deterministic digest fallback when no real model.
// Exports: advise(features) -> { digest, deltaPrune }

const crypto = require('crypto');

// Async child process model stub – deterministic fallback.
const { spawn } = require('child_process');
let child=null; let childReady=false; let queue=[]; let childBootTried=false;

function bootChild(){
  if (child || childBootTried) return; childBootTried=true;
  const script = `process.stdin.setEncoding('utf8');let buf='';process.stdin.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);if(!line.trim())continue;let o;try{o=JSON.parse(line);}catch(e){continue;}const f=o.feat||{};let dp=0;if(f.rankProxy>1.15&&f.signVar>=0.9)dp+=0.05; if(f.rankProxy<0.98)dp-=0.05; if(f.chernVar>0.03 && dp>0) dp=0; const out={ id:o.id, deltaPrune:dp }; process.stdout.write(JSON.stringify(out)+'\n');}});`;
  try {
    child = spawn(process.execPath,['-e',script],{ stdio:['pipe','pipe','inherit'] });
    child.stdout.setEncoding('utf8');
    let outBuf='';
    child.stdout.on('data',d=>{
      outBuf+=d; let idx; while((idx=outBuf.indexOf('\n'))>=0){
        const line = outBuf.slice(0,idx); outBuf = outBuf.slice(idx+1);
        if(!line.trim()) continue; let msg; try { msg=JSON.parse(line); } catch(_){ continue; }
        const pending = queue.find(q=>q.id===msg.id); if (pending){ pending.resolve({ digest: pending.digest, deltaPrune: msg.deltaPrune }); queue = queue.filter(q=>q!==pending); }
      }
    });
    child.on('exit',()=>{ child=null; childReady=false; });
    childReady=true;
  } catch(e){ child=null; childReady=false; }
}

function stableDigest(obj){ return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex').slice(0,16); }

async function advise(feat){
  const digest = stableDigest(feat);
  if (process.env.CORAL_CHILD==='0'){
    return heuristic(feat, digest);
  }
  bootChild();
  if (!childReady){
    return heuristic(feat, digest);
  }
  return new Promise(resolve=>{
  const { deriveHex } = require('./deterministic-util');
  const id = deriveHex('coral-id', Date.now(), adviceType).slice(0,8);
    const timer = setTimeout(()=>{
      // timeout fallback
      queue = queue.filter(q=>q.id!==id);
      resolve(heuristic(feat, digest));
    }, 250).unref();
    queue.push({ id, resolve:(v)=>{ clearTimeout(timer); resolve(v); }, digest });
    try { child.stdin.write(JSON.stringify({ id, feat })+'\n'); } catch(_){ resolve(heuristic(feat,digest)); }
  });
}

function heuristic(feat, digest){
  let deltaPrune=0;
  if (typeof feat.rankProxy==='number' && typeof feat.signVar==='number'){
    if (feat.rankProxy > 1.15 && feat.signVar >= 0.90) deltaPrune += 0.05;
    if (feat.rankProxy < 0.98) deltaPrune -= 0.05;
  }
  if (typeof feat.chernVar==='number' && feat.chernVar > 0.03 && deltaPrune>0){ deltaPrune = 0; }
  return { digest, deltaPrune };
}

module.exports = { advise };
