#!/usr/bin/env node
// Monitoring wrapper: runs audit-all, keeps previous chain-tips snapshot, diffs tips, emits concise status line.
const { execSync } = require('child_process');
const fs = require('fs');
// Rate limiting: prevent overly frequent runs if scheduled aggressively.
try {
  const minInterval = parseInt(process.env.AUDIT_MONITOR_MIN_INTERVAL_MS||'0',10);
  if (minInterval > 0){
    const stampFile = '.audit-monitor-last';
    const now = Date.now();
    let prevTs = 0;
    if(fs.existsSync(stampFile)){
      try { prevTs = parseInt(fs.readFileSync(stampFile,'utf8').trim(),10)||0; } catch{}
    }
    if(prevTs && (now - prevTs) < minInterval){
      console.log('[AUDIT_MONITOR] rate_limited interval_ms='+(now - prevTs)+' required='+minInterval);
      process.exit(0); // treat as success; metrics unaffected
    }
    try { fs.writeFileSync(stampFile, String(now)); } catch{}
  }
} catch(_e){ /* ignore rate limit errors */ }
function run(cmd){ try { return execSync(cmd,{stdio:'pipe'}).toString(); } catch(e){ return e.stdout?.toString()||e.message; } }
const prevTipsPath = 'chain-tips-prev.json';
if(!fs.existsSync(prevTipsPath) && fs.existsSync('chain-tips.json')){ fs.copyFileSync('chain-tips.json', prevTipsPath); }
const auditOut = run('node audit-all.js');
let report=null; try { report = JSON.parse(auditOut); } catch{}
if(fs.existsSync('chain-tips.json')){
  try { if(fs.existsSync(prevTipsPath)){ const diffOut = run(`node diff-chain-tips.js ${prevTipsPath} chain-tips.json`); console.log('[CHAIN_TIPS_DIFF]', diffOut.trim()); } } catch(e){ console.log('[CHAIN_TIPS_DIFF_ERROR]', e.message); }
  try { fs.copyFileSync('chain-tips.json', prevTipsPath); } catch{}
}
if(report){
  const status = [
    'verification='+report.verification,
    'auditMatch='+(report.auditRootMatches===true?'1':report.auditRootMatches===false?'0':'?'),
    'envChainOk='+(report.environmentChainOk?'1':'0'),
    'hmac='+(report.hmacPresent?'1':'0'),
    'snapshots='+report.environmentSnapshots
  ].join(' ');
  console.log('[AUDIT_MONITOR]', status);
  if(report.verification==='FAIL_AUDIT_ROOT_MISMATCH') process.exit(2);
  if(report.verification!=='OK') process.exit(1);
  process.exit(0);
} else {
  console.log('[AUDIT_MONITOR] report_parse_failure');
  process.exit(1);
}
