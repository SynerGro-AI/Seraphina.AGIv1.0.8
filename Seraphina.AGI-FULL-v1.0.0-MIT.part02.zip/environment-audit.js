/**
 * Environment Audit & Snapshot Chain
 * ----------------------------------------------------------
 * Provides: auditEnvironment()
 *  - In REAL_STRICT mode aborts if a .env file exists (no implicit config)
 *  - Hashes critical configuration/environment values (SHA256) and logs
 *  - Writes an append-only snapshot line to persistent_data/environment_snapshot.chain
 *    Each line: { hash: <sha256(data json)>, data: { ts, pid, strict, critical:{KEY:{present,len,sha256}} } }
 *  - NEVER logs raw secret values; only presence, length and hash.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { getDataFilePath, ensureDataDirectory } = require('./data-paths');

let DEFAULT_CRITICAL_KEYS = [
  'REAL_STRICT','DISABLE_DOTENV',
  'BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','KRAKEN_BTC_ADDRESS',
  'RVN_LOCAL_ADDRESS','RVN_MINING_ADDRESS','RVN_PAYOUT_ADDRESS',
  'RPC_BTC_URL','RPC_BTC_USER','RPC_BTC_PASS',
  'RPC_RVN_URL','RPC_RVN_USER','RPC_RVN_PASS',
  'VAULT_PASS','SIMPLESWAP_API_KEY','SIMPLESWAP_MODE',
  'HASHER_ENDPOINT','SWAP_PROVIDER',
  'BTC_FEE_TARGET_CONF','BTC_FEE_MIN_SATS_VB','RVN_SPEND_THRESHOLD',
  'RVN_SWAP_THRESHOLD','RVN_SPEND_POLL_MS','BTC_CONFIRM_POLL_MS',
  'ANCHOR_INTERVAL_MS','KAWPOW_NATIVE_MODULE','EXTERNAL_KAWPOW_MINER',
  'EXTERNAL_KAWPOW_ARGS','TRIAD_CONFIG_HASH','TRIAD_GOV_MODE'
];

// Mining-only mode: allow suppression of governance/triad and kawpow noise
const MINING_MODE = process.env.MINING_MODE === '1';
const STRIP_TRIAD = process.env.STRIP_TRIAD === '1';
const FOCUS_RVN_FREN = process.env.FOCUS_RVN_FREN === '1';
if (MINING_MODE || STRIP_TRIAD) {
  DEFAULT_CRITICAL_KEYS = DEFAULT_CRITICAL_KEYS.filter(k => !k.startsWith('TRIAD_') && !k.startsWith('KAWPOW') && k !== 'EXTERNAL_KAWPOW_MINER' && k !== 'EXTERNAL_KAWPOW_ARGS');
}

// Focus mode: keep only keys relevant to RVN/FREN operation (drop BTC/LTC swap & fee noise)
if (FOCUS_RVN_FREN) {
  const keepPrefixes = ['REAL_STRICT','DISABLE_DOTENV','RVN_','VAULT_PASS','SIMPLESWAP','HASHER_ENDPOINT','SWAP_PROVIDER'];
  DEFAULT_CRITICAL_KEYS = DEFAULT_CRITICAL_KEYS.filter(k => keepPrefixes.some(p=>k.startsWith(p)));
}

function sha256Hex(str){
  return crypto.createHash('sha256').update(String(str)).digest('hex');
}

function auditEnvironment(opts={}){
  const {
    criticalKeys = DEFAULT_CRITICAL_KEYS,
  chainFile = getDataFilePath('environment_snapshot.chain'),
    abortOnDotenvInStrict = true
  } = opts;

  const strict = process.env.REAL_STRICT === '1';
  const rootDir = __dirname; // project root (this file placed at root)
  const dotEnvPath = path.join(rootDir,'.env');
  const dotEnvExists = fs.existsSync(dotEnvPath);

  const allowDotenv = process.env.ALLOW_DOTENV_IN_STRICT === '1';
  if (strict && abortOnDotenvInStrict && dotEnvExists && !allowDotenv) {
    console.error('[ENV_AUDIT_FAIL] REAL_STRICT=1 and .env file detected -> ABORT to enforce explicit runtime configuration (set ALLOW_DOTENV_IN_STRICT=1 to bypass)');
    throw new Error('REAL_STRICT_DOTENV_BLOCK');
  } else if (strict && dotEnvExists && allowDotenv) {
    console.log('[ENV_AUDIT] STRICT override: .env present but allowed via ALLOW_DOTENV_IN_STRICT=1');
  }

  const critical = {};
  for (const key of criticalKeys) {
    if (!(key in process.env) || process.env[key] === undefined) {
      critical[key] = { present:false };
      continue;
    }
    const val = process.env[key];
    critical[key] = {
      present:true,
      len: val.length,
      sha256: sha256Hex(val)
    };
  }

  // Hash OctaLang triad core files if present
  const octaFiles = ['CORE_FILE.octa','CORE_FILE1.octa','seraphina-triad-security-core.octa']
    .filter(f=>fs.existsSync(path.join(__dirname,f)));
  const octaHashes = {};
  for (const f of octaFiles) {
    try {
      const content = fs.readFileSync(path.join(__dirname,f));
      octaHashes[f] = sha256Hex(content);
    } catch {}
  }

  // Build snapshot
  const snapshot = {
    ts: Date.now(),
    pid: process.pid,
    strict,
    hostname: safeHostname(),
    octaHashes,
    critical
  };

  // Concatenated octa hash signature (sorted deterministic order)
  const octaConcat = Object.entries(octaHashes).sort((a,b)=>a[0].localeCompare(b[0]))
    .map(([f,h])=>f+':'+h).join('|');
  let octaHashSignature = null;
  try {
    if (octaConcat && process.env.VAULT_PASS && (process.env.VAULT_OCTA_SIGN_LABEL || process.env.VAULT_SIGN_LABEL)) {
      const label = process.env.VAULT_OCTA_SIGN_LABEL || process.env.VAULT_SIGN_LABEL;
      const { loadVault } = require('./seraphina-key-vault');
      const vault = loadVault(process.env.VAULT_PASS);
      if (vault[label] && vault[label].value) {
        const keyHex = vault[label].value.trim();
        if (/^[0-9a-fA-F]{128}$/.test(keyHex)) {
          try {
            const privateKey = crypto.createPrivateKey({ key: Buffer.from(keyHex,'hex'), format:'der', type:'pkcs8' });
            octaHashSignature = crypto.sign(null, Buffer.from(octaConcat), privateKey).toString('hex');
          } catch (e) { console.error('[ENV_AUDIT] Octa hash signing failed:', e.message); }
        }
      }
    }
  } catch (e) { console.error('[ENV_AUDIT] Octa signature attempt failed:', e.message); }
  snapshot.octaHashSignature = octaHashSignature;

  // Ensure directory exists
  try { fs.mkdirSync(path.dirname(chainFile), { recursive:true }); } catch {}
  const raw = JSON.stringify(snapshot);
  const dataHash = sha256Hex(raw);
  let signature = null;
  // Optional signing using ed25519 key from vault (ensureEd25519Key may have created it earlier)
  try {
    const label = process.env.VAULT_SIGN_LABEL || process.env.VAULT_OCTA_SIGN_LABEL;
    if (label && process.env.VAULT_PASS) {
      const { loadVaultSafe } = require('./seraphina-key-vault');
      const vault = loadVaultSafe(process.env.VAULT_PASS);
      const rec = vault[label];
      if (rec && rec.privateHex && rec.type === 'ed25519') {
        try {
          const privateKey = crypto.createPrivateKey({ key: Buffer.from(rec.privateHex,'hex'), format:'der', type:'pkcs8' });
          signature = crypto.sign(null, Buffer.from(raw), privateKey).toString('hex');
        } catch (e) { console.error('[ENV_AUDIT] Ed25519 sign failed:', e.message); }
      }
    }
  } catch (e) { console.error('[ENV_AUDIT] Signing attempt failed:', e.message); }
  const line = JSON.stringify({ hash: dataHash, sig: signature, data: snapshot });
  try { fs.appendFileSync(chainFile, line+'\n'); } catch (e) {
    console.error('[ENV_AUDIT] Failed to append snapshot:', e.message);
  }

  console.log('[ENV_AUDIT] SNAPSHOT hash='+dataHash+' strict='+strict+' criticalKeys='+criticalKeys.length);
  if (octaConcat) {
    console.log('[ENV_AUDIT] OCTA_HASH_CONCAT sha256='+sha256Hex(octaConcat)+' signed='+(!!octaHashSignature));
    Object.entries(octaHashes).forEach(([f,h])=>console.log(`[ENV_AUDIT] OCTA_FILE ${f} sha256=${h}`));
  }
  for (const key of criticalKeys) {
    const entry = critical[key];
    if (entry.present) {
      console.log(`[ENV_AUDIT] ${key} present len=${entry.len} sha256=${entry.sha256}`);
    } else {
      // Suppress TRIAD/KAWPOW related missing logs in stripped mining mode
      if ((MINING_MODE || STRIP_TRIAD) && (key.startsWith('TRIAD_') || key.startsWith('KAWPOW') || key.startsWith('EXTERNAL_KAWPOW'))) continue;
      console.log(`[ENV_AUDIT] ${key} MISSING`);
    }
  }

  return { hash:dataHash, snapshot, signature };
}

function verifyChain(chainFile = getDataFilePath('environment_snapshot.chain')) {
  let lines=[]; try { lines = fs.readFileSync(chainFile,'utf8').trim().split('\n').filter(Boolean);} catch { return { ok:false, error:'CHAIN_FILE_MISSING' }; }
  const results=[]; let allValid=true;
  for (const ln of lines) {
    try {
      const obj = JSON.parse(ln);
      const raw = JSON.stringify(obj.data);
      const expectHash = sha256Hex(raw);
      const hashMatch = (expectHash === obj.hash);
      results.push({ ts: obj.data.ts, pid: obj.data.pid, hash: obj.hash, hashMatch, strict: obj.data.strict });
      if(!hashMatch) allValid=false;
    } catch (e) {
      results.push({ parseError: e.message });
      allValid=false;
    }
  }
  return { ok: allValid, entries: results, total: results.length };
}

function safeHostname(){
  try { return require('os').hostname(); } catch { return 'unknown-host'; }
}

module.exports = { auditEnvironment, verifyChain, DEFAULT_CRITICAL_KEYS };
