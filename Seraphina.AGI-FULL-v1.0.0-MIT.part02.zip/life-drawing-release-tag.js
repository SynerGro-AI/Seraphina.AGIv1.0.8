#!/usr/bin/env node
// life-drawing-release-tag.js
// Deterministic semantic version tagging and release log entry.
// No git actions; maintains local JSON log for safety until governance matures.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const RELEASE_LOG = path.join(__dirname,'life-drawing-releases.json');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function loadLog(){
  if(!fs.existsSync(RELEASE_LOG)) return { entries: [] };
  try { return JSON.parse(fs.readFileSync(RELEASE_LOG,'utf8')); } catch(e){ return { entries: [] }; }
}

function nextVersion(prev){
  // prev like 0.1.3
  if(!prev) return '0.1.0';
  const parts = prev.split('.').map(n=> parseInt(n,10));
  if(parts.length!==3 || parts.some(isNaN)) return '0.1.0';
  // deterministic policy: increment patch if <10 releases today, otherwise minor bump.
  const date = new Date().toISOString().slice(0,10); // YYYY-MM-DD
  const todayCount = loadLog().entries.filter(e=> e.date === date).length;
  if(todayCount < 10){
    parts[2] += 1;
  } else {
    parts[1] += 1; parts[2] = 0;
  }
  return parts.join('.');
}

function main(){
  const args = process.argv.slice(2);
  const force = args.find(a=> a.startsWith('--force='));
  const log = loadLog();
  const latest = log.entries.length? log.entries[log.entries.length-1].version : null;
  const version = force? force.split('=')[1] : nextVersion(latest);
  // Optional embed manifest digest if exists
  const manifestPath = path.join(__dirname,'life-drawing-analytics-manifest.json');
  let manifestDigest = null;
  if(fs.existsSync(manifestPath)){
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8'));
      manifestDigest = manifest.digest || sha256(manifest); // fallback digest
    } catch(_){ }
  }
  const date = new Date().toISOString().slice(0,10);
  const entry = { date, version, manifestDigest, id: sha256(date+'|'+version).slice(0,16) };
  log.entries.push(entry);
  fs.writeFileSync(RELEASE_LOG, JSON.stringify(log,null,2));
  // Append to CHANGELOG.md
  try {
    const changelogPath = path.join(__dirname,'CHANGELOG.md');
    let block = `\n### ${date} Release ${version}\n- manifestDigest: ${manifestDigest || 'none'}\n- id: ${entry.id}\n`;
    if(fs.existsSync(changelogPath)){
      fs.appendFileSync(changelogPath, block);
    }
  } catch(_){ }
  console.log(JSON.stringify({ ok:true, version, manifestDigest, total: log.entries.length }, null, 2));
}

if(require.main === module){
  main();
}

module.exports = { nextVersion, loadLog };
