// agent-rate-limiter.js
// Token bucket wrapper for global.__AUR_AGENT_INVOKE__
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const RATE_VAR = 'AGENT_MAX_CALLS_MIN';
const MAX_CALLS = parseInt(process.env[RATE_VAR] || '5',10);
const REJECT_LEDGER = process.env.AGENT_REJECT_LEDGER || 'agent-rejects.jsonl';

class RateLimiter {
  constructor(invoke){
    this.invoke = invoke;
    this.tokens = MAX_CALLS;
    this.lastRefill = Date.now();
    this.chainHash = crypto.createHash('sha256').update('agent-limiter-genesis').digest('hex');
  }
  refill(){
    const now = Date.now();
    const elapsedMin = (now - this.lastRefill)/60000;
    if(elapsedMin > 0){
      this.tokens = Math.min(MAX_CALLS, this.tokens + elapsedMin*MAX_CALLS);
      this.lastRefill = now;
    }
  }
  appendReject(entry){
    try { fs.appendFileSync(REJECT_LEDGER, JSON.stringify(entry)+'\n'); } catch(e){ /* non-fatal */ }
  }
  async call(role, prompt, context){
    this.refill();
    if(this.tokens < 1){
      const reject = { ts:Date.now(), role, tokens:this.tokens, reason:'rate-limit', prevHash:this.chainHash };
      reject.chainHash = crypto.createHash('sha256').update(JSON.stringify(reject)).digest('hex');
      this.chainHash = reject.chainHash;
      this.appendReject(reject);
      return { rejected:true, reason:'rate-limit', retryInMs: 60000 - (Date.now()-this.lastRefill) };
    }
    this.tokens -= 1;
    return this.invoke(role, prompt, context);
  }
}

function wrapGlobal(){
  if(global.__AUR_AGENT_INVOKE__ && !global.__AUR_AGENT_INVOKE_WRAPPED__){
    const rl = new RateLimiter(global.__AUR_AGENT_INVOKE__);
    global.__AUR_AGENT_INVOKE__WRAPPED__ = rl;
    global.__AUR_AGENT_INVOKE__ = function(role,prompt,context){ return rl.call(role,prompt,context); };
    console.log('[AgentRateLimiter] Wrapped global invoke (max '+MAX_CALLS+' calls/min)');
  }
}

if(require.main === module){ wrapGlobal(); }
module.exports = { RateLimiter, wrapGlobal };
