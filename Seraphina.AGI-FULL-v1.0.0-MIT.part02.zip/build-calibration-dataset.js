// build-calibration-dataset.js
// Produces calibration dataset mixing original feature vectors with virtue & drift context for threshold tuning.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { extractFeatures } = require('./seraphina-model-features.js');
const DATASET = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
const MORAL_LEDGER = process.env.SERAPHINA_MORAL_SAFETY_LEDGER || 'seraphina-moral-safety-ledger.jsonl';
const DRIFT_LEDGER = process.env.SERAPHINA_DRIFT_LEDGER || 'seraphina-drift-ledger.jsonl';
const OUT = process.env.SERAPHINA_CALIBRATION_DATASET || 'seraphina-calibration-dataset.jsonl';

function readLines(p){ if(!fs.existsSync(p)) return []; return fs.readFileSync(p,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean); }
function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function build(){
  const baseEntries = readLines(DATASET);
  const moral = readLines(MORAL_LEDGER);
  const drift = readLines(DRIFT_LEDGER);
  const driftByTs = new Map(drift.map(d=> [d.ts, d]));
  let count=0;
  for(const e of baseEntries){
    const { vector, manifest } = extractFeatures(e);
    const nearestMoral = moral.reduce((best,cur)=> !best || Math.abs(cur.ts - e.ts) < Math.abs(best.ts - e.ts) ? cur : best, null);
    const nearestDrift = driftByTs.get(e.ts) || drift.reduce((best,cur)=> !best || Math.abs(cur.ts - e.ts) < Math.abs(best.ts - e.ts) ? cur : best, null);
    const outObj = {
      ts: e.ts,
      features: vector,
      manifestHash: manifest.hash,
      vocabMerkle: manifest.vocabMerkle,
      virtues: nearestMoral? nearestMoral.virtues : null,
      drift: nearestDrift? { kl: nearestDrift.kl, hR: nearestDrift.hRecent } : null
    };
    outObj.chainHash = stableHash(outObj);
    fs.appendFileSync(OUT, JSON.stringify(outObj)+'\n');
    count++;
  }
  console.log('[CalibrationDataset] Built entries=', count, 'file='+OUT);
}

if(require.main===module){ build(); }
module.exports = { build };
