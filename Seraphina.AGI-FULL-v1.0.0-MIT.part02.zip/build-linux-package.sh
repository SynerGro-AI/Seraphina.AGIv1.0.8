#!/usr/bin/env bash
set -euo pipefail

APP_NAME="seraphina-miner"
VERSION="$(date +%Y%m%d%H%M%S)"
ARCH="$(uname -m || echo unknown)"
OUT_DIR="linux-dist"
PREFIX="/opt/seraphina/mining"

echo "[linux-package] Preparing build output directory"
rm -rf "$OUT_DIR" && mkdir -p "$OUT_DIR/$APP_NAME" "$OUT_DIR/work"

echo "[linux-package] Generating manifests"
node generate-minimal-runtime-manifest.js > /dev/null
node generate-provenance.js > /dev/null

echo "[linux-package] Copying essential files"
ESSENTIAL=(
  aurrelia-pico-mesh-miner.js
  real-stratum-client.js
  audit-all.js audit-monitor.js diff-chain-tips.js integrity-audit.js environment-audit.js
  generate-usb-manifest.js verify-manifest.js export-chain-tips-prom.js
  agent-response-schema.js seraphina-key-vault.js
  minimal-runtime-manifest.json provenance.json artifact-hashes.json
  install-miner-systemd.sh seraphina-miner.service seraphina-miner.apparmor
  security/security-suite-runner.js security/security-suite-config.json security/lattice-tamper-sensor.js security/honeypot-rotator.js security/malware-scan.js security/clone-guard-bot.js security/network-anomaly.js security/vpn-bounce-controller.js security/security-signatures.json
  self-heal-controller.js hmac-seal-artifacts.js provenance-verify.js
  README.md LICENSE.txt
)

for f in "${ESSENTIAL[@]}"; do
  if [[ -f "$f" ]]; then
    dest="$OUT_DIR/$APP_NAME/$f"
    mkdir -p "$(dirname "$dest")"
    cp "$f" "$dest"
  else
    echo "[linux-package] WARN missing $f" >&2
  fi
done

echo "[linux-package] Generating SBOM"
node generate-sbom.js > "$OUT_DIR/$APP_NAME/sbom.json" || echo "[linux-package] WARN sbom generation failed"

echo "[linux-package] Creating tarball"
TARBALL_NAME="${APP_NAME}-${VERSION}-${ARCH}.tar.gz"
tar -C "$OUT_DIR" -czf "$OUT_DIR/${TARBALL_NAME}" "$APP_NAME"
echo "[linux-package] Tarball: $OUT_DIR/${TARBALL_NAME}"

if [[ "${GPG_SIGN:-0}" == "1" ]]; then
  if command -v gpg >/dev/null 2>&1; then
    echo "[linux-package] Signing tarball with GPG"
    gpg --batch --yes --armor --detach-sign -o "$OUT_DIR/${TARBALL_NAME}.asc" "$OUT_DIR/${TARBALL_NAME}" || echo "[linux-package] WARN GPG signing failed"
  else
    echo "[linux-package] GPG not installed; skipping signing"
  fi
fi

POSTINST="$OUT_DIR/work/debian-postinst.sh"
cat > "$POSTINST" <<'EOF'
#!/bin/bash
set -e
if [ -x /opt/seraphina/mining/install-miner-systemd.sh ]; then
  /opt/seraphina/mining/install-miner-systemd.sh || echo "postinst: installer script failed"
fi
systemctl daemon-reload || true
systemctl enable --now seraphina-miner.service || true
EOF
chmod +x "$POSTINST"

if command -v fpm >/dev/null 2>&1; then
  echo "[linux-package] Building .deb via fpm"
  fpm -s dir -t deb -n "$APP_NAME" -v "$VERSION" --architecture "$ARCH" \
    --prefix "$PREFIX" -C "$OUT_DIR/$APP_NAME" . \
    --description "Seraphina deterministic multi-ledger miner" \
    --license "MIT" --deb-systemd seraphina-miner.service \
    --after-install "$POSTINST" || echo "[linux-package] fpm deb creation failed"
  if [[ "${GPG_SIGN:-0}" == "1" && -f ${APP_NAME}_${VERSION}_${ARCH}.deb ]]; then
    if command -v gpg >/dev/null 2>&1; then
      echo "[linux-package] Signing deb with GPG"
      gpg --batch --yes --armor --detach-sign -o "${APP_NAME}_${VERSION}_${ARCH}.deb.asc" "${APP_NAME}_${VERSION}_${ARCH}.deb" || echo "[linux-package] WARN deb signing failed"
    fi
  fi
else
  echo "[linux-package] fpm not installed; skipping .deb creation"
fi

echo "[linux-package] Done."