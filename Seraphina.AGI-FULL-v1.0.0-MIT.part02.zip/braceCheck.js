const fs = require('fs');
const path = 'c:/Users/jmwil/OneDrive/AppData/Documents/mining/aurrelia-pico-mesh-miner.js';
const data = fs.readFileSync(path,'utf8');
let line=1,col=0;let stack=[];let inS=false,inD=false,inB=false,inSL=false,inML=false;
for (let i=0;i<data.length;i++){
  const c=data[i],n=data[i+1];
  if(c==='\n'){line++;col=0;inSL=false;continue;} col++;
  if(inSL) continue;
  if(inML){ if(c==='*'&&n=='/'){inML=false;i++;} continue; }
  if(!inS&&!inD&&!inB){ if(c==='/'&&n=='/'){inSL=true;i++;continue;} if(c==='/'&&n=='*'){inML=true;i++;continue;} }
  if(!inD&&!inB&&c==='\''&&!inS){inS=true;continue;} else if(inS&&c==='\''&&data[i-1] !== '\\'){inS=false;continue;}
  if(!inS&&!inB&&c==='"'&&!inD){inD=true;continue;} else if(inD&&c==='"'&&data[i-1] !== '\\'){inD=false;continue;}
  if(!inS&&!inD&&c==='`'&&!inB){inB=true;continue;} else if(inB&&c==='`'&&data[i-1] !== '\\'){inB=false;continue;}
  if(inS||inD||inB) continue;
  if(c=='{'){ stack.push({line,col}); }
  else if(c=='}'){ if(!stack.length){ console.log('Unmatched closing at', line, col); } else stack.pop(); }
}
console.log('Remaining opens', stack.length);
console.log('Last 20 opens:', stack.slice(-20));