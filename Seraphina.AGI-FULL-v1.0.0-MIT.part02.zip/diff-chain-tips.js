#!/usr/bin/env node
// Compare two chain-tips.json files and list changed ledgers.
const fs = require('fs');
if(process.argv.length < 4){
  console.error('Usage: node diff-chain-tips.js <old.json> <new.json>');
  process.exit(1);
}
function load(p){ try { return JSON.parse(fs.readFileSync(p,'utf8')); } catch(e){ console.error('Failed to read', p, e.message); process.exit(2);} }
const oldTips = load(process.argv[2]);
const newTips = load(process.argv[3]);
const oldMap = oldTips.tips || {}; const newMap = newTips.tips || {};
const changes = []; const unchanged = []; const added = []; const removed = [];
const allFiles = new Set([...Object.keys(oldMap), ...Object.keys(newMap)]);
for(const f of allFiles){
  if(!(f in oldMap)) { added.push(f); continue; }
  if(!(f in newMap)) { removed.push(f); continue; }
  if(oldMap[f] !== newMap[f]) changes.push({ file:f, old:oldMap[f], new:newMap[f] }); else unchanged.push(f);
}
const summary = { changed: changes.length, added: added.length, removed: removed.length, unchanged: unchanged.length, changes, added, removed };
console.log(JSON.stringify(summary, null, 2));
if(changes.length>0 || added.length>0 || removed.length>0) process.exit(3); // non-zero signals difference for CI/monitoring
process.exit(0);
