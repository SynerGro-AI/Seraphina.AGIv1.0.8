#!/usr/bin/env node
'use strict';
// dataset-build-large.js: Generate large synthetic dataset (~1GB) in append chunks.
// Usage: node dataset-build-large.js --targetSizeMB=1024 --chunk=50000 --spread=0.15 --volMult=2.5
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const OUT = process.env.SERAPHINA_LARGE_DATASET || 'seraphina-model-dataset-large.jsonl';
const BINARY_ENABLED_ENV = process.env.SERAPHINA_LARGE_DATASET_BINARY === '1';
let binaryFlag=false;
let targetSizeMB = parseInt(process.env.TARGET_SIZE_MB || '1024',10);
let chunk = parseInt(process.env.CHUNK_COUNT || '50000',10); // entries per batch
let spread = parseFloat(process.env.SYNTH_SPREAD || '0.15');
let volMult = parseFloat(process.env.SYNTH_VOL_MULT || '2.5');

for(const arg of process.argv.slice(2)){
  const m=/^--([^=]+)=(.+)$/.exec(arg); if(!m) continue; const k=m[1]; const v=m[2];
  if(k==='targetSizeMB') targetSizeMB=parseInt(v,10);
  else if(k==='chunk') chunk=parseInt(v,10);
  else if(k==='spread') spread=parseFloat(v);
  else if(k==='volMult') volMult=parseFloat(v);
  else if(k==='binary') binaryFlag = v==='1' || v==='true';
}

function randNorm(seed,i){ const h=crypto.createHash('sha256').update(seed+'|'+i).digest(); return (h[0]/255 - 0.5)*2; }

function generateEntry(seed,i){
  const baseShift = randNorm(seed,i)*spread;
  const personality = {
    openness: clamp01(0.5+baseShift*0.9),
    conscientiousness: clamp01(0.5-baseShift*0.7),
    extraversion: clamp01(0.5+baseShift*0.3),
    agreeableness: clamp01(0.5-baseShift*0.4),
    neuroticism: clamp01(0.5+baseShift*0.2),
    ethical_alignment: clamp01(0.7 - baseShift*0.5),
    empathy: clamp01(0.65 - baseShift*0.4)
  };
  const econSignals = {
    frenRevenueNorm: clamp01(0.5 + randNorm(seed,'rev'+i)*0.25),
    marketVolatility: Math.abs(randNorm(seed,'vol'+i))*volMult,
    demandIndex: clamp01(0.5 + randNorm(seed,'dem'+i)*0.35)
  };
  return { ts: Date.now(), personality, econSignals, meta:{ seed, idx:i } };
}

function clamp01(v){ return v<0?0:v>1?1:v; }

function sizeMB(){ if(!fs.existsSync(OUT)) return 0; return fs.statSync(OUT).size/(1024*1024); }

function main(){
  const seed='largeSynthSeed';
  let batch=0;
  const binaryEnabled = BINARY_ENABLED_ENV || binaryFlag;
  let binFd=null; let dim=null; let totalEntries=0;
  let binPath = OUT.replace(/\.jsonl$/,'') + '.bin';
  let metaPath = binPath + '.meta.json';
  if(binaryEnabled){
    try { binFd = fs.openSync(binPath,'w'); } catch(e){ console.warn('[LargeDataBinary] open fail', e.message); }
  }
  while(sizeMB()<targetSizeMB){
    let lines=[];
    for(let i=0;i<chunk;i++){ lines.push(JSON.stringify(generateEntry(seed, batch*chunk+i))); }
    fs.appendFileSync(OUT, lines.join('\n')+'\n');
    if(binaryEnabled && binFd){
      for(const line of lines){
        try {
          const obj = JSON.parse(line);
          const personality = obj.personality || {};
          const econ = obj.econSignals || {};
          // Build a stable ordered vector (must match training extractor ordering assumptions)
          const vec = [
            personality.openness||0,
            personality.conscientiousness||0,
            personality.extraversion||0,
            personality.agreeableness||0,
            personality.neuroticism||0,
            personality.ethical_alignment||0,
            personality.empathy||0,
            econ.frenRevenueNorm||0,
            econ.marketVolatility||0,
            econ.demandIndex||0
          ];
          if(dim==null) dim = vec.length;
          const buf = Buffer.alloc(dim*4);
          for(let k=0;k<dim;k++){ buf.writeFloatLE(vec[k], k*4); }
          fs.writeSync(binFd, buf);
          totalEntries++;
        } catch(_e){ /* skip malformed */ }
      }
    }
    batch++;
    const current=sizeMB().toFixed(2);
    console.log('[LargeData] batch='+batch+' sizeMB='+current+(binaryEnabled? ' binEntries='+totalEntries:''));
  }
  console.log('[LargeData] COMPLETE sizeMB='+sizeMB().toFixed(2)+' file='+OUT);
  if(binaryEnabled && binFd){
    try { fs.closeSync(binFd); } catch(_e){}
    const meta = { dim, entries: totalEntries, floatBytes:4, vectorOrder:['openness','conscientiousness','extraversion','agreeableness','neuroticism','ethical_alignment','empathy','frenRevenueNorm','marketVolatility','demandIndex'] };
    try { fs.writeFileSync(metaPath, JSON.stringify(meta,null,2)); console.log('[LargeDataBinary] wrote', binPath, 'meta', metaPath); } catch(e){ console.warn('[LargeDataBinary] meta write fail', e.message); }
  }
}

if(require.main===module){ main(); }
