#!/usr/bin/env node
'use strict';
// alert-severity-test.js: Run training with exaggerated thresholds to produce critical severity.
const { spawnSync } = require('child_process');
const fs = require('fs');
const TRAIN = 'seraphina-model-train.js';
const ALERT_LEDGER = process.env.SERAPHINA_EMA_MEDIAN_ALERT_LEDGER || 'seraphina-ema-median-alert-ledger.jsonl';

function run(args){
  const res = spawnSync('node', [TRAIN, ...args], { stdio:'inherit' });
  if(res.status!==0) throw new Error('Training failed');
}

try {
  // Clean ledger for deterministic test
  if(fs.existsSync(ALERT_LEDGER)) fs.unlinkSync(ALERT_LEDGER);
  // Use small thresholds to trigger alert and define severity tiers
  run(['--emaMedianThresh=0','--emaMedianAlertLow=-0.0001','--emaMedianAlertHigh=0.0001','--emaAlpha=0.7','--labelFlip=0.3']);
  if(!fs.existsSync(ALERT_LEDGER)) throw new Error('Alert ledger missing');
  const lines = fs.readFileSync(ALERT_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
  const last = JSON.parse(lines[lines.length-1]);
  console.log('[LastAlert]', last);
  if(!last.severity){ throw new Error('Severity missing'); }
  console.log('ALERT SEVERITY TEST PASS severity='+last.severity);
} catch(e){ console.error('ALERT SEVERITY TEST FAIL', e); process.exit(1); }
