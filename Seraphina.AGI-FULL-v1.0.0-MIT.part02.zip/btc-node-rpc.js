/**
 * Bitcoin Core RPC Client (Thin Wrapper)
 * Provides direct full-node access (REAL chain data) instead of only public APIs.
 * Set env:
 *  BITCOIN_RPC_URL (e.g. http://127.0.0.1:8332)
 *  BITCOIN_RPC_USER
 *  BITCOIN_RPC_PASS
 */
const { URL } = require('url');
const https = require('https');
const http = require('http');

function rpcConfig(){
  const url = process.env.BITCOIN_RPC_URL; if(!url) return null;
  try { return new URL(url); } catch { return null; }
}

function rpcCall(method, params=[]) {
  const cfg = rpcConfig(); if(!cfg) throw new Error('RPC_NOT_CONFIGURED');
  const auth = Buffer.from((process.env.BITCOIN_RPC_USER||'')+':' + (process.env.BITCOIN_RPC_PASS||'')).toString('base64');
  const body = JSON.stringify({ jsonrpc:'1.0', id: Date.now(), method, params });
  const isHttps = cfg.protocol === 'https:';
  const opts = {
    hostname: cfg.hostname,
    port: cfg.port || (isHttps?443:80),
    path: cfg.pathname,
    method: 'POST',
    headers: {
      'Content-Type':'application/json',
      'Content-Length': Buffer.byteLength(body),
      'Authorization': 'Basic ' + auth
    },
    rejectUnauthorized: false
  };
  return new Promise((resolve, reject) => {
    const req = (isHttps? https: http).request(opts, res => {
      let data='';
      res.on('data', c=>data+=c);
      res.on('end', ()=>{
        try { const json = JSON.parse(data); if(json.error) return reject(new Error(json.error.message||'RPC_ERROR')); resolve(json.result); } catch(e){ reject(e); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function listUnspentForAddress(address, minConf=1){
  const utxos = await rpcCall('listunspent', [minConf, 9999999, [address]]);
  return utxos.map(u=>({
    txid: u.txid,
    vout: u.vout,
    value: Math.round(u.amount * 100000000),
    confirmations: u.confirmations,
    scriptPubKey: u.scriptPubKey
  }));
}

async function sendRawTransaction(hex){
  return await rpcCall('sendrawtransaction', [hex]);
}

module.exports = { rpcCall, listUnspentForAddress, sendRawTransaction };
