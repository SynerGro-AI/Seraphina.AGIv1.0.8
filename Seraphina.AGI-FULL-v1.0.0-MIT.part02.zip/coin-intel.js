// coin-intel.js
// Non-invasive coin intelligence / differentiation layer.
// Does NOT alter mining behavior; BTC remains sole active coin unless others are added explicitly.
// Provides structured metadata describing algorithm families, typical pool URL patterns, hardware suitability,
// parity / validation recommendations, and risk notes.

const crypto = require('crypto');

// Static intelligence catalog (extend safely without changing active coins)
const COIN_INTEL = {
  btc: {
    name: 'Bitcoin',
    algoFamily: 'sha256d',
    hardwareSuitability: { cpu: 'low', gpu: 'low', asic: 'required' },
    typicalPorts: [3333, 443, 8444, 1314],
    stratumPatterns: ['btc\.f2pool\.com', 'solo\.ckpool\.org', 'stratum\.braiins\.com'],
    parityRecommended: true,
    notes: 'Longest chain PoW, difficulty retarget 2016 blocks (~2 weeks). ASIC only for profitability.',
    riskLevel: 'low',
    metadata: { blockIntervalSec: 600, rewardDynamic: false },
  },
  rvn: {
    name: 'Ravencoin',
    algoFamily: 'kawpow',
    hardwareSuitability: { cpu: 'very_low', gpu: 'high', asic: 'none' },
    typicalPorts: [8888, 13333],
    stratumPatterns: ['rvn\.f2pool\.com', 'us\.rvnmining\.pool'],
    parityRecommended: false,
    notes: 'GPU-oriented PoW with randomized sequence and DAG memory access. ASIC-resistant.',
    riskLevel: 'medium',
    metadata: { blockIntervalSec: 60, rewardDynamic: false },
    unsupported: true // Mark as not active in current miner build
  },
  kas: {
    name: 'Kaspa',
    algoFamily: 'kheavyhash',
    hardwareSuitability: { cpu: 'low', gpu: 'high', asic: 'emerging' },
    typicalPorts: [8888],
    stratumPatterns: ['kas\.f2pool\.com', 'pool\.kaspa\.org'],
    parityRecommended: false,
    notes: 'High-throughput blockDAG; rapid block emission; GPU mining common, specialized hardware emerging.',
    riskLevel: 'medium',
    metadata: { blockIntervalSec: 1, rewardDynamic: true },
    unsupported: true
  }
};

function getCoinIntel(coin){
  const key = (coin||'').toLowerCase();
  const info = COIN_INTEL[key];
  if(!info){
    return { coin: key, supported: false, error: 'unknown_coin' };
  }
  const digest = crypto.createHash('sha256').update(JSON.stringify(info)).digest('hex').slice(0,24);
  return { coin: key, supported: !info.unsupported, intelDigest: digest, ...info };
}

function listCoins(){
  return Object.keys(COIN_INTEL).map(c=>getCoinIntel(c));
}

module.exports = { getCoinIntel, listCoins };
