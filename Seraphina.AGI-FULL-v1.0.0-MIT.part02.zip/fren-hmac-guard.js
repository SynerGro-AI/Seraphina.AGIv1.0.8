// fren-hmac-guard.js
// Validate .fren-env FREN_WALLET against HMAC and optionally regenerate (non-strict) or abort (STRICT_INTEGRITY=1)
// Usage: node fren-hmac-guard.js
// Optional env: CONFIG_HMAC_KEY, STRICT_INTEGRITY=1 to abort on mismatch.

const fs = require('fs');
const crypto = require('crypto');

const envPath = '.fren-env';
const hmacKey = process.env.CONFIG_HMAC_KEY || 'default-key';
const strict = process.env.STRICT_INTEGRITY === '1';

function loadEnvLines(){
  if (!fs.existsSync(envPath)) return [];
  return fs.readFileSync(envPath,'utf8').split(/\n/).filter(l=> l.trim().length>0);
}

function writeEnv(lines){ fs.writeFileSync(envPath, lines.join('\n')+'\n'); }

function generateDeterministicFrenAddress(){
  const bitcoin = require('bitcoinjs-lib');
  const FREN_NETWORK = { messagePrefix:'\x18Frencoin Signed Message:\n', bech32:'fr', bip32:{ public:0x0488b21e, private:0x0488ade4 }, pubKeyHash:0x1e, scriptHash:0x1c, wif:0x80 };
  const seedSrc = (process.env.F2POOL_USER||'user') + ':' + (process.env.GLOBAL_OCTO_SEED||'0');
  const seedHash = crypto.createHash('sha256').update(seedSrc).digest();
  let idx=0; function rng(bytes){ const out=Buffer.alloc(bytes); for(let i=0;i<bytes;i++){ out[i]=seedHash[idx++ % seedHash.length]; } return out; }
  const keyPair = bitcoin.ECPair.makeRandom({ network: FREN_NETWORK, rng });
  const pay = bitcoin.payments.p2pkh({ pubkey: keyPair.publicKey, network: FREN_NETWORK });
  return pay.address;
}

(function main(){
  const lines = loadEnvLines();
  const frenLine = lines.find(l=> l.startsWith('FREN_WALLET='));
  const hmacLine = lines.find(l=> l.startsWith('FREN_WALLET_HMAC='));
  if (!frenLine){ console.warn('[FREN-HMAC] No FREN_WALLET entry found.'); return; }
  const address = frenLine.split('=')[1].trim();
  const expectedHmac = crypto.createHmac('sha256', hmacKey).update(address).digest('hex').slice(0,16);
  const storedHmac = hmacLine? hmacLine.split('=')[1].trim() : null;
  if (storedHmac !== expectedHmac){
    console.warn('[FREN-HMAC] HMAC mismatch stored='+storedHmac+' expected='+expectedHmac);
    if (strict){
      console.error('[FREN-HMAC] STRICT_INTEGRITY=1 aborting.');
      process.exit(1);
    }
    // Regenerate deterministic address and update file
    const newAddr = generateDeterministicFrenAddress();
    const newHmac = crypto.createHmac('sha256', hmacKey).update(newAddr).digest('hex').slice(0,16);
    const filtered = lines.filter(l=> !/^FREN_WALLET=/.test(l) && !/^FREN_WALLET_HMAC=/.test(l));
    filtered.push('FREN_WALLET='+newAddr); filtered.push('FREN_WALLET_HMAC='+newHmac);
    writeEnv(filtered);
    console.log('[FREN-HMAC] Regenerated wallet '+newAddr+' HMAC '+newHmac);
  } else {
    console.log('[FREN-HMAC] HMAC verified OK');
  }
})();
