// dimension-escalator.js
// Deterministic helper to decide imagination dimension escalation.
// Inputs: history of effective improvements, current dimension, governance target, thresholds.
// Escalation conditions (all must pass):
// 1. targetDim > currentDim
// 2. (targetDim - currentDim) <= IMAGINATION_DIM_STEP_MAX
// 3. variance(history[-N..]) < IMAGINATION_DIM_VARIANCE_THRESHOLD
// 4. improvement plateau: abs(mean(lastHalf) - mean(firstHalf)) <= varianceThreshold/4
// 5. plateau runs length >= IMAGINATION_DIM_PLATEAU_RUNS
// Output: { escalate: boolean, nextDim, reason }

'use strict';
const crypto = require('crypto');
function sha256(x){ return crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex'); }

function computeVariance(arr){
  if(!arr.length) return 0;
  const mean = arr.reduce((a,b)=>a+b,0)/arr.length;
  const v = arr.reduce((a,b)=> a + (b-mean)**2,0)/arr.length;
  return v;
}

function decideDimensionEscalation(opts){
  const {
    history = [],
    currentDim = 3,
    targetDim = 3,
    stepMax = 8,
    varianceThreshold = 0.2,
    plateauRuns = 5
  } = opts || {};
  if(targetDim <= currentDim) return { escalate:false, nextDim:currentDim, reason:'target<=current' };
  const delta = targetDim - currentDim;
  if(delta > stepMax) return { escalate:false, nextDim:currentDim, reason:'step-too-large' };
  const recent = history.slice(-plateauRuns);
  if(recent.length < plateauRuns) return { escalate:false, nextDim:currentDim, reason:'insufficient-history' };
  const varRecent = computeVariance(recent);
  if(varRecent >= varianceThreshold) return { escalate:false, nextDim:currentDim, reason:'variance-too-high' };
  const half = Math.floor(recent.length/2);
  const first = recent.slice(0,half);
  const last = recent.slice(half);
  const meanFirst = first.reduce((a,b)=>a+b,0)/first.length;
  const meanLast = last.reduce((a,b)=>a+b,0)/last.length;
  const plateau = Math.abs(meanLast - meanFirst) <= (varianceThreshold/4);
  if(!plateau) return { escalate:false, nextDim:currentDim, reason:'no-plateau' };
  const nextDim = currentDim + delta; // direct jump (bounded by stepMax earlier)
  return { escalate:true, nextDim, reason:'escalate', decisionDigest: sha256({currentDim,targetDim,history:recent}) };
}

if(require.main === module){
  // CLI quick deterministic check
  const history = process.env.DIM_HISTORY? process.env.DIM_HISTORY.split(',').map(Number) : [0.11,0.11,0.105,0.108,0.107];
  const res = decideDimensionEscalation({
    history,
    currentDim: parseInt(process.env.CUR_DIM||'3',10),
    targetDim: parseInt(process.env.IMAGINATION_DIM_TARGET||'12',10),
    stepMax: parseInt(process.env.IMAGINATION_DIM_STEP_MAX||'8',10),
    varianceThreshold: parseFloat(process.env.IMAGINATION_DIM_VARIANCE_THRESHOLD||'0.2'),
    plateauRuns: parseInt(process.env.IMAGINATION_DIM_PLATEAU_RUNS||'5',10)
  });
  process.stdout.write(JSON.stringify(res,null,2)+'\n');
}

module.exports = { decideDimensionEscalation };
