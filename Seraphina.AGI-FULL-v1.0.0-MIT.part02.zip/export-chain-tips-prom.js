#!/usr/bin/env node
// Export chain tips as Prometheus textfile metrics for node_exporter textfile collector.
// Reads chain-tips.json produced by audit-all or audit-monitor.
const fs = require('fs');
const path = require('path');
const OUT = process.env.CHAIN_TIPS_PROM_PATH || 'chain-tips.prom';
function main(){
  let data=null;
  try { data = JSON.parse(fs.readFileSync('chain-tips.json','utf8')); } catch(e){
    console.error('[EXPORT][WARN] chain-tips.json missing or invalid:', e.message);
    process.exit(1);
  }
  const lines = [
    '# HELP aur_chain_tip_last_hash_length Length of hex hash for each ledger tip',
    '# TYPE aur_chain_tip_last_hash_length gauge'
  ];
  for (const [file, hash] of Object.entries(data.tips||{})){
    const sanitized = file.replace(/[^a-zA-Z0-9_]/g,'_');
    lines.push(`aur_chain_tip_last_hash_length{ledger="${sanitized}"} ${hash.length}`);
    // Additionally export a fingerprint (first 12 hex) as a label via separate metric
    const short = hash.slice(0,12);
    lines.push(`aur_chain_tip_fingerprint{ledger="${sanitized}",fingerprint="${short}"} 1`);
  }
  lines.push(`# HELP aur_chain_tips_export_timestamp Unix ms timestamp of export`);
  lines.push('# TYPE aur_chain_tips_export_timestamp gauge');
  lines.push(`aur_chain_tips_export_timestamp ${Date.now()}`);
  try { fs.writeFileSync(OUT, lines.join('\n')+'\n'); } catch(e){
    console.error('[EXPORT][ERROR] write failed:', e.message); process.exit(1);
  }
  console.log('[EXPORT] chain tips Prometheus metrics written ->', path.resolve(OUT));
}
main();
