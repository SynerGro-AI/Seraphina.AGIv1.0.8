/**
 * KawPow Validator (Enhanced Scaffold)
 * --------------------------------------------------
 * Real KawPow requires:
 *  - Block height & seed hash
 *  - Epoch DAG (cached) or light cache
 *  - Keccak + ProgPoW mix / final hash
 *  - Boundary comparison vs target
 * This module presently performs STRUCTURAL VALIDATION ONLY plus a
 * deterministic pseudo-boundary check (hash prefix) to reject obviously
 * malformed submissions while awaiting real WASM/native integration.
 */
const crypto = require('crypto');
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }
let keccakLib=null; try { keccakLib = require('keccak'); } catch {}
let realInterface = null;
try {
  const { KawpowRealInterface } = require('./kawpow-real-interface');
  realInterface = new KawpowRealInterface();
} catch (e) {
  if (process.env.REAL_STRICT === '1') {
    console.error('[KAWPOW] REAL_STRICT requires real interface; aborting:', e.message);
    process.exit(1);
  }
  // Silent fallback otherwise
}

// Future: dynamically load WASM: const kawpow = require('./wasm/kawpow');

const EPOCH_BLOCK_INTERVAL = 7500; // Ravencoin KawPow epoch interval
const _seedCache = new Map();

function keccak256(buf){
  if (keccakLib) return keccakLib('keccak256').update(buf).digest();
  if (process.env.REAL_STRICT === '1') {
    console.error('[KAWPOW] REAL_STRICT missing keccak dependency. Install keccak module.');
    process.exit(1);
  }
  return crypto.createHash('sha256').update(buf).digest(); // fallback outside strict
}

function kawpowSeedForEpoch(epoch){
  if (_seedCache.has(epoch)) return _seedCache.get(epoch);
  let seed = Buffer.alloc(32,0);
  for(let i=0;i<epoch;i++) seed = keccak256(seed);
  const hex = seed.toString('hex');
  _seedCache.set(epoch, hex);
  return hex;
}

function deriveEpochFromHeight(height){
  if (!height || height < 0) return 0;
  return Math.floor(height / EPOCH_BLOCK_INTERVAL);
}

function deriveEpoch(ntimeHex){
  // Fallback: derive pseudo height from time (NOT canonical) -> epoch 0
  return 0;
}

function pseudoMix(job, submit, extranonce1){
  const base = [job.jobId, job.prevhash, job.nbits, submit.nonce, submit.ntime, extranonce1||''].join(':');
  return crypto.createHash('sha256').update(base).digest('hex');
}

function validateShare({ job, submit, extranonce1 }) {
  if (!job || !submit) return { ok:false, error:'MISSING_JOB_OR_SUBMIT'};
  if (!submit.nonce || !submit.ntime) return { ok:false, error:'MISSING_FIELDS'};
  const strict = process.env.REAL_STRICT === '1';
  // Attempt real path if native binding is present and job exposes needed fields.
  if (realInterface && job && job.seedHash && job.headerHash) {
    try {
      const epoch = job.height ? deriveEpochFromHeight(job.height) : deriveEpoch(submit.ntime || job.ntime);
      const native = realInterface.computeHash({
        epoch,
        seedHashHex: job.seedHash.replace(/^0x/,''),
        headerHashHex: job.headerHash.replace(/^0x/,''),
        nonceHex: submit.nonce.replace(/^0x/,'')
      });
      if (native) {
        // Compare finalHash against nbits/target when provided
        if (job.nbits) {
          const targetOk = _checkTarget(job.nbits, native.finalHash);
          if (!targetOk) return { ok:false, error:'KAWPOW_HASH_ABOVE_TARGET', finalHash: native.finalHash };
        }
        return { ok:true, epoch, real:true, mix: native.mixHash, final: native.finalHash };
      }
    } catch (e) {
      if (strict) return { ok:false, error:'STRICT_REAL_HASH_FAIL:'+e.message };
    }
  }
  // Fallback structural / pseudo boundary path
  const mix = pseudoMix(job, submit, extranonce1);
  const acceptable = /^0000/.test(mix);
  if (!acceptable) return { ok:false, error:'KAWPOW_BOUNDARY_FAIL_STUB', mix };
  const epoch = job.height ? deriveEpochFromHeight(job.height) : deriveEpoch(submit.ntime || job.ntime);
  const seed = kawpowSeedForEpoch(epoch);
  return { ok:true, epoch, light:true, pseudo:true, mix, seed };
}

function _checkTarget(nbitsHex, finalHashHex) {
  try {
    const n = Buffer.from(nbitsHex.replace(/^0x/,''),'hex');
    const exp = n[0];
    const mant = n.readUIntBE(1,3);
    let target = BigInt(mant) * (BigInt(2) ** (BigInt(8)*(BigInt(exp)-BigInt(3))));
    const hashNum = BigInt('0x'+finalHashHex);
    return hashNum <= target;
  } catch { return false; }
}

module.exports = { validateShare, deriveEpoch, deriveEpochFromHeight, kawpowSeedForEpoch };
