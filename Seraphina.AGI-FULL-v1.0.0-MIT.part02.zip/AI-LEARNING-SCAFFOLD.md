# AI Learning Scaffold (Deterministic Multi-Instance)

## Goals
- Provide a reproducible, hash-audited adaptive learning loop for both Miner (Aurrelia) and Seraphina AI instances.
- Surpass stochastic heuristics by using strictly deterministic candidate generation, scoring, and ledgered evolution.
- Integrate 3D imagination sandbox for scenario projection without real-world side effects.
- Allow governance proposals to gate training, imagination expansion, and grid search breadth.

## Components
1. Config (`ai-learning-config.json`)
   - Modules: `mlAdvisor`, `trading`, `imagination`, `seraphina`.
   - Governance adjustable params (subset): spread & fee, learned multipliers, imagination enable/max scenarios, training triggers.
2. Orchestrator (`ai-learning-orchestrator.js`)
   - Builds dataset manifest hash chain.
   - Invokes ML advisor training, Seraphina training, optional imagination session.
   - Produces summary ledger entry with chained hash.
3. Deterministic Training Scripts
   - `ml-train-deterministic.js` (grid around advisor weights; directional & shrink strategies via env flags).
   - `seraphina-train-deterministic.js` (uses imagination outcome features + trading signals).
4. Imagination Adapter (`seraphina-3d-imagination-adapter.js`)
   - Sphere lattice (Fibonacci shells) generation; deterministic avatar geometry transforms.
   - Scenario evaluation yields projected gain, geometry penalty, net projection.
   - Ledger: `imagination-ledger.jsonl` with hash chain.
5. Governance Engine (`governance-engine.js`)
   - Hash-based quorum simulation; clamps applied params within `PARAM_BOUNDS`.
   - Added bounds: `ML_TRAIN_TRIGGER`, `LEARNING_GRID_EXPAND`, `IMAGINATION_ENABLED`, `IMAGINATION_MAX_SCENARIOS`.
6. Trading Engine (`aurrelia-trading-engine.js`)
   - Volatility-based dynamic threshold + learned multiplier.
   - Regime hysteresis (requires N consecutive confirmations before regime change).
7. Dataset Manifest (`ai-dataset-manifest.js`)
   - Hashes artifacts; aggregate chain digest for reproducibility.
8. Ledgers
   - Training: `ml-train-ledger.jsonl`, `seraphina-train-ledger.jsonl`.
   - Summary: `ai-learning-summary-ledger.jsonl`.
   - Imagination: `imagination-ledger.jsonl`.
   - Governance: proposals & decisions files.

## Determinism Guarantees
- No Math.random / time-based branching for core logic; time only recorded as data.
- Candidate generation enumerative & sorted by SHA256 prefixes.
- Scenario lists truncated deterministically (slice by configured max).
- Regime changes only after N identical classifications (hysteresis) to avoid jitter.
- All critical outputs hashed and appended in chain form (prevHash + chainHash).

## Environment Controls (Examples)
- `ML_TRAIN_CANDIDATES`, `ML_TRAIN_DIRECTIONAL`, `ML_TRAIN_SHRINK`.
- `SERAPHINA_TRAIN_CANDIDATES`, `SERAPHINA_TRAIN_IMPROVE_MIN`.
- `IMAGINATION_ENABLED`, `IMAGINATION_MAX_SCENARIOS`.
- `TRADING_REGIME_CONFIRM` (hysteresis depth).

## Governance Flow
1. Proposal JSONL appended.
2. Quorum simulated via shard of participant hash (< approval pct).
3. If approved, parameters clamped & applied to `process.env` for subsequent runs.
4. Decision ledger chained for audit.

## Imagination Integration Strategy
- Orchestrator runs imagination session first (if enabled) providing scenario outcomes.
- Seraphina training consumes latest imagination outcomes to enrich scoring.
- Aggregate imagination gain recorded in summary -> can inform candidate acceptance weighting (future extension).

## Potential Future Enhancements
- Multi-phase training: imagination-informed prefilter -> candidate refinement layer.
- Structured response schema alignment for orchestrator JSON outputs.
- Cost & rate limiting metrics for training invocations.
- Conversation memory hashed ring for proposal provenance.
- Adaptive lattice expansion under governance constraint.

## Minimal Run Sequence
1. (Optional) Submit governance proposal enabling imagination + training trigger.
2. Execute orchestrator: `node ai-learning-orchestrator.js`.
3. Review summary ledger entry (improvementPct, seraphinaTraining, imagination aggregateGain).
4. If improvement accepted, new weight files appear (`ml-advisor-weights-trained.json`, `seraphina-weights-trained.json`).
5. Commit updated ledgers & weight versions to preserve reproducibility state.

## Failure Modes & Safety
- Missing scenarios file: imagination recorded with scenarioCount=0 (no error).
- Malformed ledger entry: ignored; chain continues with last valid hash.
- Invalid governance param values: clamped to nearest bound ensuring safety.
- Any training script error: scoreboard omitted or replaced with error object; orchestrator continues (non-fatal).

## Hash Surfaces to Monitor
- Config digest (`cfgDigest`)
- Manifest aggregate chain digest
- Weights before/after digests
- Imagination session digest
- Seraphina & ML training signal/imagination digests

## Edge Cases Considered
- Empty signal dataset (scores default to zero; no improvement accepted).
- No imagination scenarios (neutral projection baseline).
- Large candidate expansions (bounded by env & grid expand governance param).
- Rapid volatility oscillations (handled by hysteresis `TRADING_REGIME_CONFIRM`).

## Quick Reference
| Module | Script | Ledger | Scoreboard |
|--------|--------|--------|------------|
| ML Advisor | ml-train-deterministic.js | ml-train-ledger.jsonl | ml-train-scoreboard.json |
| Seraphina | seraphina-train-deterministic.js | seraphina-train-ledger.jsonl | seraphina-train-scoreboard.json |
| Imagination | seraphina-3d-imagination-adapter.js | imagination-ledger.jsonl | (session output only) |
| Orchestrator | ai-learning-orchestrator.js | ai-learning-summary-ledger.jsonl | (summary JSON) |

---
End of AI Learning Scaffold.
