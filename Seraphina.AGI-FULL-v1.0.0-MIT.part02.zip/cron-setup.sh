#!/usr/bin/env bash
# Install nightly integrity audit cron and logrotate for ledgers.
set -euo pipefail

CRON_USER=${1:-$USER}
AUDIT_CMD="cd $(pwd) && /usr/bin/node integrity-audit.js >> audit-log.jsonl 2>&1"
( crontab -u "$CRON_USER" -l 2>/dev/null | grep -v 'integrity-audit.js' ; echo "15 2 * * * $AUDIT_CMD" ) | crontab -u "$CRON_USER" -

echo "[OK] Cron installed for user $CRON_USER (02:15 nightly)."

# Create logrotate config (Linux target). Skip if already present.
LR=/etc/logrotate.d/aurrelia-ledgers
if [ "$(id -u)" -ne 0 ]; then
  echo "[WARN] Run as root to install logrotate config at $LR" >&2
  exit 0
fi
if [ -f "$LR" ]; then
  echo "[INFO] logrotate config already exists: $LR"
  exit 0
fi
cat > "$LR" <<'EOF'
/home/*/aurrelia/*-ledger.jsonl {
  daily
  rotate 14
  compress
  missingok
  copytruncate
  notifempty
}
/home/*/aurrelia/audit-log.jsonl {
  daily
  rotate 14
  compress
  missingok
  copytruncate
  notifempty
}
EOF

echo "[OK] logrotate rules installed at $LR"