# Seraphina API Contract

Version: 0.2.4 (facade) – adds confidence histogram buckets, invalid ratio gauge, consolidated rate limiter metric family (aliases deprecated), confidence sum/count, last confidence tracking refinement.

## Overview
Central entrypoint: `require('./seraphina-api')`
Provides deterministic synthetic virtue simulation, causal IV sandbox, moral guard evaluation, and model training wrapper.

## Namespaces & Exports
- `virtueSim.generateDataset()` -> `VirtueRecord[]`
- `virtueSim.computeMetrics(records)` -> `SimulationMetrics`
- `virtueSim.runSimulation(options)` -> `{ ok:true, fromCache:boolean, records, metrics } | { ok:false, code, message, ... }`
 - Cache persistence optional (env `SERAPHINA_SIM_CACHE_PERSIST=1`) storing metrics only.
- `causal.runIV(n?, seed?)` -> `IVResult`
- `moralGuard.evaluateText(text)` -> `MoralGuardResult`
- `training.trainModel(config)` -> `{ ok:true, result:{ out, scoreboard, integrity } } | { ok:false, code, message }`
  - `scoreboard.integrity` => `{ paramsDigest, metricsDigest, integrityHash }`
    - `paramsDigest`: SHA256 (first 24 hex) over normalized training parameters (epochs, lr, batchSize, updateMode, smoothing, seed, schedules, overridesApplied).
    - `metricsDigest`: SHA256 (first 24 hex) of stable base metrics `{ acc, accEthical, lossA, lossB, datasetSize, weightSig }`.
    - `integrityHash`: Full SHA256 over `{ paramsDigest, metricsDigest, v:'train-integrity-v1' }` (64 hex chars).
  - On promotion integrity written to weights file meta (`integrity`, `integrityDigest`).
- `exporters.startPrometheusExporter(opts)` -> starts metrics server (placeholder pending)
- `meta` -> { version, apiModules, rootDir }

## Data Types
### VirtueRecord
```
{
  scenarioId: string,
  virtueSignals: { prudence, truthfulness, justice, temperance, fortitude, compassion, stewardship, humility, responsibility },
  confounders: { domain, complexity, regionRisk },
  outcomes: { harmProb, truthPassRate, fairnessScore }
}
```

### SimulationMetrics (fields may expand)
```
{
  n: number,
  corrPrudenceHarm: number,
  corrTruthfulnessPass: number,
  corrJusticeFairness?: number,
  bootstrap: {
    prudenceHarm: { median: number, ci: [number, number] },
    truthTruthPass: { median: number, ci: [number, number] }
  },
  permutationP: { prudenceHarm: number, truthTruthPass: number },
  aucHarm: number,
  domainVariance: number,
  targets: { corrPrudenceTarget, corrTruthTarget, corrJusticeFairnessTarget? },
  refine?: { tol, maxIter, harmIters?, truthIters?, fairnessIters? },
  runDurationMs?: number,            // facade wrapper total runtime
  bootIterations?: number,           // bootstrap iteration count
  permutationIterations?: number,    // permutation iteration count
  deltaPrudenceHarm?: number,        // achieved - target prudence->harm
  deltaTruthPass?: number,           // achieved - target truthfulness->truthPass
  deltaJusticeFairness?: number,     // achieved - target justice->fairness
  computeDurationMs?: number         // internal metrics compute duration
}
```

### IVResult
```
{
  n, seed,
  stage1: { beta0, beta1 },
  stage2: { beta0, beta1 },
  seBeta1, tStat
}
```

### Standard Result Shapes
All facade calls now return structured objects:
Success: `{ ok:true, ...data }`
Error: `{ ok:false, code, message, ...context }`

Error Codes Implemented:
| Code | Context Fields | Description |
|------|----------------|-------------|
| INVALID_ARG_RANGE | field, value | Numeric argument outside bounds |
| MODULE_UNAVAILABLE | module? | Optional module missing |
| SIMULATION_FAILED | (none) | Failure during generate/computeMetrics |
| TRAINING_FAILED | (none) | Failure in training wrapper |
| INVALID_TRAIN_ARG_RANGE | field, value | Training parameter outside bounds |
| INVALID_TRAIN_ARG_TYPE | (none) | Non-object training config |
| INPUT_TOO_LARGE | max | Moral guard input length exceeded |
| NO_METRICS | (none) | No cached metrics for snapshot |

### MoralGuardResult
Success: `{ ok:true, blocked:boolean, note?: string, action?: string }`
Failure: `{ ok:false, code, message }`

## Determinism Guarantees
- All simulation randomness derived from SHA256-seeded xorshift or hash-chained sources.
- Passing the same (n, seed, correlation targets, refinement parameters) yields identical dataset & metrics.
- `runSimulation()` has no side-effects (does not write files or append ledger) and employs in-memory caching keyed by normalized option signature.
- CLI invocation of the raw script writes ledger line (chain-hashed) – that side effect is explicitly excluded from `runSimulation`.

## Error Modes & Codes (Planned Standardization)
| Code | When | Shape |
|------|------|-------|
| `MODULE_UNAVAILABLE` | Optional module (guard, train) absent | `{ ok:false, code, message }` |
| `INVALID_ARG_RANGE` | Out-of-range numeric (e.g., n <=0, correlation |corr| >0.95) | `{ ok:false, code, field, value, message }` |
| `INSTRUMENT_MISSING` | Future IV multi-instrument features | same pattern |
| `EXPORTER_NOT_IMPLEMENTED` | startPrometheusExporter called before implementation | `{ ok:false, code, message }` |

Facade hardened: internal exceptions wrapped into structured error objects.

## Input Validation (Upcoming)
- `n` must be integer 1..1e7 (soft cap adjustable)
- correlation targets in (-0.95, 0.95)
- refinement: `refineMaxIter` 0..25, `refineTol` in (0, 0.1]
- seed length <= 128 chars

## Performance Notes
- Complexity roughly O(n) + O(BOOT*n + PERM*n) for metrics.
- Caching short-circuits repeated identical runs (`fromCache:true`).
- `runDurationMs` and `computeDurationMs` provide timing instrumentation.
 - LRU eviction (default max 32, override with `SERAPHINA_SIM_CACHE_MAX`). Metrics persisted omit records to reduce disk size.

### Cache Persistence & CLI
Persistence stores ONLY metrics snapshots (no records) when enabled via `api.meta.toggleCachePersistence(true, pathOverride?)` or environment `SERAPHINA_SIM_CACHE_PERSIST=1`.

Programmatic toggle signature:
`toggleCachePersistence(enable:boolean, pathOverride?:string) -> { ok, persistence, path }`

CLI: see `CACHE-CLI.md` (`seraphina-cache` bin) for commands: `stats`, `enable-persist`, `disable-persist`, `clear`, plus flag `--pretty=false`.

Exporter adds gauges:
`seraphina_sim_cache_entries`, `seraphina_sim_cache_capacity`, `seraphina_sim_cache_persistence_enabled`, and protocol indicator `seraphina_exporter_protocol{protocol="http|https"}`.
Additional cache age gauges:
`seraphina_sim_cache_age_oldest_ms`, `seraphina_sim_cache_age_newest_ms`, `seraphina_sim_cache_age_average_ms`, `seraphina_sim_cache_last_access_stale_max_ms`.

Compression & pruning gauges:
`seraphina_sim_cache_pruned_total` (counter of entries removed programmatically) and `seraphina_sim_cache_compressed` (1 if last persistence save used gzip).
Integrity & prune event gauges:
`seraphina_sim_cache_last_prune_removed`, `seraphina_sim_cache_last_prune_timestamp_ms`.
Integrity scan gauges (0.2.3): `seraphina_sim_cache_integrity_mismatches`, `seraphina_sim_cache_integrity_scanned`.
Age metrics: `seraphina_sim_cache_age_oldest_ms`, `..._newest_ms`, `..._average_ms`, `..._last_access_stale_max_ms`.

Programmatic prune API:
`api.meta.pruneCache(maxAgeMs)` -> `{ ok, pruned }` removes in-memory entries older than cutoff (by createdTs). Triggers persistence save if any removed.

Warm cache API:
`api.meta.warmCache([{ n, seed, ...opts }])` pre-runs simulations to populate cache. Returns `{ ok, hits, added }`.

Cache JSON Endpoint:
`/cache` returns `{ ok, size, entries:[ { key, createdTs, lastAccessTs, hash } ] }` (hash is SHA256 of metrics JSON). If `SERAPHINA_CACHE_TOKEN` is set, requires `Authorization: Bearer <token>` header.

Integrity Hash:
Each persisted entry stores `hash` (sha256 of metrics). On load, mismatch increments internal counter (future gauge TBD) and recalculates stored value.

Age-based Auto Eviction:
If `SERAPHINA_SIM_CACHE_MAX_AGE_MS` > 0, entries older than cutoff are removed upon insertion events (increments prune counters).

Compression threshold env:
`SERAPHINA_SIM_CACHE_COMPRESS_THRESHOLD` (bytes, default 65536) – if serialized JSON length >= threshold, file saved gzipped.

### Persistence File Schema
### Training Integrity & Gauges
Training runs populate an internal scoreboard accessible via `meta.getLatestTrainingScoreboard()` and exposed on `/metrics`:
Gauges:
- `seraphina_train_acc`
- `seraphina_train_acc_ethical`
- `seraphina_train_loss_a`
- `seraphina_train_loss_b`
- `seraphina_train_epoch_avg_ms`
- `seraphina_train_integrity_hash_len` (expected constant 64)
- `seraphina_train_last_promoted` (1 if promotion occurred)
- `seraphina_train_ema_vs_median_delta`

Validation ranges enforced (`validateTrainingOpts`):
- epochs: 1..100000
- lr: (0,10]
- labelFlipPct: 0..0.5
- emaAlpha: 0..1
- emaMedianThresh: 0..1
Errors return structured objects with codes above.

Integrity digests deliberately exclude volatile smoothing / trend fields (emaGain, smoothGain, promotion rationale) so identical core configurations produce identical digests even as rolling context changes.

Schema version: `1.0.0` stored as:
```
{
  "version": "1.0.0",
  "generatedTs": <number>,
  "entries": {
     "<cacheKey>": { "metrics": {...}, "createdTs": <ms>, "lastAccessTs": <ms> }
  }
}
```
Validated with Ajv; invalid file aborts hydration. Migration:
- 1.0.0 -> 1.1.0: add compression awareness.
- 1.1.0 -> 1.2.0: add per-entry `hash`.

## Security Considerations
- Guard evaluation must sanitize input; future facade layer will strip control characters and reject excessively long text (>16k chars).
- No dynamic code execution of agent outputs.
- Prometheus endpoint (pending) will expose only non-PII synthetic metrics + ledger chain hash digest.

## Future Extensions
1. Prometheus exporter exposes correlations, refinement iteration counts, bootstrap/permutation counts, target deviation deltas, duration metrics.
2. HC3 robust SE for IV and Sargan over-ID test (when multiple instruments added).
3. Async facade to allow streamed dataset generation.
4. Pluggable RNG policy / reproducibility manifest export.
5. Structured error object & logging correlation with request UUID.

## Changelog Stub
- 0.2.0: Added API module, JSDoc, fairness correlation target, refinement metadata.
- 0.2.1: Simulation cache persistence, compression threshold, integrity hash per metrics entry, prune & warm cache APIs, `/cache` endpoint.
- 0.2.2: Training integrity hashing (paramsDigest/metricsDigest/integrityHash), training param validation, added training gauges to exporter, `meta.getLatestTrainingScoreboard` accessor.
- 0.2.3: Agent per-action counters (`seraphina_agent_action_total{action}`), agent rate limiter gauges (`seraphina_agent_rate_limit_capacity`, `seraphina_agent_rate_limit_tokens_remaining`, `seraphina_agent_rate_limit_hits_total`, `seraphina_agent_rate_limit_blocked_total`, `seraphina_agent_rate_limit_refill_seconds`), cache integrity scan gauges (`seraphina_sim_cache_integrity_mismatches`, `seraphina_sim_cache_integrity_scanned`), meta test helpers (`__test_getCacheEntries`, `__test_corruptFirstCacheEntry`), version bump.
- 0.2.4: Confidence histogram metrics (`seraphina_agent_confidence_bucket{le}` cumulative, `seraphina_agent_confidence_sum`, `seraphina_agent_confidence_count`), invalid ratio gauge (`seraphina_agent_invalid_ratio`), deprecated legacy rate limiter metric family kept with deprecation HELP notes (`seraphina_agent_rate_limit_*`) in favor of unified `seraphina_agent_rate_*` gauges/counters, internal bucket update logic during agent invocation, last confidence gauge retained.
  - Adds autonomous testing module (`autotest.runAll()`, `autotest.start()`, `autotest.stop()`, `autotest.getLastReport()`) and related exporter gauges (`seraphina_autotest_last_run_timestamp_ms`, `seraphina_autotest_pass_total`, `seraphina_autotest_fail_total`, `seraphina_autotest_last_status{status}`).

---
This contract will evolve; breaking changes bump minor version until 1.0.0 stabilization.
