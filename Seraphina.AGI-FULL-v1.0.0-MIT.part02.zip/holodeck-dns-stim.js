// holodeck-dns-stim.js
// Generates deterministic DNS lookup traffic + optional agent invoke suggestions
// Usage: node holodeck-dns-stim.js --hosts=host1,host2 --agent=burrowAdapt --count=50

try { require('./holodeck/holodeck-loader'); } catch(e){ console.error('[Stim] Failed to activate holodeck loader', e.message); }
const dns = require('dns');
const crypto = require('crypto');

function parseArg(name, def){
  const m = process.argv.find(a=> a.startsWith('--'+name+'='));
  return m? m.split('=')[1] : def;
}

const hostsArg = parseArg('hosts','pool.raven.f2pool.com,fast.test.local,slow.test.local');
const hosts = hostsArg.split(',').map(s=> s.trim()).filter(Boolean);
const count = parseInt(parseArg('count','30'),10);
const agentRole = parseArg('agent','');

let invoke = global.__AUR_AGENT_INVOKE__;

function doLookup(h){
  return new Promise(res=>{
    dns.lookup(h, (err, addr)=>{
      if (err) return res({ host:h, error:err.code||err.message });
      res({ host:h, addr });
    });
  });
}

(async ()=>{
  console.log('[Stim] Starting DNS stim: hosts='+hosts.join(',')+' count='+count+' agentRole='+agentRole);
  let results=[];
  for (let i=0;i<count;i++){
    const h = hosts[i % hosts.length];
    const r = await doLookup(h);
    results.push(r);
    if (agentRole && invoke){
      const context = { acceptRatio: 0.5 + ((i % 7)/20), idx: i };
      try { await invoke(agentRole, 'Suggest micro adjustment '+i, context); } catch(e){ /* ignore */ }
    }
  }
  console.log('[Stim] Completed lookups='+results.length+' errors='+(results.filter(r=>r.error).length));
})();
