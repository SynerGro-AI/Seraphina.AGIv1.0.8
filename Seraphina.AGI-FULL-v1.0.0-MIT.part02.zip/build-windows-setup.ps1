Param(
  [string]$SourceDir = "$PSScriptRoot",
  [string]$OutDir = "$PSScriptRoot\dist-win",
  [string]$SetupName = 'SeraphinaMiner-Setup.exe',
  [string]$IconPng = '',
  [switch]$NoIcon,
  [string]$Version = '',
  [switch]$IncludeNode,
  [string]$NodeVersion = 'v20.11.1',
  [string]$SignCertPath = '',
  [string]$SignCertPassword = '',
  [string]$TimestampUrl = 'http://timestamp.digicert.com'
)
$ErrorActionPreference = 'Stop'
Write-Host "[Setup] Building Windows installer..." -ForegroundColor Cyan

if ($Version) {
  $base = [System.IO.Path]::GetFileNameWithoutExtension($SetupName)
  $ext = [System.IO.Path]::GetExtension($SetupName)
  $SetupName = "$base-$Version$ext"
}

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

# Ensure Node presence (installer doesn't include Node unless -IncludeNode)
$nodePresent = (Get-Command node -ErrorAction SilentlyContinue)
if (-not $nodePresent -and -not $IncludeNode) {
  Write-Warning "Node.js not detected. Use -IncludeNode to bundle a portable copy." }

# 1. Create archive of source
$stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$zipPath = Join-Path $OutDir "miner-$stamp.zip"
Write-Host "Compressing miner sources -> $zipPath" -ForegroundColor DarkGray
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDir, $zipPath)

# Optional portable Node (downloads win-x64 zip)
$portableNodeDir = Join-Path $OutDir 'portable-node'
$portableNodeZip = Join-Path $OutDir "node-$NodeVersion-win-x64.zip"
if ($IncludeNode) {
  if (-not (Test-Path $portableNodeZip)) {
    $nodeUrl = "https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-win-x64.zip"
    Write-Host "Downloading portable Node $NodeVersion" -ForegroundColor Cyan
    Invoke-WebRequest -Uri $nodeUrl -OutFile $portableNodeZip
  }
  if (Test-Path $portableNodeDir) { Remove-Item -Recurse -Force $portableNodeDir }
  New-Item -ItemType Directory -Path $portableNodeDir | Out-Null
  [System.IO.Compression.ZipFile]::ExtractToDirectory($portableNodeZip, $portableNodeDir)
}

# 2. Icon generation / detection
$icoPath = Join-Path $OutDir 'seraphina.ico'
$detectedIco = Get-ChildItem -Path $SourceDir -Filter '*.ico' -File -ErrorAction SilentlyContinue | Select-Object -First 1
if ($detectedIco -and -not $IconPng -and -not $NoIcon) {
  Write-Host "Using existing ICO: $($detectedIco.FullName)" -ForegroundColor DarkGray
  Copy-Item $detectedIco.FullName $icoPath -Force
} elseif (-not $NoIcon) {
  if ($IconPng -and (Test-Path $IconPng)) {
    Write-Host "Generating ICO from PNG $IconPng" -ForegroundColor DarkGray
    Add-Type -AssemblyName System.Drawing
    $bmp = [System.Drawing.Bitmap]::FromFile($IconPng)
    $stream = New-Object System.IO.FileStream($icoPath, [System.IO.FileMode]::Create)
    $icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
    $icon.Save($stream)
    $stream.Close(); $bmp.Dispose();
  } else {
    Write-Warning "Icon PNG not provided or missing; using default system icon."; $NoIcon = $true
  }
}

# 3. Install script extracted by IExpress
$installCmd = @'
@echo off
setlocal enableextensions
set TARGET="%ProgramFiles%\SeraphinaMiner"
if exist %TARGET% (echo Target exists, overwriting...) else (echo Creating %TARGET%)
mkdir %TARGET% >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::ExtractToDirectory('%~dp0miner.zip', $env:ProgramFiles + '\\SeraphinaMiner')" || goto :fail
REM Include portable Node if present
if exist "%~dp0portable-node" (
  echo Copying portable Node runtime...
  xcopy /E /I /Y "%~dp0portable-node" "%ProgramFiles%\SeraphinaMiner\portable-node" >nul
)
copy "%~dp0seraphina.ico" %TARGET% >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%ProgramFiles%\SeraphinaMiner\install-windows-miner.ps1" -Force || goto :fail
if not exist "%ProgramFiles%\SeraphinaMiner\run-miner.ps1" (
  echo Missing run-miner.ps1 after install; failing.
  goto :fail
)
echo Install complete.
exit /b 0
:fail
echo Install failed.
exit /b 1
'@
$installCmdPath = Join-Path $OutDir 'install.cmd'
Set-Content -Path $installCmdPath -Value $installCmd -Encoding ASCII

# 4. Prepare files for package (rename miner zip to miner.zip)
$zipDest = Join-Path $OutDir 'miner.zip'
Copy-Item $zipPath $zipDest -Force
if ($IncludeNode) { Write-Host "Portable Node included." -ForegroundColor DarkGray }
if (-not $NoIcon -and (Test-Path $icoPath)) { Write-Host "ICO ready." -ForegroundColor DarkGray }

# 5. IExpress SED file
$sed = @"
; IExpress SED file
[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=1
HideExtractAnimation=0
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=I
InstallPrompt=
DisplayLicense=
FinishMessage=Seraphina Miner installation finished.
TargetName=$OutDir\\$SetupName
FriendlyName=Seraphina Miner $Version
AppLaunched=install.cmd
PostInstallCmd=<None>
AdminQuietInstCmd=install.cmd
QuietInstallCmd=install.cmd
SourceFiles=SourceFiles
[SourceFiles]
" + $OutDir + "=\n[SourceFiles0]\ninstall.cmd=\nminer.zip=\n" + ($(if($IncludeNode){'portable-node='} else {''})) + ($(if(-not $NoIcon -and (Test-Path $icoPath)){'seraphina.ico='} else {''})) + "\n"

$sedPath = Join-Path $OutDir 'SeraphinaMiner.sed'
Set-Content -Path $sedPath -Value $sed -Encoding ASCII

# 6. Run IExpress to build
Write-Host "Running IExpress..." -ForegroundColor Cyan
$iexpress = "$Env:SystemRoot\System32\iexpress.exe"
if (-not (Test-Path $iexpress)) { throw "IExpress not found (available on most Windows editions)." }
& $iexpress /N "$sedPath" | Out-Null

$setupPath = Join-Path $OutDir $SetupName
if (-not (Test-Path $setupPath)) { throw "Setup build failed" }
Write-Host "Setup built: $setupPath" -ForegroundColor Green

# 7. SHA256 manifest
$sha256 = (Get-FileHash -Path $setupPath -Algorithm SHA256).Hash
$manifestObj = [ordered]@{
  name = $SetupName
  version = $Version
  built = (Get-Date).ToString('o')
  sha256 = $sha256
  includeNode = [bool]$IncludeNode
  sourceRoot = (Resolve-Path $SourceDir).Path
}
$manifestJson = ($manifestObj | ConvertTo-Json -Depth 4)
$manifestPath = Join-Path $OutDir 'installer-manifest.json'
Set-Content -Path $manifestPath -Value $manifestJson -Encoding UTF8
$shaFile = Join-Path $OutDir 'installer.sha256'
Set-Content -Path $shaFile -Value "$sha256  $SetupName" -Encoding ASCII
Write-Host "SHA256 manifest written." -ForegroundColor DarkGray

# 8. Optional code signing (requires signtool)
if ($SignCertPath -and (Test-Path $SignCertPath)) {
  $signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue)
  if ($signtool) {
    Write-Host "Signing installer..." -ForegroundColor Cyan
    $pwdArg = $(if ($SignCertPassword) {"/p $SignCertPassword"} else {''})
    & $signtool /f $SignCertPath $pwdArg /tr $TimestampUrl /td sha256 /fd sha256 $setupPath
  } else {
    Write-Warning "signtool.exe not found; skipping signing." }
}

Write-Host "All done." -ForegroundColor Green
