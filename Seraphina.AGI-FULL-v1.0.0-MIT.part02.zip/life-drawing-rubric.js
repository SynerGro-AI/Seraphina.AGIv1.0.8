// life-drawing-rubric.js
// Generates simple posture/balance hints from pose filename tokens.
'use strict';

function tokenize(filename){
  return filename.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim().split(/\s+/).filter(Boolean);
}

function generateHints(filename){
  const tokens = tokenize(filename);
  const hints = [];
  if(tokens.some(t=> /side|profile/.test(t))){ hints.push('Emphasize lateral line; check ribcage tilt.'); }
  if(tokens.some(t=> /twist|rotate/.test(t))){ hints.push('Capture spinal rotation with opposing shoulder/hip angles.'); }
  if(tokens.some(t=> /lean|tilt/.test(t))){ hints.push('Project center of gravity over base of support; show counterbalance.'); }
  if(tokens.some(t=> /stretch|reach/.test(t))){ hints.push('Extend gesture line beyond limb; accentuate negative space.'); }
  if(tokens.some(t=> /crouch|bend/.test(t))){ hints.push('Compact masses; clarify knee compression and weight distribution.'); }
  if(hints.length===0){ hints.push('Identify main gesture line and anchor masses (head, ribcage, pelvis).'); }
  return { filename, hints };
}

module.exports = { generateHints };
