#!/usr/bin/env node
// life-drawing-audit-simulate.js
// Deterministically append synthetic audit history entries to model trends.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
function sha256(x){ return crypto.createHash('sha256').update(String(x)).digest('hex'); }

function rng(seed){
  let h = sha256(seed); let i=0;
  return function(){
    if(i>=h.length-8){ h = sha256(h); i=0; }
    const slice = h.slice(i,i+8); i+=8;
    const val = parseInt(slice,16)/0xffffffff; // ~0..1
    return val;
  };
}

function simulate(opts={}){
  const count = parseInt(process.env.AUDIT_SIM_COUNT || opts.count || '20',10);
  const seed = process.env.AUDIT_SIM_SEED || opts.seed || 'audit-sim-seed-v1';
  const trendHigh = parseFloat(process.env.AUDIT_SIM_TREND_HIGH || opts.trendHigh || '0.1'); // expected avg increment probability
  const trendModerate = parseFloat(process.env.AUDIT_SIM_TREND_MOD || opts.trendModerate || '0.05');
  const r = rng(seed);
  let low=0, moderate=0, high=2, critical=0; // start from current observed sample
  const histPath = path.join(__dirname,'life-drawing-audit-history.jsonl');
  for(let idx=0; idx<count; idx++){
    // deterministic drift
    if(r() < trendHigh) high += 1;
    if(r() < trendModerate) moderate += 1;
    // occasional remediation (reduce high) if r() small
    if(high>0 && r() < 0.02) high -= 1;
    const counts = { low, moderate, high, critical };
    const entry = { ts: new Date(Date.now() + idx*60000).toISOString(), counts, digest: sha256(JSON.stringify(counts)) };
    fs.appendFileSync(histPath, JSON.stringify(entry)+'\n');
  }
  return { ok:true, appended: count };
}

if(require.main === module){
  console.log(JSON.stringify(simulate(), null, 2));
}

module.exports = { simulate };
