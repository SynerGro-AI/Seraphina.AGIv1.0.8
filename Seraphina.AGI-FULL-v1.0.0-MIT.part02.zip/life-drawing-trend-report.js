// life-drawing-trend-report.js
// Analyze ledger for rolling score/completeness trends and practice gaps.
'use strict';
const fs = require('fs');
const path = require('path');

function readLedger(){
  const ledgerPath = path.join(__dirname,'life-drawing-session-ledger.jsonl');
  if(!fs.existsSync(ledgerPath)) return [];
  const lines = fs.readFileSync(ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean);
  return lines.map(l=>{ try { return JSON.parse(l); } catch(_){ return null; } }).filter(Boolean);
}

function computeTrends(opts={}){
  const entries = readLedger();
  if(!entries.length) return { ok:false, message:'No ledger sessions yet.' };
  // Sort by time ascending for rolling computation
  entries.sort((a,b)=> a.ts - b.ts);
  const windowSize = parseInt(opts.windowSize || process.env.LIFE_DRAWING_TREND_WINDOW || '5',10);
  const scoreSeries = entries.map(e=> e.totalScore);
  const completenessSeries = entries.map(e=> e.avgCompleteness || 0);
  function rollingAvg(arr, w){
    const out=[]; for(let i=0;i<arr.length;i++){ const start=Math.max(0,i-w+1); const slice=arr.slice(start,i+1); out.push(slice.reduce((a,b)=>a+b,0)/slice.length); } return out; }
  const scoreRolling = rollingAvg(scoreSeries, windowSize);
  const completenessRolling = rollingAvg(completenessSeries, windowSize);
  // Trend slope (last window linear regression simplified)
  function slope(arr){
    const n = arr.length; if(n<2) return 0; const xAvg=(n-1)/2; const yAvg=arr.reduce((a,b)=>a+b,0)/n; let num=0,den=0; for(let i=0;i<n;i++){ num += (i - xAvg)*(arr[i]-yAvg); den += (i - xAvg)**2; } return den? num/den:0; }
  const recentSpan = Math.min(windowSize, scoreRolling.length);
  const scoreSlope = slope(scoreRolling.slice(-recentSpan));
  const completenessSlope = slope(completenessRolling.slice(-recentSpan));
  // Field coverage gap detection: last session snapshot vs frequency rank
  const last = entries[entries.length-1];
  const seenFields = new Set(last.fieldCoverageSnapshot||[]);
  // Build usage counts across ledger snapshots
  const fieldCounts = {};
  entries.forEach(e=>{ (e.fieldCoverageSnapshot||[]).forEach(f=>{ fieldCounts[f] = (fieldCounts[f]||0)+1; }); });
  const allFields = Object.keys(fieldCounts).map(f=> ({ field:f, count:fieldCounts[f] }));
  allFields.sort((a,b)=> a.count - b.count); // ascending: least practiced
  const leastPracticed = allFields.slice(0, Math.max(1, Math.ceil(allFields.length*0.25)));
  const gaps = leastPracticed.filter(f=> !seenFields.has(f.field));
  // Field delta improvements: compare counts in first half vs second half
  const midIndex = Math.floor(entries.length/2);
  const firstCounts = {}; const secondCounts = {};
  entries.forEach((e,i)=>{ (e.fieldCoverageSnapshot||[]).forEach(f=>{ (i<midIndex? firstCounts: secondCounts)[f] = ((i<midIndex? firstCounts: secondCounts)[f]||0)+1; }); });
  const allFieldNames = new Set([...Object.keys(firstCounts), ...Object.keys(secondCounts)]);
  const fieldDeltas = [];
  allFieldNames.forEach(f=>{
    const a = firstCounts[f]||0; const b = secondCounts[f]||0; const delta = b - a;
    fieldDeltas.push({ field:f, first:a, second:b, delta });
  });
  fieldDeltas.sort((a,b)=> b.delta - a.delta);
  const improving = fieldDeltas.filter(d=> d.delta>0).slice(0,5);
  const declining = fieldDeltas.filter(d=> d.delta<0).slice(0,5);
  let scoreSpark=null, completenessSpark=null;
  if(opts.sparkline){
    const blocks = ['▁','▂','▃','▄','▅','▆','▇','█'];
    const maxScore = Math.max(...scoreRolling,1); const maxComp = Math.max(...completenessRolling,1);
    scoreSpark = scoreRolling.map(v=> blocks[Math.min(blocks.length-1, Math.floor((v/maxScore)*(blocks.length-1)))]).join('');
    completenessSpark = completenessRolling.map(v=> blocks[Math.min(blocks.length-1, Math.floor((v/maxComp)*(blocks.length-1)))]).join('');
  }
  const result = {
    ok:true,
    totalSessions: entries.length,
    windowSize,
    scoreRolling,
    completenessRolling,
    scoreSlope: Number(scoreSlope.toFixed(4)),
    completenessSlope: Number(completenessSlope.toFixed(4)),
    recentImproving: scoreSlope>0 && completenessSlope>0,
    fieldPracticeGaps: gaps.map(g=> g.field),
    leastPracticed,
    improvingFields: improving,
    decliningFields: declining,
    fieldDeltas,
    scoreSpark,
    completenessSpark
  };
  if(opts.format==='csv'){
    const header = 'field,first_half,second_half,delta';
    const rows = fieldDeltas.map(d=> [d.field,d.first,d.second,d.delta].join(','));
    return header+'\n'+rows.join('\n');
  }
  return result;
}

if(require.main === module){
  const format = process.argv.includes('--csv') ? 'csv' : 'json';
  const sparkline = process.argv.includes('--sparkline');
  const report = computeTrends({ format, sparkline });
  if(sparkline){ console.log(JSON.stringify(report,null,2)); }
  else if(format==='csv') console.log(report); else console.log(JSON.stringify(report,null,2));
}

module.exports = { computeTrends };
