// benchmark-hash-midstate.js
// Performance measurement harness for cooperative midstate refactor
// Measures: raw double SHA256, optimized midstate-style path, worker shard batch throughput (simulated)

const crypto = require('crypto');

function reverseBytes(buf){ const b=Buffer.from(buf); b.reverse(); return b; }

function doubleSha256Buf(b){ const h1 = crypto.createHash('sha256').update(b).digest(); return crypto.createHash('sha256').update(h1).digest(); }

function randomHex(len){ return crypto.randomBytes(len/2).toString('hex'); }

// Build synthetic block header components (80 bytes header but we simulate variable nonce/time portion)
function buildHeaderParts(){
  const version = Buffer.alloc(4,0x01);
  const prevhash = crypto.randomBytes(32);
  const merkle = crypto.randomBytes(32);
  const time = Buffer.alloc(4); time.writeUInt32LE(Math.floor(Date.now()/1000));
  const bits = Buffer.from('ffff001f','hex').reverse(); // test difficulty
  return { version, prevhash, merkle, time, bits };
}

function assembleHeaderStatic(parts){
  return Buffer.concat([ parts.version, parts.prevhash, parts.merkle, parts.time, parts.bits ]); // 4+32+32+4+4 = 76 bytes static
}

function naiveHash(headerStatic, nonce){
  const nonceBuf = Buffer.alloc(4); nonceBuf.writeUInt32LE(nonce>>>0);
  const full = Buffer.concat([headerStatic, nonceBuf]);
  return doubleSha256Buf(full);
}

// Midstate style: first SHA256 over (static76 + nonce4) would still need full 80 bytes; however, if many nonce iterations share the same first 64 bytes block we can reuse hash state.
// Here we simulate reuse of first 64 bytes midstate and process tail (remaining 16 + nonce) as second chunk (simplified illustrative approach).

function sha256MidstateFirst64(buf64){
  const h = crypto.createHash('sha256');
  h.update(buf64); // returns no midstate externally; we simulate by hashing and slicing
  // Node crypto does not expose internal state, so we approximate cost by pre-hashing first 64 bytes once and combining.
  return h.digest();
}

function optimizedHash(headerStatic, nonce, first64Digest){
  // For illustration we just combine pre-digest + tail and hash again (NOT canonical midstate but comparative for CPU cost trend)
  const tail = Buffer.concat([headerStatic.slice(64), Buffer.alloc(4,0)]); // placeholder
  const mix = crypto.createHash('sha256').update(first64Digest).update(tail).update(Buffer.from([(nonce>>>0)&0xff,(nonce>>>8)&0xff,(nonce>>>16)&0xff,(nonce>>>24)&0xff])).digest();
  return crypto.createHash('sha256').update(mix).digest();
}

function bench(label, fn, iterations){
  const t0 = process.hrtime.bigint();
  let acc=0; for (let i=0;i<iterations;i++){ acc ^= fn(i)[0]; }
  const dt = Number(process.hrtime.bigint() - t0)/1e6;
  return { label, ms: dt, iter: iterations, khs: (iterations/(dt/1000))/1000, acc };
}

function main(){
  const ITER = parseInt(process.env.BENCH_ITER||'200000',10);
  const parts = buildHeaderParts();
  const static76 = assembleHeaderStatic(parts);
  const first64 = static76.slice(0,64);
  const first64Digest = sha256MidstateFirst64(first64);
  const naive = bench('naive-double-sha256', (i)=> naiveHash(static76, i), ITER);
  const opt = bench('optimized-midstate-like', (i)=> optimizedHash(static76, i, first64Digest), ITER);
  console.table([naive,opt]);
  const speedup = (opt.ms ? (naive.ms/opt.ms) : 0).toFixed(3);
  console.log(`Approx speedup factor (illustrative)=${speedup}x over ${ITER} iterations`);
}

if (require.main === module){ main(); }
