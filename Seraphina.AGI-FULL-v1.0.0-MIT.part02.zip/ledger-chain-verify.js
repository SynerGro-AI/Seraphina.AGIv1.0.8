// ledger-chain-verify.js
// Verify integrity of hash-chained ledgers: companion-suggestions, income, trade-ab (if enabled), governance decisions.
// Usage: node ledger-chain-verify.js (optional env LEDGER_OUT=ledger-verify.json)

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const LEDGERS = [
  { name:'companion', path: process.env.COMPANION_LEDGER_PATH || 'companion-suggestions.jsonl', hashField:'chainHash', prevField:'prevHash' },
  { name:'income', path: process.env.INCOME_LEDGER_PATH || 'income-ledger.jsonl', hashField:'chainHash', prevField:'prevHash' },
  { name:'tradeAB', path: process.env.TRADING_AB_LEDGER_PATH || 'trade-ab-ledger.jsonl', hashField:'chainHash', prevField:'prevHash' },
  { name:'governanceDecisions', path: process.env.GOV_DECISIONS_PATH || 'governance-decisions.jsonl', hashField:'chainHash', prevField:'prevHash' }
];

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function verifyLedger(def){
  const res = { name:def.name, path:def.path, entries:0, issues:[], ok:true };
  if(!fs.existsSync(def.path)){ res.ok=false; res.issues.push('missing'); return res; }
  const lines = fs.readFileSync(def.path,'utf8').trim().split(/\n+/);
  let prev = 'GENESIS';
  lines.forEach((l,i)=>{
    let obj=null; try { obj=JSON.parse(l); } catch(e){ res.ok=false; res.issues.push(`line ${i+1} JSON parse fail`); return; }
    res.entries++;
    // Recompute chain hash excluding chainHash field itself to match creation logic (entry included chainHash -> we replicate original algorithm?).
    // We assume original hash = sha256(JSON(entryWithoutChainHash? entryWith?)). For current implementation: some ledgers hashed entry before adding chainHash.
    // Attempt both strategies deterministically.
    const clone = { ...obj }; delete clone[def.hashField];
    const hash1 = stableHash(clone);
    const hash2 = stableHash(obj);
    const declared = obj[def.hashField];
    const match = (declared === hash1) || (declared === hash2);
    if(!match){ res.ok=false; res.issues.push(`line ${i+1} hash mismatch`); }
    if(obj[def.prevField] !== prev){ res.ok=false; res.issues.push(`line ${i+1} prevHash mismatch expected ${prev} got ${obj[def.prevField]}`); }
    prev = declared;
  });
  return res;
}

function main(){
  const out = [];
  LEDGERS.forEach(def=> out.push(verifyLedger(def)));
  const summary = { ts: new Date().toISOString(), ledgers: out };
  const outPath = process.env.LEDGER_OUT || 'ledger-verify.json';
  try { fs.writeFileSync(outPath, JSON.stringify(summary, null, 2)); console.log('[LEDGER_VERIFY] wrote', outPath); } catch(e){ console.error('[LEDGER_VERIFY] write failed', e.message); process.exit(2); }
  out.forEach(r=>{
    console.log(`[LEDGER_VERIFY] ${r.name} ok=${r.ok} entries=${r.entries} issues=${r.issues.length}`);
  });
  const allOk = out.every(r=> r.ok);
  process.exit(allOk?0:1);
}

main();
