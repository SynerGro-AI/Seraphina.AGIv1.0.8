#!/usr/bin/env node
// life-drawing-forecast.js
// Deterministic forecast stubs: linear extrapolation of score & completeness trends + field practice/retention outlook.
'use strict';
const { computeTrends } = require('./life-drawing-trend-report');
const { computeRetention } = require('./life-drawing-retention');
const { generateReport } = require('./life-drawing-coverage-report');

function linearProject(current, slope, steps){
  // slope assumed per session; project steps sessions ahead.
  const arr = [];
  for(let i=1;i<=steps;i++){ arr.push(Number((current + slope * i).toFixed(4))); }
  return arr;
}

function buildForecast(opts={}){
  const horizon = parseInt(process.env.LIFE_DRAWING_FORECAST_HORIZON || opts.horizon || '12',10); // sessions ahead
  const vol = parseFloat(process.env.LIFE_DRAWING_FORECAST_VOL || opts.vol || '0.08'); // relative volatility factor (0..1)
  const trends = computeTrends();
  const retention = computeRetention();
  const coverage = generateReport();
  if(!trends.ok || !retention.ok || !coverage.ok){
    return { ok:false, message:'Insufficient analytics for forecast.' };
  }
  const scoreBase = trends.scoreRollingAvg || trends.scoreSlope;
  const completenessBase = trends.completenessRollingAvg || trends.completenessSlope;
  const scorePath = linearProject(scoreBase, trends.scoreSlope, horizon);
  const completenessPath = linearProject(completenessBase, trends.completenessSlope, horizon);
  // Variance bands: +/- vol * sqrt(step) scaled by base metric magnitude (deterministic, no randomness)
  function bands(path){
    return path.map((v,i)=>{
      const step = i+1;
      const delta = Number((vol * Math.sqrt(step) * 0.1 * Math.max(1, Math.abs(v))).toFixed(4));
      return { value: v, low: Number((v - delta).toFixed(4)), high: Number((v + delta).toFixed(4)) };
    });
  }
  const scoreBands = bands(scorePath);
  const completenessBands = bands(completenessPath);
  // Field outlook: for each field take last retention value and assume mild mean-reversion toward 0.5 with decay based on slope sign.
  const fieldOutlook = retention.fields.map(f=>{
    const current = f.retention;
    // simple deterministic rule: target moves 10% toward 0.5 per horizon step
    const projected = linearProject(current, (0.5 - current) * 0.1, horizon);
    const fieldBands = bands(projected);
    return { field: f.field, current: Number(current.toFixed(4)), projected, bands: fieldBands };
  });
  // Practice recommendation stability: use recommendationDetail scores trend -> assume no score history, so static plus minor normalization drift.
  const recDetail = coverage.recommendationDetail || [];
  const recommendationOutlook = recDetail.map(r=> {
    const projected = linearProject(r.score, (0.5 - r.score)*0.05, horizon);
    const recBands = bands(projected);
    return { field: r.field, currentScore: Number(r.score.toFixed(4)), projected, bands: recBands };
  });
  // Deterministic confidence heuristics (0..1):
  // Lower band spread relative to value -> higher confidence.
  function confidenceFromBands(b){
    const spreads = b.map(x=> (x.high - x.low)/Math.max(1e-9, Math.abs(x.value)));
    const avgSpread = spreads.reduce((a,c)=> a+c,0)/spreads.length;
    const conf = Math.max(0, Math.min(1, 1 - avgSpread));
    return Number(conf.toFixed(4));
  }
  const scoreConfidence = confidenceFromBands(scoreBands);
  const completenessConfidence = confidenceFromBands(completenessBands);
  return { ok:true, horizon, vol, scorePath, completenessPath, scoreBands, completenessBands, fieldOutlook, recommendationOutlook, scoreConfidence, completenessConfidence };
}

if(require.main === module){
  console.log(JSON.stringify(buildForecast(), null, 2));
}

module.exports = { buildForecast };
