#!/usr/bin/env node
/**
 * Litecoin Mining Readiness Assessment
 * ------------------------------------
 * Evaluates environment + module prerequisites for activating real LTC (scrypt) mining later.
 * Safe to run repeatedly; does NOT start hashing.
 *
 * Checks:
 *  - Presence of scryptsy module
 *  - Detected hash strategy (by requiring hash-strategies)
 *  - Address validity for LTC_MINING_ADDRESS / LTC_KRAKEN_ADDRESS (basic + Base58Check / bech32 pattern)
 *  - Pool host/port defaults or overrides
 *  - REAL_STRICT implications (enforces real hash path)
 *  - Suggests next steps to move from readiness to activation
 */
const crypto = require('crypto');

let scryptsy=null; try { scryptsy = require('scryptsy'); } catch(_){ }
const { HASH_STRATEGIES } = require('./hash-strategies.js');

const result = { ts: Date.now(), checks: {}, recommendations: [] };

function pushRec(r){ result.recommendations.push(r); }

// 1. Module presence
result.checks.scryptsy_present = !!scryptsy;
if (!scryptsy) pushRec('Install scryptsy for real LTC hashing: npm install scryptsy');

// 2. Hash strategy detection
result.checks.hash_strategies_has_scrypt = !!HASH_STRATEGIES.scrypt;
if (!HASH_STRATEGIES.scrypt) pushRec('HASH_STRATEGIES.scrypt missing (likely scryptsy load failed).');

// 3. Address validation
const ltcAddr = process.env.LTC_MINING_ADDRESS || process.env.LTC_KRAKEN_ADDRESS || null;
result.checks.ltc_address_provided = !!ltcAddr;

const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const base58Map = new Map([...base58Alphabet].map((c,i)=>[c,i]));
function decodeBase58(str){
  let num=BigInt(0); const base=BigInt(58);
  for (const ch of str){ const v = base58Map.get(ch); if (v==null) throw new Error('invalid char '+ch); num = num*base + BigInt(v); }
  let bytes=[]; while(num>0){ bytes.push(Number(num & BigInt(0xff))); num >>= BigInt(8); }
  bytes = bytes.reverse();
  for (const ch of str){ if (ch==='1') bytes.unshift(0); else break; }
  return Buffer.from(bytes);
}
function ltcCheck(addr){
  if (!addr) return { ok:false, error:'missing'};
  if (/^ltc1[0-9ac-hj-np-z]{20,}$/i.test(addr)) return { ok:true, bech32:true };
  try {
    const buf = decodeBase58(addr); if (buf.length<4) return { ok:false, error:'too short'};
    const payload=buf.slice(0,-4), checksum=buf.slice(-4);
    const h=crypto.createHash('sha256').update(crypto.createHash('sha256').update(payload).digest()).digest();
    if (!checksum.equals(h.slice(0,4))) return { ok:false, error:'checksum mismatch' };
    const ver = payload[0];
    if ([0x30,0x32,0x05].includes(ver)) return { ok:true, version:ver };
    return { ok:false, error:'unexpected version '+ver };
  } catch(e){ return { ok:false, error:e.message }; }
}
result.checks.ltc_address_validation = ltcCheck(ltcAddr);
if (!result.checks.ltc_address_validation.ok) pushRec('Provide valid LTC address via LTC_MINING_ADDRESS before enabling LTC mining.');

// 4. Pool config
const poolHost = process.env.LTC_POOL_HOST || 'ltc.f2pool.com';
const poolPort = parseInt(process.env.LTC_POOL_PORT || '3335',10);
result.checks.pool = { host: poolHost, port: poolPort };
if (poolPort<=0 || poolPort>65535) pushRec('Set valid LTC_POOL_PORT');

// 5. REAL_STRICT interplay
const realStrict = process.env.REAL_STRICT==='1';
result.checks.real_strict = realStrict;
if (realStrict && !scryptsy) pushRec('REAL_STRICT active but scryptsy missing: cannot proceed with authentic LTC hashing.');

// 6. Worker string derivation preview
const rig = process.env.RIG_NAME || 'Rig01';
let workerPreview = null;
if (ltcAddr) workerPreview = ltcAddr + '.' + rig;
result.checks.worker_preview = workerPreview;

// 7. Activation readiness classification
const ready = result.checks.scryptsy_present && result.checks.hash_strategies_has_scrypt && result.checks.ltc_address_validation.ok;
result.status = ready ? 'READY' : 'NOT_READY';
if (ready) pushRec('Set AUR_COIN=ltc STRATUM_WORKER='+workerPreview+' to attempt connection (after verifying pool acceptance).');

console.log(JSON.stringify(result,null,2));
if (!ready) process.exit(2);