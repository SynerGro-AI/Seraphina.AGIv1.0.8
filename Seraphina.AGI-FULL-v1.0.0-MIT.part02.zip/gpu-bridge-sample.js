#!/usr/bin/env node
// gpu-bridge-sample.js – demonstration external GPU hasher protocol
// Reads job JSON lines from stdin and randomly emits fake shares to test submit path.
// NOT a real KawPow implementation.

const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin });
console.log(JSON.stringify({ type:'ready' }));
let currentJob=null;
rl.on('line', line => {
  line=line.trim(); if(!line) return;
  try {
    const msg = JSON.parse(line);
    if (msg.type==='job'){
      currentJob = msg;
      console.error('[Bridge] Job received', msg.jobId);
      // schedule a few fake shares
      for (let i=1;i<=3;i++){
        setTimeout(()=>{
          if (!currentJob) return;
          const { deriveHex } = require('./deterministic-util');
          const ex2 = deriveHex('gpu-ex2', currentJob.ex2Size, i, Date.now()).slice(0, currentJob.ex2Size*2).padStart(currentJob.ex2Size*2,'0');
          const nonce = deriveHex('gpu-nonce', i, Date.now(), currentJob.jobId).slice(0,8).padStart(8,'0');
          const ntime = (parseInt(currentJob.ntime,16)+i).toString(16).padStart(8,'0');
          const share = { type:'share', jobId: currentJob.jobId, ex2, ntime, nonce, mixHash: 'deadbeef'.repeat(8) };
          process.stdout.write(JSON.stringify(share)+'\n');
        }, 1000*i);
      }
    }
  } catch(e){ console.error('[Bridge] Bad line', e.message); }
});
rl.on('close', ()=> process.exit(0));
