#!/usr/bin/env node
// life-drawing-audit-trend.js
// Compute linear slope and rolling averages of cached audit severity counts.
'use strict';
const fs = require('fs');
const path = require('path');

function readHistory(){
  const histPath = path.join(__dirname,'life-drawing-audit-history.jsonl');
  if(!fs.existsSync(histPath)) return [];
  return fs.readFileSync(histPath,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try { return JSON.parse(l); } catch(_){ return null; } }).filter(Boolean);
}

function computeTrend(opts={}){
  const entries = readHistory();
  if(!entries.length) return { ok:false, message:'No audit history' };
  // Limit to last N (default 50)
  const limit = parseInt(process.env.AUDIT_TREND_LIMIT || opts.limit || '50',10);
  const recent = entries.slice(-limit);
  // Build arrays per severity
  const severities = ['low','moderate','high','critical'];
  const points = severities.reduce((acc,s)=>{ acc[s] = recent.map(e=> (e.counts && typeof e.counts[s] === 'number')? e.counts[s]:0 ); return acc; }, {});
  function slope(arr){
    const n = arr.length; if(n<2) return 0;
    const xs = arr.map((_,i)=> i);
    const meanX = (n-1)/2; const meanY = arr.reduce((a,c)=> a+c,0)/n;
    let num=0, den=0; for(let i=0;i<n;i++){ const dx = xs[i]-meanX; num += dx*(arr[i]-meanY); den += dx*dx; }
    return den? Number((num/den).toFixed(6)) : 0;
  }
  function rolling(arr, win){
    const out=[]; for(let i=0;i<arr.length;i++){ const start=Math.max(0,i-win+1); const slice=arr.slice(start,i+1); out.push(Number((slice.reduce((a,c)=>a+c,0)/slice.length).toFixed(4))); } return out;
  }
  const windowSize = parseInt(process.env.AUDIT_TREND_WINDOW || opts.window || '5',10);
  const result = severities.map(s=> ({ severity: s, latest: points[s][points[s].length-1], slope: slope(points[s]), rollingAvg: rolling(points[s], windowSize) }));
  return { ok:true, count: recent.length, windowSize, severities: result };
}

if(require.main === module){
  console.log(JSON.stringify(computeTrend(), null, 2));
}

module.exports = { computeTrend };
