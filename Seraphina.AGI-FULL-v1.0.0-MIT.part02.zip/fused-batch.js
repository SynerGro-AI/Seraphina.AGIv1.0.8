"use strict";
// fused-batch.js – unified fused/WASM batch hashing + parity guard + adaptive batch sizing
// Focuses on SHA256d double hash batching; degrades gracefully to CPU.
// Exports:
//   createFusedBatch(options) -> { hashBatch(headersHex[]), stats }
// Options:
//   parityInterval (default 100), increaseFactor, decreaseFactor, minInterval, maxInterval
//   targetBatchMs (default 20), minSize (16), maxSize (512), adjustEvery (8)
//   enable (boolean) – if false, always CPU
//   hashFn(hex) fallback CPU function
//   fusedImpl (object) with doubleSha256Batch(Buffer[]) -> Buffer[]

const crypto = require('crypto');
let prom=null; try { prom=require('prom-client'); } catch(_){}

function createFusedBatch(opts={}){
  const cfg = {
    parityInterval: opts.parityInterval || 100,
    increaseFactor: opts.increaseFactor || 1.5,
    decreaseFactor: opts.decreaseFactor || 0.5,
    minInterval: opts.minInterval || 10,
    maxInterval: opts.maxInterval || 400,
    targetBatchMs: opts.targetBatchMs || 20,
    minSize: opts.minSize || 16,
    maxSize: opts.maxSize || 512,
    adjustEvery: opts.adjustEvery || 8,
    enable: opts.enable !== false,
    hashFn: opts.hashFn || (h=> crypto.createHash('sha256').update(Buffer.from(crypto.createHash('sha256').update(Buffer.from(h,'hex')).digest())).digest('hex')),
    fusedImpl: opts.fusedImpl || null
  };
  let batchSize = Math.min(cfg.maxSize, Math.max(cfg.minSize, opts.initialSize || 128));
  let parityInterval = cfg.parityInterval;
  let batchCount = 0;
  let parityStable = 0;
  let disabled = !cfg.enable || !cfg.fusedImpl;
  const stats = { batches:0, fallbacks:0, parityMismatches:0, parityInterval, batchSize, speedupEwma:null, lastLatencyNs:0 };
  let gauges=null;
  if (prom && process.env.METRICS==='1'){
    try { gauges = {
      batchSize: new prom.Gauge({ name:'aurrelia_fused_batch_size', help:'Current fused batch size' }),
      parityInterval: new prom.Gauge({ name:'aurrelia_fused_parity_interval', help:'Current fused parity interval batches' }),
      mismatches: new prom.Counter({ name:'aurrelia_fused_parity_mismatches_total', help:'Total fused parity mismatches' }),
      speedup: new prom.Gauge({ name:'aurrelia_fused_speedup_est', help:'Estimated CPU speedup ratio' }),
      latencyNs: new prom.Gauge({ name:'aurrelia_fused_last_latency_ns', help:'Last fused per-header latency ns' })
    }; } catch(_){ gauges=null; }
  }

  function cpuBatch(hexes){ return hexes.map(cfg.hashFn); }

  function hashBatch(headers){
    if (disabled) return Promise.resolve(cpuBatch(headers));
    const buffers = headers.map(h=> Buffer.from(h,'hex'));
    const start = process.hrtime.bigint();
    let digests;
    try { digests = cfg.fusedImpl.doubleSha256Batch(buffers).map(b=> b.toString('hex')); }
    catch(e){ disabled=true; stats.fallbacks += buffers.length; return Promise.resolve(cpuBatch(headers)); }
    const end = process.hrtime.bigint();
    const batchNs = Number(end - start);
    stats.lastLatencyNs = batchNs / (buffers.length||1);
    stats.batches++;
    batchCount++;
    // Parity sample
  if (batchCount % parityInterval === 0){
      const sampleHex = headers[0];
      try {
        const cpu = cfg.hashFn(sampleHex);
        if (cpu !== digests[0]){
          stats.parityMismatches++;
          if (gauges) gauges.mismatches.inc();
          disabled = true; // hard disable fused path
          parityInterval = Math.max(cfg.minInterval, Math.round(parityInterval * cfg.decreaseFactor));
          stats.parityInterval = parityInterval;
          return digests.map((_,i)=> i===0? cpu : digests[i]);
        } else {
          parityStable++;
          if (parityStable >= cfg.adjustEvery && parityInterval < cfg.maxInterval){
            parityInterval = Math.min(cfg.maxInterval, Math.round(parityInterval * cfg.increaseFactor));
            stats.parityInterval = parityInterval;
            parityStable = 0;
          }
          // speedup estimate (cpu single vs avg per header fused)
          const cpuStart = process.hrtime.bigint(); cfg.hashFn(sampleHex); const cpuNs = Number(process.hrtime.bigint()-cpuStart);
          const speed = cpuNs / stats.lastLatencyNs;
          stats.speedupEwma = stats.speedupEwma == null ? speed : stats.speedupEwma*0.7 + speed*0.3;
          if (gauges){ gauges.speedup.set(stats.speedupEwma); }
        }
      } catch(_){ /* ignore parity errors */ }
    }
    // Adaptive size
  if (stats.batches % cfg.adjustEvery === 0){
      const perHeaderMs = stats.lastLatencyNs/1e6;
      const batchMs = perHeaderMs * batchSize;
      if (batchMs < cfg.targetBatchMs*0.6 && batchSize < cfg.maxSize){ batchSize = Math.min(cfg.maxSize, batchSize*2); }
      else if (batchMs > cfg.targetBatchMs && batchSize > cfg.minSize){ batchSize = Math.max(cfg.minSize, Math.floor(batchSize/2)); }
      stats.batchSize = batchSize;
    }
    if (gauges){ gauges.batchSize.set(batchSize); gauges.parityInterval.set(parityInterval); gauges.latencyNs.set(stats.lastLatencyNs); }
    return Promise.resolve(digests);
  }

  return { hashBatch, stats:()=>({ ...stats, disabled, batchSize, parityInterval }) };
}

module.exports = { createFusedBatch };
