// governance-engine.js
// Deterministic parameter governance proposal evaluation.
// Proposals are appended to governance-proposals.jsonl and evaluated for quorum deterministically.
// Each proposal: { id, t, params:{KEY:VALUE,...}, participants:[addr,...] }
// Quorum simulation: hash of participant id mod 100 < approvalThreshold% considered 'approve'. Approval threshold env GOV_APPROVAL_PCT (default 60).
// On approval, parameters applied (bounded) and logged. No external code execution.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const PROP_FILE = process.env.GOV_PROPOSALS_PATH || 'governance-proposals.jsonl';
const DECISIONS_FILE = process.env.GOV_DECISIONS_PATH || 'governance-decisions.jsonl';
const APPROVAL_PCT = parseInt(process.env.GOV_APPROVAL_PCT || '60',10); // percent
const PARAM_BOUNDS = {
  ECON_FREN_BIAS: [0.5, 3],
  ECON_RVN_BIAS: [0.5, 3],
  ECON_BTC_BIAS: [0.1, 2],
  ECON_KAS_BIAS: [0.1, 2],
  ECON_HYSTERESIS_CYCLES: [1, 12],
  TRADING_MIN_SPREAD_FOR_SWAP: [0.005, 0.5],
  SWAP_FEE_RATE: [0.0001, 0.02],
  LEARNED_START_MULTI: [0.8, 2.2],
  LEARNED_MIN_MULTI: [0.5, 1.5],
  LEARNED_MAX_MULTI: [1.0, 3.0],
  // Training trigger: 0 or 1 interpreted as boolean (apply clamps still numeric)
  ML_TRAIN_TRIGGER: [0, 1],
  // Expand grid candidate search count (multiplier applied to base candidate count bounds)
  LEARNING_GRID_EXPAND: [1, 10],
  // Imagination enable flag (0/1)
  IMAGINATION_ENABLED: [0, 1],
  // Max scenarios allowed surfaced via governance
  IMAGINATION_MAX_SCENARIOS: [1, 256],
  // Minimum effective improvement required to accept new weights (0..1)
  GLOBAL_MIN_IMPROVEMENT: [0, 1],
  // Weight applied to imagination aggregate gain when computing effective improvement (0..5)
  IMAGINATION_GAIN_WEIGHT: [0, 5]
  , SANDBOX_ENABLED: [0,1]
  , CURIOSITY_GAIN_WEIGHT: [0,5]
  , CURIOSITY_TUNE_LOW_THRESHOLD: [0, 0.5]
  , CURIOSITY_TUNE_HIGH_THRESHOLD: [0, 1]
  , IMAGINATION_TUNE_LOW_THRESHOLD: [0, 1]
  , TUNER_MAX_DRAFTS_WINDOW: [1, 100]
  , INTEGRATION_GAIN_WEIGHT: [0,5]
  , PARETO_ENABLED: [0,1]
  , IMAGINATION_DIM_TARGET: [3, 64]
  , IMAGINATION_DIM_STEP_MAX: [1, 16]
  , IMAGINATION_DIM_VARIANCE_THRESHOLD: [0, 0.5]
  , IMAGINATION_DIM_PLATEAU_RUNS: [1, 50]
  , IMAGINATION_DIM_ROLLBACK_RUNS: [1, 50]
  , IMAGINATION_DIM_RAMP_STEP: [1, 32]
  , IMAGINATION_DIM_MIN_INTEGRATION: [0, 1]
  , IMAGINATION_DIM_MIN_EMPOWERMENT: [0, 1]
  , DIMENSION_ROLLBACK_PROPOSAL_MODE: [0,1]
  , EMPOWERMENT_GAIN_WEIGHT: [0,5]
  , IMAGINATION_DIM_ESC_COOLDOWN_RUNS: [0, 100]
  , IMAGINATION_DIM_COST_LIMIT: [0, 100000]
  , IMAGINATION_DIM_COST_ALT_LIMIT: [0, 100000]
  , REGRESSION_WINDOW_SIZE: [3, 200]
  , NOVELTY_SPARSE_THRESHOLD: [0,1]
  , PARETO_MAX_CANDIDATES: [0,100000]
  , PARETO_EPSILON: [0,1]
  , PARETO_EPSILON_IMAGINATION: [0,1]
  , PARETO_EPSILON_CURIOSITY: [0,1]
  , PARETO_EPSILON_INTEGRATION: [0,1]
  , PARETO_EPSILON_EMPOWERMENT: [0,1]
  , PARETO_EPSILON_NOVELTY: [0,1]
  , PARETO_INCLUDE_NOVELTY: [0,1]
  , EMPOWERMENT_STABILITY_WINDOW: [5, 200]
  , AUTONOMY_ENABLED: [0,1]
  , AUTONOMY_MAX_PARAM_DELTA: [0,2]
};

let lastDecisionHash = null;
function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function loadProposals(limit=100){
  if(!fs.existsSync(PROP_FILE)) return [];
  const lines = fs.readFileSync(PROP_FILE,'utf8').trim().split(/\n+/).slice(-limit);
  const arr=[]; for(const l of lines){ try { arr.push(JSON.parse(l)); } catch(_){} }
  return arr;
}

function evaluateProposal(p){
  if(!p || !p.id || typeof p.params !== 'object') return { status:'invalid' };
  const parts = Array.isArray(p.participants)? p.participants : [];
  if(!parts.length) return { status:'no-participants' };
  let approvals=0;
  parts.forEach(addr=>{
    const h = stableHash(addr);
    const shard = parseInt(h.slice(0,8),16) % 100;
    if (shard < APPROVAL_PCT) approvals++;
  });
  const approvalRate = approvals / parts.length;
  const approved = (approvalRate*100) >= APPROVAL_PCT;
  return { status: approved?'approved':'rejected', approvalRate: Number(approvalRate.toFixed(4)) };
}

function applyParams(params){
  const applied={};
  for(const [k,v] of Object.entries(params)){
    if(!(k in PARAM_BOUNDS)) continue;
    const [min,max] = PARAM_BOUNDS[k];
    let num = parseFloat(v);
    if(!isFinite(num)) continue;
    if(num < min) num = min; if(num > max) num = max;
    applied[k]=Number(num.toFixed(8));
    // Reflect into process.env so miner picks up (must restart or live-check depending on param)
    process.env[k]= applied[k].toString();
  }
  return applied;
}

function appendDecision(entry){
  try {
    if(!lastDecisionHash){
      if(fs.existsSync(DECISIONS_FILE)){
        try { const lines = fs.readFileSync(DECISIONS_FILE,'utf8').trim().split(/\n+/); const obj=JSON.parse(lines[lines.length-1]); lastDecisionHash = obj.chainHash || 'GENESIS'; } catch(_){ lastDecisionHash='GENESIS'; }
      } else { lastDecisionHash='GENESIS'; }
    }
    entry.prevHash = lastDecisionHash;
    entry.chainHash = stableHash(entry);
    fs.appendFileSync(DECISIONS_FILE, JSON.stringify(entry)+"\n");
    lastDecisionHash = entry.chainHash;
  } catch(e){ /* ignore */ }
}

function governanceCycle(){
  try {
    const props = loadProposals(200);
    if(!props.length) return;
    const latest = props[props.length-1];
    const ev = evaluateProposal(latest);
    let applied = {};
    if(ev.status === 'approved') applied = applyParams(latest.params);
    const decision = { t: Date.now(), id: latest.id, status: ev.status, approvalRate: ev.approvalRate, applied };
    appendDecision(decision);
    if(process.env.GOVERNANCE_LOG==='1') console.log('[GOV]', decision);
    // Prometheus governance gauges (lazy)
    try {
      if (global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges){
        const g = global.__AUR_METRICS_REG__.gauges; const prom = require('prom-client');
        if (!g.govLastApprovalRate){ g.govLastApprovalRate = new prom.Gauge({ name:'aurrelia_gov_last_approval_rate', help:'Last governance proposal approval rate (0..1)' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.govLastApprovalRate); }
        if (!g.govLastDecisionStatus){ g.govLastDecisionStatus = new prom.Gauge({ name:'aurrelia_gov_last_decision_status', help:'Last governance decision status (approved=1, rejected=0, other=-1)' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.govLastDecisionStatus); }
        g.govLastApprovalRate.set(decision.approvalRate||0);
        const code = decision.status==='approved'?1: decision.status==='rejected'?0:-1;
        g.govLastDecisionStatus.set(code);
      }
    } catch(_){ }
  } catch(e){ if(process.env.GOVERNANCE_LOG==='1') console.warn('[GOV] error', e.message); }
}

module.exports = { governanceCycle, evaluateProposal, PARAM_BOUNDS };
