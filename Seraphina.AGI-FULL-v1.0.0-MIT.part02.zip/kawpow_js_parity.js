// kawpow_js_parity.js
// JS parity mirror of current simplified native KawPow light hash implementation.
// NOTE: Mirrors the scaffold logic (NOT full canonical KawPow). Update alongside native changes.

const crypto = require('crypto');
let sha3js; try { sha3js = require('js-sha3'); } catch(_) {}
function keccak256_js(buf){ return sha3js ? Buffer.from(sha3js.keccak256.arrayBuffer(buf)) : crypto.createHash('sha3-256').update(buf).digest(); }
function keccak512_js(buf){ return sha3js ? Buffer.from(sha3js.keccak512.arrayBuffer(buf)) : crypto.createHash('sha3-512').update(buf).digest(); }
function expandSeedWords_js(headerHash){
  const out = Buffer.alloc(84*4); let produced=0, counter=0;
  while(produced < out.length){
    const inBuf = Buffer.concat([headerHash, Buffer.from(Uint32Array.of(counter).buffer)]);
    const h=keccak512_js(inBuf);
    const take = Math.min(64, out.length - produced);
    h.copy(out, produced, 0, take); produced += take; counter++;
  }
  return out;
}
function generateAluTable_js(epoch){
  const size=32; const t=new Uint8Array(size);
  let x = BigInt(epoch) * 0x85ebca6bn ^ 0x243f6a8885ebca6bn; // deterministic seed
  function next(){ x ^= x >> 12n; x ^= x << 25n; x ^= x >> 27n; return x * 0x2545F4914F6CDD1Dn; }
  for (let i=0;i<size;i++){ const v = next(); const m = (v ^ (v >> 17n) ^ (v << 23n) ^ 0x9e3779b97f4a7c15n) & 0xffffffffffffffffn; t[i]= Number(m % 4n); }
  return t;
}
function rotl32(v,r){ r&=31; return ((v<<r)|(v>>> (32-r)))>>>0; }
function kawpowLightJs(headerHex, height){
  const headerBufRaw = Buffer.from(headerHex,'hex');
  const header80 = headerBufRaw.length >=80 ? headerBufRaw.slice(0,80) : Buffer.concat([headerBufRaw, Buffer.alloc(80-headerBufRaw.length)]);
  const headerHash = keccak256_js(header80);
  const seedWordsBuf = expandSeedWords_js(headerHash);
  const seedWords = new Uint32Array(seedWordsBuf.buffer, seedWordsBuf.byteOffset, 84);
  const epoch = Math.floor(height / 7500);
  const alu = generateAluTable_js(epoch);
  const LANES=64, ROUNDS=64, LINE_BYTES=64;
  const lightItems = Math.max(1<<16, (16*1024*1024)/LINE_BYTES);
  const light = new Array(lightItems);
  const epochBytes = Buffer.alloc(8); epochBytes.writeUInt32LE(epoch,0);
  const base = keccak256_js(epochBytes);
  for(let i=0;i<lightItems;i++){
    const inBuf = Buffer.concat([base, Buffer.from([i & 0xFF])]);
    light[i] = keccak512_js(inBuf).subarray(0, LINE_BYTES);
  }
  const mix = new Uint32Array(LANES);
  for (let L=0; L<LANES; L++){ mix[L] = (seedWords[L % 84] ^ ((L * 0x9e3779b9)>>>0))>>>0; }
  for (let R=0; R<ROUNDS; R++){
    const seed_word = seedWords[R % 84];
    for (let L=0; L<LANES; L++){
      const pc = (R*LANES + L) % alu.length; const op = alu[pc];
      const idxExpr = BigInt(mix[L]) + BigInt(R) * BigInt(L) + BigInt(seed_word);
      const index = Number(idxExpr % BigInt(lightItems));
      const line = light[index];
      const offset = R % (LINE_BYTES - 3);
      const data_val = line.readUInt32LE(offset);
      let m = mix[L];
      switch(op){ case 0: m = (m + data_val)>>>0; break; case 1: m = Math.imul(m, (data_val|1)>>>0)>>>0; break; case 2: m = (m ^ data_val)>>>0; break; case 3: m = rotl32(m, data_val & 31); break; }
      const header_word = headerHash.readUInt32LE((R % 8)*4);
      if (((header_word + R) % 128) < 64){
        const extra_index = (m + 1) % lightItems;
        const line2 = light[extra_index];
        const offset2 = (R*7) % (LINE_BYTES - 3);
        const data2_val = line2.readUInt32LE(offset2);
        switch(op){ case 0: m = (m + data2_val)>>>0; break; case 1: m = Math.imul(m, (data2_val|1)>>>0)>>>0; break; case 2: m = (m ^ data2_val)>>>0; break; case 3: m = rotl32(m, data2_val & 31); break; }
      }
      mix[L]=m>>>0;
    }
  }
  const mixConcat = Buffer.alloc(LANES*4); for(let i=0;i<LANES;i++) mixConcat.writeUInt32LE(mix[i], i*4);
  const mixHashFull = keccak512_js(mixConcat);
  const mixHash = mixHashFull.subarray(0,32);
  const finalIn = Buffer.concat([mixHash, Buffer.alloc(8,0)]);
  const finalFull = keccak512_js(finalIn);
  return { mixHash: mixHash.toString('hex'), finalHash: finalFull.subarray(0,32).toString('hex') };
}
module.exports = { kawpowLightJs };
