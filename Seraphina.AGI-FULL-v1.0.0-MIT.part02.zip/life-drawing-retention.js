// life-drawing-retention.js
// Compute retention (decay-weighted practice) per field over sessions.
// Environment Variables:
//   LIFE_DRAWING_RETENTION_HALF_LIFE   -> integer/float; sessions for a field at constant presence to halve its influence (default 20)
//   LIFE_DRAWING_RETENTION_DECAY_FACTOR -> 0..1; adaptive extra decay applied proportionally to practiceRatio (default 0.3)
//     EffectiveRetention = BaseDecayWeight * (1 - practiceRatio * adaptiveFactor)
// CLI Flags:
//   --hist  -> prints ASCII histogram instead of JSON.
// Interpretation:
//   Lower retention value => field has decayed more (less recently reinforced or heavily penalized by over-practice) and is a candidate for re-focus.
// Normalization:
//   Retention scores divided by theoretical max if field appeared in every session (sum of decay weights).
'use strict';
const fs = require('fs');
const path = require('path');

function readLedger(){
  const ledgerPath = path.join(__dirname,'life-drawing-session-ledger.jsonl');
  if(!fs.existsSync(ledgerPath)) return [];
  return fs.readFileSync(ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try { return JSON.parse(l); } catch(_){ return null; } }).filter(Boolean);
}

function computeRetention(opts={}){
  const entries = readLedger();
  if(!entries.length) return { ok:false, message:'No sessions' };
  entries.sort((a,b)=> a.ts - b.ts);
  const halfLife = parseFloat(process.env.LIFE_DRAWING_RETENTION_HALF_LIFE || opts.halfLife || '20'); // sessions to halve weight
  const decayBase = Math.pow(0.5, 1/halfLife);
  const adaptiveFactor = parseFloat(process.env.LIFE_DRAWING_RETENTION_DECAY_FACTOR || opts.decayFactor || '0.3');
  const fieldScores = {};
  const fieldCountsTotal = {};
  entries.forEach((e,i)=>{
    const weight = Math.pow(decayBase, entries.length - 1 - i); // newer sessions weighted higher
    (e.fieldCoverageSnapshot||[]).forEach(f=>{
      fieldCountsTotal[f] = (fieldCountsTotal[f]||0) + 1;
      fieldScores[f] = (fieldScores[f]||0) + weight;
    });
  });
  // Apply adaptive decay: heavy practiced fields get reduced effective score
  const maxCount = Object.values(fieldCountsTotal).reduce((m,v)=> v>m? v: m, 1);
  Object.keys(fieldScores).forEach(f=>{
    const practiceRatio = (fieldCountsTotal[f]||0)/maxCount; // 0..1
    const penalty = practiceRatio * adaptiveFactor; // up to adaptiveFactor
    fieldScores[f] = fieldScores[f] * (1 - penalty);
  });
  // Normalize to 0..1 by dividing by max possible (sum of weights if field appeared every session)
  const totalMax = entries.reduce((acc,_,i)=> acc + Math.pow(decayBase, entries.length - 1 - i),0);
  const fields = Object.keys(fieldScores).map(f=> ({ field:f, retention: fieldScores[f]/totalMax }));
  fields.sort((a,b)=> a.retention - b.retention); // ascending -> weakest retention first
  return { ok:true, halfLife, decayBase: Number(decayBase.toFixed(6)), adaptiveFactor, fields };
}

if(require.main === module){
  const hist = process.argv.includes('--hist');
  const report = computeRetention();
  if(hist && report.ok){
    // ASCII histogram (bars scaled to 40 chars)
    const max = Math.max(...report.fields.map(f=> f.retention),1);
    report.fields.forEach(f=>{
      const barLen = Math.round((f.retention/max) * 40);
      console.log((f.field.padEnd(16))+'|'+ '#'.repeat(barLen) + ' '+(f.retention.toFixed(4))); 
    });
  } else {
    console.log(JSON.stringify(report,null,2));
  }
}

module.exports = { computeRetention };
