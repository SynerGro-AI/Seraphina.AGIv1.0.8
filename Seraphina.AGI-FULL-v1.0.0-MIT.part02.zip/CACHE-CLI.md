# Seraphina Simulation Cache CLI

`seraphina-cache-cli.js` (installed via `seraphina-cache` bin) lets you inspect and control the in-memory simulation cache used by `seraphina-api.js`.

## Commands

- `stats` – Show current cache entry count, capacity (max), persistence state, and path (if enabled).
- `enable-persist` – Turn on disk persistence. Optionally set env `SERAPHINA_SIM_CACHE_PATH` before invocation to choose file.
- `disable-persist` – Turn off persistence (no further writes; existing file untouched).
- `clear` – Remove all cache entries (also triggers a save if persistence enabled and cache not empty afterwards — otherwise no file changed).
- `prune` – Remove persisted entries older than `--maxAgeMs` (defaults 3600000 ms). Operates directly on persistence file; does not touch in-memory entries until next reload.

## Flags

- `--pretty=false` – Emit compact single-line JSON instead of human-readable pretty format.
- `--maxAgeMs=<ms>` – Age threshold applied by `prune` command.

## Environment Variables

- `SERAPHINA_SIM_CACHE_MAX` – Maximum in-memory entries (default 32).
- `SERAPHINA_SIM_CACHE_PERSIST` – If set to `1` at process start, persistence auto-enabled.
- `SERAPHINA_SIM_CACHE_PATH` – Path to persistence file (default `seraphina-sim-cache.json` in API directory).
- `SERAPHINA_SIM_CACHE_MAX_AGE_MS` – If >0, entries older than this many milliseconds auto-evicted on new insertions.
- `SERAPHINA_CACHE_TOKEN` – If set, /cache endpoint requires `Authorization: Bearer <token>`.

## Persistence Behavior

- Only metrics objects (not full records) are persisted to minimize size and avoid large arrays.
- File write occurs only when cache has at least one entry.
- Reload repopulates cache with empty `records` arrays (metrics still available for introspection and exporter).
- Prune command edits persistence file directly (in-memory entries unaffected until reload). Programmatic prune removes in-memory entries immediately.
- Compression activates automatically when payload size >= `SERAPHINA_SIM_CACHE_COMPRESS_THRESHOLD` (default 65536 bytes); CLI output does not indicate compression, but gauge `seraphina_sim_cache_compressed` does.
- Warm cache (programmatic only) enables prepopulation for high-frequency simulation patterns.

## Programmatic Toggle

Available via `api.meta.toggleCachePersistence(enable, pathOverride)` returning `{ ok, persistence, path }`.

## Examples (PowerShell)

```powershell
node seraphina-cache-cli.js stats
node seraphina-cache-cli.js enable-persist
node seraphina-cache-cli.js stats --pretty=false
node seraphina-cache-cli.js clear
```

## Prometheus Integration

Exporter exposes:
- `seraphina_sim_cache_entries`
- `seraphina_sim_cache_capacity`
- `seraphina_sim_cache_persistence_enabled`

Use these to alert on near-capacity or unexpected disabling.

---
Last updated: 2025-11-10
