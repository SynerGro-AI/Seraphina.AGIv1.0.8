#!/usr/bin/env node
// analyze-rings.js
// Offline analyzer for rule-stats-ring.jsonl and share-corr-ring.jsonl
// Provides simple regression fitting (OLS) between norm / proxy / signVar and share outcome.
// Deterministic, no network. Usage: node analyze-rings.js [--dir=path]

const fs = require('fs');
const path = require('path');

function loadLines(file, limit){
  try { const data = fs.readFileSync(file,'utf8').trim().split(/\n/); return data.slice(-limit); } catch(_){ return []; }
}

function parseJSONL(lines){ const out=[]; for(const l of lines){ try { out.push(JSON.parse(l)); } catch(_){ } } return out; }

function ols(X, y){
  // X: array of arrays (features), y: array
  // Solve (X'X)^{-1} X'y (small system; use naive Gauss-Jordan)
  const n = X.length; if (!n) return { coef:[], r2:0 };
  const m = X[0].length;
  // Build XtX and Xty
  const XtX = Array.from({length:m},()=>Array(m).fill(0));
  const Xty = Array(m).fill(0);
  let yMean=0; for(let i=0;i<n;i++) yMean += y[i]; yMean/=n;
  let ssTot=0, ssRes=0;
  for (let i=0;i<n;i++){
    const xi=X[i]; const yi=y[i];
    for (let a=0;a<m;a++){ Xty[a]+=xi[a]*yi; for (let b=a;b<m;b++){ XtX[a][b]+=xi[a]*xi[b]; if (b!==a) XtX[b][a]=XtX[a][b]; } }
  }
  // Augment XtX|Xty
  for (let i=0;i<m;i++) XtX[i].push(Xty[i]);
  // Gauss-Jordan
  for (let i=0;i<m;i++){
    // pivot
    let piv=i; for(let r=i+1;r<m;r++) if(Math.abs(XtX[r][i])>Math.abs(XtX[piv][i])) piv=r;
    if (piv!==i){ const tmp=XtX[i]; XtX[i]=XtX[piv]; XtX[piv]=tmp; }
    const div = XtX[i][i] || 1e-12;
    for (let c=i;c<=m;c++) XtX[i][c]/=div;
    for (let r=0;r<m;r++) if(r!==i){ const f=XtX[r][i]; for (let c=i;c<=m;c++) XtX[r][c]-=f*XtX[i][c]; }
  }
  const coef = XtX.map(r=>r[m]);
  // Compute R^2
  for (let i=0;i<n;i++){
    let pred=0; for(let j=0;j<m;j++) pred+= X[i][j]*coef[j];
    ssTot += (y[i]-yMean)**2;
    ssRes += (y[i]-pred)**2;
  }
  const r2 = ssTot>0 ? 1 - ssRes/ssTot : 0;
  return { coef, r2 };
}

function run(){
  const dirArg = process.argv.find(a=>a.startsWith('--dir='));
  const dir = dirArg ? dirArg.split('=')[1] : process.cwd();
  const ruleFile = path.join(dir,'rule-stats-ring.jsonl');
  const shareFile = path.join(dir,'share-corr-ring.jsonl');
  const rule = parseJSONL(loadLines(ruleFile, 5000));
  const corr = parseJSONL(loadLines(shareFile, 5000));
  console.log(`[ANALYZE] Loaded rule=${rule.length} shareCorr=${corr.length}`);
  if (!corr.length){ console.log('No share correlation data.'); return; }
  // Features: norm, proxy, signVar, norm*proxy, proxy^2
  const X=[]; const y=[];
  for (const r of corr){
    if (typeof r.norm==='number' && typeof r.proxy==='number' && typeof r.signVar==='number' && typeof r.share==='number'){
      X.push([ r.norm, r.proxy, r.signVar, r.norm*r.proxy, r.proxy*r.proxy ]);
      y.push(r.share);
    }
  }
  if (!X.length){ console.log('Insufficient feature data.'); return; }
  const { coef, r2 } = ols(X,y);
  console.log('[REG] coef (norm,proxy,signVar,norm*proxy,proxy^2)=', coef.map(c=>+c.toFixed(4)).join(','),' R2=',r2.toFixed(4));
  // Basic guidance suggestion (deterministic): if proxy term strongly positive + norm negative -> consider loosening high-rank buckets
  const proxyCoef = coef[1]; const normCoef = coef[0];
  if (proxyCoef > 0.05 && normCoef < -0.05){
    console.log('[GUIDE] Suggest: allow additional bucket extension if sustained P95 overflow OR reduce skip threshold slightly.');
  }
}

if (require.main === module){ run(); }

module.exports = { run };
