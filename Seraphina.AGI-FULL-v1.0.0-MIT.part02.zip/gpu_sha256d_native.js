// gpu_sha256d_native.js
// Loader for native CUDA batch hashing addon (optional). Falls back silently if build not present.

let native = null;
try {
  native = require('node-gyp-build')(__dirname);
} catch(e){
  try { native = require('./build/Release/gpu_sha256d.node'); } catch(_) {}
}

module.exports = {
  available: !!(native && native.hashBatch && !native.isStub),
  hashBatch(headers){
    if (!native || !native.hashBatch || native.isStub) throw new Error('GPU native addon not available');
    return native.hashBatch(headers); // returns array of Buffers(32)
  }
};
