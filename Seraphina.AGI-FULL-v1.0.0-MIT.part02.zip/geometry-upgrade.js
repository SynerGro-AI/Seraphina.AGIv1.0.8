#!/usr/bin/env node
// geometry-upgrade.js - Geometric rotation / projection capacity estimator for Aurrelia miner
// Usage:
//   node geometry-upgrade.js --d=8 --room=1.0 --spacing=0.1 --seed=jobB6ya6ZuzW
// Environment / CLI Flags (CLI has precedence):
//   --d             : conceptual dimensionality to simulate (default 8)
//   --room          : normalized lattice radius/room (default 1.0)
//   --spacing       : target spacing between projected points (default 0.1)
//   --seed          : arbitrary string to anchor deterministic hashing
// Output explains raw combinatorial node surface vs rotated+projected packing.

const args = process.argv.slice(2).reduce((acc, a) => {
  if (!a.startsWith('--')) return acc; const [k,v] = a.replace(/^--/,'').split('='); acc[k] = v === undefined ? true : v; return acc;
}, {});

function cfg(k, d){ return args[k] != null ? args[k] : d; }
const d = parseInt(cfg('d', 8), 10);
const room = parseFloat(cfg('room', 1.0));
const spacing = parseFloat(cfg('spacing', 0.1));
const seed = cfg('seed', 'jobB6ya6ZuzW');

if (d < 2 || d > 64){
  console.error('[geom] d must be between 2 and 64');
  process.exit(1);
}

const layers = Math.max(1, Math.floor(room / spacing));
// Simplistic raw surface approximation: layers^(d-1)
const rawNodes = Math.pow(layers, d - 1);
// Rotational packing heuristic: 2D projected grid (layers^2) * 8-fold symmetry * scale factor 2^(d-4) beyond baseline 4D
const fittedNodes = Math.min(rawNodes, Math.pow(layers, 2) * 8 * Math.pow(2, Math.max(0, d - 4)));
const spillover = Math.max(0, fittedNodes - Math.pow(layers, 2));

function fmt(n){ if (n < 1e6) return n.toString(); return n.toExponential(2); }

console.log(`Etching ${d}D crystal in room=${room} spacing=${spacing} seed=${seed}`);
console.log(`Layers: ${layers}`);
console.log(`Raw nodes (surface est): ${fmt(rawNodes)}`);
console.log(`Fitted (rot+proj heuristic): ${fmt(fittedNodes)}`);
console.log(`Spillover (folded): ${fmt(spillover)}`);
if (spillover > 0) console.log('Note: spillover suggests higher-dimensional folding (conceptual Klein mapping).');

console.log('\nSuggested miner env to enable geometry optimization:');
console.log('  set GEOM_ROTATE=1');
console.log('  set GEOM_ROT_COUNT=4   # or 8 for denser rotation sampling');
console.log('  set OCTO_PROJECT_2D=1  # project to 2D for lighter processing');
console.log('  set BURROW_NORMALIZE=1 # maintain inward growth stability');

console.log('\nThis tool is heuristic & illustrative; actual miner dynamics remain governed by octonion ops + clamp.');
