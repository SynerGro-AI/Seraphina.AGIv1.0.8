#!/usr/bin/env bash
set -euo pipefail

# Multi-arch build (amd64, arm64) producing tarballs & debs inside per-arch folders.
# Requires Docker Buildx and QEMU emulation (docker run --privileged multiarch/qemu-user-static --reset -p yes).

IMAGE_BASE="seraphina-miner-build"
ARCHES=(amd64 arm64)
OUT_ROOT="multiarch-dist"
GPG_FLAG=${GPG_SIGN:-0}

echo "[multiarch] Preparing output root";
rm -rf "$OUT_ROOT" && mkdir -p "$OUT_ROOT"

for ARCH in "${ARCHES[@]}"; do
  echo "[multiarch] Building for $ARCH";
  docker buildx build --platform linux/${ARCH} -f Dockerfile.linux-build -t ${IMAGE_BASE}:${ARCH} --build-arg TARGETARCH=${ARCH} --load .
  CID=$(docker create ${IMAGE_BASE}:${ARCH})
  mkdir -p "$OUT_ROOT/$ARCH"
  docker cp "$CID":/dist/linux-dist/. "$OUT_ROOT/$ARCH/"
  docker rm "$CID" >/dev/null
  if [[ "$GPG_FLAG" == "1" && -d "$OUT_ROOT/$ARCH" ]]; then
    for f in "$OUT_ROOT/$ARCH"/*.tar.gz "$OUT_ROOT/$ARCH"/*.deb; do
      [[ -f "$f" ]] || continue
      echo "[multiarch] Signing $f"
      gpg --batch --yes --armor --detach-sign -o "$f.asc" "$f" || echo "[multiarch] WARN failed signing $f"
    done
  fi
done

echo "[multiarch] Build complete. Artifacts in $OUT_ROOT/<arch>/"