<#
 build-production-iso.ps1

 Creates a production ISO containing deterministic Aurrelia miner + Seraphina deterministic language engine harness.
 Requires: Windows (PowerShell), optional Windows ADK (oscdimg.exe) OR mkisofs in PATH.

 Parameters:
   -StageDir <path>    Working staging directory (will be created)
   -IsoName <name>     Output ISO filename (default Aurrelia-Deterministic.iso)
   -IncludeLogs        Switch to create empty logs/ directory
   -SkipHashManifest   Skip generation of hash manifest (not recommended)

 Contents staged:
   /app/*.js key runtime scripts (aurrelia-pico-mesh-miner.js, system-repro-*.js, deterministic AI core)
   /config/env-sample.txt sample environment variable file
   /docs/*.md reproducibility + production docs
   manifest-hashes.json (unless -SkipHashManifest)

 Usage example:
   powershell -ExecutionPolicy Bypass -File .\build-production-iso.ps1 -StageDir .\iso_stage -IsoName Aurrelia-Deterministic.iso

#>
param(
  [string]$StageDir = "./iso_stage",
  [string]$IsoName = "Aurrelia-Deterministic.iso",
  [switch]$IncludeLogs,
  [switch]$SkipHashManifest,
  [string]$SummarySourceScript = "system-repro-test.js",
  [switch]$SignManifest,
  [string]$GpgKeyId,
  [SecureString]$GpgPassphrase
)

function New-Dir($p){ if(!(Test-Path $p)){ New-Item -ItemType Directory -Path $p | Out-Null } }

Write-Host "[ISO] Staging directory: $StageDir"
New-Dir $StageDir
New-Dir "$StageDir/app"
New-Dir "$StageDir/config"
New-Dir "$StageDir/docs"
if($IncludeLogs){ New-Dir "$StageDir/logs" }

# Copy core JS files
$coreFiles = @(
  'aurrelia-pico-mesh-miner.js',
  'coin-config.js',
  'system-repro-test.js',
  'system-repro-verify.js',
  'final-mining-test.js',
  'deterministic-ai-core.js',
  'language-engine.js',
  'seraphina-wallet-companion.js',
  'companion-policy-engine.js',
  'aurrelia-trading-engine.js'
) | ForEach-Object { Join-Path $PSScriptRoot $_ }

foreach($f in $coreFiles){
  if(Test-Path $f){ Copy-Item $f "$StageDir/app/" }
  else { Write-Warning "Missing file $f" }
}

# SBOM generation (optional): if sbom-generate.js exists in root and not already produced, run it then copy sbom.json
if(Test-Path (Join-Path $PSScriptRoot 'sbom-generate.js')){
  $sbomPath = Join-Path $PSScriptRoot 'sbom.json'
  if(-not (Test-Path $sbomPath)){
    Write-Host '[ISO] Generating SBOM via sbom-generate.js'
    $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
    if($nodeCmd){
      & $nodeCmd.Source (Join-Path $PSScriptRoot 'sbom-generate.js') | Out-Null
    } else { Write-Warning '[ISO] Node not found; skipping SBOM generation' }
  } else { Write-Host '[ISO] Existing sbom.json detected; reusing' }
  if(Test-Path $sbomPath){ Copy-Item $sbomPath "$StageDir/app/"; Write-Host '[ISO] SBOM included in /app/sbom.json' }
}

# Copy documentation
$docFiles = @(
  'SYSTEM-REPRODUCIBILITY.md',
  'PRODUCTION-ISO.md'
  ,'TRADING-ENGINE.md'
  ,'ADAPTIVE-ROADMAP.md'
  ,'GOVERNANCE-ENGINE.md'
  ,'ML-ADVISOR.md'
) | ForEach-Object { Join-Path $PSScriptRoot $_ }
foreach($d in $docFiles){ if(Test-Path $d){ Copy-Item $d "$StageDir/docs/" } }

# Sample env template
$envSample = @'
# Deterministic Seraphina + Aurrelia Miner Environment (Sample)
SERAPHINA_STRICT_DETERMINISM=1
SERAPHINA_SEED=prod-seed-CHANGE-ME
AUR_REPRO_CYCLE_LIMIT=8
AUR_REPRO_FAST=0
AUR_COIN=BTC
GLOBAL_OCTO_SEED=change-me
# Wallets
WALLET_BTC=1ChangeMeBTCAddr
WALLET_RVN=RChangeMeRVNAddr
WALLET_FREN=FChangeMeFRENAddr
# Optional pool overrides
# RVN_POOL= stratum+tcp://raven.f2pool.com:3636
# FREN_POOL= stratum+tcp://fren.aikapool.com:3333
'@
$envSample | Out-File -FilePath "$StageDir/config/env-sample.txt" -Encoding utf8

# Reproducibility summary: run source script if present
$summaryObj = $null
if(Test-Path (Join-Path $PSScriptRoot $SummarySourceScript)){
  Write-Host "[ISO] Gathering reproducibility summary via $SummarySourceScript"
  $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
  $nodeExe = if($nodeCmd){ $nodeCmd.Source } else { $null }
  if($nodeExe){
    $summaryRaw = & $nodeExe (Join-Path $PSScriptRoot $SummarySourceScript) 2>$null
    try { $summaryObj = $summaryRaw | ConvertFrom-Json } catch { Write-Warning "[ISO] Failed to parse reproducibility summary JSON" }
  } else { Write-Warning "[ISO] Node not found; skipping reproducibility summary" }
}
if($summaryObj){ $summaryObj | ConvertTo-Json -Depth 4 | Out-File -FilePath "$StageDir/reproducibility-summary.json" -Encoding utf8 }

# Hash manifest (includes summary if generated)
$manifest = @()
if(-not $SkipHashManifest){
  $filesToHash = Get-ChildItem -Recurse $StageDir | Where-Object { -not $_.PSIsContainer }
  foreach($file in $filesToHash){
    $bytes = [IO.File]::ReadAllBytes($file.FullName)
    $sha256 = (Get-FileHash -InputStream ([IO.MemoryStream]::new($bytes)) -Algorithm SHA256).Hash.ToLower()
    $manifest += [pscustomobject]@{ path = $file.FullName.Substring((Resolve-Path $StageDir).Path.Length + 1); sha256 = $sha256 }
  }
  $manifest | ConvertTo-Json -Depth 3 | Out-File -FilePath "$StageDir/manifest-hashes.json" -Encoding utf8
  if($SignManifest){
    if(-not (Get-Command gpg -ErrorAction SilentlyContinue)){ Write-Warning "[ISO] gpg not found; skipping signing" }
    else {
      $sigArgs = @('--detach-sign','--armor','manifest-hashes.json')
      if($GpgKeyId){ $sigArgs = @('--local-user',$GpgKeyId) + $sigArgs }
      if($GpgPassphrase){
        Write-Host "[ISO] Signing manifest with provided SecureString passphrase"
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($GpgPassphrase))
        $sigArgs = @('--batch','--yes','--passphrase-fd','0') + $sigArgs
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'gpg'
        $psi.WorkingDirectory = $StageDir
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.UseShellExecute = $false
        $psi.ArgumentList.Clear()
        foreach($a in $sigArgs){ $psi.ArgumentList.Add($a) }
        $p = [System.Diagnostics.Process]::Start($psi)
        $p.StandardInput.WriteLine($plain)
        $p.StandardInput.Close()
        $p.WaitForExit()
        if($p.ExitCode -ne 0){ Write-Warning "[ISO] gpg signing exit code $($p.ExitCode): $($p.StandardError.ReadToEnd())" }
      } else {
        Write-Host "[ISO] Signing manifest (no passphrase provided; gpg may prompt)"
        Push-Location $StageDir; & gpg @sigArgs; $exit=$LASTEXITCODE; Pop-Location
        if($exit -ne 0){ Write-Warning "[ISO] gpg signing exit code $exit" }
      }
      if(Test-Path "$StageDir/manifest-hashes.json.asc"){ Write-Host "[ISO] Manifest signed -> manifest-hashes.json.asc" } else { Write-Warning "[ISO] Manifest signing may have failed" }
    }
  }
}

# Attempt ISO creation
$isoTool = $null
if(Get-Command oscdimg.exe -ErrorAction SilentlyContinue){ $isoTool = 'oscdimg' }
elseif(Get-Command mkisofs.exe -ErrorAction SilentlyContinue){ $isoTool = 'mkisofs' }

if($isoTool -eq 'oscdimg'){
  Write-Host "[ISO] Using oscdimg.exe"
  $label = 'AURRELIA'
  $cmd = "oscdimg -l$label -m -o $StageDir $IsoName"
  Write-Host "[ISO] Running: $cmd"
  Invoke-Expression $cmd
} elseif ($isoTool -eq 'mkisofs') {
  Write-Host "[ISO] Using mkisofs.exe"
  $cmd = "mkisofs -V AURRELIA -o $IsoName $StageDir"
  Write-Host "[ISO] Running: $cmd"
  Invoke-Expression $cmd
} else {
  Write-Warning "No ISO tool found (oscdimg or mkisofs). ISO not created. Install Windows ADK or cdrtools."   
}

Write-Host "[ISO] Complete. Staged files:"; Get-ChildItem -Recurse $StageDir | Select-Object FullName
