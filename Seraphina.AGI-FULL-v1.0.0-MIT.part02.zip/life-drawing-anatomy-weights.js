// life-drawing-anatomy-weights.js
// Loads anatomy field weights from life-drawing-config.json or env override.
'use strict';
const fs = require('fs');
const path = require('path');

const DEFAULT_WEIGHTS = {
  gestureDirection: 1.0,
  centerOfGravity: 1.0,
  dominantMass: 0.8,
  balanceAssessment: 0.6,
  proportionCheck: 0.7,
  negativeSpace: 0.5
};

function loadAnatomyWeights(){
  let weights = { ...DEFAULT_WEIGHTS };
  try {
    const cfgPath = path.join(__dirname,'life-drawing-config.json');
    if(fs.existsSync(cfgPath)){
      const raw = fs.readFileSync(cfgPath,'utf8');
      const cfg = JSON.parse(raw);
      if(cfg.anatomyWeights && typeof cfg.anatomyWeights === 'object'){
        Object.keys(cfg.anatomyWeights).forEach(k=>{
          const v = cfg.anatomyWeights[k];
          if(typeof v === 'number' && isFinite(v) && v >= 0){ weights[k] = v; }
        });
      }
    }
  } catch(_){ }
  if(process.env.LIFE_DRAWING_WEIGHTS){
    try {
      const envObj = JSON.parse(process.env.LIFE_DRAWING_WEIGHTS);
      if(envObj && typeof envObj === 'object'){
        Object.keys(envObj).forEach(k=>{ const v = envObj[k]; if(typeof v==='number' && isFinite(v) && v>=0){ weights[k]=v; } });
      }
    } catch(_){ }
  }
  return weights;
}

module.exports = { loadAnatomyWeights, DEFAULT_WEIGHTS };
