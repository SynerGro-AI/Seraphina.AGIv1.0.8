#!/usr/bin/env node
// Nightly integrity audit: recompute chain hashes of all ledgers, build Merkle root, optional HMAC seal.
// Usage: node integrity-audit.js > audit-YYYYMMDD.json

const fs = require('fs');
const crypto = require('crypto');

const LEDGERS = [
  'share-ledger.jsonl',
  'swap-ledger.jsonl',
  'parity-ledger.jsonl',
  'econ-realization-ledger.jsonl',
  'price-ledger.jsonl',
  'governance-ledger.jsonl'
];

function hashLineChain(file, projector){
  if(!fs.existsSync(file)) return { file, entries:0, tip:null, ok:true };
  const lines = fs.readFileSync(file,'utf8').trim().split(/\n+/).filter(Boolean);
  let prev='GENESIS'; let ok=true; let idx=0; let last=null;
  for(const ln of lines){
    idx++; let o; try { o=JSON.parse(ln); } catch(_){ ok=false; break; }
    const proj = projector? projector(o): o.__project || o; // fallback
    const raw = JSON.stringify(proj);
    const ch = crypto.createHash('sha256').update(prev+raw).digest('hex');
    if(o.chain_hash && ch !== o.chain_hash){ ok=false; break; }
    prev = ch; last = ch;
  }
  return { file, entries: idx, tip:last, ok };
}

function merkleRoot(hashes){
  if(!hashes.length) return null;
  let level = hashes.slice();
  while(level.length>1){
    const next=[];
    for(let i=0;i<level.length;i+=2){
      if(i+1===level.length) next.push(level[i]);
      else next.push(crypto.createHash('sha256').update(level[i]+level[i+1]).digest('hex'));
    }
    level = next;
  }
  return level[0];
}

const results = LEDGERS.map(f=> hashLineChain(f, (o)=>{ // projector strips volatile fields
  if(f==='share-ledger.jsonl') return { ts:o.ts, coin:o.coin, difficulty:o.difficulty, poolDifficulty:o.poolDifficulty, shareTarget:o.shareTarget, creditEst:o.creditEst, source:o.source, acceptLatencyMs:o.acceptLatencyMs };
  if(f==='swap-ledger.jsonl') return { ts:o.ts, event:o.event, id:o.id, from:o.from, to:o.to, amount:o.amount, rate:o.rate, live:o.live, status:o.status, orderId:o.orderId, depositAddress:o.depositAddress, txid:o.txid, confirmations:o.confirmations, error:o.error };
  if(f==='parity-ledger.jsonl') return { ts:o.ts, coin:o.coin, poolDifficulty:o.poolDifficulty, difficulty:o.difficulty, canonicalDifficulty:o.canonicalDifficulty, creditEst:o.creditEst, source:o.source };
  if(f==='econ-realization-ledger.jsonl') return { ts:o.ts, type:o.type, swapId:o.swapId, from:o.from, to:o.to, amountFrom:o.amountFrom, rateUsed:o.rateUsed, realizedUSD:o.realizedUSD, preCreditUSD:o.preCreditUSD, pnlDeltaUSD:o.pnlDeltaUSD, status:o.status };
  if(f==='price-ledger.jsonl') return { ts:o.ts, btc:o.btc, rvn:o.rvn, kas:o.kas, fren:o.fren, krakenLiveBTC:o.krakenLiveBTC };
  if(f==='governance-ledger.jsonl') return { ts:o.ts, type:o.type, proposal:o.proposal, hash:o.hash, approvals:o.approvals, activatedTs:o.activatedTs };
  return o; }));

const activeHashes = results.filter(r=> r.tip).map(r=> r.tip);
const root = merkleRoot(activeHashes);
let seal=null; const key=process.env.AUDIT_HMAC_KEY; if(key && root){ seal = crypto.createHmac('sha256', key).update(root).digest('hex'); }

const audit = { ts: Date.now(), results, merkleRoot: root, globalMerkleRoot: root, seal };
console.log(JSON.stringify(audit, null, 2));
