/**
 * Hash Engine Manager
 * -------------------------------------------------
 * Lightweight supervisor for external hashing processes (BTC focus).
 * Spawns an external miner binary specified via environment or per-pool config
 * and parses stdout lines to detect accepted/rejected shares and optional hashrate lines.
 *
 * Environment Variables:
 *  BTC_EXTERNAL_MINER_CMD   -> full command or executable path (e.g. "C:\\miners\\cpuminer.exe")
 *  BTC_EXTERNAL_MINER_ARGS  -> argument template; tokens: {POOL_HOST} {POOL_PORT} {WORKER} {PASS}
 *  BTC_EXTERNAL_MINER_PASS  -> worker password (default 'x')
 *  HASH_ENGINE_DEBUG=1      -> verbose logging
 *
 * Emits events:
 *  'shareAccepted' ({ poolName })
 *  'shareRejected' ({ poolName, reason })
 *  'hashrate' ({ poolName, value, unit, raw })
 *  'exit' ({ poolName, code, signal })
 */
const { EventEmitter } = require('events');
const { spawn } = require('child_process');

class HashEngineManager extends EventEmitter {
  constructor(opts={}) {
    super();
    this.debug = !!process.env.HASH_ENGINE_DEBUG;
    this.processes = new Map(); // poolName -> child
    this.opts = opts;
    this.restartDelays = {}; // poolName -> ms backoff
    this.maxBackoff = 300000; // 5m
  }
  log(...a){ if(this.debug) console.log('[HASH_ENGINE]', ...a); }
  startForPool(pool, worker){
    if (pool.coin !== 'BTC') return; // scope to BTC for now
    if (this.processes.has(pool.name)) return;
    const cmd = process.env.BTC_EXTERNAL_MINER_CMD;
    if (!cmd) return; // nothing to do
    const pass = process.env.BTC_EXTERNAL_MINER_PASS || 'x';
    const argsTemplate = process.env.BTC_EXTERNAL_MINER_ARGS || '-o stratum+tcp://{POOL_HOST}:{POOL_PORT} -u {WORKER} -p {PASS}';
    const hostPort = pool.host.replace('stratum+tcp://','');
    const [POOL_HOST, POOL_PORT] = hostPort.split(':');
    const argLine = argsTemplate
      .replace('{POOL_HOST}', POOL_HOST)
      .replace('{POOL_PORT}', POOL_PORT)
      .replace('{WORKER}', worker)
      .replace('{PASS}', pass);
    const args = argLine.split(/\s+/).filter(Boolean);
    this.log('Spawning external miner', cmd, args.join(' '), 'pool='+pool.name);
    const child = spawn(cmd, args, { stdio:['ignore','pipe','pipe'] });
    this.processes.set(pool.name, child);
    child.stdout.on('data', d=> this._onLine(pool, d.toString(), false));
    child.stderr.on('data', d=> this._onLine(pool, d.toString(), true));
    child.on('exit', (code, signal)=>{
      this.log('Miner exit', pool.name, code, signal);
      this.processes.delete(pool.name);
      this.emit('exit', { poolName: pool.name, code, signal });
      this._scheduleRestart(pool, worker);
    });
  }
  _onLine(pool, data, isErr){
    const lines = data.split(/\r?\n/).filter(Boolean);
    for (const line of lines) {
      const low = line.toLowerCase();
      if (low.includes('accept')) {
        this.emit('shareAccepted', { poolName: pool.name, raw: line });
      } else if (low.includes('reject')) {
        this.emit('shareRejected', { poolName: pool.name, raw: line });
      }
      // crude hashrate parse: look for e.g. '123.45 kh/s', '10.2 MH/s', '1.5 GH/s'
      const hr = line.match(/([0-9]+(?:\.[0-9]+)?)\s*(k|m|g|t|p)?h\/?s/i);
      if (hr) {
        const value = parseFloat(hr[1]);
        const unit = (hr[2]||'').toUpperCase();
        let mul=1; if(unit==='K') mul=1e3; else if(unit==='M') mul=1e6; else if(unit==='G') mul=1e9; else if(unit==='T') mul=1e12; else if(unit==='P') mul=1e15;
        this.emit('hashrate', { poolName: pool.name, value: value*mul, unit: unit+'H/s', raw: line });
      }
      this.log(pool.name, (isErr?'[ERR] ':'')+line);
    }
  }
  _scheduleRestart(pool, worker){
    const prev = this.restartDelays[pool.name] || 10000; // start 10s
    const next = Math.min(prev * 2, this.maxBackoff);
    this.restartDelays[pool.name] = next;
    setTimeout(()=>{
      this.startForPool(pool, worker);
    }, next).unref();
  }
}

module.exports = { HashEngineManager };