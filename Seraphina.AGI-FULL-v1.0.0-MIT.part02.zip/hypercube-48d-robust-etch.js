#!/usr/bin/env node
/**
 * hypercube-48d-robust-etch.js
 * Robust enhancer for aurrelia-pico-mesh-miner.js hypercube 48D (or <=64D) projection.
 * Features:
 *  - Validates requested dimension (1..64)
 *  - Backs up target file before patch (miner.js.bak timestamped)
 *  - Idempotent: skips if already etched (marker ROBUST_HYPERCUBE_ETCHED)
 *  - Writes log entries to etch.log
 *  - Rollback on failure
 *  - Optional revert (--revert) restores last backup
 *  - Optional phi scaling (--phi-scale=1) sets env for phi scaling in hypercube vectors
 *  - Optional blend override (--blend=0.07) sets default HYPERCUBE_BLEND value
 *  - Optional slice size override (--slice-size=N)
 *  - WASM fallback note: if octo-simd.wasm missing, logs advisory (no crash)
 *
 * Usage Examples:
 *    node hypercube-48d-robust-etch.js --d=48 --phi-scale=1 --blend=0.07 --slice-size=64
 *    node hypercube-48d-robust-etch.js --revert
 */

const fs = require('fs');
const path = require('path');

const LOG_PATH = path.resolve('etch.log');
const TARGET = path.resolve('aurrelia-pico-mesh-miner.js');
const MAX_SAFE_DIM = 64;
const SPILLOVER_LIMIT = 1e16; // guard for capacity calculations

function log(msg){
  const line = `[${new Date().toISOString()}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(LOG_PATH, line + '\n'); } catch(_){ }
}

function parseArgs(){
  const args = process.argv.slice(2);
  const get = k => { const raw = args.find(a=> a.startsWith(`--${k}=`)); return raw? raw.split('=')[1]: null; };
  const has = k => args.includes(`--${k}`);
  return { args, get, has };
}

function loadTarget(){
  if (!fs.existsSync(TARGET)) throw new Error('Target miner file not found');
  return fs.readFileSync(TARGET,'utf8');
}

function alreadyEtched(content){ return /ROBUST_HYPERCUBE_ETCHED/.test(content); }

function backup(){
  const stamp = Date.now();
  const name = `aurrelia-pico-mesh-miner.js.bak.${stamp}`;
  fs.copyFileSync(TARGET, name);
  log('Backup created: '+name);
  return name;
}

function revertLatest(){
  const files = fs.readdirSync('.').filter(f=> /^aurrelia-pico-mesh-miner\.js\.bak\.\d+$/.test(f));
  if (!files.length) throw new Error('No backups found');
  files.sort((a,b)=> parseInt(b.split('.').pop()) - parseInt(a.split('.').pop()));
  const latest = files[0];
  fs.copyFileSync(latest, TARGET);
  log('Reverted to backup: '+latest);
}

function validateDim(dim){
  if (Number.isNaN(dim)) throw new Error('Dimension NaN');
  if (dim < 1 || dim > MAX_SAFE_DIM) throw new Error(`Invalid dimension ${dim} (1..${MAX_SAFE_DIM})`);
}

function capacityEstimate(dim){
  // simplistic capacity proxy: number of vectors = 2*dim, potential combinations ~ dim^3 (bounded)
  const est = Math.pow(dim,3);
  if (est > SPILLOVER_LIMIT) throw new Error(`Spillover capacity risk est=${est} > ${SPILLOVER_LIMIT}`);
  return est;
}

function patchContent(original, dim, phiScale, blend, sliceSize){
  const marker = 'this.hypercube = {';
  if (!original.includes(marker)) throw new Error('Hypercube initialization marker not found');
  const lines = original.split(/\n/);
  const idx = lines.findIndex(l=> l.includes(marker));
  let braceClose = -1;
  for (let i=idx; i<lines.length; i++){ if (/^\s*};\s*$/.test(lines[i])){ braceClose = i; break; } }
  if (braceClose === -1) throw new Error('Hypercube block closing not found');
  const inject = [];
  inject.push('    // ROBUST_HYPERCUBE_ETCHED start');
  inject.push(`    this.robustHypercubeDim = ${dim};`);
  inject.push(`    if (process.env.AUR_DIM && parseInt(process.env.AUR_DIM,10) !== ${dim}) { /* mismatch noted */ } else { process.env.AUR_DIM = String(${dim}); }`);
  if (phiScale) inject.push('    process.env.HYPERCUBE_PHI_SCALE = process.env.HYPERCUBE_PHI_SCALE || "1";');
  if (blend) inject.push(`    process.env.HYPERCUBE_BLEND = process.env.HYPERCUBE_BLEND || "${blend}";`);
  if (sliceSize) inject.push(`    process.env.HYPERCUBE_SLICE_SIZE = process.env.HYPERCUBE_SLICE_SIZE || "${sliceSize}";`);
  inject.push('    // Capacity guard (spillover risk) dim^3 <= '+SPILLOVER_LIMIT);
  inject.push('    // ROBUST_HYPERCUBE_ETCHED end');
  lines.splice(braceClose+1,0,...inject);
  const patched = lines.join('\n');
  if (!/ROBUST_HYPERCUBE_ETCHED/.test(patched)) throw new Error('Patch marker missing');
  return patched;
}

function run(){
  const { get, has } = parseArgs();
  if (has('revert')){ try { revertLatest(); process.exit(0); } catch(e){ log('Revert failed: '+e.message); process.exit(1); } }
  let dim = parseInt(get('d') || '48',10); validateDim(dim); const est = capacityEstimate(dim); log(`Dimension ${dim} capacity est=${est}`);
  const phiScale = get('phi-scale') === '1'; const blend = get('blend'); const sliceSize = get('slice-size');
  const origin = loadTarget(); if (alreadyEtched(origin)){ log('Already etched; idempotent skip.'); process.exit(0); }
  const bak = backup();
  try {
    const wasmPath = process.env.OCTO_WASM_PATH || 'octo-simd.wasm'; if (!fs.existsSync(wasmPath)) log('WASM SIMD missing; JS fallback path');
    const patched = patchContent(origin, dim, phiScale, blend, sliceSize);
    fs.writeFileSync(TARGET, patched);
    log(`Patched hypercube dim=${dim} phiScale=${phiScale} blend=${blend||'unchanged'} sliceSize=${sliceSize||'auto'}`);
    const verifyLines = patched.split(/\n/).filter(l=> /ROBUST_HYPERCUBE_ETCHED|robustHypercubeDim/.test(l));
    log('Verification:\n'+verifyLines.map(l=>'  '+l).join('\n'));
    log('Success');
  } catch(e){
    log('Patch failed: '+e.message+' rolling back');
    try { fs.copyFileSync(bak, TARGET); log('Rollback complete'); } catch(rb){ log('Rollback failed: '+rb.message); }
    process.exit(1);
  }
}

run();

// Parse args
const args = process.argv.slice(2);
const arg = name => {
  const raw = args.find(a=> a.startsWith(`--${name}=`));
  return raw ? raw.split('=')[1] : null;
};
const has = name => args.includes(`--${name}`);

if (has('revert')){
  // Revert logic: find latest backup and restore
  try {
    const files = fs.readdirSync('.').filter(f=> /^aurrelia-pico-mesh-miner\.js\.bak\.\d+$/.test(f));
    if (!files.length){ log('No backups found to revert.'); process.exit(1); }
    files.sort((a,b)=> parseInt(b.split('.').pop()) - parseInt(a.split('.').pop()));
    const latest = files[0];
    fs.copyFileSync(latest, TARGET);
    log(`Reverted to backup: ${latest}`);
    process.exit(0);
  } catch(e){ log('Revert failed: '+e.message); process.exit(1); }
}

let dim = parseInt(arg('d') || '48',10);
if (Number.isNaN(dim)) dim = 48;
if (dim < 1 || dim > 64){
  log(`Invalid dimension ${dim}. Must be 1..64.`);
  process.exit(1);
}
const phiScale = arg('phi-scale') === '1';
const blend = arg('blend');
const sliceSize = arg('slice-size');

// Pre-flight checks
if (!fs.existsSync(TARGET)){
  log('Target miner file not found: '+TARGET);
  process.exit(1);
}

const original = fs.readFileSync(TARGET,'utf8');
if (/ROBUST_HYPERCUBE_ETCHED/.test(original)){
  log('Hypercube already robust-etched; skipping (idempotent). Use --revert to undo.');
  process.exit(0);
}

// Backup
const stamp = Date.now();
const backupName = `aurrelia-pico-mesh-miner.js.bak.${stamp}`;
try { fs.copyFileSync(TARGET, backupName); log('Backup created: '+backupName); } catch(e){ log('Backup failed: '+e.message); process.exit(1); }

// Construct patch block
// We look for hypercube state initialization in constructor (this.hypercube = { ... })
// and append marker comments + enforced dimension & phi scale env injection hook.
let patched;
try {
  const marker = 'this.hypercube = {';
  if (!original.includes(marker)) throw new Error('Hypercube initialization marker not found');

  // WASM advisory
  const wasmPath = process.env.OCTO_WASM_PATH || 'octo-simd.wasm';
  const wasmExists = fs.existsSync(wasmPath);
  if (!wasmExists){
    log(`WASM SIMD module not found at ${wasmPath}; proceeding with JS path (fallback).`);
  }

  // Inject after hypercube object definition closing '};' nearest following lines.
  // We'll append near first occurrence.
  const lines = original.split(/\n/);
  let idx = lines.findIndex(l=> l.includes(marker));
  let braceClose = -1;
  for (let i=idx; i<lines.length; i++){
    if (/^\s*};\s*$/.test(lines[i])){ braceClose = i; break; }
  }
  if (braceClose === -1) throw new Error('Hypercube block closing not found');

  const inject = [];
  inject.push('    // ROBUST_HYPERCUBE_ETCHED start');
  inject.push(`    this.robustHypercubeDim = ${dim};`);
  inject.push(`    if (process.env.AUR_DIM && parseInt(process.env.AUR_DIM,10) !== ${dim}) { /* respect existing AUR_DIM but note mismatch */ } else { process.env.AUR_DIM = String(${dim}); }`);
  if (phiScale){
    inject.push('    process.env.HYPERCUBE_PHI_SCALE = process.env.HYPERCUBE_PHI_SCALE || "1";');
  }
  if (blend){
    inject.push(`    process.env.HYPERCUBE_BLEND = process.env.HYPERCUBE_BLEND || "${blend}";`);
  }
  if (sliceSize){
    inject.push(`    process.env.HYPERCUBE_SLICE_SIZE = process.env.HYPERCUBE_SLICE_SIZE || "${sliceSize}";`);
  }
  inject.push('    // Ensure slice size does not exceed vector count later (runtime checked)');
  inject.push('    // WASM fallback note: JS path retained if module load fails.');
  inject.push('    // ROBUST_HYPERCUBE_ETCHED end');

  lines.splice(braceClose+1,0,...inject);

  patched = lines.join('\n');

  // Basic validation: confirm marker comment present & dimension set
  if (!/ROBUST_HYPERCUBE_ETCHED/.test(patched)) throw new Error('Patch marker missing after injection');
  if (!patched.includes(`this.robustHypercubeDim = ${dim};`)) throw new Error('Dimension injection failed');

  // Write updated file
  fs.writeFileSync(TARGET, patched);
  log(`Patched hypercube dimension=${dim} phiScale=${phiScale} blend=${blend||'unchanged'} sliceSize=${sliceSize||'auto'}`);

} catch(e){
  log('Patch failed: '+e.message+' rolling back.');
  try { fs.copyFileSync(backupName, TARGET); log('Rollback complete.'); } catch(rb){ log('Rollback failed: '+rb.message); }
  process.exit(1);
}

// Final advisory: quick diff lines
try {
  const diffLines = patched.split(/\n/).filter(l=> /ROBUST_HYPERCUBE_ETCHED/.test(l) || /robustHypercubeDim/.test(l));
  log('Patch verification lines:\n'+diffLines.map(l=>'  '+l).join('\n'));
} catch(_){ }

log('Robust hypercube etch completed successfully.');
