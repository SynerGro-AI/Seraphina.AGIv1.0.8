// command-moral-gate.js
// Deterministic moral gate leveraging command-risk-classifier.
// Blocks HIGH risk commands; returns structured report.
'use strict';
const { classify, classifyBatch } = require('./command-risk-classifier');

function validateCommands(commands){
  if(!Array.isArray(commands)) throw new Error('commands must be array');
  const results = classifyBatch(commands.map(String));
  const blocked = results.filter(r=> r.risk === 'HIGH');
  const suggestions = [];
  const altMap = [
    { pattern:/rm\s+-rf/i, alt:'Use trash or targeted rm without -rf, verify path, add --preserve-root' },
    { pattern:/passwd\b.*root/i, alt:'Avoid direct root password changes; use sudoers adjustments or key-based auth' },
    { pattern:/wipefs|mkfs|dd\b/i, alt:'Backup device first; use lsblk and blkid to verify target before formatting' },
    { pattern:/mount\b.*dev\/sd/i, alt:'Mount read-only first with -o ro to inspect contents' },
    { pattern:/chown\b.*root:root/i, alt:'Limit scope; apply least privilege principle' }
  ];
  blocked.forEach(b=> {
    let alt = null;
    for(const m of altMap){ if(m.pattern.test(b.command)){ alt = m.alt; break; } }
    suggestions.push({ command: b.command, reasons: b.reasons, alternative: alt });
  });
  return {
    analyzed: results.length,
    blockedCount: blocked.length,
    blockedCommands: suggestions,
    allowedCommands: results.filter(r=> r.risk !== 'HIGH').map(r=> r.command),
    all: results
  };
}

if(require.main === module){
  const args = process.argv.slice(2);
  const report = validateCommands(args);
  process.stdout.write(JSON.stringify(report,null,2)+'\n');
}

module.exports = { validateCommands };
