#!/usr/bin/env python3
"""Deterministic Coral TPU inference helper.
Modes:
  1) Single-shot: coral_infer.py "[json array features]"
  2) Warm server: coral_infer.py --server <ipc_base.sock>
Server IPC protocol (file-based, deterministic, no sockets to keep portability):
  Writes request features to <ipc>.sock.req
  Python reads, performs inference (or deterministic fallback if TPU not available), writes <ipc>.sock.res
Feature Vector: Must match ordering in miner (meanEff, eff[0..3], attempts[0..3], accepts[0..3], gapRatio, rashbaGain, hypercubeBlend, subsetIdx, chernProxy)
Deterministic Fallback: If TPU libs unavailable, we hash features via FNV-1a and derive stable weights.
"""
import sys, json, time, os, hashlib

# Attempt to import pycoral libs; fallback if not present
try:
    from pycoral.utils import edgetpu
    TPU_AVAILABLE = True
except Exception:
    TPU_AVAILABLE = False

MODEL_PATH = os.environ.get('CORAL_MODEL_PATH','model_edgetpu.tflite')

engine = None
interpreter = None
if TPU_AVAILABLE and os.path.exists(MODEL_PATH):
    try:
        interpreter = edgetpu.make_interpreter(MODEL_PATH)
        interpreter.allocate_tensors()
    except Exception:
        interpreter = None
        TPU_AVAILABLE = False

# Deterministic weight derivation fallback
def derive_weights(feats, count=4):
    h = hashlib.sha256(json.dumps(feats, separators=(',',':')).encode()).digest()
    out = []
    for i in range(count):
        # use 4 bytes per weight
        chunk = h[i*4:(i+1)*4]
        v = int.from_bytes(chunk,'little') & 0xFFFFFF
        d = (v/float(0xFFFFFF))
        out.append(0.5 + 0.5*d)
    s = sum(out)
    return [w/s for w in out]

# Real inference (assuming model outputs 4-plane softmax or logits)
def infer(feats):
    if not TPU_AVAILABLE or interpreter is None:
        return derive_weights(feats)
    try:
        # Fill input tensor deterministically (assuming float32 input)
        input_details = interpreter.get_input_details()[0]
        tensor = interpreter.tensor(input_details['index'])()[0]
        # Clear then set (pad/truncate)
        for i in range(len(tensor)):
            tensor[i] = 0.0
        lim = min(len(tensor), len(feats))
        for i in range(lim):
            tensor[i] = float(feats[i])
        start = time.time()
        interpreter.invoke()
        out_details = interpreter.get_output_details()[0]
        output = interpreter.tensor(out_details['index'])()[0]
        arr = [float(v) for v in output[:4]]
        # Normalize
        s = sum(max(1e-6, v) for v in arr)
        return [max(1e-6,v)/s for v in arr]
    except Exception:
        return derive_weights(feats)

if '--server' in sys.argv:
    base = sys.argv[sys.argv.index('--server')+1]
    req = base + '.req'
    res = base + '.res'
    print('[CoralServer] starting warm server, TPU_AVAILABLE=%s' % TPU_AVAILABLE, flush=True)
    while True:
        try:
            if os.path.exists(req):
                try:
                    raw = open(req,'r').read()
                    feats = json.loads(raw)
                except Exception:
                    feats = []
                out = infer(feats)
                try:
                    open(res,'w').write(json.dumps(out))
                except Exception:
                    pass
                try:
                    os.unlink(req)
                except Exception:
                    pass
            time.sleep(0.05)
        except KeyboardInterrupt:
            break
        except Exception:
            # Keep loop alive deterministically
            time.sleep(0.1)
    sys.exit(0)
else:
    if len(sys.argv) < 2:
        print(json.dumps(derive_weights([])))
        sys.exit(0)
    feats = json.loads(sys.argv[1])
    out = infer(feats)
    print(json.dumps(out))
    sys.exit(0)
