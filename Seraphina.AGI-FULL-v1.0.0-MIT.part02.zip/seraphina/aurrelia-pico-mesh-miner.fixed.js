// aurrelia-pico-mesh-miner.fixed.js (modular rebuild baseline)
// Phase 1 modularization: extracts hashing (hash-strategies.js), economics (econ.js), geometry (geometry-octo.js), crystal tuner (crystal-tuner.js), multi-worker (multiworker.js placeholder)
// Focus coins: BTC / RVN / FREN. Deterministic only – no simulation paths.

'use strict';

// --- Economic counters WAL (parity with main miner variant) -----------------
// Light-weight persistence so /self-check can expose last known switch/rollback
// stats even in this modular fixed build. If the main autoswitch logic writes
// to econ-counters.wal we surface size & rotation status here.
const __ECON_COUNTER_WAL = 'econ-counters.wal';
const __ECON_LOG_SCHEMA = 'econ_event/v1.0';
const __ECON_WAL_MAX_SIZE = parseInt(process.env.ECON_WAL_MAX_SIZE || (10*1024*1024).toString(),10); // 10 MB
const __ECON_WAL_MAX_FILES = parseInt(process.env.ECON_WAL_MAX_FILES || '5',10);
let __ECON_LAST_SNAP = null; // cached latest parsed line
let __ECON_LAST_WAL_STAT_TS = 0;
let __ECON_LAST_WAL_SIZE = 0;
let __ECON_LAST_BACKUPS = 0;
let __ECON_WAL_ROTATIONS = 0; // incremented on successful rotation

function econRotateWalFixed(){
  try {
    const fs = require('fs'); const zlib = require('zlib');
    if (!fs.existsSync(__ECON_COUNTER_WAL)) return;
    const st = fs.statSync(__ECON_COUNTER_WAL);
    if (st.size <= __ECON_WAL_MAX_SIZE) return;
    const ts = Date.now();
    const gzName = `${__ECON_COUNTER_WAL}.${ts}.gz`;
    const inp = fs.createReadStream(__ECON_COUNTER_WAL); const out = fs.createWriteStream(gzName); const gz = zlib.createGzip();
    inp.pipe(gz).pipe(out).on('finish', ()=>{
      try { fs.unlinkSync(__ECON_COUNTER_WAL); } catch(_){ }
      try { // prune old archives (keep newest N)
        const list = fs.readdirSync('.').filter(f=>f.startsWith('econ-counters.wal.') && f.endsWith('.gz')).sort();
        const excess = list.length - __ECON_WAL_MAX_FILES;
        if (excess>0){ for (let i=0;i<excess;i++){ try { fs.unlinkSync(list[i]); } catch(_){} } }
      } catch(_e){}
      __ECON_WAL_ROTATIONS++;
    });
  } catch(e){ console.warn('[ECON][Rotate][fixed] failed', e.message); }
}

function econRefreshWalSnapshot(){
  try {
    const fs = require('fs');
    if (fs.existsSync(__ECON_COUNTER_WAL)){
      const raw = fs.readFileSync(__ECON_COUNTER_WAL,'utf8').trim();
      if (raw){
        const lastLine = raw.split(/\n/).filter(Boolean).pop();
        try { __ECON_LAST_SNAP = JSON.parse(lastLine); } catch(_j){ }
      }
      __ECON_LAST_WAL_SIZE = fs.statSync(__ECON_COUNTER_WAL).size;
    } else {
      __ECON_LAST_WAL_SIZE = 0; __ECON_LAST_SNAP = null;
    }
    // backup count
    try {
      const list = require('fs').readdirSync('.').filter(f=>f.startsWith('econ-counters.wal.') && f.endsWith('.gz'));
      __ECON_LAST_BACKUPS = list.length;
    } catch(_b){ __ECON_LAST_BACKUPS = 0; }
    __ECON_LAST_WAL_STAT_TS = Date.now();
  } catch(e){ /* silent */ }
}

// Initial snapshot (non-fatal if fails)
try { econRefreshWalSnapshot(); } catch(_){ }


const crypto = require('crypto');
const fs = require('fs');
const { HASH_STRATEGIES, doubleSha256 } = require('./hash-strategies.js');
const { initEcon, state: ECONSTATE } = require('./econ.js');
const { buildPlaneSeeds } = require('./geometry-octo.js');
const PicoCrystalTuner = require('./crystal-tuner.js');
require('./multiworker-controller.js'); // coordinated multiworker
const { createFusedBatch } = require('./fused-batch.js');
const { createAdaptivePrune } = require('./adaptive-prune.js');
const { runIntegrityChecks } = require('./integrity-guard.js');
const { initKawpowParity, initShaParity } = require('./parity-guard.js');
const { attachPoolRotation } = require('./pool-rotation.js');
const { startMining } = require('./mining-core.js');
const { getPrices, bestMiningTarget } = (()=>{ try { return require('./price-oracle.js'); } catch(e){ return { getPrices: async()=>({}), bestMiningTarget:()=>null }; } })();
const { WalletPlatform } = (()=>{ try { return require('./wallet-platform.js'); } catch(e){ return {}; } })();
let DepositManager = null; try { DepositManager = require('./deposit-manager.js'); } catch(_){ }
const { buildWithdrawal, exportAddresses } = (()=>{ try { return require('./kraken-exporter.js'); } catch(_){ return {}; } })();

// Early integrity enforcement (before starting heavy subsystems)
try { runIntegrityChecks({}); } catch(e){ console.error('[Integrity][Fatal]', e.message); process.exit(2); }

// Auto-switch hook writes to file; pluggable for future pool rotation
let LAST_SWITCH_TS = 0; const MIN_SWITCH_MS = parseInt(process.env.AUR_ECON_MIN_SWITCH_MS || '600000',10);
function onEconomicRecommendation(target, meta){
  if (!target) return; const now=Date.now();
  const hyst = parseInt(process.env.AUR_ECON_HYST_CYCLES||'2',10);
  if ((meta?.stable||0) < hyst) return;
  if (now - LAST_SWITCH_TS < MIN_SWITCH_MS) return;
  try { fs.writeFileSync('econ-recommend.txt', JSON.stringify({ t: now, target, meta })); LAST_SWITCH_TS = now; console.log('[ECON][AutoSwitch]', target, meta); } catch(_){}
  const minStable = parseInt(process.env.AUR_ROTATE_MIN_STABLE || '2',10);
  if (global.__AUR_PIPELINE__ && meta && meta.stable >= minStable && target && target !== global.__AUR_PIPELINE__.selectedCoin){
    if (process.env.AUR_ROTATE_ENABLED==='1'){
      console.log('[Rotate][EconTrigger] stable cycles', meta.stable, 'switch to', target);
      global.__AUR_PIPELINE__.rotateToCoin && global.__AUR_PIPELINE__.rotateToCoin(target);
    }
  }
}
initEcon(onEconomicRecommendation);

// --- Stratum Skeleton ------------------------------------------------
let RealStratumClient = null; try { ({ RealStratumClient } = require('./real-stratum-client.js')); } catch(_){ }
class MinimalPipeline {
  constructor(){
  this.selectedCoin = (process.env.AUR_COIN||'btc').toLowerCase();
  if (this.selectedCoin==='rvn'||this.selectedCoin==='fren') this.hashStrategy = HASH_STRATEGIES.kawpow || HASH_STRATEGIES.sha256d;
  else if (this.selectedCoin==='kas') this.hashStrategy = HASH_STRATEGIES.kheavy || HASH_STRATEGIES.sha256d;
  else if (this.selectedCoin==='ltc') this.hashStrategy = HASH_STRATEGIES.scrypt || HASH_STRATEGIES.sha256d; // LTC readiness (scrypt). Falls back to sha256d if scrypt not present.
  else this.hashStrategy = HASH_STRATEGIES.sha256d;
    // --- FREN Multi-Address Rotation (pre-autogen) ---
    if (this.selectedCoin === 'fren' && !process.env.FREN_WALLET && process.env.FREN_WALLETS) {
      const list = process.env.FREN_WALLETS.split(/[,\s]+/).map(s=>s.trim()).filter(Boolean);
      if (list.length) {
        this.frenWallets = list;
        this._frenWalletIndex = 0;
        process.env.FREN_WALLET = list[0];
        console.log('[FREN][MultiWallet] Loaded', list.length, 'addresses. Using index=0');
      }
    }
    // --- FREN Wallet Auto-Generation (if coin=fren and no FREN_WALLET set) ---
    if (this.selectedCoin === 'fren' && !process.env.FREN_WALLET && process.env.FREN_AUTOGEN !== '0') {
      try {
        const { generateFRENAddress } = require('./fren-wallet-swap.js');
        const rpcHost = process.env.FREN_RPC_HOST || 'localhost';
        const rpcPort = parseInt(process.env.FREN_RPC_PORT || '8332',10);
        const rpcUser = process.env.FREN_RPC_USER || 'user';
        const rpcPass = process.env.FREN_RPC_PASS || 'pass';
        const seedPhrase = process.env.FREN_SEED_PHRASE || null;
        console.log('[FREN][Autogen] Generating wallet (rpcHost='+rpcHost+':'+rpcPort+', seed='+(seedPhrase? 'yes':'no')+')');
        const genPromise = generateFRENAddress(rpcHost, rpcPort, rpcUser, rpcPass, seedPhrase);
        // Support both promise and sync (should be promise)
        const autogenStart = Date.now();
        this.frenAutogenMeta = { start: autogenStart, success: 0, fail: 0, validated: 0 };
        Promise.resolve(genPromise).then(addrObj => {
          if (!addrObj || !addrObj.address) throw new Error('address generation returned empty');
          // FREN address validation (Base58Check + prefix) before acceptance
          let valid = false; let vErr='';
          try { valid = validateFrenAddress(addrObj.address); if(!valid) vErr='checksum/prefix'; } catch(e){ vErr = e.message; }
          if (!valid) throw new Error('Generated FREN address failed validation: '+vErr);
          process.env.FREN_WALLET = addrObj.address;
          console.log('[FREN][Autogen] Address:', addrObj.address, 'source=', addrObj.source);
          // Optional HMAC seal
          if (process.env.CONFIG_HMAC_KEY){
            try {
              const h = require('crypto').createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(addrObj.address).digest('hex').slice(0,16);
              process.env.FREN_WALLET_HMAC = h;
              try { fs.appendFileSync('.fren-env', `FREN_WALLET=${addrObj.address}\nFREN_WALLET_HMAC=${h}\n`); } catch(_envErr){}
              console.log('[FREN][Autogen] HMAC(sealed)=', h);
            } catch(e){ console.warn('[FREN][Autogen] HMAC seal failed:', e.message); }
          } else {
            try { fs.appendFileSync('.fren-env', `FREN_WALLET=${addrObj.address}\n`); } catch(_envErr){}
          }
          // Persist JSON artifact (optionally encrypted)
          const walletObj = { t:Date.now(), autogenMs: Date.now()-autogenStart, ...addrObj };
          try {
            const vaultKeyRaw = process.env.FREN_VAULT_KEY || (process.env.FREN_VAULT_KEY_FILE && fs.existsSync(process.env.FREN_VAULT_KEY_FILE) ? fs.readFileSync(process.env.FREN_VAULT_KEY_FILE,'utf8').trim() : null);
            if (vaultKeyRaw) {
              const key = crypto.createHash('sha256').update(vaultKeyRaw).digest();
              const { deriveBuffer } = require('./deterministic-util');
              const iv = deriveBuffer('fixed-iv',12,this.phase||0,Date.now());
              const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
              const plaintext = JSON.stringify(walletObj);
              const ct = Buffer.concat([cipher.update(plaintext,'utf8'), cipher.final()]);
              const tag = cipher.getAuthTag();
              const encObj = { alg:'AES-256-GCM', iv: iv.toString('hex'), ct: ct.toString('base64'), tag: tag.toString('hex'), created: walletObj.t };
              fs.writeFileSync('fren-wallet.enc', JSON.stringify(encObj,null,2));
              console.log('[FREN][Autogen][Encrypted] Stored fren-wallet.enc');
            } else {
              fs.writeFileSync('fren-wallet.json', JSON.stringify(walletObj, null,2));
            }
          } catch(e){ console.warn('[FREN][Autogen] Persist error', e.message); }
          if (this.frenAutogenMeta){ this.frenAutogenMeta.success = 1; this.frenAutogenMeta.validated = 1; this.frenAutogenMeta.durationMs = Date.now()-autogenStart; }
        }).catch(e => {
          console.warn('[FREN][Autogen] Generation error:', e.message);
          if (process.env.REAL_MINING_ENFORCED==='1'){ console.error('[FREN][Autogen] Enforcement active -> abort'); process.exit(12); }
          else {
            process.env.FREN_WALLET = 'FMockTestAddressForDebug';
            console.log('[FREN][Autogen] Using mock wallet (enforcement off)');
          }
          if (this.frenAutogenMeta){ this.frenAutogenMeta.fail = 1; }
        });
      } catch(e){
        console.warn('[FREN][Autogen] Module load failed:', e.message);
      }
    } else if (this.selectedCoin==='fren' && process.env.FREN_WALLET) {
      // Integrity: verify HMAC if present
      if (process.env.FREN_WALLET_HMAC && process.env.CONFIG_HMAC_KEY){
        try {
          const recompute = require('crypto').createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(process.env.FREN_WALLET).digest('hex').slice(0,16);
          if (recompute !== process.env.FREN_WALLET_HMAC){
            const msg='FREN wallet HMAC mismatch';
            if (process.env.STRICT_INTEGRITY==='1'){ console.error('[FREN][Integrity]', msg,'-> abort'); process.exit(13); }
            else console.warn('[FREN][Integrity]', msg,'(continuing)');
          }
        } catch(e){ console.warn('[FREN][Integrity] HMAC verify error:', e.message); }
      }
      console.log('[FREN] Using wallet', process.env.FREN_WALLET);
    }
    this.stats = { hashes:0, shares:0 };
  this.shareStats = { acceptanceRatio:0, accepted:0, rejected:0, stale:0, invalid:0 };
    this.startTime = Date.now();
    // Optional OctaLang spiral aggregate spin bias loader
    this.octaSpinBias = null;
    try {
      let spinHex = process.env.OCTA_SPIN_HASH;
      if (!spinHex && fs.existsSync('octa-spin.txt')) {
        const raw = (fs.readFileSync('octa-spin.txt','utf8')||'').trim();
        if (/^[0-9a-fA-F]{4,64}$/.test(raw)) spinHex = raw;
      }
      if (spinHex && /^[0-9a-fA-F]{4,64}$/.test(spinHex)) {
        this.octaSpinBias = parseInt(spinHex.slice(0,8),16) >>> 0;
        console.log('[OctaSpin] Loaded aggregate spin bias 0x'+spinHex.slice(0,8));
      }
    } catch(e){ console.warn('[OctaSpin] Load failed:', e.message); }
    this.crystal = new PicoCrystalTuner();
    // Adaptive prune (placeholder integration; can drive norm filtering once real nonce loop integrated)
  this.adaptivePrune = createAdaptivePrune({ base: parseFloat(process.env.AUR_PRUNE_BASE || '2.5'), min: parseFloat(process.env.AUR_PRUNE_MIN || '1.6'), max: parseFloat(process.env.AUR_PRUNE_MAX || '4.0'), step: parseFloat(process.env.AUR_PRUNE_STEP || '0.05'), targetAccept: parseFloat(process.env.AUR_PRUNE_TARGET_ACCEPT || '0.25'), window: parseInt(process.env.AUR_PRUNE_WINDOW || '4000',10), adjustMs: parseInt(process.env.AUR_PRUNE_ADJUST_MS || '8000',10), persistFile: process.env.AUR_PRUNE_STATE_FILE, persistMs: parseInt(process.env.AUR_PRUNE_PERSIST_MS||'15000',10) });
    // Fused batch engine (sha256d only)
    if (this.hashStrategy.id === 'sha256d'){
      let fusedImpl=null; try { fusedImpl = require('./fused_wasm.js'); } catch(_){ }
      this.fusedBatch = createFusedBatch({ enable: process.env.FUSED_ENABLED !== '0', fusedImpl, hashFn: doubleSha256 });
    }
    if (RealStratumClient){
  const host = process.env.STRATUM_HOST || (
        this.selectedCoin==='rvn' ? 'rvn.2miners.com' :
        this.selectedCoin==='fren' ? (process.env.FREN_DEFAULT_POOL_HOST||'fren.example.pool') :
        this.selectedCoin==='ltc' ? (process.env.LTC_POOL_HOST||'ltc.f2pool.com') :
        'stratum.slushpool.com'
      );
  const port = parseInt(process.env.STRATUM_PORT || (
        this.selectedCoin==='rvn' ? '6060' :
        this.selectedCoin==='fren' ? (process.env.FREN_DEFAULT_POOL_PORT||'12345') :
        this.selectedCoin==='ltc' ? (process.env.LTC_POOL_PORT||'3335') :
        '3333'
      ),10);
      // Worker derivation logic (wallet.rig). Priority: explicit STRATUM_WORKER > STRATUM_USER > derived wallet + rigName
      let worker = process.env.STRATUM_WORKER || process.env.STRATUM_USER;
      const rigName = process.env.RIG_NAME || process.env.WORKER_NAME || 'Rig01';
      if (!worker){
        // Attempt wallet detection for RVN/FREN/LTC
        if (this.selectedCoin==='rvn' || this.selectedCoin==='fren'){
          const wallet = process.env.STRATUM_WALLET || process.env.RVN_MINING_ADDRESS || process.env.RVN_LOCAL_ADDRESS || process.env.RVN_WALLET || process.env.RVN_ADDRESS;
          if (wallet){ worker = wallet + '.' + rigName; }
        } else if (this.selectedCoin==='ltc') {
          const ltcWallet = process.env.STRATUM_WALLET || process.env.LTC_MINING_ADDRESS || process.env.LTC_KRAKEN_ADDRESS;
          if (ltcWallet){ worker = ltcWallet + '.' + rigName; }
        }
      }
      if (!worker) worker = 'WALLET.WORKER';
      const password = process.env.STRATUM_PASSWORD || process.env.STRATUM_PASS || 'x';
      // Always log chosen stratum parameters (password redacted)
      try {
        console.log(`[Stratum] init coin=${this.selectedCoin} host=${host}:${port} worker=${worker}`);
        if (/WALLET\.WORKER/i.test(worker)) {
          console.warn('[Stratum][Warn] Placeholder worker detected. Set STRATUM_WORKER="<RVN_WALLET_ADDRESS>.<RigName>"');
        }
        if (this.selectedCoin==='rvn'){
          const wAddr = (worker.split('.')[0]||'');
          if (process.env.RVN_SKIP_ADDR_CHECK!=='1'){
            const rvnValidBasic = /^R[1-9A-HJ-NP-Za-km-z]{25,}$/; // basic length check
            let deepOk=false; let deepErr='';
            if (rvnValidBasic.test(wAddr)){
              try {
                if (validateRvnAddress(wAddr)) deepOk=true; else deepErr='checksum mismatch';
              } catch(e){ deepErr = e.message; }
            } else {
              deepErr = 'format mismatch';
            }
            if (!deepOk){
              console.error(`[Stratum][AddrInvalid] Ravencoin address failed validation (${deepErr}). Set RVN_MINING_ADDRESS or STRATUM_WORKER with a valid address. To bypass temporarily: set RVN_SKIP_ADDR_CHECK=1 (NOT recommended).`);
              if (process.env.FAIL_ON_INVALID_ADDR==='1'){
                console.error('[Stratum][AddrInvalid] Aborting due to FAIL_ON_INVALID_ADDR=1');
                process.exit(7);
              }
            }
          }
        } else if (this.selectedCoin==='ltc') {
          const wAddr = (worker.split('.')[0]||'');
          if (process.env.LTC_SKIP_ADDR_CHECK!=='1') {
            let ok=false; let why='';
            try { ok = validateLtcAddress(wAddr); if (!ok) why='checksum/version mismatch'; } catch(e){ why=e.message; }
            if (!ok){
              console.error(`[Stratum][AddrInvalid] Litecoin address failed validation (${why}). Set LTC_MINING_ADDRESS or STRATUM_WORKER with a valid address. To bypass: set LTC_SKIP_ADDR_CHECK=1 (NOT recommended).`);
              if (process.env.FAIL_ON_INVALID_ADDR==='1'){ console.error('[Stratum][AddrInvalid] Aborting due to FAIL_ON_INVALID_ADDR=1'); process.exit(8); }
            }
          }
          // Enforce presence of real scrypt hashing path if attempting actual mining
          if (this.hashStrategy && this.hashStrategy.id !== 'scrypt'){
            console.warn('[LTC][Warn] Scrypt hash strategy not active (scryptsy missing?). Mining will not function until installed: npm install scryptsy');
          }
        }
      } catch(_){ }
      this.stratum = new RealStratumClient({ coin: this.selectedCoin.toUpperCase(), host, port, worker, password });
      // Graceful error handling to prevent unhandled crash on authorize failure
      this.stratum.on('error', (e)=>{
        if (/AUTHORIZE_FAILED/.test(e.message)){
          console.error('[Stratum][AuthFail] Authorization failed. Fix wallet/worker then restart. Message:', e.message);
          if (process.env.EXIT_ON_AUTH_FAIL==='1') return process.exit(10);
          // Otherwise pause reconnect attempts until user fixes env (no mining without auth)
        }
      });
      this.wire();
      const doConnect = ()=>{
        if (this._connectedAttempted) return; // ensure single connect attempt lifecycle per gating transition
        this._connectedAttempted = true;
        this.stratum.connect().catch(e=>{
          console.error('[Stratum][ConnectError]', e.message);
          this._connectedAttempted = false; // allow retry
          const backoff = 5000; // simple fixed backoff
          setTimeout(()=>{ console.log('[Stratum] Retrying connect...'); doConnect(); }, backoff).unref();
        });
      };
      // Hashrate / capability gating (auto-start) for BTC + LTC
      const nowMs = Date.now();
      this._gatingStart = nowMs;
      const btcThresholdEhs = parseFloat(process.env.BTC_START_MIN_HASHRATE_EHS||'0'); // e.g. 0.000001 for 1 PH/s
      const ltcThresholdMhs = parseFloat(process.env.LTC_START_MIN_HASHRATE_MHS||'0');
      const genericHsThreshold = parseFloat(process.env.AUR_GENERIC_START_MIN_HS||'0');
      const maxWaitMs = parseInt(process.env.AUTO_START_WAIT_MAX_MS||'0',10); // 0 = infinite wait
      const gatingCoin = (this.selectedCoin==='btc' && btcThresholdEhs>0) || (this.selectedCoin==='ltc' && ltcThresholdMhs>0) || (genericHsThreshold>0);
      if (!gatingCoin){
        doConnect();
      } else {
        console.log('[AutoStart] Gating enabled for', this.selectedCoin, 'thresholds =>', {
          btcThresholdEhs, ltcThresholdMhs, genericHsThreshold, maxWaitMs
        });
        const gateTimer = setInterval(()=>{
          const elapsed = Date.now()-this._gatingStart;
          const hashes = this.stats.hashes; // updated by mining-core once active (pre-connection may be 0)
          const hs = hashes && elapsed>0 ? (hashes / (elapsed/1000)) : 0;
          const ehs = hs / 1e18;
          const mhs = hs / 1e6;
          const genericMet = genericHsThreshold>0 && hs >= genericHsThreshold;
          const btcMet = this.selectedCoin==='btc' && btcThresholdEhs>0 && ehs >= btcThresholdEhs;
          const ltcMet = this.selectedCoin==='ltc' && ltcThresholdMhs>0 && mhs >= ltcThresholdMhs;
          const anyMet = btcMet || ltcMet || genericMet;
          if (anyMet){
            console.log('[AutoStart] Threshold met (hs=', hs.toFixed(2), 'EHS=', ehs.toExponential(3), 'MHS=', mhs.toFixed(2), ') -> initiating stratum connect');
            clearInterval(gateTimer); doConnect(); return;
          }
          if (maxWaitMs>0 && elapsed>maxWaitMs){
            console.log('[AutoStart] Max wait exceeded -> forcing connect');
            clearInterval(gateTimer); doConnect(); return;
          }
          if (!(hashes % 2000)){
            console.log('[AutoStart][Waiting]', this.selectedCoin, 'hs=', hs.toFixed(2), 'EHS=', ehs.toExponential(3), 'MHS=', mhs.toFixed(2));
          }
        }, 2000).unref();
      }
    } else {
      console.warn('[Pipeline] RealStratumClient unavailable – running hash self-test loop only.');
      this.selfTest();
    }
    // Pool rotation support
    attachPoolRotation(this);
    // Parity guards
    initKawpowParity(this, { onDisable: ()=>{ this.hashStrategy = HASH_STRATEGIES.sha256d; } });
    initShaParity(this, { onDisable: ()=>{ if (this.fusedBatch) this.fusedBatch = null; } });
    this._initMetricsEndpoint();
    this._initCliControl();
  this._initIncomeOptimizer();
  // Auto spin optimization (adaptive Octa spin experimentation) init before metrics so gauges can attach lazily
  this._initAutoSpin();
    // Trading init (after income optimizer scaffold)
    if (process.env.TRADING_ENABLED === '1') {
      try { const LowFeeTrader = require('./trading-module.js'); this.trader = new LowFeeTrader(this); console.log('[Trading] Module active'); }
      catch(e){ console.warn('[Trading] Load failed:', e.message); }
      if (DepositManager) {
        try { this.depositManager = new DepositManager(this); console.log('[Deposit] Manager active'); } catch(e){ console.warn('[Deposit] Init failed', e.message); }
      }
    }
  }
  wire(){
    this.stratum.on('job', job=>{ 
      // Maintain both currentJob and legacy p.job field used by mining-core
      this.currentJob = job; this.job = job; 
      this._planeCache=null; this.extranonce1 = this.stratum.extranonce1; 
    });
    this.stratum.on('shareAccepted', (o)=>{ this.shareStats.accepted++; this.updateAcceptance(); this.adaptivePrune.recordShare(true,false); });
    this.stratum.on('shareRejected', (o)=>{ // classify stale vs invalid
      const isStale = Array.isArray(o.error) && /stale/i.test(JSON.stringify(o.error));
      this.shareStats.rejected++;
      if (isStale) this.shareStats.stale++; else this.shareStats.invalid++;
      this.updateAcceptance(); this.adaptivePrune.recordShare(false, isStale); });
    // Optional FREN multi-wallet rotation trigger (manual or heuristic placeholder)
    if (this.selectedCoin==='fren'){
      this.maybeRotateFrenWallet = ()=>{
        if (!this.frenWallets || this.frenWallets.length < 2) return false;
        // Heuristic: rotate if acceptance ratio very low and at least some rejects
        if (this.shareStats.accepted + this.shareStats.rejected < 10) return false;
        if (this.shareStats.acceptanceRatio > 0.05) return false;
        return this.rotateFrenAddress('heuristic-low-accept');
      };
      // Periodic check every 60s
      setInterval(()=>{ try { this.maybeRotateFrenWallet(); } catch(_e){} },60000).unref();
    }
  }
  updateAcceptance(){ const tot=this.shareStats.accepted+this.shareStats.rejected; this.shareStats.acceptanceRatio = tot? this.shareStats.accepted/tot : 0; }
  selfTest(){
    setInterval(()=>{
  const { deriveHex } = require('./deterministic-util');
  let header = deriveHex('fixed-header', this.iteration||0, Date.now()).repeat(2).slice(0,160);
      // Apply optional Octa spin bias by XOR-ing first 4 bytes of header with spin value
      if (this.octaSpinBias != null){
        try {
          const prefix = header.slice(0,8);
            const prefNum = parseInt(prefix,16) >>> 0;
            const mixed = (prefNum ^ this.octaSpinBias) >>> 0;
            header = mixed.toString(16).padStart(8,'0') + header.slice(8);
            if (!(this.stats.hashes % 20000)) console.log('[OctaSpin][Bias] prefix', prefix,'->', header.slice(0,8));
        } catch(_e){}
      }
      // Multi-plane hyper integration (deterministic plane seeds)
      if (this.currentJob && !this._planeCache){ this._planeCache = buildPlaneSeeds(this.currentJob, this.currentJob.extranonce1 || ''); }
      if (process.env.HYPERCUBE_48D==='1' && this.currentJob && !(this.stats.hashes % 8192)){
        try {
          const { generateHypercube } = require('./hypercube-48d.js');
          const hc = generateHypercube(this.currentJob, { extranonce1: this.extranonce1 });
          if (!this._lastHcLog || Date.now()-this._lastHcLog > 15000){
            console.log('[Hypercube48D] rankProxy=', hc.rankProxy.toFixed(3), 'signVar=', hc.signVar.toFixed(3));
            this._lastHcLog = Date.now();
          }
        } catch(e){ /* ignore */ }
      }
      let h;
      if (this.fusedBatch){
        this.fusedBatch.hashBatch([header]).then(d=>{/* ignore async result in self-test */});
        h = this.hashStrategy.hashHeader(header); // keep parity path exercised
      } else {
        h = this.hashStrategy.hashHeader(header);
      }
      this.stats.hashes++;
      if (!(this.stats.hashes % 5000)) console.log('[HashTest]', this.hashStrategy.id, 'hashes=', this.stats.hashes, 'sample=', h.slice(0,16), 'econRec=', ECONSTATE.recommend || 'na');
  const { deriveInt } = require('./deterministic-util');
  const pseudo = deriveInt('fixed-prune', 3000, this.adaptivePrune.count||0, Date.now());
  this.adaptivePrune.record((pseudo/1000)+1, true); // deterministic pseudo metric
      this.adaptivePrune.maybeAdjust();
    }, 2).unref();
  }
  _initMetricsEndpoint(){
    if (process.env.METRICS_ENDPOINT === '0') return;
    let prom=null; try { prom=require('prom-client'); } catch(_){ return; }
    const http = require('http');
    const collectDefault = process.env.METRICS_DEFAULT !== '0';
    if (collectDefault){ try { prom.collectDefaultMetrics(); } catch(_){ } }
    // --- Hardware Auto-Detection (Raspberry Pi / BigTreeTech / Generic) ---
    this.hardwareInfo = { hardware:'generic', arch: process.arch, model: 'unknown' };
    try {
      const os = require('os');
      const fs = require('fs');
      const arch = os.arch();
      let model = 'unknown';
      if (fs.existsSync('/proc/device-tree/model')){
        try { model = fs.readFileSync('/proc/device-tree/model','utf8').trim(); } catch(_m){}
      } else if (fs.existsSync('/proc/cpuinfo')){
        try { const ci = fs.readFileSync('/proc/cpuinfo','utf8'); const mLine = ci.split('\n').find(l=>/^Model/.test(l)); if (mLine) model = mLine.split(':').slice(1).join(':').trim(); } catch(_c){}
      }
      let hardware='generic';
      const lowModel = (model||'').toLowerCase();
      if (/raspberry pi/.test(lowModel) || (arch.startsWith('arm') && fs.existsSync('/sys/firmware/devicetree/base/serial-number'))){ hardware='raspberry_pi'; }
      else if (/bigtree|big tree|btt/.test(lowModel)){ hardware='bigtreetech'; }
      else if (process.env.BTT_BOARD==='1'){ hardware='bigtreetech'; }
      this.hardwareInfo = { hardware, arch, model };
      if (!this._loggedHw){ console.log('[HWDetect]', this.hardwareInfo); this._loggedHw=true; }
    } catch(e){ console.warn('[HWDetect] failed', e.message); }
    const gauges = {
      hashes: new prom.Counter({ name:'aurrelia_hashes_total', help:'Total hashes (local count)' }),
      shares: new prom.Counter({ name:'aurrelia_shares_total', help:'Total shares submitted (accepted+rejected)' }),
      accRatio: new prom.Gauge({ name:'aurrelia_share_accept_ratio', help:'Share acceptance ratio' }),
      pruneThreshold: new prom.Gauge({ name:'aurrelia_prune_threshold', help:'Current adaptive prune threshold' }),
      pruneAttempts: new prom.Counter({ name:'aurrelia_prune_attempts_total', help:'Total prune attempts' }),
      econWalSize: new prom.Gauge({ name:'aurrelia_econ_wal_size_bytes', help:'Economic counters WAL current size in bytes' }),
      econWalBackups: new prom.Gauge({ name:'aurrelia_econ_wal_backups', help:'Number of compressed WAL backup files present' }),
      econWalRotations: new prom.Counter({ name:'aurrelia_econ_wal_rotations_total', help:'Total WAL rotations (compress+truncate) observed' }),
      econSwitchPath: new prom.Counter({ name:'aurrelia_econ_switch_total', help:'Total economic coin switches', labelNames:['from_coin','to_coin','reason'] }),
      econRollbackLabeled: new prom.Counter({ name:'aurrelia_econ_rollback_total', help:'Total economic rollbacks due to acceptance degradation', labelNames:['from_coin','to_coin'] })
    };
    // Octa spin bias gauge (global regardless of coin)
    try { gauges.octaSpinBias = new prom.Gauge({ name:'aurrelia_octa_spin_bias', help:'Current OctaLang aggregate spin bias (lower 32-bit value)' }); } catch(_){ }
    // Spin auto optimization gauges
    try {
      gauges.spinBestScore = new prom.Gauge({ name:'aurrelia_spin_best_score', help:'Best observed spin acceptance score' });
      gauges.spinCandidateIndex = new prom.Gauge({ name:'aurrelia_spin_candidate_index', help:'Current spin candidate index' });
      gauges.spinWindowShares = new prom.Gauge({ name:'aurrelia_spin_window_shares', help:'Shares in current spin evaluation window', labelNames:['type'] });
      gauges.spinEvalDuration = new prom.Histogram({ name:'aurrelia_spin_eval_duration_ms', help:'Spin evaluation duration ms', buckets:[1000,5000,15000,30000,60000,120000] });
      gauges.spinEvalShares = new prom.Histogram({ name:'aurrelia_spin_eval_window_total_shares', help:'Total shares per spin evaluation window', buckets:[1,2,4,8,12,20,40,80] });
      gauges.spinCandidateHashrate = new prom.Gauge({ name:'aurrelia_spin_candidate_hashrate_hs', help:'Measured hashes/sec for current candidate window' });
      gauges.spinPromoteFactor = new prom.Gauge({ name:'aurrelia_spin_dynamic_promote_factor', help:'Current adaptive promote factor threshold' });
      gauges.spinScoreVariance = new prom.Gauge({ name:'aurrelia_spin_score_variance', help:'Rolling variance of recent candidate scores' });
      gauges.spinCandidateJPerHash = new prom.Gauge({ name:'aurrelia_spin_candidate_j_per_hash', help:'Energy per hash (J/hash) for current candidate window' });
      gauges.spinEnergyEfficiency = new prom.Gauge({ name:'aurrelia_spin_energy_efficiency_factor', help:'Energy efficiency factor (normalized vs baseline)' });
      gauges.spinJPerHashDist = new prom.Histogram({ name:'aurrelia_spin_j_per_hash_distribution', help:'Distribution of J per hash per evaluation window', buckets:[1e-9,5e-9,1e-8,5e-8,1e-7,5e-7,1e-6,5e-6,1e-5] });
      gauges.spinWilsonOverlapMargin = new prom.Gauge({ name:'aurrelia_spin_wilson_overlap_margin', help:'Wilson interval overlap margin (candidate.low - best.high); >0 => non-overlap' });
      gauges.spinNormComposite = new prom.Gauge({ name:'aurrelia_spin_normalized_composite_score', help:'Normalized composite score (0-1 averaged component norms)' });
  gauges.spinAnomalyCount = new prom.Counter({ name:'aurrelia_spin_anomaly_total', help:'Total spin evaluation anomaly detections (z-threshold breaches)' });
  gauges.spinLastZScore = new prom.Gauge({ name:'aurrelia_spin_last_zscore', help:'Last computed z-score for normalized composite window' });
    } catch(_){ }
    // Expose metrics set for other subsystems
    this._metrics = Object.assign(this._metrics||{}, {
      frenRotationCounter: gauges.frenRotationCounter,
      frenRotationReason: gauges.frenRotationReason,
      spinEvalDuration: gauges.spinEvalDuration,
      spinEvalShares: gauges.spinEvalShares,
      spinJPerHashDist: gauges.spinJPerHashDist
    });
    // Wheel / Color spectral mining metrics (if wheel backend available globally)
    try {
      if (!gauges.color_phase_hist && global.AdvancedLanguageEngine){ /* avoid duplicate if restarted */ }
      // Create only once per process guard
      const coinLabel = this.selectedCoin || 'unknown';
      gauges.color_phase_hist = new prom.Histogram({
        name: 'wheel_color_phase_histogram',
        help: 'Distribution of spectral phase multipliers by color mood (electron bias)',
        labelNames: ['mood','tier','coin'],
        buckets: [0.5,1.0,1.5,2.0,2.5,3.0,Infinity]
      });
      gauges.wheel_encodes_counter = new prom.Counter({
        name: 'wheel_encodings_total',
        help: 'Total octagramal encodings by color / quantum operation',
        labelNames: ['color_emoji','quantum_op','coin']
      });
      gauges.aggregate_spin_gauge = new prom.Gauge({
        name: 'wheel_aggregate_spin_variance',
        help: 'Variance in aggregate electron spin (rolling window)',
        labelNames: ['coin']
      });
      gauges.verifier_calls_counter = new prom.Counter({
        name: 'wheel_verifier_calls_total',
        help: 'Batch verifier status counts aggregated',
        labelNames: ['status','coin']
      });
      gauges.verifier_latency_hist = new prom.Histogram({
        name: 'wheel_verifier_latency_ms',
        help: 'Batch verifier spawn+exec latency ms',
        labelNames: ['coin'],
        buckets: [50,100,200,400,800,1500,3000,6000,12000]
      });
      gauges.hwInfo = new prom.Gauge({ name:'aurrelia_hw_info', help:'Hardware info marker (value=1)', labelNames:['hardware','arch','model'] });
      gauges.aggregate_spin_gauge_hw = new prom.Gauge({ name:'wheel_aggregate_spin_variance_hw', help:'Aggregate spin variance by hardware', labelNames:['hardware','coin'] });
      this._lastWheelMetricsTs = Date.now();
      this._lastWheelSpinsSample = [];
      this._wheelSnapshotFile = process.env.AUR_WHEEL_SNAPSHOT_FILE || 'wheel-metrics.jsonl';
    } catch(e){ console.warn('[Metrics][WheelInit]', e.message); }
    // FREN-specific gauges
    if (this.selectedCoin==='fren'){
      gauges.frenAutogenSuccess = new prom.Gauge({ name:'fren_wallet_autogen_success', help:'FREN autogen success (1=success,0=not yet/failed)' });
      gauges.frenAutogenFail = new prom.Counter({ name:'fren_wallet_autogen_fail_total', help:'FREN wallet autogen failures total' });
      gauges.frenWalletRotationIndex = new prom.Gauge({ name:'fren_wallet_rotation_index', help:'Current index in FREN wallet rotation list' });
      gauges.frenWalletRotationTotal = new prom.Gauge({ name:'fren_wallet_addresses_total', help:'Total FREN wallet addresses loaded for rotation' });
      gauges.frenAutogenDuration = new prom.Gauge({ name:'fren_wallet_autogen_duration_ms', help:'Autogen duration ms (set after success)' });
      gauges.frenRotationCounter = new prom.Counter({ name:'fren_wallet_rotations_total', help:'Total FREN wallet rotations executed' });
      gauges.frenRotationReason = new prom.Counter({ name:'fren_wallet_rotation_reason_total', help:'FREN wallet rotations by reason', labelNames:['reason'] });
      gauges.coinDifficulty = new prom.Gauge({ name:'aurrelia_coin_difficulty', help:'Current coin difficulty estimate', labelNames:['coin'] });
    }
    // Periodic sync from internal counters
    setInterval(()=>{
      try {
        gauges.accRatio.set(this.shareStats.acceptanceRatio);
        gauges.pruneThreshold.set(this.adaptivePrune.state.threshold);
        // Economic WAL housekeeping (non-blocking)
        try { econRotateWalFixed(); } catch(_er){}
        // Refresh snapshot at most every 10s (independent of /self-check) for metrics
        if (Date.now() - __ECON_LAST_WAL_STAT_TS > 10000){ econRefreshWalSnapshot(); }
        // Export WAL gauges
        try {
          if (typeof __ECON_LAST_WAL_SIZE === 'number') gauges.econWalSize.set(__ECON_LAST_WAL_SIZE);
          if (typeof __ECON_LAST_BACKUPS === 'number') gauges.econWalBackups.set(__ECON_LAST_BACKUPS);
          if (this._lastWalRotationsProm == null) this._lastWalRotationsProm = 0;
          const rotDelta = __ECON_WAL_ROTATIONS - this._lastWalRotationsProm;
            if (rotDelta > 0){ gauges.econWalRotations.inc(rotDelta); this._lastWalRotationsProm = __ECON_WAL_ROTATIONS; }
        } catch(_wm){}
        // Tail economic event log for labeled switch/rollback metrics
        try {
          const fs = require('fs');
          const evFile = 'econ-events.jsonl';
          if (!this._econEventOffset) this._econEventOffset = 0;
          if (fs.existsSync(evFile)){
            const st = fs.statSync(evFile);
            if (st.size > this._econEventOffset){
              const fd = fs.openSync(evFile,'r');
              const len = st.size - this._econEventOffset;
              const buf = Buffer.alloc(len);
              fs.readSync(fd, buf, 0, len, this._econEventOffset); fs.closeSync(fd);
              this._econEventOffset = st.size;
              const lines = buf.toString('utf8').split(/\n/).filter(Boolean);
              for (const line of lines){
                try {
                  const ev = JSON.parse(line);
                  if (ev && ev.type === 'switch' && ev.from_coin && ev.to_coin){ gauges.econSwitchPath.inc({ from_coin: ev.from_coin, to_coin: ev.to_coin, reason: ev.reason || 'unknown' }); }
                  else if (ev && ev.type === 'rollback' && ev.from_coin && ev.to_coin){ gauges.econRollbackLabeled.inc({ from_coin: ev.from_coin, to_coin: ev.to_coin }); }
                } catch(_pe){}
              }
            }
          }
        } catch(_et){}
        // Add deltas
        const hDelta = this.stats.hashes - (this._lastHashesProm||0); if (hDelta>0) gauges.hashes.inc(hDelta); this._lastHashesProm = this.stats.hashes;
        const sTot = this.shareStats.accepted + this.shareStats.rejected; const sDelta = sTot - (this._lastSharesProm||0); if (sDelta>0) gauges.shares.inc(sDelta); this._lastSharesProm = sTot;
        const aDelta = this.adaptivePrune.state.attempts - (this._lastPruneAttempts||0); if (aDelta>0) gauges.pruneAttempts.inc(aDelta); this._lastPruneAttempts = this.adaptivePrune.state.attempts;
        if (this.selectedCoin==='fren'){
          if (this.frenAutogenMeta){
            gauges.frenAutogenSuccess.set(this.frenAutogenMeta.success?1:0);
            if (this.frenAutogenMeta.fail && !this._frenAutogenFailPromEmitted){ gauges.frenAutogenFail.inc(1); this._frenAutogenFailPromEmitted=true; }
            if (this.frenAutogenMeta.durationMs) gauges.frenAutogenDuration.set(this.frenAutogenMeta.durationMs);
          }
      gauges.frenWalletRotationIndex.set(this._frenWalletIndex||0);
            gauges.frenWalletRotationTotal.set(this.frenWallets? this.frenWallets.length : (process.env.FREN_WALLET?1:0));
      // Difficulty placeholder: future inject real difficulty
      try { if (gauges.coinDifficulty) gauges.coinDifficulty.set({ coin: this.selectedCoin }, ECONSTATE.difficulty || 0); } catch(_e){}
        }
        if (gauges.octaSpinBias && this.octaSpinBias != null) { try { gauges.octaSpinBias.set(this.octaSpinBias); } catch(_e){} }
        if (this._spinAutoState && this._spinAutoState.enabled){
          try {
            if (gauges.spinCandidateIndex) gauges.spinCandidateIndex.set(this._spinAutoState.candidateIndex||0);
            if (gauges.spinBestScore) gauges.spinBestScore.set(this._spinAutoState.bestScore||0);
            if (gauges.spinWindowShares){
              gauges.spinWindowShares.set({ type:'accepted' }, this._spinAutoState.windowShares.accepted||0);
              gauges.spinWindowShares.set({ type:'rejected' }, this._spinAutoState.windowShares.rejected||0);
              gauges.spinWindowShares.set({ type:'stale' }, this.shareStats.stale || 0);
              gauges.spinWindowShares.set({ type:'invalid' }, this.shareStats.invalid || 0);
            }
            if (gauges.spinCandidateHashrate && this._spinAutoState.windowHs){ gauges.spinCandidateHashrate.set(this._spinAutoState.windowHs); }
            if (gauges.spinPromoteFactor && this._spinAutoState.dynamicPromoteFactor){ gauges.spinPromoteFactor.set(this._spinAutoState.dynamicPromoteFactor); }
            if (gauges.spinScoreVariance && this._spinAutoState.scoreVariance!=null){ gauges.spinScoreVariance.set(this._spinAutoState.scoreVariance); }
            if (gauges.spinCandidateJPerHash && this._spinAutoState.windowJPerHash!=null){ gauges.spinCandidateJPerHash.set(this._spinAutoState.windowJPerHash); }
            if (gauges.spinEnergyEfficiency && this._spinAutoState.energyEfficiencyFactor!=null){ gauges.spinEnergyEfficiency.set(this._spinAutoState.energyEfficiencyFactor); }
            if (gauges.spinWilsonOverlapMargin && this._spinAutoState.lastWilson){
              const lw = this._spinAutoState.lastWilson; if (lw.candidate && lw.best){ const margin = (lw.candidate.low - lw.best.high); gauges.spinWilsonOverlapMargin.set(margin); }
            }
            if (gauges.spinNormComposite && this._spinAutoState.normComposite!=null){ gauges.spinNormComposite.set(this._spinAutoState.normComposite); }
          } catch(_m){}
        }
        // Wheel spectral metrics sync (every 30s loop already frequent; internal guard inside)
        try {
          if (!this._lastWheelSync || Date.now()-this._lastWheelSync > 30000){
            const wheelCoder = (global.__AUR_LANGUAGE_ENGINE__ && global.__AUR_LANGUAGE_ENGINE__.wheelCoder) || (global.AdvancedLanguageEngine && global.AdvancedLanguageEngine.wheelCoder) || null;
            if (wheelCoder && wheelCoder.colors && wheelCoder.colors.length){
              const recentColors = wheelCoder.colors.slice(-10);
              const coinLbl = this.selectedCoin||'unknown';
              recentColors.forEach(c=>{
                try {
                  const phase = c.frequency * (((c.wavelength?.[0]||1)+(c.wavelength?.[1]||1))/2 / (wheelCoder.divine_freq||1));
                  gauges.color_phase_hist.observe({ mood: c.mood||c.word||'unknown', tier: 'tier3', coin: coinLbl }, phase);
                  gauges.wheel_encodes_counter.inc({ color_emoji: c.emoji||'?', quantum_op: 'color', coin: coinLbl },1);
                } catch(_o){}
              });
              if (wheelCoder.quantum_last && Array.isArray(wheelCoder.quantum_last)){
                wheelCoder.quantum_last.forEach(q=>{ try { gauges.wheel_encodes_counter.inc({ color_emoji: q.color_entangled||'none', quantum_op: q.op||'unknown', coin: coinLbl },1); } catch(_q){} });
              }
              // Spin variance on rolling 100 spins
              if (wheelCoder.wheel_spins && wheelCoder.wheel_spins.length){
                const spins = wheelCoder.wheel_spins.slice(-100);
                if (spins.length>1){
                  const mean = spins.reduce((a,b)=>a+b,0)/spins.length;
                  const variance = spins.reduce((a,b)=> a + Math.pow(b-mean,2),0)/spins.length;
                  gauges.aggregate_spin_gauge.set({ coin: coinLbl }, variance);
                  if (gauges.aggregate_spin_gauge_hw && this.hardwareInfo){ try { gauges.aggregate_spin_gauge_hw.set({ hardware: this.hardwareInfo.hardware, coin: coinLbl }, variance); } catch(_ah){} }
                }
              }
            }
            // Verifier status counts (consumed & reset)
            if (global.__AUR_WHEEL_VERIFIER_COUNTS__){
              const counts = global.__AUR_WHEEL_VERIFIER_COUNTS__;
              ['secure','caution','critical','other'].forEach(k=>{ if (counts[k]>0){ try { gauges.verifier_calls_counter.inc({ status:k, coin: coinLbl }, counts[k]); } catch(_vc){} } });
              // reset after export to avoid double counting
              global.__AUR_WHEEL_VERIFIER_COUNTS__ = { secure:0,caution:0,critical:0,other:0 };
            }
            if (global.__AUR_WHEEL_VERIFIER_LAT__ && global.__AUR_WHEEL_VERIFIER_LAT__.length){
              const lats = global.__AUR_WHEEL_VERIFIER_LAT__.splice(0, global.__AUR_WHEEL_VERIFIER_LAT__.length);
              lats.forEach(ms=>{ try { gauges.verifier_latency_hist.observe({ coin: coinLbl }, ms); } catch(_lh){} });
            }
            // Hardware info gauge (constant 1, refreshed for liveness)
            if (gauges.hwInfo && this.hardwareInfo){ try { gauges.hwInfo.set({ hardware:this.hardwareInfo.hardware, arch:this.hardwareInfo.arch, model:this.hardwareInfo.model }, 1); } catch(_hi){} }
            // Snapshot persistence (JSONL)
            try {
              if (this._wheelSnapshotFile && wheelCoder && wheelCoder.colors){
                const snap = {
                  t: Date.now(),
                  coin: coinLbl,
                  variance: (()=>{ try { const v = gauges.aggregate_spin_gauge.get(); return v && v.values && v.values[0] ? v.values[0].value : null; } catch(_g){ return null; } })(),
                  colors: wheelCoder.colors.slice(-10).map(c=>({ e:c.emoji, m:c.mood, f:c.frequency, wl:c.wavelength })),
                  quantum: (wheelCoder.quantum_last||[]).map(q=>({ op:q.op, c:q.color_entangled })),
                  aggregate: (wheelCoder._lastEncoded && wheelCoder._lastEncoded.aggregate)||null
                };
                fs.appendFile(this._wheelSnapshotFile, JSON.stringify(snap)+'\n', ()=>{});
              }
            } catch(_snap){}
            this._lastWheelSync = Date.now();
          }
        } catch(e){ /* wheel metrics errors suppressed */ }
      } catch(_){ }
    }, 3000).unref();
    const port = parseInt(process.env.METRICS_PORT || '9310',10);
    http.createServer(async (req,res)=>{
      if (req.url === '/metrics'){
        try { const out = await prom.register.metrics(); res.writeHead(200,{ 'Content-Type':'text/plain' }); res.end(out); }
        catch(e){ res.writeHead(500); res.end('metrics error'); }
      } else if (req.url === '/health'){
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, since: this.startTime, coin: this.selectedCoin }));
      } else if (req.url === '/self-check') {
        // Refresh WAL snapshot at most every 5s to avoid IO spam
        if (Date.now() - __ECON_LAST_WAL_STAT_TS > 5000){ econRefreshWalSnapshot(); }
        const econ = __ECON_LAST_SNAP || {};
        const walSizeMb = __ECON_LAST_WAL_SIZE / (1024*1024);
        const body = {
          ok: true,
          coin: this.selectedCoin,
          uptime_s: Math.round((Date.now()-this.startTime)/1000),
          schema_version: __ECON_LOG_SCHEMA,
          econ: {
            switches_total: econ.switches_total || 0,
            switches_fail: econ.switches_fail || 0,
            rollbacks: econ.rollbacks || 0,
            active_coin: econ.active_coin || null,
            last_reason: econ.last_reason || null
          },
          wal: {
            size_bytes: __ECON_LAST_WAL_SIZE,
            size_mb: parseFloat(walSizeMb.toFixed(3)),
            max_size_bytes: __ECON_WAL_MAX_SIZE,
            backups: __ECON_LAST_BACKUPS,
            max_backups: __ECON_WAL_MAX_FILES
          }
        };
        res.writeHead(200,{ 'Content-Type':'application/json' }); res.end(JSON.stringify(body));
      } else { res.writeHead(404); res.end('not found'); }
    }).listen(port, ()=> console.log('[Metrics] Endpoint listening on', port,'/metrics'));
  }
}
// ---- FREN Address Validation (Base58Check + prefix) ----
function validateFrenAddress(addr){
  // Configurable expected prefix(s) via FREN_ADDR_PREFIX (comma separated), default 'F'
  const prefixes = (process.env.FREN_ADDR_PREFIX || 'F').split(',').map(p=>p.trim()).filter(Boolean);
  const prefixOk = prefixes.some(p=> addr.startsWith(p));
  if (!prefixOk) return false;
  // Base58Check like BTC / RVN
  const buf = b58decode(addr);
  if (buf.length < 4) return false;
  const payload = buf.slice(0,-4); const checksum = buf.slice(-4);
  const hash = crypto.createHash('sha256').update(crypto.createHash('sha256').update(payload).digest()).digest();
  return checksum.equals(hash.slice(0,4));
}

// Rotation helper
MinimalPipeline.prototype.rotateFrenAddress = function(reason){
  if (this.selectedCoin !== 'fren') return false;
  if (!this.frenWallets || this.frenWallets.length < 2) return false;
  this._frenWalletIndex = (this._frenWalletIndex + 1) % this.frenWallets.length;
  const newAddr = this.frenWallets[this._frenWalletIndex];
  if (!validateFrenAddress(newAddr)){
    console.warn('[FREN][Rotate] Skipped invalid address at index', this._frenWalletIndex);
    return false;
  }
  process.env.FREN_WALLET = newAddr;
  console.log('[FREN][Rotate] Switched to wallet index', this._frenWalletIndex, 'reason=', reason||'manual');
  // Automatic stratum reconnect with new worker identity
  if (this.stratum){
    try {
      const rigName = process.env.RIG_NAME || process.env.WORKER_NAME || 'Rig01';
      const newWorker = newAddr + '.' + rigName;
      if (this.stratum.close) { try { this.stratum.close(); } catch(_e){} }
      this._connectedAttempted = false; // allow reconnect gating logic if reused
      if (this.stratum.setWorker) { try { this.stratum.setWorker(newWorker); } catch(_e){} }
      console.log('[FREN][Rotate] Reconnecting stratum with worker', newWorker);
      setTimeout(()=>{ try { this.stratum.connect(); } catch(e){ console.error('[FREN][Rotate][ReconnectError]', e.message); } }, 250).unref();
    } catch(e){ console.warn('[FREN][Rotate] Reconnect sequence error', e.message); }
  }
  if (this._metrics && this._metrics.frenRotationCounter){ try { this._metrics.frenRotationCounter.inc(1); } catch(_e){} }
  if (this._metrics && this._metrics.frenRotationReason){ try { this._metrics.frenRotationReason.inc({ reason: reason||'unknown' }, 1); } catch(_e){} }
  // Persist rotation history
  try { fs.appendFileSync('fren-rotation-history.jsonl', JSON.stringify({ t:Date.now(), idx:this._frenWalletIndex, addr:newAddr, reason })+'\n'); } catch(_h){}
  return true;
};

// ---- FREN Wallet Decrypt Helper (AES-256-GCM) ----
function decryptFrenWalletEnc(vaultKeyRaw){
  try {
    if (!fs.existsSync('fren-wallet.enc')) return null;
    const encObj = JSON.parse(fs.readFileSync('fren-wallet.enc','utf8'));
    const key = crypto.createHash('sha256').update(vaultKeyRaw).digest();
    const iv = Buffer.from(encObj.iv,'hex');
    const ct = Buffer.from(encObj.ct,'base64');
    const tag = Buffer.from(encObj.tag,'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]).toString('utf8');
    return JSON.parse(pt);
  } catch(e){ console.warn('[FREN][Decrypt] Failed:', e.message); return null; }
}

// ---- CLI / API Control Channel ----
MinimalPipeline.prototype._initCliControl = function(){
  if (process.env.DISABLE_CLI_CTRL==='1') return;
  try {
    if (process.stdin.setEncoding) process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk=>{ chunk.split(/\n+/).map(l=>l.trim()).filter(Boolean).forEach(l=> this._handleCommand(l)); });
  } catch(_){ }
  if (process.env.CTRL_HTTP_PORT){
    try {
      const http = require('http');
      const port = parseInt(process.env.CTRL_HTTP_PORT,10);
      http.createServer(async (req,res)=>{
        if (req.method==='POST' && req.url==='/cmd'){
          const token = req.headers['x-ctrl-token'];
          if (process.env.CTRL_TOKEN && token !== process.env.CTRL_TOKEN){ res.writeHead(401); return res.end('unauthorized'); }
          let body=''; req.on('data',d=>body+=d); req.on('end',()=>{ const cmd=(body||'').trim(); const out=this._handleCommand(cmd,true); res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, cmd, out })); }); return;
        }
        res.writeHead(404); res.end('not found');
      }).listen(port, ()=> console.log('[CTRL] HTTP control listening on', port));
    } catch(e){ console.warn('[CTRL] HTTP init failed', e.message); }
  }
};

MinimalPipeline.prototype._handleCommand = function(line, silent){
  const parts = line.split(/\s+/); const cmd = parts[0]?.toLowerCase();
  if (!cmd) return;
  let resp='';
  switch(cmd){
    case 'rotate-fren':
      if (this.rotateFrenAddress('cli')) resp='rotated'; else resp='no-rotate';
      break;
    case 'show-fren-wallets':
      resp = { index: this._frenWalletIndex||0, wallets: this.frenWallets||[process.env.FREN_WALLET] };
      break;
    case 'decrypt-fren':
      {
        const key = process.env.FREN_VAULT_KEY || (process.env.FREN_VAULT_KEY_FILE && fs.existsSync(process.env.FREN_VAULT_KEY_FILE)? fs.readFileSync(process.env.FREN_VAULT_KEY_FILE,'utf8').trim(): null);
        if (!key) resp='no-key'; else resp = decryptFrenWalletEnc(key) || 'decrypt-failed';
      }
      break;
    case 'econ-recommend':
      resp = ECONSTATE.recommend || 'none';
      break;
    case 'optimize-income':
      this._runIncomeOptimizer && this._runIncomeOptimizer('cli');
      resp = 'optimizer-run';
      break;
    case 'kraken-export':
      // Usage: kraken-export SYMBOL AMOUNT ADDRESS
      {
        const sym = parts[1]; const amount = parseFloat(parts[2]||'0'); const address = parts[3];
        if (!sym || !address){ resp = 'usage: kraken-export SYMBOL AMOUNT ADDRESS'; break; }
        if (buildWithdrawal){ resp = buildWithdrawal(sym, address, amount); }
        else resp = 'exporter-missing';
      }
      break;
    case 'set-spin':
      if (parts[1] && /^[0-9a-fA-F]{4,64}$/.test(parts[1])){
        this.octaSpinBias = parseInt(parts[1].slice(0,8),16)>>>0; resp='spin-set-0x'+parts[1].slice(0,8);
        try { fs.writeFileSync('octa-spin.txt', parts[1].toLowerCase()); } catch(e){ console.warn('[OctaSpin] persist failed', e.message); }
      } else resp='usage: set-spin <hex>'; break;
    case 'spin-status':
      resp = this._spinAutoState ? { state: this._spinAutoState.phase, currentSpin: '0x'+(this.octaSpinBias!=null? this.octaSpinBias.toString(16).padStart(8,'0'):'null'), candidateIndex: this._spinAutoState.candidateIndex, bestScore: this._spinAutoState.bestScore, windowShares: this._spinAutoState.windowShares } : 'disabled';
      break;
    case 'spin-force':
      if (this._spinAutoState && this._spinAutoState.enabled){ this._spinAutoState.forceNext = true; resp='spin-force-queued'; } else resp='disabled';
      break;
    case 'spin-best':
      if (this._spinAutoState && this._spinAutoState.bestSpin!=null){
        resp = {
          bestSpin: '0x'+this._spinAutoState.bestSpin.toString(16).padStart(8,'0'),
          bestScore: this._spinAutoState.bestScore,
          variance: this._spinAutoState.scoreVariance,
          baselineHs: this._spinAutoState.baselineHs,
          baselineJPerHash: this._spinAutoState.baselineJPerHash||null,
          lastWilson: this._spinAutoState.lastWilson||null
        };
      }
      else resp='none';
      break;
    case 'spin-use-best':
      if (this._spinAutoState && this._spinAutoState.bestSpin!=null){ this.octaSpinBias = this._spinAutoState.bestSpin; try { fs.writeFileSync('octa-spin.txt', this.octaSpinBias.toString(16).padStart(8,'0')); } catch(_){} resp='applied-0x'+this.octaSpinBias.toString(16).padStart(8,'0'); }
      else resp='no-best';
      break;
    default:
      resp = 'unknown-cmd';
  }
  if (!silent) console.log('[CTRL][Resp]', cmd, typeof resp==='string'? resp : JSON.stringify(resp));
  return resp;
};

// ---- Income Optimization Scaffold ----
MinimalPipeline.prototype._initIncomeOptimizer = function(){
  if (process.env.DISABLE_INCOME_OPT==='1') return;
  const swapTargetList = (process.env.SWAP_CANDIDATES || 'usdt,btc').split(/[,\s]+/).filter(Boolean);
  const feeMax = parseFloat(process.env.MAX_SWAP_FEE_PCT || '0.3');
  this.walletPlatform = new WalletPlatform();
  this._runIncomeOptimizer = (origin)=>{
    const rec = ECONSTATE.recommend || this.selectedCoin.toUpperCase();
    const hr = this.stats.hashes ? this.stats.hashes / ((Date.now()-this.startTime)/1000 || 1) : 0;
    const hashRates = { [this.selectedCoin.toUpperCase()]: hr };
    const difficultyHints = {};
    return getPrices({ symbols: swapTargetList.concat([rec]) })
      .then(async prices => {
        const best = bestMiningTarget(prices, hashRates, difficultyHints) || { coin: rec, score:0 };
        console.log('[IncomeOpt]', { origin, rec, chosen: best.coin, score: best.score.toFixed(6), prices });
        if (this.walletPlatform && best.coin && !this.walletPlatform.list(best.coin).length){
          const addr = this.walletPlatform.deriveTempAddress(best.coin);
          console.log('[WalletPlatform] Derived temp address for', best.coin, addr);
        }
        if (this.trader && process.env.TRADING_ENABLED==='1'){
          try { const tradeRes = await this.trader.optimize(origin); if (tradeRes.swap) console.log('[Trading][Result]', tradeRes); } catch(e){ console.warn('[Trading][OptErr]', e.message); }
        }
        return best.coin;
      })
      .catch(e=>{ console.warn('[IncomeOpt] price fetch fail', e.message); return rec; });
  };
  const periodMs = parseInt(process.env.INCOME_OPT_INTERVAL_MS || '300000',10);
  setInterval(()=>{ try { this._runIncomeOptimizer('periodic'); } catch(e){ console.warn('[IncomeOpt] run error', e.message); } }, periodMs).unref();
};

// ---- Auto Spin Optimization Loop ----
MinimalPipeline.prototype._initAutoSpin = function(){
  if (process.env.DISABLE_SPIN_AUTO==='1') return; // allow disable
  const enable = process.env.SPIN_AUTO_ENABLED === '1';
  if (!enable){ this._spinAutoState = { enabled:false }; return; }
  // Configurable parameters
  const evalMs = parseInt(process.env.SPIN_EVAL_INTERVAL_MS || '60000',10); // per candidate evaluation window
  const minShares = parseInt(process.env.SPIN_MIN_WINDOW_SHARES || '4',10); // minimal shares before scoring
  const maxCandidates = parseInt(process.env.SPIN_MAX_CANDIDATES || '8',10);
  const strategy = (process.env.SPIN_CANDIDATE_STRATEGY||'xor-drift').toLowerCase(); // xor-drift | bitflip | rotate
  const basePromoteFactor = parseFloat(process.env.SPIN_PROMOTE_ACCEPT_RATIO || '0.05'); // base improvement threshold
  const pruneK = parseFloat(process.env.SPIN_SCORE_PRUNE_K || '0.2');
  const latK = parseFloat(process.env.SPIN_SCORE_LAT_K || '0.0');
  const energyK = parseFloat(process.env.SPIN_SCORE_ENERGY_K || '0.0'); // weighting for energy efficiency contribution
  const zMin = parseFloat(process.env.SPIN_PROMOTE_Z_MIN || '1.0'); // significance threshold
  const wilsonZ = parseFloat(process.env.SPIN_WILSON_Z || '1.96'); // z value for Wilson interval (default 95%)
  const wilsonMode = (process.env.SPIN_WILSON_MODE || 'two-sided').toLowerCase(); // 'two-sided' or 'one-sided'
  const guardMinShares = parseInt(process.env.SPIN_GUARD_MIN_SHARES || Math.max(minShares*2, 6),10);
  const halfLifeMs = parseInt(process.env.SPIN_SCORE_DECAY_HALF_LIFE_MS || (30*60*1000).toString(),10); // default 30m
  const reconfirmMs = parseInt(process.env.SPIN_RECONFIRM_INTERVAL_MS || (60*60*1000).toString(),10); // 1h
  // Internal state
  this._spinAutoState = {
    enabled:true,
    phase:'warmup',
    candidateIndex:0,
    candidates:[],
    bestSpin: this.octaSpinBias != null ? this.octaSpinBias : null,
    bestScore:0,
    bestRawAcceptance:0,
    bestEvalTs: Date.now(),
    lastEvalTs: Date.now(),
    windowStartShares: { accepted: this.shareStats.accepted, rejected: this.shareStats.rejected },
    windowShares: { accepted:0, rejected:0 },
  forceNext:false,
  recentScores:[],
  dynamicPromoteFactor: basePromoteFactor,
  cooldownActive:false,
  windowHs:0,
  scoreVariance:null
  };
  const st = this._spinAutoState;
  st.jPerHashHistory = [];
  st.componentHistory = []; // stores {accept, penalty, prune, latency, energy}
  const compHistoryMax = parseInt(process.env.SPIN_COMPONENT_HISTORY_MAX || '64',10);
  const jHistoryMax = parseInt(process.env.SPIN_JPH_HISTORY_MAX || '50',10);
  const jouleStaleMs = parseInt(process.env.POWER_J_TOTAL_STALE_MS || '15000',10); // 15s default staleness
  st.baselinePrune = this.adaptivePrune && this.adaptivePrune.state ? this.adaptivePrune.state.threshold : null;
  st.lastCandidateStartTs = Date.now();
  // Helper: generate candidate spin integers
  const genCandidate = ()=>{
  const { deriveBuffer, deriveInt } = require('./deterministic-util');
  let base = st.bestSpin != null ? st.bestSpin : (this.octaSpinBias!=null? this.octaSpinBias : deriveBuffer('fixed-spin',4,this.octaSpinBias||0,this.spinSet||0).readUInt32LE(0));
    // Optional: derive from language engine OctaLang snippet when available
    try {
      const snippetPath = process.env.OCTA_SPIN_SNIPPET_FILE;
      const inlineSnippet = process.env.OCTA_SPIN_SNIPPET;
      if ((snippetPath && fs.existsSync(snippetPath)) || inlineSnippet){
        let code = inlineSnippet || fs.readFileSync(snippetPath,'utf8');
        // Lazy load bridge or language engine if present
        let engine=null;
        try { engine = require('./language-engine.js'); } catch(_e){}
        if (engine && engine.prototype && engine.prototype.computeOctaSpin){
          const inst = new engine();
          if (inst.computeOctaSpin){
            // computeOctaSpin returns promise
            const p = inst.computeOctaSpin(code);
            // We cannot block; but we can opportunistically update base synchronously later via then
            p.then(res=>{ if (res && res.aggregate_spin){ base = parseInt(res.aggregate_spin.slice(0,8),16)>>>0; } }).catch(()=>{});
          }
        }
      }
    } catch(_lang){ }
    let cand;
    switch(strategy){
  case 'bitflip': { const bit = deriveInt('fixed-bitflip',32,base,this.spinSet||0); cand = base ^ (1<<bit); break; }
      case 'rotate': cand = ((base << 1) | (base >>> 31)) >>> 0; break;
      case 'xor-drift':
  default: cand = (base ^ deriveBuffer('fixed-xor',4,base,this.spinSet||0).readUInt32LE(0)) >>> 0; break;
    }
    return cand >>> 0;
  };
  // Pre-seed candidates list
  for (let i=0;i<maxCandidates;i++){ st.candidates.push(genCandidate()); }
  // Evaluation loop
  const evalLoop = ()=>{
    try {
  const now = Date.now();
      const totalAccepted = this.shareStats.accepted; const totalRejected = this.shareStats.rejected;
  const totalHashes = this.stats.hashes;
      // Update window shares
      st.windowShares.accepted = totalAccepted - st.windowStartShares.accepted;
      st.windowShares.rejected = totalRejected - st.windowStartShares.rejected;
      const windowTotal = st.windowShares.accepted + st.windowShares.rejected;
      const windowAccRatio = windowTotal>0 ? st.windowShares.accepted / windowTotal : 0;
      const elapsed = now - st.lastEvalTs;
      const timeReady = elapsed >= evalMs;
      const sharesReady = windowTotal >= minShares;
      if ((timeReady && sharesReady) || st.forceNext){
        const evalDuration = now - st.lastCandidateStartTs;
        const currentSpin = this.octaSpinBias;
        // Measure hash rate for this window
        const windowHashes = totalHashes - (st.windowStartHashes || 0);
        st.windowHs = evalDuration>0 ? windowHashes / (evalDuration/1000) : 0;
        // Energy telemetry with provenance & staleness
        let energyJ = null; let energySource = null;
        const jouleFile = process.env.POWER_J_TOTAL_FILE;
        if (jouleFile && fs.existsSync(jouleFile)){
          try {
            const jRaw = parseFloat((fs.readFileSync(jouleFile,'utf8')||'').trim());
            if (!isNaN(jRaw)){
              if (st._lastJouleReading != null){ const deltaJ = jRaw - st._lastJouleReading; if (deltaJ >= 0) { energyJ = deltaJ; energySource='joule'; } }
              st._lastJouleReading = jRaw; st._lastJouleFileTs = Date.now();
            }
          } catch(_jf){}
        }
        if (energyJ == null && jouleFile){
          if (!(st._lastJouleFileTs && (Date.now()-st._lastJouleFileTs) < jouleStaleMs)){
            const w = parseFloat(process.env.POWER_WATTS || '0'); if (!isNaN(w) && w>0){ energyJ = w * (evalDuration/1000); energySource='watts-fallback'; }
          }
        }
        if (energyJ == null){
          const w = parseFloat(process.env.POWER_WATTS || '0'); if (!isNaN(w) && w>0){ energyJ = w * (evalDuration/1000); energySource = energySource||'watts'; }
        }
        if (energyJ != null){
          let rawJph = (windowHashes>0)? energyJ / windowHashes : null;
          if (rawJph!=null){
            st.jPerHashHistory.push(rawJph); if (st.jPerHashHistory.length>jHistoryMax) st.jPerHashHistory.shift();
            const medianArr = [...st.jPerHashHistory].sort((a,b)=>a-b); const median = medianArr[Math.floor(medianArr.length/2)] || rawJph;
            if (median>0 && rawJph > median*3) rawJph = median;
            st.windowJPerHash = rawJph;
          } else st.windowJPerHash = null;
          if (st.windowJPerHash!=null){
            if (!st.baselineJPerHash || st.baselineJPerHash<=0) st.baselineJPerHash = st.windowJPerHash;
            st.energyEfficiencyFactor = Math.min(st.baselineJPerHash / st.windowJPerHash, 2);
            if (this._metrics && this._metrics.spinJPerHashDist){ try { this._metrics.spinJPerHashDist.observe(st.windowJPerHash); } catch(_o){} }
          }
        } else { st.windowJPerHash = null; st.energyEfficiencyFactor = null; }
        // Compute prune improvement metric
        let pruneImprovement = 0;
        if (st.baselinePrune && this.adaptivePrune && this.adaptivePrune.state){
          const cur = this.adaptivePrune.state.threshold;
            if (cur>0) pruneImprovement = (st.baselinePrune - cur) / st.baselinePrune; // positive if threshold reduced (more aggressive?)
        }
        // Latency / efficiency metric now based on hashes per second relative to moving baseline
        if (!st.baselineHs || st.baselineHs < 1){ st.baselineHs = st.windowHs || 1; }
        const latencyFactor = st.windowHs > 0 ? Math.min(st.windowHs / st.baselineHs, 2) / 2 : 0; // normalize 0..1 (cap 2x)
        // Composite score
        // Rejection penalties (weight stale lower than invalid)
        const staleDelta = (this.shareStats.stale - (st.windowStartStale||0));
        const invalidDelta = (this.shareStats.invalid - (st.windowStartInvalid||0));
        const rejectionPenalty = windowTotal>0 ? ((staleDelta*0.5) + (invalidDelta*1.0)) / (windowTotal + 1) : 0;
        const energyFactorTerm = (st.energyEfficiencyFactor!=null)? (energyK * (st.energyEfficiencyFactor/2)) : 0; // normalize 0..1 (since efficiency factor capped 2 -> /2)
  const comp_accept = windowAccRatio;
  const comp_penalty = -rejectionPenalty;
  const comp_prune = pruneK * pruneImprovement;
  const comp_lat = latK * latencyFactor;
  const comp_energy = energyFactorTerm;
        const compositeScore = comp_accept + comp_penalty + comp_prune + comp_lat + comp_energy;
        // Store component history for local adaptive context
        st.componentHistory.push({ accept:comp_accept, penalty:comp_penalty, prune:comp_prune, latency:comp_lat, energy:comp_energy });
        if (st.componentHistory.length>compHistoryMax) st.componentHistory.shift();
        // Persistent normalization state (min/max across restarts)
        if (!st._normStateLoaded){
          try { const raw = fs.readFileSync('spin-norm-state.json','utf8'); st.normStats = JSON.parse(raw); } catch(_n){ /* first run */ }
          if (!st.normStats) st.normStats = {}; st._normStateLoaded = true; st._normPersistCounter=0;
        }
        const updateNorm = (key,value)=>{
          if (!st.normStats[key]) st.normStats[key] = { min:value, max:value };
          if (value < st.normStats[key].min) st.normStats[key].min = value;
          if (value > st.normStats[key].max) st.normStats[key].max = value;
          const {min,max} = st.normStats[key];
            if (max===min) return 0.5;
          return (value - min)/(max - min);
        };
        const normAccept = updateNorm('accept', comp_accept);
        const normPenalty = updateNorm('penalty', comp_penalty);
        const normPrune = updateNorm('prune', comp_prune);
        const normLatency = updateNorm('latency', comp_lat);
        const normEnergy = updateNorm('energy', comp_energy);
        // Periodic persistence of normalization state (every 20 evaluations)
        st._normPersistCounter = (st._normPersistCounter||0) + 1;
        if (st._normPersistCounter % 20 === 0){ try { fs.writeFileSync('spin-norm-state.json', JSON.stringify(st.normStats)); } catch(_pw){} }
        // Decay existing best score
        const decayDt = now - st.bestEvalTs;
        const decayFactor = halfLifeMs>0 ? Math.pow(0.5, decayDt / halfLifeMs) : 1;
        const decayedBestScore = st.bestScore * decayFactor;
        // Rolling score variance for adaptive promote factor
        st.recentScores.push(compositeScore);
        if (st.recentScores.length > 32) st.recentScores.shift();
        const mean = st.recentScores.reduce((a,b)=>a+b,0)/st.recentScores.length;
        const variance = st.recentScores.reduce((a,b)=>a+Math.pow(b-mean,2),0)/st.recentScores.length;
        st.scoreVariance = variance;
        // Adjust promote factor: higher variance -> raise threshold, lower variance -> reduce slightly
        const varNorm = Math.min(Math.max(variance, 0), 0.25) / 0.25; // clamp 0..1 for variance up to 0.25
        st.dynamicPromoteFactor = basePromoteFactor * (0.5 + varNorm); // ranges from 0.5x to 1.5x base
        // Cooldown if variance very high to prevent churn
        const highVar = variance > 0.15;
        if (highVar && !st.cooldownActive){ st.cooldownActive = true; st.cooldownUntil = now + Math.min(evalMs*3, 180000); }
        if (st.cooldownActive && now > (st.cooldownUntil||0)){ st.cooldownActive=false; }
        // Statistical guardrails
        let promote = false; let why='';
        if (windowTotal < guardMinShares){ why='insufficient-shares'; }
        else if (st.cooldownActive){ why='cooldown'; }
        else {
          // Wilson interval significance: compute lower bound for candidate and upper bound for best; promote if no overlap and score improved
          const n1 = windowTotal; const p1 = windowAccRatio; // candidate
          const n0 = st.bestSampleN || guardMinShares; const p0 = st.bestRawAcceptance || 0; // best so far
          const z = wilsonZ; // chosen confidence level
          const wilson = (p,n)=>{
            if (n===0) return { low:0, high:0 };
            if (wilsonMode==='one-sided'){
              // lower confidence bound one-sided using z
              const denom = 1 + (z*z)/(2*n);
              const low = (p + (z*z)/(2*n) - z*Math.sqrt((p*(1-p))/n + (z*z)/(4*n*n)))/denom;
              return { low: Math.max(0, low), high: 1 };
            }
            const denom = 1 + (z*z)/n;
            const center = p + (z*z)/(2*n);
            const margin = z*Math.sqrt((p*(1-p) + (z*z)/(4*n))/n);
            const low = Math.max(0,(center - margin)/denom);
            const high = Math.min(1,(center + margin)/denom);
            return { low, high };
          };
          const cInt = wilson(p1,n1); const bInt = wilson(p0,n0);
          const nonOverlap = cInt.low > bInt.high; // candidate statistically better
          if (compositeScore > decayedBestScore + st.dynamicPromoteFactor && (nonOverlap || (p1>p0 && (cInt.low - bInt.high) > 0))){ promote=true; why='score+wilson'; }
          else why = 'score/wilson-not-met';
          st.lastWilson = { candidate: cInt, best: bInt, p1, p0, n1, n0 };
        }
        // Reconfirmation: if best aged past reconfirmMs, allow promote of same spin if performs similar
        if (!promote && (now - st.bestEvalTs) > reconfirmMs && windowAccRatio >= (st.bestRawAcceptance - st.dynamicPromoteFactor/2)){
          promote = true; why = 'reconfirm-aged';
        }
  // Persist logic learning nodes file (pc storage) summarizing key normalized metrics for ML ingestion
  // Normalized composite & anomaly detection additions
  st.normComposite = (normAccept+normPenalty+normPrune+normLatency+normEnergy)/5;
  // Load recentComposite once from disk for continuity
  if (!st._recentCompositeLoaded){
    try { const raw=fs.readFileSync('spin-recent-composite.json','utf8'); const arr=JSON.parse(raw); if (Array.isArray(arr)) st.recentComposite = arr.slice(-100); } catch(_rc){}
    st._recentCompositeLoaded=true;
  }
  st.recentComposite = st.recentComposite || []; st.recentComposite.push(st.normComposite); if (st.recentComposite.length>100) st.recentComposite.shift();
  // Periodically persist (every 10 updates)
  st._recentCompositePersistCounter = (st._recentCompositePersistCounter||0)+1; if (st._recentCompositePersistCounter % 10 === 0){ try { fs.writeFileSync('spin-recent-composite.json', JSON.stringify(st.recentComposite)); } catch(_pw){} }
  let anomalyFlag=0; let zScore=0;
  if (st.recentComposite.length>=10){ const m = st.recentComposite.reduce((a,b)=>a+b,0)/st.recentComposite.length; const v = st.recentComposite.reduce((a,b)=>a+Math.pow(b-m,2),0)/st.recentComposite.length; const sd=Math.sqrt(v)||1; zScore=(st.normComposite-m)/sd; const thr=parseFloat(process.env.SPIN_ANOM_Z_THRESH||'2.5'); if (Math.abs(zScore)>=thr){ anomalyFlag=1; if (this._metrics && this._metrics.spinAnomalyCount) try{ this._metrics.spinAnomalyCount.inc(); }catch(_){} } if (this._metrics && this._metrics.spinLastZScore) try { this._metrics.spinLastZScore.set(zScore); } catch(_z){} }
  const logicNode = { t:now, spin: currentSpin>>>0, norm:{ accept:normAccept, penalty:normPenalty, prune:normPrune, latency:normLatency, energy:normEnergy, composite: st.normComposite }, raw:{ accept:comp_accept, penalty:comp_penalty, prune:comp_prune, latency:comp_lat, energy:comp_energy }, jPerHash: st.windowJPerHash, eff: st.energyEfficiencyFactor, energySource, anomaly: anomalyFlag, zScore };
  if (anomalyFlag){
    logicNode.suggestion = { action:'diagnostic_probe', reason:'normalized_composite_z_anomaly', zScore, recommendation:{ adjust_prune_threshold: zScore>0? -0.01: 0.01, reeval_latency: true, capture_window: 3 } };
  }
  try { fs.appendFileSync('spin-eval-logic-nodes.jsonl', JSON.stringify(logicNode)+'\n'); } catch(_ln){}
  try { fs.appendFileSync('spin-eval-history.jsonl', JSON.stringify({ t:now, spin:'0x'+currentSpin.toString(16).padStart(8,'0'), compositeScore, components:{ accept:comp_accept, penalty:comp_penalty, prune:comp_prune, latency:comp_lat, energy:comp_energy }, norm:{ accept:normAccept, penalty:normPenalty, prune:normPrune, latency:normLatency, energy:normEnergy, composite: st.normComposite }, acceptance: windowAccRatio, pruneImprovement, latencyFactor, energyFactor: energyFactorTerm, jPerHash: st.windowJPerHash, energyEff: st.energyEfficiencyFactor, energySource, stale: staleDelta, invalid: invalidDelta, penalty: rejectionPenalty, windowHs: st.windowHs, baseHs: st.baselineHs, variance, dynPromote: st.dynamicPromoteFactor, accepted: st.windowShares.accepted, rejected: st.windowShares.rejected, elapsed: evalDuration, decayedBest: decayedBestScore, promote, why, cooldown: st.cooldownActive, wilson: st.lastWilson, anomaly: anomalyFlag, zScore })+'\n'); } catch(_h){}
        if (promote){
          st.bestScore = compositeScore; st.bestSpin = currentSpin; st.bestEvalTs = now; st.bestRawAcceptance = windowAccRatio; st.bestSampleN = windowTotal; st.phase='improved';
          console.log('[SpinAuto][Promote]', why, 'spin=0x'+currentSpin.toString(16).padStart(8,'0'),'score=', compositeScore.toFixed(4),'acc=',windowAccRatio.toFixed(4),'pruneΔ=',pruneImprovement.toFixed(4),'lat=',latencyFactor.toFixed(3));
          try { fs.writeFileSync('octa-spin-best.txt', currentSpin.toString(16).padStart(8,'0')); } catch(_p){}
          // Export best snapshot JSON with variance & baselines
          try {
            const snap = {
              t: now,
              spin: '0x'+currentSpin.toString(16).padStart(8,'0'),
              score: compositeScore,
              components:{ accept:comp_accept, penalty:comp_penalty, prune:comp_prune, latency:comp_lat, energy:comp_energy },
              normComponents:{ accept:normAccept, penalty:normPenalty, prune:normPrune, latency:normLatency, energy:normEnergy, composite: st.normComposite },
              acceptance: windowAccRatio,
              sampleShares: windowTotal,
              pruneImprovement,
              latencyFactor,
              energyFactor: energyFactorTerm,
              jPerHash: st.windowJPerHash,
              energyEff: st.energyEfficiencyFactor,
              energySource,
              anomaly: anomalyFlag,
              zScore,
              baselineHs: st.baselineHs,
              baselineJPerHash: st.baselineJPerHash||null,
              variance,
              promoteReason: why,
              wilson: st.lastWilson || null
            };
            fs.writeFileSync('octa-spin-best-snapshot.json', JSON.stringify(snap,null,2));
          } catch(_s){}
          // Update baseline hash rate after promotion to reflect improved reference
          st.baselineHs = st.windowHs>0 ? (st.baselineHs*0.5 + st.windowHs*0.5) : st.baselineHs;
          // Update baseline energy efficiency if available
            if (st.windowJPerHash!=null){ st.baselineJPerHash = (st.baselineJPerHash && st.baselineJPerHash>0)? (st.baselineJPerHash*0.7 + st.windowJPerHash*0.3) : st.windowJPerHash; }
        }
        // Metrics histograms
        try {
          if (this._metrics && this._metrics.spinEvalDuration) this._metrics.spinEvalDuration.observe(evalDuration);
        } catch(_){}
        try {
          if (this._metrics && this._metrics.spinEvalShares) this._metrics.spinEvalShares.observe(windowTotal);
        } catch(_){}
        // Advance to next candidate
        st.candidateIndex = (st.candidateIndex + 1) % st.candidates.length;
        if (st.candidateIndex===0){
          // Regenerate new cohort except preserve best
            const preserved = st.bestSpin;
            st.candidates = [];
            for (let i=0;i<maxCandidates;i++) st.candidates.push(genCandidate());
            if (preserved != null) st.candidates[0] = preserved; // ensure best always re-tested first slot
            console.log('[SpinAuto] Regenerated candidates cohort');
        }
        const nextSpin = st.candidates[st.candidateIndex];
        this.octaSpinBias = nextSpin >>> 0;
        try { fs.writeFileSync('octa-spin.txt', nextSpin.toString(16).padStart(8,'0')); } catch(_e){}
        st.lastEvalTs = now; st.lastCandidateStartTs = now; st.windowStartShares = { accepted: totalAccepted, rejected: totalRejected }; st.windowShares = { accepted:0, rejected:0 }; st.windowStartHashes = totalHashes; st.windowStartStale = this.shareStats.stale; st.windowStartInvalid = this.shareStats.invalid; st.forceNext=false; st.phase='evaluating';
        if (!(totalAccepted % 10)) console.log('[SpinAuto] Switched to candidate index', st.candidateIndex, 'spin=0x'+nextSpin.toString(16).padStart(8,'0'));
      }
    } catch(e){ console.warn('[SpinAuto] Loop error', e.message); }
    setTimeout(evalLoop, 2000).unref(); // light-weight tick
  };
  // Initialize first candidate spin if none
  if (this.octaSpinBias == null){ this.octaSpinBias = st.candidates[0]; }
  console.log('[SpinAuto] Enabled with', st.candidates.length, 'candidates; evalMs=', evalMs,'minShares=', minShares,'strategy=', strategy);
  evalLoop();
};

// ---- Ravencoin Base58Check Validation (lightweight) ----
const _B58_ALPH = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function b58decode(str){
  let num = BigInt(0); const base = BigInt(58);
  for (const ch of str){
    const idx = _B58_ALPH.indexOf(ch); if (idx<0) throw new Error('invalid char');
    num = num * base + BigInt(idx);
  }
  // Convert BigInt to buffer
  let bytes=[]; while(num>0){ bytes.push(Number(num & BigInt(0xff))); num >>= BigInt(8); }
  bytes = bytes.reverse();
  // Leading zeros carry over as '1' chars in Base58
  let leading=0; for (const c of str){ if (c==='1') leading++; else break; }
  if (leading){ bytes = Array(leading).fill(0).concat(bytes); }
  return Buffer.from(bytes);
}
function validateRvnAddress(addr){
  // Ravencoin uses same Base58Check as Bitcoin with version byte 0x3c (R = 60) or similar; accept any version for now but enforce checksum
  const buf = b58decode(addr);
  if (buf.length < 4) return false;
  const payload = buf.slice(0,-4); const checksum = buf.slice(-4);
  const hash = require('crypto').createHash('sha256').update(require('crypto').createHash('sha256').update(payload).digest()).digest();
  return checksum.equals(hash.slice(0,4));
}

// ---- Litecoin Base58Check Validation ----
function validateLtcAddress(addr){
  // Accept legacy Base58 & bech32 (ltc1...) simple pattern. Full bech32 checksum not implemented here.
  if (/^ltc1[0-9ac-hj-np-z]{20,}$/i.test(addr)) return true; // structural acceptance; deeper bech32m check could be added
  const buf = b58decode(addr);
  if (buf.length < 4) return false;
  const payload = buf.slice(0,-4); const checksum = buf.slice(-4);
  const hash = require('crypto').createHash('sha256').update(require('crypto').createHash('sha256').update(payload).digest()).digest();
  if (!checksum.equals(hash.slice(0,4))) return false;
  const version = payload[0];
  // Common LTC version bytes: 0x30 (L addresses P2PKH), 0x32 (M addresses P2SH wrapped segwit), 0x05 also seen historically.
  if ([0x30,0x32,0x05].includes(version)) return true;
  return false;
}

if (!module.parent){
  console.log('[Aurrelia][Fixed][Modular] Minimal miner starting (btc/rvn/fren)');
  const pipeline = new MinimalPipeline();
  global.__AUR_PIPELINE__ = pipeline;
  if (process.env.WORKERS === '1' || process.env.WORKER_CHILD === '1'){
    // Activate full mining loop (adaptive prune + fused batch)
    startMining(pipeline);
  }
}

module.exports = { HASH_STRATEGIES, ECONSTATE };
