// aurrelia-self-optimizing-miner.js
// Aurrelia.AI: Self-optimizing, self-learning mining pipeline for F2Pool
// Author: Wilsonof Orange + GitHub Copilot

const Stratum = require('stratum-client');
const sha256 = require('js-sha256');
const BigIntBuffer = require('bigint-buffer');
// Triad parity integration
let CoderTriad = null;
try { ({ CoderTriad } = require('./seraphina-coder-triad')); } catch(_e){ /* triad optional */ }

// Simple Deterministic Octo (no random)
function hashToOctonion(dataStr) {
  let hash = 0;
  for (let i = 0; i < dataStr.length; i++) {
    hash = ((hash << 5) - hash) + dataStr.charCodeAt(i);
    hash |= 0;
  }
  const coeffs = [];
  for (let i = 0; i < 8; i++) {
    const chunk = (hash >>> (i * 4)) & 0xFFFF;
    coeffs.push((chunk % 10000 / 5000 - 1));
  }
  return { coeffs };
}

class SimpleOcto {
  constructor(coeffs) { this.coeffs = coeffs; }
  norm() { return Math.sqrt(this.coeffs.reduce((s, c) => s + c * c, 0)); }
  add(other) { return new SimpleOcto(this.coeffs.map((c, i) => c + other.coeffs[i])); }
  multiply(other) {
    const prod = new Array(8).fill(0);
    prod[0] = this.coeffs[0] * other.coeffs[0] - this.coeffs.slice(1).reduce((s, c, i) => s + c * other.coeffs[i + 1], 0);
    for (let i = 1; i < 8; i++) prod[i] = this.coeffs[0] * other.coeffs[i] + other.coeffs[0] * this.coeffs[i];
    return new SimpleOcto(prod);
  }
  power(d = 2) { return d === 2 ? this.multiply(this) : this; }
}

class AurreliaNode {
  constructor(id) {
    this.octo = new SimpleOcto(hashToOctonion(`node${id}`).coeffs);
    this.freq = 432;
    this.successes = 0;
    this.attempts = 0;
  }
  generateNonce(seedStr) {
    const c = new SimpleOcto(hashToOctonion(seedStr).coeffs);
    const theta = 2 * Math.PI * (this.freq / 432);
    let z = new SimpleOcto([0, 0, 0, 0, 0, 0, 0, 0]);
    z = z.power(2).add(c.multiply(new SimpleOcto([Math.cos(theta), Math.sin(theta), 0, 0, 0, 0, 0, 0])));
    z = z.power(2).add(c);
    const nonce = Math.floor(Math.abs(z.coeffs[0]) * 0xFFFFFFFF) >>> 0;
    return { nonce, norm: z.norm() };
  }
  verifyNonce(nonceStr, seedStr) {
    const c = new SimpleOcto(hashToOctonion(seedStr + nonceStr).coeffs);
    const theta = 2 * Math.PI * (this.freq / 432);
    let z = new SimpleOcto([0, 0, 0, 0, 0, 0, 0, 0]);
    for (let i = 0; i < 50; i++) {
      z = z.power(2).add(c.multiply(new SimpleOcto([Math.cos(8 * theta * i), Math.sin(8 * theta * i), 0, 0, 0, 0, 0, 0])));
      if (z.norm() > 2) return { valid: false, norm: z.norm() };
    }
    return { valid: true, norm: z.norm() };
  }
  feedback(success) {
    this.attempts++;
    if (success) this.successes++;
    // Self-optimize: if success rate drops, sweep freq
    if (this.attempts % 32 === 0) {
      const rate = this.successes / this.attempts;
      if (rate < 0.01) {
        // Deterministic sweep: hash previous freq + attempts count
        const crypto = require('crypto');
        const h = crypto.createHash('sha256').update(String(this.freq) + String(this.attempts)).digest('hex');
        const delta = parseInt(h.slice(0, 4), 16) % 96; // 0..95
        this.freq = 432 + delta; // 432-527 inclusive
      }
      this.successes = 0;
      this.attempts = 0;
    }
  }
}

const lattice = Array.from({ length: 512 }, (_, i) => new AurreliaNode(i));
// Optional share acceptance oracle (logistic) if weights present
let __SHARE_ORACLE__ = null;
try { const { ShareOracle } = require('./share-oracle-infer'); __SHARE_ORACLE__ = new ShareOracle(); if(__SHARE_ORACLE__.loaded) console.log('[SHARE-ORACLE] Loaded weights'); } catch(_e){ /* ignore */ }

class RealSHAMiner {
  constructor(blob, target) {
    this.blob = blob;
    this.target = BigInt('0x' + target);
  }
  tryNonce(nonce) {
    const nonceHex = nonce.toString(16).padStart(8, '0');
    const fullBlob = this.blob.slice(0, 152) + nonceHex + this.blob.slice(160);
    const hash1 = sha256(fullBlob);
    const hash2 = sha256(hash1);
    const hashBuf = Buffer.from(hash2, 'hex').reverse();
    const hashInt = BigIntBuffer.toBigInt(hashBuf);
    return { meetsTarget: hashInt <= this.target, nonce: nonceHex };
  }
}

class F2PoolAurreliaPipeline {
  constructor(user) {
    this.stratum = new Stratum({ host: 'stratum.f2pool.com', port: 3333, user, pass: 'x' });
    this.job = null;
    this.miner = null;
    this.currentNonce = 0;
    this.stats = { hashes: 0, shares: 0, ths: 0 };
    this.startTime = Date.now();
    this.shareLedgerPath = 'aurrelia-shares-ledger.jsonl';
    this.triadAuditPaths = (process.env.AUR_TRIAD_AUDIT_PATHS || '').split(',').filter(Boolean);
    this.triad = CoderTriad ? new CoderTriad({ seed: process.env.AUR_TRIAD_SEED || 'aurrelia-triad-seed' }) : null;
    this.triadLastDigests = new Map();
    this.setup();
  }

  setup() {
    this.stratum.on('connect', () => console.log('Connected to F2Pool'));
    this.stratum.on('job', (job) => {
      this.job = job;
      this.miner = new RealSHAMiner(job.blob, job.target);
      this.currentNonce = job.clean ? 0 : this.currentNonce;
      console.log(`Job ${job.jobId}, D=${job.difficulty}, starting at ${this.currentNonce.toString(16)}`);
    });
    this.stratum.on('submit', (res) => {
      if (res) {
        this.stats.shares++;
        console.log(`✅ Accepted: ${res.nonce}`);
      } else console.log(`❌ Rejected: ${res.nonce}`);
    });
    this.stratum.connect();
  }

  start() {
    this.cycle();
  }

  appendShareEntry(entry){
    try {
      const fs = require('fs');
      const crypto = require('crypto');
      const base = JSON.stringify(entry);
      const digest = crypto.createHash('sha256').update(base).digest('hex');
      fs.appendFileSync(this.shareLedgerPath, JSON.stringify({ ...entry, digest })+'\n');
    } catch(e){ /* non-fatal */ }
  }

  cycle() {
    if (!this.job) return setImmediate(() => this.cycle());
    // Periodic triad audits (every ~200 cycles) for configured paths
    if(this.triad && this.stats.hashes % 200 === 0 && this.triadAuditPaths.length){
      for(const p of this.triadAuditPaths){
        try {
          const code = require('fs').readFileSync(p,'utf8');
          this.triad.registerBlock(p, code);
          const res = this.triad.triadCycle(code);
          const prev = this.triadLastDigests.get(p);
          if(prev !== res.digest){
            console.log('[AUR-TRIAD][audit]', p, 'opt', res.optimization.score.toFixed(3), 'issues', res.syntax.issues.length, 'astOK', res.ast.ok, 'digest', res.digest.slice(0,16));
            this.triadLastDigests.set(p, res.digest);
          }
        } catch(e){ /* ignore read errors */ }
      }
    }
    // Reorder lattice once per cycle based on oracle predicted acceptance probability
    if(__SHARE_ORACLE__ && __SHARE_ORACLE__.loaded){
      try { global.__AUR_CURRENT_JOB_DIFFICULTY__ = this.job.difficulty || 0; const reordered = __SHARE_ORACLE__.sortLattice(lattice); for(let i=0;i<reordered.length;i++){ lattice[i] = reordered[i]; } } catch(_or){ /* non-fatal */ }
    }
    let hashes = 0;
    const chunkSize = 0x100000000 / lattice.length;
    let offset = this.currentNonce;
    for (let i = 0; i < lattice.length; i++) {
      const node = lattice[i];
      const start = offset;
      const end = offset + chunkSize;
      const gen = node.generateNonce(this.job.jobId + i);
      let testNonce = gen.nonce % chunkSize + start;
      if (gen.norm <= 2) {
        const shaRes = this.miner.tryNonce(testNonce);
        hashes += 1;
        if (shaRes.meetsTarget) {
          const ver = node.verifyNonce(shaRes.nonce, this.job.jobId + i);
          node.feedback(ver.valid);
          if (ver.valid) {
            this.stratum.submit({ jobId: this.job.jobId, nonce: shaRes.nonce, extranonce2: this.job.extranonce2, ntime: this.job.ntime });
            this.appendShareEntry({ ts: Date.now(), accepted: true, node_freq: node.freq, recent_success_rate: node.successes / (node.attempts || 1), job_difficulty: this.job.difficulty || 0, lattice_index: i });
          } else {
            node.feedback(false);
            this.appendShareEntry({ ts: Date.now(), accepted: false, node_freq: node.freq, recent_success_rate: node.successes / (node.attempts || 1), job_difficulty: this.job.difficulty || 0, lattice_index: i, verify_failed: true });
          }
        } else {
          node.feedback(false);
          this.appendShareEntry({ ts: Date.now(), accepted: false, node_freq: node.freq, recent_success_rate: node.successes / (node.attempts || 1), job_difficulty: this.job.difficulty || 0, lattice_index: i, meetsTarget: false });
        }
      } else {
        node.feedback(false);
        this.appendShareEntry({ ts: Date.now(), accepted: false, node_freq: node.freq, recent_success_rate: node.successes / (node.attempts || 1), job_difficulty: this.job.difficulty || 0, lattice_index: i, skipped_norm: true });
      }
      offset = end;
    }
    this.currentNonce = offset % 0x100000000;
    this.stats.hashes += hashes;
    const elapsed = (Date.now() - this.startTime) / 1000;
    this.stats.ths = (this.stats.hashes / elapsed / 1e12).toFixed(6);
    if (Date.now() % 10000 < 100) console.log(`Stats: ${this.stats.hashes} hashes, ${this.stats.shares} shares, ${this.stats.ths} TH/s`);
    setImmediate(() => this.cycle());
  }
}

// CLI quick-start
const user = process.argv[2] || 'your.wallet.worker';
const pipeline = new F2PoolAurreliaPipeline(user);
pipeline.start();

// Optional adaptive tuning hook using global.__AUR_AGENT_INVOKE__
;(async function agentAdaptiveLoop(){
  const invoke = global.__AUR_AGENT_INVOKE__;
  if(typeof invoke !== 'function'){ return; }
  const intervalMs = parseInt(process.env.AUR_AGENT_INTERVAL_MS || '60000',10); // 1 min
  let lastDigest = null;
  async function step(){
    try {
      // Simple context: average freq & share rate snapshot
      const avgFreq = lattice.reduce((a,n)=> a + n.freq,0)/lattice.length;
      const ctx = { avgFreq: Number(avgFreq.toFixed(2)), shares: pipeline.stats.shares, hashes: pipeline.stats.hashes };
      const prompt = 'Suggest prune threshold shift for octo lattice (frequency optimization)';
      const resp = await invoke('burrowAdapt', prompt, ctx);
      if(resp && !resp.blocked){
        const delta = (typeof resp.delta === 'number')? resp.delta:0;
        if(delta !== 0){
          // Apply bounded deterministic adjustment to first 16 nodes as a demo (advisory layer only)
          const adj = Math.max(-1, Math.min(1, delta));
          for(let i=0;i<16;i++){ lattice[i].freq = Math.max(400, Math.min(560, Math.round(lattice[i].freq + adj))); }
          console.log('[AGENT][freq-adjust]', adj, 'newFreq0=', lattice[0].freq);
        }
        const digest = resp.note || resp.text || null;
        if(digest && digest !== lastDigest){
          console.log('[AGENT][resp]', resp.action || 'noop', 'delta', resp.delta, 'conf', resp.confidence);
          lastDigest = digest;
        }
      }
    } catch(e){ /* ignore */ }
    setTimeout(step, intervalMs);
  }
  step();
})();

process.on('SIGINT', () => process.exit(0));
