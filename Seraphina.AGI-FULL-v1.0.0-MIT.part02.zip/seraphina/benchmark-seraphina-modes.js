// benchmark-seraphina-modes.js
// Compare training modes: loop, native, mathjs, wasm
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
let prom=null; let modeEpochGauge=null;
try { prom = require('prom-client'); modeEpochGauge = new prom.Gauge({ name:'seraphina_mode_epoch_avg_ms', help:'Average epoch time per mode', labelNames:['mode'] }); } catch(_e){}
function runMode(mode){
  const env = { ...process.env, SERAPHINA_VECTORIZE: mode==='mathjs'? '1':'', SERAPHINA_VECTORIZE_MODE: mode==='loop'? 'loop': (mode==='native'? 'native': (mode==='wasm'? 'wasm':'loop')), SERAPHINA_FORCE_PROMOTE:'1' };
  const t0 = Date.now();
  const res = spawnSync(process.execPath, ['seraphina-model-train.js'], { env, encoding:'utf8' });
  const dur = Date.now()-t0;
  let scoreboard=null;
  try { scoreboard = JSON.parse(fs.readFileSync(env.SERAPHINA_MODEL_SCOREBOARD || 'seraphina-model-scoreboard.json','utf8')); } catch(_e){}
  return { mode, exitCode: res.status, durationMs: dur, acc: scoreboard? scoreboard.acc: null, accEthical: scoreboard? scoreboard.accEthical: null };
}
function main(){
  const modes = ['loop','native','mathjs','wasm'];
  const results = [];
  for(const m of modes){
    console.log('[BenchmarkModes] running mode='+m);
    results.push(runMode(m));
  }
  const out = { ts: Date.now(), results };
  fs.writeFileSync('seraphina-modes-benchmark.json', JSON.stringify(out,null,2));
  // Append to hash-chained ledger
  const LEDGER = process.env.SERAPHINA_MODES_LEDGER || 'seraphina-modes-ledger.jsonl';
  let prev='GENESIS';
  if(fs.existsSync(LEDGER)){
    const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
    if(lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){} }
  }
  const crypto = require('crypto');
  function stableChainHash(entry, prevHash){ return crypto.createHash('sha256').update(prevHash+JSON.stringify(entry)).digest('hex'); }
  const entry = { ts: out.ts, results: out.results, prevHash: prev };
  entry.chainHash = stableChainHash(entry, prev);
  fs.appendFileSync(LEDGER, JSON.stringify(entry)+'\n');
  // Observe gauge
  if(modeEpochGauge){
    for(const r of out.results){
      if(typeof r.durationMs === 'number' && r.durationMs>0){
        // Rough per-epoch estimate: duration / SERAPHINA_MODEL_EPOCHS (env or default 120)
        const epochs = parseInt(process.env.SERAPHINA_MODEL_EPOCHS || '120',10);
        modeEpochGauge.labels(r.mode).set(Number((r.durationMs/epochs).toFixed(3)));
      }
    }
  }
  console.log('[BenchmarkModesDone]', JSON.stringify(out));
}
if(require.main === module) main();
