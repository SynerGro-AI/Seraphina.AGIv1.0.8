// aurrelia-prom-exporter.js
// Simple Prometheus exporter reading a merged or per-instance metrics JSONL tail.
// Usage: node aurrelia-prom-exporter.js --file=aurrelia-metrics-merged.jsonl --port=9108
// Exposes /metrics with selected gauges/counters aggregated over recent window.

const http = require('http');
const fs = require('fs');

const args = process.argv.slice(2);
function getArg(name, def){ const a=args.find(x=>x.startsWith(`--${name}=`)); return a? a.split('=')[1]: def; }
const file = getArg('file','aurrelia-metrics-merged.jsonl');
const port = parseInt(getArg('port','9108'),10);
const windowLines = parseInt(getArg('window','500'),10);

let lastInode = null; let lastSize = 0; let buffer=[]; let lastMTime=0;
function readTail(){
  try {
    const st = fs.statSync(file); if (lastInode && (st.ino !== lastInode || st.size < lastSize)) { buffer=[]; }
    lastInode = st.ino; lastSize = st.size; lastMTime = st.mtimeMs;
    const data = fs.readFileSync(file,'utf8').trim().split(/\n/).filter(Boolean);
    buffer = data.slice(-windowLines);
  } catch(e){ /* ignore */ }
}
setInterval(readTail, 4000); readTail();

function aggregate(){
  const agg = { hashes:0, shares:0, attempted:0, ths:0, recs:0, harmonics:{}, weightSkips:0, weightActive:0, weightSamples:0 };
  let gpuMode = 0; // 0=absent,1=stub,2=active
  for (const l of buffer){
    try {
      const o = JSON.parse(l);
      if (o.hashes!=null) agg.hashes += o.hashes;
      if (o.shares!=null) agg.shares += o.shares;
      if (o.attempted!=null) agg.attempted += o.attempted;
      if (o.ths) agg.ths += parseFloat(o.ths);
      agg.recs++;
      if (o.wasM && o.wasM.assignedFreq){
        const f = o.wasM.assignedFreq;
        agg.harmonics[f] = (agg.harmonics[f]||0)+1;
      }
        if (o.gating || o.gpu){
        if (o.gating.weightSkipActive) agg.weightActive++;
        // If worker-level attempted vs oppAttempts present, derive skips
        if (typeof o.oppAttempts === 'number' && typeof o.attempted === 'number'){
          const diff = o.oppAttempts - o.attempted;
          if (diff > 0){ agg.weightSkips += diff; }
          agg.weightSamples++;
        }
      }
        if (o.gpu){
          // Derive gpuMode if present
          if (o.gpu.stub) { gpuMode = Math.max(gpuMode,1); }
          if (o.gpu.enabled && !o.gpu.stub){ gpuMode = 2; }
        }
        if (o.gpu && o.gpu.enabled && !o.gpu.stub){
          agg.gpu = agg.gpu || { batches:0, headers:0, totalNs:0, lastNs:0, parityChecks:0, parityMismatches:0 };
          agg.gpu.batches += o.gpu.batches||0;
          agg.gpu.headers += o.gpu.headers||0;
          agg.gpu.totalNs += o.gpu.avgNsPerHeader && o.gpu.headers ? (o.gpu.avgNsPerHeader * o.gpu.headers) : 0;
          agg.gpu.lastNs = o.gpu.lastBatchNs||agg.gpu.lastNs;
          agg.gpu.parityChecks += o.gpu.parityChecks||0;
          agg.gpu.parityMismatches += o.gpu.parityMismatches||0;
        }
    } catch(_){ }
  }
  agg.gpuMode = gpuMode;
  return agg;
}

http.createServer((req,res)=>{
  if (req.url === '/metrics'){
    const a = aggregate();
    let out = '';
    out += `aurrelia_hashes_total ${a.hashes}\n`;
    out += `aurrelia_shares_total ${a.shares}\n`;
    out += `aurrelia_attempted_total ${a.attempted}\n`;
    out += `aurrelia_ths_sum ${a.ths}\n`;
    out += `aurrelia_records_window ${a.recs}\n`;
    for (const [hf,count] of Object.entries(a.harmonics)) out += `aurrelia_harmonic_instances{freq="${hf}"} ${count}\n`;
    out += `aurrelia_weight_skip_total ${a.weightSkips}\n`;
    out += `aurrelia_weight_skip_windows ${a.weightSamples}\n`;
    out += `aurrelia_weight_active_instances ${a.weightActive}\n`;
    if (a.gpu){
      const avgNsPerHeader = a.gpu.headers ? (a.gpu.totalNs / a.gpu.headers) : 0;
      out += `aurrelia_gpu_batches_total ${a.gpu.batches}\n`;
      out += `aurrelia_gpu_headers_total ${a.gpu.headers}\n`;
      out += `aurrelia_gpu_avg_ns_per_header ${avgNsPerHeader.toFixed(0)}\n`;
      out += `aurrelia_gpu_last_batch_ns ${a.gpu.lastNs}\n`;
      out += `aurrelia_gpu_parity_checks_total ${a.gpu.parityChecks}\n`;
      out += `aurrelia_gpu_parity_mismatches_total ${a.gpu.parityMismatches}\n`;
      if (a.gpu.currentBatchSize) out += `aurrelia_gpu_current_batch_size ${a.gpu.currentBatchSize}\n`;
    }
    out += `aurrelia_gpu_mode ${a.gpuMode}\n`;
    res.writeHead(200,{ 'Content-Type':'text/plain' }); res.end(out);
  } else if (req.url === '/health'){
    res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, fileExists: fs.existsSync(file), lastMTime }));
  } else { res.writeHead(404); res.end('not found'); }
}).listen(port, ()=> console.log('[Prom] listening on', port, 'file=', file));
