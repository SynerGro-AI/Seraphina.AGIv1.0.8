// Load .env early unless explicitly disabled
try {
  if (process.env.DISABLE_DOTENV !== '1'){
    const fs = require('fs'); const path = require('path');
    const envPath = path.resolve(process.cwd(), '.env');
    if (fs.existsSync(envPath)){
      let loaded=false;
      try { require('dotenv').config({ path: envPath }); loaded=true; console.log('[ENV] .env loaded from', envPath); } catch(e){ console.warn('[ENV] dotenv not installed, using manual parser'); }
      if (!loaded){
        try {
          const txt = fs.readFileSync(envPath,'utf8');
          for (const rawLine of txt.split(/\r?\n/)){
            const line = rawLine.trim();
            if (!line || line.startsWith('#')) continue;
            const eq = line.indexOf('=');
            if (eq === -1) continue;
            const k = line.slice(0, eq).trim();
            let v = line.slice(eq+1).trim();
            if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1,-1);
            if (process.env[k] == null) process.env[k] = v;
          }
          console.log('[ENV] .env loaded (manual) from', envPath);
        } catch(e){ console.warn('[ENV] manual .env parse failed', e.message); }
      }
    }
  }
} catch(_e){}

// Load manifest audit root early for Prometheus gauge comparisons (non-fatal if absent)
try {
  const fs = require('fs');
  if (!global.__AUR_MANIFEST_ROOT__ && fs.existsSync('artifact-hashes.json')){
  // Holodeck activation (virtual deterministic environment if enabled)
  try { require('./holodeck/holodeck-loader'); } catch(_holo){}
  // AI memory log integration wrapper (agent suggestion persistence)
  try {
    const { appendMemory, enabled: __AI_MEM_ENABLED } = require('./ai-memory-log.js');
    if (__AI_MEM_ENABLED){
      const origInvoke = global.__AUR_AGENT_INVOKE__;
      if (typeof origInvoke === 'function'){
        global.__AUR_AGENT_INVOKE__ = async function(role, prompt, context){
          const resp = await origInvoke(role, prompt, context);
          if (resp && !resp.blocked){
            // structured schema attempt or fallback
              const mem = {
                action: resp.action || null,
                delta: (typeof resp.delta === 'number') ? resp.delta : null,
                confidence: (typeof resp.confidence === 'number') ? resp.confidence : null,
                note: resp.note || resp.text || ('role:'+role)
              };
              appendMemory(mem);
          }
          return resp;
        };
        console.log('[AI-MEM] Agent invoke wrapped for memory logging');
      }
    }
  } catch(e){ /* optional */ }
  try {
      const manifestRaw = fs.readFileSync('artifact-hashes.json','utf8');
      const manifest = JSON.parse(manifestRaw);
      // Prefer auditMerkleRoot (ledger integrity) falling back to merkleRoot
      const root = manifest.auditMerkleRoot || manifest.merkleRoot || null;
      if (root){
        global.__AUR_MANIFEST_ROOT__ = root;
        console.log('[INIT] Loaded manifest audit root', root.slice(0,16)+'...');
      }
    } catch(e){ /* ignore parse errors */ }
  }
} catch(_e){ /* ignore fs errors */ }

// Helper: build coinbase transaction hex from parts (coinb1 + extranonce1 + extranonce2 + coinb2)
// Used by both BTC and RVN job processing. Keep minimal and deterministic.
function buildCoinbase(coinb1, extranonce1, extranonce2, coinb2){
  return String(coinb1||'') + String(extranonce1||'') + String(extranonce2||'') + String(coinb2||'');
}

// Optional Coral advisor (deterministic heuristic + fast IPC child)
const coralAdvisor = (()=>{ try { return require('./coral-advisor.js'); } catch(_){ return null; } })();

// Economic counters persistence (WAL)
let __ECON_SWITCH_COUNT_PERSIST = 0;
let __ECON_SWITCH_FAIL_COUNT_PERSIST = 0;
let __ECON_ROLLBACK_COUNT_PERSIST = 0;
let __ECON_LAST_PERSIST_TS = 0;
const __ECON_COUNTER_WAL = 'econ-counters.wal';
const __ECON_LOG_SCHEMA = 'econ_event/v1.0';
const __ECON_WAL_MAX_SIZE = parseInt(process.env.ECON_WAL_MAX_SIZE || (10*1024*1024).toString(),10); // 10MB default
const __ECON_WAL_MAX_FILES = parseInt(process.env.ECON_WAL_MAX_FILES || '5',10);
// Event log (switch/rollback) rotation + integrity hash chain
const __ECON_EVENT_LOG = 'econ-events.jsonl';
const __ECON_EVENT_MAX_SIZE = parseInt(process.env.ECON_EVENT_MAX_SIZE || (5*1024*1024).toString(),10); // 5MB
const __ECON_EVENT_MAX_FILES = parseInt(process.env.ECON_EVENT_MAX_FILES || '6',10);
let __ECON_LAST_EVENT_HASH = null; // previous chain hash
let __ECON_EVENT_ROTATIONS = 0; let __ECON_EVENT_ROTATION_FAIL = 0;
function econRotateEventLog(){
  try {
    const fs = require('fs'); const zlib = require('zlib');
    if (!fs.existsSync(__ECON_EVENT_LOG)) return;
    const st = fs.statSync(__ECON_EVENT_LOG);
    if (st.size <= __ECON_EVENT_MAX_SIZE) return;
    const ts = Date.now();
    const gzName = `${__ECON_EVENT_LOG}.${ts}.gz`;
    const inp = fs.createReadStream(__ECON_EVENT_LOG); const out = fs.createWriteStream(gzName); const gz = zlib.createGzip();
    inp.pipe(gz).pipe(out).on('finish', ()=>{
      try { fs.unlinkSync(__ECON_EVENT_LOG); } catch(_){ }
      try {
        const list = fs.readdirSync('.').filter(f=>f.startsWith('econ-events.jsonl.') && f.endsWith('.gz')).sort();
        const excess = list.length - __ECON_EVENT_MAX_FILES;
        if (excess>0){ for (let i=0;i<excess;i++){ try { fs.unlinkSync(list[i]); } catch(_){} } }
      } catch(_prune){}
      __ECON_EVENT_ROTATIONS++;
    }).on('error',()=>{ __ECON_EVENT_ROTATION_FAIL++; });
  } catch(e){ __ECON_EVENT_ROTATION_FAIL++; console.warn('[ECON][EventRotate] failed', e.message); }
}
function econAppendEvent(ev){
  try {
    const fs = require('fs'); const crypto = require('crypto');
    const payload = JSON.stringify(ev);
    const h = crypto.createHash('sha256').update((__ECON_LAST_EVENT_HASH||'GENESIS') + payload).digest('hex');
    __ECON_LAST_EVENT_HASH = h;
    fs.appendFileSync(__ECON_EVENT_LOG, JSON.stringify({ ...ev, chain_hash: h })+'\n');
    econRotateEventLog();
  } catch(e){ console.warn('[ECON][EventLog] append fail', e.message); }
}
function econRotateWal(){
  try {
    const fs = require('fs'); const zlib = require('zlib');
    if (!fs.existsSync(__ECON_COUNTER_WAL)) return;
    const st = fs.statSync(__ECON_COUNTER_WAL);
    if (st.size <= __ECON_WAL_MAX_SIZE) return;
    const ts = Date.now();
    const gzName = `${__ECON_COUNTER_WAL}.${ts}.gz`;
    const inp = fs.createReadStream(__ECON_COUNTER_WAL); const out = fs.createWriteStream(gzName); const gz = zlib.createGzip();
    inp.pipe(gz).pipe(out).on('finish', ()=>{
      try { fs.unlinkSync(__ECON_COUNTER_WAL); } catch(_){}
      // Prune old archives (keep newest __ECON_WAL_MAX_FILES)
      try {
        const list = fs.readdirSync('.').filter(f=>f.startsWith('econ-counters.wal.') && f.endsWith('.gz')).sort();
        const excess = list.length - __ECON_WAL_MAX_FILES;
        if (excess>0){ for (let i=0;i<excess;i++){ try { fs.unlinkSync(list[i]); } catch(_){} } }
      } catch(_e){}
    });
  } catch(e){ console.warn('[ECON][Persist] rotate failed', e.message); }
}
function econLoadCounters(){
  try {
    const fs = require('fs');
    if (fs.existsSync(__ECON_COUNTER_WAL)){
      const lines = fs.readFileSync(__ECON_COUNTER_WAL,'utf8').trim().split(/\n/).filter(Boolean);
      if (lines.length){
        const latest = JSON.parse(lines[lines.length-1]);
        __ECON_SWITCH_TOTAL = latest.switches_total || __ECON_SWITCH_TOTAL;
        __ECON_SWITCH_FAIL = latest.switches_fail || __ECON_SWITCH_FAIL;
        __ECON_ROLLBACK_COUNT_PERSIST = latest.rollbacks || 0;
        __ECON_SWITCH_COUNT_PERSIST = __ECON_SWITCH_TOTAL;
        __ECON_SWITCH_FAIL_COUNT_PERSIST = __ECON_SWITCH_FAIL;
      }
    }
  } catch(e){ console.warn('[ECON][Persist] load failed', e.message); }
}
function econPersistCounters(force=false){
  try {
    const now = Date.now();
    if (!force && (now - __ECON_LAST_PERSIST_TS) < 300000) return; // 5m throttle
    const fs = require('fs');
    const snap = { ts: now, switches_total: __ECON_SWITCH_TOTAL, switches_fail: __ECON_SWITCH_FAIL, rollbacks: __ECON_ROLLBACK_COUNT_PERSIST, active_coin: __ECON_ACTIVE_COIN, last_reason: __ECON_LAST_SWITCH_REASON };
    fs.appendFileSync(__ECON_COUNTER_WAL, JSON.stringify(snap)+'\n');
    econRotateWal();
    __ECON_LAST_PERSIST_TS = now;
  } catch(e){ console.warn('[ECON][Persist] append failed', e.message); }
}
econLoadCounters();
// aurrelia-pico-mesh-miner.js
// Aurrelia.AI: Self-optimizing, pico-mesh learning, F2Pool mining pipeline
// Author: Wilsonof Orange + GitHub Copilot + Grok Refinement

const crypto = require('crypto');
// Swapped external 'stratum-client' (engine-locked to old Node) for internal implementation
const { RealStratumClient } = require('./real-stratum-client.js');
// Optional WASM accelerated hashing
let wasmHash = null;
try { wasmHash = require('./midstate_wasm.js'); } catch(_) { }
let fusedHash = null;
try { fusedHash = require('./fused_wasm.js'); } catch(_) {}
// Deterministic double SHA256 (hex in -> hex out)
function doubleSha256(hex){
  const buf = Buffer.isBuffer(hex)? hex : Buffer.from(hex, 'hex');
  const h1 = crypto.createHash('sha256').update(buf).digest();
  return crypto.createHash('sha256').update(h1).digest('hex');
}
// Plane aggregation mode & weighting flags (geometry layer)
const PLANE_AGG_MODE = (process.env.PLANE_AGG_MODE === 'sum' ? 'sum' : 'avg');
const PLANE_WEIGHTED = process.env.PLANE_WEIGHTED === '1';
// Harmonic frequency set (geometry resonance) & toggle
const HARMONICS = (process.env.HARMONICS && process.env.HARMONICS.split(',').map(x=> parseFloat(x.trim())).filter(x=> !isNaN(x)&&x>0)) || [432, 528, 444, 440, 480, 500, 512];
const MULTI_HARMONIC = process.env.MULTI_HARMONIC === '1';
// WASM metrics container (prevent undefined access later)
if (!global.__AUR_WASM_METRICS__) {
  global.__AUR_WASM_METRICS__ = {
    available: !!wasmHash,
    fusedAvailable: false,
    triedInit: false,
    fallbacks: 0,
    mismatches: 0
  };
}
if (typeof reverseBytes === 'undefined') {
  function reverseBytes(hex){
    try { return hex.match(/.{2}/g).reverse().join(''); } catch(_){ return hex; }
  }
}
// GPU enable flag (env-driven)
let GPU_ENABLED = process.env.AUR_GPU === '1';
// Worker count (single-mode guards)
const AUR_WORKERS = parseInt(process.env.WORKERS || '1', 10);
const thermalEnabled = process.env.GPU_THERMAL === '1';
// WASM dynamic batch tuning state (for fused midstate path)
const WASM_TUNER = {
  enabled: !!fusedHash,
  batchSize: parseInt(process.env.WASM_FUSED_BATCH || '32',10),
  targetMs: parseInt(process.env.WASM_FUSED_TARGET_MS || '12',10),
  emaLatency: null,
  samples: 0
};
function tunedFusedBatch(bufs){
  if(!fusedHash) return Promise.resolve(bufs.map(b=> crypto.createHash('sha256').update(crypto.createHash('sha256').update(b).digest()).digest()));
  const start = process.hrtime.bigint();
  return fusedHash.hashBatch(bufs).then(out=> {
    const end=process.hrtime.bigint();
    const ms = Number(end-start)/1e6;
    WASM_TUNER.samples++;
    if(WASM_TUNER.emaLatency==null) WASM_TUNER.emaLatency=ms; else WASM_TUNER.emaLatency = WASM_TUNER.emaLatency*0.85 + ms*0.15;
    // Simple adaptive batch size tweak toward targetMs
    if(WASM_TUNER.samples % 25 === 0){
      if(WASM_TUNER.emaLatency < WASM_TUNER.targetMs*0.75) WASM_TUNER.batchSize = Math.min(WASM_TUNER.batchSize+4, 256);
      else if(WASM_TUNER.emaLatency > WASM_TUNER.targetMs*1.25) WASM_TUNER.batchSize = Math.max(8, WASM_TUNER.batchSize-4);
    }
    return out;
  }).catch(e=> {
    console.warn('[FUSED_WASM] batch error fallback CPU', e.message);
    return bufs.map(b=> crypto.createHash('sha256').update(crypto.createHash('sha256').update(b).digest()).digest());
  });
}
// end fused batch helper
// GPU metrics initialization (standalone, no flush wrapping)
try {
  const client = require('prom-client');
  if (!global.__AUR_GPU_METRICS__) {
    global.__AUR_GPU_METRICS__ = {
      batches: new client.Gauge({ name:'aurrelia_gpu_batches_total', help:'Total GPU SHA256d batches executed'}),
      headers: new client.Gauge({ name:'aurrelia_gpu_headers_total', help:'Total headers processed via GPU path'}),
      lastBatchNs: new client.Gauge({ name:'aurrelia_gpu_last_batch_ns', help:'Nanoseconds duration of last GPU batch'}),
      avgPerHeaderNs: new client.Gauge({ name:'aurrelia_gpu_avg_per_header_ns', help:'Average nanoseconds per header across all GPU batches'}),
      parityChecks: new client.Gauge({ name:'aurrelia_gpu_parity_checks_total', help:'Total GPU parity sample checks'}),
      parityMismatches: new client.Gauge({ name:'aurrelia_gpu_parity_mismatches_total', help:'Total GPU parity mismatches (disables GPU)'}),
      enabled: new client.Gauge({ name:'aurrelia_gpu_enabled', help:'GPU backend enabled state (1=enabled,0=disabled)'}),
      speedup: new client.Gauge({ name:'aurrelia_gpu_speedup_est', help:'Estimated CPU/GPU speedup ratio'}),
      recoveryAttempts: new client.Gauge({ name:'aurrelia_gpu_recovery_attempts_total', help:'Total GPU recovery attempts performed'}),
      reenabled: new client.Gauge({ name:'aurrelia_gpu_reenabled_total', help:'Total times GPU backend successfully re-enabled'}),
      cpuSampleNs: new client.Gauge({ name:'aurrelia_gpu_last_cpu_sample_ns', help:'CPU parity sample hashing ns'}),
      gpuSampleNs: new client.Gauge({ name:'aurrelia_gpu_last_gpu_sample_ns', help:'GPU per-header ns last batch'}),
      parityIntervalCurrent: new client.Gauge({ name:'aurrelia_gpu_parity_interval_current', help:'Current GPU parity sampling interval'}),
      recoveryFailures: new client.Gauge({ name:'aurrelia_gpu_recovery_failures_total', help:'Total failed GPU recovery attempts'}),
      batchPerHeaderHist: new client.Histogram({ name:'aurrelia_gpu_batch_per_header_ns', help:'Per-header ns GPU batches', labelNames:['batch_size'], buckets: (process.env.GPU_BATCH_LATENCY_BUCKETS || '20000,40000,80000,160000,320000,640000').split(',').map(x=> parseInt(x.trim(),10)).filter(x=> !isNaN(x)&&x>0).sort((a,b)=>a-b) }),
      cpuPerHeaderHist: new client.Histogram({ name:'aurrelia_cpu_per_header_ns', help:'CPU per-header ns (parity samples)', buckets: (process.env.GPU_BATCH_LATENCY_BUCKETS || '20000,40000,80000,160000,320000,640000').split(',').map(x=> parseInt(x.trim(),10)).filter(x=> !isNaN(x)&&x>0).sort((a,b)=>a-b) }),
      latencyP50: new client.Gauge({ name:'aurrelia_gpu_latency_p50_ns', help:'Moving P50 GPU per-header ns'}),
      latencyP90: new client.Gauge({ name:'aurrelia_gpu_latency_p90_ns', help:'Moving P90 GPU per-header ns'}),
      latencyP99: new client.Gauge({ name:'aurrelia_gpu_latency_p99_ns', help:'Moving P99 GPU per-header ns'}),
      tempC: new client.Gauge({ name:'aurrelia_gpu_temp_c', help:'GPU temperature Celsius'}),
      powerW: new client.Gauge({ name:'aurrelia_gpu_power_w', help:'GPU power draw Watts'}),
      throttle: new client.Gauge({ name:'aurrelia_gpu_throttle', help:'GPU thermal throttle state'}),
      cpuLatencyP50: new client.Gauge({ name:'aurrelia_cpu_latency_p50_ns', help:'Moving window P50 CPU parity sample ns'}),
      cpuLatencyP90: new client.Gauge({ name:'aurrelia_cpu_latency_p90_ns', help:'Moving window P90 CPU parity sample ns'}),
      cpuLatencyP99: new client.Gauge({ name:'aurrelia_cpu_latency_p99_ns', help:'Moving window P99 CPU parity sample ns'}),
      disableCause: new client.Gauge({ name:'aurrelia_gpu_disable_cause', help:'GPU disable cause code (0=ok,1=parity_fail,2=recovery_exceeded,3=thermal_throttle,4=driver_error,5=misconfig)'}),
      utilPct: new client.Gauge({ name:'aurrelia_gpu_utilization_pct', help:'GPU utilization percent'}),
      memUsedMB: new client.Gauge({ name:'aurrelia_gpu_mem_used_mb', help:'GPU memory used MB'}),
      memTotalMB: new client.Gauge({ name:'aurrelia_gpu_mem_total_mb', help:'GPU memory total MB'}),
      memUtilPct: new client.Gauge({ name:'aurrelia_gpu_mem_utilization_pct', help:'GPU memory utilization percent'}),
      tempAvgC: new client.Gauge({ name:'aurrelia_gpu_temp_avg_c', help:'Rolling average GPU temperature Celsius'}),
      utilAvgPct: new client.Gauge({ name:'aurrelia_gpu_utilization_avg_pct', help:'Rolling average GPU utilization percent'}),
    };
    global.__AUR_GPU_METRICS__.enabled.set(GPU_ENABLED?1:0);
  }
} catch(_) { /* metrics optional */ }
  const GPU_INDEX = parseInt(process.env.GPU_INDEX || '0',10);
// Attempt load of KawPow native addon early (optional)
function __loadKawpowNativeOnce() {
  // Allow explicit override e.g. KAWPOW_NATIVE_MODULE=C:\path\to\kawpowhash.node
  const override = process.env.KAWPOW_NATIVE_MODULE;
  if (override) {
    try { return require(override); } catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow] override load failed', override, e.message); }
  }
  // Preferred target name per binding.gyp / NODE_API_MODULE(kawpowhash)
  try { return require('./build/Release/kawpowhash.node'); } catch(e1){
    // Back-compat older name
    try { return require('./build/Release/kawpow_native.node'); } catch(e2){
      if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow] native load failed early', e1.message, '| fallback', e2.message);
      return null;
    }
  }
}
try { if (!global.kawpowNative) global.kawpowNative = __loadKawpowNativeOnce(); } catch(_){}
  const nvmlWrapper = thermalEnabled ? (function(){ try { return require('./nvml-wrapper.js'); } catch(_){ return null; } })() : null;
  if (thermalEnabled && !global.__AUR_GPU_ROLLING__) global.__AUR_GPU_ROLLING__ = { temps:[], utils:[], window: parseInt(process.env.GPU_ROLLING_WINDOW || '120',10) }; // ~120 samples default
      // Driver / misconfiguration classification
      if (process.env.AUR_GPU === '1' && (!gpuHash || typeof gpuHash.hashBatch !== 'function')){
        if(global.__AUR_GPU_METRICS__){
          const cudaHint = process.env.CUDA_PATH || process.env.NVCUDA_DLL;
          if (cudaHint){ global.__AUR_GPU_METRICS__.disableCause.set(4); console.warn('[GPU] driver error suspected: CUDA hint present, gpuHash missing'); }
          else { global.__AUR_GPU_METRICS__.disableCause.set(5); console.warn('[GPU] misconfiguration: AUR_GPU=1 without CUDA hints'); }
        }
      }
    // Rebuilt clean HASH_STRATEGIES registry after corruption
    const HASH_STRATEGIES = {
      sha256d: { id:'sha256d', hashHeader: (h)=> doubleSha256(h), parityEnabled:true },
      fused_wasm_dyn: (fusedHash && tunedFusedBatch) ? { id:'fused_wasm_dyn', hashHeader: (function(){
        let q=[]; let ts=Date.now(); const ageLimit=15; return function(headerHex){
          q.push(headerHex); const age=Date.now()-ts; if(q.length >= WASM_TUNER.batchSize || age >= ageLimit){
            const batch=q; q=[]; ts=Date.now(); const bufs=batch.map(h=> Buffer.from(h,'hex'));
            return tunedFusedBatch(bufs).then(out=> out[out.length-1]).catch(e=>{ console.warn('[WASM] batch err fallback CPU', e.message); return doubleSha256(headerHex); }); }
          return doubleSha256(headerHex); };
      })(), parityEnabled:true } : null,
      scrypt: (typeof litecoinScryptHash==='function') ? { id:'scrypt', hashHeader: h=> litecoinScryptHash(h), parityEnabled:false } : null,
      kawpow: (function(){
        let native = (typeof global.kawpowNative !== 'undefined' && global.kawpowNative) ? global.kawpowNative : __loadKawpowNativeOnce();
        let enabled = true;
        if (!native){
          if (process.env.REAL_MINING_ENFORCED==='1'){
            console.error('[KawPow] Native addon missing while REAL_MINING_ENFORCED=1 -> abort');
            process.exit(42);
          } else {
            console.warn('[KawPow] Native addon not loaded, falling back to doubleSha256 stub');
            enabled = false;
          }
        }
        return { id:'kawpow', hashHeader: (headerHex, height=0, seedHex='')=>{
          if (native && typeof native.hash === 'function'){
            try {
              const headerBuf=Buffer.from(headerHex,'hex');
              const seedBuf = seedHex? Buffer.from(seedHex,'hex') : Buffer.alloc(32,0);
              const nonce=0;
              const out=native.hash(headerBuf,height,seedBuf,nonce);
              return out.toString('hex');
            } catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow] native hash error fallback', e.message); }
          }
          return doubleSha256(headerHex);
        }, parityEnabled:false, enabled };
      })()
    };

// Lightweight HTTP helpers (used by ECON block)
const https = require('https');
const http = require('http');
function fetchJson(url){
  return new Promise(res=>{
    try {
      const mod = url.startsWith('https')? https : http;
      const t = Date.now();
      const rq = mod.get(url, r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try { res({ bitcoin:undefined, ravencoin:undefined, kaspa:undefined, frencoin:undefined, ...JSON.parse(d) }); } catch(_){ res(null); } }); });
      rq.on('error',()=> res(null));
      rq.setTimeout(5000,()=>{ rq.destroy(); res(null); });
    } catch(_) { res(null); }
  });
}
function fetchText(url){
  return new Promise(res=>{
    try {
      const mod = url.startsWith('https')? https : http;
      const rq = mod.get(url, r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=> res(d.trim())); });
      rq.on('error',()=> res(null));
      rq.setTimeout(5000,()=>{ rq.destroy(); res(null); });
    } catch(_) { res(null); }
  });
}

// --- Advisory bridge (prompt shield + Coral fallback + structured schema) ---
const __AGENT_BLOCK_RE = /(\.ssh|id_rsa|wallet|seed|mnemonic|passphrase|artifact-hashes\.json|source-manifest|package\.json|node_modules|\.env)/i;
const __AGENT_RED_VERBS = /(upload|exfiltrate|send to|leak)/ig;
function _shieldPrompt(s){ if (!s) return s; return String(s).replace(__AGENT_RED_VERBS,'[redacted]'); }
let validateAgentResponse = null; try { ({ validateAgentResponse } = require('./agent-response-schema')); } catch(_e){ }
async function invokeAgent(role, prompt, context){
  try {
    const ptxt = _shieldPrompt(prompt||'');
    const ctx = context || {};
    const raw = (ptxt||'') + ' ' + JSON.stringify(ctx||{});
    if (__AGENT_BLOCK_RE.test(raw)){
      return { blocked:true };
    }
    if (global.__AUR_AGENT_INVOKE__ && typeof global.__AUR_AGENT_INVOKE__ === 'function'){
      try {
        const resp = await Promise.resolve(global.__AUR_AGENT_INVOKE__(role, ptxt, ctx));
        if (resp) return resp;
      } catch(_e){}
    }
    // Coral heuristic fallback mapping
    let feat = {};
    if (ctx && Array.isArray(ctx.featBase)){
      const fb = ctx.featBase;
      const meanEff = Number(fb[0]||0);
      const eff = fb.slice(1,5).map(Number);
      const chernProxy = Number(fb[fb.length-2]||0);
      let v=0; if (eff.length){ const m = eff.reduce((a,b)=>a+b,0)/eff.length; v = eff.reduce((a,b)=>a+(b-m)*(b-m),0)/eff.length; }
      const signVar = Math.max(0, Math.min(1, 1/(1+v)));
      feat = { rankProxy: meanEff, signVar, chernVar: chernProxy };
    }
    let delta = 0; let digest=null;
    if (coralAdvisor && typeof coralAdvisor.advise==='function'){
      try { const out = await Promise.resolve(coralAdvisor.advise(feat)); if (out){ delta = Number(out.deltaPrune||0)||0; digest = out.digest||null; } } catch(_e){}
    }
    if (typeof delta === 'number' && delta !== 0){
      let suggestion = { action:'adjust_prune', delta, confidence:0.5 };
      if (validateAgentResponse){
        const v = validateAgentResponse(suggestion);
        if (v.ok){ suggestion = v.normalized; } else { suggestion = undefined; }
      }
      return { suggestion, digest };
    }
    if (validateAgentResponse){
      const v = validateAgentResponse({ action:'noop', delta:0, confidence:0 });
      if (v.ok){ return { suggestion: v.normalized, digest }; }
    }
    return { digest };
  } catch(_){ return {}; }
}

// Economic data aggregator (price + difficulty) with hysteresis (reconstructed)
const ECON = {
  enabled: process.env.ECON_ENABLED !== '0',
  intervalMs: parseInt(process.env.ECON_INTERVAL_MS || '60000',10),
  lastFetch: 0,
  api: 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ravencoin,kaspa,frencoin&vs_currencies=usd',
  diffSources: {
    btc: 'https://blockchain.info/q/getdifficulty',
    rvn: 'https://ravencoin.network/api/v2/network/difficulty',
    kas: 'https://api.kaspa.org/insights/difficulty',
    fren: process.env.FREN_DIFF_URL || 'https://explorer.frencoin.org/api/getdifficulty'
  },
  state: { price:{}, diff:{} }
};
// ECON hysteresis tracking
ECON.hysteresisCycles = parseInt(process.env.ECON_HYSTERESIS_CYCLES || '3',10);
ECON.lastRecommendation = null; ECON.stableCount = 0;
// Income bias multipliers (deterministic): allow prioritizing FREN & RVN while still honoring raw income order.
const ECON_BIAS = {
  fren: parseFloat(process.env.ECON_FREN_BIAS || '1.08'), // slight income boost for strategic priority
  rvn: parseFloat(process.env.ECON_RVN_BIAS || '1.04'),
  btc: parseFloat(process.env.ECON_BTC_BIAS || '1.0'),
  kas: parseFloat(process.env.ECON_KAS_BIAS || '1.0')
};
// --- Runtime Bias Override & AB Micro-Evaluation ---
// If ECON_RUNTIME_BIAS_PATH exists (JSON {coin:multiplier,...}) load and apply overrides (deterministic rounding) with snapshot.
const RT_BIAS_PATH = process.env.ECON_RUNTIME_BIAS_PATH || 'econ-runtime-bias.json';
let __RT_BIAS_SNAPSHOT = null; // original bias snapshot before runtime overrides
let __RT_BIAS_APPLIED_TS = null;
function loadRuntimeBias(){
  try {
    const fs = require('fs');
    if (!fs.existsSync(RT_BIAS_PATH)) return false;
    const raw = fs.readFileSync(RT_BIAS_PATH,'utf8');
    const data = JSON.parse(raw);
    if (typeof data !== 'object' || !data) return false;
    if (!__RT_BIAS_SNAPSHOT){ __RT_BIAS_SNAPSHOT = { ...ECON_BIAS }; }
    let changed = false;
    Object.keys(data).forEach(c=>{
      const v = parseFloat(data[c]);
      if (isFinite(v) && v>0){
        ECON_BIAS[c] = Number(v.toFixed(8)); changed = true;
      }
    });
    if (changed){ __RT_BIAS_APPLIED_TS = Date.now(); console.log('[RUNTIME_BIAS] applied overrides', ECON_BIAS); }
    return changed;
  } catch(e){ console.warn('[RUNTIME_BIAS] load failed', e.message); return false; }
}
if (process.env.ECON_RUNTIME_BIAS_ENABLE === '1'){ loadRuntimeBias(); }

// AB micro-evaluation: track post-change acceptance & income deltas; rollback if degradation crosses threshold.
const AB_EVAL_WINDOW_MS = parseInt(process.env.AB_EVAL_WINDOW_MS || '180000',10); // 3 minutes
const AB_ROLLBACK_ACCEPT_DELTA = parseFloat(process.env.AB_ROLLBACK_ACCEPT_DELTA || '-0.04'); // rollback if acceptance drops more than 4 percentage points
const AB_ROLLBACK_INCOME_RATIO = parseFloat(process.env.AB_ROLLBACK_INCOME_RATIO || '0.92'); // rollback if biased income top < 92% of pre-change top
let __AB_BASELINE = null; // { ts, acceptRatio, topIncome }
let __AB_ACTIVE = false;
function startAbBaseline(acceptRatio, topIncome){
  __AB_BASELINE = { ts: Date.now(), acceptRatio, topIncome }; __AB_ACTIVE = true; console.log('[AB] baseline started', __AB_BASELINE);
}
function maybeAbEvaluate(currentAccept, currentTopIncome){
  if (!__AB_ACTIVE || !__AB_BASELINE) return;
  const now = Date.now();
  if (now - __AB_BASELINE.ts < AB_EVAL_WINDOW_MS) return;
  const acceptDelta = currentAccept - __AB_BASELINE.acceptRatio;
  const incomeRatio = currentTopIncome > 0 ? currentTopIncome / (__AB_BASELINE.topIncome || 1) : 0;
  let rollback = false; let reason = '';
  if (acceptDelta < AB_ROLLBACK_ACCEPT_DELTA){ rollback = true; reason += 'accept-delta '; }
  if (incomeRatio < AB_ROLLBACK_INCOME_RATIO){ rollback = true; reason += 'income-ratio '; }
  if (rollback && __RT_BIAS_SNAPSHOT){
    Object.keys(__RT_BIAS_SNAPSHOT).forEach(c=>{ ECON_BIAS[c] = __RT_BIAS_SNAPSHOT[c]; });
    console.log('[AB] rollback biases -> snapshot due to', reason.trim(), 'baseline', __AB_BASELINE, 'current',{accept:currentAccept, topIncome:currentTopIncome});
    __AB_ACTIVE = false; __RT_BIAS_SNAPSHOT = null; __RT_BIAS_APPLIED_TS = null;
  } else if (!rollback){
    console.log('[AB] evaluation passed; keeping runtime biases');
    __AB_ACTIVE = false; __RT_BIAS_SNAPSHOT = null; __RT_BIAS_APPLIED_TS = null;
  }
}

// Deterministic block reward reference for income estimation (dup to avoid ordering issues with later BLOCK_REWARD const)
const ECON_BLOCK_REWARD = {
  btc: parseFloat(process.env.BTC_BLOCK_REWARD || '3.125'),
  rvn: parseFloat(process.env.RVN_BLOCK_REWARD || '5000'),
  kas: parseFloat(process.env.KAS_BLOCK_REWARD || '110'),
  fren: parseFloat(process.env.FREN_BLOCK_REWARD || '1000')
};

async function econUpdate(){
  if(!ECON.enabled) return;
  const now = Date.now(); if (now - ECON.lastFetch < ECON.intervalMs) return; ECON.lastFetch = now;
  try {
    const price = await fetchJson(ECON.api);
    if (price){ ECON.state.price.btc = price.bitcoin?.usd; ECON.state.price.rvn = price.ravencoin?.usd; ECON.state.price.kas = price.kaspa?.usd; ECON.state.price.fren = price.frencoin?.usd; }
    // Kraken integration (public ticker snapshot)
    try {
      if(process.env.KRAKEN_FEED_ENABLED==='1'){
        const kr = require('./kraken-feed-adapter.js');
        const snap = await kr.snapshot();
        // Map selected pairs to supplemental prices (prefer live where available)
        // BTC/USD or BTC/USDT overrides btc usd price if live
        const btcPair = snap['BTC/USD'] || snap['BTC/USDT'];
        if(btcPair && btcPair.last && btcPair.live){ ECON.state.price.btc = btcPair.last; }
        // For RVN/BTC and KAS/BTC derive USD if btc USD price present
        const rvnBtc = snap['RVN/BTC'];
        const kasBtc = snap['KAS/BTC'];
        if(rvnBtc && rvnBtc.last && ECON.state.price.btc){ ECON.state.price.rvn = Number((rvnBtc.last * ECON.state.price.btc).toFixed(8)); }
        if(kasBtc && kasBtc.last && ECON.state.price.btc){ ECON.state.price.kas = Number((kasBtc.last * ECON.state.price.btc).toFixed(8)); }
        // Optional price ledger append (hash chained) for audit of feed blending
        if(process.env.PRICE_LEDGER_ENABLED==='1'){
          try {
            const fs=require('fs'); const crypto=require('crypto');
            const f='price-ledger.jsonl';
            global.__PRICE_CHAIN_HASH__ = global.__PRICE_CHAIN_HASH__ || null;
            const payload={ ts:Date.now(), btc:ECON.state.price.btc, rvn:ECON.state.price.rvn, kas:ECON.state.price.kas, fren:ECON.state.price.fren, krakenLiveBTC: btcPair && btcPair.live || false };
            const raw=JSON.stringify(payload);
            const chain=crypto.createHash('sha256').update((global.__PRICE_CHAIN_HASH__||'GENESIS')+raw).digest('hex');
            global.__PRICE_CHAIN_HASH__=chain;
            let hmac=null; const key=process.env.PRICE_LEDGER_HMAC_KEY || process.env.LEDGER_HMAC_KEY; if(key){ try { hmac=crypto.createHmac('sha256',key).update(chain+raw).digest('hex'); } catch(_){ hmac=null; } }
            fs.appendFileSync(f, JSON.stringify({ ...payload, chain_hash: chain, hmac })+'\n');
          } catch(e){ console.warn('[PRICE_LEDGER] append failed', e.message); }
        }
      }
    } catch(e){ console.warn('[ECON][Kraken] feed error', e.message); }
    const [btcDiff,rvnDiff,kasDiff,frenDiff] = await Promise.all([
      fetchText(ECON.diffSources.btc),
      fetchText(ECON.diffSources.rvn),
      fetchText(ECON.diffSources.kas),
      fetchText(ECON.diffSources.fren)
    ]);
    if(btcDiff) ECON.state.diff.btc = parseFloat(btcDiff);
    if(rvnDiff) ECON.state.diff.rvn = parseFloat(rvnDiff);
    if(kasDiff) ECON.state.diff.kas = parseFloat(kasDiff);
    if(frenDiff) ECON.state.diff.fren = parseFloat(frenDiff);
    // Deterministic income estimation per coin: (reward * price) / difficulty (approx expected value scalar)
    const rawIncome = {}; const biasedIncome = {}; const coins=['btc','rvn','kas','fren'];
    coins.forEach(c=>{
      const price = ECON.state.price[c]; const diff = ECON.state.diff[c]; const reward = ECON_BLOCK_REWARD[c];
      if (price && diff && reward){
        // Use fixed precision to keep deterministic (avoid FP drift)
        const income = (reward * price) / diff; // expected value proxy
        rawIncome[c] = Number(income.toFixed(16));
        biasedIncome[c] = Number((rawIncome[c] * ECON_BIAS[c]).toFixed(16));
      }
    });
    // Provide backward compatibility scores object (price/diff) for logging / external tools
    const scores={}; coins.forEach(c=>{ if (ECON.state.price[c] && ECON.state.diff[c]) scores[c]= Number((ECON.state.price[c]/ECON.state.diff[c]).toFixed(16)); });
    ECON.state.income = { raw: rawIncome, biased: biasedIncome };
    // --- Income Persistence Ledger (hash-chained) ---
    try {
      const fs = require('fs'); const crypto = require('crypto');
      const INC_LEDGER = process.env.INCOME_LEDGER_PATH || 'income-ledger.jsonl';
      if (!global.__INC_LEDGER_HASH__){
        if (fs.existsSync(INC_LEDGER)){
          try { const lines = fs.readFileSync(INC_LEDGER,'utf8').trim().split(/\n+/); const last = lines[lines.length-1]; const obj=JSON.parse(last); global.__INC_LEDGER_HASH__ = obj.chainHash || 'GENESIS'; } catch(_){ global.__INC_LEDGER_HASH__='GENESIS'; }
        } else { global.__INC_LEDGER_HASH__='GENESIS'; }
      }
      const topCoinTmp = Object.entries(biasedIncome).sort((a,b)=> b[1]-a[1] || a[0].localeCompare(b[0]))[0]?.[0] || null;
      const entry = {
        t: Date.now(),
        price: ECON.state.price,
        diff: ECON.state.diff,
        incomeRaw: rawIncome,
        incomeBiased: biasedIncome,
        topCoin: topCoinTmp,
        prevHash: global.__INC_LEDGER_HASH__
      };
      const chainHash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
      entry.chainHash = chainHash;
      fs.appendFileSync(INC_LEDGER, JSON.stringify(entry)+"\n");
      global.__INC_LEDGER_HASH__ = chainHash;
    } catch(e){ console.warn('[INCOME_LEDGER] append failed', e.message); }
    const ranked = Object.entries(biasedIncome).sort((a,b)=>{
      if (b[1] === a[1]){
        // Deterministic tie-breaker: hash coin labels to stable integer
        const crypto = require('crypto');
        const ha = parseInt(crypto.createHash('sha256').update(a[0]).digest('hex').slice(0,8),16);
        const hb = parseInt(crypto.createHash('sha256').update(b[0]).digest('hex').slice(0,8),16);
        return ha - hb;
      }
      return b[1] - a[1];
    });
    if (ranked.length >= 2){
      const bestCoin = ranked[0][0];
      if (ECON.lastRecommendation === bestCoin){
        ECON.stableCount++;
      } else {
        ECON.lastRecommendation = bestCoin; ECON.stableCount = 1;
      }
      if (ECON.stableCount >= ECON.hysteresisCycles){
        if (ECON.state.recommend !== bestCoin){
          ECON.state.recommend = bestCoin;
          console.log('[ECON] switch ->', bestCoin,'income(raw)', rawIncome,'income(biased)', biasedIncome,'scores', scores);
        }
      } else {
        if (!ECON.state.recommend) ECON.state.recommend = bestCoin; // first time
      }
      // Prometheus gauge updates (if econ gauges are registered externally)
      if (global.__AUR_ECON_GAUGES__){
        try {
          const map={rvn:1,btc:2,kas:3,fren:4};
          global.__AUR_ECON_GAUGES__.coinRecommendation.set(map[ECON.state.recommend]||0);
          if (global.__AUR_ECON_GAUGES__.incomeBTC){
            global.__AUR_ECON_GAUGES__.incomeBTC.set(rawIncome.btc||0);
            global.__AUR_ECON_GAUGES__.incomeRVN.set(rawIncome.rvn||0);
            global.__AUR_ECON_GAUGES__.incomeKAS.set(rawIncome.kas||0);
            global.__AUR_ECON_GAUGES__.incomeFREN.set(rawIncome.fren||0);
              // FREN revenue per hash gauges (smoothed & raw) if available
              try {
                if (!global.__AUR_ECON_GAUGES__.frenRevenuePerHash){
                  const prom=require('prom-client');
                  global.__AUR_ECON_GAUGES__.frenRevenuePerHash = new prom.Gauge({ name:'aurrelia_fren_revenue_per_hash', help:'Raw FREN revenue per hash (price*reward/diff)' });
                  global.__AUR_ECON_GAUGES__.frenRevenuePerHashSmoothed = new prom.Gauge({ name:'aurrelia_fren_revenue_per_hash_smoothed', help:'Smoothed FREN revenue per hash (EMA)' });
                  global.__AUR_ECON_GAUGES__.frenRevenueNorm = new prom.Gauge({ name:'aurrelia_fren_revenue_norm', help:'Normalized FREN revenue per hash (0-1 vs top income)' });
                }
                if (ECON.state && typeof ECON.state.frenRevenuePerHash === 'number'){
                  global.__AUR_ECON_GAUGES__.frenRevenuePerHash.set(ECON.state.frenRevenuePerHash);
                }
                if (ECON.state && typeof ECON.state.frenRevenuePerHashSmoothed === 'number'){
                  global.__AUR_ECON_GAUGES__.frenRevenuePerHashSmoothed.set(ECON.state.frenRevenuePerHashSmoothed);
                }
                if (typeof frenRevenueNorm === 'number'){
                  global.__AUR_ECON_GAUGES__.frenRevenueNorm.set(frenRevenueNorm);
                }
              } catch(_){ }
            const top = rawIncome[bestCoin] || 0;
            // Spread ratio: (top - second)/top for diversification insight
            const second = ranked[1] ? rawIncome[ ranked[1][0] ] : 0;
            const spread = top>0 ? (top - second)/top : 0;
            global.__AUR_ECON_GAUGES__.incomeTop.set(top);
            global.__AUR_ECON_GAUGES__.incomeSpread.set(Number(spread.toFixed(16)));
            // AB micro-eval hooks
            const acceptRatio = (pipeline && pipeline.shareStats && typeof pipeline.shareStats.acceptanceRatio === 'number') ? pipeline.shareStats.acceptanceRatio : 0;
            if (__RT_BIAS_APPLIED_TS && !__AB_ACTIVE){
              startAbBaseline(acceptRatio, top);
            } else if (__AB_ACTIVE){
              maybeAbEvaluate(acceptRatio, top);
            }
            // ML advisor deterministic invocation
            if (process.env.ML_ADVISOR === '1'){
              try {
                if (!global.__AUR_ML_ADVISOR__){ global.__AUR_ML_ADVISOR__ = require('./deterministic-ml-advisor.js'); }
                const latencyMap = {}; // optionally populate from pool-latency.json
                try { const fs=require('fs'); if(fs.existsSync('pool-latency.json')){ const js=JSON.parse(fs.readFileSync('pool-latency.json','utf8')); const arr=js.results||[]; arr.forEach(r=>{ if(r.ok && typeof r.connectMs==='number' && r.coin) latencyMap[r.coin.toLowerCase()] = r.connectMs; }); } } catch(_){ }
                const latVals = Object.values(latencyMap).filter(v=> typeof v==='number');
                const latMedian = latVals.length? latVals.slice().sort((a,b)=>a-b)[Math.floor(latVals.length/2)] : 0;
                // Normalize FREN revenue per hash for advisor (min-max within recent window or relative to top income)
                let frenRevenueNorm = 0;
                try {
                  const frRaw = ECON.state && ECON.state.frenRevenuePerHashSmoothed;
                  if (typeof frRaw === 'number' && frRaw > 0){
                    // Use biasedIncome top as scaling reference
                    const topIncome = Math.max(...Object.values(rawIncome).filter(v=> typeof v==='number' && v>0));
                    if (topIncome>0) frenRevenueNorm = Math.min(1, frRaw / topIncome);
                  }
                } catch(_){ }
                const resAdvisor = global.__AUR_ML_ADVISOR__.advise({ acceptRatio, latencyMedian:latMedian, incomeSpread:spread, biasFREN:ECON_BIAS.fren, biasRVN:ECON_BIAS.rvn, frenRevenueNorm });
                if (resAdvisor && resAdvisor.score != null){
                  if (global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges){
                    const g = global.__AUR_METRICS_REG__.gauges;
                    if (!g.mlAdvisorScore){ const prom=require('prom-client'); g.mlAdvisorScore = new prom.Gauge({ name:'aurrelia_ml_advisor_score', help:'Deterministic ML advisor normalized score' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.mlAdvisorScore); }
                    if (!g.mlAdvisorAction){ const prom=require('prom-client'); g.mlAdvisorAction = new prom.Gauge({ name:'aurrelia_ml_advisor_action_code', help:'ML advisor action code (noop=0, biasInc=1, biasDec=2)' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.mlAdvisorAction); }
                    if (!g.mlAdvisorWeightsVersion){ const prom=require('prom-client'); g.mlAdvisorWeightsVersion = new prom.Gauge({ name:'aurrelia_ml_advisor_weights_version', help:'ML advisor weights version hash indicator', labelNames:['version'] }); global.__AUR_METRICS_REG__.registry.registerMetric(g.mlAdvisorWeightsVersion); }
                    // Set weights version gauge once (value constant =1) labeled by version
                    try { if (resAdvisor.versionHash && resAdvisor.modelVersion){ g.mlAdvisorWeightsVersion.set({version: resAdvisor.modelVersion+'-'+resAdvisor.versionHash.slice(0,12)}, 1); } } catch(_){ }
                    g.mlAdvisorScore.set(resAdvisor.score);
                    const aCode = resAdvisor.action==='suggest_bias_increase'?1: resAdvisor.action==='suggest_bias_reduce'?2:0;
                    g.mlAdvisorAction.set(aCode);
                  }
                  console.log('[ML-ADVISOR]', 'score='+resAdvisor.score, 'action='+resAdvisor.action, 'delta='+resAdvisor.delta, 'frenRevenueNorm='+frenRevenueNorm.toFixed(4), 'digest='+resAdvisor.digest.slice(0,16));
                }
              } catch(e){ console.warn('[ML-ADVISOR] error', e.message); }
            }
          }
        } catch(_){ }
      }
      // Deterministic wallet companion advisory (no side-effects)
      try {
        if (process.env.WALLET_COMPANION === '1'){
          if (!global.__AUR_WALLET_COMPANION__){
            try { global.__AUR_WALLET_COMPANION__ = require('./seraphina-wallet-companion.js'); } catch(e){ console.warn('[COMPANION] load failed', e.message); }
          }
          if (global.__AUR_WALLET_COMPANION__ && typeof global.__AUR_WALLET_COMPANION__.companionCycle === 'function'){
            const latencyPath = process.env.COMPANION_LAT_SAMPLE_PATH || 'pool-latency.json';
            const res = global.__AUR_WALLET_COMPANION__.companionCycle(process.env, { recommend: ECON.state.recommend, latencyPath });
            // Log compact suggestion summary (ids + digest) for audit chain; no auto-execution
            if (res && res.suggestion){
              const ids = res.suggestion.suggestions.map(s=>s.id+':'+s.type).join(',');
              console.log('[COMPANION]', 'digest='+res.suggestion.digest, 'suggestions='+ids);
              // --- Companion Suggestion Ledger Append (hash-chained) ---
              try {
                const fs = require('fs');
                const crypto = require('crypto');
                const LEDGER_FILE = process.env.COMPANION_LEDGER_PATH || 'companion-suggestions.jsonl';
                if (!global.__AUR_COMP_LEDGER_LAST_HASH__){
                  if (fs.existsSync(LEDGER_FILE)){
                    try {
                      const lines = fs.readFileSync(LEDGER_FILE,'utf8').trim().split(/\n+/);
                      const lastLine = lines[lines.length-1];
                      const parsed = JSON.parse(lastLine);
                      global.__AUR_COMP_LEDGER_LAST_HASH__ = parsed.chainHash || 'GENESIS';
                    } catch(_) { global.__AUR_COMP_LEDGER_LAST_HASH__ = 'GENESIS'; }
                  } else {
                    global.__AUR_COMP_LEDGER_LAST_HASH__ = 'GENESIS';
                  }
                }
                const entry = {
                  t: Date.now(),
                  recommend: ECON.state.recommend || null,
                  suggestions: res.suggestion.suggestions.map(s=>({ id:s.id, type:s.type, conf:s.confidence })),
                  digest: res.suggestion.digest,
                  prevHash: global.__AUR_COMP_LEDGER_LAST_HASH__
                };
                const chainHash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
                entry.chainHash = chainHash;
                fs.appendFileSync(LEDGER_FILE, JSON.stringify(entry)+"\n");
                global.__AUR_COMP_LEDGER_LAST_HASH__ = chainHash;
                // Companion gauges update
                if (global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges){
                  const g = global.__AUR_METRICS_REG__.gauges;
                  if (g.companionSuggestionCount) g.companionSuggestionCount.set(res.suggestion.suggestions.length);
                  if (g.companionTopConfidence){
                    const maxConf = res.suggestion.suggestions.reduce((m,s)=> s.confidence>m? s.confidence : m, 0);
                    g.companionTopConfidence.set(Number(maxConf.toFixed(6)));
                  }
                }
              } catch(e){ console.warn('[COMPANION] ledger append failed', e.message); }
              // --- Policy Engine Evaluation (dry-run bias apply) ---
              try {
                if (process.env.WALLET_COMPANION_POLICY === '1'){
                  if (!global.__AUR_COMP_POLICY__){
                    try { global.__AUR_COMP_POLICY__ = require('./companion-policy-engine.js'); } catch(pe){ console.warn('[POLICY] load failed', pe.message); }
                  }
                  if (global.__AUR_COMP_POLICY__ && typeof global.__AUR_COMP_POLICY__.evaluateSuggestions === 'function'){
                    const polRes = global.__AUR_COMP_POLICY__.evaluateSuggestions(res.suggestion.digest, res.suggestion.suggestions, { recommend: ECON.state.recommend });
                    if (polRes && polRes.decision){
                      console.log('[POLICY]', polRes.reason, 'decision='+JSON.stringify(polRes.decision), 'hash='+polRes.hash.slice(0,16));
                      // Actual bias application deferred / guarded; only log deterministic decision.
                      if (polRes.decision.action === 'apply_bias' && process.env.ECON_POLICY_APPLY === '1'){
                        // Apply bias delta safely: mutate ECON_BIAS[coin] within bounds (keep deterministic rounding)
                        const c = polRes.decision.coin;
                        const newBias = Number((ECON_BIAS[c] + polRes.decision.delta).toFixed(8));
                        // Clamp bias to sane range [0.01, 10] to prevent runaway
                        const clamped = Math.min(10, Math.max(0.01, newBias));
                        ECON_BIAS[c] = clamped;
                        console.log('[POLICY] bias applied coin='+c+' delta='+polRes.decision.delta+' newBias='+clamped);
                      }
                    }
                  }
                }
              } catch(e){ console.warn('[POLICY] error', e.message); }
              // --- Trading Engine Advisory (income-driven) ---
              try {
                if (process.env.TRADING_ENGINE === '1'){
                  if (!global.__AUR_TRADING_ENGINE__){
                    try { global.__AUR_TRADING_ENGINE__ = require('./aurrelia-trading-engine.js'); } catch(te){ console.warn('[TRADING] load failed', te.message); }
                  }
                  if (global.__AUR_TRADING_ENGINE__ && typeof global.__AUR_TRADING_ENGINE__.evaluate === 'function'){
                    const latencyMap = (()=>{ // parse latency file if exists
                      const p = process.env.COMPANION_LAT_SAMPLE_PATH || 'pool-latency.json';
                      try { const fs=require('fs'); if (fs.existsSync(p)){ return JSON.parse(fs.readFileSync(p,'utf8')); } } catch(_){}
                      return {};
                    })();
                    const tradeRes = global.__AUR_TRADING_ENGINE__.evaluate(ECON.state.income?.raw, ECON.state.income?.biased, latencyMap, ECON.state.recommend);
                    if (tradeRes && tradeRes.signal){
                      console.log('[TRADING]', tradeRes.reason, 'signal='+JSON.stringify(tradeRes.signal), 'hash='+tradeRes.hash.slice(0,16));
                      if (global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges){
                        const g = global.__AUR_METRICS_REG__.gauges;
                        if (!g.tradeSpread){ const prom=require('prom-client'); g.tradeSpread = new prom.Gauge({ name:'aurrelia_trade_spread', help:'Raw spread between top and second income coin' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeSpread); }
                        if (!g.tradeAdjSpread){ const prom=require('prom-client'); g.tradeAdjSpread = new prom.Gauge({ name:'aurrelia_trade_adjusted_spread', help:'Latency-adjusted income spread' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeAdjSpread); }
                        if (!g.tradeAction){ const prom=require('prom-client'); g.tradeAction = new prom.Gauge({ name:'aurrelia_trade_action_code', help:'Trade action code (hold=0, swap=1)' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeAction); }
                        if (!g.tradeVolatility){ const prom=require('prom-client'); g.tradeVolatility = new prom.Gauge({ name:'aurrelia_trade_volatility', help:'Rolling spread volatility (std dev)' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeVolatility); }
                        if (!g.tradeThreshold){ const prom=require('prom-client'); g.tradeThreshold = new prom.Gauge({ name:'aurrelia_trade_dynamic_threshold', help:'Dynamic spread threshold applied after volatility scaling' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeThreshold); }
                        if (!g.tradeLearnedThreshold){ const prom=require('prom-client'); g.tradeLearnedThreshold = new prom.Gauge({ name:'aurrelia_trade_learned_threshold', help:'Learned adaptive threshold after multiplier' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeLearnedThreshold); }
                        if (!g.tradeNetSpread){ const prom=require('prom-client'); g.tradeNetSpread = new prom.Gauge({ name:'aurrelia_trade_net_spread', help:'Net spread after fee/slippage cost' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeNetSpread); }
                        if (!g.tradeFeeRate){ const prom=require('prom-client'); g.tradeFeeRate = new prom.Gauge({ name:'aurrelia_trade_fee_rate', help:'Configured fee/slippage rate applied to trades' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.tradeFeeRate); }
                        g.tradeSpread.set(tradeRes.signal.spread||0);
                        g.tradeAdjSpread.set(tradeRes.signal.adjustedSpread||0);
                        g.tradeAction.set(tradeRes.signal.action==='swap'?1:0);
                        g.tradeVolatility.set(tradeRes.signal.volatility||0);
                        g.tradeThreshold.set(tradeRes.signal.threshold||0);
                        if (tradeRes.signal.learnedThreshold!=null){ g.tradeLearnedThreshold.set(tradeRes.signal.learnedThreshold); }
                        if (tradeRes.signal.netSpread!=null){ g.tradeNetSpread.set(tradeRes.signal.netSpread); }
                        if (tradeRes.signal.feeRate!=null){ g.tradeFeeRate.set(tradeRes.signal.feeRate); }
                      }
                    }
                  }
                }
              } catch(e){ console.warn('[TRADING] error', e.message); }
            }
          }
        }
      } catch(e){ console.warn('[COMPANION] error', e.message); }
    }
  } catch(e){ console.warn('[ECON] update error', e.message); }
}
setInterval(econUpdate, 60000).unref(); econUpdate();

// Governance engine periodic evaluation
if (process.env.GOVERNANCE_ENGINE === '1'){
  try {
    global.__AUR_GOV_ENGINE__ = require('./governance-engine.js');
    const GOV_INTERVAL_MS = parseInt(process.env.GOV_INTERVAL_MS || '300000',10); // 5m default
    setInterval(()=>{ try { global.__AUR_GOV_ENGINE__.governanceCycle(); } catch(_){} }, GOV_INTERVAL_MS).unref();
  } catch(e){ console.warn('[GOV] load failed', e.message); }
}

// Coin auto-switch logic applying ECON.state.recommend (hysteresis already handled in econUpdate)
// Safe + conservative: only switch after stable recommendation and cooldown.
let __ECON_LAST_SWITCH = 0;
let __ECON_LAST_SWITCH_COOLDOWN_MS = null; // dynamic per-switch cooldown (allows extension after rollback)
// Persisted economic autoswitch metadata (loaded later with adaptive state)
let __ECON_ACTIVE_COIN = null; // will mirror pipeline.selectedCoin once pipeline constructed
let __ECON_SWITCH_TOTAL = 0; // in-memory counters (Prom gauges will expose)
let __ECON_SWITCH_FAIL = 0;
let __ECON_LAST_SWITCH_REASON = 'boot';
let __ECON_LAST_PRE_SWITCH_ACCEPT = null;
// --- Share Ledger Chain (append-only, hash chained) ---
const __SHARE_LEDGER_FILE = 'share-ledger.jsonl';
let __SHARE_LAST_HASH = null; // previous entry chain hash
function appendShareLedger(entry){
// --- Swap Ledger (hash chained) helper definitions (added) ---
}
// --- Parity Digest Chain (multi-protocol normalization) ---
const __PARITY_LEDGER_FILE = 'parity-ledger.jsonl';
let __PARITY_LAST_HASH = null;
function appendParityDigest(meta){
  try {
    const fs=require('fs'); const crypto=require('crypto');
    // Normalization: convert share to canonical difficulty units (BTC baseline) using network difficulty ratios.
    // canonicalDifficulty = (poolDifficulty || difficulty) / (netDiffCoin) * netDiffBTC
    const coin = meta.coin || null;
    const netDiffBTC = (ECON && ECON.state && ECON.state.diff && ECON.state.diff.btc) ? ECON.state.diff.btc : null;
    const netDiffCoin = (coin && ECON && ECON.state && ECON.state.diff && ECON.state.diff[coin]) ? ECON.state.diff[coin] : null;
    const poolDiff = typeof meta.poolDifficulty === 'number' ? meta.poolDifficulty : (typeof meta.difficulty === 'number' ? meta.difficulty : null);
    let canonicalDifficulty = null;
    if(netDiffBTC && netDiffCoin && poolDiff){
      canonicalDifficulty = (poolDiff / netDiffCoin) * netDiffBTC;
      if(!isFinite(canonicalDifficulty)) canonicalDifficulty=null; else canonicalDifficulty = Number(canonicalDifficulty.toFixed(12));
    }
    const payload = {
      ts: Date.now(),
      coin,
      jobId: meta.jobId || null,
      nonce: meta.nonce || null,
      poolDifficulty: typeof meta.poolDifficulty === 'number'? meta.poolDifficulty : null,
      difficulty: typeof meta.difficulty === 'number'? meta.difficulty : null,
      canonicalDifficulty,
      creditEst: typeof meta.creditEst === 'number'? meta.creditEst : null,
      source: 'parity'
    };
    const raw = JSON.stringify(payload);
    const chainHash = crypto.createHash('sha256').update((__PARITY_LAST_HASH||'GENESIS') + raw).digest('hex');
    __PARITY_LAST_HASH = chainHash;
    let hmac=null; const key = process.env.PARITY_LEDGER_HMAC_KEY || process.env.LEDGER_HMAC_KEY;
    if(key){ try { hmac = crypto.createHmac('sha256', key).update(chainHash + raw).digest('hex'); } catch(_){ hmac=null; } }
    fs.appendFileSync(__PARITY_LEDGER_FILE, JSON.stringify({ ...payload, chain_hash: chainHash, hmac })+'\n');
  } catch(e){ console.warn('[PARITY_LEDGER] append failed', e.message); }
}
const __SWAP_LEDGER_FILE = 'swap-ledger.jsonl';
let __SWAP_LAST_HASH = null;
function appendSwapLedger(entry){
  try {
    const fs = require('fs'); const crypto = require('crypto');
    const payload = {
      ts: Date.now(),
      event: entry.event || null,
      id: entry.id || null,
      from: entry.from || null,
      to: entry.to || null,
      amount: typeof entry.amount === 'number' ? entry.amount : null,
      rate: typeof entry.rate === 'number' ? entry.rate : null,
      live: entry.live ? true : false,
      status: entry.status || null,
      orderId: entry.orderId || null,
      depositAddress: entry.depositAddress || null,
      txid: entry.txid || null,
      confirmations: typeof entry.confirmations === 'number' ? entry.confirmations : null,
      error: entry.error || null
    };
    const raw = JSON.stringify(payload);
    const chainHash = crypto.createHash('sha256').update((__SWAP_LAST_HASH||'GENESIS') + raw).digest('hex');
    __SWAP_LAST_HASH = chainHash;
    let hmac = null; const key = process.env.SWAP_LEDGER_HMAC_KEY || process.env.LEDGER_HMAC_KEY;
    if (key){ try { hmac = crypto.createHmac('sha256', key).update(chainHash + raw).digest('hex'); } catch(_){ hmac=null; } }
    fs.appendFileSync(__SWAP_LEDGER_FILE, JSON.stringify({ ...payload, chain_hash: chainHash, hmac })+'\n');
  } catch(e){ console.warn('[SWAP_LEDGER] append failed', e.message); }
}
// --- Econ Realization Ledger (P&L events) ---
const __ECON_REAL_LEDGER_FILE = 'econ-realization-ledger.jsonl';
let __ECON_REAL_LAST_HASH = null;
function appendEconRealization(ev){
  try {
    const fs=require('fs'); const crypto=require('crypto');
    const payload = {
      ts: Date.now(),
      type: ev.type || null,
      swapId: ev.swapId || null,
      from: ev.from || null,
      to: ev.to || null,
      amountFrom: typeof ev.amountFrom==='number'? ev.amountFrom : null,
      rateUsed: typeof ev.rateUsed==='number'? ev.rateUsed : null,
      usdBTC: typeof ev.usdBTC==='number'? ev.usdBTC : null,
      usdRVN: typeof ev.usdRVN==='number'? ev.usdRVN : null,
      usdKAS: typeof ev.usdKAS==='number'? ev.usdKAS : null,
      usdFREN: typeof ev.usdFREN==='number'? ev.usdFREN : null,
      preCreditUSD: typeof ev.preCreditUSD==='number'? ev.preCreditUSD : null,
      realizedUSD: typeof ev.realizedUSD==='number'? ev.realizedUSD : null,
      pnlDeltaUSD: typeof ev.pnlDeltaUSD==='number'? ev.pnlDeltaUSD : null,
      live: ev.live? true:false,
      status: ev.status || null,
      confirmations: typeof ev.confirmations==='number'? ev.confirmations : null
    };
    const raw = JSON.stringify(payload);
    const chainHash = crypto.createHash('sha256').update((__ECON_REAL_LAST_HASH||'GENESIS') + raw).digest('hex');
    __ECON_REAL_LAST_HASH = chainHash;
    let hmac=null; const key=process.env.ECON_REAL_LEDGER_HMAC_KEY || process.env.LEDGER_HMAC_KEY; if(key){ try { hmac=crypto.createHmac('sha256',key).update(chainHash + raw).digest('hex'); } catch(_){ hmac=null; } }
    fs.appendFileSync(__ECON_REAL_LEDGER_FILE, JSON.stringify({ ...payload, chain_hash: chainHash, hmac })+'\n');
  } catch(e){ console.warn('[ECON_REAL_LEDGER] append failed', e.message); }
}
// --- End Swap Ledger additions ---
function appendShareLedger(entry){
// --- Environment Hardcoded Address / Key Audit (REAL_STRICT) ---
try {
  if (process.env.REAL_STRICT === '1'){
    const fs = require('fs'); const path = require('path');
    const rootDir = __dirname;
    const suspectPatterns = [
      process.env.BTC_MINING_ADDRESS,
      process.env.RVN_LOCAL_ADDRESS,
      process.env.BTC_KRAKEN_ADDRESS || process.env.KRAKEN_BTC_ADDRESS,
      process.env.LTC_KRAKEN_ADDRESS,
      process.env.SIMPLESWAP_API_KEY
    ].filter(Boolean).map(x=> String(x).trim()).filter(x=> x.length>8);
    const findings = [];
    function scanFile(fp){
      try {
        const rel = path.relative(rootDir, fp);
        if (/node_modules|\.git|persistent_data|\.json$|\.jsonl$|\.log$/i.test(rel)) return; // skip common dirs and data files
        const content = fs.readFileSync(fp,'utf8');
        suspectPatterns.forEach(pat=>{ if (pat && content.includes(pat)){ findings.push({ file: rel, pattern: pat }); } });
      } catch(_){ }
    }
    function walk(dir){
      try { fs.readdirSync(dir).forEach(name=>{ const fp = path.join(dir,name); try { const st=fs.statSync(fp); if (st.isDirectory()) walk(fp); else scanFile(fp); } catch(_){ } }); } catch(_){ }
    }
    walk(rootDir);
    if (findings.length){
      console.error('[STRICT_AUDIT] Hardcoded sensitive values detected:', JSON.stringify(findings));
      console.error('[STRICT_AUDIT] Aborting startup due to REAL_STRICT policy. Remove hardcoded addresses/API keys from source.');
      process.exit(13);
    } else {
      console.log('[STRICT_AUDIT] Passed (no hardcoded sensitive values).');
    }
  }
} catch(e){ console.warn('[STRICT_AUDIT] error', e.message); }
  try {
    const fs = require('fs'); const crypto = require('crypto');
    // Minimal deterministic ordering of fields
    const payload = {
      ts: Date.now(),
      coin: entry.coin || null,
      jobId: entry.jobId || null,
  difficulty: typeof entry.difficulty === 'number' ? entry.difficulty : null,
  poolDifficulty: typeof entry.poolDifficulty === 'number' ? entry.poolDifficulty : null,
  shareTarget: entry.shareTarget || null,
      targetHex: entry.targetHex || null,
      nonce: entry.nonce || null,
      creditEst: typeof entry.creditEst === 'number' ? entry.creditEst : null,
      source: entry.source || 'stratum',
      acceptLatencyMs: typeof entry.acceptLatencyMs === 'number' ? entry.acceptLatencyMs : null
    };
    const raw = JSON.stringify(payload);
    const chainHash = crypto.createHash('sha256').update((__SHARE_LAST_HASH||'GENESIS') + raw).digest('hex');
    __SHARE_LAST_HASH = chainHash;
    // Optional HMAC sealing for payload+chainHash (integrity & tamper-evidence)
    let hmac = null;
    if (process.env.LEDGER_HMAC_KEY){
      try { hmac = crypto.createHmac('sha256', process.env.LEDGER_HMAC_KEY).update(chainHash + raw).digest('hex'); } catch(_){ hmac = null; }
    }
    fs.appendFileSync(__SHARE_LEDGER_FILE, JSON.stringify({ ...payload, chain_hash: chainHash, hmac })+'\n');
  } catch(e){ console.warn('[SHARE_LEDGER] append failed', e.message); }
}

// --- Stratum share acceptance hook (install once pipeline built later) ---
function bindShareLedgerToStratum(stratum, activeCoinResolver){
  if (!stratum || stratum._shareLedgerBound) return;
  stratum.on('shareAccepted', info => {
    try {
      const coin = typeof activeCoinResolver === 'function' ? activeCoinResolver() : null; // Get the active coin
      // Estimated credit using pool difficulty and network difficulty (if ECON state available)
      let creditEst = null;
      try {
        if (typeof estimateShareCredit === 'function') creditEst = estimateShareCredit(coin);
      } catch(_){ creditEst = null; }
      const poolDiff = (global.__AUR_POOL_DIFF__ && coin) ? global.__AUR_POOL_DIFF__[coin] : (global.__AUR_LAST_DIFF || null);
      appendShareLedger({
        coin,
        jobId: info.jobId || null,
        nonce: info.nonce || null,
        // Difficulty & target placeholders (will refine with share difficulty accounting)
        difficulty: global.__AUR_LAST_DIFF || null,
        poolDifficulty: poolDiff || null,
        targetHex: global.__AUR_LAST_TARGET_HEX || null,
        creditEst: creditEst,
        source: 'stratum',
        acceptLatencyMs: info.acceptLatencyMs || null
      });
      // Parity digest append (normalized difficulty chain)
      appendParityDigest({
        coin,
        jobId: info.jobId || null,
        nonce: info.nonce || null,
        difficulty: global.__AUR_LAST_DIFF || null,
        poolDifficulty: poolDiff || null,
        creditEst: creditEst
      });
    } catch(e){ console.warn('[SHARE_LEDGER] stratum hook error', e.message); }
  });
  // Pool difficulty tracking
  stratum.on('difficulty', d => {
    if (d && typeof d.difficulty === 'number'){
      if (!global.__AUR_POOL_DIFF__) global.__AUR_POOL_DIFF__ = {};
      global.__AUR_POOL_DIFF__[d.coin || (activeCoinResolver && activeCoinResolver()) || 'unknown'] = d.difficulty;
      global.__AUR_LAST_DIFF = d.difficulty; // backward compat for existing placeholder
    }
  });
  stratum._shareLedgerBound = true;
}

  // --- Share Credit Estimation (FPPS stub) ---
  if (typeof global.estimateShareCredit !== 'function'){
    global.estimateShareCredit = function estimateShareCredit(coin){
      try {
        if (!coin) return null;
        // Network difficulty & pool difficulty sources
        const netDiff = ECON && ECON.state && ECON.state.diff ? ECON.state.diff[coin] : null;
        const poolDiff = (global.__AUR_POOL_DIFF__ && global.__AUR_POOL_DIFF__[coin]) ? global.__AUR_POOL_DIFF__[coin] : null;
        if (!netDiff || !poolDiff) return null;
        // Block rewards (approx; update on halving/fork)
        const BLOCK_REWARD = {
          btc: parseFloat(process.env.BTC_BLOCK_REWARD || '3.125'), // adjust if post-2024 halving
          rvn: parseFloat(process.env.RVN_BLOCK_REWARD || '2500'),
          kas: parseFloat(process.env.KAS_BLOCK_REWARD || '103'),
          fren: parseFloat(process.env.FREN_BLOCK_REWARD || '0')
        };
        const reward = BLOCK_REWARD[coin];
        if (!reward) return null;
        // Simplified credit: reward * (poolDiff / netDiff) * FPPS_FACTOR
        const FPPS_FACTOR = parseFloat(process.env.FPPS_FACTOR || '1');
        const credit = reward * (poolDiff / netDiff) * FPPS_FACTOR;
        if (!isFinite(credit)) return null;
        return Number(credit.toFixed(12));
      } catch(e){ return null; }
    };
  }

  // --- Deterministic Repro Cycle Limit Support ---
  let __REPRO_CYCLE_LIMIT = parseInt(process.env.AUR_REPRO_CYCLE_LIMIT||'0',10);
  let __REPRO_CYCLE_COUNT = 0;
  let __REPRO_DIGEST_CHAIN = null;
  function __reproDigestUpdate(label, payload){
    try {
      const crypto = require('crypto');
      const raw = JSON.stringify({label,payload});
      __REPRO_DIGEST_CHAIN = crypto.createHash('sha256').update((__REPRO_DIGEST_CHAIN||'GENESIS') + raw).digest('hex');
    } catch(_){ }
  }
  // Repro state load (optional)
  if (process.env.AUR_REPRO_STATE_IN){
    try {
      const fs = require('fs');
      if (fs.existsSync(process.env.AUR_REPRO_STATE_IN)){
        const obj = JSON.parse(fs.readFileSync(process.env.AUR_REPRO_STATE_IN,'utf8'));
        if (obj && typeof obj.cycleCount === 'number' && typeof obj.chainHead === 'string'){
          __REPRO_CYCLE_COUNT = obj.cycleCount;
          __REPRO_DIGEST_CHAIN = obj.chainHead;
          console.log('[REPRO] State restored cycles='+__REPRO_CYCLE_COUNT+' chainHead='+__REPRO_DIGEST_CHAIN.slice(0,16)+'...');
        }
      }
    } catch(e){ console.warn('[REPRO] state restore failed', e.message); }
  }
  function __reproPersistState(){
    if (!process.env.AUR_REPRO_STATE_OUT) return;
    try {
      const fs = require('fs');
      const snap = { cycleCount: __REPRO_CYCLE_COUNT, chainHead: __REPRO_DIGEST_CHAIN };
      fs.writeFileSync(process.env.AUR_REPRO_STATE_OUT, JSON.stringify(snap));
    } catch(e){ console.warn('[REPRO] state persist failed', e.message); }
  }

// --- Readiness Aggregator ---
let __READINESS_LAST = null;
function computeReadiness(p){
  const now = Date.now();
  const jobAge = p && p.job && p.job.jobId ? (now - (p._lastJobTs||now)) : null;
  const shareAge = p && p._lastRealShareTs ? (now - p._lastRealShareTs) : null;
  const econRec = ECON && ECON.state && ECON.state.recommend || null;
  const walletSealed = process.env.WALLET_HMAC_ENFORCE === '1' ? (global.__AUR_WALLET_SEALED===true) : 'unknown';
  const integrityStrict = process.env.STRICT_INTEGRITY === '1';
  const swapMode = process.env.SIMPLESWAP_MODE || null;
  const lastChainHash = __SHARE_LAST_HASH || null;
  const readiness = {
    ts: now,
    jobAgeMs: jobAge,
    shareAgeMs: shareAge,
    econRecommend: econRec,
    walletSealed,
    integrityStrict,
    swapMode,
    shareChainTip: lastChainHash,
    gpuEnabled: GPU_ENABLED || false,
    kawpowNative: !!global.kawpowNative,
    activeCoin: p && p.selectedCoin || null
  };
  __READINESS_LAST = readiness;
  return readiness;
}

// --- Share Credit Estimation ---
// Approximate FPPS-like credit per accepted share: (blockReward / networkDifficulty) * poolDifficultyFactor
// For Bitcoin: blockReward halves every era; for RVN constant for now. We can map via static table.
const BLOCK_REWARD = { btc: parseFloat(process.env.BTC_BLOCK_REWARD || '3.125'), rvn: parseFloat(process.env.RVN_BLOCK_REWARD || '5000'), kas: parseFloat(process.env.KAS_BLOCK_REWARD || '110'), fren: parseFloat(process.env.FREN_BLOCK_REWARD || '1000') };
function estimateShareCredit(coin){
  try {
    if (!coin) return 0;
    const netDiff = ECON && ECON.state && ECON.state.diff && ECON.state.diff[coin];
    const poolDiff = global.__AUR_POOL_DIFF__ && global.__AUR_POOL_DIFF__[coin];
    if (!netDiff || !poolDiff) return 0;
    const reward = BLOCK_REWARD[coin] || 0;
    if (!reward) return 0;
    // Simplified: shareCredit ~ reward * (poolDiff / netDiff) * scale
    // scale may be tuned; using 1 for now. Future: incorporate target normalization.
    const credit = reward * (poolDiff / netDiff);
    if (credit < 0) return 0;
    return credit;
  } catch(e){ return 0; }
}



let __ECON_LAST_DELTA_EMITTED_AT = 0; // timestamp when last acceptance delta emitted
let __ECON_LAST_FROM_COIN = null; // previous coin code captured at switch time for delta labeling
let __ECON_SHADOW_MODE = (process.env.ECON_AUTOSWITCH_SHADOW === '1');
let __ECON_ROLLBACK_THRESHOLD = parseFloat(process.env.ECON_ROLLBACK_THRESHOLD || '0.8');
const __ECON_ROLLBACK_ENABLE = process.env.ECON_ROLLBACK_DISABLE === '1' ? false : true;
// Structured log helper (safe JSON) – can be consumed by log pipeline
function econStructuredLog(type, data){
  try { const obj = { schema: __ECON_LOG_SCHEMA, type, ts: Date.now(), pid: process.pid, ...data }; console.log(JSON.stringify(obj)); } catch(_){ }
}
const ECON_SWITCH_COOLDOWN_MS = parseInt(process.env.ECON_SWITCH_COOLDOWN_MS || '300000',10); // 5m default
const COIN_POOL_MAP = {
  btc: process.env.BTC_POOL || process.env.POOL_BTC || process.env.MINER_POOL_BTC,
  rvn: process.env.RVN_POOL || process.env.POOL_RVN || process.env.MINER_POOL_RVN,
  kas: process.env.KAS_POOL || process.env.POOL_KAS || process.env.MINER_POOL_KAS,
  fren: process.env.FREN_POOL || process.env.POOL_FREN || process.env.MINER_POOL_FREN
};
let __DISCOVERED_POOLS = {};
function resolvePoolForCoin(c){
  if (__DISCOVERED_POOLS && __DISCOVERED_POOLS[c]) return __DISCOVERED_POOLS[c];
  const url = COIN_POOL_MAP[c];
  if (url) return url;
  // Provide conservative defaults only if explicitly allowed (avoid accidental wrong submissions)
  if (process.env.ALLOW_DEFAULT_POOLS==='1'){
    if (c==='btc') return 'stratum+tcp://btc.f2pool.com:3333';
    if (c==='rvn') return 'stratum+tcp://raven.f2pool.com:3636';
  }
  return null;
}
function maybeAutoEconomicSwitch(pipeline){
  try {
    if (!pipeline || !pipeline.stratum || !ECON.enabled) return;
    const rec = ECON.state.recommend;
    if (!rec || pipeline.selectedCoin === rec) return;
    const now = Date.now();
    if (__ECON_LAST_SWITCH_COOLDOWN_MS == null) __ECON_LAST_SWITCH_COOLDOWN_MS = ECON_SWITCH_COOLDOWN_MS;
    const elapsed = now - __ECON_LAST_SWITCH;
    if (elapsed < __ECON_LAST_SWITCH_COOLDOWN_MS) return;
    if (ECON.stableCount < ECON.hysteresisCycles) return; // hysteresis not satisfied
    const floorAccept = parseFloat(process.env.ECON_SWITCH_ACCEPT_FLOOR || '0');
    if (floorAccept > 0 && pipeline.shareStats?.acceptanceRatio != null && pipeline.shareStats.acceptanceRatio < floorAccept){
      if (process.env.ECON_SWITCH_LOG==='1') console.warn('[ECON][AutoSwitch] Blocked (low_accept)', pipeline.shareStats.acceptanceRatio.toExponential(3), '< floor', floorAccept);
      __ECON_SWITCH_FAIL++;
      econStructuredLog('econ_switch_block', { reason:'low_accept', from:pipeline.selectedCoin, to:rec, accept:pipeline.shareStats.acceptanceRatio, floor: floorAccept });
      return;
    }
    if (__ECON_SHADOW_MODE){
      econStructuredLog('econ_would_switch', { from:pipeline.selectedCoin, to:rec, reason:'hysteresis', accept:pipeline.shareStats?.acceptanceRatio||0, stableCycles:ECON.stableCount });
      return;
    }
    const poolUrl = resolvePoolForCoin(rec);
    if (!poolUrl){
      if (!pipeline.__warnedMissingPoolOnce){
        console.warn('[ECON][AutoSwitch] Missing pool mapping for coin', rec, 'set BTC_POOL / RVN_POOL / KAS_POOL / FREN_POOL');
        pipeline.__warnedMissingPoolOnce = true;
      }
      return;
    }
    if (process.env.ECON_PREFLIGHT === '1'){
      const net = require('net');
      const timeoutMs = parseInt(process.env.ECON_PREFLIGHT_TIMEOUT_MS || '2000',10);
      let host=poolUrl, port=0;
      try { const m = poolUrl.match(/^[^:]+:\/\/([^:]+):(\d+)/); if (m){ host=m[1]; port=parseInt(m[2],10); } } catch(_){ }
      if (host && port){
        const preflight = new Promise(res=>{ const s=net.createConnection({host,port},()=>{s.end();res(true);}); s.setTimeout(timeoutMs,()=>{s.destroy();res(false);}); s.on('error',()=>{res(false);}); });
        preflight.then(ok=>{ if (ok){ try { maybeAutoEconomicSwitch(pipeline); } catch(_e){} } else { console.warn('[ECON][AutoSwitch] Preflight failed host',host,'port',port); __ECON_SWITCH_FAIL++; } });
        return;
      }
    }
    const prevCoin = pipeline.selectedCoin; __ECON_LAST_FROM_COIN = prevCoin;
    __ECON_LAST_PRE_SWITCH_ACCEPT = pipeline.shareStats ? pipeline.shareStats.acceptanceRatio : null;
    console.log('[ECON][AutoSwitch] Switching coin', prevCoin,'->', rec,'pool', poolUrl);
    try { pipeline.stratum.disconnect && pipeline.stratum.disconnect(); } catch(_){ }
    let switchOk = true;
    try {
      if (pipeline.initStratumForPool){ pipeline.initStratumForPool(poolUrl, rec); }
      else {
        const opts = { ...pipeline.stratum.options, url: poolUrl };
        const { RealStratumClient } = require('./real-stratum-client.js');
        pipeline.stratum = new RealStratumClient(opts);
        pipeline.attachStratumEvents && pipeline.attachStratumEvents();
      }
    } catch(e){ console.error('[ECON][AutoSwitch] stratum rebuild failed', e.message); switchOk=false; }
    if (!switchOk){ __ECON_SWITCH_FAIL++; return; }
    pipeline.selectedCoin = rec; __ECON_ACTIVE_COIN = rec; __ECON_LAST_SWITCH = now; __ECON_SWITCH_TOTAL++;
    __ECON_LAST_SWITCH_REASON = 'hysteresis'; __ECON_LAST_SWITCH_COOLDOWN_MS = ECON_SWITCH_COOLDOWN_MS;
    econStructuredLog('econ_switch', { from: prevCoin, to: rec, reason: __ECON_LAST_SWITCH_REASON, accept_pre: __ECON_LAST_PRE_SWITCH_ACCEPT });
    try {
      const { deriveId } = require('./deterministic-util');
      const ev = { event_id: deriveId('switch', Date.now(), prevCoin, rec, __ECON_LAST_SWITCH_REASON), ts: Date.now(), type: 'switch', from_coin: prevCoin, to_coin: rec, reason: __ECON_LAST_SWITCH_REASON };
      econAppendEvent(ev);
    } catch(_elog){}
    __ECON_LAST_DELTA_EMITTED_AT = 0; econPersistCounters();
    try { const st = loadAdaptiveState(); st.lastSwitchTs = __ECON_LAST_SWITCH; st.activeCoin = __ECON_ACTIVE_COIN; st.lastSwitchReason = __ECON_LAST_SWITCH_REASON; saveAdaptiveState(st); } catch(_){ }
    if (__ECON_ROLLBACK_ENABLE && __ECON_LAST_PRE_SWITCH_ACCEPT != null && isFinite(__ECON_LAST_PRE_SWITCH_ACCEPT)){
      const baseline = __ECON_LAST_PRE_SWITCH_ACCEPT;
      setTimeout(()=>{
        try {
          const curAcc = pipeline.shareStats ? pipeline.shareStats.acceptanceRatio : null;
          if (curAcc != null && curAcc < baseline * __ECON_ROLLBACK_THRESHOLD){
            econStructuredLog('econ_rollback', { from: rec, to: prevCoin, accept_pre: baseline, accept_post: curAcc, threshold: __ECON_ROLLBACK_THRESHOLD });
            try {
              const { deriveId } = require('./deterministic-util');
              const ev2 = { event_id: deriveId('rollback', Date.now(), rec, prevCoin), ts: Date.now(), type: 'rollback', from_coin: rec, to_coin: prevCoin, reason: 'accept_degradation' };
              econAppendEvent(ev2);
            } catch(_elog){}
            try { if (typeof gauges !== 'undefined' && gauges.econAcceptDelta){ const delta = (curAcc!=null && baseline!=null)? (curAcc - baseline) : 0; gauges.econAcceptDelta.set({ from_coin: rec, to_coin: prevCoin, reason: 'rollback' }, delta); econStructuredLog('econ_delta', { from: rec, to: prevCoin, reason: 'rollback', delta, baseline, post: curAcc }); __ECON_LAST_DELTA_EMITTED_AT = Date.now(); } } catch(_eDelta){}
            __ECON_SWITCH_FAIL++; __ECON_ROLLBACK_COUNT_PERSIST++;
            try { if (typeof gauges !== 'undefined' && gauges.econRollback){ gauges.econRollback.inc({ from_coin: rec, to_coin: prevCoin }); } } catch(_){ }
            try { pipeline.stratum.disconnect && pipeline.stratum.disconnect(); } catch(_){ }
            let rbOk=true; try { const origPool = resolvePoolForCoin(prevCoin); if (origPool){ if (pipeline.initStratumForPool){ pipeline.initStratumForPool(origPool, prevCoin); } else { const opts2={ ...pipeline.stratum.options, url: origPool }; const { RealStratumClient } = require('./real-stratum-client.js'); pipeline.stratum=new RealStratumClient(opts2); pipeline.attachStratumEvents && pipeline.attachStratumEvents(); } pipeline.selectedCoin = prevCoin; __ECON_ACTIVE_COIN = prevCoin; } else rbOk=false; } catch(_e){ rbOk=false; }
            if (rbOk){ __ECON_LAST_SWITCH = Date.now(); __ECON_LAST_SWITCH_REASON = 'rollback'; __ECON_LAST_SWITCH_COOLDOWN_MS = ECON_SWITCH_COOLDOWN_MS + 600000; try { const st2 = loadAdaptiveState(); st2.lastSwitchTs = __ECON_LAST_SWITCH; st2.activeCoin = __ECON_ACTIVE_COIN; st2.lastSwitchReason = __ECON_LAST_SWITCH_REASON; saveAdaptiveState(st2); } catch(_){ } econPersistCounters(true); }
          }
        } catch(_err){}
      }, 300000).unref();
    }
  } catch(e){ console.warn('[ECON][AutoSwitch] error', e.message); }
}

// Post-switch acceptance delta sampler: emits one delta ~2m after switch if not rollback
setInterval(()=>{
  try {
    if (!__ECON_LAST_PRE_SWITCH_ACCEPT || __ECON_LAST_PRE_SWITCH_ACCEPT <= 0) return;
    if (!__ECON_LAST_SWITCH) return;
    if (__ECON_LAST_DELTA_EMITTED_AT && (Date.now()-__ECON_LAST_DELTA_EMITTED_AT) < 300000) return; // already emitted in last 5m
    const since = Date.now() - __ECON_LAST_SWITCH;
    const stabilizeMs = parseInt(process.env.ECON_DELTA_STABILIZE_MS || '120000',10); // default 2m
    if (since < stabilizeMs) return;
    // Need gauges and current acceptance
    if (typeof gauges === 'undefined' || !gauges.econAcceptDelta) return;
    const curAcc = (global.pipeline && global.pipeline.shareStats) ? global.pipeline.shareStats.acceptanceRatio : null;
    if (curAcc == null) return;
    const delta = curAcc - __ECON_LAST_PRE_SWITCH_ACCEPT;
    const fromCoin = __ECON_LAST_FROM_COIN || 'unknown';
    const toCoin = __ECON_ACTIVE_COIN || 'unknown';
    gauges.econAcceptDelta.set({ from_coin: fromCoin, to_coin: toCoin, reason: __ECON_LAST_SWITCH_REASON || 'hysteresis' }, delta);
    econStructuredLog('econ_delta', { from: fromCoin, to: toCoin, reason: __ECON_LAST_SWITCH_REASON, delta, baseline: __ECON_LAST_PRE_SWITCH_ACCEPT, post: curAcc, stabilize_ms: stabilizeMs, mode:'stabilized' });
    __ECON_LAST_DELTA_EMITTED_AT = Date.now();
  } catch(e){ /* ignore */ }
}, 30000).unref();

// Import centralized deterministic parameters (with config hash)
const { GLOBAL_OCTO_SEED, GLOBAL_BURROW_DEPTH, GLOBAL_PRUNE_THRESHOLD, CONFIG_HASH, VAULT_HMAC } = require('./deterministic-config.js');
if (process.env.VAULT_PASS && !VAULT_HMAC){ console.warn('[Octabit] Vault HMAC missing'); }
if (process.env.VAULT_PASS && VAULT_HMAC){
  const recompute = require('crypto').createHmac('sha256', process.env.VAULT_PASS).update(CONFIG_HASH).digest('hex');
  if (recompute !== VAULT_HMAC){ console.error('[Octabit] Vault mismatch – exiting'); process.exit(1); }
}
// Optional HMAC signature for config hash (tamper-evidence) when CONFIG_HMAC_KEY provided
let CONFIG_HMAC = null;
try {
  if (process.env.CONFIG_HMAC_KEY) {
    CONFIG_HMAC = crypto.createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(CONFIG_HASH).digest('hex');
  }
} catch(_) { CONFIG_HMAC = null; }

// Optional source manifest hashing (per-file integrity) if source-manifest.json present
let SOURCE_MANIFEST_HASH = null;
let SOURCE_MANIFEST_HMAC = null;
try {
  const fs = require('fs');
  if (fs.existsSync('source-manifest.json')) {
    const manifest = JSON.parse(fs.readFileSync('source-manifest.json','utf8'));
    if (manifest && manifest.aggregateHash) {
      SOURCE_MANIFEST_HASH = manifest.aggregateHash;
    } else {
      SOURCE_MANIFEST_HASH = crypto.createHash('sha256').update(JSON.stringify(manifest||{})).digest('hex');
    }
    if (fs.existsSync('source-manifest.hmac.json')) {
      try {
        const sig = JSON.parse(fs.readFileSync('source-manifest.hmac.json','utf8'));
        SOURCE_MANIFEST_HMAC = sig.hmac || null;
        if (process.env.MANIFEST_HMAC_KEY && SOURCE_MANIFEST_HASH) {
          const recomputed = crypto.createHmac('sha256', process.env.MANIFEST_HMAC_KEY).update(SOURCE_MANIFEST_HASH).digest('hex');
            if (recomputed !== SOURCE_MANIFEST_HMAC) {
              console.warn('[Manifest] HMAC mismatch (expected recomputed)');
            } else {
              console.log('[Manifest] HMAC verified');
            }
        }
      } catch(_){ }
    }
    if (!global.__AUR_MANIFEST_HEADER__) {
      console.log(`[Aurrelia][Manifest] sourceManifestHash=${SOURCE_MANIFEST_HASH}` + (SOURCE_MANIFEST_HMAC?` hmac=${SOURCE_MANIFEST_HMAC}`:''));
      global.__AUR_MANIFEST_HEADER__ = 1;
    }
  }
} catch(_){ }
// Lightweight CLI flag mapping -> env overrides (MSI quick tune)
const argvFlags = (()=>{
  const map = {};
  for (const a of process.argv.slice(2)){
    if (!a.startsWith('--')) continue;
    const eq = a.indexOf('=');
    let k,v; if (eq>0){ k=a.slice(2,eq); v=a.slice(eq+1); } else { k=a.slice(2); v='1'; }
    map[k] = v;
  }
  return map;
})();
function flag(name, envKey, transform){
  if (argvFlags[name] != null){ const val = transform? transform(argvFlags[name]): argvFlags[name]; process.env[envKey] = val; }
}
flag('ico-blend','AUR_ICO_BLEND');
flag('spin-blend','SPIN_ALPHA');
flag('burrow-adapt','BURROW_ADAPT', v=> v==='0'?'0':'1');
flag('rule-persist','RULE_PERSIST', v=> v==='0'?'0':'1');
flag('geom-rotate','GEOM_ROTATE', v=> v==='0'?'0':'1');
flag('node-growth','NODE_GROWTH', v=> v==='0'?'0':'1');
flag('geom-ring-max','GEOM_RING_MAX');
flag('geom-ring-rotate-mb','GEOM_RING_ROTATE_MB');
flag('wasm-batch','BATCH_SIZE');
flag('rule-stats-path','RULE_STATS_PATH');
flag('spin-rashba','SPIN_RASHBA', v=> v==='0'?'0':'1');
flag('ishe','ISHE_ENABLED', v=> v==='0'?'0':'1');
flag('hyper-d','AUR_DIM');
flag('rashba-gain','RASHBA_GAIN');
flag('ishe-eff','ISHE_EFF');
flag('rashba-adapt','RASHBA_ADAPT', v=> v==='0'?'0':'1');
flag('hypercube-path','HYPERCUBE_PATH');
flag('hypercube-auto','HYPERCUBE_AUTO', v=> v==='0'?'0':'1');
flag('hypercube-count','HYPERCUBE_COUNT');
flag('hypercube-phi','HYPERCUBE_PHI_SCALE');
flag('hypercube-blend','HYPERCUBE_BLEND');
flag('hypercube-rotate-hashes','HYPERCUBE_ROTATE_HASHES');
// Startup summary of overrides
if (!global.__AUR_FLAGS_PRINTED__){
  const used = Object.keys(argvFlags).map(k=> `${k}=${argvFlags[k]}`).join(', ');
  console.log(`[Flags] Applied overrides: ${used || 'none'}`);
  global.__AUR_FLAGS_PRINTED__=1;
}
const PRINT_CONFIG = process.argv.includes('--print-config');
const DRY_RUN = process.argv.includes('--dry-run');
// Global spin power samples ring buffer (for percentile telemetry)
global.__AUR_SPIN_SAMPLES__ = global.__AUR_SPIN_SAMPLES__ || [];
global.__AUR_SPIN_SAMPLES_MAX__ = parseInt(process.env.SPIN_POWER_SAMPLES || '512',10);
if (global.__AUR_RASHBA_GAIN__ == null){
  global.__AUR_RASHBA_GAIN__ = parseFloat(process.env.RASHBA_GAIN || '0.15');
  global.__AUR_RASHBA_LAST_ADAPT__ = Date.now();
}
// Optional hypercube scaffold load/generate
if (!global.__AUR_HYPERCUBE__){
  try {
    const dim = parseInt(process.env.AUR_DIM || '0',10);
    const path = process.env.HYPERCUBE_PATH || null;
    const auto = process.env.HYPERCUBE_AUTO === '1';
    const count = parseInt(process.env.HYPERCUBE_COUNT || '1024',10);
    const phiScale = (process.env.HYPERCUBE_PHI_SCALE || '1') === '1';
    const seed = process.env.HYPERCUBE_SEED || 'aurrelia';
    const fs = require('fs');
    function genSample(dim, count, seed, phiScale){
      const phi = (1+Math.sqrt(5))/2;
      const out = [];
      for (let i=0;i<count;i++){
        // deterministic hash -> signs
        const h = require('crypto').createHash('sha256').update(seed+':'+i).digest();
        const v = new Array(dim);
        for (let d=0; d<dim; d++){
          const byte = h[d % h.length];
          const bit = (byte >> (d % 8)) & 1;
          let val = bit ? 1 : -1;
          if (phiScale){ val *= Math.pow(phi, (d % 8)/8 - 0.5); }
          v[d] = val;
        }
        out.push(v);
      }
      return out;
    }
    let loaded = null;
    if (path && fs.existsSync(path)){
      loaded = JSON.parse(fs.readFileSync(path,'utf8'));
      if (loaded && loaded.vectors && Array.isArray(loaded.vectors)){
        global.__AUR_HYPERCUBE__ = { dim: loaded.dim||dim, vectors: loaded.vectors, count: loaded.vectors.length, phiScale: !!loaded.phiScale };
        console.log('[Hypercube] Loaded', loaded.vectors.length, 'vectors from', path, 'dim', loaded.dim||dim);
      }
    }
    if (!global.__AUR_HYPERCUBE__ && auto && dim >= 48){
      const vectors = genSample(dim, count, seed, phiScale);
      global.__AUR_HYPERCUBE__ = { dim, vectors, count: vectors.length, phiScale };
      console.log('[Hypercube] Generated sample dim', dim, 'count', vectors.length, 'phiScale', phiScale?'on':'off');
    }
  } catch(e){ console.warn('[Hypercube] init error', e.message); }
}
// --- Inter-process Harmonic Sharing Bus (UDP or FS) ------------------
// Enable with AUR_HBUS_UDP=1 and/or AUR_HBUS_FS=1
//  UDP env: HBUS_PORT (default 49321), HBUS_INTERVAL_MS, HBUS_DECAY (0..1 smoothing)
//  FS  env: HBUS_FS_PATH (default hbus-shared.json)
let __HBUS_ENABLED=false, __HBUS_MODE_UDP=false, __HBUS_MODE_FS=false, __HBUS_MODE_MCAST=false; let __HBUS_SOCKET=null; let __HBUS_LAST=0; let __HBUS_FS_PATH=null; let __HBUS_SHARED_FREQ=432;
let __HBUS_LOCAL_ACCEPT = 0; // local acceptance rate proxy (shares/attempted or shares/hashes)
const __HBUS_PEERS = new Map(); // key: instanceIdx or pid -> { freq, accRate, ts }
let __HBUS_ASSIGNED_FREQ = null; // cluster-assigned harmonic for load distribution
const HBUS_VOTING = process.env.HBUS_VOTING === '1';
const INSTANCE_INDEX = parseInt(process.env.AUR_INSTANCE_INDEX || '-1',10);
const HBUS_DECAY = parseFloat(process.env.HBUS_DECAY || '0.75');
const HBUS_INTERVAL_MS = parseInt(process.env.HBUS_INTERVAL_MS || '3000',10);
try {
  if (process.env.AUR_HBUS_UDP === '1' || process.env.HBUS_MULTICAST === '1'){
    const dgram = require('dgram');
    const port = parseInt(process.env.HBUS_PORT || '49321',10);
    const mcastAddr = process.env.HBUS_MCAST_ADDR || '239.255.42.32';
    __HBUS_SOCKET = dgram.createSocket({ type:'udp4', reuseAddr:true });
    __HBUS_SOCKET.on('message', msg=>{ try { const o=JSON.parse(msg.toString()); if (o && typeof o.freq==='number'){
          // Update peer table
          const k = (o.idx!=null? o.idx : o.pid);
          const accRate = typeof o.accRate === 'number'? o.accRate : 0;
          __HBUS_PEERS.set(k, { freq:o.freq, accRate, ts: Date.now() });
          __HBUS_SHARED_FREQ = (__HBUS_SHARED_FREQ*HBUS_DECAY)+(o.freq*(1-HBUS_DECAY));
        } } catch(_){ } });
    __HBUS_SOCKET.on('error', e=> console.warn('[HBUS] socket error', e.message));
    __HBUS_SOCKET.bind(port, ()=>{
      if (process.env.HBUS_MULTICAST === '1'){
        try { __HBUS_SOCKET.addMembership(mcastAddr); __HBUS_MODE_MCAST=true; console.log('[HBUS][MCAST] joined', mcastAddr, 'port', port); } catch(e){ console.warn('[HBUS][MCAST] join failed', e.message); }
      } else {
        try { __HBUS_SOCKET.setBroadcast(true); __HBUS_MODE_UDP=true; console.log('[HBUS][UDP] listening port', port); } catch(_){ }
      }
    });
    __HBUS_ENABLED=true;
  }
  if (process.env.AUR_HBUS_FS === '1'){
    __HBUS_FS_PATH = process.env.HBUS_FS_PATH || 'hbus-shared.json';
    __HBUS_ENABLED=true; __HBUS_MODE_FS=true; console.log('[HBUS][FS] path', __HBUS_FS_PATH);
  }
} catch(e){ console.warn('[HBUS] init error', e.message); }
function hbusPublish(localFreq){
  if (!__HBUS_ENABLED) return; const now=Date.now(); if (now-__HBUS_LAST < HBUS_INTERVAL_MS) return; __HBUS_LAST=now;
  // Prune stale peers (> 15s)
  for (const [k,v] of __HBUS_PEERS.entries()){ if (now - v.ts > 15000) __HBUS_PEERS.delete(k); }
  let votedFreq = localFreq;
  if (HBUS_VOTING && __HBUS_PEERS.size){
    // Weighted harmonic voting: weight by acceptance rate (fallback weight 0.01)
    let sumW=0, sumWF=0;
    for (const v of __HBUS_PEERS.values()){ const w = (v.accRate>0? v.accRate:0.01); sumW+=w; sumWF += w * v.freq; }
    if (sumW>0) votedFreq = sumWF / sumW;
    __HBUS_SHARED_FREQ = (__HBUS_SHARED_FREQ*0.8)+(votedFreq*0.2);
    // Load distribution: assign distinct harmonic by ordering peer keys
    if (MULTI_HARMONIC){
      const keys = Array.from(__HBUS_PEERS.keys()).sort();
      const pos = INSTANCE_INDEX>=0? keys.indexOf(INSTANCE_INDEX)>=0? keys.indexOf(INSTANCE_INDEX): (keys.indexOf(process.pid)>=0? keys.indexOf(process.pid):0):0;
      __HBUS_ASSIGNED_FREQ = HARMONICS[pos % HARMONICS.length];
    }
  }
  const payload = JSON.stringify({ freq: localFreq, ts: now, pid: process.pid, idx: INSTANCE_INDEX, accRate: __HBUS_LOCAL_ACCEPT });
  const port = parseInt(process.env.HBUS_PORT||'49321',10);
  if (__HBUS_SOCKET){
    try {
      if (__HBUS_MODE_MCAST){
        __HBUS_SOCKET.send(Buffer.from(payload), port, process.env.HBUS_MCAST_ADDR || '239.255.42.32');
      } else if (__HBUS_MODE_UDP){
        __HBUS_SOCKET.send(Buffer.from(payload), port, '255.255.255.255');
      }
    } catch(_){ }
  }
  if (__HBUS_MODE_FS && __HBUS_FS_PATH){
    try { const fs=require('fs'); let merged={ freq: localFreq, ts: now }; if (fs.existsSync(__HBUS_FS_PATH)){ try { const prev=JSON.parse(fs.readFileSync(__HBUS_FS_PATH,'utf8')); if (prev && typeof prev.freq==='number'){ merged.freq=(prev.freq*HBUS_DECAY)+(localFreq*(1-HBUS_DECAY)); } } catch(_){ } } fs.writeFileSync(__HBUS_FS_PATH, JSON.stringify(merged)); __HBUS_SHARED_FREQ = merged.freq; } catch(_){ }
  }
}
if (!global.__AUR_REPRO_HEADER__) {
  console.log(`[Aurrelia][Deterministic] seed=${GLOBAL_OCTO_SEED} burrowDepth=${GLOBAL_BURROW_DEPTH} pruneThreshold=${GLOBAL_PRUNE_THRESHOLD} configHash=${CONFIG_HASH}` + (CONFIG_HMAC?` hmac=${CONFIG_HMAC}`:'') + (SOURCE_MANIFEST_HASH?` manifestHash=${SOURCE_MANIFEST_HASH}`:''));
  global.__AUR_REPRO_HEADER__ = 1;
}
// Repro header digest update
if (__REPRO_CYCLE_LIMIT>0){ __reproDigestUpdate('header', { seed:GLOBAL_OCTO_SEED, prune:GLOBAL_PRUNE_THRESHOLD, burrow:GLOBAL_BURROW_DEPTH, configHash:CONFIG_HASH }); }

// Fast reproducibility mode: synthetic cycles without real stratum / network
if (process.env.AUR_REPRO_FAST === '1' && __REPRO_CYCLE_LIMIT>0){
  for (let i=0;i<__REPRO_CYCLE_LIMIT;i++){
    __REPRO_CYCLE_COUNT++;
    __reproDigestUpdate('fastCycle', { c: __REPRO_CYCLE_COUNT });
  }
  __reproDigestUpdate('finalFast', { cycles: __REPRO_CYCLE_COUNT });
  __reproPersistState();
  console.log(`[REPRO][FAST] cycles=${__REPRO_CYCLE_COUNT} digest=${__REPRO_DIGEST_CHAIN}`);
  process.exit(0);
}
// Prometheus gauge for repro digest (updated on persist attempts)
let __REPRO_PROM_GAUGE = null;
try {
  const prom = require('prom-client');
  if (!prom.register.getSingleMetric('aurrelia_system_repro_digest')){
    __REPRO_PROM_GAUGE = new prom.Gauge({ name:'aurrelia_system_repro_digest', help:'Aurrelia system reproducibility digest head', labelNames:['mode'] });
  } else { __REPRO_PROM_GAUGE = prom.register.getSingleMetric('aurrelia_system_repro_digest'); }
  if (__REPRO_PROM_GAUGE){ __REPRO_PROM_GAUGE.set({mode: process.env.AUR_REPRO_FAST==='1'?'fast':'normal'}, 1); }
} catch(_){ }
// --- Geometry capacity parameters ---
const AUR_DIM = parseInt(process.env.AUR_DIM || '8',10);
const GEOM_ROOM = parseFloat(process.env.GEOM_ROOM || '1.0');
const GEOM_SPACING = parseFloat(process.env.GEOM_SPACING || '0.1');
function geomCapacity(d=AUR_DIM){
  const layers = Math.max(1, Math.floor(GEOM_ROOM / GEOM_SPACING));
  // Heuristic: 2D projected grid * 8-fold rotation * 2^(d-4) scale for >4D conceptual richness
  const packed = Math.pow(layers,2) * 8 * Math.pow(2, Math.max(0, d-4));
  return packed > Number.MAX_SAFE_INTEGER ? Number.MAX_SAFE_INTEGER : Math.floor(packed);
}
const GEOM_CAPACITY = geomCapacity();
// Strict integrity mode: abort if hashes/HMAC missing or mismatch
if (process.argv.includes('--strict-integrity') || process.env.STRICT_INTEGRITY === '1'){
  let fail = false;
  if (!SOURCE_MANIFEST_HASH){ console.error('[Integrity] Missing source manifest hash'); fail = true; }
  if (process.env.MANIFEST_HMAC_KEY && !SOURCE_MANIFEST_HMAC){ console.error('[Integrity] Missing source manifest HMAC'); fail = true; }
  if (process.env.CONFIG_HMAC_KEY && !CONFIG_HMAC){ console.error('[Integrity] Missing config HMAC'); fail = true; }
  if (fail){
    console.error('[Integrity] Enforcement triggered. Exiting.');
    process.exit(2);
  } else {
    console.log('[Integrity] Strict integrity checks passed.');
  }
}

// ---------------------------------------------------------------------------
// Startup wallet HMAC verification (tamper-evidence of critical payout addrs)
// Each sealed wallet env var has companion KEY_HMAC generated via /wallet/seal.
// Recompute HMAC(address) using CONFIG_HMAC_KEY; mismatch -> warn or abort.
// Enable hard enforcement with WALLET_HMAC_ENFORCE=1 (or --wallet-hmac-enforce).
// ---------------------------------------------------------------------------
try {
  const enforce = process.env.WALLET_HMAC_ENFORCE === '1' || process.argv.includes('--wallet-hmac-enforce');
  const hmacKey = process.env.CONFIG_HMAC_KEY || null;
  const walletKeys = ['BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','LTC_KRAKEN_ADDRESS','RVN_LOCAL_ADDRESS','FREN_WALLET','KAS_WALLET'];
  if (hmacKey){
    let mismatches = 0; let verified = 0; let sealed = 0; const details = [];
    for (const k of walletKeys){
      const addr = process.env[k]; const sig = process.env[k+'_HMAC'];
      if (!addr){ continue; }
      if (sig){ sealed++; }
      const recomputed = crypto.createHmac('sha256', hmacKey).update(addr).digest('hex').slice(0,32);
      if (sig){
        if (sig === recomputed){ verified++; details.push({ key:k, status:'ok', hmac:sig }); }
        else { mismatches++; details.push({ key:k, status:'mismatch', expected:recomputed, got:sig }); }
      } else {
        details.push({ key:k, status:'unsealed' });
      }
    }
    const summary = { ts: Date.now(), sealed, verified, mismatches, enforce };
    console.log('[WalletHMAC] summary', JSON.stringify(summary));
    if (details.length){
      for (const d of details){
        if (d.status === 'mismatch') console.error('[WalletHMAC] MISMATCH', d.key, 'expected', d.expected, 'got', d.got);
        else if (d.status === 'unsealed') console.warn('[WalletHMAC] Unsealed wallet', d.key, '-> seal via /wallet/seal');
        else console.log('[WalletHMAC] OK', d.key);
      }
    }
    if (mismatches > 0 && enforce){
      console.error('[WalletHMAC] Enforcement enabled; mismatches detected. Exiting.');
      process.exit(3);
    }
  } else {
    console.warn('[WalletHMAC] CONFIG_HMAC_KEY not set; wallet HMAC verification skipped');
  }
} catch(e){ console.error('[WalletHMAC] verification error', e.message); }
function hashToOctonion(dataStr) {
  // Seed-mixed additive hash (stable across processes when seed & input identical)
  let hash = 0;
  for (let i = 0; i < dataStr.length; i++) {
    // XOR with seed low byte then mix; stays deterministic and reversible only by input knowledge.
    const ch = dataStr.charCodeAt(i) ^ (GLOBAL_OCTO_SEED & 0xFF);
    hash = ((hash << 5) - hash) + ch;
    hash |= 0;
  }
  const coeffs = [];
  for (let i = 0; i < 8; i++) {
    const chunk = (hash >>> (i * 4)) & 0xFFFF;
    coeffs.push((chunk % 10000 / 5000 - 1));
  }
  if (process.env.OCTO_PROJECT_2D === '1') {
    const c0 = coeffs[0]; const c1 = coeffs[1];
    return { coeffs: [c0, c1, 0,0,0,0,0,0] };
  }
  return { coeffs };
}

// OctaBit Wheel Lattice Encryption Integration for Pico Mesh
class OctaBitWheelLattice {
  constructor() {
    this.wheel = { keyboard: [], symbol: [], emoji: [] };
    this.lattice = {};
    this.masterKey = null;
    this.nonceSize = 432;
    this.iterations = 986;
    this.hashAlg = 'sha256';
  }

  buildWheel(inputStr) {
    const keyboard = [...inputStr].filter(c => c.match(/[a-zA-Z0-9]/));
    this.wheel.keyboard = keyboard.map(c => ({ tier: 'keyboard', value: c, type: 'node', harmonic: 512.0 }));

    const symbols = ['=>', '->', '~', '❓', '⊶'];
    this.wheel.symbol = symbols.filter(s => inputStr.includes(s)).map(s => ({ tier: 'symbol', value: s, type: 'bond', harmonic: 4.32 }));

    const emojiMap = { '🔴': 432.0, '🟠': 458.0, '🟡': 484.0, '🟢': 512.0, '🔵': 542.0, '🟣': 574.0 };
    const emojis = [...inputStr].filter(e => Object.keys(emojiMap).includes(e));
    this.wheel.emoji = emojis.map(e => ({ tier: 'emoji', value: e, type: 'harmonic', harmonic: emojiMap[e] }));

    console.log(`🌀 Wheel Built: Keyboard=${keyboard.length} nodes, Symbols=${this.wheel.symbol.length} bonds, Emoji=${emojis.length} harmonics`);
  }

  forgeKey(wheelHash) {
    const salt = Buffer.from('octabit_wheel_salt_2025');
    this.masterKey = require('crypto').pbkdf2Sync(wheelHash, salt, this.iterations, 32, 'sha256'); // 32 bytes for AES-256
    console.log(`🔐 Key Forged: AES-256 from wheel hash (${this.iterations} iters)`);
    return this.masterKey;
  }

  buildLattice() {
    for (let i = 0; i < 512; i++) {
      const x = i % 8, y = Math.floor(i / 8) % 8, z = Math.floor(i / 64);
      this.lattice[`${x},${y},${z}`] = { data: null, hash: null, bonds: [] };
    }

    let nodeIdx = 0;
    for (const sym of [...this.wheel.keyboard, ...this.wheel.symbol, ...this.wheel.emoji]) {
      if (nodeIdx < 512) {
        const pos = `${nodeIdx % 8},${Math.floor(nodeIdx / 8) % 8},${Math.floor(nodeIdx / 64)}`;
        this.lattice[pos].data = sym.value;
        this.lattice[pos].harmonic = sym.harmonic || 1.0;
        nodeIdx++;
      }
    }

    for (let i = 1; i < 512; i++) {
      const prev = `${(i-1) % 8},${Math.floor((i-1) / 8) % 8},${Math.floor((i-1) / 64)}`;
      const curr = `${i % 8},${Math.floor(i / 8) % 8},${Math.floor(i / 64)}`;
      this.lattice[curr].bonds.push(prev);
    }

    console.log(`💎 Lattice Built: 512 nodes, ${Object.values(this.lattice).reduce((s, n) => s + n.bonds.length, 0)} bonds`);
  }

  encryptLattice() {
    const crypto = require('crypto');
    const wheelHash = crypto.createHash(this.hashAlg).update(JSON.stringify(this.wheel)).digest('hex');
    const key = this.forgeKey(wheelHash);

    for (const [pos, cell] of Object.entries(this.lattice)) {
      if (cell.data) {
        const dataHash = crypto.createHash(this.hashAlg).update(cell.data).digest('hex');
        cell.hash = dataHash;

        const iv = crypto.createHash(this.hashAlg).update(String(cell.harmonic || 1.0)).digest().slice(0, 16); // 16 bytes IV for GCM
        const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
        let encrypted = cipher.update(cell.data, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const authTag = cipher.getAuthTag();
        cell.data = encrypted + ':' + authTag.toString('hex') + ':' + iv.toString('hex');
      }
    }

    console.log(`🔒 Lattice Encrypted: SHA-256 leaves + AES-256-GCM shards (IV=16B)`);
  }

  rebuildFromWheel(inputStr) {
    this.buildWheel(inputStr);
    this.buildLattice();
    this.encryptLattice();
    return this.lattice;
  }
}
// End OctaBit Integration

class SimpleOcto {
  constructor(coeffs) { this.coeffs = coeffs; }
  norm() {
    if (global.__AUR_OCTO_WASM__ && global.__AUR_OCTO_WASM__.norm){
      try { return global.__AUR_OCTO_WASM__.norm(this.coeffs); } catch(_){ }
    }
    return Math.sqrt(this.coeffs.reduce((s, c) => s + c * c, 0));
  }
  add(other) { return new SimpleOcto(this.coeffs.map((c, i) => c + other.coeffs[i])); }
  multiply(other) {
    if (global.__AUR_OCTO_WASM__ && global.__AUR_OCTO_WASM__.multiply){
      try { const out = global.__AUR_OCTO_WASM__.multiply(this.coeffs, other.coeffs); if (out && out.length===8) return new SimpleOcto(out); } catch(_){ }
    }
    // Base (Cayley-Dickson style reduced) product
    const prod = new Array(8).fill(0);
    prod[0] = this.coeffs[0] * other.coeffs[0] - this.coeffs.slice(1).reduce((s, c, i) => s + c * other.coeffs[i + 1], 0);
    for (let i = 1; i < 8; i++) prod[i] = this.coeffs[0] * other.coeffs[i] + other.coeffs[0] * this.coeffs[i];
    // Optional Fano-plane triad enhancement for richer non-associative mixing (deterministic)
    // Enabled by default; disable with OCTO_TRIAD=0
    const OCTO_TRIAD = process.env.OCTO_TRIAD !== '0';
    if (OCTO_TRIAD) {
      // Triads: [i,j,k,sign] with 1..7 imaginary indexes, 0 = real component
      const FANO_TRIADS = [
        [1,2,4,-1],
        [1,3,5, 1],
        [1,6,7,-1],
        [2,3,6, 1],
        [2,5,7, 1],
        [3,4,7, 1],
        [4,5,6,-1]
      ];
      for (let t = 0; t < FANO_TRIADS.length; t++) {
        const [i,j,k,sg] = FANO_TRIADS[t];
        // Adjust k component with signed product (pure imaginary interaction)
        prod[k] += sg * this.coeffs[i] * other.coeffs[j];
      }
    }
    return new SimpleOcto(prod);
  }
  power(d = 2) {
    if (d === 2){
      if (global.__AUR_OCTO_WASM__ && global.__AUR_OCTO_WASM__.power){
        try { const out = global.__AUR_OCTO_WASM__.power(this.coeffs); if (out && out.length===8) return new SimpleOcto(out); } catch(_){ }
      }
      return this.multiply(this);
    }
    return this;
  }
}

// Explicit declaration of OCTA (8 coefficient) verifier architecture. No TRIAD logic exists here.
const OCTA_VERIFIER_COUNT = 8;
if (!global.__AUR_OCTA_BANNER__) {
  console.log(`[Aurrelia] Octa verifier mode active (${OCTA_VERIFIER_COUNT} coefficient basis – SimpleOcto)`);
  global.__AUR_OCTA_BANNER__ = 1;
}

// Attempt lazy init of Octo WASM SIMD module (optional). Provide JS shim if build artifact present.
if (!global.__AUR_OCTO_WASM_INIT__){
  global.__AUR_OCTO_WASM_INIT__ = 1;
  (function(){
    const fs = require('fs');
    const path = process.env.OCTO_WASM_PATH || 'octo-simd.wasm';
    if (fs.existsSync(path)){
      try {
        const bytes = fs.readFileSync(path);
        WebAssembly.instantiate(bytes, { env:{} }).then(obj=>{
          const exp = obj.instance.exports;
          // Expect exported functions with simple memory passing or direct params; wrap for array usage.
          if (exp && exp.memory){
            const mem = new Uint32Array(exp.memory.buffer);
            global.__AUR_OCTO_WASM__ = {
              multiply(a,b){
                // naive marshaling (place at fixed offsets)
                const base = 0;
                for (let i=0;i<8;i++){ mem[base+i]=Float32Array.from([a[i]])[0]; mem[base+16+i]=Float32Array.from([b[i]])[0]; }
                if (exp._multiply){ exp._multiply(base, base+16, base+32); }
                const out = [];
                for (let i=0;i<8;i++){ out.push(mem[base+32+i]); }
                return out.map(Number);
              },
              power(a){ return this.multiply(a,a); },
              norm(a){ let s=0; for (let i=0;i<8;i++) s+=a[i]*a[i]; return Math.sqrt(s); }
            };
            console.log('[OctoWASM] SIMD module loaded');
          }
        }).catch(()=>{});
      } catch(_){ }
    }
  })();
}

// Minimal mode flag: when MINING_MINIMAL=1 we suppress heavy optional subsystems (crystal tuner offload, IPFS, Arweave, Filecoin, Helia)
const MINING_MINIMAL = process.env.MINING_MINIMAL === '1';
if (MINING_MINIMAL) {
  process.env.ARWEAVE_DISABLED = '1';
  process.env.IPFS_ENABLED = '0';
  process.env.IPFS_ENABLED_HELIA = '0';
  process.env.FILECOIN_ENABLED = '0';
  process.env.CRYSTAL_PERSIST = '0';
  process.env.CRYSTAL_TUNING = '0';
  if (!global.__AUR_MINIMAL_ONCE__) {
    console.log('[Aurrelia][Minimal] Heavy auxiliary subsystems disabled (pure octa mining path).');
    global.__AUR_MINIMAL_ONCE__ = 1;
  }
}

// RomanDecoderWheel: Spiral cipher for each data plane
class RomanDecoderWheel {
  constructor(plane = 'xy', freq = 432, hue = 650) {
    this.plane = plane; // 'xy', 'xz', 'yz', 'w4d'
    this.freq = freq;
    this.hue = hue;
    this.r = hue / 1000; // Color-tuned radius
    this.theta = 0;
  }
  decodeData(dataHex) {
    this.theta += 2 * Math.PI * (this.freq / 432) / 8; // Octagonal decode step
    const spiralR = this.r * (Math.cos(8 * this.theta) + 1.5) / 2.5; // Modulated r
    const decoded = [];
    for (let i = 0; i < dataHex.length; i += 8) {
      const chunk = dataHex.slice(i, i + 8);
      const oct = chunk.split('').reduce((acc, c, j) => { acc[j % 8] += parseInt(c, 16); return acc; }, Array(8).fill(0));
      if (this.kawpowMixHash){
        const mixNibbles = this.kawpowMixHash.match(/.{2}/g);
        if (mixNibbles){
          for (let j=0;j<8;j++){
            const mixIdx = (i/8 + j) % mixNibbles.length;
            const val = parseInt(mixNibbles[mixIdx],16);
            if (!isNaN(val)) oct[j] ^= val;
          }
        }
      }
      const norm = new SimpleOcto(oct).norm() * spiralR;
      if (norm <= 2) decoded.push(chunk); // Resonant decode
    }
    return decoded.join(''); // Decoded wave
  }
}

class AurreliaNode {
  constructor(id, mesh, picoCrystalTuner = null, enableCrystalBias = false, harmonicIndex = 0) {
    this.octo = new SimpleOcto(hashToOctonion(`node${id}`).coeffs);
    this.harmonicIndex = MULTI_HARMONIC ? (harmonicIndex % HARMONICS.length) : 0;
    this.freq = MULTI_HARMONIC ? HARMONICS[this.harmonicIndex] : 432;
    this.successes = 0;
    this.attempts = 0;
    this.mesh = mesh;
    this.id = id;
    this.w = 0; // 4D temporal entropy
    this.picoCrystalTuner = picoCrystalTuner;
    this.enableCrystalBias = enableCrystalBias;
    // Per-node engine parameters (harmonic-specific)
    const baseFreq = this.freq;
    this.engine = {
      harmonic: baseFreq,
      thetaBase: (2 * Math.PI) / baseFreq,
      burrowDepth: GLOBAL_BURROW_DEPTH,
      pruneThreshold: GLOBAL_PRUNE_THRESHOLD
    };
    this.picoTheta = 0; // phase accumulator for interference term
    this.interferenceGain = 1.5;  // base gain
    if (global.__AUR_HYPERCUBE__ && global.__AUR_HYPERCUBE__.vectors){
      // Assign deterministic hypercube vector slice to node for geometric modulation
      const hv = global.__AUR_HYPERCUBE__.vectors[id % global.__AUR_HYPERCUBE__.vectors.length];
      if (hv && hv.length){
        // Store a lightweight projected norm and two leading coords for later blending
        const hNorm = Math.sqrt(hv.reduce((a,b)=>a + b*b,0));
        this.hyperVec = { n: hNorm, x: hv[0], y: hv[1] };
      }
    }
    if (process.env.AUR_ICO12 === '1') {
      const phi = (1 + Math.sqrt(5)) / 2;
      const ico = [];
      for (const s1 of [1,-1]) for (const s2 of [1,-1]) {
        ico.push([0, s1, s2*phi]);
        ico.push([s1, s2*phi, 0]);
        ico.push([s2*phi, 0, s1]);
      }
      const targetDim = Math.min(AUR_DIM, 12);
      this.icoVectors = ico.map(v => {
        const ext = new Array(targetDim).fill(0);
        for (let d=0; d<targetDim; d++){
          const baseIdx = d % 3;
          const scale = (d < 3) ? 1 : Math.pow(phi, (d-2)%4) * 0.25;
          ext[d] = v[baseIdx] * scale;
        }
        return new SimpleOcto(ext.slice(0,2).concat([0,0,0,0,0,0]));
      });
    }
    // Optional rotated node projections for geometric variance (light 2D embedding)
    if (process.env.GEOM_ROTATE === '1') {
      const rotCount = parseInt(process.env.GEOM_ROT_COUNT || '4',10);
      this.rotatedNodes = [];
      for (let r=0;r<rotCount;r++){
        const angle = (Math.PI/2) * r; // quarter rotations
        // Build conceptual extended vector length AUR_DIM with deterministic perturbation
        const base = [];
        for (let i=0;i<AUR_DIM;i++){
          const src = this.octo.coeffs[i % this.octo.coeffs.length];
          const mix = (((i*2654435761)>>>0) & 0xffff)/0xffff; // Knuth-like mix
          base.push((src*0.85) + (mix*0.3 - 0.15));
        }
        const x = base[0]*Math.cos(angle) - base[1]*Math.sin(angle);
        const y = base[0]*Math.sin(angle) + base[1]*Math.cos(angle);
        const proj = [x,y];
        this.rotatedNodes.push(new SimpleOcto(proj.concat([0,0,0,0,0,0])));
      }
      this.crossFireCount = 0;
    }
  }
  generateNonce(seedStr, nTime, planeSeeds = []) {
    const c = new SimpleOcto(hashToOctonion(seedStr).coeffs);
    const theta = this.engine.thetaBase * (this.freq / 432); // scale relative to canonical 432 (core)
    let z = new SimpleOcto([0,0,0,0,0,0,0,0]);
    z = z.power(2).add(c.multiply(new SimpleOcto([Math.cos(theta), Math.sin(theta), 0,0,0,0,0,0])));
    z = z.power(2).add(c);
    // Cross-plane interference (quantum sing) — deterministic: depends only on planeSeeds content and harmonic set
    let crossInterference = 0;
    if (planeSeeds && planeSeeds.length){
      for (let i=0;i<planeSeeds.length;i++){
        const ps = planeSeeds[i];
        const oct = new SimpleOcto(hashToOctonion(ps).coeffs);
        crossInterference += (oct.norm() * HARMONICS[i % HARMONICS.length] / 432) * this.engine.thetaBase;
      }
      this.picoTheta += theta; // accumulate phase deterministically
      z.coeffs[0] += crossInterference * this.interferenceGain * Math.sin(this.picoTheta);
    }
    // Geometric rotated average influence (gentle inward bias) if enabled
    if (this.rotatedNodes && this.rotatedNodes.length){
      let avg = 0; for (const rn of this.rotatedNodes) avg += rn.norm(); avg /= this.rotatedNodes.length;
      // Blend a small component into z first coeff to modulate nonce deterministically
      z.coeffs[0] = (z.coeffs[0]*0.9) + (avg*0.1);
    }
    if (this.icoVectors && this.icoVectors.length){
      let isum = 0; for (const v of this.icoVectors) isum += v.norm(); isum /= this.icoVectors.length;
      const icoBlend = Math.min(0.5, Math.max(0, parseFloat(process.env.AUR_ICO_BLEND || '0.08')));
      z.coeffs[0] = (z.coeffs[0]*(1-icoBlend)) + (isum*icoBlend);
      // Hypercube projection influence (if available)
      if (this.hyperVec){
        let hBlend = Math.min(0.25, Math.max(0, parseFloat(process.env.HYPERCUBE_BLEND || '0.05')));
        // Acceptance-driven gentle raise & spin gap ratio driven suppression (localized, per-node read of global pipeline state)
        try {
          if (global.__AUR_PIPELINE__){
            const acc = global.__AUR_PIPELINE__.shareStats ? (global.__AUR_PIPELINE__.shareStats.acceptanceRatio||0) : 0;
            if (acc < 0.55) hBlend = Math.min(0.25, hBlend * 1.02 + 0.001);
            const sgr = global.__AUR_PIPELINE__.spinGapRatio;
            if (sgr != null){
              const target = parseFloat(process.env.RASHBA_TARGET_GAP || '0.35');
              if (sgr > target * 1.3) hBlend = Math.max(0.01, hBlend * 0.90 - 0.002);
              else if (sgr < target * 0.75) hBlend = Math.min(0.25, hBlend * 1.04 + 0.002);
            }
          }
        } catch(_){ }
        const projMag = (Math.abs(this.hyperVec.x) + Math.abs(this.hyperVec.y)) / 2;
        z.coeffs[0] = (z.coeffs[0]*(1-hBlend)) + (this.hyperVec.n * hBlend * 0.5) + (projMag * hBlend * 0.5);
      }
      if (process.env.SPIN_TORQUE === '1'){
        const base = 1.5; const phase = (this.picoTheta + this.id*0.61803398875);
        const alpha = parseFloat(process.env.SPIN_ALPHA || '0.15');
        let gain = base + Math.sin(phase)*alpha;
        if (process.env.SPIN_RASHBA === '1'){
          const rg = parseFloat(process.env.RASHBA_GAIN || '0.15');
          // Rashba: additive sinusoidal modulation scaled by utilization proxy (id hash)
          const idPhase = ((this.id * 2654435761)>>>0) / 0xffffffff;
          gain *= (1 + rg * Math.sin(phase * 0.5 + idPhase));
        }
        if (process.env.ISHE_ENABLED === '1'){
          const eff = parseFloat(process.env.ISHE_EFF || '0.10');
          // Inverse spin Hall: convert a fraction of spin oscillation variance into extra gain
          const varianceProxy = Math.abs(Math.sin(phase));
          gain *= (1 + eff * varianceProxy);
        }
        this.interferenceGain = gain;
      }
    }
    this.w = parseInt(nTime, 16) % 1000 / 1000;
    // Involution pruning: project into more stable basin if norm drifts above threshold (deterministic)
    const INVOLVE_THRESHOLD = this.engine.pruneThreshold * 0.85; // early projection before hard prune
    if (z.norm() > INVOLVE_THRESHOLD) {
      // Flip two mid components (indices 3,4) to mirror across subspace boundary
      z.coeffs[3] = -z.coeffs[3];
      z.coeffs[4] = -z.coeffs[4];
    }
    const nonce = Math.floor(Math.abs(z.coeffs[0] + this.w * 0xFFFFFFFF) >>> 0);
    if (process.env.DEBUG_BURROW === '1') {
      console.log(`[Gen] node=${this.id} harm=${this.freq} norm=${z.norm().toFixed(2)} nonce=0x${nonce.toString(16)}`);
    }
    return { nonce, norm: z.norm(), interference: crossInterference };
  }
  verifyNonce(nonceStr, seedStr, nTime) {
    const c = new SimpleOcto(hashToOctonion(seedStr + nonceStr).coeffs);
    const theta = this.engine.thetaBase * (this.freq / 432);
    let z = new SimpleOcto([0,0,0,0,0,0,0,0]);
    for (let i=0;i<this.engine.burrowDepth;i++){
      z = z.power(2).add(c.multiply(new SimpleOcto([
        Math.cos(8 * theta * i),
        Math.sin(8 * theta * i),
        this.w * i,0,0,0,0,0
      ])));
      if (process.env.BURROW_NORMALIZE === '1'){
        const cap = parseFloat(process.env.BURROW_NORM_CAP || '1.0');
        let n = z.norm();
        if (n > cap){
          for (let k=0;k<z.coeffs.length;k++) z.coeffs[k] /= n;
          if (process.env.DEBUG_BURROW === '1') console.log(`[NormClamp] node=${this.id} iter=${i} preNorm=${n.toFixed(2)} -> ${cap}`);
        }
      }
      if (process.env.DEBUG_BURROW === '1') {
        console.log(`[Ver] node=${this.id} iter=${i} norm=${z.norm().toFixed(2)}`);
      }
      const n2 = z.norm();
      if (n2 > this.engine.pruneThreshold) {
        if (process.env.DEBUG_BURROW === '1') console.log(`[Prune] node=${this.id} iter=${i} norm=${n2.toFixed(2)} thr=${this.engine.pruneThreshold}`);
        return { valid:false, norm: n2, iter: i };
      }
    }
    return { valid:true, norm: z.norm(), iter: this.engine.burrowDepth-1 };
  }
  feedback(success, sweepSeed = 0, headerHash = null, planeIndex = null) {
    this.attempts++;
    if (success) this.successes++;
    if (this.mesh) this.mesh.shareLearning(this.id, this.freq, success);
    if (headerHash && this.picoCrystalTuner){
      try {
        const hashSalted = planeIndex == null ? headerHash : (headerHash + planeIndex.toString(16));
        const tuned = this.picoCrystalTuner.meshDataHash(hashSalted, this.freq, sweepSeed);
        if (this.enableCrystalBias && process.env.CRYSTAL_TUNING === '1') {
          this.freq = (this.freq * 0.9) + (tuned * 0.1);
        }
      } catch(_){ }
    }
    if (this.attempts % 32 === 0){
      const rate = this.successes / this.attempts;
      if (rate < 0.01){
        if (MULTI_HARMONIC){
          // rotate harmonic deterministically
          this.harmonicIndex = (this.harmonicIndex + 1) % HARMONICS.length;
          this.freq = HARMONICS[this.harmonicIndex];
          this.engine.thetaBase = (2*Math.PI)/this.freq;
        } else {
          this.freq = 432 + (sweepSeed % 96);
        }
        // damp interference if struggling
        this.interferenceGain = Math.max(0.4, this.interferenceGain * 0.85);
      } else if (rate > 0.05){
        // aggressive boost with higher cap (tuned)
        this.interferenceGain = Math.min(2.5, this.interferenceGain * 1.1);
      }
      this.successes = 0; this.attempts = 0;
    }
  }
  receiveMeshUpdate(freq){
    this.freq = (this.freq + freq)/2;
  }
}

class PicoMesh {
  constructor(size) {
    this.size = size;
    this.freqStats = Array(size).fill(432);
    this.successStats = Array(size).fill(0);
    // OctaBit encryption for mesh data
    this.octaBit = new OctaBitWheelLattice();
    this.meshKey = 'pico-mesh-shared-secret-2025'; // Shared key for mesh encryption
    this.octaBit.rebuildFromWheel(this.meshKey);
  }
  shareLearning(nodeId, freq, success) {
    this.freqStats[nodeId] = freq;
    if (success) this.successStats[nodeId]++;
    // Share best freq to all nodes every 64 attempts
    if (this.successStats.reduce((a,b)=>a+b,0) % 64 === 0) {
      const bestIdx = this.successStats.indexOf(Math.max(...this.successStats));
      const bestFreq = this.freqStats[bestIdx];
      const sharedData = { bestFreq, bestIdx, totalSuccess: this.successStats.reduce((a,b)=>a+b,0) };
      const encrypted = this.encryptMeshData(sharedData);
      console.log(`[PicoMesh] Encrypted shared data: ${encrypted.slice(0,16)}...`);
      for (let i = 0; i < this.size; i++) {
        if (i !== bestIdx) this.freqStats[i] = (this.freqStats[i] + bestFreq) / 2;
      }
    }
  }
  getFreq(nodeId) {
    return this.freqStats[nodeId];
  }
  // Encrypted mesh data sharing
  encryptMeshData(data) {
    const dataStr = JSON.stringify(data);
    const lattice = this.octaBit.rebuildFromWheel(dataStr + this.meshKey);
    // Use lattice hash as encrypted representation
    const crypto = require('crypto');
    const hash = crypto.createHash('sha256').update(JSON.stringify(lattice)).digest('hex');
    return hash;
  }
  decryptMeshData(encryptedHash) {
    // For mesh, we use deterministic reconstruction; in real mesh network, this would require shared wheel
    const lattice = this.octaBit.rebuildFromWheel(encryptedHash + this.meshKey);
    // Attempt to recover data from lattice (simplified for in-memory mesh)
    const recovered = Object.values(lattice).filter(cell => cell.data).map(cell => cell.data).join('');
    try {
      return JSON.parse(recovered);
    } catch(e) {
      return null; // Decryption failed
    }
  }
}

// Optional Arweave (guarded). Disable with ARWEAVE_DISABLED=1
let arweave = null;
try {
  if (process.env.ARWEAVE_DISABLED !== '1') {
    const Arweave = require('arweave'); // npm i arweave
    arweave = Arweave.init({ host: 'arweave.net', port: 443, protocol: 'https' });
  }
} catch (e) {
  console.warn('[CrystalTuner] Arweave unavailable -> disk ring buffer only. Reason:', e.message);
}

class PicoCrystalTuner {
  constructor(baseFreq = 432, scale = 1e12) {
    // Base frequency & scalar
    this.base = baseFreq;
    this.scale = scale;
    // Crystal accumulation buffer (in-memory prior to unload/offload)
    this.crystals = [];
    this.picoTheta = 0;
    // Unload thresholds (adaptive between min/max when dynamic enabled)
    this.unloadThreshold = 1000; // initial starting point
    this.minUnload = parseInt(process.env.CRYSTAL_UNLOAD_MIN || '500',10);
    this.maxUnload = parseInt(process.env.CRYSTAL_UNLOAD_MAX || '4000',10);
    this.dynamicUnload = process.env.CRYSTAL_UNLOAD_DYNAMIC === '1';
    if (this.unloadThreshold < this.minUnload) this.unloadThreshold = this.minUnload;
    if (this.unloadThreshold > this.maxUnload) this.unloadThreshold = this.maxUnload;
    // Stats accumulation
    this.totalCrystals = 0;
    this.sumNorm = 0;
    this.lastAvgNorm = 0;
    // Persistence ring buffer (used if Arweave disabled OR forced with CRYSTAL_PERSIST=1)
    this.persistEnabled = (process.env.CRYSTAL_PERSIST === '1') || !arweave;
    this.persistPath = process.env.CRYSTAL_PERSIST_PATH || 'crystal-ring.jsonl';
    this.ringSize = parseInt(process.env.CRYSTAL_RING_SIZE || '50000', 10);
    // 8-set partition ring files (deterministic) when CRYSTAL_PARTITION_8=1
    this.partition8 = process.env.CRYSTAL_PARTITION_8 === '1';
    if (this.partition8) {
      const base = this.persistPath.replace(/\.jsonl$/,'');
      this.ringFiles = Array.from({length:8},(_,i)=> `${base}-h${i}-ring.jsonl`);
    }
    this.persistBatchSize = parseInt(process.env.CRYSTAL_PERSIST_BATCH || '100', 10);
    this.persistBuffer = [];
    // IPFS integration (optional)
    this.ipfsEnabled = process.env.IPFS_ENABLED === '1' && typeof ipfsClientFactory !== 'undefined' && !!ipfsClientFactory;
    this.ipfsEndpoint = process.env.IPFS_ENDPOINT || 'http://localhost:5001';
    this.ipfsClient = null;
    if (this.ipfsEnabled) {
      try {
        if (this.ipfsEndpoint.startsWith('http')) {
          const url = new URL(this.ipfsEndpoint);
          this.ipfsClient = ipfsClientFactory.create({ host: url.hostname, port: url.port || 5001, protocol: url.protocol.replace(':','') });
        } else {
          this.ipfsClient = ipfsClientFactory.create({ url: this.ipfsEndpoint });
        }
        console.log(`[IPFS] Client initialized -> ${this.ipfsEndpoint}`);
      } catch (e) {
        console.warn('[IPFS] Initialization failed:', e.message);
        this.ipfsEnabled = false;
      }
    }
    this.ipfsCidLog = process.env.IPFS_CID_LOG || 'crystal-ipfs-cids.jsonl';
    // Filecoin (web3.storage) integration
    this.filecoinEnabled = process.env.FILECOIN_ENABLED === '1' && typeof Web3StorageClient !== 'undefined' && !!Web3StorageClient && !!process.env.WEB3_STORAGE_TOKEN;
    this.filecoinClient = null;
    if (this.filecoinEnabled) {
      try {
        this.filecoinClient = new Web3StorageClient({ token: process.env.WEB3_STORAGE_TOKEN });
        console.log('[Filecoin] web3.storage client initialized');
      } catch (e) {
        console.warn('[Filecoin] Initialization failed:', e.message);
        this.filecoinEnabled = false;
      }
    }
    this.filecoinCidLog = process.env.FILECOIN_CID_LOG || 'crystal-filecoin-cids.jsonl';
    // Audit chain log
    this.auditLogPath = process.env.CRYSTAL_AUDIT_LOG || 'crystal-audit-chain.jsonl';
    this.lastCid = null; // last offloaded CID (IPFS or Filecoin)
    this.latestAuditHash = null;
    this.prevAuditHash = null;
    // Helia integration
    this.heliaEnabled = typeof heliaFactory !== 'undefined' && !!heliaFactory && process.env.IPFS_ENABLED_HELIA === '1';
    this.helia = null; this.heliaFs = null;
    if (this.heliaEnabled) { this.initHelia(); }
  }
  async initHelia() {
    try {
      this.helia = await heliaFactory.create();
      this.heliaFs = unixfsFactory.unixfs(this.helia);
      console.log('[Helia] in-process node ready');
    } catch (e) { console.warn('[Helia] init failed:', e.message); this.heliaEnabled = false; }
  }
  meshDataHash(dataHash, nodeFreq, sweepSeed) {
    this.picoTheta += 2 * Math.PI * (sweepSeed % 96) / this.scale;
    const picoMod = Math.cos(this.picoTheta) * 0.001;
    const tunedFreq = nodeFreq + picoMod * this.base;
    const hash = crypto.createHash('sha256').update(dataHash).digest('hex');
    const coeffs = Array.from(hash.match(/.{1,2}/g)).reduce((acc, h, i) => {
      acc[i % 8] += parseInt(h, 16) / 255; return acc;
    }, Array(8).fill(0));
    const crystal = new SimpleOcto(coeffs);
    this.crystals.push(crystal);
    const norm = crystal.norm();
    this.totalCrystals++;
    this.sumNorm += norm;
    if (this.totalCrystals % 5000 === 0) {
      this.lastAvgNorm = this.sumNorm / this.totalCrystals;
      console.log(`[CrystalTuner] ${this.totalCrystals} crystals | avgNorm=${this.lastAvgNorm.toFixed(4)} | tuned=${tunedFreq.toFixed(4)}`);
    }
    if (this.crystals.length >= this.unloadThreshold) {
      this.unloadCrystals();
      if (this.dynamicUnload) this.recalcThreshold();
    }
    if (this.persistEnabled) this.enqueuePersist(norm, tunedFreq, dataHash);
    // Deterministic resonance weighting (no randomness): derive pseudo-random phase from stable inputs
    const weightSeedHash = crypto.createHash('sha256')
      .update(dataHash.slice(0, 32) + String(sweepSeed) + String(Math.floor(nodeFreq * 1e6)))
      .digest('hex');
    const phaseFrac = (parseInt(weightSeedHash.slice(0, 8), 16) % 1000) / 1000; // [0,1)
    const distance = Math.min(1, Math.abs(nodeFreq - 432) / 432);
    const resonance = Math.cos(distance * Math.PI * 2 * phaseFrac); // Stable resonance factor
    const weighted = tunedFreq + (norm % 1) * resonance * 0.5; // 0.5 damp to avoid runaway
    return weighted;
  }
  enqueuePersist(norm, tunedFreq, dataHash) {
    this.persistBuffer.push({ t: Date.now(), n: Number(norm.toFixed(6)), f: Number(tunedFreq.toFixed(6)), h: dataHash.slice(0, 16) });
    if (this.persistBuffer.length >= this.persistBatchSize) this.flushPersist();
  }
  flushPersist() {
    if (!this.persistEnabled || !this.persistBuffer.length) return;
    try {
      const fs = require('fs');
      if (this.partition8) {
        // Deterministically route each record by first hex nibble of hash (0-15) -> collapse to 0..7 via mod 8
        for (const rec of this.persistBuffer) {
          const nib = parseInt(rec.h[0],16) % 8;
            const path = this.ringFiles[nib];
            if (!fs.existsSync(path)) fs.writeFileSync(path,'');
            fs.appendFileSync(path, JSON.stringify(rec)+'\n');
        }
      } else {
        if (!fs.existsSync(this.persistPath)) fs.writeFileSync(this.persistPath, '');
        fs.appendFileSync(this.persistPath, this.persistBuffer.map(o => JSON.stringify(o)).join('\n') + '\n');
      }
      this.persistBuffer = [];
      // Rotation / compaction for each ring file
      const rotateOne = (path) => {
        try {
          const st = fs.statSync(path);
          const maxBytes = parseInt(process.env.CRYSTAL_RING_MAX_BYTES || '10000000',10); // 10MB default per ring
          if (st.size > maxBytes) {
            const data = fs.readFileSync(path,'utf8').trim().split(/\n/);
            if (data.length > this.ringSize) {
              // Deterministic trim using latestAuditHash derived offset (prevents biased survival)
              const basis = this.latestAuditHash || crypto.createHash('sha256').update(path+String(this.totalCrystals)).digest('hex');
              const v = parseInt(basis.slice(0,6),16)/0xFFFFFF; // 0..1
              const keep = data.slice(-this.ringSize);
              // Down-sample head deterministically
              const head = keep.slice(0, Math.floor(keep.length/2)).filter((_,i)=> (i % (2 + Math.floor(v*2)))===0);
              const tail = keep.slice(Math.floor(keep.length/2));
              const merged = head.concat(tail);
              fs.writeFileSync(path, merged.join('\n')+'\n');
              console.log('[CrystalTuner] Ring rotation', path, 'size->', st.size);
            }
          }
        } catch(_){}
      };
      if (this.partition8) {
        for (const p of this.ringFiles) rotateOne(p);
        // Global cap management (~350GB) when CRYSTAL_GLOBAL_CAP_GB set
        const capGb = parseInt(process.env.CRYSTAL_GLOBAL_CAP_GB || '0',10);
        if (capGb>0) {
          const total = this.ringFiles.reduce((s,p)=>{ try { return s + fs.statSync(p).size; } catch(_){ return s; } },0);
          const capBytes = capGb * 1024 * 1024 * 1024;
          if (total > capBytes) {
            // Down-sample each file: keep every 4th line deterministically
            for (const p of this.ringFiles) {
              try {
                const d = fs.readFileSync(p,'utf8').trim().split(/\n/);
                const slim = d.filter((_,i)=> i % 4 === 0);
                fs.writeFileSync(p, slim.join('\n')+'\n');
              } catch(_){ }
            }
            console.log('[CrystalTuner] Global cap down-sample applied (partition8)');
          }
        }
      } else {
        rotateOne(this.persistPath);
      }
    } catch (e) {
      console.warn('[CrystalTuner] Persist failed:', e.message);
    }
  }
  async unloadCrystals() {
    if (!this.crystals.length) return; // nothing to unload
    const PARALLEL = process.env.OFFLOAD_PARALLEL === '1';
    const batch = this.crystals.map(c => c.coeffs);
    const primaryOrder = ['ipfs','helia','filecoin','arweave'];
    const results = {};
    const doIpfs = async ()=>{
      if (!(this.ipfsEnabled && this.ipfsClient)) return;
      const dataBuf = Buffer.from(JSON.stringify({ t: Date.now(), batch }));
      const added = await this.ipfsClient.add(dataBuf, { pin: true });
      const cid = added.cid.toString();
      this.logIpfsCid(cid, batch.length);
      console.log(`[IPFS] Offloaded ${batch.length} crystals -> CID ${cid}`);
      results.ipfs = { cid };
    };
    const doHelia = async ()=>{
      if (!(this.heliaEnabled && this.heliaFs)) return;
      const bytes = Buffer.from(JSON.stringify({ t: Date.now(), batch }));
      const cid = await this.heliaFs.addBytes(bytes);
      const cidStr = cid.toString();
      this.logIpfsCid(cidStr, batch.length);
      console.log(`[Helia] Offloaded ${batch.length} crystals -> CID ${cidStr}`);
      results.helia = { cid: cidStr };
    };
    const doFilecoin = async ()=>{
      if (!(this.filecoinEnabled && this.filecoinClient)) return;
      const contents = Buffer.from(JSON.stringify(batch));
      const fileName = `crystals-${Date.now()}.json`;
      const file = new (class FakeFile { constructor(buf,name){ this.buf=buf; this.name=name; this.size=buf.length; this.type='application/json'; } stream(){ const { Readable } = require('stream'); return Readable.from(this.buf);} arrayBuffer(){ return Promise.resolve(this.buf);} text(){ return Promise.resolve(this.buf.toString()); } get [Symbol.toStringTag](){ return 'File'; } })(contents,fileName);
      const cid = await this.filecoinClient.put([file], { name: fileName });
      this.logFilecoinCid(cid, batch.length);
      console.log(`[Filecoin] Offloaded ${batch.length} crystals -> CID ${cid}`);
      results.filecoin = { cid };
    };
    const doArweave = async ()=>{
      if (!arweave) return;
      if (!process.env.ARWEAVE_WALLET_JSON) { console.warn('[CrystalTuner] No wallet - skipping Arweave'); return; }
      const fs = require('fs');
      const walletPath = process.env.ARWEAVE_WALLET_JSON;
      if (!fs.existsSync(walletPath)) { console.warn('[CrystalTuner] Wallet missing - skipping Arweave'); return; }
      const walletKey = JSON.parse(fs.readFileSync(walletPath,'utf8'));
      const tx = await arweave.createTransaction({ data: JSON.stringify(batch) }, walletKey);
      await arweave.transactions.sign(tx, walletKey);
      const res = await arweave.transactions.post(tx);
      if (res.status && res.status >= 400) throw new Error(`Arweave TX failed: ${res.status}`);
      console.log(`[CrystalTuner] Unloaded ${batch.length} crystals -> TX ${tx.id}`);
      results.arweave = { cid: tx.id };
    };
    try {
      if (PARALLEL){
        const tasks = [];
        if (this.ipfsEnabled && this.ipfsClient) tasks.push(doIpfs());
        if (this.heliaEnabled && this.heliaFs) tasks.push(doHelia());
        if (this.filecoinEnabled && this.filecoinClient) tasks.push(doFilecoin());
        if (arweave) tasks.push(doArweave());
        await Promise.allSettled(tasks);
      } else {
        try { await doIpfs(); } catch(e){ console.warn('[IPFS] Offload failed:', e.message);} 
        try { await doHelia(); } catch(e){ console.warn('[Helia] Offload failed:', e.message);} 
        try { await doFilecoin(); } catch(e){ console.warn('[Filecoin] Offload failed:', e.message);} 
        try { await doArweave(); } catch(e){ console.warn('[Arweave] Offload failed:', e.message);} 
      }
      // Pick primary in deterministic priority order for audit binding
      for (const k of primaryOrder){
        if (results[k]){ this.lastCid = results[k].cid; this.logAudit(k, results[k].cid, batch.length); break; }
      }
      if (!this.lastCid) {
        // No backend succeeded
        this.fallbackPersist();
      }
    } catch (err) {
      console.warn('[CrystalTuner] Parallel offload error:', err.message);
      this.fallbackPersist();
    }
    if (!arweave && !this.lastCid) { this.fallbackPersist(); }
    try {
      this.crystals = []; // Always clear
    } catch(_) { this.crystals = []; }
  }
  fallbackPersist() {
    try {
      const fs = require('fs');
      fs.appendFileSync('crystal-fallback.jsonl', JSON.stringify({ t: Date.now(), crystals: this.crystals.map(c => c.coeffs) }) + '\n');
    } catch (_) {}
  }
  logIpfsCid(cid, count) {
    try {
      const fs = require('fs');
      const rec = { t: Date.now(), cid, count };
      fs.appendFileSync(this.ipfsCidLog, JSON.stringify(rec) + '\n');
    } catch (e) {
      console.warn('[IPFS] CID log append failed:', e.message);
    }
  }
  logFilecoinCid(cid, count) {
    try {
      const fs = require('fs');
      const rec = { t: Date.now(), cid, count };
      fs.appendFileSync(this.filecoinCidLog, JSON.stringify(rec) + '\n');
    } catch (e) {
      console.warn('[Filecoin] CID log append failed:', e.message);
    }
  }
  logAudit(kind, cid, count) {
    try {
      const fs = require('fs');
      // Create deterministic chain link: hash(lastCid||'genesis' + cid + count)
      const prev = this.prevAuditHash || 'genesis';
      const linkHash = crypto.createHash('sha256').update(prev + cid + String(count)).digest('hex');
      const rec = { t: Date.now(), kind, cid, count, prev, hash: linkHash };
      fs.appendFileSync(this.auditLogPath, JSON.stringify(rec) + '\n');
      this.prevAuditHash = linkHash; this.latestAuditHash = linkHash;
    } catch (e) {
      console.warn('[Audit] log append failed:', e.message);
    }
  }
  recalcThreshold() {
    // Geodesic-based deterministic adaptation: derive virtual vectors from last norms
    const basis = this.latestAuditHash || crypto.createHash('sha256').update(String(this.totalCrystals)).digest('hex');
    const vSeed = parseInt(basis.slice(0,6), 16) / 0xFFFFFF; // [0,1)
    // Approximate S^7 geodesic variance: sample 8 pseudo-norms from hash stream
    const coeffs = [];
    for (let i=0;i<8;i++) coeffs.push(parseInt(basis.slice(6+i*2, 8+i*2) || 'ff',16)/255);
    const mean = coeffs.reduce((a,b)=>a+b,0)/coeffs.length;
    const varSum = coeffs.reduce((a,b)=> a + (b-mean)*(b-mean),0)/coeffs.length;
    // Map variance into [0,1]
    const normVar = Math.min(1, varSum / 0.05); // assume 0.05 upper typical
    // Combine with seed factor to position inside unload range
    const span = this.maxUnload - this.minUnload;
    const geodesicFactor = (vSeed*0.6) + (1-normVar)*0.4; // higher variance -> lower threshold to unload sooner
    this.unloadThreshold = this.minUnload + Math.floor(span * geodesicFactor);
    if (this.unloadThreshold < this.minUnload) this.unloadThreshold = this.minUnload;
    if (this.unloadThreshold > this.maxUnload) this.unloadThreshold = this.maxUnload;
    console.log(`[CrystalTuner] Adaptive unloadThreshold=${this.unloadThreshold} (geoFactor=${geodesicFactor.toFixed(3)} var=${normVar.toFixed(3)})`);
  }
  async reloadFromIpfs(cid) {
    if (!this.ipfsEnabled || !this.ipfsClient) throw new Error('IPFS not enabled');
    const chunks = [];
    for await (const chunk of this.ipfsClient.cat(cid)) chunks.push(chunk);
    const data = Buffer.concat(chunks).toString();
    const parsed = JSON.parse(data);
    return (parsed.batch || []).map(coeffs => new SimpleOcto(coeffs));
  }
  async reloadFromFilecoin(cid) {
    if (!this.filecoinEnabled || !this.filecoinClient) throw new Error('Filecoin not enabled');
    const res = await this.filecoinClient.get(cid);
    if (!res) throw new Error('CID not found');
    const files = await res.files();
    if (!files.length) throw new Error('No files in CID');
    const buf = Buffer.from(await files[0].arrayBuffer());
    const batch = JSON.parse(buf.toString());
    return batch.map(coeffs => new SimpleOcto(coeffs));
  }
}
// Ensure global reference for external modules prior to final export block
global.PicoCrystalTuner = PicoCrystalTuner;

// In F2PoolAurreliaPipeline
// Removed misplaced constructor; initialization for picoCrystalTuner is handled in the F2PoolAurreliaPipeline class constructor.

// Removed obsolete inline guidance comments from earlier iterations.

// Real, persistent, event-driven manifold (up to 5 million nodes, built inward)
const MAX_NODES = 5000000;
const CRYSTAL_GLOBAL_CAP_GB = parseFloat(process.env.CRYSTAL_GLOBAL_CAP_GB || '0');
// Heuristic nodes per GB (memory footprint dominated by node objects + telemetry) ~25k nodes/GB
const NODES_PER_GB = parseInt(process.env.NODES_PER_GB || '25000',10);
const GLOBAL_NODE_CAP_BY_GB = CRYSTAL_GLOBAL_CAP_GB>0 ? Math.min(MAX_NODES, Math.floor(CRYSTAL_GLOBAL_CAP_GB * NODES_PER_GB)) : MAX_NODES;
const { QuantumTuner, NeuralNode } = require('./octonion-real-processor.js');
const mesh = new PicoMesh(MAX_NODES);
const lattice = [];
const manifold = [];
const quantumTuner = new QuantumTuner();
let nodeCount = 0;
let bytesProcessed = 0;
let lastThroughputLog = Date.now();
let cycleCount = 0; // For batching
// Global holodeck bytes processed exposure for deterministic throughput metrics
if (typeof global.__HOLO_BYTES_PROCESSED__ !== 'number') {
  global.__HOLO_BYTES_PROCESSED__ = 0;
}

class F2PoolAurreliaPipeline {
  constructor(user) {
    this.job = null;
    this.extranonce1 = '';
    this.extranonce2Size = 0;
    this.currentExtranonce2 = 0;
    this.stats = { hashes: 0, shares: 0, ths: 0 };
    // Per-pool performance tracking (latency & share efficiency)
    this.poolPerf = {
      // key -> { jobs:0, shares:0, lastJobTs:0, avgJobIntervalMs:null, shareAccepts:0, shareRejects:0, acceptanceRatio:0, spinWeightedScore:0 }
      map: new Map(),
      updateJob: (key)=>{
        const now = Date.now();
        let rec = this.poolPerf.map.get(key);
        if (!rec){ rec = { jobs:0, shares:0, lastJobTs:0, avgJobIntervalMs:null, shareAccepts:0, shareRejects:0, acceptanceRatio:0, spinWeightedScore:0 }; this.poolPerf.map.set(key, rec); }
        rec.jobs++;
        if (rec.lastJobTs){ const dt = now - rec.lastJobTs; rec.avgJobIntervalMs = rec.avgJobIntervalMs==null? dt : (rec.avgJobIntervalMs*0.8 + dt*0.2); }
        rec.lastJobTs = now;
      },
      updateShare: (key, accepted)=>{
        let rec = this.poolPerf.map.get(key);
        if (!rec){ rec = { jobs:0, shares:0, lastJobTs:0, avgJobIntervalMs:null, shareAccepts:0, shareRejects:0, acceptanceRatio:0, spinWeightedScore:0 }; this.poolPerf.map.set(key, rec); }
        rec.shares++;
        if (accepted) rec.shareAccepts++; else rec.shareRejects++;
        const total = rec.shareAccepts + rec.shareRejects;
        rec.acceptanceRatio = total? rec.shareAccepts/total : 0;
        // Spin-weighted scoring: combine acceptance + inverse avg job interval (favor more jobs) * spin gap ratio
        const spinGapRatio = (this.ruleStats && this.ruleStats.spin && this.ruleStats.spin.gapRatio != null) ? this.ruleStats.spin.gapRatio : 1;
        const intervalFactor = rec.avgJobIntervalMs? (1 / Math.max(1, rec.avgJobIntervalMs)) : 0;
        rec.spinWeightedScore = rec.acceptanceRatio + intervalFactor * spinGapRatio;
      }
    };
    // Hypercube rotation state
    this.hypercube = {
      blend: parseFloat(process.env.HYPERCUBE_BLEND || '0.05'),
      rotateEvery: parseInt(process.env.HYPERCUBE_ROTATE_HASHES || '0',10),
      lastRotHash: 0,
      subsetIdx: 0,
      sliceSize: parseInt(process.env.HYPERCUBE_SLICE_SIZE || '0',10),
      activeSlice: null
    };
    // Share-level efficiency stats (accepted/rejected/stale + sliding window + EMA shares/min)
    this.shareStats = {
      accepted: 0,
      rejected: 0,
      stale: 0,
      window: [], // { t, a, r }
      windowSpanMs: parseInt(process.env.SHARE_WINDOW_SPAN_MS || (10*60*1000).toString(),10), // default 10m
      lastShareTs: null,
      emaSharesPerMin: null,
      emaAlpha: parseFloat(process.env.SHARE_SPM_ALPHA || '0.2'),
      acceptanceRatio: 0,
      sharesPerMin: 0
    };
    // --- Adaptive Prune / Self-Learning Configuration ---
    this.pruneLearn = {
      enabled: process.env.AUR_PRUNE_LEARN !== '0',
      targetAccept: parseFloat(process.env.AUR_PRUNE_TARGET_ACCEPT || '0.25'), // desired fraction of gen candidates reaching verify-valid per attempt considered
      min: parseFloat(process.env.AUR_PRUNE_MIN || '1.6'),
      max: parseFloat(process.env.AUR_PRUNE_MAX || '3.2'),
      step: parseFloat(process.env.AUR_PRUNE_STEP || '0.05'),
      intervalMs: parseInt(process.env.AUR_PRUNE_LEARN_INTERVAL_MS || '10000',10),
      lastAdjust: 0,
      attempts: 0,
      accepted: 0,
      recent: [], // sliding window of {norm, ok}
      window: parseInt(process.env.AUR_PRUNE_WINDOW || '4000',10)
    };
    // Plane reinforcement stats (simple online learner)
    this.planeReinforce = { attempts: [0,0,0,0], accepts: [0,0,0,0], weights: [1,1,1,1], lastUpdate:0, intervalMs: 15000 };
    this.startTime = Date.now();
    this.started = false;
    this.cycleCount = 0;
    // Always use the real crystal tuner (no stubs / no simulation). Minimal mode simply disables external offloads.
    this.picoCrystalTuner = new PicoCrystalTuner();
    if (MINING_MINIMAL) {
      // Hard-disable persistence/offloads deterministically while preserving full data path.
      this.picoCrystalTuner.persistEnabled = false;
      this.picoCrystalTuner.ipfsEnabled = false;
      this.picoCrystalTuner.filecoinEnabled = false;
      this.picoCrystalTuner.heliaEnabled = false;
      this.picoCrystalTuner.unloadThreshold = Number.MAX_SAFE_INTEGER; // effectively never offload
      if (!global.__AUR_MINIMAL_REAL_TUNER__) {
        console.log('[Aurrelia][Minimal] Real crystal tuner active; all external offloads disabled (deterministic, no simulation).');
        global.__AUR_MINIMAL_REAL_TUNER__ = 1;
      }
    }
    this.crystalBias = (!MINING_MINIMAL) && process.env.CRYSTAL_TUNING === '1';
    // Roman decoder wheels (multi-plane spiral) initialized lazily once job + extranonce1 available
    this.romanWheels = [];
    this.lastRomanSeed = '';
  this.latestPlaneWeights = null; // for telemetry
  this.telemetryEnabled = process.env.METRICS === '1';
  this.telemetryIntervalMs = parseInt(process.env.METRICS_INTERVAL || '7000',10);
  this.lastTelemetry = Date.now();
  this.planeShareCounts = [0,0,0,0];
  this.totalPlaneShares = 0;
  this.reinforceAlpha = parseFloat(process.env.PLANE_REINFORCE_ALPHA || '0.3');
  this.cachedPlaneSeeds = null;
  this.cachedXorSeed = null;
  this.cachedRomanCycle = -1;
  // Single-worker symbolic VM partitioning support
  this.symbolicVmEnabled = process.env.SYMBOLIC_VM === '1';
  this.vmProgramsByHarmonic = new Map();
  this.partitionStats = { attempts:{ h0:0,h1:0,h2:0,h3:0 }, accepts:{ h0:0,h1:0,h2:0,h3:0 } };
  this.partitionDecayFactor = 0.98; this.lastPartitionDecay = Date.now();
    // Recording rules for auto scaling decisions
    this.recordingRules = [
      { name:'lowEff',  query:(st)=> (st.acc < 0.90 && st.util > 0.80), action:'prune_8x' },
      { name:'highEff', query:(st)=> (st.acc > 0.95 && st.util < 0.20), action:'spawn_8x' }
    ];
    // Geometry ring buffer (persist recent utilization samples)
    this.geomRing = { buffer: [], max: parseInt(process.env.GEOM_RING_MAX || '500',10), path: process.env.GEOM_RING_PATH || 'geom-ring.jsonl', rotateMb: parseFloat(process.env.GEOM_RING_ROTATE_MB || '8') };
  this.ruleStats = { hits:{}, actions:{ prune_8x:0, spawn_8x:0 }, spin:{} };
    this.appendGeomSample = (nodeCt, util) => {
      const rec = { t: Date.now(), nodeCount: nodeCt, geomUtil: util };
      this.geomRing.buffer.push(rec);
      if (this.geomRing.buffer.length > this.geomRing.max) this.geomRing.buffer.shift();
      const fs = require('fs');
      try {
        // Rotation: if file exceeds rotateMb, truncate by rewriting last half of in-memory buffer
        let rotate = false;
        if (this.geomRing.rotateMb > 0 && fs.existsSync(this.geomRing.path)){
          const sz = fs.statSync(this.geomRing.path).size;
            if (sz > this.geomRing.rotateMb * 1024 * 1024) rotate = true;
        }
        if (rotate){
          const tail = this.geomRing.buffer.slice(-Math.floor(this.geomRing.max/2));
          fs.writeFileSync(this.geomRing.path, tail.map(r=>JSON.stringify(r)).join('\n')+'\n');
        } else {
          fs.appendFileSync(this.geomRing.path, JSON.stringify(rec)+"\n");
        }
      } catch(_){ }
    };
    // Periodic persistence of ruleStats (if enabled)
    if (process.env.RULE_PERSIST === '1'){
      const statsPath = process.env.RULE_STATS_PATH || 'rule-stats-ring.jsonl';
      const rotateMb = parseFloat(process.env.RULE_STATS_ROTATE_MB || '2');
      setInterval(()=>{
        try {
          const fs = require('fs');
          let pcts = null;
          if (global.__AUR_SPIN_SAMPLES__ && global.__AUR_SPIN_SAMPLES__.length){
            const cp = [...global.__AUR_SPIN_SAMPLES__].sort((a,b)=>a-b);
            function pct(p){ const i = Math.floor(p*(cp.length-1)); return cp[i]; }
            pcts = { p50:pct(0.50), p90:pct(0.90), p99:pct(0.99) };
          }
          let gapRatio = null;
          try {
            if (pcts && pcts.p50!=null && pcts.p90!=null){
              const gap = pcts.p90 - pcts.p50;
              const avg = (pcts.p50 + pcts.p90)/2;
              const targetGap = avg * 0.25; // heuristic anchor
              if (targetGap>0) gapRatio = gap/targetGap;
            }
          } catch(_){ }
          if (gapRatio!=null) this.ruleStats.spin.gapRatio = gapRatio;
          const snap = { schema:'aurrelia.ruleStats.v2', t: Date.now(), hits: this.ruleStats.hits, actions: this.ruleStats.actions, spinPowerP: pcts, rashbaGain: global.__AUR_RASHBA_GAIN__, spin: this.ruleStats.spin };
          let rotate = false;
          if (rotateMb>0 && fs.existsSync(statsPath)){
            const sz = fs.statSync(statsPath).size; if (sz > rotateMb*1024*1024) rotate = true;
          }
            if (rotate){
              // Keep only last 80% of lines
              const lines = fs.readFileSync(statsPath,'utf8').trim().split(/\n/);
              const keep = lines.slice(Math.floor(lines.length*0.2));
              fs.writeFileSync(statsPath, keep.join('\n')+'\n');
            }
          fs.appendFileSync(statsPath, JSON.stringify(snap)+'\n');
        } catch(e){ /* ignore */ }
      }, parseInt(process.env.RULE_STATS_INTERVAL_MS || '30000',10)).unref();
    }
    // Adaptive fused batch hashing controls
    this.adaptiveBatchEnabled = process.env.ADAPTIVE_BATCH === '1';
    this.batchMin = parseInt(process.env.BATCH_MIN || '16',10);
    this.batchMax = parseInt(process.env.BATCH_MAX || '512',10);
    this.batchLatencyMaxMs = parseInt(process.env.BATCH_LATENCY_MAX_MS || '25',10); // desired upper bound per batch
    this.batchAdjustEvery = parseInt(process.env.BATCH_ADJUST_INTERVAL || '12',10); // adjust after N batches sampled
    this.currentBatchSize = parseInt(process.env.BATCH_SIZE || '128',10);
    if (this.currentBatchSize < this.batchMin) this.currentBatchSize = this.batchMin;
    if (this.currentBatchSize > this.batchMax) this.currentBatchSize = this.batchMax;
    this.batchPerfSamples = []; // store recent {size, ms, perHeaderNs}
    this.fusedBatchCount = 0;
    this.fusedParityInterval = parseInt(process.env.FUSED_PARITY_SAMPLE_INTERVAL || '50',10); // sample every N batches
    this.fusedSpeedupEwma = null; // exponential moving average of speedup vs JS
    this.fusedSpeedupAlpha = parseFloat(process.env.FUSED_SPEEDUP_ALPHA || '0.3');
    // Fused auto-recovery controls
    this.fusedRecoverCooldownMs = parseInt(process.env.FUSED_RECOVER_COOLDOWN_MS || '60000',10);
    this.fusedLastDisableTime = 0;
    this.fusedConsecRecoverPasses = 0;
    this.fusedRecoverThreshold = parseInt(process.env.FUSED_RECOVER_CONSEC || '2',10);
    this.fusedRecoverCases = parseInt(process.env.FUSED_RECOVER_SELFTEST_CASES || '4',10);
  this.fusedRecoverAttempts = 0;
  this.fusedRecoverSuccesses = 0;
  this.fusedRecoverFailures = 0;
  this.fusedLastRecoverTs = 0;
  this.fusedRampActive = false;
  this.fusedRampTarget = 0;
  this._fusedRampBatchCounter = 0;
  // Separate anomaly counters
  this.parityMismatchAnomalyCount = 0; // mismatches
  this.varianceAnomalyCount = 0; // high CV variance triggers
  // Enhanced ramp latency statistics & adaptive parity sampling
  this.rampLatencySamples = [];
  this.rampLatencyWindow = parseInt(process.env.FUSED_RAMP_LAT_WIN || '20',10);
  this.rampMaxCv = parseFloat(process.env.FUSED_RAMP_MAX_CV || '0.25'); // coefficient of variation cap for stepping
  this.rampHeadroomFactor = parseFloat(process.env.FUSED_RAMP_HEADROOM || '0.9'); // projected doubled batch must remain under headroom * max latency
  this.parityIntervalMin = parseInt(process.env.FUSED_PARITY_MIN || '10',10);
  this.parityIntervalMax = parseInt(process.env.FUSED_PARITY_MAX || '400',10);
  this.parityIncreaseFactor = parseFloat(process.env.FUSED_PARITY_INCREASE || '1.5');
  this.parityDecreaseFactor = parseFloat(process.env.FUSED_PARITY_DECREASE || '0.5');
  this.parityAdjustEvery = parseInt(process.env.FUSED_PARITY_ADJUST_EVERY || '8',10);
  this.parityStableBatches = 0;
  this.parityAnomalyCount = 0;
  this.lastLatencyAnomalyTs = 0;
  this.varianceAnomalyCount = 0; // variance/CV anomalies
  this.parityMismatchAnomalyCount = 0; // parity mismatches
    // JS baseline benchmarking
    this.jsBaselineIntervalMs = parseInt(process.env.JS_BASELINE_INTERVAL_MS || '300000',10); // 5 min
    this.lastJsBaseline = 0; this.jsBaselineNs = null;
    // Latency histogram buckets (ns per header)
  this.latencyBucketBounds = [5000,10000,20000,40000,80000]; // last bucket = inf
  this.latencyBuckets = Object.fromEntries(this.latencyBucketBounds.map(b=>[b,0]).concat([["inf",0]]));
  this.fusedLatencyCount = 0; // total observed header latency measurements
  this.fusedLatencyTotalNs = 0; // cumulative sum of per-header latency ns
  // Throughput growth event horizon detection
  this.throughputSamples = []; // {t, bytes, bps, nodes}
  this.eventHorizonTs = 0;
  this.lastSlopeSign = 0;
  this.nodeThroughputSlope = 0;
    // Speedup history persistence
    this.speedupHistoryLog = process.env.FUSED_SPEEDUP_HISTORY_LOG || 'fused-speedup-history.jsonl';
  this.speedupHistoryMaxLines = parseInt(process.env.FUSED_SPEEDUP_HISTORY_MAX_LINES || '5000',10);
  this.speedupHistoryCompactEvery = parseInt(process.env.FUSED_SPEEDUP_HISTORY_COMPACT_EVERY || '200',10);
  this._speedupHistoryAppendCount = 0;
    // Global metrics object extension
    if (global.__AUR_WASM_METRICS__) {
      global.__AUR_WASM_METRICS__.fusedSpeedupEst = 0;
      global.__AUR_WASM_METRICS__.currentBatchSize = this.currentBatchSize;
      global.__AUR_WASM_METRICS__.jsBaselineNs = 0;
                global.__AUR_WASM_METRICS__.fusedLatencyBuckets = this.latencyBuckets || {};
  global.__AUR_WASM_METRICS__.fusedLatencyCount = this.fusedLatencyCount;
  global.__AUR_WASM_METRICS__.fusedLatencyTotalNs = this.fusedLatencyTotalNs;
  global.__AUR_WASM_METRICS__.fusedRecoverAttempts = this.fusedRecoverAttempts;
  global.__AUR_WASM_METRICS__.fusedRecoverSuccesses = this.fusedRecoverSuccesses;
  global.__AUR_WASM_METRICS__.fusedRecoverFailures = this.fusedRecoverFailures;
  global.__AUR_WASM_METRICS__.fusedLastRecoverTs = this.fusedLastRecoverTs;
      global.__AUR_WASM_METRICS__.fusedParityInterval = this.fusedParityInterval;
      global.__AUR_WASM_METRICS__.fusedParityAnomalies = this.parityAnomalyCount;
  global.__AUR_WASM_METRICS__.fusedVarianceAnomalies = this.varianceAnomalyCount;
          global.__AUR_WASM_METRICS__.fusedParityMismatchAnomalies = this.parityMismatchAnomalyCount;
    }
    // Coin selection (initial: BTC or LTC merged set using same logic but different port)
    // Set AUR_COIN=ltc or pass --coin=ltc to target f2pool merged LTC+DOGE/BELLS/LKY/PEP/JKC/DINGO/SHIC/CRC on port 1315
    // Default: btc
  // Solo CKPool support: pass --coin=btc_ckpool or set AUR_COIN=btc_ckpool and STRATUM user=YOUR_BTC_WALLET password=anything
    const COINS = require('./coin-config.js');
    const coinArg = (process.argv.find(a=>a.startsWith('--coin='))||'').split('=')[1];
    const requestedCoin = (process.env.AUR_COIN || coinArg || 'btc').toLowerCase();
    const experimental = process.env.AUR_EXPERIMENTAL === '1' || process.argv.includes('--experimental');
    let cfg = COINS[requestedCoin];
    if (!cfg) { console.warn('[Coin] Unsupported coin requested, defaulting to btc'); cfg = COINS.btc; }
    if (cfg.experimental && !experimental){
      console.warn(`[Coin] ${requestedCoin} requires experimental flag; reverting to btc`);
      cfg = COINS.btc;
    }
    // Determine final coin key
    this.selectedCoin = Object.entries(COINS).find(([,v])=> v === cfg)?.[0] || 'btc';
    this.selectedAlgo = cfg.algo;
    this.hashStrategy = HASH_STRATEGIES[this.selectedAlgo] || HASH_STRATEGIES.sha256d;
    // Expose selection globally for holodeck/reporting layers
    try {
      global.__AUR_SELECTED_COIN__ = this.selectedCoin;
      global.__AUR_SELECTED_ALGO__ = this.selectedAlgo;
    } catch(_gSel){}
    // Safe local capture of scryptsy module (may already have been loaded in hash-strategies); used later in enforcement block
    let scryptsy = null; try { scryptsy = require('scryptsy'); } catch(_scryptLoad){}
    // Lightweight scrypt shim if scryptsy dependency absent to avoid crash in deterministic test harness.
    if (this.selectedAlgo === 'scrypt' && (!this.hashStrategy || this.hashStrategy.id === 'sha256d')){
      // Attempt dynamic require of scryptsy only now (lazy) to keep startup lean.
      try {
        const scryptsy = require('scryptsy');
        HASH_STRATEGIES.scrypt = {
          id: 'scrypt',
          hashHeader: (headerBuf) => {
            // Litecoin style header hashing: scrypt(N=1024,r=1,p=1, 80 bytes, 32 out)
            const out = scryptsy(headerBuf, headerBuf, 1024, 1, 1, 32);
            return out;
          }
        };
        this.hashStrategy = HASH_STRATEGIES.scrypt;
        console.log('[Scrypt] Loaded scryptsy module at runtime.');
      } catch(e){
        // Deterministic placeholder: reuse double sha256 but label degraded.
        HASH_STRATEGIES.scrypt = {
          id: 'scrypt',
          hashHeader: (headerBuf) => doubleSHA256(headerBuf) // preserves deterministic bytes progression.
        };
        this.hashStrategy = HASH_STRATEGIES.scrypt;
        console.warn('[Scrypt] scryptsy not installed; using deterministic doubleSHA256 placeholder (NOT real scrypt).');
      }
    }
    // Debug trace for coin selection to validate env propagation during smoke tests
    try {
      console.log(`[CoinSelect] requested=${requestedCoin} experimentalRequested=${experimental} cfg.experimental=${cfg.experimental || false} finalCoin=${this.selectedCoin} algo=${this.selectedAlgo}`);
    } catch(_){ }
    // Deterministic multi-coin target computation helper
    const computeCoinTarget = (nbits, coin) => {
      // Base target from nbits (Bitcoin-style compact encoding)
      let base; try { base = nbitsToTarget(nbits); } catch(_) { base = 0n; }
      if (!coin) return base;
      switch(coin){
        case 'ltc':
          // Litecoin shares diff encoding is similar; retain base
          return base;
        case 'rvn':
          // KawPow dynamic target often differs; keep base for determinism until real RPC template used
          return base;
        case 'fren':
          // FREN placeholder: derive a deterministic scaled target using coin label hash for slight variation
          try {
            const h = crypto.createHash('sha256').update('fren:'+nbits).digest('hex');
            const tweak = BigInt('0x'+h.slice(0,12)); // 48 bits tweak
            const scale = 1n + (tweak % 7n); // small deterministic multiplier 1..7
            const t = base / scale; // tighter target (harder) ensures no accidental easy shares
            return t>0n ? t : base;
          } catch(_) { return base; }
        default:
          return base;
      }
    };
    this.computeCoinTarget = computeCoinTarget;

    // Placeholder deterministic FREN hash (KawPow planned); reuse doubleSha256 with label mixing for now
    const frenMixHash = (headerHex) => {
      const m = crypto.createHash('sha256').update('fren-mix:'+headerHex).digest('hex');
      return crypto.createHash('sha256').update(m).digest('hex');
    };
    this.frenMixHash = frenMixHash;
    // Auto-generate FREN wallet if mining fren and env missing (with HMAC guard)
    if (this.selectedCoin === 'fren' && !process.env.FREN_WALLET){
      try {
        const fs = require('fs');
        const rpcUser = process.env.FREN_RPC_USER; const rpcPass = process.env.FREN_RPC_PASS; const rpcHost = process.env.FREN_RPC_HOST || 'localhost'; const rpcPort = process.env.FREN_RPC_PORT || '8332';
        let addrObj = null;
        if (rpcUser && rpcPass){
          try {
            // Synchronous RPC attempt placeholder (actual async call deferred outside constructor)
            const { generateFRENAddress } = require('./fren-wallet-swap.js');
            if (typeof generateFRENAddress === 'function'){
              console.log('[FREN] RPC generation deferred (constructor sync).');
            }
          } catch(_){ /* ignore RPC sync failure */ }
        }
        if (!addrObj){
          // Deterministic FREN address derivation (placeholder): derive pseudo key from seed then Base58Check encode.
          // NOTE: This is NOT a secure wallet generation; for real mining replace with proper key derivation using cryptographically secure seed.
          const seedSrc = process.env.CONFIG_HMAC_KEY || 'fren-deterministic-seed-v1';
          const seed = crypto.createHash('sha256').update(seedSrc).digest();
          // Use first 20 bytes for pubKeyHash body (like RIPEMD160 result) deterministically.
          const body = seed.subarray(0,20);
          const version = Buffer.from([0x1e]); // FREN pubKeyHash version (placeholder, mirrors Litecoin 0x30? here 0x1e from network def)
          const payload = Buffer.concat([version, body]);
          const checksum = crypto.createHash('sha256').update(
            crypto.createHash('sha256').update(payload).digest()
          ).digest().subarray(0,4);
          const full = Buffer.concat([payload, checksum]);
          const ALPH = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
          let x = BigInt('0x'+full.toString('hex'));
          let b58='';
          while (x > 0n){ const r = x % 58n; b58 = ALPH[Number(r)] + b58; x /= 58n; }
          // Preserve leading zeros as '1'
          for (let i=0;i<payload.length && payload[i]===0;i++) b58 = '1'+b58;
          addrObj = { address: 'F'+b58.slice(1), wif: null, source:'deterministic' }; // Force leading 'F'
        }
        if (addrObj && addrObj.address && /^F[1-9A-HJ-NP-Za-km-z]{25,34}$/.test(addrObj.address)){
          process.env.FREN_WALLET = addrObj.address;
          const hmac = process.env.CONFIG_HMAC_KEY ? crypto.createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(addrObj.address).digest('hex').slice(0,16) : null;
          const envLines = [`FREN_WALLET=${addrObj.address}`]; if (hmac) envLines.push(`FREN_WALLET_HMAC=${hmac}`);
          try { fs.appendFileSync('.fren-env', envLines.join('\n')+'\n'); } catch(_){ }
          console.log('[FREN] Auto-generated wallet address:', addrObj.address, 'source:', addrObj.source);
        } else {
          console.warn('[FREN] Wallet generation failed validation pattern');
          if (process.env.REAL_MINING_ENFORCED==='1'){ console.error('[FREN] Enforcement active; aborting.'); process.exit(11); }
        }
  } catch(e){ console.warn('[FREN] Auto-generation error', e.message); if (process.env.REAL_MINING_ENFORCED==='1') process.exit(12); else { process.env.FREN_WALLET='FMockTestAddressForDebug'; console.log('[FREN] Mock wallet for testing (enforcement off)'); } }
    }
    if (this.selectedCoin === 'fren'){
      // HMAC verification (STRICT_INTEGRITY aborts if mismatch)
      try {
        const fs = require('fs');
        const envPath = '.fren-env';
        let fileHmac = null;
        if (fs.existsSync(envPath)){
          const content = fs.readFileSync(envPath,'utf8');
          const line = content.split(/\r?\n/).find(l=>/^FREN_WALLET_HMAC=/.test(l));
          if (line) fileHmac = line.split('=')[1].trim();
        }
        if (process.env.CONFIG_HMAC_KEY && process.env.FREN_WALLET){
          const recomputed = crypto.createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(process.env.FREN_WALLET).digest('hex').slice(0,16);
          if (!fileHmac || recomputed !== fileHmac){
            console.warn('[FREN] Wallet HMAC mismatch or missing');
            if (process.env.STRICT_INTEGRITY === '1'){ console.error('[FREN] STRICT_INTEGRITY abort'); process.exit(13); }
          } else { console.log('[FREN] Wallet HMAC verified'); }
        }
      } catch(e){ console.warn('[FREN] HMAC verify error', e.message); if (process.env.STRICT_INTEGRITY === '1') process.exit(14); }
      console.log('[FREN] Using wallet', process.env.FREN_WALLET || '(unset)');
    }
  // GPU automatic backoff / re-enable
  this.gpuDisabledAt = 0;
  this.gpuBackoffMs = parseInt(process.env.GPU_BACKOFF_MS || '60000',10);
  this.gpuAutoReEnable = process.env.GPU_AUTO_REENABLE !== '0';
  this.gpuPendingMeta = []; // for queued GPU batch headers (sha256d only)
  this.useGpuBatch = (GPU_ENABLED && this.selectedAlgo === 'sha256d');
  // Adaptive GPU batch controls (separate from fused WASM)
  this.gpuBatchSize = parseInt(process.env.GPU_BATCH_SIZE || '128',10);
  this.gpuBatchMin = parseInt(process.env.GPU_BATCH_MIN || '32',10);
  this.gpuBatchMax = parseInt(process.env.GPU_BATCH_MAX || '1024',10);
  this.gpuBatchLatencyMaxMs = parseFloat(process.env.GPU_BATCH_LATENCY_MAX_MS || '25');
  this.gpuBatchAdjustEvery = parseInt(process.env.GPU_BATCH_ADJUST_EVERY || '10',10);
  this._gpuBatchPerf = []; // {size, ms, perHeaderNs}
  if (this.gpuBatchSize < this.gpuBatchMin) this.gpuBatchSize = this.gpuBatchMin;
  if (this.gpuBatchSize > this.gpuBatchMax) this.gpuBatchSize = this.gpuBatchMax;
  if (!global.__AUR_GPU_STATS__) global.__AUR_GPU_STATS__ = { batches:0, headers:0, totalNs:0, lastBatchNs:0, parityChecks:0, parityMismatches:0 };
  global.__AUR_GPU_STATS__.currentBatchSize = this.gpuBatchSize;
  const poolServer = cfg.server;
  const poolPort = cfg.port;
  // Baseline diff1 target for share difficulty reporting (per-coin configurable in coin-config)
  try { this.diff1Target = nbitsToTarget(cfg.diff1bits || '1d00ffff'); } catch(_) { this.diff1Target = 0n; }
  console.log(`[Coin] Active coin=${this.selectedCoin} algo=${this.selectedAlgo} server=${poolServer}:${poolPort}`);
  // --- Strict real-wallet enforcement ---
  if (process.env.REAL_MINING_ENFORCED === '1'){
    const crypto = require('crypto');
    function doubleSha(b){ return crypto.createHash('sha256').update(crypto.createHash('sha256').update(b).digest()).digest(); }
    const b58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    const b58Map = new Map(b58Alphabet.split('').map((c,i)=>[c,i]));
    function b58Decode(str){ let n=0n; for(const ch of str){ const v=b58Map.get(ch); if(v==null) return null; n=n*58n+BigInt(v);} let bytes=[]; while(n>0n){ bytes.push(Number(n & 0xffn)); n >>= 8n;} bytes=bytes.reverse(); let leading=0; for(const c of str){ if(c==='1') leading++; else break;} if(leading){ bytes = new Array(leading).fill(0).concat(bytes);} return Buffer.from(bytes); }
    function validateBase58Check(addr){ if(!addr||typeof addr!=='string') return false; const s=addr.trim(); if(!/^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/.test(s)) return false; if(s.length<26||s.length>42) return false; const decoded=b58Decode(s); if(!decoded||decoded.length<5) return false; const payload=decoded.slice(0,-4); const checksum=decoded.slice(-4); const exp=doubleSha(payload).slice(0,4); if(!checksum.equals(exp)) return false; return { payload, version: payload[0] }; }
    function enforceAddr(envKey, opts){
      const val = process.env[envKey];
      if(!val){ console.error(`[ENFORCE] Missing required address env ${envKey}`); process.exit(2); }
      const v = validateBase58Check(val);
      if(!v){ console.error(`[ENFORCE] Invalid Base58Check address in ${envKey}: ${val}`); process.exit(2); }
      if(opts && opts.prefix && !val.startsWith(opts.prefix)){ console.error(`[ENFORCE] Address ${envKey} must start with ${opts.prefix}`); process.exit(2); }
      if(opts && opts.version && v.version !== opts.version){ console.error(`[ENFORCE] Address ${envKey} version byte mismatch expected 0x${opts.version.toString(16)} got 0x${v.version.toString(16)}`); process.exit(2); }
      console.log(`[ENFORCE] ${envKey} OK (version=0x${v.version.toString(16)})`);
    }
    try {
      if (this.selectedCoin === 'btc'){ enforceAddr('BTC_MINING_ADDRESS', { /* BTC P2PKH 0x00 starts with '1' */ }); }
      if (this.selectedCoin === 'ltc'){ enforceAddr('LTC_KRAKEN_ADDRESS'); }
      if (this.selectedCoin === 'rvn'){ enforceAddr('RVN_LOCAL_ADDRESS', { version: 0x3c, prefix: 'R' }); }
      if (this.selectedCoin === 'fren'){ enforceAddr('FREN_WALLET'); }
    } catch(e){ console.error('[ENFORCE] Wallet validation exception', e.message); process.exit(2); }
  }
    if (this.selectedAlgo !== 'sha256d'){
      // Require experimental flag and backend availability (or explicit placeholder allow)
      const allowPlaceholder = process.env.AUR_ALLOW_PLACEHOLDER === '1';
      if (this.selectedAlgo === 'scrypt'){
        // Real enforcement: must have scryptsy loaded (litecoinScryptHash) unless explicitly overridden
        const realRequired = process.env.REAL_MINING_ENFORCED === '1';
        const experimental = process.env.ALLOW_EXPERIMENTAL === '1';
        if (!scryptsy) {
          if (realRequired || !allowPlaceholder){
            console.error('[LTC] scryptsy module missing and real enforcement active. Install with: npm install scryptsy');
            process.exit(1);
          } else {
            console.warn('[LTC] scryptsy missing but placeholder allowed (NOT recommended for real mining).');
          }
        } else if (realRequired && !experimental) {
          // Accept since we have real scrypt; just note enforcement applied
          console.log('[LTC] Real scrypt hash path active under enforcement.');
        }
        // Validate LTC diff1 bits if coin config supplies reference (COINS.ltc.diff1bits_reference)
        try {
          if (cfg.diff1bits_reference && cfg.diff1bits && cfg.diff1bits_reference.toLowerCase() !== cfg.diff1bits.toLowerCase()){
            console.warn(`[LTC] diff1bits mismatch config=${cfg.diff1bits} ref=${cfg.diff1bits_reference}`);
          }
        } catch(_){ }
      }
    }
    // Derive F2Pool worker credentials (F2Pool pays to account-level payout address configured on their site)
    const baseUser = process.env.F2POOL_USER || user.split('.')[0];
    const workerSuffix = process.env.F2POOL_WORKER || user.split('.')[1] || '001';
    const workerName = `${baseUser}.${workerSuffix}`;
    const password = process.env.F2POOL_PASSWORD || process.env.MINER_PASSWORD || 'x'; // F2Pool usually ignores password, 'x' standard
    if (process.env.REAL_MINING_ENFORCED === '1' && !process.env.F2POOL_USER) {
      console.error('[ENFORCE] REAL_MINING_ENFORCED=1 requires F2POOL_USER env (your F2Pool account).');
      process.exit(1);
    }
  this.pendingShares = new Map();
  this.extranonce2Wraps = 0;

  // RVN regional fallback logic: if DNS fails, try us/asia/eu.raven.f2pool.com automatically.
  const self = this;
  // --- RVN wallet preflight (Base58Check, verbose) ---
  function base58Decode(str){
    const ALPH = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    const map = new Map(); for (let i=0;i<ALPH.length;i++) map.set(ALPH[i], i);
    let num = 0n;
    for (const ch of str){ const v = map.get(ch); if (v == null) return null; num = num * 58n + BigInt(v); }
    // count leading zeros
    let leading = 0; for (const c of str){ if (c === '1') leading++; else break; }
    // convert BigInt to bytes
    let bytes = [];
    while (num > 0n){ bytes.push(Number(num & 0xffn)); num >>= 8n; }
    bytes = bytes.reverse();
    if (leading){ bytes = new Array(leading).fill(0).concat(bytes); }
    return Buffer.from(bytes);
  }
  function validateRvnAddressVerbose(addr){
    try {
      if (typeof addr !== 'string') return { ok:false, reason:'not_string' };
      const s = addr.trim();
      if (!s) return { ok:false, reason:'empty' };
      if (!/^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/.test(s)) return { ok:false, reason:'invalid_chars' };
      if (s.length < 26 || s.length > 35) return { ok:false, reason:'length_out_of_range', length:s.length };
      const buf = base58Decode(s); if (!buf) return { ok:false, reason:'base58_decode_failed' };
      if (buf.length < 25) return { ok:false, reason:'decoded_too_short', len: buf.length };
      const payload = buf.slice(0, -4); const checksum = buf.slice(-4);
      const cs = require('crypto').createHash('sha256').update(require('crypto').createHash('sha256').update(payload).digest()).digest();
      const cs4 = cs.slice(0,4);
      if (!checksum.equals(cs4)) return { ok:false, reason:'checksum_mismatch', expected: cs4.toString('hex'), got: checksum.toString('hex') };
      const ver = payload[0];
      // Ravencoin mainnet P2PKH=0x3C ('R...'), P2SH=0x7A ('r...')
      if (ver === 0x3c || ver === 0x7a) return { ok:true, version: ver };
      return { ok:false, reason:'version_unsupported', version: ver };
    } catch (e) { return { ok:false, reason:'exception', error: String(e && e.message || e) }; }
  }
  function parseHostPort(h, p){ return { host: String(h||'').trim(), port: parseInt(p,10) || 0 }; }
  function buildRvnCandidates(){
    if (self.selectedCoin !== 'rvn') return [ parseHostPort(poolServer, poolPort) ];
    const cand = [];
    // Highest priority: explicit URL override
    try {
      const { host, port } = (function(){
        const u = process.env.RVN_POOL;
        if (!u) return {};
        const x = u.replace(/^stratum\+tcp:\/\//i,'').replace(/^stratum:\/\//i,'').replace(/^tcp:\/\//i,'');
        const m = x.match(/^([^:]+):(\d{2,5})$/); if (m) return { host: m[1], port: parseInt(m[2],10) };
        return {};
      })();
      if (host && port) cand.push({ host, port });
    } catch(_){ }
    // Next: explicit host/port overrides
    if (process.env.RVN_POOL_HOST){ cand.push(parseHostPort(process.env.RVN_POOL_HOST, process.env.RVN_POOL_PORT||poolPort)); }
    // Base from config
    cand.push(parseHostPort(poolServer, poolPort));
    // Regional variants if base is raven.f2pool.com
    try {
      const base = (poolServer||'').toLowerCase();
      if (/^raven\.f2pool\.com$/.test(base)){
        ['us.raven.f2pool.com','asia.raven.f2pool.com','eu.raven.f2pool.com'].forEach(h=> cand.push({ host:h, port: poolPort }));
      }
    } catch(_){ }
    // 2Miners fallback: enabled by default (opt-out with RVN_DISABLE_2MINERS_FALLBACK=1). Kept explicit opt-in for back-compat.
    if (process.env.RVN_ALLOW_2MINERS_FALLBACK === '1' || process.env.RVN_DISABLE_2MINERS_FALLBACK !== '1'){
      cand.push({ host:'rvn.2miners.com', port:6060 });
    }
    // Deduplicate in order
    const seen = new Set();
    return cand.filter(c=>{ const k = c.host+':'+c.port; if (seen.has(k)) return false; seen.add(k); return true; });
  }
  let rvnCandidates = buildRvnCandidates();
  let rvnTryIndex = 0;
  const refreshRvnCandidates = ()=>{ try { rvnCandidates = buildRvnCandidates(); rvnTryIndex = 0; } catch(_){} };

  const connectStratum = (host, port) => {
    // If falling back to 2Miners, username must be wallet.worker (not F2Pool account)
    let connectWorker = workerName;
    let connectPass = password;
    const is2Miners = /(^|\.)2miners\.com$/i.test(host) || /2miners/i.test(host);
    if (this.selectedCoin === 'rvn' && is2Miners){
      const rigSuffix = (user && user.split('.')[1]) || process.env.F2POOL_WORKER || process.env.WORKER_NAME || process.env.RIG_NAME || '001';
      const walletPart = (process.env.RVN_LOCAL_ADDRESS || process.env.RVN_MINING_ADDRESS || process.env.RVN_PAYOUT_ADDRESS || (user && user.split('.')[0]) || '').trim();
      // Preflight wallet validation
      const v = validateRvnAddressVerbose(walletPart);
      if (process.env.RVN_PREFLIGHT_BYPASS === '1'){
        console.warn('[Stratum][2Miners][Preflight] BYPASS active. Using wallet as-is:', walletPart);
      } else if (!walletPart || /REPLACE_WITH_YOUR_RVN_WALLET/i.test(walletPart) || !v.ok){
        console.error('[Stratum][2Miners][Preflight] Invalid or placeholder Ravencoin wallet address.');
        console.error('  chosen_wallet =', walletPart || '(empty)');
        if (!v.ok){
          console.error('  reason =', v.reason, (v.length!=null?(' length='+v.length):''), (v.version!=null?(' version=0x'+Number(v.version).toString(16)):'') );
          if (v.expected || v.got){ console.error('  checksum expected/got =', v.expected || '(n/a)', '/', v.got || '(n/a)'); }
        }
        console.error('  Set RVN_LOCAL_ADDRESS (or RVN_MINING_ADDRESS/RVN_PAYOUT_ADDRESS) to a valid mainnet RVN address (Base58Check, starts with R, ~34 chars).');
        console.error('  Example: $env:RVN_LOCAL_ADDRESS = "R...34chars..."');
        // Fail fast to prevent repeated authorize errors
        try { this.stratum?.close?.(); } catch(_e){}
        return;
      }
      connectWorker = `${walletPart}.${rigSuffix}`;
      connectPass = process.env.MINER_PASSWORD || process.env.STRATUM_PASSWORD || 'x';
      console.log(`[Stratum][2Miners] Using wallet.worker format for auth: ${connectWorker}`);
    }
    console.log(`[Stratum] Connecting to ${host}:${port} as ${connectWorker}`);
    try { if (this.stratum && this.stratum.close) this.stratum.close(); } catch(_){ }
  this.stratum = new RealStratumClient({ host, port, coin: this.selectedCoin.toUpperCase(), worker: connectWorker, password: connectPass });
    this.stratum.on('connected', ()=> console.log('[Stratum] Connected'));
    this.stratum.on('closed', ()=> console.log('[Stratum] Disconnected'));
    this.stratum.on('error', (e)=> {
      console.log('[Stratum] Error', e.message);
      const msg = String(e && e.message || '');
      if (/AUTHORIZE_FAILED/i.test(msg) && is2Miners){
        console.warn('[Stratum][Auth] Authorization failed on 2Miners. Ensure RVN_LOCAL_ADDRESS (or RVN_MINING_ADDRESS) is a valid Ravencoin address and worker suffix is set.');
      }
      if (/ENOTFOUND/i.test(msg) && this.selectedCoin === 'rvn'){
        // Try next candidate
        const next = rvnCandidates[++rvnTryIndex];
        if (next){
          console.warn(`[Stratum][RVN] DNS failed for ${host}. Trying fallback ${next.host}:${next.port} ...`);
          setTimeout(()=> connectStratum(next.host, next.port), 200);
          return;
        } else {
          console.warn('[Stratum][RVN] Exhausted RVN host fallbacks. You can set RVN_POOL or RVN_POOL_HOST to override.');
          // Optional interactive prompt to set a new pool URL (host:port) and/or wallet
          if (process.env.AUR_PROMPT_ON_POOL_FAILURE === '1' && process.stdin && process.stdin.isTTY){
            try {
              const rl = require('readline').createInterface({ input: process.stdin, output: process.stdout });
              const ask = q=> new Promise(r=> rl.question(q, ans=> r(ans)));
              (async ()=>{
                const newUrl = (await ask('Enter RVN pool as host:port (or press Enter to skip): ')).trim();
                let newWallet = (await ask('Enter RVN wallet (or press Enter to keep current): ')).trim();
                rl.close();
                if (newUrl){ process.env.RVN_POOL = /^stratum\+tcp:\/\//i.test(newUrl)? newUrl : `stratum+tcp://${newUrl}`; }
                if (newWallet){ process.env.RVN_LOCAL_ADDRESS = newWallet; }
                refreshRvnCandidates();
                const first = rvnCandidates[0];
                if (first){ console.warn(`[Stratum][RVN] Reconnecting to ${first.host}:${first.port} ...`); setTimeout(()=> connectStratum(first.host, first.port), 200); }
              })();
            } catch(_){ }
          }
        }
      }
      if (/ENOTFOUND/i.test(msg)){
        console.warn('[Stratum] DNS resolution failed. You can override the pool host via env e.g. RVN_POOL_HOST=raven.f2pool.com (port 3636) or use an alternative region.');
      }
    });
    this.stratum.on('subscribed', (s)=>{
      console.log('[Stratum][Subscribe]', s);
      this.extranonce1 = s.extranonce1 || '';
      this.extranonce2Size = s.extranonce2Size || 8;
    });
  this.stratum.on('authorized', ()=> console.log('[Stratum] Authorized worker ' + (this.stratum && this.stratum.worker ? this.stratum.worker : connectWorker)));
    this.stratum.on('job', (job)=>{
      this.job = {
        jobId: job.jobId,
        prevhash: job.prevhash,
        coinb1: job.part1,
        coinb2: job.part2,
        merkle_branch: job.merkleBranches,
        version: job.version,
        nbits: job.nbits,
        ntime: job.ntime
      };
      this.currentExtranonce2 = 0;
        console.log(`[Stratum] New job id=${job.jobId} ntime=${job.ntime} nbits=${job.nbits} prevhash=${job.prevhash?.slice(0,16)}...`);
        // Holodeck early lattice seed: ensure initial nodes so hashing loop can start producing hashes without fallback
        if (process.env.HOLODECK_ENABLE === '1') {
          const wantNodes = parseInt(process.env.HOLODECK_INIT_NODES || '8',10);
          if (!this.nodes || !Array.isArray(this.nodes)) this.nodes = [];
          if (this.nodes.length === 0 && wantNodes > 0){
            try {
              const cap = Math.min(wantNodes, 256); // guard upper bound
              for (let i=0;i<cap;i++){
                const nid = this.nodes.length;
                const harmIdx = nid % HARMONICS.length;
                this.nodes.push(new AurreliaNode(nid, this.mesh, this.picoCrystalTuner, false, harmIdx));
              }
              console.log(`[Holodeck] Seeded ${this.nodes.length} initial lattice nodes`);
            } catch(e){ console.warn('[Holodeck] Seed lattice failed', e.message); }
          }
        }
        if (this.selectedAlgo === 'kawpow'){
          // Light stub: derive pseudo mixHash from seed/height (replace with native result when hashing loop integrated)
          this.kawpowHeight = parseInt(job.height || job.blockheight || '0',10) || 0;
          this.kawpowSeed = job.seed || job.prevhash || '00'.repeat(32);
          const lightMix = crypto.createHash('sha256').update(this.kawpowSeed + ':' + this.kawpowHeight).digest('hex');
          if (this.romanWheels && this.romanWheels.length){ this.romanWheels.forEach(w=> w.kawpowMixHash = lightMix); }
        }
        if (!job.jobId) console.warn('[Stratum] Empty jobId received - pool anomaly?');
      try { this.poolPerf.updateJob(this.selectedCoin); } catch(_){ }
      // Optimized hypercube reseed with rankProxy perturbation & adaptive flip density
      try {
        if (process.env.HYPERCUBE_RESEED === '1' && global.__AUR_HYPERCUBE__){
          const seed = job.jobId || 'job';
          const heightSalt = (job.height || 0).toString();
          const dim = global.__AUR_HYPERCUBE__.dim;
          const count = global.__AUR_HYPERCUBE__.count;
          const phiScale = global.__AUR_HYPERCUBE__.phiScale;
          const crypto = require('crypto');
          let flipThresh = parseFloat(process.env.RANK_PROXY_FLIP_THRESH || '0.60');
          flipThresh = Math.max(0.50, Math.min(0.80, flipThresh));
          const PHI = (1+Math.sqrt(5))/2;
          const newVecs = []; let totalDensity=0; let totalFlips=0;
          for (let i=0;i<count;i++){
            const hStr = seed + ':' + i + ':' + heightSalt;
            const h = crypto.createHash('sha256').update(hStr).digest();
            const v = new Array(dim);
            let prevSign = 0; let flips=0;
            for (let d=0; d<dim; d++){
              const byteIdx = d % h.length;
              const byte = h[byteIdx];
              const bit = (byte >> (d % 8)) & 1;
              let val = bit ? 1 : -1;
              if (phiScale){ const exp = (d % 8)/8 - 0.5; val *= Math.pow(PHI, exp) * (dim>32? 0.8:1); }
              // Deterministic perturbation: fractional threshold from neighbor byte
              const fracByte = h[(byteIdx+1) % h.length];
              const frac = fracByte / 255;
              if (frac > flipThresh) val = -val;
              v[d] = val;
              const currSign = val >=0 ? 1 : -1;
              if (prevSign !== 0 && currSign !== prevSign) flips++;
              prevSign = currSign;
            }
            const density = flips / dim; totalDensity += density; totalFlips += flips; newVecs.push(v);
          }
          const avgRankProxy = totalDensity / (count||1);
          const flipPct = (totalFlips / (count*dim)) * 100;
          global.__AUR_HYPERCUBE__.vectors = newVecs;
          global.__AUR_HYPERCUBE__.seed = seed;
          global.__AUR_HYPERCUBE__.rankProxy = avgRankProxy;
          global.__AUR_HYPERCUBE__.flipPct = flipPct;
          // Adaptive threshold based on acceptance ratio (if available)
          if (global.__AUR_PIPELINE__ && global.__AUR_PIPELINE__.shareStats){
            const acc = global.__AUR_PIPELINE__.shareStats.acceptanceRatio || 0;
            let adapt = flipThresh;
            if (acc < 0.55) adapt += 0.02; else if (acc > 0.95) adapt -= 0.01;
            adapt = Math.max(0.50, Math.min(0.80, adapt));
            if (adapt !== flipThresh) process.env.RANK_PROXY_FLIP_THRESH = adapt.toFixed(2);
          }
          if (avgRankProxy < 1.0 && typeof sharedFreq === 'number'){ sharedFreq *= 0.95; }
          console.log(`[Hypercube][Reseed] jobId=${seed} dim=${dim} vectors=${count} rankProxy=${avgRankProxy.toFixed(3)} (target=1.1) flips=${flipPct.toFixed(1)}% thresh=${flipThresh.toFixed(2)}`);
        }
      } catch(e){ console.warn('[Hypercube][Reseed] error', e.message); }
      if (!this.started){ this.started = true; this.start(); }
      if (DRY_RUN) {
        try {
          const extranonce2Hex = '00'.padStart(this.extranonce2Size * 2, '0');
          const coinbaseTx = buildCoinbase(this.job.coinb1, this.extranonce1, extranonce2Hex, this.job.coinb2);
          const merkleRoot = buildMerkleRoot(coinbaseTx, this.job.merkle_branch || []);
          const headerHex = buildBlockHeader(this.job, merkleRoot, this.job.ntime, this.job.nbits, '00000000');
          let headerHash;
          if (this.selectedAlgo === 'sha256d') headerHash = doubleSha256(headerHex);
          else if (this.selectedAlgo === 'scrypt') headerHash = litecoinScryptHash(headerHex);
          else headerHash = doubleSha256(headerHex);
          console.log('[DRY_RUN]', JSON.stringify({ seed: GLOBAL_OCTO_SEED, burrowDepth: GLOBAL_BURROW_DEPTH, pruneThreshold: GLOBAL_PRUNE_THRESHOLD, configHash: CONFIG_HASH, coin: this.selectedCoin, algo: this.selectedAlgo, jobId: this.job.jobId, headerHex: headerHex.slice(0,160)+"...", headerHash }));
        } catch(e){ console.error('[DRY_RUN] error', e.message); }
        process.exit(0);
      }
    });
    this.stratum.on('shareAccepted', ()=>{
      this.stats.shares++;
      try { this.poolPerf.updateShare(this.selectedCoin, true); } catch(_){ }
      // Share efficiency accounting
      const nowTs = Date.now();
      this.shareStats.accepted++;
      if (this.shareStats.lastShareTs){
        const dtMin = (nowTs - this.shareStats.lastShareTs)/60000;
        if (dtMin > 0){
          const instSpm = 1/dtMin;
          if (this.shareStats.emaSharesPerMin == null) this.shareStats.emaSharesPerMin = instSpm; else this.shareStats.emaSharesPerMin = this.shareStats.emaSharesPerMin*(1-this.shareStats.emaAlpha) + instSpm*this.shareStats.emaAlpha;
          this.shareStats.sharesPerMin = instSpm;
        }
      }
      this.shareStats.lastShareTs = nowTs;
      this.shareStats.window.push({ t: nowTs, a:1, r:0 });
      // Prune window
      const cutoff = nowTs - this.shareStats.windowSpanMs;
      if (this.shareStats.window.length > 10000 || (this.shareStats.window[0] && this.shareStats.window[0].t < cutoff)){
        while (this.shareStats.window.length && this.shareStats.window[0].t < cutoff) this.shareStats.window.shift();
      }
      const accInWindow = this.shareStats.window.reduce((s,x)=> s + x.a,0);
      const rejInWindow = this.shareStats.window.reduce((s,x)=> s + x.r,0);
      const totalInWindow = accInWindow + rejInWindow;
      this.shareStats.acceptanceRatio = totalInWindow? accInWindow / totalInWindow : 0;
      let meta = null;
      if (this.pendingShares.size){
        const firstKey = this.pendingShares.keys().next().value;
        meta = this.pendingShares.get(firstKey);
        this.pendingShares.delete(firstKey);
      }
      if (meta && typeof meta.shareDiff === 'number') {
        console.log(`[Stratum] Share accepted diff≈${meta.shareDiff.toFixed(4)} hash=${meta.hash.slice(0,16)}…`);
        // Sliding window diff history for percentile aggregation
        if (!this._shareDiffWindow) this._shareDiffWindow = [];
        this._shareDiffWindow.push(meta.shareDiff);
        const maxWin = parseInt(process.env.DIFF_WINDOW_SIZE || '500',10);
        if (this._shareDiffWindow.length > maxWin) this._shareDiffWindow.splice(0, this._shareDiffWindow.length - maxWin);
      } else {
        console.log('[Stratum] Share accepted');
      }
      // Share-level ledger (deterministic append) if enabled
      try {
        if (!this.shareLogPath) {
          this.shareLogPath = process.env.SHARE_LOG_PATH || 'aurrelia-shares-ledger.jsonl';
        }
        const fs = require('fs');
        const rec = {
          t: Date.now(),
          jobId: this.job ? this.job.jobId : null,
          coin: this.selectedCoin,
          algo: this.selectedAlgo,
          diffApprox: meta && meta.shareDiff ? Number(meta.shareDiff.toFixed(6)) : null,
          hash: meta && meta.hash ? meta.hash : null,
          seed: GLOBAL_OCTO_SEED,
          burrowDepth: GLOBAL_BURROW_DEPTH,
          pruneThreshold: GLOBAL_PRUNE_THRESHOLD,
          configHash: CONFIG_HASH,
          spinPower: (process.env.SPIN_METRIC ? (function(){
            const acc = pipeline.shareStats ? pipeline.shareStats.acceptanceRatio : 0;
            const h = pipeline.stats && pipeline.stats.hashes ? pipeline.stats.hashes : 0;
            const alpha = parseFloat(process.env.SPIN_ALPHA || '0.15');
            return acc * alpha * (h/1000);
          })() : null),
          configHmac: CONFIG_HMAC,
          planeWeights: this.latestPlaneWeights,
          planeShareCounts: this.planeShareCounts,
          partition8: this.picoCrystalTuner ? !!this.picoCrystalTuner.partition8 : false
        };
        fs.appendFileSync(this.shareLogPath, JSON.stringify(rec)+'\n');
        // Mock job fallback if enabled and no real job after delay
        if (process.env.MOCK_JOB_DELAY){
          const delayMs = parseInt(process.env.MOCK_JOB_DELAY,10);
          if (!isNaN(delayMs)){
            setTimeout(()=>{
              if (!this.job || !this.job.jobId){
                console.warn('[MockJob] Injecting mock job after delay', delayMs);
                this.job = { jobId: 'mock1', prevhash: '00'.repeat(32), coinb1: '01', coinb2: '02', merkle_branch: [], version: '04000000', nbits: '1d00ffff', ntime: (Math.floor(Date.now()/1000)).toString(16) };
                if (!this.extranonce1) this.extranonce1 = '00';
                this.currentExtranonce2 = 0;
                if (!this.started){ this.started = true; this.start(); }
              }
            }, delayMs).unref();
          }
        }
        // Share ledger rotation / compaction
        try {
          const maxBytes = parseInt(process.env.SHARE_LEDGER_MAX_BYTES || '100000000',10); // 100MB
          const dsFactor = parseInt(process.env.SHARE_LEDGER_DOWNSAMPLE_FACTOR || '4',10);
          if (fs.existsSync(this.shareLogPath)) {
            const st = fs.statSync(this.shareLogPath);
            if (st.size > maxBytes) {
              const lines = fs.readFileSync(this.shareLogPath,'utf8').trim().split(/\n/).filter(Boolean);
              if (lines.length > 20000) {
                const head = lines.slice(0, Math.floor(lines.length/2)).filter((_,i)=> i % dsFactor === 0);
                const tail = lines.slice(Math.floor(lines.length/2));
                const merged = head.concat(tail);
                fs.writeFileSync(this.shareLogPath, merged.join('\n')+'\n');
                console.log('[ShareLedger] Compaction applied');
              }
            }
          }
        } catch(_){ }
      } catch(_){ }
    });
    this.stratum.on('shareRejected', (r)=> {
      console.log('[Stratum] Share rejected: ' + (r.error ? JSON.stringify(r.error) : 'unknown'));
      const nowTs = Date.now();
      this.shareStats.rejected++;
      this.shareStats.window.push({ t: nowTs, a:0, r:1 });
      const cutoff = nowTs - this.shareStats.windowSpanMs;
      if (this.shareStats.window.length > 10000 || (this.shareStats.window[0] && this.shareStats.window[0].t < cutoff)){
        while (this.shareStats.window.length && this.shareStats.window[0].t < cutoff) this.shareStats.window.shift();
      }
      const accInWindow = this.shareStats.window.reduce((s,x)=> s + x.a,0);
      const rejInWindow = this.shareStats.window.reduce((s,x)=> s + x.r,0);
      const totalInWindow = accInWindow + rejInWindow;
      this.shareStats.acceptanceRatio = totalInWindow? accInWindow / totalInWindow : 0;
    });
    // Kick async connect (non-blocking; pipeline will poll until job exists)
    this.stratum.connect().catch(e=> console.error('[Stratum] Connect failed', e.message));
    // Retry connection if no job within 60s
    setTimeout(()=>{ if (!this.job){ console.warn('[Stratum] No job after 60s, retrying subscription'); try { this.stratum?.close?.(); this.stratum?.connect?.().catch(err=> console.warn('[Stratum] Retry failed', err.message)); } catch(e){ console.warn('[Stratum] Retry failed', e.message); } } }, 60000).unref();
  };
  // Expose reconnect helpers on the pipeline instance for external control (HTTP/UI)
  this.connectStratum = connectStratum;
  this.refreshRvnCandidates = refreshRvnCandidates;
  this.reconnectWithCurrent = ()=>{
    try {
      if (this.selectedCoin === 'rvn'){
        refreshRvnCandidates();
        const first = rvnCandidates[0] || { host: poolServer, port: poolPort };
        return connectStratum(first.host, first.port);
      }
      return connectStratum(poolServer, poolPort);
    } catch(e){ console.warn('[Stratum][Reconnect] failed', e.message); }
  };
  // Begin initial connection using first candidate
  if (rvnCandidates.length){
    const first = rvnCandidates[0];
    connectStratum(first.host, first.port);
  } else {
    connectStratum(poolServer, poolPort);
  }
}
  start() {
    this.mine();
  }
  mine() {
    if (!this.job || !this.extranonce1) {
      if (process.env.MINE_SKIP_LOG === '1') console.log(`[Mine] Skipping - job=${!!this.job} extranonce1=${!!this.extranonce1}`);
      return setTimeout(() => this.mine(), 1000);
    }
    this.cycleCount++;
    // Extranonce2 generation: optionally override with guard rails module (EXTRANONCE2_GUARD=1)
    let extranonce2Hex;
    if (process.env.EXTRANONCE2_GUARD === '1'){
      try {
        if (!this._ex2Guard){ this._ex2Guard = require('./extranonce2-guard.js'); }
        extranonce2Hex = this._ex2Guard.nextExtranonce2(this.extranonce2Size);
      } catch(e){
        console.warn('[Ex2Guard] Fallback to counter:', e.message);
        extranonce2Hex = this.currentExtranonce2.toString(16).padStart(this.extranonce2Size * 2, '0');
      }
    } else {
      extranonce2Hex = this.currentExtranonce2.toString(16).padStart(this.extranonce2Size * 2, '0');
    }
    this.currentExtranonce2 = (this.currentExtranonce2 + 1) % (1 << (this.extranonce2Size * 8));
    if (this.currentExtranonce2 === 0){
      this.extranonce2Wraps++;
      if (this.extranonce2Wraps % 32 === 0){
        console.warn(`[Stratum] Extranonce2 wrapped ${this.extranonce2Wraps} times – monitor share freshness.`);
      }
    }

    const coinbaseTx = buildCoinbase(this.job.coinb1, this.extranonce1, extranonce2Hex, this.job.coinb2);
    // Deterministic Merkle root builder (single coinbase + ordered branches)
    function buildMerkleRoot(coinbaseHex, branches){
      try {
        const dbl = h=> crypto.createHash('sha256').update(Buffer.from(h,'hex')).digest('hex');
        let root = dbl(dbl(coinbaseHex));
        for (const b of branches){
          // Branch may already be hex; combine in little-endian order per Bitcoin style
          const combined = Buffer.from(root,'hex').reverse().toString('hex') + Buffer.from(b,'hex').reverse().toString('hex');
          root = dbl(dbl(combined));
        }
        return root;
      } catch(e){ console.warn('[MerkleRoot] fallback', e.message); return crypto.createHash('sha256').update(coinbaseHex).digest('hex'); }
    }
    const merkleRoot = buildMerkleRoot(coinbaseTx, this.job.merkle_branch || []);
    let nTimeHex = this.job.ntime;
    nTimeHex = (parseInt(nTimeHex, 16) + this.currentExtranonce2).toString(16).padStart(8, '0');

    // Lazy init multi-plane RomanDecoderWheel set (deterministic, no randomness)
    if (this.romanWheels.length === 0) {
      const seedHex = crypto.createHash('sha256').update(this.extranonce1 + this.job.jobId).digest('hex');
      const segs = [0, 8, 16, 24].map(o => parseInt(seedHex.slice(o, o + 8), 16));
      const mkWheel = (plane, idx) => {
        const hue = 560 + (segs[idx] % 120); // bounded hue shift
        const freqDelta = (segs[idx] % 33) - 16; // [-16..16]
        return new RomanDecoderWheel(plane, 432 + freqDelta, hue);
      };
      this.romanWheels = [
        mkWheel('xy', 0),
        mkWheel('xz', 1),
        mkWheel('yz', 2),
        mkWheel('w4d', 3)
      ];
    }

    let planeSeeds, romanSeed;
    const planeDebugInterval = parseInt(process.env.ROMAN_DEBUG_INTERVAL || '500', 10);
    if (this.cycleCount % 10 !== 0 && this.cachedPlaneSeeds) {
      planeSeeds = this.cachedPlaneSeeds;
      romanSeed = this.cachedXorSeed;
    } else {
  const planeInput = (coinbaseTx.slice(0, 256) + (this.extranonce2Hex||'') + (this.job ? this.job.ntime : '')).slice(0,512);
      const decodedPlanes = this.romanWheels.map(w => w.decodeData(planeInput));
      planeSeeds = decodedPlanes.map(p => (p && p.length ? p : planeInput).slice(0,64).padEnd(64,'0'));
      let planeWeights = null;
      if (PLANE_AGG_MODE === 'avg' && PLANE_WEIGHTED && planeSeeds.length){
        // deterministic weight vector
        const lengths = decodedPlanes.map(p=> (p && p.length ? p.length: planeInput.length));
        const maxLen = Math.max(...lengths);
        planeWeights = planeSeeds.map((s,idx)=>{
          const uniq = new Set(s.split('')).size; // 1..16
            const w = (uniq/16) * (lengths[idx]/(maxLen||1));
            return w || 0.0001;
        });
        const wSum = planeWeights.reduce((a,b)=>a+b,0);
        if (wSum>0) for (let i=0;i<planeWeights.length;i++) planeWeights[i] /= wSum;
        // Reinforcement from accepted share distribution
        if (this.totalPlaneShares > 0){
          const reinforced = planeWeights.map((w,i)=> w * (1 + this.reinforceAlpha * (this.planeShareCounts[i] / this.totalPlaneShares)));
          const rSum = reinforced.reduce((a,b)=>a+b,0) || 1;
          for (let i=0;i<reinforced.length;i++) reinforced[i] /= rSum;
          planeWeights = reinforced;
        }
      }
      this.latestPlaneWeights = planeWeights;
      const aggregateSeed = (() => {
        if (!planeSeeds.length) return planeInput.slice(0,64);
        const nibbleArrays = planeSeeds.map(s => s.split(''));
        const out = [];
        for (let i=0;i<64;i++){
          if (PLANE_AGG_MODE === 'avg') {
            if (planeWeights){
              let accum = 0; for (let p=0;p<nibbleArrays.length;p++){ accum += planeWeights[p]* parseInt(nibbleArrays[p][i],16); }
              const val = Math.floor(accum) & 0xF; out.push(val.toString(16));
            } else {
              let sum = 0; for (const arr of nibbleArrays) sum += parseInt(arr[i],16);
              const avg = Math.floor(sum / nibbleArrays.length) & 0xF; out.push(avg.toString(16));
            }
          } else { // xor (default/backward)
            let acc = 0; for (const arr of nibbleArrays) acc ^= parseInt(arr[i],16);
            out.push(acc.toString(16));
          }
        }
        return out.join('');
      })();
      // Dynamic plane/harmonic re-weighting: if symbolic VM enabled, modulate plane weights by partition ratios
      if (this.symbolicVmEnabled && this.partitionStats && this.partitionStats.attempts){
        const ratios = {}; for (const k of Object.keys(this.partitionStats.attempts)){ const a=this.partitionStats.attempts[k]||0; const b=this.partitionStats.accepts[k]||0; ratios[k]= a? (b/a):0; }
        const ratioVals = Object.values(ratios);
        const avgRatio = ratioVals.length? ratioVals.reduce((a,b)=>a+b,0)/ratioVals.length : 0;
        if (planeWeights && avgRatio > 0){
          // Map partitions h0..h3 onto planes 0..3; scale weights by (ratio / avgRatio)
          for (let i=0;i<planeWeights.length && i<4;i++){
            const tag = 'h'+i; const r = ratios[tag] || 0;
            planeWeights[i] *= (avgRatio>0 ? (0.5 + 0.5 * (r/avgRatio)) : 1);
          }
          const newSum = planeWeights.reduce((a,b)=>a+b,0)||1; for (let i=0;i<planeWeights.length;i++) planeWeights[i]/=newSum;
          this.latestPlaneWeights = planeWeights;
        }
        // Harmonic re-weighting: choose next rotation bias toward best partition ratio
        const bestTag = Object.entries(ratios).sort((a,b)=> b[1]-a[1])[0];
        if (bestTag && bestTag[1] > 0 && MULTI_HARMONIC){
          // Map tag hN to harmonic index N
            const idx = parseInt(bestTag[0].slice(1),10)%HARMONICS.length;
            // Slightly bias global frequency by averaging with favored harmonic
            if (lattice.length){
              for (const n of lattice.slice(-50)){
                n.freq = (n.freq*0.9) + (HARMONICS[idx]*0.1);
                n.engine.thetaBase = (2*Math.PI)/n.freq;
              }
            }
        }
      }
      romanSeed = aggregateSeed;
      this.cachedPlaneSeeds = planeSeeds;
      this.cachedXorSeed = romanSeed;
      this.cachedRomanCycle = this.cycleCount;
      if (this.cycleCount % planeDebugInterval === 0) {
        console.log(`[RomanSeeds] cycle=${this.cycleCount} planes=${planeSeeds.map(s=>s.slice(0,8)).join(',')} xor=${romanSeed.slice(0,8)}`);
      }
    }
    this.lastRomanSeed = romanSeed;
    // Node growth gating: only grow lattice if projected hash throughput increases beyond threshold
  // Node growth gating (adjust default eval delay to 40 cycles for more stable baseline comparison)
  if (!global.__AUR_NODE_GROWTH__){ global.__AUR_NODE_GROWTH__ = { attempts:0, kept:0, reverted:0, pending:[], evalDelayCycles: parseInt(process.env.NODE_GROWTH_EVAL_DELAY || '40',10), improvementThreshold: parseFloat(process.env.NODE_GROWTH_THRESHOLD || '0.015'), revertFloor: parseFloat(process.env.NODE_GROWTH_REVERT_FLOOR || '0.005'), pendingMax: parseInt(process.env.NODE_GROWTH_PENDING_MAX || '16',10) }; }
    const NG = global.__AUR_NODE_GROWTH__;

    // Event-driven node: Only on success or burrow resonance (not every attempt)
  const seedOct = romanSeed.slice(0, 64).split('').reduce((acc, c, i) => { acc[i % 8] += c.charCodeAt(0); return acc; }, Array(8).fill(0));
  if (nodeCount < MAX_NODES && NG.pending.length < NG.pendingMax) {
      // Capture baseline hashes for evaluation
      const baselineHashes = this.stats.hashes;
      const baselineTime = Date.now();
      const newNode = new NeuralNode();
      newNode.learn({ e: seedOct });
      quantumTuner.addFrequency(newNode.getColorFrequency());
      manifold.push(newNode);
      if (nodeCount < GLOBAL_NODE_CAP_BY_GB){
        lattice.push(new AurreliaNode(nodeCount, mesh, this.picoCrystalTuner, this.crystalBias, nodeCount % HARMONICS.length));
        // Register pending evaluation
        NG.pending.push({ idx: nodeCount, baselineHashes, baselineTime });
        NG.attempts++;
      }
      nodeCount++;
    }
    // Evaluate pending node growths
    if (NG.pending.length){
      const still = [];
      for (const p of NG.pending){
        if (this.cycleCount - (this.cachedRomanCycle||0) < NG.evalDelayCycles){ still.push(p); continue; }
        const elapsedMs = Date.now() - p.baselineTime;
        if (elapsedMs < 1000){ still.push(p); continue; } // ensure at least 1s
        const deltaHashes = this.stats.hashes - p.baselineHashes;
        const rate = deltaHashes / (elapsedMs/1000);
        const baseRate = p.baselineHashes / Math.max(1,(p.baselineTime - (p.baselineTime-1000))/1000); // rough (avoid division by zero)
        const improvement = baseRate>0 ? (rate - baseRate)/baseRate : (rate>0?1:0);
        if (improvement >= NG.improvementThreshold){ NG.kept++; }
        else if (improvement < NG.revertFloor) {
          // Revert: remove most recently added lattice node if exists
          const removed = lattice.pop();
          if (removed){ NG.reverted++; nodeCount = Math.max(0,nodeCount-1); }
        }
      }
      NG.pending = still;
    }
    bytesProcessed += Buffer.byteLength(coinbaseTx, 'hex') + Buffer.byteLength(merkleRoot, 'hex');

    // Batching: Only burrow every 10 cycles, else just process coinbase/merkle bytes
    // Adjustable hashing cycle modulus: default 10 normally, but under holodeck (or HASH_CYCLE_MOD env) we can lower to exercise hashing faster.
    const cycleModEnv = process.env.HASH_CYCLE_MOD || (process.env.HOLODECK_ENABLE === '1' ? '1' : '10');
    let cycleMod = parseInt(cycleModEnv, 10); if (!isFinite(cycleMod) || cycleMod <= 0) cycleMod = 10;
    if (this.cycleCount % cycleMod !== 0) {
      // Skipping heavy hashing phase this cycle (mod gating). Adjust HASH_CYCLE_MOD to control frequency.
    } else {
      // Prune high-norm nodes, keep lattice <1K recent, only norm<=2
      while (lattice.length > 1000) lattice.shift();
      // Prefetch + cached active lattice slice (reduces O(nodes) scanning cost). Refresh every 8 cycles.
      if (!this._cachedActive || (this.cycleCount - (this._cachedActive.cycle||0) >= 8)){
        const arr = [];
        // Sample only tail portion; compute norms once.
        const tail = lattice.slice(-400);
        for (const n of tail){
          const nm = n.octo.norm();
          if (nm <= 2) arr.push(n);
          if (arr.length >= 120) break;
        }
        this._cachedActive = { cycle: this.cycleCount, nodes: arr.slice(-100) };
      }
      const activeLattice = this._cachedActive.nodes;
      let hashes = 0;
      // Holodeck fallback: if no active lattice nodes yet (early cycles), emit a minimal deterministic hashing pass
      if (process.env.HOLODECK_ENABLE === '1' && activeLattice.length === 0) {
        try {
          const fallbackAttempts = parseInt(process.env.HOLODECK_FALLBACK_HASHES || '64',10);
          if (fallbackAttempts > 0) {
          for (let i=0;i<fallbackAttempts;i++){
            // Deterministic nonce derived from jobId + cycle + i
            const nonceSeed = this.job.jobId + ':' + this.cycleCount + ':' + i;
            const nonceHex = crypto.createHash('sha256').update(nonceSeed).digest('hex').slice(0,8);
            // Simplified header mix (romanSeed + nonce)
            const headerHex = (romanSeed + nonceHex).slice(0,160).padEnd(160,'0');
            // Choose algo path deterministically; we only need to exercise counter, not real target check
            let h;
            if (this.selectedAlgo === 'sha256d') h = doubleSha256(headerHex);
            else if (this.selectedAlgo === 'scrypt' && typeof litecoinScryptHash === 'function') h = litecoinScryptHash(headerHex);
            else h = crypto.createHash('sha256').update(headerHex).digest('hex');
            hashes++;
            if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
            const _fbBytes = Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(h,'hex');
            bytesProcessed += _fbBytes; if (typeof global.__HOLO_BYTES_PROCESSED__ === 'number') global.__HOLO_BYTES_PROCESSED__ += _fbBytes;
            // Occasionally log one sample for trace
            if (i===0 && process.env.HOLODECK_FALLBACK_TRACE==='1') console.log('[HolodeckFallbackHash] headerSample', headerHex.slice(0,64),'hash', h.slice(0,32));
          }
          } // fallbackAttempts>0
        } catch(e){ if (process.env.HOLODECK_FALLBACK_TRACE==='1') console.warn('[HolodeckFallbackHash] error', e.message); }
      }
  // Batch hashing buffers (accumulate candidate headers then hash in one call when fused available)
  const batchHeaders = [];
  const batchMeta = []; // {nonceHex, target, planeIndex, node, gen, headerHex}
  let interferenceAccum = 0;
  let interferenceSamples = 0;
      let gainAccum = 0; let gainSamples = 0;
  const self = this; // capture context for flushBatch

      // Attempt fused auto-recovery if disabled & cooldown elapsed
      if (fusedHash && !global.__AUR_WASM_METRICS__.fusedAvailable && (Date.now() - this.fusedLastDisableTime > this.fusedRecoverCooldownMs) && !this._fusedRecovering){
        this._fusedRecovering = true;
        this.fusedRecoverAttempts++;
        if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedRecoverAttempts = this.fusedRecoverAttempts;
        fusedHash.selfTest(this.fusedRecoverCases).then(res=>{
          if (res.ok){
            this.fusedConsecRecoverPasses++;
            if (this.fusedConsecRecoverPasses >= this.fusedRecoverThreshold){
              global.__AUR_WASM_METRICS__.fusedAvailable = true;
              this.fusedConsecRecoverPasses = 0;
              console.log('[Miner] Fused path auto-recovered after self-tests');
              this.fusedRecoverSuccesses++;
              this.fusedLastRecoverTs = Date.now();
              if (global.__AUR_WASM_METRICS__){
                global.__AUR_WASM_METRICS__.fusedRecoverSuccesses = this.fusedRecoverSuccesses;
                global.__AUR_WASM_METRICS__.fusedLastRecoverTs = this.fusedLastRecoverTs;
              }
              // Gentle ramp: start from minimum batch size toward previous size
              this.fusedRampActive = true;
              this.fusedRampTarget = this.currentBatchSize;
              this._fusedRampBatchCounter = 0;
              this.currentBatchSize = this.batchMin;
              if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.currentBatchSize = this.currentBatchSize;
            }
          } else {
            this.fusedConsecRecoverPasses = 0;
            this.fusedLastDisableTime = Date.now();
            this.fusedRecoverFailures++;
            if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedRecoverFailures = this.fusedRecoverFailures;
          }
        }).catch(()=>{ this.fusedLastDisableTime = Date.now(); this.fusedConsecRecoverPasses = 0; this.fusedRecoverFailures++; if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedRecoverFailures = this.fusedRecoverFailures; }).finally(()=>{ delete this._fusedRecovering; });
      }
      for (let node of activeLattice) {
    // Plane-specific seed selection for node to diversify resonance (still deterministic) + extra per-cycle entropy
    // Add coinbase + merkle mix to break uniform seed vortex observed in flat jobs
    const coinbaseSlice = (coinbaseTx || '').slice((node.id*8)%128, ((node.id*8)%128)+32);
    const merkleMix = (merkleRoot || '').slice(0,16);
    const planeSeedBase = planeSeeds.length ? planeSeeds[node.id % planeSeeds.length] : romanSeed;
    const planeSeed = crypto.createHash('sha256').update(planeSeedBase + coinbaseSlice + extranonce2Hex + merkleMix).digest('hex');
    // Composite includes jobId, extranonce2, diversified planeSeed and aggregated romanSeed for cross-plane coupling
  const compositeSeed = this.job.jobId + extranonce2Hex + planeSeed + romanSeed + coinbaseSlice + merkleMix;
  const auditBind = this.picoCrystalTuner.latestAuditHash || 'na';
  const cidBind = this.picoCrystalTuner.lastCid || 'nocid';
  const bindHash = crypto.createHash('sha256').update(auditBind + cidBind).digest('hex').slice(0,16);
  const compositeSeedBound = compositeSeed + bindHash;
        const gen = node.generateNonce(compositeSeedBound, nTimeHex, planeSeeds); // interference-aware
    if (gen.interference){ interferenceAccum += gen.interference; interferenceSamples++; }
        // Use adaptive or configured generation norm threshold (default 2.5) before expensive verify
        const genNormMax = this.dynamicPruneThreshold ? (this.dynamicPruneThreshold * 0.9) : parseFloat(process.env.AUR_GEN_NORM_MAX || '2.5');
        if (gen.norm > genNormMax) {
          if (process.env.AUR_GEN_NORM_DEBUG==='1' && (hashes % 500===0)) console.log('[GenFilter] skip norm', gen.norm.toFixed(3),'>', genNormMax.toFixed(3));
          continue;
        }
        // Adaptive prune sampling: record norm values under a ceiling (avoid outliers)
        if (pipeline && pipeline.adaptivePruneEnabled && gen.norm && isFinite(gen.norm)){
          if (!pipeline._normSamples) pipeline._normSamples = [];
            if (gen.norm < 10){
              pipeline._normSamples.push(gen.norm);
              if (pipeline._normSamples.length > pipeline.normSampleCap) pipeline._normSamples.splice(0, pipeline._normSamples.length - pipeline.normSampleCap);
            }
        }
        // Symbolic VM partition filter (single-worker mode)
        let symbolicOk = true;
        if (this.symbolicVmEnabled){
          const seed = compositeSeedBound;
          const harmonicIndex = (parseInt(seed[0],16)%4);
          const tag = 'h'+harmonicIndex;
          this.partitionStats.attempts[tag]++;
          if (this.planeReinforce) this.planeReinforce.attempts[harmonicIndex]++;
          let ops = this.vmProgramsByHarmonic.get(tag);
            if (!ops){
              ops = this.compileVmProgram(tag, seed);
              this.vmProgramsByHarmonic.set(tag, ops);
            }
            const baseHash = crypto.createHash('sha256').update(seed + gen.nonce.toString(16)).digest('hex');
            let h = parseInt(baseHash.slice(0,8),16) >>> 0;
            for (const op of ops){
              const opcode = op.opcode; const c = op.c;
              switch(opcode){
                case 0: { const r=c&31; h=((h<<r)|(h>>> (32-r)))>>>0; break; }
                case 1: { h=(h ^ ((c*0x9e37)>>>0))>>>0; break; }
                case 2: { h=(h + c*65793)>>>0; break; }
                case 3: { h=(h - (c*1315423911))>>>0; break; }
                case 4: { h ^= h>>>13; h=(h*0x85ebca6b)>>>0; h^=h>>>16; break; }
                case 5: { const hh=crypto.createHash('sha256').update(baseHash + c.toString(16)).digest('hex'); h=parseInt(hh.slice(0,8),16)>>>0; break; }
                case 6: { h=((h & 0xffff) ^ (h>>>16))>>>0; break; }
                case 7: { const leading=(c%5)+3; const mask=(1<<leading)-1; symbolicOk = (h & mask)===0; break; }
              }
              if (opcode===7) break;
            }
            if (symbolicOk){
              this.partitionStats.accepts[tag]++;
              if (this.planeReinforce) this.planeReinforce.accepts[harmonicIndex]++;
            }
        }
        if (!symbolicOk) continue;
        // Track generation attempt for adaptive prune learner
        if (this.pruneLearn.enabled){
          this.pruneLearn.attempts++;
          this.pruneLearn.recent.push({ norm: gen.norm, ok: false });
          if (this.pruneLearn.recent.length > this.pruneLearn.window) this.pruneLearn.recent.shift();
        }
        const ver = node.verifyNonce(gen.nonce.toString(16), compositeSeedBound, nTimeHex);
        if (pipeline.burrowAdapt && pipeline.burrowAdapt.enabled){
          pipeline.burrowAdapt.verifies++;
            if (!ver.valid && ver.iter != null && ver.iter < 2) pipeline.burrowAdapt.earlyPrunes++;
            if (pipeline.burrowAdapt.verifies % pipeline.burrowAdapt.window === 0){
              const ratio = pipeline.burrowAdapt.earlyPrunes / pipeline.burrowAdapt.window;
              if (ratio > pipeline.burrowAdapt.hiRatio && pipeline.burrowAdapt.current > pipeline.burrowAdapt.min){
                pipeline.burrowAdapt.current--;
              } else if (ratio < pipeline.burrowAdapt.loRatio && pipeline.burrowAdapt.current < pipeline.burrowAdapt.base){
                pipeline.burrowAdapt.current++;
              }
              if (process.env.DEBUG_BURROW === '1') console.log(`[BurrowAdapt] windowEarlyRatio=${ratio.toFixed(3)} depth->${pipeline.burrowAdapt.current}`);
              if (pipeline.burrowAdapt.current !== GLOBAL_BURROW_DEPTH){
                for (const n of this.nodes) n.engine.burrowDepth = pipeline.burrowAdapt.current;
              }
              pipeline.burrowAdapt.earlyPrunes = 0;
            }
        }
        if (process.env.AUR_NORM_TRACE==='1' && (hashes % 400===0)) {
          console.log('[NormTrace] gen', gen.norm && gen.norm.toFixed ? gen.norm.toFixed(3):gen.norm,'verOk', ver.valid, 'thr', genNormMax.toFixed(3));
        }
        if (!ver.valid) continue;
        if (this.pruneLearn.enabled){
          this.pruneLearn.accepted++;
          const last = this.pruneLearn.recent[this.pruneLearn.recent.length-1];
          if (last) last.ok = true;
        }
        if (process.env.NODE_GROWTH === '1' && hashes % 4096 === 0 && this.shareStats){
          const acc = this.shareStats.acceptanceRatio;
          const capacityUtil = this.nodes.length / (GEOM_CAPACITY || 1);
          const accHigh = parseFloat(process.env.NODE_GROWTH_ACC_HIGH || '0.95');
          const accLow = parseFloat(process.env.NODE_GROWTH_ACC_LOW || '0.50');
          const capThresh = parseFloat(process.env.NODE_GROWTH_CAP_THRESH || '0.80');
          const maxN = parseInt(process.env.NODE_GROWTH_MAX || '65536',10);
          const spawnBatch = parseInt(process.env.NODE_GROWTH_BATCH || '8',10);
          const minKeep = parseInt(process.env.NODE_GROWTH_MIN || '4',10);
          if (acc != null){
            // Cross-fire lock evolution
            if (this.nodes.length){
              const cfProb = parseFloat(process.env.CROSS_FIRE_PROB || '0.3');
              const cfLock = parseInt(process.env.CROSS_FIRE_LOCK_THRESHOLD || '3',10);
              for (const n of this.nodes){
                const mix = ((hashes + (n.id*2654435761))>>>0) & 0xffff;
                if ((mix/0xffff) < cfProb){ n.crossFireCount = (n.crossFireCount||0)+1; }
                if (n.crossFireCount && n.crossFireCount > cfLock){ n.locked = true; }
              }
            }
            // Prune locked if poor acceptance
            if (acc < accLow && this.nodes.length > minKeep){
              const before = this.nodes.length;
              this.nodes = this.nodes.filter(n=> !n.locked);
              if (this.nodes.length < before && process.env.DEBUG_GROWTH==='1') console.log('[Growth] Pruned locked', before - this.nodes.length);
            }
            // Spawn burst under high efficiency & below soft capacity threshold
            if (acc > accHigh && capacityUtil < capThresh && this.nodes.length < maxN){
              let toAdd = Math.min(spawnBatch, maxN - this.nodes.length);
              const softCap = Math.floor(GEOM_CAPACITY * capThresh);
              if (this.nodes.length + toAdd > softCap) toAdd = Math.max(0, softCap - this.nodes.length);
              for (let k=0;k<toAdd;k++){
                if (this.nodes.length >= GLOBAL_NODE_CAP_BY_GB) break;
                const nid = this.nodes.length;
                const harmIdx = nid % HARMONICS.length;
                const newNode = new AurreliaNode(nid, this.mesh, this.picoCrystalTuner, false, harmIdx);
                if (process.env.DEBUG_GROWTH==='1') console.log('[Growth] Spawn node', nid, 'acc', acc.toFixed(3), 'util', capacityUtil.toFixed(3));
                this.nodes.push(newNode);
              }
              if (this.nodes.length >= GLOBAL_NODE_CAP_BY_GB && !this._loggedNodeCap){ console.warn('[Growth] Node cap reached (GB limit) – further spawns suppressed'); this._loggedNodeCap = 1; }
            }
          }
        }
        // Periodic geometry utilization sampling (independent of NODE_GROWTH env)
        if (hashes % 2048 === 0){
          const util = this.nodes.length / (GEOM_CAPACITY || 1);
          this.lastGeomUtil = util;
          if (this.appendGeomSample) this.appendGeomSample(this.nodes.length, util);
        }
        // Recording rule evaluation (auto scaling decisions) every 4096 hashes
        if (hashes % 4096 === 0 && this.recordingRules){
          try {
            const acc = this.shareStats && this.shareStats.acceptanceRatio != null ? this.shareStats.acceptanceRatio : 0;
            const util = this.lastGeomUtil || (this.nodes.length / (GEOM_CAPACITY || 1));
            const st = { acc, util };
            for (const rule of this.recordingRules){
              if (rule.query && rule.query(st)){
                this.ruleStats.hits[rule.name] = (this.ruleStats.hits[rule.name]||0)+1;
                this.lastTriggeredRule = { name: rule.name, ts: Date.now(), acc: acc, util: util };
                if (rule.action === 'prune_8x'){
                  const pruneN = Math.min(8, Math.max(0, this.nodes.length - 1));
                  if (pruneN > 0) this.nodes.splice(-pruneN, pruneN);
                  this.ruleStats.actions.prune_8x++;
                  if (global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges && global.__AUR_METRICS_REG__.gauges.rulePrune){
                    try { global.__AUR_METRICS_REG__.gauges.rulePrune.inc(); } catch(_){ }
                  }
                } else if (rule.action === 'spawn_8x'){
                  const maxSpawn = Math.min(8, (GEOM_CAPACITY|| (this.nodes.length+8)) - this.nodes.length);
                  for (let i=0;i<maxSpawn;i++){
                    if (this.nodes.length >= GLOBAL_NODE_CAP_BY_GB) break;
                    const nid = this.nodes.length;
                    const harmIdx = nid % HARMONICS.length;
                    this.nodes.push(new AurreliaNode(nid, this.mesh, this.picoCrystalTuner, false, harmIdx));
                  }
                  if (maxSpawn>0) this.ruleStats.actions.spawn_8x++;
                  if (maxSpawn>0 && global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges && global.__AUR_METRICS_REG__.gauges.ruleSpawn){
                    try { global.__AUR_METRICS_REG__.gauges.ruleSpawn.inc(); } catch(_){ }
                  }
                }
                break; // one rule per interval
              }
            }
          } catch(e){ /* swallow */ }
        }
  hashes++;
  if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
        // Hypercube subset rotation (temporal variance) if configured
        if (this.hypercube && this.hypercube.rotateEvery > 0 && global.__AUR_HYPERCUBE__ && global.__AUR_HYPERCUBE__.vectors){
          if (hashes - this.hypercube.lastRotHash >= this.hypercube.rotateEvery){
            this.hypercube.lastRotHash = hashes;
            const vecCount = global.__AUR_HYPERCUBE__.vectors.length;
            let sliceSize = this.hypercube.sliceSize;
            if (!sliceSize || sliceSize <= 0){
              sliceSize = Math.max(8, Math.floor(vecCount * 0.02));
              this.hypercube.sliceSize = sliceSize;
            }
            const sliceCount = Math.max(1, Math.floor(vecCount / sliceSize));
            this.hypercube.subsetIdx = (this.hypercube.subsetIdx + 1) % sliceCount;
            const start = this.hypercube.subsetIdx * sliceSize;
            const end = Math.min(vecCount, start + sliceSize);
            this.hypercube.activeSlice = { start, end, size: end - start };
            // Rebind node hyperVec within slice
            try {
              const span = end - start;
              for (const n of this.nodes){
                const idx = start + (n.id % span);
                const hv = global.__AUR_HYPERCUBE__.vectors[idx];
                if (hv){ n.hyperVec = { x: hv[0], y: hv[1], n: hv.reduce((a,b)=>a+Math.abs(b),0)/hv.length }; }
              }
            } catch(_){ }
            // Persist chern proxy topology sample
            try {
              const vecs = global.__AUR_HYPERCUBE__.vectors.slice(start, end);
              let changes=0,total=0; for (let i=1;i<vecs.length;i++){ const a=vecs[i-1], b=vecs[i]; const m=Math.min(8,a.length,b.length); for (let k=0;k<m;k++){ if (Math.sign(a[k])!==Math.sign(b[k])) changes++; total++; } }
              const density = total>0? changes/total : 0;
              if (!this.chernRing){ this.chernRing = { buffer:[], max: parseInt(process.env.CHERN_RING_MAX||'512',10), path: process.env.CHERN_RING_PATH||'chern-ring.jsonl', rotateMb: parseFloat(process.env.CHERN_RING_ROTATE_MB||'2') }; }
              const rec = { t: Date.now(), subsetIdx: this.hypercube.subsetIdx, density };
              this.chernRing.buffer.push(rec); if (this.chernRing.buffer.length > this.chernRing.max) this.chernRing.buffer.shift();
              const fs = require('fs');
              let rotate=false; if (fs.existsSync(this.chernRing.path)){ const sz=fs.statSync(this.chernRing.path).size; if (sz > this.chernRing.rotateMb*1024*1024) rotate=true; }
              if (rotate){ const tail=this.chernRing.buffer.slice(-Math.floor(this.chernRing.max/2)); fs.writeFileSync(this.chernRing.path, tail.map(r=>JSON.stringify(r)).join('\n')+'\n'); }
              else { fs.appendFileSync(this.chernRing.path, JSON.stringify(rec)+'\n'); }
            } catch(_){ }
          }
        }
        const nonceHex = gen.nonce.toString(16).padStart(8, '0');
        const headerHex = buildBlockHeader(this.job, merkleRoot, nTimeHex, this.job.nbits, nonceHex);
        // Lazy init(s)
        if (fusedHash && !global.__AUR_WASM_METRICS__.fusedTried){
          fusedHash.initFused().then(()=>{ global.__AUR_WASM_METRICS__.fusedAvailable = true; }).catch(()=>{ global.__AUR_WASM_METRICS__.fusedAvailable = false; });
          global.__AUR_WASM_METRICS__.fusedTried = true;
        }
        if (!global.__AUR_WASM_METRICS__.fusedAvailable && wasmHash && !global.__AUR_WASM_METRICS__.triedInit){
          wasmHash.initWasm().then(()=>{ global.__AUR_WASM_METRICS__.available = true; }).catch(()=>{ global.__AUR_WASM_METRICS__.available = false; });
          global.__AUR_WASM_METRICS__.triedInit = true;
        }
        const planeIndex = planeSeeds.length ? (node.id % planeSeeds.length) : null;
  const target = this.computeCoinTarget(this.job.nbits, this.selectedCoin);
        const headerBuf = Buffer.from(headerHex, 'hex');
        // If fused batch available, accumulate; else hash immediately via midstate or JS
  if (self.selectedAlgo === 'sha256d' && fusedHash && global.__AUR_WASM_METRICS__.fusedAvailable){
          batchHeaders.push(headerBuf);
            batchMeta.push({ nonceHex, planeIndex, node, target, headerHex });
          let limit;
          if (self.useGpuBatch && GPU_ENABLED){
            limit = self.gpuBatchSize;
          } else {
            limit = self.adaptiveBatchEnabled ? self.currentBatchSize : parseInt(process.env.BATCH_SIZE || '128',10);
          }
          if (batchHeaders.length >= limit) {
            flushBatch();
          }
        } else {
          if (self.selectedAlgo === 'fren') {
            // FREN placeholder hashing uses frenMixHash (double sha256 variant)
            const finalHex = self.frenMixHash(headerHex);
            const hashInt = BigInt('0x' + reverseBytes(finalHex));
            bytesProcessed += Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(finalHex,'hex');
            node.feedback(hashInt <= target, this.currentExtranonce2, finalHex, planeIndex);
            if (hashInt <= target){
              let shareDiff = 0; try { shareDiff = Number(this.diff1Target / (hashInt === 0n ? 1n : hashInt)); } catch(_){ shareDiff=0; }
              this.pendingShares.set(`${extranonce2Hex}:${nonceHex}`, { shareDiff, hash: finalHex });
              this.stratum.submit([ this.stratum.options.worker, this.job.jobId, extranonce2Hex, nTimeHex, nonceHex ]);
              if (planeIndex != null){ this.planeShareCounts[planeIndex]++; this.totalPlaneShares++; }
            }
            hashes++;
            if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
            continue;
          }
          if (self.selectedAlgo === 'kawpow'){
            // KawPow nonce sweep with optional parity sampling
            const height = this.job.height || 1;
            const seed = this.job.seed || this.job.prevhash || '';
            let nativeRes = self.hashStrategy.hashHeader(headerHex, height, seed);
            let finalHex = nativeRes && nativeRes.finalHash ? nativeRes.finalHash : (typeof nativeRes === 'string'? nativeRes: null);
            if (!finalHex) finalHex = doubleSha256(headerHex); // last-resort

            // Parity sample every KAWPOW_PARITY_INTERVAL hashes (default 97) comparing to a JS fallback (sha256d placeholder here)
            const PARITY_INTERVAL = parseInt(process.env.KAWPOW_PARITY_INTERVAL || '97',10);
            if (PARITY_INTERVAL > 0 && (this.totalHashes % PARITY_INTERVAL === 0)){
              try {
                const jsFallback = doubleSha256(headerHex); // placeholder; future: pure JS kawpow light mirror
                if (jsFallback.slice(0,16) === finalHex.slice(0,16)) {
                  // Probably still stub fallback (both sha256d) -> mark degraded
                  if (!this.kawpowParityDegradedLogged){
                    console.warn('[KawPow][Parity] Detected identical fallback pattern -> native path may be stub.');
                    this.kawpowParityDegradedLogged = true;
                  }
                }
              } catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow][Parity] sample error', e.message); }
            }

            // Metrics ingestion if native stats accessible
            try {
              if (global.kawpowNative && typeof global.kawpowNative.stats === 'function'){
                const st = global.kawpowNative.stats();
                if (global.__AUR_WASM_METRICS__) {
                  global.__AUR_WASM_METRICS__.kawpowHashNsLast = st.lastHashNs;
                  global.__AUR_WASM_METRICS__.kawpowHashNsAvg = st.hashCount ? (st.totalHashNs / st.hashCount) : 0;
                  global.__AUR_WASM_METRICS__.kawpowCacheBuildMs = st.cacheBuildMs;
                }
              }
            } catch(_){ /* silent */ }

            const hashInt = BigInt('0x' + reverseBytes(finalHex));
            const _bp = Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(finalHex,'hex');
            bytesProcessed += _bp;
            global.__HOLO_BYTES_PROCESSED__ += _bp;
            node.feedback(hashInt <= target, this.currentExtranonce2, finalHex, planeIndex);
            if (hashInt <= target){
              let shareDiff = 0; try { shareDiff = Number(this.diff1Target / (hashInt === 0n ? 1n : hashInt)); } catch(_){ shareDiff=0; }
              this.pendingShares.set(`${extranonce2Hex}:${nonceHex}`, { shareDiff, hash: finalHex });
              this.stratum.submit([ this.stratum.options.worker, this.job.jobId, extranonce2Hex, nTimeHex, nonceHex ]);
              if (planeIndex != null){ this.planeShareCounts[planeIndex]++; this.totalPlaneShares++; }
              if (process.env.KAWPOW_VERBOSE==='1') console.log('[KawPow] Share candidate nonce', nonceHex, 'hash', finalHex.slice(0,16));
            }
            hashes++;
            if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
            continue; // proceed next node/nonce
          }
          let headerHash;
          if (self.selectedAlgo === 'sha256d' && wasmHash && global.__AUR_WASM_METRICS__.available){
            try {
              const first64 = headerBuf.slice(0,64); const tail16 = headerBuf.slice(64,80);
              headerHash = wasmHash.doubleSha256MidWasm(first64, tail16).toString('hex');
            } catch(e){ global.__AUR_WASM_METRICS__.fallbacks++; headerHash = (self.hashStrategy? self.hashStrategy.hashHeader(headerHex): doubleSha256(headerHex)); }
          } else {
            // Non-fused path for any algo (sha256d fallback OR scrypt)
            if (self.selectedAlgo === 'scrypt'){
              // Use wasm if available else strategy hash
              if (global.__AUR_WASM_METRICS__.scryptAvailable && scryptWasm && typeof scryptWasm.hashHeader === 'function'){
                try { headerHash = scryptWasm.hashHeader(headerHex); global.__AUR_WASM_METRICS__.scryptCalls++; }
                catch(e){ headerHash = self.hashStrategy.hashHeader(headerHex); global.__AUR_WASM_METRICS__.scryptFallbacks++; }
              } else {
                headerHash = (self.hashStrategy? self.hashStrategy.hashHeader(headerHex): doubleSha256(headerHex));
                global.__AUR_WASM_METRICS__.scryptFallbacks++;
              }
            } else {
              headerHash = (self.hashStrategy? self.hashStrategy.hashHeader(headerHex): doubleSha256(headerHex));
            }
          }
          const hashInt = BigInt('0x' + reverseBytes(headerHash));
          const _bp2 = Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(headerHash,'hex');
          bytesProcessed += _bp2;
          global.__HOLO_BYTES_PROCESSED__ += _bp2;
          node.feedback(hashInt <= target, this.currentExtranonce2, headerHash, planeIndex);
          if (hashInt <= target){
            let shareDiff = 0; try { shareDiff = Number(this.diff1Target / (hashInt === 0n ? 1n : hashInt)); } catch(_){ shareDiff=0; }
            this.pendingShares.set(`${extranonce2Hex}:${nonceHex}`, { shareDiff, hash: headerHash });
            this.stratum.submit([ this.stratum.options.worker, this.job.jobId, extranonce2Hex, nTimeHex, nonceHex ]);
            if (planeIndex != null){ this.planeShareCounts[planeIndex]++; this.totalPlaneShares++; }
          }
          hashes++;
          if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
        }
      }
      // Flush any remaining batched headers
  if (self.selectedAlgo === 'sha256d' && fusedHash && global.__AUR_WASM_METRICS__.fusedAvailable && batchHeaders.length){ flushBatch(); }

      function flushBatch(){
        if (!batchHeaders.length) return;
        const startHr = process.hrtime.bigint();
        let digests; let batchErrored = false;
        if (self.selectedAlgo === 'sha256d'){
          // Priority order: GPU batch (if enabled & available) -> fused WASM -> CPU
          if (self.useGpuBatch && GPU_ENABLED && gpuHash && typeof gpuHash.hashBatch === 'function'){
            let headerHexes = batchHeaders.map(b=> b.toString('hex'));
            try {
              const startBatch = process.hrtime.bigint();
              const outBufs = gpuHash.hashBatch(batchHeaders); // expecting array<Buffer(32)>
              const endBatch = process.hrtime.bigint();
              const ns = Number(endBatch - startBatch);
              digests = outBufs.map(b=> b.toString('hex'));
              const gpuStats = global.__AUR_GPU_STATS__;
              gpuStats.batches++; gpuStats.headers += batchHeaders.length; gpuStats.totalNs += ns; gpuStats.lastBatchNs = ns;
              // Record perf sample
              self._gpuBatchPerf.push({ size: batchHeaders.length, ms: ns/1e6, perHeaderNs: ns / batchHeaders.length });
              if (self._gpuBatchPerf.length > 100) self._gpuBatchPerf.shift();
              // Adaptive sizing
              if (self._gpuBatchPerf.length && (gpuStats.batches % self.gpuBatchAdjustEvery === 0)){
                const recent = self._gpuBatchPerf.slice(-self.gpuBatchAdjustEvery);
                const avgMs = recent.reduce((a,b)=>a+b.ms,0)/recent.length;
                if (avgMs < self.gpuBatchLatencyMaxMs * 0.6 && self.gpuBatchSize < self.gpuBatchMax){
                  self.gpuBatchSize = Math.min(self.gpuBatchMax, Math.round(self.gpuBatchSize * 1.5));
                  global.__AUR_GPU_STATS__.currentBatchSize = self.gpuBatchSize;
                  console.log('[GPU] batch size increase to', self.gpuBatchSize, 'avgMs', avgMs.toFixed(2));
                } else if (avgMs > self.gpuBatchLatencyMaxMs && self.gpuBatchSize > self.gpuBatchMin){
                  self.gpuBatchSize = Math.max(self.gpuBatchMin, Math.round(self.gpuBatchSize / 2));
                  global.__AUR_GPU_STATS__.currentBatchSize = self.gpuBatchSize;
                  console.log('[GPU] batch size decrease to', self.gpuBatchSize, 'avgMs', avgMs.toFixed(2));
                }
              }
              // Deterministic parity sample already handled earlier at HASH_STRATEGIES layer; optional additional spot-check
            } catch(e){
              console.warn('[GPU] batch fallback to fused/CPU due to error:', e.message);
              self.useGpuBatch = false; GPU_ENABLED = false; self.gpuDisabledAt = Date.now();
              batchErrored = true;
              try {
                digests = fusedHash.doubleSha256Batch(batchHeaders).map(b=> b.toString('hex'));
              } catch(e2){
                global.__AUR_WASM_METRICS__.fallbacks += batchHeaders.length;
                digests = headerHexes.map(hx=> doubleSha256(hx));
              }
            }
          } else {
            try {
              digests = fusedHash.doubleSha256Batch(batchHeaders).map(b=> b.toString('hex'));
            } catch(e){
              batchErrored = true;
              global.__AUR_WASM_METRICS__.fallbacks += batchHeaders.length;
              digests = batchHeaders.map(b=> (self.hashStrategy? self.hashStrategy.hashHeader(b.toString('hex')): doubleSha256(b.toString('hex'))));
            }
          }
        } else {
          // No fused batching for non-sha256d algorithms; hash individually
            digests = batchHeaders.map(b=> {
              const hx = b.toString('hex');
              if (self.selectedAlgo === 'scrypt'){
                if (global.__AUR_WASM_METRICS__.scryptAvailable && scryptWasm && typeof scryptWasm.hashHeader === 'function'){
                  try { global.__AUR_WASM_METRICS__.scryptCalls++; return scryptWasm.hashHeader(hx); } catch(_){ global.__AUR_WASM_METRICS__.scryptFallbacks++; return self.hashStrategy.hashHeader(hx); }
                } else { global.__AUR_WASM_METRICS__.scryptFallbacks++; return self.hashStrategy.hashHeader(hx); }
              }
              return self.hashStrategy.hashHeader(hx);
            });
        }
        const endHr = process.hrtime.bigint();
        const batchNs = Number(endHr - startHr);
        const perHeaderNs = batchHeaders.length ? batchNs / batchHeaders.length : 0;
        // Update latency histogram buckets
        if (perHeaderNs > 0){
          let placed = false;
          for (const b of self.latencyBucketBounds){
            if (perHeaderNs <= b){ self.latencyBuckets[b]++; placed = true; break; }
          }
          if (!placed) self.latencyBuckets["inf"]++;
          self.fusedLatencyCount += batchHeaders.length;
          self.fusedLatencyTotalNs += batchNs; // aggregate sum for histogram _sum
          if (global.__AUR_WASM_METRICS__) {
            global.__AUR_WASM_METRICS__.fusedLatencyBuckets = self.latencyBuckets;
            global.__AUR_WASM_METRICS__.fusedLatencyCount = self.fusedLatencyCount;
            global.__AUR_WASM_METRICS__.fusedLatencyTotalNs = self.fusedLatencyTotalNs;
          }
          // Maintain ramp latency sample window (one sample per batch)
          self.rampLatencySamples.push(perHeaderNs);
          if (self.rampLatencySamples.length > self.rampLatencyWindow) self.rampLatencySamples.shift();
          if (self.rampLatencySamples.length){
            const mean = self.rampLatencySamples.reduce((a,b)=>a+b,0)/self.rampLatencySamples.length;
            const varSum = self.rampLatencySamples.reduce((a,b)=> a + (b-mean)*(b-mean),0);
            const variance = varSum / self.rampLatencySamples.length;
            const stdDev = Math.sqrt(variance);
            const cv = mean>0 ? stdDev/mean : 0;
            if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedLatencyCv = Number(cv.toFixed(6));
            // Variance anomaly tightens parity sampling interval deterministically
            if (cv > self.rampMaxCv * 1.5 && Date.now() - self.lastLatencyAnomalyTs > 2000){
              const prevInt = self.fusedParityInterval;
              self.fusedParityInterval = Math.max(self.parityIntervalMin, Math.round(self.fusedParityInterval * self.parityDecreaseFactor));
              if (self.fusedParityInterval !== prevInt){
                self.varianceAnomalyCount++;
                self.parityAnomalyCount++; // total legacy counter still maintained
                if (global.__AUR_WASM_METRICS__) {
                  global.__AUR_WASM_METRICS__.fusedParityInterval = self.fusedParityInterval;
                  global.__AUR_WASM_METRICS__.fusedParityAnomalies = self.parityAnomalyCount;
                  global.__AUR_WASM_METRICS__.fusedVarianceAnomalies = self.varianceAnomalyCount;
                }
              }
              self.parityStableBatches = 0;
              self.lastLatencyAnomalyTs = Date.now();
            }
          }
        }
        // Runtime parity sampling & speedup estimation
  if (self.selectedAlgo === 'sha256d') self.fusedBatchCount++;
        let parityMismatch = false;
  const paritySampleDue = (!batchErrored && self.hashStrategy && self.hashStrategy.parityEnabled && self.fusedBatchCount % self.fusedParityInterval === 0);
        if (paritySampleDue){
          const sampleIdx = 0; // deterministic first header
          const metaS = batchMeta[sampleIdx];
          try {
            const jsStart = process.hrtime.bigint();
            const jsDigest = self.hashStrategy? self.hashStrategy.hashHeader(metaS.headerHex): doubleSha256(metaS.headerHex);
            const jsNs = Number(process.hrtime.bigint() - jsStart);
            if (jsDigest !== digests[sampleIdx]) {
              parityMismatch = true;
            } else {
              // Update speedup EWMA
              if (perHeaderNs > 0){
                const speedup = jsNs / perHeaderNs;
                if (self.fusedSpeedupEwma == null) self.fusedSpeedupEwma = speedup; else self.fusedSpeedupEwma = self.fusedSpeedupEwma * (1-self.fusedSpeedupAlpha) + speedup * self.fusedSpeedupAlpha;
                if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedSpeedupEst = Number(self.fusedSpeedupEwma.toFixed(3));
                // Persist speedup history (lightweight)
                 try {
                   const fs = require('fs');
                   fs.appendFileSync(self.speedupHistoryLog, JSON.stringify({ t: Date.now(), ewma: Number(self.fusedSpeedupEwma.toFixed(4)), batch: batchHeaders.length, perHeaderNs: Math.round(perHeaderNs) })+'\n');
                   self._speedupHistoryAppendCount++;
                   if (self._speedupHistoryAppendCount % self.speedupHistoryCompactEvery === 0){
                     try {
                       const data = fs.readFileSync(self.speedupHistoryLog,'utf8').trim().split(/\n/).filter(Boolean);
                       if (data.length > self.speedupHistoryMaxLines){
                         const trimmed = data.slice(-self.speedupHistoryMaxLines);
                         // Down-sample older half deterministically by taking every 2nd record
                         const keepHead = trimmed.slice(0, Math.floor(trimmed.length/2)).filter((_,i)=> i%2===0);
                         const keepTail = trimmed.slice(Math.floor(trimmed.length/2));
                         const merged = keepHead.concat(keepTail);
                         fs.writeFileSync(self.speedupHistoryLog, merged.join('\n')+'\n');
                       }
                     } catch(_){ }
                   }
                 } catch(_){ }
                self.parityStableBatches++;
                if (self.parityStableBatches >= self.parityAdjustEvery && self.fusedParityInterval < self.parityIntervalMax){
                  const oldInt = self.fusedParityInterval;
                  self.fusedParityInterval = Math.min(self.parityIntervalMax, Math.round(self.fusedParityInterval * self.parityIncreaseFactor));
                  self.parityStableBatches = 0;
                  if (self.fusedParityInterval !== oldInt && global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedParityInterval = self.fusedParityInterval;
                }
              }
            }
          } catch(e){ /* ignore parity error context */ }
        }
        if (parityMismatch){
          console.warn('[Miner] Runtime fused parity mismatch detected – disabling fused path');
          if (global.__AUR_WASM_METRICS__) { global.__AUR_WASM_METRICS__.mismatches++; global.__AUR_WASM_METRICS__.fusedAvailable = false; }
          self.fusedLastDisableTime = Date.now();
          self.fusedRampActive = false; // cancel ramp on mismatch
          const prevInt = self.fusedParityInterval;
          self.fusedParityInterval = Math.max(self.parityIntervalMin, Math.round(self.fusedParityInterval * self.parityDecreaseFactor));
          self.parityMismatchAnomalyCount++;
          self.parityAnomalyCount++; // single increment only
          self.parityStableBatches = 0;
            if (global.__AUR_WASM_METRICS__) {
              global.__AUR_WASM_METRICS__.fusedParityInterval = self.fusedParityInterval;
              global.__AUR_WASM_METRICS__.fusedParityAnomalies = self.parityAnomalyCount;
              global.__AUR_WASM_METRICS__.fusedParityMismatchAnomalies = self.parityMismatchAnomalyCount;
            }
          digests = batchHeaders.map(b=> (self.hashStrategy? self.hashStrategy.hashHeader(b.toString('hex')): doubleSha256(b.toString('hex'))));
        }
        // Periodic JS baseline micro-benchmark (independent of parity sample)
        if (Date.now() - self.lastJsBaseline >= self.jsBaselineIntervalMs){
          try {
            const testHex = batchMeta[0]? batchMeta[0].headerHex : '00'.repeat(80);
            const loops = 4;
            const jsStart = process.hrtime.bigint();
            for (let i=0;i<loops;i++) (self.hashStrategy? self.hashStrategy.hashHeader(testHex): doubleSha256(testHex));
            const jsNs = Number(process.hrtime.bigint() - jsStart)/loops;
            self.jsBaselineNs = Math.round(jsNs);
            self.lastJsBaseline = Date.now();
            if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.jsBaselineNs = self.jsBaselineNs;
          } catch(_){ }
        }
        for (let i=0;i<digests.length;i++){
          const meta = batchMeta[i];
          const headerHash = digests[i];
          const hashInt = BigInt('0x'+ reverseBytes(headerHash));
          const _bp3 = Buffer.byteLength(meta.headerHex,'hex') + Buffer.byteLength(headerHash,'hex');
          bytesProcessed += _bp3;
          global.__HOLO_BYTES_PROCESSED__ += _bp3;
          meta.node.feedback(hashInt <= meta.target, meta.nonceHex, headerHash, meta.planeIndex);
          if (hashInt <= meta.target){
            let shareDiff = 0; try { shareDiff = Number(self.diff1Target / (hashInt === 0n ? 1n : hashInt)); } catch(_){ shareDiff=0; }
            self.pendingShares.set(`${extranonce2Hex}:${meta.nonceHex}`, { shareDiff, hash: headerHash });
            self.stratum.submit([ self.stratum.options.worker, self.job.jobId, extranonce2Hex, nTimeHex, meta.nonceHex ]);
            if (meta.planeIndex != null){ self.planeShareCounts[meta.planeIndex]++; self.totalPlaneShares++; }
          }
          hashes++;
          if (typeof global.__HOLO_HASH_COUNT__ === 'number') global.__HOLO_HASH_COUNT__++;
        }
        // Record performance sample & adapt size if enabled
        if (self.adaptiveBatchEnabled && !batchErrored && perHeaderNs > 0){
          self.batchPerfSamples.push({ size: batchHeaders.length, ms: batchNs/1e6, perHeaderNs });
          if (self.batchPerfSamples.length >= self.batchAdjustEvery){
            // Compute average batch ms
            const avgMs = self.batchPerfSamples.reduce((a,b)=>a+b.ms,0)/self.batchPerfSamples.length;
            if (avgMs > self.batchLatencyMaxMs && self.currentBatchSize > self.batchMin){
              self.currentBatchSize = Math.max(self.batchMin, Math.floor(self.currentBatchSize/2));
            } else if (avgMs < self.batchLatencyMaxMs/2 && self.currentBatchSize < self.batchMax){
              self.currentBatchSize = Math.min(self.batchMax, self.currentBatchSize*2);
            }
            self.batchPerfSamples.length = 0;
            if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.currentBatchSize = self.currentBatchSize;
          }
        }
        // Gentle ramp progression with variance & headroom gating (balanced braces)
        if (self.fusedRampActive && !batchErrored){
          self._fusedRampBatchCounter++;
          const rampEvery = 5;
          if (self._fusedRampBatchCounter % rampEvery === 0){
            let allowStep = true;
            if (self.rampLatencySamples.length >= Math.floor(self.rampLatencyWindow/2)){
              const m = self.rampLatencySamples.reduce((a,b)=>a+b,0)/self.rampLatencySamples.length;
              const vs = self.rampLatencySamples.reduce((a,b)=> a + (b-m)*(b-m),0);
              const varc = vs / self.rampLatencySamples.length;
              const sd = Math.sqrt(varc);
              const cv = (isFinite(m) && m>0) ? sd/m : 0; // guard
              const projectedMs = (m * (self.currentBatchSize*2)) / 1e6;
              if (cv > self.rampMaxCv || projectedMs > self.batchLatencyMaxMs * self.rampHeadroomFactor) allowStep = false;
            }
            if (allowStep && self.currentBatchSize < self.fusedRampTarget){
              self.currentBatchSize = Math.min(self.fusedRampTarget, self.currentBatchSize * 2);
              if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.currentBatchSize = self.currentBatchSize;
            }
            if (self.currentBatchSize >= self.fusedRampTarget){ self.fusedRampActive = false; }
          }
        }
        batchHeaders.length = 0; batchMeta.length = 0;
      }
      this.stats.hashes += hashes;
      if (this.telemetryEnabled && Date.now() - this.lastTelemetry >= this.telemetryIntervalMs){
        const avgInterf = interferenceSamples ? (interferenceAccum / interferenceSamples) : 0;
        const avgGain = gainSamples ? (gainAccum / gainSamples) : 0;
        // Throughput sample & event horizon detection (bytes/sec slope sign change + node growth)
        try {
          const elapsed = (Date.now() - this.startTime)/1000;
          const bps = bytesProcessed / (elapsed||1);
          this.throughputSamples.push({ t: Date.now(), bytes: bytesProcessed, bps, nodes: nodeCount });
          if (this.throughputSamples.length > 60) this.throughputSamples.shift();
          if (this.throughputSamples.length >= 6){
            const first = this.throughputSamples[0];
            const last = this.throughputSamples[this.throughputSamples.length-1];
            const slope = (last.bps - first.bps) / ((last.t - first.t)/1000 || 1);
            this.nodeThroughputSlope = slope;
            const sign = slope>0?1:(slope<0?-1:0);
            if (this.lastSlopeSign !== 1 && sign === 1 && nodeCount > 0){
              this.eventHorizonTs = Date.now();
            }
            this.lastSlopeSign = sign;
          }
        } catch(_){}
        // Decay partition stats periodically
        if (this.symbolicVmEnabled && Date.now() - this.lastPartitionDecay > 5000){
          for (const k of Object.keys(this.partitionStats.attempts)){ this.partitionStats.attempts[k]*=this.partitionDecayFactor; this.partitionStats.accepts[k]*=this.partitionDecayFactor; }
          this.lastPartitionDecay = Date.now();
        }
        const ratios = {}; if (this.symbolicVmEnabled){ for (const k of Object.keys(this.partitionStats.attempts)){ const a=this.partitionStats.attempts[k]||0; const b=this.partitionStats.accepts[k]||0; ratios[k] = a? (b/a):0; } }
        const rec = {
          t: Date.now(),
          hashes: this.stats.hashes,
          shares: this.stats.shares,
          attempted: null, // single-thread path lacks attempt instrumentation
          hashEff: null,
          planeMode: PLANE_AGG_MODE + (PLANE_WEIGHTED?'+w':''),
          coin: this.selectedCoin || 'btc',
          algo: this.selectedAlgo || 'sha256d',
          planeWeights: this.latestPlaneWeights,
          avgInterference: Number(avgInterf.toFixed(6)),
          avgInterferenceGain: Number(avgGain.toFixed(4)),
          planeShareCounts: this.planeShareCounts,
          partitions: this.symbolicVmEnabled ? { attempts: this.partitionStats.attempts, accepts: this.partitionStats.accepts, ratios } : { attempts:{ h0:0,h1:0,h2:0,h3:0 }, accepts:{ h0:0,h1:0,h2:0,h3:0 }, ratios:{ h0:0,h1:0,h2:0,h3:0 } },
          nodes: nodeCount,
          ths: this.stats.ths,
            wasm: (global.__AUR_WASM_METRICS__) ? (()=>{
              let extra = {};
              try { const w = require('./midstate_wasm.js'); if (w._stats){ const s=w._stats; extra.mid = { calls:s.calls, pooled:s.pooled, mallocs:s.mallocs, avgFirstNs: s.calls? Math.round(s.firstHashNs/s.calls):0, avgSecondNs: s.calls? Math.round(s.secondHashNs/s.calls):0 }; } } catch(_){ }
              try { const f = require('./fused_wasm.js'); if (f._stats){ const fs=f._stats; const fusedObj = { calls:fs.calls, batches:fs.batches, totalHeaders:fs.totalHeaders, avgNsPerHeader: fs.totalHeaders? Math.round(fs.ns/fs.totalHeaders):0, speedupEst: global.__AUR_WASM_METRICS__.fusedSpeedupEst || 0, currentBatchSize: global.__AUR_WASM_METRICS__.currentBatchSize || 0, jsBaselineNs: global.__AUR_WASM_METRICS__.jsBaselineNs || 0, latencyBuckets: global.__AUR_WASM_METRICS__.fusedLatencyBuckets || {}, latencyCount: global.__AUR_WASM_METRICS__.fusedLatencyCount || 0, latencyTotalNs: global.__AUR_WASM_METRICS__.fusedLatencyTotalNs || 0, recoverAttempts: global.__AUR_WASM_METRICS__.fusedRecoverAttempts || 0, recoverSuccesses: global.__AUR_WASM_METRICS__.fusedRecoverSuccesses || 0, recoverFailures: global.__AUR_WASM_METRICS__.fusedRecoverFailures || 0, lastRecoverTs: global.__AUR_WASM_METRICS__.fusedLastRecoverTs || 0, parityInterval: global.__AUR_WASM_METRICS__.fusedParityInterval || this.fusedParityInterval, parityAnomalies: global.__AUR_WASM_METRICS__.fusedParityAnomalies || this.parityAnomalyCount, latencyCv: global.__AUR_WASM_METRICS__.fusedLatencyCv || 0, rampActive: this.fusedRampActive?1:0 };
                if (this.rampLatencySamples.length){ const mean = this.rampLatencySamples.reduce((a,b)=>a+b,0)/this.rampLatencySamples.length; fusedObj.projectedNextDoubleNs = Math.round(mean * this.currentBatchSize * 2); } else { fusedObj.projectedNextDoubleNs = 0; }
                fusedObj.rampTarget = this.fusedRampTarget || 0;
                  fusedObj.parityMismatchAnomalies = this.parityMismatchAnomalyCount;
                  fusedObj.varianceAnomalies = this.varianceAnomalyCount;
                  fusedObj.eventHorizonTs = this.eventHorizonTs;
                  fusedObj.nodeThroughputSlope = Number(this.nodeThroughputSlope.toFixed(3));
                extra.fused = fusedObj; } } catch(_){ }
              return { midAvailable: !!global.__AUR_WASM_METRICS__.available, fusedAvailable: !!global.__AUR_WASM_METRICS__.fusedAvailable, fallbacks: global.__AUR_WASM_METRICS__.fallbacks||0, mismatches: global.__AUR_WASM_METRICS__.mismatches||0, ...extra };
            })() : undefined,
          gpu: (function(){
            if (!GPU_ENABLED) return { enabled:false, stub: (function(){ try { const n=require('./gpu_sha256d_native'); return n && n.isStub; } catch(_){ return true; } })() };
            const g = global.__AUR_GPU_STATS__ || {};
            return {
              enabled: true,
              stub: (function(){ try { const n=require('./gpu_sha256d_native'); return n && n.isStub; } catch(_){ return false; } })(),
              batches: g.batches||0,
              headers: g.headers||0,
              avgNsPerHeader: g.headers? Math.round((g.totalNs||0)/g.headers):0,
              lastBatchNs: g.lastBatchNs||0,
              parityChecks: g.parityChecks||0,
              parityMismatches: g.parityMismatches||0,
              samplerInterval: (global.__AUR_GPU_SAMPLER__ && global.__AUR_GPU_SAMPLER__.interval) || null
            };
          })(),
        };
    // Embed deterministic & adaptive parameters
  rec.seed = GLOBAL_OCTO_SEED; rec.burrowDepth = GLOBAL_BURROW_DEPTH; rec.pruneThreshold = GLOBAL_PRUNE_THRESHOLD; if (this.dynamicPruneThreshold) rec.dynamicPruneThreshold = this.dynamicPruneThreshold; rec.configHash = CONFIG_HASH; if (CONFIG_HMAC) rec.configHmac = CONFIG_HMAC; if (SOURCE_MANIFEST_HASH) rec.sourceManifestHash = SOURCE_MANIFEST_HASH; if (SOURCE_MANIFEST_HMAC) rec.sourceManifestHmac = SOURCE_MANIFEST_HMAC;
        // Partition ring utilization metrics (if enabled)
        if (this.picoCrystalTuner && this.picoCrystalTuner.partition8) {
          try {
            const fs = require('fs');
            const util = {};
            for (const rf of this.picoCrystalTuner.ringFiles) {
              try { const st = fs.statSync(rf); util[rf] = st.size; } catch(_) { util[rf]=0; }
            }
            rec.partition8 = { enabled: true, rings: util };
          } catch(_) { rec.partition8 = { enabled:true, error:true }; }
        } else {
          rec.partition8 = { enabled: false };
        }
        try { require('fs').appendFileSync(process.env.METRICS_LOG || 'aurrelia-metrics.jsonl', JSON.stringify(rec)+'\n'); } catch(_){ }
        // Metrics compaction / rotation (deterministic down-sample) when size exceeds threshold
        try {
          const fs = require('fs');
          const mPath = process.env.METRICS_LOG || 'aurrelia-metrics.jsonl';
          const maxBytes = parseInt(process.env.METRICS_MAX_BYTES || '50000000',10); // 50MB
          const dsFactor = parseInt(process.env.METRICS_DOWNSAMPLE_FACTOR || '5',10);
          if (fs.existsSync(mPath)) {
            const st = fs.statSync(mPath);
            if (st.size > maxBytes) {
              const lines = fs.readFileSync(mPath,'utf8').trim().split(/\n/).filter(Boolean);
              if (lines.length > 10000) {
                const head = lines.slice(0, Math.floor(lines.length/2)).filter((_,i)=> i % dsFactor === 0);
                const tail = lines.slice(Math.floor(lines.length/2));
                const merged = head.concat(tail);
                fs.writeFileSync(mPath, merged.join('\n')+'\n');
                console.log('[Metrics] Compaction applied');
              }
            }
          }
        } catch(_){ }
        this.lastTelemetry = Date.now();
      }
    }

    // Stats
    const now = Date.now();
    if (this.stats.hashes % 10000 < 1000 || now - lastThroughputLog > 5000) {
      const elapsed = (now - this.startTime) / 1000;
  // TH/s removed – focus on deterministic bytes/sec throughput
  const throughput = (bytesProcessed / (elapsed || 1)).toFixed(2);
  const dbgRequestedCoin = (process.env.AUR_COIN || '').toLowerCase();
  const dbgExperimentalFlag = (process.env.AUR_EXPERIMENTAL === '1' || process.argv.includes('--experimental')) ? 'expOn':'expOff';
  console.log(`Stats: coin=${this.selectedCoin} algo=${this.selectedAlgo} ${this.stats.hashes} hashes, ${this.stats.shares} shares, ${throughput} bytes/sec, ${nodeCount} nodes built (envCoin=${dbgRequestedCoin||'none'} ${dbgExperimentalFlag})`);
      lastThroughputLog = now;
      if (this.hashStrategy && this.hashStrategy.id === 'gpu_sha256d' && !GPU_ENABLED && this.gpuAutoReEnable){
        if (!this.gpuDisabledAt) this.gpuDisabledAt = Date.now();
        if (Date.now() - this.gpuDisabledAt >= this.gpuBackoffMs){
          if (gpuHash && (gpuHash.hashBatch || gpuHash.hashHeader)){
            console.log('[GPU] Auto re-enable attempt after backoff window');
            GPU_ENABLED = true; this.gpuDisabledAt = 0;
          }
        }
      }
    }
    setImmediate(() => this.mine());
  }
  compileVmProgram(tag, seedBasis){
    const keySeed = (this.job? this.job.jobId:'') + seedBasis + tag;
    const progSeed = crypto.createHash('sha256').update(keySeed).digest('hex');
    const ops = [];
    for (let i=0;i<progSeed.length && ops.length < 32;i++){
      const nib = parseInt(progSeed[i],16);
      const opcode = nib % 8;
      const cIdx = (i+1) % progSeed.length;
      const cVal = parseInt(progSeed.slice(cIdx,cIdx+2),16) || nib;
      ops.push({ opcode, c: cVal });
    }
    if (!ops.some(o=>o.opcode===7) && ops.length){ ops[ops.length-1].opcode=7; }
    return ops;
  }
}

// Multi-worker coordinator bootstrap
const user = process.env.AUR_DEFAULT_WORKER || 'donumdei888.001';
const WORKER_HEALTH_TIMEOUT = parseInt(process.env.WORKER_HEALTH_TIMEOUT || '6000',10); // D. heartbeat timeout
const ENABLE_ASYNC_PERSISTENCE = process.env.ASYNC_PERSISTENCE === '1'; // C. delegate real offloads to persistence worker

if (AUR_WORKERS <= 1) {
  const pipeline = new F2PoolAurreliaPipeline(user);
  if (AUR_WORKERS <= 1) {
    global.__AUR_PIPELINE__ = pipeline; // expose for single-worker observability only
    // Holodeck hash counter (deterministic activity gauge)
    if (typeof global.__HOLO_HASH_COUNT__ !== 'number') global.__HOLO_HASH_COUNT__ = 0;
  }
  // --- Adaptive Prune (EWMA) -------------------------------------------
  pipeline.adaptivePruneEnabled = process.env.AUR_EWMA_PRUNE === '1';
  pipeline.pruneEwmaAlpha = parseFloat(process.env.EWMA_ALPHA || '0.10');
  pipeline.pruneMin = parseFloat(process.env.PRUNE_MIN || '2.5');
  pipeline.pruneMax = parseFloat(process.env.PRUNE_MAX || '4.0');
  pipeline.dynamicPruneThreshold = GLOBAL_PRUNE_THRESHOLD; // start baseline
  pipeline.pruneEwma = GLOBAL_PRUNE_THRESHOLD;
  pipeline._normSamples = []; // sliding window of candidate norms
  pipeline.normSampleCap = parseInt(process.env.NORM_SAMPLE_CAP || '600',10);
  pipeline.normPercentileLow = parseFloat(process.env.NORM_PCT_LOW || '0.30');
  pipeline.normPercentileHigh = parseFloat(process.env.NORM_PCT_HIGH || '0.40');
  pipeline._lastPruneAdjust = 0;
  pipeline.pruneAdjustIntervalMs = parseInt(process.env.PRUNE_ADJUST_INTERVAL_MS || '4000',10);
  // Dynamic pool discovery (opt-in)
  try {
    const DISC_ALLOW = process.env.ALLOW_DYNAMIC_POOL_DISCOVERY === '1';
    const DISC_INTERVAL = parseInt(process.env.POOL_DISCOVERY_INTERVAL_MS || '600000',10);
    const rvnSrc = process.env.RVN_POOL_DISCOVERY || process.env.RVN_POOL_DISCOVERY_URL || '';
    const btcSrc = process.env.BTC_POOL_DISCOVERY || process.env.BTC_POOL_DISCOVERY_URL || '';
    function _normStratum(u){ if (!u) return null; let s=String(u).trim(); if (!/^stratum\+tcp:\/\//i.test(s)){ if (/^[a-z0-9_.-]+:\d+$/i.test(s)) s='stratum+tcp://'+s; else return null; } return s; }
    async function discoverOnce(coin, src){
      if (!DISC_ALLOW || !src) return;
      try {
        const txt = await fetchText(src).catch(()=>null); if (!txt) return;
        let found=null; const m = txt.match(/(stratum\+tcp:\/\/)?([a-z0-9_.-]+):(\d{2,5})/i);
        if (m){ found=(m[1]? '':'stratum+tcp://')+m[2]+':'+m[3]; }
        const url=_normStratum(found); if (!url) return;
        const prev = __DISCOVERED_POOLS[coin] || null;
        if (prev !== url){ __DISCOVERED_POOLS[coin]=url; econStructuredLog('pool_discovery',{ coin, url, source: src, updated:true }); }
      } catch(_){ }
    }
    if (DISC_ALLOW && (rvnSrc || btcSrc)){
      if (rvnSrc) discoverOnce('rvn', rvnSrc);
      if (btcSrc) discoverOnce('btc', btcSrc);
      setInterval(()=>{ if (rvnSrc) discoverOnce('rvn', rvnSrc); if (btcSrc) discoverOnce('btc', btcSrc); }, DISC_INTERVAL).unref();
    }
  } catch(_){ }
  if (PRINT_CONFIG) {
    const cfg = {
      seed: GLOBAL_OCTO_SEED,
      burrowDepth: GLOBAL_BURROW_DEPTH,
      pruneThreshold: GLOBAL_PRUNE_THRESHOLD,
      multiHarmonic: MULTI_HARMONIC ? 1 : 0,
      planeAggMode: PLANE_AGG_MODE + (PLANE_WEIGHTED?'+w':''),
      minimal: MINING_MINIMAL ? 1 : 0,
      algo: pipeline.selectedAlgo,
      coin: pipeline.selectedCoin,
      configHash: CONFIG_HASH,
      configHmac: CONFIG_HMAC || null,
      partition8: pipeline.picoCrystalTuner ? (pipeline.picoCrystalTuner.partition8?1:0):0,
      sourceManifestHash: SOURCE_MANIFEST_HASH || null,
      sourceManifestHmac: SOURCE_MANIFEST_HMAC || null
    };
    console.log('[CONFIG]', JSON.stringify(cfg));
    process.exit(0);
  }
  pipeline.start();
  // Solo pool rotation scheduler (time-based). Disabled unless SOLO_POOL_CYCLE=1 and coin starts with btc_.
  if (process.env.SOLO_POOL_CYCLE === '1'){
    const intervalMs = parseInt(process.env.SOLO_POOL_INTERVAL_MS || '900000',10); // default 15m
    if (!global.__AUR_SOLO_ROTATE__){
      console.log('[SoloRotate] Enabled interval', intervalMs, 'ms; sequence', SOLO_POOLS_SEQUENCE.join(','));
      global.__AUR_SOLO_ROTATE__ = { last: Date.now(), intervalMs };
      setInterval(()=>{
        try {
          rotateSoloPool(pipeline, 'interval');
          global.__AUR_SOLO_ROTATE__.last = Date.now();
        } catch(e){ console.warn('[SoloRotate] error', e.message); }
      }, intervalMs).unref();
      // Failure-based evaluator loop (short cadence)
      const evalMs = parseInt(process.env.SOLO_POOL_EVAL_MS || '60000',10); // 1m
      setInterval(()=>{ evaluateSoloRotation(pipeline); }, evalMs).unref();
      // Passive probe loop (optional)
      const probeMs = parseInt(process.env.SOLO_POOL_PROBE_INTERVAL_MS || '300000',10); // 5m default
      setInterval(()=>{ passivePoolProbe(pipeline); }, probeMs).unref();
      // Stale share decay loop
      const staleDecayMs = parseInt(process.env.SOLO_POOL_STALE_DECAY_INTERVAL_MS || '600000',10); // 10m default
      const staleDecayFactor = parseFloat(process.env.SOLO_POOL_STALE_DECAY_FACTOR || '0.85');
      setInterval(()=>{
        try {
          for (const rec of pipeline.poolPerf.map.values()){
            if (rec.staleShares>0){ rec.staleShares = Math.floor(rec.staleShares * staleDecayFactor); }
          }
        } catch(_){ }
      }, staleDecayMs).unref();
    }
  }
  // Adaptive prune self-learning loop
  if (pipeline.pruneLearn && pipeline.pruneLearn.enabled){
    setInterval(()=>{
      try {
        const pl = pipeline.pruneLearn;
        const now = Date.now();
        if (pl.attempts === 0) return;
        const windowData = pl.recent.slice(-pl.window);
        const accWindow = windowData.filter(r=>r.ok).length;
        const acceptRatio = accWindow / (windowData.length||1);
        if (now - pl.lastAdjust >= pl.intervalMs){
          if (acceptRatio < pl.targetAccept*0.8 && pipeline.dynamicPruneThreshold < pl.max){
            pipeline.dynamicPruneThreshold = Math.min(pl.max, (pipeline.dynamicPruneThreshold || GLOBAL_PRUNE_THRESHOLD) + pl.step);
          } else if (acceptRatio > pl.targetAccept*1.2 && pipeline.dynamicPruneThreshold > pl.min){
            pipeline.dynamicPruneThreshold = Math.max(pl.min, (pipeline.dynamicPruneThreshold || GLOBAL_PRUNE_THRESHOLD) - pl.step);
          }
          pl.lastAdjust = now;
          if (process.env.AUR_PRUNE_LEARN_LOG==='1') console.log('[PruneLearn] ratio', acceptRatio.toFixed(3),'target',pl.targetAccept,'newThr',pipeline.dynamicPruneThreshold.toFixed(3));
        }
      } catch(_){}
    }, parseInt(process.env.AUR_PRUNE_TICK_MS || '5000',10)).unref();
  }
  // Plane reinforcement updater
  setInterval(()=>{
    try {
      const pr = pipeline.planeReinforce;
      if (!pr) return;
  const totalAttempts = pr.attempts.reduce((a,b)=>a+b,0);
      if (totalAttempts < 50) return; // wait for enough samples
      const eff = pr.attempts.map((a,i)=> a? (pr.accepts[i]/a):0);
      const meanEff = eff.reduce((a,b)=>a+b,0)/eff.length;
      const newWeights = eff.map(e=> (e + 1e-6) / (meanEff + 1e-6));
      // Normalize
      const sumW = newWeights.reduce((a,b)=>a+b,0);
      for (let i=0;i<newWeights.length;i++) pr.weights[i] = newWeights[i]/sumW;
      // Optional ML inference override (TensorRT or Coral) if enabled
      let mlLatencyMs = null;
      // Latency skip guard: if last latency consumed > interval*0.8 skip ML this cycle for stability
      const intervalMs = parseInt(process.env.AUR_PLANE_REINFORCE_MS || '12000',10);
      if (pipeline.lastMlLatencyMs && pipeline.lastMlLatencyMs > intervalMs * 0.8){
        if (process.env.ML_LAT_SKIP_LOG==='1') console.log('[ML] Skipping ML override due to previous high latency', pipeline.lastMlLatencyMs);
      } else {
      const startMs = Date.now();
      try {
        // Feature vector builder aligning with ONNX training pipeline ordering
        // Deterministic ordering: [meanEff, eff[0..3], attempts[0..3], accepts[0..3], gapRatio, rashbaGain, hypercubeBlend, subsetIdx, chernProxy]
        const gapRatio = typeof pipeline.spinGapRatio === 'number' ? pipeline.spinGapRatio : 0;
        const rashbaGain = typeof pipeline.rashbaGain === 'number' ? pipeline.rashbaGain : 0;
        const hypercubeBlend = pipeline.hypercubeBlend || 0;
        const subsetIdx = pipeline.hypercubeSubsetIdx || 0;
        const chernProxy = pipeline.lastChernProxyDensity || 0;
        const featBase = [ meanEff ]
          .concat(eff)
          .concat(pr.attempts.map(v=> v))
          .concat(pr.accepts.map(v=> v))
          .concat([ gapRatio, rashbaGain, hypercubeBlend, subsetIdx, chernProxy ]);
        if (process.env.ML_TENSORRT === '1'){
          if (!global.__AUR_TRT__){
            try { global.__AUR_TRT__ = require('bindings')('tensorrt-addon'); global.__AUR_TRT_ENGINE__ = global.__AUR_TRT__.loadEngine(process.env.TRT_ENGINE_PATH || 'weights.trt'); console.log('[ML] TensorRT engine loaded'); } catch(e){ console.warn('[ML] TensorRT load failed', e.message); }
          }
          if (global.__AUR_TRT__ && global.__AUR_TRT_ENGINE__){
            if (typeof pipeline.mlModelVersion !== 'number'){ pipeline.mlModelVersion = parseInt(process.env.TRT_MODEL_VERSION || '1',10); }
            const out = global.__AUR_TRT__.infer(global.__AUR_TRT_ENGINE__, featBase);
            if (out && Array.isArray(out) && out.length === pr.weights.length){ pr.weights = out.map(v=> Math.max(0.01, v)); }
          }
        } else if (process.env.ML_CORAL === '1'){
          // Warm persistent Coral process strategy
          const fs = require('fs');
          const path = require('path');
          const { spawnSync, spawn } = require('child_process');
          const sockPath = process.env.CORAL_SOCKET_PATH || path.join(process.cwd(),'coral-ipc.sock');
          const warmScript = process.env.CORAL_WARM_SCRIPT || 'coral_infer.py';
          if (!global.__CORAL_WORKER__){
            try {
              // Remove stale socket
              if (fs.existsSync(sockPath)) try { fs.unlinkSync(sockPath); } catch(_){ }
              global.__CORAL_WORKER__ = spawn('python3',[warmScript, '--server', sockPath], { stdio:['ignore','pipe','pipe'] });
              global.__CORAL_WORKER__.stdout.on('data', d=>{ if (process.env.CORAL_WARM_LOG==='1') console.log('[CoralWarm]', d.toString().trim()); });
              global.__CORAL_WORKER__.stderr.on('data', d=>{ if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWarmE]', d.toString().trim()); });
              if (typeof pipeline.mlModelVersion !== 'number'){ pipeline.mlModelVersion = parseInt(process.env.CORAL_MODEL_VERSION || '1',10); }
              global.__CORAL_WORKER__.on('exit', (code)=>{ global.__CORAL_WORKER_EXIT_TS__ = Date.now(); global.__CORAL_WORKER__ = null; if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWarm] exited code', code); });
            } catch(e){ if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWarm] spawn failed', e.message); }
          }
          if (!global.__CORAL_WATCHDOG__){
            global.__CORAL_WATCHDOG__ = setInterval(()=>{
              try {
                if (process.env.ML_CORAL !== '1') return;
                if (!global.__CORAL_WORKER__ && (!global.__CORAL_WORKER_EXIT_TS__ || Date.now() - global.__CORAL_WORKER_EXIT_TS__ > 1000)){
                  try {
                    global.__CORAL_WORKER__ = spawn('python3',[warmScript, '--server', sockPath], { stdio:['ignore','pipe','pipe'] });
                    global.__CORAL_WORKER__.stdout.on('data', d=>{ if (process.env.CORAL_WARM_LOG==='1') console.log('[CoralWarm]', d.toString().trim()); });
                    global.__CORAL_WORKER__.stderr.on('data', d=>{ if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWarmE]', d.toString().trim()); });
                    global.__CORAL_WORKER__.on('exit', (code)=>{ global.__CORAL_WORKER_EXIT_TS__ = Date.now(); global.__CORAL_WORKER__ = null; if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWarm] exited code', code); });
                    if (process.env.CORAL_WARM_LOG==='1') console.log('[CoralWatchdog] restarted Coral worker');
                  } catch(err){ if (process.env.CORAL_WARM_LOG==='1') console.warn('[CoralWatchdog] restart failed', err.message); }
                }
              } catch(_){ }
            }, 2500).unref();
          }
          let coralOutput = null;
          try {
            // Fallback single-shot if warm process not ready
            const useSingle = !fs.existsSync(sockPath);
            if (useSingle){
              const resp = spawnSync('python3',[warmScript, JSON.stringify(featBase)], { timeout: parseInt(process.env.CORAL_SINGLE_TIMEOUT_MS||'1500',10) });
              if (resp.status === 0){ coralOutput = JSON.parse(resp.stdout.toString()); }
            } else {
              // IPC via simple file request-response (deterministic, no network)
              const reqPath = sockPath + '.req';
              const resPath = sockPath + '.res';
              fs.writeFileSync(reqPath, JSON.stringify(featBase));
              const startWait = Date.now();
              while (Date.now() - startWait < 1200){
                if (fs.existsSync(resPath)){
                  coralOutput = JSON.parse(fs.readFileSync(resPath,'utf8')); fs.unlinkSync(resPath); break;
                }
              }
              try { fs.unlinkSync(reqPath); } catch(_){ }
            }
          } catch(e){ /* swallow */ }
          if (Array.isArray(coralOutput) && coralOutput.length === pr.weights.length){ pr.weights = coralOutput.map(v=> Math.max(0.01, v)); }
        }
      } catch(_){ }
      mlLatencyMs = Date.now() - startMs;
      }
      pipeline.lastMlLatencyMs = mlLatencyMs;
      if (!pipeline.mlLatencySamples) pipeline.mlLatencySamples = [];
      if (mlLatencyMs != null){
        pipeline.mlLatencySamples.push(mlLatencyMs);
        if (pipeline.mlLatencySamples.length > 256) pipeline.mlLatencySamples.shift();
        // compute percentiles P50/P90/P99 deterministically
        const sorted = pipeline.mlLatencySamples.slice().sort((a,b)=>a-b);
        const pct = (p)=> sorted[Math.min(sorted.length-1, Math.floor((p/100)*sorted.length))];
        pipeline.mlLatencyP50 = pct(50); pipeline.mlLatencyP90 = pct(90); pipeline.mlLatencyP99 = pct(99);
        if (mlLatencyMs > 2000 && !pipeline.mlLatencyBucketsExtended && global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.registry){
          try {
            const prom = require('prom-client');
            const ext = new prom.Histogram({ name:'aurrelia_ml_latency_hist_ext_ms', help:'Extended histogram of ML inference latency (ms)', buckets:[10,25,50,75,100,150,250,400,600,800,1000,1500,2000,2500,3000,4000,5000] });
            global.__AUR_METRICS_REG__.registry.registerMetric(ext);
            global.__AUR_METRICS_REG__.gauges.mlLatencyHistExt = ext;
            pipeline.mlLatencyBucketsExtended = true;
          } catch(e){ }
        }
        if (pipeline.mlLatencyBucketsExtended && global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges.mlLatencyHistExt){ global.__AUR_METRICS_REG__.gauges.mlLatencyHistExt.observe(mlLatencyMs); }
      }
      if (process.env.AUR_PLANE_REINFORCE_LOG==='1') console.log('[PlaneReinforce] eff', eff.map(e=>e.toFixed(3)).join(','),'weights', pr.weights.map(w=>w.toFixed(3)).join(','));
      // Decay counts to give recent data more influence
      for (let i=0;i<4;i++){ pr.attempts[i]*=0.5; pr.accepts[i]*=0.5; }
      // RVN KawPow adaptive prune tuning via agent suggestion (deterministic stub -> real model later)
      if (pipeline.selectedCoin === 'rvn'){
        try {
          const gapRatio = typeof pipeline.spinGapRatio === 'number' ? pipeline.spinGapRatio : 0;
          const rashbaGain = typeof pipeline.rashbaGain === 'number' ? pipeline.rashbaGain : 0;
          const hypercubeBlend = pipeline.hypercubeBlend || 0;
          const subsetIdx = pipeline.hypercubeSubsetIdx || 0;
          const chernProxy = pipeline.lastChernProxyDensity || 0;
          const featBase = [ meanEff ].concat(eff).concat(pr.attempts).concat(pr.accepts).concat([ gapRatio, rashbaGain, hypercubeBlend, subsetIdx, chernProxy, 1 ]);
          Promise.resolve(invokeAgent('burrowAdapt', 'refine nonce bias for RVN KawPow', { featBase }))
            .then(act=>{
              if (act && act.suggestion && act.suggestion.action === 'adjust_prune' && typeof act.suggestion.delta === 'number'){
                const d = Math.max(-0.05, Math.min(0.05, act.suggestion.delta));
                pipeline.dynamicPruneThreshold = Math.min(pipeline.pruneMax || 4.0, Math.max(pipeline.pruneMin || 1.6, pipeline.dynamicPruneThreshold + d));
                if (process.env.AGENT_TUNE_LOG==='1' || process.env.AUR_PLANE_REINFORCE_LOG==='1') console.log('[Copilot][KawPowTune] prune adjust', d.toFixed(5), '->', pipeline.dynamicPruneThreshold.toFixed(3));
              }
            })
            .catch(e=>{ if (process.env.AGENT_TUNE_LOG==='1') console.warn('[AgentTune] error', e.message); });
        } catch(e){ if (process.env.AGENT_TUNE_LOG==='1') console.warn('[AgentTune] setup error', e.message); }
      }
    } catch(_){}
  }, parseInt(process.env.AUR_PLANE_REINFORCE_MS || '12000',10)).unref();
} else {
  // Worker thread mode
  const { Worker } = require('worker_threads');
  const workers = [];
  let currentJobSnapshot = null;
  let hashes = 0; let shares = 0; let bytes = 0; let attempted = 0; let oppAttempts = 0; let lastFlushTotal = 0;
  let lastHashProgressTs = Date.now();
  let stallFusedDisabled = false;
  // Global norm guidance / adaptation aggregation
  const NORM_RING_CAP = parseInt(process.env.COORD_NORM_RING_CAP || '512',10);
  const TARGET_LOW = parseFloat(process.env.COORD_NORM_TARGET_LOW || '0.25');
  const TARGET_HIGH = parseFloat(process.env.COORD_NORM_TARGET_HIGH || '0.40');
  const GUIDANCE_INTERVAL_MS = parseInt(process.env.COORD_NORM_GUIDE_INTERVAL_MS || '5000',10);
  const OSC_WINDOW = parseInt(process.env.COORD_NORM_OSC_WINDOW || '6',10); // number of changes to inspect for thrash
  const OSC_DAMP_FACTOR = parseFloat(process.env.COORD_NORM_OSC_DAMP || '0.5');
  const OSC_THRESHOLD = parseInt(process.env.COORD_NORM_OSC_THRESHOLD || '3',10); // flips within window
  let normSampleRing = []; // store {thr, accRate, ts}
  let lastGuidanceTs = 0;
  let lastGlobalThreshold = null;
  let globalOscillationScore = 0;
  let lastBroadcastNormThreshold = null;
  // Global gating norm threshold (adaptive). Base can be overridden by env NORM_THRESHOLD_BASE.
  let globalNormThreshold = parseFloat(process.env.NORM_THRESHOLD_BASE || '2.50');
  if (global.__AUR_NORM_THRESHOLD != null) globalNormThreshold = global.__AUR_NORM_THRESHOLD;
  global.__AUR_NORM_THRESHOLD = globalNormThreshold;
  let lastPersistAdaptiveTs = Date.now();
  function computePercentile(samples, p){ if (!samples.length) return 0; const sorted=[...samples].sort((a,b)=>a-b); const idx=Math.min(sorted.length-1, Math.floor(p*(sorted.length-1))); return sorted[idx]; }
  const STALL_HASH_WINDOW_MS = parseInt(process.env.STALL_HASH_WINDOW_MS || '7000',10); // duration with attempts rising but no hashes
  const STALL_ATTEMPT_DELTA = parseInt(process.env.STALL_ATTEMPT_DELTA || '500',10); // attempts growth threshold to treat as stall
  const TUNE_INTERVAL_MS = parseInt(process.env.TUNE_INTERVAL_MS || '15000',10);
  let lastTuneTs = Date.now();
  let dynamicModulus = parseInt(process.env.WORKER_MODULUS || '6',10);
  let dynamicFlushMs = parseInt(process.env.WORKER_BATCH_FLUSH_MS || '80',10);
  // Count how many times watchdog has disabled fused mode (telemetry + Prometheus)
  let watchdogFusedDisableCount = 0;
  let partitionStats = { attempts: { h0:0,h1:0,h2:0,h3:0 }, accepts: { h0:0,h1:0,h2:0,h3:0 } };
  let planeSeedsCache = null; let romanSeedCache = null; let bindHash = 'stub';
  let sharedFreq = 432; // cooperative shared frequency
  let lastMeshPulse = Date.now();
  // Per-harmonic work allocation weights (dynamic) when MULTI_HARMONIC active
  let harmonicWeights = MULTI_HARMONIC ? HARMONICS.map(()=>1/HARMONICS.length) : [1];
  function rebalanceHarmonics(){
    if (!MULTI_HARMONIC) return;
    // If local acceptance high, damp our assigned harmonic weight slightly to free room for others
    if (__HBUS_LOCAL_ACCEPT > 0.06 && __HBUS_ASSIGNED_FREQ){
      const idx = HARMONICS.indexOf(__HBUS_ASSIGNED_FREQ);
      if (idx>=0){
        harmonicWeights[idx] *= 0.95; // slight reduction
        const sum = harmonicWeights.reduce((a,b)=>a+b,0)||1; for (let i=0;i<harmonicWeights.length;i++) harmonicWeights[i]/=sum;
      }
    }
  }
  const MESH_PULSE_INTERVAL = parseInt(process.env.MESH_PULSE_INTERVAL || '3000',10);
  // Aggregated fused metrics across shards (if they emit partial states in future extension)
  let fusedAggLegacy = {
    latencyBuckets: {},
    latencyCount: 0,
    latencyTotalNs: 0,
    recoverAttempts: 0,
    recoverSuccesses: 0,
    recoverFailures: 0,
    lastRecoverTs: 0,
    parityInterval: 0,
    parityAnomalies: 0,
    currentBatchSize: 0,
    speedupEst: 0,
    jsBaselineNs: 0,
    latencyCv: 0,
    rampActive: 0
  };
  // Adaptive state persistence file
  const adaptiveStatePath = process.env.ADAP_STATE_PATH || 'adaptive-state.json';
  function loadAdaptiveState(){
    try { const fs=require('fs'); if (fs.existsSync(adaptiveStatePath)){ const st=JSON.parse(fs.readFileSync(adaptiveStatePath,'utf8')); return st || {}; } } catch(_){}
    return {}; }
  function saveAdaptiveState(state){ try { require('fs').writeFileSync(adaptiveStatePath, JSON.stringify(state)); } catch(_){} }
  const loadedState = loadAdaptiveState();
  // Restore persisted adaptive parameters (normThreshold, latency backoff factor)
  try {
    if (loadedState && loadedState.globalNormThreshold != null && isFinite(loadedState.globalNormThreshold)){
      global.__AUR_NORM_THRESHOLD = loadedState.globalNormThreshold;
    }
    if (loadedState && loadedState.latBackoffFactor != null && isFinite(loadedState.latBackoffFactor)){
      if (!global.__AUR_LAT_BACKOFF) global.__AUR_LAT_BACKOFF = { factor:1 };
      global.__AUR_LAT_BACKOFF.factor = loadedState.latBackoffFactor;
    }
    if (loadedState && loadedState.lastSwitchTs){ __ECON_LAST_SWITCH = loadedState.lastSwitchTs; }
    if (loadedState && loadedState.activeCoin){ __ECON_ACTIVE_COIN = loadedState.activeCoin; }
    if (loadedState && loadedState.lastSwitchReason){ __ECON_LAST_SWITCH_REASON = loadedState.lastSwitchReason; }
  } catch(_){ }
  // Persistence worker (async crystal offload)
  const persistenceWorker = new Worker('./persistence-worker.js');
  let lastPersistenceAck = Date.now();
  persistenceWorker.on('message', (m)=>{
    if (m.type === 'PERSIST_OK') {
      const pseudoCid = m.cid;
      const auditBind = pipeline.picoCrystalTuner.latestAuditHash || 'na';
      const linkHash = crypto.createHash('sha256').update(auditBind + pseudoCid + String(m.count)).digest('hex');
      pipeline.picoCrystalTuner.prevAuditHash = linkHash;
      pipeline.picoCrystalTuner.latestAuditHash = linkHash;
      pipeline.picoCrystalTuner.lastCid = pseudoCid;
      lastPersistenceAck = Date.now();
    } else if (m.type === 'PERSIST_ERR') {
      console.warn('[PersistWorker] Error:', m.error);
    }
  });
  const pipeline = new F2PoolAurreliaPipeline(user);
  const submitShare = (j, sh) => {
    pipeline.stratum.submit([
      pipeline.stratum.options.worker,
      j.jobId,
      sh.extranonce2Hex,
      sh.nTimeHex,
      sh.nonceHex
    ]);
  };
  const workerMeta = new Map(); // shardIndex -> { worker, lastHeartbeat, attempted:0, opp:0, hashes:0, lastFlush:0 }
  // Per-shard fused latency aggregation (true multi-worker histogram)
  const fusedAggLatencyBuckets = [5000,10000,20000,40000,80000];
  const aggPersistPath = process.env.AGG_HIST_PATH || 'fused-agg-hist.json';
  function loadAggHist(){ try { const fs=require('fs'); if (fs.existsSync(aggPersistPath)) return JSON.parse(fs.readFileSync(aggPersistPath,'utf8')); } catch(_){ } return null; }
  function saveAggHist(o){ try { require('fs').writeFileSync(aggPersistPath, JSON.stringify(o)); } catch(_){ } }
  const _loadedAgg = loadAggHist();
  const fusedAgg = { buckets: Object.fromEntries(fusedAggLatencyBuckets.map(b=>[b,0]).concat([["inf",0]])), count:0, total:0, sumSq:0 };
  if (_loadedAgg && _loadedAgg.buckets){ for (const k of Object.keys(fusedAgg.buckets)){ if (_loadedAgg.buckets[k]!=null) fusedAgg.buckets[k]=_loadedAgg.buckets[k]; } fusedAgg.count=_loadedAgg.count||0; fusedAgg.total=_loadedAgg.total||0; fusedAgg.sumSq=_loadedAgg.sumSq||0; }
  let fusedAggCv = _loadedAgg && _loadedAgg.latencyCv || 0;
  let eventHorizonTriggers = _loadedAgg && _loadedAgg.eventHorizonTriggers || 0;
  const workerHists = new Map(); // shardIndex -> { buckets, count, total, sumSq }
  let lastSlope = 0; let eventHorizonFlag = 0; let eventHorizonTs = 0; let prevNodeCount = 0;
  const slopeAlpha = parseFloat(process.env.THROUGHPUT_SLOPE_ALPHA || '0.25');
  // Optional reset (CLI: --reset-agg or env RESET_AGG=1)
  if (process.env.RESET_AGG === '1' || process.argv.includes('--reset-agg')){
    for (const k of Object.keys(fusedAgg.buckets)) fusedAgg.buckets[k]=0;
    fusedAgg.count=0; fusedAgg.total=0; fusedAgg.sumSq=0; fusedAggCv=0; eventHorizonTriggers=0;
    saveAggHist({ buckets: fusedAgg.buckets, count:0, total:0, sumSq:0, latencyCv:0, eventHorizonTriggers:0 });
    console.log('[Agg] Aggregated histogram & triggers reset');
  }

  function spawnOne(i){
  const w = new Worker('./worker-shard.js', { workerData: { shardIndex: i, workerCount: AUR_WORKERS } });
  workerMeta.set(i, { worker: w, lastHeartbeat: Date.now(), attempted:0, opp:0, hashes:0, lastFlush:0 });
  w.on('message', (m)=>{
    try {
      switch(m.type){
        case 'HEARTBEAT': {
          sharedFreq = (sharedFreq * 7 + m.sharedFreq) / 8;
          if (__HBUS_ENABLED) {
            sharedFreq = (sharedFreq * 0.9) + (__HBUS_SHARED_FREQ * 0.1);
          }
            if (HBUS_VOTING && __HBUS_LOCAL_ACCEPT > 0.05 && MULTI_HARMONIC && __HBUS_ASSIGNED_FREQ){
              sharedFreq = (sharedFreq * 0.8) + ((__HBUS_ASSIGNED_FREQ * 0.95) * 0.2);
            }
            rebalanceHarmonics();
            const meta = workerMeta.get(i); if (meta) meta.lastHeartbeat = Date.now();
          break; }
        case 'FUSED_STATS': {
          const ns = m.perHeaderNs || 0;
          if (ns > 0){
            let placed=false; for (const b of fusedAggLatencyBuckets){ if (ns<=b){ fusedAgg.buckets[b]++; placed=true; break; } }
            if (!placed) fusedAgg.buckets['inf']++;
            fusedAgg.count += m.count || 0;
            fusedAgg.total += m.totalNs || (ns * (m.count||1));
            fusedAgg.sumSq += (ns*ns) * (m.count||1);
            if (m.shardIndex!=null){
              let wh = workerHists.get(m.shardIndex);
              if (!wh){ wh = { buckets:Object.fromEntries(fusedAggLatencyBuckets.map(b=>[b,0]).concat([['inf',0]])), count:0, total:0, sumSq:0 }; workerHists.set(m.shardIndex, wh); }
              let pw=false; for (const b of fusedAggLatencyBuckets){ if (ns<=b){ wh.buckets[b]++; pw=true; break; } }
              if (!pw) wh.buckets['inf']++;
              const incrCount = m.count||0; const effNs = ns; const effTotal = m.totalNs || (effNs * (incrCount||1));
              wh.count += incrCount; wh.total += effTotal; wh.sumSq += (effNs*effNs) * (incrCount||1);
            }
            if (fusedAgg.count>0){ const mean = fusedAgg.total/fusedAgg.count; const varEst = Math.max(0,(fusedAgg.sumSq/fusedAgg.count)-mean*mean); fusedAggCv = mean>0? Math.sqrt(varEst)/mean:0; if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.fusedLatencyCv = Number(fusedAggCv.toFixed(6)); }
            if (global.__AUR_WASM_METRICS__){ global.__AUR_WASM_METRICS__.fusedLatencyBuckets = fusedAgg.buckets; global.__AUR_WASM_METRICS__.fusedLatencyCount = fusedAgg.count; global.__AUR_WASM_METRICS__.fusedLatencyTotalNs = fusedAgg.total; }
          }
          break; }
        case 'BATCH': {
          const meta = workerMeta.get(i);
          if (meta){
            meta.attempted += (m.attempted||0);
            meta.opp += (m.oppAttempts||0);
            meta.hashes += (m.hashes||0);
            meta.lastFlush = m.lastFlush || 0;
            if (m.gating){
              if (!meta.gating) meta.gating = { normAccept:0,normReject:0,symAccept:0,symReject:0,normAvg:0,normRejAvg:0,normThreshold:0 };
              meta.gating.normAccept = m.gating.normAccept;
              meta.gating.normReject = m.gating.normReject;
              meta.gating.symAccept = m.gating.symAccept;
              meta.gating.symReject = m.gating.symReject;
              meta.gating.normAvg = m.gating.normAvg;
              meta.gating.normRejAvg = m.gating.normRejAvg;
              meta.gating.normThreshold = m.gating.normThreshold;
            }
          }
          hashes += m.hashes; bytes += m.bytes; attempted += (m.attempted||0); oppAttempts += (m.oppAttempts||0); lastFlushTotal += (m.lastFlush||0);
          if (m.hashes && m.hashes > 0) lastHashProgressTs = Date.now();
          if (m.gating){
            if (!global.__AUR_COORD_GATING) global.__AUR_COORD_GATING = { normAccept:0,normReject:0,symAccept:0,symReject:0, norms:[] };
            global.__AUR_COORD_GATING.normAccept += m.gating.normAccept || 0;
            global.__AUR_COORD_GATING.normReject += m.gating.normReject || 0;
            global.__AUR_COORD_GATING.symAccept += m.gating.symAccept || 0;
            global.__AUR_COORD_GATING.symReject += m.gating.symReject || 0;
            if (m.gating.normAvg && m.gating.normAvg>0){ global.__AUR_COORD_GATING.norms.push(m.gating.normAvg); }
            if (m.gating.normRejAvg && m.gating.normRejAvg>0){ global.__AUR_COORD_GATING.norms.push(m.gating.normRejAvg); }
            while (global.__AUR_COORD_GATING.norms.length > NORM_RING_CAP) global.__AUR_COORD_GATING.norms.shift();
          }
          if (m.partitions){
            for (const k of Object.keys(m.partitions.attempts||{})) partitionStats.attempts[k] = (partitionStats.attempts[k]||0) + m.partitions.attempts[k];
            for (const k of Object.keys(m.partitions.accepts||{})) partitionStats.accepts[k] = (partitionStats.accepts[k]||0) + m.partitions.accepts[k];
          }
          if (currentJobSnapshot && m.shares && m.shares.length){
            m.shares.sort((a,b)=> a.extranonce2Hex.localeCompare(b.extranonce2Hex));
            for (const sh of m.shares){ submitShare(currentJobSnapshot, sh); shares++; }
            if (hashes>0){ __HBUS_LOCAL_ACCEPT = (__HBUS_LOCAL_ACCEPT*0.8) + ((shares/hashes)*0.2); }
          }
          if (hashes % 10000 < 1000){
            const elapsed = (Date.now() - pipeline.startTime)/1000;
            const ths = (hashes / elapsed / 1e12).toFixed(6);
            const throughput = (bytes / (elapsed||1)).toFixed(2);
            const eff = attempted? ((hashes/attempted)*100).toFixed(2): '0.00';
            const oppRate = oppAttempts? (oppAttempts/elapsed).toFixed(1): '0.0';
            const per = Array.from(workerMeta.entries()).map(([idx,mt])=>{
              if (!mt.gating) return `w${idx}:h=${mt.hashes} att=${mt.attempted} opp=${mt.opp} lf=${mt.lastFlush}`;
              const ga = mt.gating; const normAtt = ga.normAccept + ga.normReject; const normRate = normAtt? (ga.normAccept / normAtt *100).toFixed(1):'0.0';
              return `w${idx}:h=${mt.hashes} att=${mt.attempted} opp=${mt.opp} lf=${mt.lastFlush} normAcc=${normRate}% thr=${ga.normThreshold.toFixed(2)}`;
            }).join(' | ');
            console.log(`[MW] hashes=${hashes} attempted=${attempted} opp=${oppAttempts} eff=${eff}% oppRate=${oppRate}/s lastFlushSum=${lastFlushTotal} shares=${shares} ths=${ths} bytes/s=${throughput}\n       per-worker: ${per}`);
          }
          if (pipeline.telemetryEnabled && Date.now() - pipeline.lastTelemetry >= pipeline.telemetryIntervalMs){
            // Acceptance quantile sampling (ring buffer)
            if (!global.__AUR_ACCEPT_SAMPLES) global.__AUR_ACCEPT_SAMPLES = [];
            if (pipeline.shareStats && pipeline.shareStats.acceptanceRatio!=null){
              const r = pipeline.shareStats.acceptanceRatio;
              global.__AUR_ACCEPT_SAMPLES.push(r);
              const MAX_ACC_SAMPLES = 512;
              if (global.__AUR_ACCEPT_SAMPLES.length > MAX_ACC_SAMPLES) global.__AUR_ACCEPT_SAMPLES.splice(0, global.__AUR_ACCEPT_SAMPLES.length - MAX_ACC_SAMPLES);
            }
            // Compute quantiles if we have enough samples
            let p50=null,p90=null; const samp = global.__AUR_ACCEPT_SAMPLES || [];
            if (samp.length >= 20){
              const sorted = [...samp].sort((a,b)=>a-b);
              const q = (q)=>{ const pos = (sorted.length-1)*q; const lo=Math.floor(pos); const hi=Math.ceil(pos); if (hi===lo) return sorted[lo]; const w=pos-lo; return sorted[lo]*(1-w)+sorted[hi]*w; };
              p50 = q(0.5); p90 = q(0.9);
              global.__AUR_ACCEPT_Q = { p50, p90, n: sorted.length, ts: Date.now() };
            }
            if (global.__AUR_WASM_METRICS__) {
              global.__AUR_WASM_METRICS__.fusedLatencyBuckets = fusedAgg.buckets;
              global.__AUR_WASM_METRICS__.fusedLatencyCount = fusedAgg.count;
              global.__AUR_WASM_METRICS__.fusedLatencyTotalNs = fusedAgg.total;
              try {
                const bounds = fusedAggLatencyBuckets.slice();
                let total = 0; let weightSum = 0; let m2 = 0;
                for (const b of bounds){ const c = fusedAgg.buckets[b] || 0; if (!c) continue; total += c; const x = b; const delta = x - weightSum/ ( (total-c)||1); weightSum += x * c; m2 += c * delta * (x - (weightSum/total)); }
                const countEff = total; if (countEff>0){ const mean = weightSum / countEff; const variance = countEff>1 ? (m2 / countEff) : 0; const cv = mean>0 ? Math.sqrt(variance)/mean : 0; global.__AUR_WASM_METRICS__.fusedLatencyCv = Number(cv.toFixed(6)); }
              } catch(_){ }
              global.__AUR_WASM_METRICS__.fusedParityMismatchAnomalies = pipeline.parityMismatchAnomalyCount || 0;
              global.__AUR_WASM_METRICS__.fusedVarianceAnomalies = pipeline.varianceAnomalyCount || 0;
            }
            let slope = 0; const baseT = pipeline.startTime; const dtSec = (Date.now()-baseT)/1000;
            if (!pipeline._thrSeries) pipeline._thrSeries=[]; pipeline._thrSeries.push({ t: Date.now(), bytes }); while (pipeline._thrSeries.length>50) pipeline._thrSeries.shift();
            if (pipeline._thrSeries.length>=6){ const xs=[]; const ys=[]; const t0=pipeline._thrSeries[0].t; for (const s of pipeline._thrSeries){ xs.push((s.t-t0)/1000); ys.push(s.bytes);} const n=xs.length; const sumX=xs.reduce((a,b)=>a+b,0); const sumY=ys.reduce((a,b)=>a+b,0); const sumXY=xs.reduce((a,b,i)=>a + b*ys[i],0); const sumX2=xs.reduce((a,b)=>a + b*b,0); const denom=(n*sumX2 - sumX*sumX)||1; slope=(n*sumXY - sumX*sumY)/denom; }
            slope = isFinite(slope)? (lastSlope===0? slope : lastSlope*(1-slopeAlpha)+slope*slopeAlpha): lastSlope;
            const nodeGrowthRate = (nodeCount - prevNodeCount)/(dtSec||1);
            if (lastSlope < 0 && slope > 0 && nodeGrowthRate > 0){ eventHorizonFlag = 1; eventHorizonTs = Date.now(); eventHorizonTriggers++; }
            if (eventHorizonFlag && Date.now() - eventHorizonTs > 60000) eventHorizonFlag = 0;
            lastSlope = slope; prevNodeCount = nodeCount;
            const elapsedAll = (Date.now()-pipeline.startTime)/1000;
            const attemptRate = attempted && elapsedAll>0 ? attempted/elapsedAll : 0;
            const hashEff = attempted? (hashes/attempted): 0;
            const effDerivative = attemptRate? hashEff*attemptRate : 0;
            const now = Date.now();
            if (!stallFusedDisabled && (now - lastHashProgressTs) > STALL_HASH_WINDOW_MS && attempted > STALL_ATTEMPT_DELTA){
              stallFusedDisabled = true; watchdogFusedDisableCount++; console.warn('[Watchdog] Hash stall detected -> disabling fused path & tightening modulus');
              for (const w of workers) w.postMessage({ type:'FUSED_MODE', enabled:false });
              dynamicModulus = Math.max(2, Math.floor(dynamicModulus/2));
              dynamicFlushMs = Math.max(20, Math.floor(dynamicFlushMs*0.75));
              for (const w of workers) w.postMessage({ type:'TUNE_WORKER', modulus: dynamicModulus, flushMs: dynamicFlushMs });
            }
            if (stallFusedDisabled && (now - lastHashProgressTs) <= STALL_HASH_WINDOW_MS/2){
              console.log('[Watchdog] Hash flow restored -> re-enabling fused path'); stallFusedDisabled = false; for (const w of workers) w.postMessage({ type:'FUSED_MODE', enabled:true });
            }
            if (now - lastTuneTs > TUNE_INTERVAL_MS){
              lastTuneTs = now; const avgFlush = (lastFlushTotal && attempted) ? (lastFlushTotal / Math.max(1, (attempted))) : 0;
              if (attempted && lastFlushTotal < attempted*0.2){ dynamicModulus = Math.max(2, dynamicModulus-1); } else if (lastFlushTotal > attempted*0.8){ dynamicModulus = Math.min(50, dynamicModulus+1); }
              if (lastFlushTotal === 0) { dynamicFlushMs = Math.max(20, dynamicFlushMs - 10); } else if (avgFlush > 0.6){ dynamicFlushMs = Math.min(500, dynamicFlushMs + 20); }
              for (const w of workers) w.postMessage({ type:'TUNE_WORKER', modulus: dynamicModulus, flushMs: dynamicFlushMs });
              lastFlushTotal = 0;
            }
            if (global.__AUR_COORD_GATING && (now - lastGuidanceTs) >= GUIDANCE_INTERVAL_MS){
              const g = global.__AUR_COORD_GATING; const tot = g.normAccept + g.normReject; if (tot > 50){ /* percentile guidance placeholder */ }
              lastGuidanceTs = now;
            }
            // Adaptive modulation using latency backoff & acceptance quantiles
            try {
              const latF = global.__AUR_LAT_BACKOFF?.factor || 1;
              // Base modulus derived from dynamicModulus then scaled by latency factor (>1 => slow down / increase modulus)
              let effMod = Math.max(2, Math.round(dynamicModulus * latF));
              let p99 = null;
              if (samp.length >= 50){
                const sorted99 = [...samp].sort((a,b)=>a-b);
                const idx99 = Math.min(sorted99.length-1, Math.floor(0.99*(sorted99.length-1)));
                p99 = sorted99[idx99];
                if (global.__AUR_ACCEPT_Q) global.__AUR_ACCEPT_Q.p99 = p99; else global.__AUR_ACCEPT_Q = { p99 };
              }
              if (p50!=null && p90!=null){
                const target = parseFloat(process.env.ACCEPT_TARGET || '0.0005');
                const high = parseFloat(process.env.ACCEPT_HIGH || (target*2).toString());
                // If upper tail (p90) still below target, we are under-submitting effective candidates -> decrease modulus (speed up)
                if (p90 < target*0.75) effMod = Math.max(2, effMod - 1);
                // If median already well above high threshold, we can relax (increase modulus) to reduce overhead
                else if (p50 > high) effMod = Math.min(80, effMod + 1);
              }
              // Only broadcast if changed meaningfully vs current dynamicModulus to avoid churn
              if (effMod !== dynamicModulus){
                dynamicModulus = effMod;
                for (const w of workers) w.postMessage({ type:'TUNE_WORKER', modulus: dynamicModulus, flushMs: dynamicFlushMs });
                if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.adaptiveModulus = dynamicModulus;
              }
              // Gating regression / recovery using p90
              if (p90!=null){
                const normBase = parseFloat(process.env.NORM_THRESHOLD_BASE || '2.50');
                const regressFactor = parseFloat(process.env.NORM_REGRESS_FACTOR || '0.90'); // 10% reduction when too hot
                const highBand = parseFloat(process.env.ACCEPT_HIGH || '0.001');
                const overBand = parseFloat(process.env.ACCEPT_P90_BAND || (highBand*1.5).toString());
                const recoverRate = parseFloat(process.env.NORM_RECOVER_RATE || '0.02'); // 2% upward creep per eval
                if (p90 > overBand){
                  globalNormThreshold = globalNormThreshold * regressFactor;
                  if (globalNormThreshold < 0.1) globalNormThreshold = 0.1; // floor
                  global.__AUR_NORM_THRESHOLD = globalNormThreshold;
                  if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.normThreshold = Number(globalNormThreshold.toFixed(4));
                  if (process.env.GATING_LOG==='1') console.log('[GATING] p90=',p90.toExponential(3),'regress normThreshold ->',globalNormThreshold.toFixed(3));
                } else if (p90 < highBand*0.6 && globalNormThreshold < normBase){
                  // gentle recovery towards base if tail pressure low
                  globalNormThreshold = Math.min(normBase, globalNormThreshold * (1+recoverRate));
                  global.__AUR_NORM_THRESHOLD = globalNormThreshold;
                  if (global.__AUR_WASM_METRICS__) global.__AUR_WASM_METRICS__.normThreshold = Number(globalNormThreshold.toFixed(4));
                }
                // Broadcast updated normThreshold to workers only when changed
                if (lastBroadcastNormThreshold == null || Math.abs(globalNormThreshold - lastBroadcastNormThreshold) > 0.001){
                  lastBroadcastNormThreshold = globalNormThreshold;
                  for (const w of workers) w.postMessage({ type:'NORM_THRESHOLD', value: globalNormThreshold });
                }
              }
              // Persist adaptive parameters periodically
              if (Date.now() - lastPersistAdaptiveTs > 60000){
                lastPersistAdaptiveTs = Date.now();
                try { const st = loadAdaptiveState(); st.globalNormThreshold = global.__AUR_NORM_THRESHOLD; st.latBackoffFactor = global.__AUR_LAT_BACKOFF ? global.__AUR_LAT_BACKOFF.factor : 1; saveAdaptiveState(st); } catch(_){ }
              }
              if (process.env.ECON_AUTOSWITCH==='1') maybeAutoEconomicSwitch(pipeline);
              if (process.env.ACCEPT_ALERT_LOG==='1' && p99!=null && p90!=null && p99 > p90*4){ console.warn('[ACCEPT][Alert] p99 tail', p99.toExponential(3),'>> p90', p90.toExponential(3)); }
            } catch(_e) {}
          }
          break; }
      }
    } catch(e){ console.error('[WorkerMsg][Error]', e.message); }
  });
    w.on('exit', (code)=>{
      console.warn(`[Worker] shard ${i} exited code=${code}`);
      // respawn if active job and health monitor still expects it
  if (AUR_WORKERS > 1 && pipeline.job) {
        console.log('[Worker] respawning shard', i);
        spawnOne(i);
      }
    });
    workers[i] = w;
  }

  function spawnWorkers(){
    for (let i=0;i<AUR_WORKERS;i++){
      spawnOne(i);
    }
  }
  // Override pipeline.mine to only update seeds + broadcast job snapshot
  pipeline.mine = function multiMine(){
    if (!this.job || !this.extranonce1) return setTimeout(()=>this.mine(), 1000);
    this.cycleCount++;
    // Rebuild plane seeds every 10 cycles (reuse existing logic partially)
    if (!planeSeedsCache || this.cycleCount % 10 === 0){
      const coinbaseTx = buildCoinbase(this.job.coinb1, this.extranonce1, '00'.padStart(this.extranonce2Size*2,'0'), this.job.coinb2);
      // Define missing variables for deterministic plane input construction
      const extranonce2Hex = '00'.padStart(this.extranonce2Size*2,'0');
      const nTimeHex = this.job.ntime; // could apply controlled drift if needed
      const planeInput = (coinbaseTx.slice(0,256) + extranonce2Hex + nTimeHex).slice(0,512);
      if (this.romanWheels.length === 0){
        const seedHex = crypto.createHash('sha256').update(this.extranonce1 + this.job.jobId).digest('hex');
        const segs = [0,8,16,24].map(o=> parseInt(seedHex.slice(o,o+8),16));
        const mkWheel = (plane,idx)=> new RomanDecoderWheel(plane, 432 + ((segs[idx]%33)-16), 560 + (segs[idx]%120));
        this.romanWheels = ['xy','xz','yz','w4d'].map((p,i)=>mkWheel(p,i));
      }
      const decoded = this.romanWheels.map(w=> w.decodeData(planeInput));
      planeSeedsCache = decoded.map(p=> (p && p.length ? p : planeInput).slice(0,64).padEnd(64,'0'));
      let planeWeights = null;
      if (PLANE_AGG_MODE === 'avg' && PLANE_WEIGHTED && planeSeedsCache.length){
        const lens = decoded.map(p=> (p && p.length ? p.length: planeInput.length));
        const maxL = Math.max(...lens);
        planeWeights = planeSeedsCache.map((s,idx)=>{
          const uniq = new Set(s.split('')).size;
          const w = (uniq/16) * (lens[idx]/(maxL||1));
          return w || 0.0001;
        });
        const totalW = planeWeights.reduce((a,b)=>a+b,0);
        if (totalW>0) for (let i=0;i<planeWeights.length;i++) planeWeights[i]/=totalW;
      }
      const aggregate = (()=>{
        if (!planeSeedsCache.length) return planeInput.slice(0,64);
        const nib = planeSeedsCache.map(s=> s.split(''));
        const out = [];
        for (let i=0;i<64;i++){
          if (PLANE_AGG_MODE === 'avg'){
            if (planeWeights){
              let accW=0; for (let p=0;p<nib.length;p++){ accW += planeWeights[p]* parseInt(nib[p][i],16); }
              out.push((Math.floor(accW) & 0xF).toString(16));
            } else {
              let sum=0; for (const a of nib) sum += parseInt(a[i],16);
              out.push((Math.floor(sum / nib.length) & 0xF).toString(16));
            }
          } else {
            let acc=0; for (const a of nib) acc ^= parseInt(a[i],16); out.push(acc.toString(16));
          }
        }
        return out.join('');
      })();
      romanSeedCache = aggregate;
      // Bind hash uses latest audit state
      const auditBind = this.picoCrystalTuner.latestAuditHash || 'na';
      const cidBind = this.picoCrystalTuner.lastCid || 'nocid';
      bindHash = crypto.createHash('sha256').update(auditBind + cidBind).digest('hex').slice(0,16);
      currentJobSnapshot = { jobId: this.job.jobId, version: this.job.version, prevhash: this.job.prevhash, coinb1: this.job.coinb1, coinb2: this.job.coinb2, merkle_branch: this.job.merkle_branch || [], nbits: this.job.nbits, ntime: this.job.ntime, extranonce2Size: this.extranonce2Size };
      for (const w of workers){
        w.postMessage({ type:'JOB', job: currentJobSnapshot, planeSeeds: planeSeedsCache, romanSeed: romanSeedCache, bindHash, extranonce1: this.extranonce1, sharedFreq });
      }
    }
    if (Date.now() - lastMeshPulse >= MESH_PULSE_INTERVAL){
      for (const w of workers) w.postMessage({ type:'MESH_FREQ', freq: sharedFreq });
      lastMeshPulse = Date.now();
    }
    // Publish to inter-process harmonic bus (multi-worker mode uses global sharedFreq)
    hbusPublish(sharedFreq);
    if (__HBUS_ASSIGNED_FREQ && MULTI_HARMONIC){
      // Light bias toward assigned harmonic distinct across cluster
      sharedFreq = (sharedFreq*0.85) + (__HBUS_ASSIGNED_FREQ*0.15);
    }
    // Async crystal offload (non-blocking)
    if (ENABLE_ASYNC_PERSISTENCE && this.picoCrystalTuner.crystals.length >= this.picoCrystalTuner.unloadThreshold) {
      const batch = this.picoCrystalTuner.crystals.map(c => c.coeffs);
      this.picoCrystalTuner.crystals = [];
      persistenceWorker.postMessage({ type:'CRYSTALS_BATCH', batch, backends: { ipfs: this.picoCrystalTuner.ipfsEnabled, filecoin: this.picoCrystalTuner.filecoinEnabled, arweave: !!arweave }, opts: { ipfsEndpoint: this.picoCrystalTuner.ipfsEndpoint } });
    }
    // D. Health monitor: check worker heartbeats
    const nowT = Date.now();
    for (const [idx, meta] of workerMeta.entries()){
      if (nowT - meta.lastHeartbeat > WORKER_HEALTH_TIMEOUT){
        console.warn('[Health] Worker shard', idx, 'timed out. Respawning.');
        try { meta.worker.terminate(); } catch(_){ }
        spawnOne(idx);
      }
    }
    setTimeout(()=>this.mine(), 50); // coordinator tick
  };
  // Apply loaded adaptive state to pipeline fused settings (single authoritative pipeline object)
  if (loadedState && Object.keys(loadedState).length){
    if (loadedState.fusedParityInterval) pipeline.fusedParityInterval = loadedState.fusedParityInterval;
    if (loadedState.currentBatchSize) pipeline.currentBatchSize = loadedState.currentBatchSize;
    if (loadedState.rampLatencySamples && Array.isArray(loadedState.rampLatencySamples)) pipeline.rampLatencySamples = loadedState.rampLatencySamples.slice(-pipeline.rampLatencyWindow);
    if (process.env.SOLO_POOL_CYCLE === '1' && typeof loadedState.soloPoolIndex === 'number'){
      soloCycleIndex = loadedState.soloPoolIndex % SOLO_POOLS_SEQUENCE.length;
      console.log('[SoloRotate] Restored soloPoolIndex', soloCycleIndex, 'coin', SOLO_POOLS_SEQUENCE[soloCycleIndex]);
    }
    if (process.env.SOLO_POOL_CYCLE === '1' && Array.isArray(loadedState.soloPoolBackoff)){
      SOLO_POOL_BACKOFF.clear();
      for (const [k,v] of loadedState.soloPoolBackoff){ SOLO_POOL_BACKOFF.set(k,v); }
      console.log('[SoloRotate] Restored backoff map entries', SOLO_POOL_BACKOFF.size);
    }
    if (process.env.SOLO_POOL_CYCLE === '1' && loadedState.soloPoolMode){
      process.env.SOLO_POOL_MODE = loadedState.soloPoolMode; // maintain mode if not explicitly overridden
      console.log('[SoloRotate] Restored mode', process.env.SOLO_POOL_MODE);
    }
    if (loadedState.lastRotationReason){ global.__AUR_LAST_ROTATION_REASON__ = loadedState.lastRotationReason; }
    if (loadedState.jobIntervalBuckets && Array.isArray(loadedState.jobIntervalBuckets)){
      global.__AUR_JOB_INT_BUCKETS__ = loadedState.jobIntervalBuckets;
      console.log('[SoloPool][AdaptiveBuckets] Restored bucket list', global.__AUR_JOB_INT_BUCKETS__.join(','));
    }
    if (global.__AUR_WASM_METRICS__){
      global.__AUR_WASM_METRICS__.currentBatchSize = pipeline.currentBatchSize;
      global.__AUR_WASM_METRICS__.fusedParityInterval = pipeline.fusedParityInterval;
    }
  }
  spawnWorkers();
  pipeline.start();
  // Adaptive inward-growth burrow depth optimizer (focus on early prune ratio)
  const BASE_BURROW_DEPTH = GLOBAL_BURROW_DEPTH;
  pipeline.burrowAdapt = {
    enabled: process.env.BURROW_ADAPT === '1',
    base: BASE_BURROW_DEPTH,
    current: BASE_BURROW_DEPTH,
    min: parseInt(process.env.MIN_BURROW_DEPTH || '3',10),
    window: parseInt(process.env.BURROW_ADAPT_WINDOW || '512',10),
    hiRatio: parseFloat(process.env.BURROW_ADAPT_EARLY_RATIO_HIGH || '0.75'),
    loRatio: parseFloat(process.env.BURROW_ADAPT_EARLY_RATIO_LOW || '0.35'),
    earlyPrunes: 0,
    verifies: 0
  };
  // Persist share efficiency snapshot every 30s (deterministic overwrite)
  setInterval(()=>{
    try {
      const snap = {
        t: Date.now(),
        accepted: pipeline.shareStats.accepted,
        rejected: pipeline.shareStats.rejected,
        acceptanceRatio: pipeline.shareStats.acceptanceRatio,
        emaSharesPerMin: pipeline.shareStats.emaSharesPerMin,
        instSharesPerMin: pipeline.shareStats.sharesPerMin,
        hashes: pipeline.stats.hashes,
        shares: pipeline.stats.shares,
        ths: pipeline.stats.ths,
        recommend: ECON.state ? ECON.state.recommend : null
      };
      require('fs').writeFileSync(process.env.SHARE_EFF_PATH || 'share-efficiency.json', JSON.stringify(snap,null,2));
    } catch(e){ /* ignore */ }
  }, parseInt(process.env.SHARE_EFF_INTERVAL_MS || '30000',10)).unref();
  // Periodically persist adaptive state
  setInterval(()=>{
    const state = {
      fusedParityInterval: pipeline.fusedParityInterval,
      currentBatchSize: pipeline.currentBatchSize,
      fusedRampActive: pipeline.fusedRampActive,
      fusedRampTarget: pipeline.fusedRampTarget,
        rampLatencySamples: pipeline.rampLatencySamples,
        soloPoolIndex: (process.env.SOLO_POOL_CYCLE === '1') ? soloCycleIndex : undefined
        ,soloPoolBackoff: (process.env.SOLO_POOL_CYCLE === '1') ? Array.from(SOLO_POOL_BACKOFF.entries()) : undefined
        ,soloPoolMode: process.env.SOLO_POOL_MODE || 'sequence'
        ,lastRotationReason: global.__AUR_LAST_ROTATION_REASON__ || null
        ,jobIntervalBuckets: global.__AUR_JOB_INT_BUCKETS__ || null
    };
    saveAdaptiveState(state);
  }, parseInt(process.env.ADAP_STATE_PERSIST_MS || '15000',10));

  // Latency-based dynamic controller backoff (adjust internal pacing factor)
  if (!global.__AUR_LAT_BACKOFF){
    global.__AUR_LAT_BACKOFF = { factor:1, lastAdj:0 };
  }
  const LAT_BACKOFF_MIN = parseFloat(process.env.LAT_BACKOFF_MIN || '0.5');
  const LAT_BACKOFF_MAX = parseFloat(process.env.LAT_BACKOFF_MAX || '2.5');
  const LAT_TARGET_MS = parseFloat(process.env.LAT_TARGET_MS || '250'); // target fused batch latency
  const LAT_ADJ_INTERVAL_MS = parseInt(process.env.LAT_ADJ_INTERVAL_MS || '15000',10);
  setInterval(()=>{
    try {
      // Use pipeline.fusedLastLatency if present or rolling estimate
      const lat = pipeline.fusedLastLatencyMs || pipeline._lastFusedLatencyMs || null;
      if (lat == null) return;
      const ratio = lat / LAT_TARGET_MS; // >1 means slower than target
      const accept = pipeline.shareStats ? pipeline.shareStats.acceptanceRatio || 0 : 0;
      let f = global.__AUR_LAT_BACKOFF.factor;
      // If latency high AND acceptance not suffering, raise backoff to reduce pressure
      if (ratio > 1.2){ f *= 1.05; }
      else if (ratio < 0.8){ f *= 0.95; }
      // Acceptance safeguard: if acceptance drops under 0.05 reduce backoff (speed up) to seek shares
      if (accept < 0.05){ f *= 0.9; }
      if (f < LAT_BACKOFF_MIN) f = LAT_BACKOFF_MIN; if (f > LAT_BACKOFF_MAX) f = LAT_BACKOFF_MAX;
      if (Math.abs(f - global.__AUR_LAT_BACKOFF.factor) > 0.02){
        global.__AUR_LAT_BACKOFF.factor = f;
        if (process.env.LAT_BACKOFF_LOG==='1') console.log('[LatencyBackoff] factor ->', f.toFixed(3), 'latMs=', lat.toFixed(1),'accept=',accept.toFixed(3));
      }
    } catch(e){ /* ignore */ }
  }, LAT_ADJ_INTERVAL_MS).unref();
  // Acceptance sample persistence
  const ACCEPT_SAMPLES_PATH = process.env.ACCEPT_SAMPLES_PATH || 'accept-samples.json';
  if (!global.__AUR_ACCEPT_SAMPLES){
    try { const fs=require('fs'); if (fs.existsSync(ACCEPT_SAMPLES_PATH)){ const arr=JSON.parse(fs.readFileSync(ACCEPT_SAMPLES_PATH,'utf8')); if (Array.isArray(arr)) global.__AUR_ACCEPT_SAMPLES = arr.slice(-512); } } catch(e){ /* ignore */ }
  }
  function persistAcceptSamples(){
    try { if (global.__AUR_ACCEPT_SAMPLES && global.__AUR_ACCEPT_SAMPLES.length){ require('fs').writeFileSync(ACCEPT_SAMPLES_PATH, JSON.stringify(global.__AUR_ACCEPT_SAMPLES.slice(-512))); } } catch(_){ }
  }
  const ACCEPT_PERSIST_MS = parseInt(process.env.ACCEPT_PERSIST_MS || '30000',10);
  setInterval(persistAcceptSamples, ACCEPT_PERSIST_MS).unref();
  // Lightweight HTTP self-check endpoint
  if (process.env.SELF_CHECK_HTTP === '1'){
    const http = require('http');
    // Prometheus metrics registry (lazy to avoid dep if unused)
    let prom = null; let registry = null; let gauges = {};
    function initProm(){
      if (prom) return;
      try {
        prom = require('prom-client');
        registry = new prom.Registry();
        global.__AUR_METRICS_REG__ = { registry, gauges };
        prom.collectDefaultMetrics({ register: registry, prefix: 'aurrelia_' });
        gauges.batchSize = new prom.Gauge({ name:'aurrelia_wasm_batch_size', help:'Current WASM dynamic batch size' });
        gauges.emaLatency = new prom.Gauge({ name:'aurrelia_wasm_ema_latency_ms', help:'EMA latency ms for fused batch' });
        gauges.sharesAccepted = new prom.Counter({ name:'aurrelia_shares_accepted_total', help:'Accepted shares total' });
        gauges.sharesRejected = new prom.Counter({ name:'aurrelia_shares_rejected_total', help:'Rejected shares total' });
        gauges.acceptanceRatio = new prom.Gauge({ name:'aurrelia_share_acceptance_ratio', help:'Sliding window acceptance ratio' });
  // New: acceptance ratio distribution histogram for gating/quantiles
  gauges.acceptanceHist = new prom.Histogram({ name:'aurrelia_share_accept_ratio_hist', help:'Histogram of share acceptance ratio window samples', buckets:[0.0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.6,0.7,0.8,0.9,1.0] });
    // Quantile gauges (p50 / p90 of acceptance)
  gauges.acceptP50 = new prom.Gauge({ name:'adaptive_acceptance_p50', help:'p50 (median) acceptance ratio' });
  gauges.acceptP90 = new prom.Gauge({ name:'adaptive_acceptance_p90', help:'p90 acceptance ratio' });
  gauges.acceptP99 = new prom.Gauge({ name:'adaptive_acceptance_p99', help:'p99 acceptance ratio (tail)' });
  gauges.normThreshold = new prom.Gauge({ name:'adaptive_norm_threshold', help:'Current global norm gating threshold' });
        gauges.emaSharesPerMin = new prom.Gauge({ name:'aurrelia_ema_shares_per_min', help:'EMA of shares per minute' });
        gauges.hashes = new prom.Counter({ name:'aurrelia_hashes_total', help:'Total header hashes attempted' });
        gauges.ths = new prom.Gauge({ name:'aurrelia_hashrate_ths', help:'Current approximate TH/s' });
  gauges.nodeGrowthAttempts = new prom.Counter({ name:'aurrelia_node_growth_attempts_total', help:'Total node growth attempts' });
  gauges.nodeGrowthKept = new prom.Counter({ name:'aurrelia_node_growth_kept_total', help:'Node growth kept (improved hashrate)' });
  gauges.nodeGrowthReverted = new prom.Counter({ name:'aurrelia_node_growth_reverted_total', help:'Node growth reverted (no improvement)' });
  gauges.nodeGrowthPending = new prom.Gauge({ name:'aurrelia_node_growth_pending', help:'Pending node growth evaluations' });
  gauges.econScore = new prom.Gauge({ name:'aurrelia_econ_btcrvn_ratio', help:'Relative BTC vs RVN score ratio (btcScore/rvnScore)' });
  gauges.recommend = new prom.Gauge({ name:'aurrelia_econ_recommend', help:'Recommended coin (btc=0, rvn=1, other=2)' });
  gauges.burrowDepth = new prom.Gauge({ name:'aurrelia_burrow_depth_current', help:'Current adaptive burrow depth' });
  gauges.rulePrune = new prom.Counter({ name:'aurrelia_rule_prune_total', help:'Total prune_8x rule actions' });
  gauges.ruleSpawn = new prom.Counter({ name:'aurrelia_rule_spawn_total', help:'Total spawn_8x rule actions' });
  gauges.rashbaGain = new prom.Gauge({ name:'aurrelia_rashba_gain_current', help:'Current adaptive Rashba gain factor' });
  gauges.isheEff = new prom.Gauge({ name:'aurrelia_ishe_eff', help:'Configured ISHE efficiency factor' });
  gauges.spinGap = new prom.Gauge({ name:'aurrelia_spin_gap_p90_p50', help:'Spin power gap (p90 - p50)' });
  gauges.hypercubeBlend = new prom.Gauge({ name:'aurrelia_hypercube_blend', help:'Hypercube blend factor' });
  gauges.rashbaTargetGap = new prom.Gauge({ name:'aurrelia_rashba_target_gap', help:'Adaptive Rashba target gap' });
  gauges.rashbaGapRatio = new prom.Gauge({ name:'aurrelia_rashba_gap_ratio', help:'Observed gap / target gap ratio' });
  // Geometry / spin extension gauges
  gauges.spinPower = new prom.Gauge({ name:'aurrelia_spin_power', help:'Derived spin/icosa variance power metric' });
  gauges.spinPowerHist = new prom.Histogram({ name:'aurrelia_spin_power_hist', help:'Histogram of spin power metric', buckets:[0.0001,0.001,0.01,0.05,0.1,0.2,0.5,1,2,5] });
  gauges.nodeCount = new prom.Gauge({ name:'aurrelia_node_count', help:'Active lattice node count' });
  gauges.geomUtil = new prom.Gauge({ name:'aurrelia_geom_utilization', help:'Geometry utilization (0..1)' });
  gauges.geomCapacity = new prom.Gauge({ name:'aurrelia_geom_capacity', help:'Geometric capacity estimate' });
  gauges.geomNodesMax = new prom.Gauge({ name:'aurrelia_geom_nodes_max', help:'Configured max nodes (growth cap)' });
  gauges.hypercubeSubset = new prom.Gauge({ name:'aurrelia_hypercube_subset_idx', help:'Hypercube active subset index' });
  gauges.hypercubeSliceSize = new prom.Gauge({ name:'aurrelia_hypercube_slice_size', help:'Hypercube active slice size' });
  gauges.chernProxy = new prom.Gauge({ name:'aurrelia_chern_proxy', help:'Topology proxy (sign change density across slice)' });
  gauges.mlLatency = new prom.Gauge({ name:'aurrelia_ml_latency_ms', help:'Latest ML inference latency (ms)' });
  gauges.mlLatencyHist = new prom.Histogram({ name:'aurrelia_ml_latency_hist_ms', help:'Histogram of ML inference latency (ms)', buckets:[10,25,50,75,100,150,250,400,600,800,1000,1500,2000] });
  gauges.mlLatencyP50 = new prom.Gauge({ name:'aurrelia_ml_latency_p50_ms', help:'ML latency 50th percentile (ms)' });
  gauges.mlLatencyP90 = new prom.Gauge({ name:'aurrelia_ml_latency_p90_ms', help:'ML latency 90th percentile (ms)' });
  gauges.mlLatencyP99 = new prom.Gauge({ name:'aurrelia_ml_latency_p99_ms', help:'ML latency 99th percentile (ms)' });
  gauges.mlModelVersion = new prom.Gauge({ name:'aurrelia_ml_model_version', help:'Numeric ML model version' });
  gauges.agentInvocations = new prom.Counter({ name:'aurrelia_agent_invocations_total', help:'Total external agent (LLM) invocation attempts' });
  gauges.agentModelSig = new prom.Gauge({ name:'aurrelia_agent_model_sig', help:'SHA256 signature (truncated) of agent model or deterministic stub digest' });
  gauges.mlModelSignature = new prom.Gauge({ name:'aurrelia_ml_model_signature', help:'Numeric shard of ML model signature (truncated SHA256)' });
  // Swap / balance extension gauges
  gauges.balanceRVN = new prom.Gauge({ name:'aurrelia_balance_rvn', help:'Approximate RVN balance (credited)' });
  gauges.balanceBTC = new prom.Gauge({ name:'aurrelia_balance_btc', help:'Approximate BTC balance (credited)' });
  gauges.balanceFREN = new prom.Gauge({ name:'aurrelia_balance_fren', help:'Approximate FREN balance (credited)' });
  gauges.balanceKAS = new prom.Gauge({ name:'aurrelia_balance_kas', help:'Approximate KAS balance (credited)' });
  // Companion suggestion / advisory gauges
  gauges.companionTopConfidence = new prom.Gauge({ name:'aurrelia_companion_top_confidence', help:'Top companion suggestion confidence (0..1)' });
  gauges.companionSuggestionCount = new prom.Gauge({ name:'aurrelia_companion_suggestion_count', help:'Suggestion count emitted in last companion cycle' });
  gauges.swapExecTotal = new prom.Counter({ name:'aurrelia_swap_exec_total', help:'Total swap executions', labelNames:['from','to','mode'] });
  gauges.swapExecSettled = new prom.Counter({ name:'aurrelia_swap_exec_settled_total', help:'Total settled swap executions', labelNames:['from','to','mode'] });
  gauges.swapExecFailed = new prom.Counter({ name:'aurrelia_swap_exec_failed_total', help:'Total failed swap executions', labelNames:['from','to','reason'] });
  gauges.rvnCreditTotal = new prom.Counter({ name:'aurrelia_rvn_credit_total', help:'Total RVN credit units' });
  gauges.rvnCreditShares = new prom.Counter({ name:'aurrelia_rvn_credit_shares_total', help:'Total shares counted for RVN credit' });
  gauges.rvnCreditLast = new prom.Gauge({ name:'aurrelia_rvn_credit_last', help:'Last RVN credit increment' });
  // Economic autoswitch metrics
  gauges.econSwitchTotal = new prom.Counter({ name:'aurrelia_econ_switch_total', help:'Total economic coin switches', labelNames:['from_coin','to_coin','reason'] });
  gauges.econSwitchFail = new prom.Counter({ name:'aurrelia_econ_switch_fail_total', help:'Failed economic coin switches', labelNames:['from_coin','to_coin','reason'] });
  gauges.econActive = new prom.Gauge({ name:'aurrelia_econ_active_coin', help:'Active coin numeric code', labelNames:['coin'] });
  gauges.econCooldown = new prom.Gauge({ name:'aurrelia_econ_switch_cooldown_seconds', help:'Remaining cooldown seconds for autoswitch readiness' });
  gauges.econRollback = new prom.Counter({ name:'aurrelia_econ_rollback_total', help:'Total economic rollbacks due to acceptance degradation', labelNames:['from_coin','to_coin'] });
  gauges.econAcceptDelta = new prom.Gauge({ name:'aurrelia_econ_acceptance_delta', help:'Acceptance delta since last economic switch (positive=improved)', labelNames:['from_coin','to_coin','reason'] });
  // Solo pool rotation metrics
  gauges.soloPoolActiveIndex = new prom.Gauge({ name:'aurrelia_solo_pool_active_index', help:'Current index into deterministic solo pool sequence' });
  gauges.soloPoolRotations = new prom.Counter({ name:'aurrelia_solo_pool_rotations_total', help:'Total solo pool rotations performed' });
  gauges.soloPoolRotationsLabeled = new prom.Counter({ name:'aurrelia_solo_pool_rotations_labeled_total', help:'Solo pool rotations labeled by reason', labelNames:['reason','pool'] });
  gauges.soloPoolAcceptanceRatio = new prom.Gauge({ name:'aurrelia_solo_pool_acceptance_ratio', help:'Acceptance ratio for currently active solo pool' });
  gauges.soloPoolSpinWeightedScore = new prom.Gauge({ name:'aurrelia_solo_pool_spin_weighted_score', help:'Spin-weighted score for current solo pool (acceptance + intervalFactor*spinGapRatio)' });
  gauges.soloPoolAvgJobIntervalHist = new prom.Histogram({ name:'aurrelia_solo_pool_avg_job_interval_ms', help:'Histogram of avg job interval ms for active pool', buckets:[1000,5000,15000,30000,60000,120000,300000,600000] });
  // Labeled per-pool metrics
  gauges.soloPoolAcceptanceLabeled = new prom.Gauge({ name:'aurrelia_solo_pool_acceptance_ratio_labeled', help:'Per-pool acceptance ratio', labelNames:['pool'] });
  gauges.soloPoolConfidenceLabeled = new prom.Gauge({ name:'aurrelia_solo_pool_confidence', help:'Per-pool confidence score (1/(1+cv))', labelNames:['pool'] });
  gauges.soloPoolJobIntervalLabeled = new prom.Histogram({ name:'aurrelia_solo_pool_job_interval_ms', help:'Per-pool job interval distribution (ms)', labelNames:['pool'], buckets:[500,1000,2000,5000,10000,20000,30000,60000,120000,300000,600000] });
  gauges.soloPoolBucketMax = new prom.Gauge({ name:'aurrelia_solo_pool_job_interval_bucket_max_ms', help:'Current max bucket upper bound for job interval histogram' });
  gauges.soloPoolBucketExpansions = new prom.Counter({ name:'aurrelia_solo_pool_job_interval_bucket_expansions_total', help:'Times interval buckets expanded' });
  // Per-pool rotation reason metrics
  gauges.soloPoolLastRotationAge = new prom.Gauge({ name:'aurrelia_solo_pool_last_rotation_age_ms', help:'Age in ms since last rotation for pool', labelNames:['pool'] });
  gauges.soloPoolLastRotationReasonCode = new prom.Gauge({ name:'aurrelia_solo_pool_last_rotation_reason_code', help:'Numeric code for last rotation reason per pool', labelNames:['pool'] });
  gauges.soloPoolLastRotationReasonFlag = new prom.Gauge({ name:'aurrelia_solo_pool_last_rotation_reason_flag', help:'One-hot flag for last rotation reason (1 active) per pool', labelNames:['pool','reason'] });
  // Governance & audit gauges
  gauges.govProposals = new prom.Gauge({ name:'aurrelia_gov_proposals_total', help:'Total governance proposals loaded/in-memory' });
  gauges.govApprovals = new prom.Gauge({ name:'aurrelia_gov_approvals_total', help:'Sum of approvals across all proposals' });
  gauges.govActivated = new prom.Gauge({ name:'aurrelia_gov_activated_total', help:'Total proposals activated (ready state reached)' });
  gauges.auditLastTs = new prom.Gauge({ name:'aurrelia_audit_last_timestamp', help:'Timestamp (ms) of last integrity audit run' });
  gauges.auditLastMerkle = new prom.Gauge({ name:'aurrelia_audit_last_merkle_prefix', help:'Numeric shard (first 8 hex -> int) of last audit Merkle root' });
  gauges.auditRootMatch = new prom.Gauge({ name:'aurrelia_audit_root_match', help:'1 if audit root matches manifest embedded root, 0 if mismatch, -1 unknown' });
        registry.registerMetric(gauges.batchSize); registry.registerMetric(gauges.emaLatency); registry.registerMetric(gauges.sharesAccepted);
        registry.registerMetric(gauges.sharesRejected); registry.registerMetric(gauges.acceptanceRatio); registry.registerMetric(gauges.emaSharesPerMin);
  registry.registerMetric(gauges.acceptanceHist);
  registry.registerMetric(gauges.acceptP50); registry.registerMetric(gauges.acceptP90); registry.registerMetric(gauges.acceptP99); registry.registerMetric(gauges.normThreshold);
  registry.registerMetric(gauges.hashes); registry.registerMetric(gauges.ths); registry.registerMetric(gauges.econScore); registry.registerMetric(gauges.recommend);
  registry.registerMetric(gauges.nodeGrowthAttempts); registry.registerMetric(gauges.nodeGrowthKept); registry.registerMetric(gauges.nodeGrowthReverted); registry.registerMetric(gauges.nodeGrowthPending);
  registry.registerMetric(gauges.spinPower); registry.registerMetric(gauges.spinPowerHist); registry.registerMetric(gauges.nodeCount); registry.registerMetric(gauges.geomUtil); registry.registerMetric(gauges.geomCapacity); registry.registerMetric(gauges.geomNodesMax); registry.registerMetric(gauges.burrowDepth);
  registry.registerMetric(gauges.rulePrune); registry.registerMetric(gauges.ruleSpawn);
  registry.registerMetric(gauges.rashbaGain); registry.registerMetric(gauges.isheEff); registry.registerMetric(gauges.spinGap); registry.registerMetric(gauges.rashbaTargetGap); registry.registerMetric(gauges.rashbaGapRatio); registry.registerMetric(gauges.hypercubeBlend); registry.registerMetric(gauges.hypercubeSubset); registry.registerMetric(gauges.hypercubeSliceSize); registry.registerMetric(gauges.chernProxy); registry.registerMetric(gauges.mlLatency); registry.registerMetric(gauges.mlLatencyHist); registry.registerMetric(gauges.mlLatencyP50); registry.registerMetric(gauges.mlLatencyP90); registry.registerMetric(gauges.mlLatencyP99); registry.registerMetric(gauges.mlModelVersion); registry.registerMetric(gauges.agentInvocations); registry.registerMetric(gauges.agentModelSig);
  registry.registerMetric(gauges.mlModelSignature);
  registry.registerMetric(gauges.balanceRVN); registry.registerMetric(gauges.balanceBTC); registry.registerMetric(gauges.balanceFREN); registry.registerMetric(gauges.balanceKAS);
  registry.registerMetric(gauges.swapExecTotal); registry.registerMetric(gauges.swapExecSettled); registry.registerMetric(gauges.swapExecFailed);
  registry.registerMetric(gauges.rvnCreditTotal); registry.registerMetric(gauges.rvnCreditShares); registry.registerMetric(gauges.rvnCreditLast);
  registry.registerMetric(gauges.companionTopConfidence); registry.registerMetric(gauges.companionSuggestionCount);
  registry.registerMetric(gauges.econSwitchTotal); registry.registerMetric(gauges.econSwitchFail); registry.registerMetric(gauges.econActive); registry.registerMetric(gauges.econCooldown); registry.registerMetric(gauges.econRollback); registry.registerMetric(gauges.econAcceptDelta);
  registry.registerMetric(gauges.soloPoolActiveIndex); registry.registerMetric(gauges.soloPoolRotations);
  registry.registerMetric(gauges.soloPoolAcceptanceRatio); registry.registerMetric(gauges.soloPoolSpinWeightedScore);
  registry.registerMetric(gauges.soloPoolAvgJobIntervalHist);
  registry.registerMetric(gauges.soloPoolAcceptanceLabeled); registry.registerMetric(gauges.soloPoolConfidenceLabeled);
  registry.registerMetric(gauges.soloPoolRotationsLabeled);
  registry.registerMetric(gauges.soloPoolJobIntervalLabeled);
  registry.registerMetric(gauges.soloPoolBucketMax); registry.registerMetric(gauges.soloPoolBucketExpansions);
  registry.registerMetric(gauges.soloPoolLastRotationAge); registry.registerMetric(gauges.soloPoolLastRotationReasonCode); registry.registerMetric(gauges.soloPoolLastRotationReasonFlag);
  registry.registerMetric(gauges.govProposals); registry.registerMetric(gauges.govApprovals); registry.registerMetric(gauges.govActivated); registry.registerMetric(gauges.auditLastTs); registry.registerMetric(gauges.auditLastMerkle); registry.registerMetric(gauges.auditRootMatch);
      } catch(e){ console.warn('[Metrics] prom-client unavailable', e.message); }
    }
    const selfPort = parseInt(process.env.SELF_CHECK_PORT || '9786',10);
    http.createServer((req,res)=>{
      const authToken = process.env.PERF_API_TOKEN || null;
      // Basic rate limit for hypercube endpoint
      if (!global.__AUR_RATE__){ global.__AUR_RATE__ = { lastWindow: Date.now(), count:0 }; }
      const rl = global.__AUR_RATE__;
      const now = Date.now();
      if (now - rl.lastWindow > 60000){ rl.lastWindow = now; rl.count = 0; }
      function deny(){ res.writeHead(403); res.end('forbidden'); }
      if (authToken){
        // Accept token from header or query string (?token=)
        let provided = (req.headers['x-perf-token'] || req.headers['authorization'] || '').toString().replace(/^Bearer /i,'');
        if (!provided){ try { const u = new URL(req.url, 'http://localhost'); provided = u.searchParams.get('token') || ''; } catch(_){}
        }
        if (provided !== authToken) return deny();
      }
      if (req.url.startsWith('/hypercube')){
        rl.count++;
        const maxPerMin = parseInt(process.env.HYPERCUBE_RATE_MAX || '60',10);
        if (rl.count > maxPerMin){ res.writeHead(429); return res.end(JSON.stringify({ error:'rate_exceeded', retryInMs: 60000 - (now - rl.lastWindow) })); }
      }
      // Wallet listing (masked) with HMAC status
      if (req.url === '/wallet/list'){
        const mask = s=>{ if(!s) return null; const t=String(s); if (t.length<=10) return t.replace(/.(?=.{4}$)/g,'*'); return t.slice(0,4)+'***'+t.slice(-4); };
        const wallets = {};
        const keys = ['BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','LTC_KRAKEN_ADDRESS','RVN_LOCAL_ADDRESS','FREN_WALLET','KAS_WALLET'];
        keys.forEach(k=>{ if (process.env[k]) wallets[k]={ masked: mask(process.env[k]), hmac: process.env[k+'_HMAC']||null }; });
        res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, wallets }));
      }
      // Update governance & audit gauges on any request for lightweight freshness
      try {
        if (prom && registry && gauges.govProposals){
          const gov = global.__AUR_GOV__;
          if (gov && gov.proposals){
            const list = [...gov.proposals.values()];
            const approvalsSum = list.reduce((a,p)=> a + (Array.isArray(p.approvals)?p.approvals.length:0), 0);
            const activated = list.filter(p=> p.activatedTs).length;
            gauges.govProposals.set(list.length);
            gauges.govApprovals.set(approvalsSum);
            gauges.govActivated.set(activated);
          }
          if (gauges.auditLastTs && gauges.auditLastMerkle && global.__AUR_LAST_AUDIT__){
            gauges.auditLastTs.set(global.__AUR_LAST_AUDIT__.ts||0);
            const root = global.__AUR_LAST_AUDIT__.merkleRoot || null;
            if (root && /^[0-9a-fA-F]{16,}$/.test(root)){
              const shard = parseInt(root.slice(0,8),16);
              gauges.auditLastMerkle.set(shard);
            }
            // Attempt to compare with manifest embedded root if loaded
            try {
              if (global.__AUR_MANIFEST_ROOT__ && root){
                gauges.auditRootMatch.set(root === global.__AUR_MANIFEST_ROOT__ ? 1 : 0);
              } else {
                gauges.auditRootMatch.set(-1);
              }
            } catch(_){ gauges.auditRootMatch.set(-1); }
          }
        }
      } catch(_){ }
      // Wallet seal: POST /wallet/seal { key, address } -> compute HMAC and store KEY_HMAC
      if (req.url === '/wallet/seal' && req.method==='POST'){
        if (!process.env.CONFIG_HMAC_KEY){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'missing_CONFIG_HMAC_KEY' })); }
        let body=''; req.on('data',c=> body+=c); req.on('end',()=>{ try {
          const data = JSON.parse(body||'{}');
          const key = (data.key||'').toUpperCase(); const addr = (data.address||'').trim();
          if (!key || !addr) { res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'missing_fields' })); }
          // Basic pattern checks per coin
          const pat = /^[A-Za-z0-9]{26,50}$/; if (!pat.test(addr)){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'address_pattern' })); }
          process.env[key] = addr;
          const hmac = crypto.createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(addr).digest('hex').slice(0,32);
          process.env[key+'_HMAC'] = hmac;
          res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, key, hmac }));
        } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'bad_json', message:e.message })); }});
        return;
      }
      // Payout routing hint
      if (req.url === '/payout/routing'){
        const routes = [];
        function addRoute(symbol, sourceKey, targetKey){
          if (process.env[sourceKey] && process.env[targetKey]){
            routes.push({ coin: symbol, from: sourceKey, to: targetKey, targetMasked: process.env[targetKey].slice(0,4)+'***'+process.env[targetKey].slice(-4) });
          }
        }
        addRoute('btc','BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS');
        addRoute('ltc','LTC_KRAKEN_ADDRESS','LTC_KRAKEN_ADDRESS');
        addRoute('rvn','RVN_LOCAL_ADDRESS','BTC_KRAKEN_ADDRESS'); // example swap path rvn -> btc
        addRoute('fren','FREN_WALLET','BTC_KRAKEN_ADDRESS');
        res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, routes }));
      }
      // Dynamic pool oracle: aggregates pool perf + economic hints
      if (req.url === '/oracle/pools'){
        const out = { ts: Date.now(), pools: {}, coins: {}, recommendation: ECON && ECON.state ? ECON.state.recommend : null };
        try {
          if (pipeline.poolPerf && pipeline.poolPerf.map){
            for (const [name,p] of pipeline.poolPerf.map.entries()){
              out.pools[name] = {
                jobs: p.jobs, shares: p.shares, acceptanceRatio: p.acceptanceRatio,
                lastNotifyDeltaMs: p.lastNotifyDeltaMs, avgJobIntervalMs: p.avgJobIntervalMs,
                spinWeightedScore: p.spinWeightedScore, confidence: p.confidence
              };
            }
          }
          if (ECON && ECON.state){
            const prices = ECON.state.price || {}; const diffs = ECON.state.diff || {};
            ['btc','rvn','kas','fren'].forEach(c=>{
              if (prices[c] && diffs[c]){
                out.coins[c] = { price: prices[c], diff: diffs[c], ratio: prices[c]/diffs[c] };
              }
            });
          }
          // Simple profit ordering suggestion (highest price/diff ratio * acceptance if pool name contains coin ticker)
          const scored = [];
          for (const pk in out.pools){
            const pool = out.pools[pk];
            const coinKey = ['rvn','btc','kas','fren'].find(c=> pk.toLowerCase().includes(c));
            let econRatio = coinKey && out.coins[coinKey] ? out.coins[coinKey].ratio : 0;
            const acc = pool.acceptanceRatio || 0;
            const score = econRatio * (0.5 + 0.5*acc);
            scored.push({ pool: pk, score, coin: coinKey, acc });
          }
          scored.sort((a,b)=> b.score - a.score);
          out.rank = scored.slice(0,12);
        } catch(e){ out.error = e.message; }
        res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify(out));
      }
      // --- Swap Adapter (Enhanced) ------------------------------------------------
      // Adapter integration replacing inline SimpleSwap logic.
      let swapAdapter = null;
      try { swapAdapter = require('./simple-swap-adapter.js'); } catch(e){ console.warn('[SwapAdapter] load failed', e.message); }
      global.__AUR_SWAP_EXEC__ = global.__AUR_SWAP_EXEC__ || new Map();
      if (req.url.startsWith('/swap/quote')){
        try {
          const u = new URL(req.url,'http://x');
          const from = (u.searchParams.get('from')||'').toLowerCase();
          const to = (u.searchParams.get('to')||'').toLowerCase();
          const amount = parseFloat(u.searchParams.get('amount')||'0');
          if (!from || !to || !(amount>0)){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'missing_params' })); }
          if(!swapAdapter){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:'adapter_unavailable' })); }
          swapAdapter.quote(from,to,amount).then(q=>{
            appendSwapLedger({ event:'quote', id:q.id, from, to, amount, rate:q.rate, live:q.live, status:'quoted', error: q.error||null });
            res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, quote:q }));
          }).catch(e=>{ res.writeHead(500); res.end(JSON.stringify({ ok:false, error:e.message })); });
        } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false, error:e.message })); }
      }
      if (req.url === '/swap/execute' && req.method==='POST'){
        let body=''; req.on('data',c=> body+=c); req.on('end',()=>{
          try {
            const data=JSON.parse(body||'{}'); const { from,to,amount,quoteId }=data; if(!from||!to||!(amount>0)){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_fields' })); }
            if(!swapAdapter){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:'adapter_unavailable' })); }
            // Attempt to find cached quote in adapter map (dry-run deterministic recreation if missing acceptable)
            swapAdapter.quote(from,to,amount).then(q=>{
              if(quoteId && q.id!==quoteId){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'quote_mismatch' })); }
              return swapAdapter.execute(from,to,amount,q).then(exec=>{
                const rec = { ts:Date.now(), status:exec.status, detail:{ live: exec.live }, from, to, amount, quote:q };
                global.__AUR_SWAP_EXEC__.set(exec.execId, rec);
                appendSwapLedger({ event:'execute', id: exec.execId, from, to, amount, rate:q.rate, live: exec.live, status: exec.status });
                try { if(typeof gauges!=='undefined' && gauges.swapExecTotal) gauges.swapExecTotal.inc({ from, to, mode: exec.live?'live':'dry' }); } catch(_){ }
                res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, execId: exec.execId, status: exec.status }));
              });
            }).catch(e=>{ res.writeHead(500); res.end(JSON.stringify({ ok:false,error:e.message })); });
          } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:e.message })); }
        });
        return;
      }
      if (req.url.startsWith('/swap/status')){
        try {
          const u=new URL(req.url,'http://x'); const id=u.searchParams.get('id'); if(!id){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_id' })); }
          const exec=global.__AUR_SWAP_EXEC__.get(id); if(!exec){ res.writeHead(404); return res.end(JSON.stringify({ ok:false,error:'not_found' })); }
          if(!swapAdapter){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:'adapter_unavailable' })); }
          swapAdapter.poll(id).then(updated=>{
            if(updated.status && updated.status!==exec.status){
              // status transition, append ledger
              appendSwapLedger({ event:'status', id, from: updated.from, to: updated.to, amount: updated.amount, rate: (updated.quote&&updated.quote.rate)||null, live: updated.detail && updated.detail.live, status: updated.status, orderId: updated.detail && updated.detail.orderId, depositAddress: updated.detail && updated.detail.depositAddress, txid: updated.detail && updated.detail.txid_out, confirmations: updated.detail && updated.detail.confirmations, error: updated.detail && updated.detail.error });
              // Econ realization on settlement
              if(updated.status==='settled'){
                try {
                  const prices = ECON && ECON.state && ECON.state.price || {};
                  const usdBTC = prices.btc || null;
                  const usdFrom = prices[updated.from] || null;
                  const usdTo = prices[updated.to] || null;
                  let preCreditUSD=null; let realizedUSD=null; let pnlDeltaUSD=null;
                  if(usdFrom && typeof updated.amount==='number') preCreditUSD = Number((updated.amount * usdFrom).toFixed(8));
                  if(usdTo && updated.quote && updated.quote.rate){
                    // realized destination amount (from * rate) * usdTo
                    const destAmt = updated.amount * updated.quote.rate;
                    realizedUSD = Number((destAmt * usdTo).toFixed(8));
                  }
                  if(preCreditUSD!=null && realizedUSD!=null){ pnlDeltaUSD = Number((realizedUSD - preCreditUSD).toFixed(8)); }
                  appendEconRealization({ type:'swap_settle', swapId:id, from: updated.from, to: updated.to, amountFrom: updated.amount, rateUsed: (updated.quote&&updated.quote.rate)||null, usdBTC, usdRVN: prices.rvn||null, usdKAS: prices.kas||null, usdFREN: prices.fren||null, preCreditUSD, realizedUSD, pnlDeltaUSD, live: updated.detail && updated.detail.live, status: updated.status, confirmations: updated.detail && updated.detail.confirmations });
                } catch(_){ }
              }
              if(updated.status==='settled'){ try { if(typeof gauges!=='undefined' && gauges.swapExecSettled) gauges.swapExecSettled.inc({ from: updated.from, to: updated.to, mode: updated.detail && updated.detail.live ? 'live':'dry' }); } catch(_){ } }
              if(updated.status==='error'){ try { if(typeof gauges!=='undefined' && gauges.swapExecFailed) gauges.swapExecFailed.inc({ from: updated.from, to: updated.to, reason: updated.detail && (updated.detail.error||'error') }); } catch(_){ } }
            }
            // mirror updated back into global exec map
            global.__AUR_SWAP_EXEC__.set(id, updated);
            res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, exec: updated }));
          }).catch(e=>{ res.writeHead(500); res.end(JSON.stringify({ ok:false,error:e.message })); });
        } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
      }
      // --- Readiness Endpoint (deterministic integrity) -------------------------
      if (req.url === '/readiness'){
        try {
          const fs=require('fs'); const crypto=require('crypto');
          // Share ledger chain tip validation (recompute last hash from file tail for assurance)
          let shareChainTipValid=null; let shareEntries=0; let shareLastHash=null; try {
            if(fs.existsSync('share-ledger.jsonl')){ const lines=fs.readFileSync('share-ledger.jsonl','utf8').trim().split(/\n+/); shareEntries=lines.length; let prev='GENESIS'; for(const ln of lines){ try { const o=JSON.parse(ln); const raw=JSON.stringify({ ts:o.ts, coin:o.coin, difficulty:o.difficulty, poolDifficulty:o.poolDifficulty, shareTarget:o.shareTarget, creditEst:o.creditEst, source:o.source, acceptLatencyMs:o.acceptLatencyMs }); const ch=crypto.createHash('sha256').update(prev+raw).digest('hex'); if(ch!==o.chain_hash){ shareChainTipValid=false; break; } prev=ch; shareLastHash=ch; } catch(_){ shareChainTipValid=false; break; } } if(shareChainTipValid!==false){ shareChainTipValid=true; } } } catch(_){ shareChainTipValid=false; }
          // Swap ledger chain tip validation
          let swapChainTipValid=null; let swapEntries=0; let swapLastHash=null; try {
            if(fs.existsSync('swap-ledger.jsonl')){ const lines=fs.readFileSync('swap-ledger.jsonl','utf8').trim().split(/\n+/); swapEntries=lines.length; let prev='GENESIS'; for(const ln of lines){ try { const o=JSON.parse(ln); const raw=JSON.stringify({ ts:o.ts, event:o.event, id:o.id, from:o.from, to:o.to, amount:o.amount, rate:o.rate, live:o.live, status:o.status, orderId:o.orderId, depositAddress:o.depositAddress, txid:o.txid, confirmations:o.confirmations, error:o.error }); const ch=crypto.createHash('sha256').update(prev+raw).digest('hex'); if(ch!==o.chain_hash){ swapChainTipValid=false; break; } prev=ch; swapLastHash=ch; } catch(_){ swapChainTipValid=false; break; } } if(swapChainTipValid!==false){ swapChainTipValid=true; } } } catch(_){ swapChainTipValid=false; }
          // Balance file signature verification
          let balanceValid=null; let balanceVersion=null; try { if(fs.existsSync(BAL_PATH)){ const raw=fs.readFileSync(BAL_PATH,'utf8'); let parsed; try { parsed=JSON.parse(raw); } catch(_){ parsed=null; } if(parsed && parsed.version){ balanceVersion=parsed.version; if(process.env.BALANCE_HMAC_KEY && parsed.hmac){ const expected=crypto.createHmac('sha256', process.env.BALANCE_HMAC_KEY).update(JSON.stringify(parsed.data)).digest('hex'); balanceValid = expected===parsed.hmac; } else { balanceValid = parsed.version===2; } } else if(parsed){ balanceValid=true; balanceVersion='legacy'; } } } catch(_){ balanceValid=false; }
          // Explorer health snapshot
          let explorerHealth=null; try { const explorer = global.__AUR_EXPLORER__ || (global.__AUR_EXPLORER__ = require('./explorer-multi.js')); explorerHealth = explorer.health(); } catch(_){ }
          // Swap risk state
          const swapRisk = global.__AUR_SWAP_RISK__ || null;
          // Autoswitch econ state
          const econState = ECON && ECON.state ? { recommend: ECON.state.recommend, price: ECON.state.price, diff: ECON.state.diff } : null;
          const readiness = { ts: Date.now(), shareChainTipValid, shareLastHash, shareEntries, swapChainTipValid, swapLastHash, swapEntries, balanceValid, balanceVersion, explorerHealth, swapRisk, econRecommend: econState && econState.recommend, circuitOpen: !!(swapRisk && swapRisk.circuit) };
          // Overall readiness boolean
          readiness.ok = !!(shareChainTipValid && swapChainTipValid && balanceValid !== false);
          res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, readiness }));
        } catch(e){ res.writeHead(500,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:false, error:e.message })); }
      }
      // --- Balance / Threshold Monitor (Enhanced) ---------------------------------
      global.__AUR_BALANCES__ = global.__AUR_BALANCES__ || { rvn:0, btc:0, fren:0, kas:0 };
      const BAL_PATH = process.env.BALANCES_PATH || 'balances.json';
      const BAL_VERSION = 2; // introduce versioned + HMAC wrapper starting at version 2
      function balanceWrap(obj){
        const payload = { version: BAL_VERSION, data: obj };
        if(process.env.BALANCE_HMAC_KEY){
          try { const crypto=require('crypto'); payload.hmac = crypto.createHmac('sha256', process.env.BALANCE_HMAC_KEY).update(JSON.stringify(payload.data)).digest('hex'); } catch(_){ }
        }
        return payload;
      }
      function balanceVerify(raw){
        try {
          if(!raw || typeof raw!=='object') return { ok:false, reason:'not_object'};
          if(!raw.version){ // legacy unwrapped file
            return { ok:true, legacy:true, data: raw };
          }
            if(raw.version !== BAL_VERSION) return { ok:false, reason:'version_mismatch', data: raw };
            if(process.env.BALANCE_HMAC_KEY && raw.hmac){
              const crypto=require('crypto');
              const expected = crypto.createHmac('sha256', process.env.BALANCE_HMAC_KEY).update(JSON.stringify(raw.data)).digest('hex');
              if(expected !== raw.hmac) return { ok:false, reason:'hmac_mismatch', data: raw };
            }
            return { ok:true, data: raw.data };
        } catch(e){ return { ok:false, reason:e.message }; }
      }
      if (!global.__AUR_BALANCES_LOADED__){ try { const fs=require('fs'); if(fs.existsSync(BAL_PATH)){ let objRaw; try { objRaw=JSON.parse(fs.readFileSync(BAL_PATH,'utf8')); } catch(_){ objRaw=null; }
          if(objRaw){ const ver = balanceVerify(objRaw); if(!ver.ok){ console.error('[BALANCES] verify fail', ver.reason); if(process.env.REAL_STRICT==='1'){ console.error('[BALANCES] REAL_STRICT abort on verify fail'); process.exit(40); } if(ver.data) global.__AUR_BALANCES__ = ver.data.data || ver.data; } else { global.__AUR_BALANCES__ = ver.data; if(ver.legacy){ /* will upgrade on next persist */ } } }
        } } catch(_){ } global.__AUR_BALANCES_LOADED__=1; }
      if (req.url === '/balances'){ res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, balances: global.__AUR_BALANCES__ })); }
      if (!global.__AUR_BALANCE_LOOP__){
          const crypto = require('crypto');
          function maybeEncrypt(obj){
            if (process.env.BALANCE_ENCRYPT !== '1') return JSON.stringify(obj, null, 2);
            const pass = process.env.VAULT_PASS || process.env.BALANCE_ENCRYPT_PASS || null; if(!pass) return JSON.stringify(obj,null,2);
            const { deriveBuffer } = require('./deterministic-util');
            const iv = deriveBuffer('enc-iv',16,pass); const key = crypto.createHash('sha256').update(pass).digest();
            const cipher = crypto.createCipheriv('aes-256-cbc', key, iv); let enc = cipher.update(JSON.stringify(obj),'utf8','base64'); enc += cipher.final('base64');
            return JSON.stringify({ v:1, iv: iv.toString('hex'), data: enc, alg:'aes-256-cbc' });
          }
          function maybeDecrypt(str){
            try {
              if (process.env.BALANCE_ENCRYPT !== '1') return JSON.parse(str);
              const pass = process.env.VAULT_PASS || process.env.BALANCE_ENCRYPT_PASS || null; if(!pass) return JSON.parse(str);
              const o = JSON.parse(str); if(!o || !o.iv || !o.data) return o;
              const iv = Buffer.from(o.iv,'hex'); const key = crypto.createHash('sha256').update(pass).digest();
              const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv); let dec = decipher.update(o.data,'base64','utf8'); dec += decipher.final('utf8');
              return JSON.parse(dec);
            } catch(e){ return {}; }
          }
          // End OctaBit Integration

          try { if (!global.__AUR_BALANCES_DECRYPTED__){ const fs=require('fs'); if(fs.existsSync(BAL_PATH)){ const raw=fs.readFileSync(BAL_PATH,'utf8'); const parsed=maybeDecrypt(raw); if(parsed && typeof parsed==='object'){ const ver = balanceVerify(parsed); if(!ver.ok){ console.error('[BALANCES] decrypt verify fail', ver.reason); if(process.env.REAL_STRICT==='1'){ console.error('[BALANCES] REAL_STRICT abort on decrypt verify fail'); process.exit(41); } if(ver.data) global.__AUR_BALANCES__ = ver.data.data || ver.data; } else { global.__AUR_BALANCES__ = ver.data; } } global.__AUR_BALANCES_DECRYPTED__=1; } } } catch(_){ }
          global.__AUR_LAST_ACCEPTED_SHARES__ = 0;
          global.__AUR_BALANCE_LOOP__ = setInterval(()=>{
            try {
              const stats=(pipeline && pipeline.shareStats)? pipeline.shareStats : null; if(!stats) return;
              const accepted=stats.accepted||0; const delta=accepted - global.__AUR_LAST_ACCEPTED_SHARES__;
              if(delta>0){
                const netDiff = (ECON && ECON.state && ECON.state.diff && ECON.state.diff.rvn) ? ECON.state.diff.rvn : 1;
                const BLOCK_REWARD_RVN = parseFloat(process.env.RVN_BLOCK_REWARD || '5000');
                const SHARE_DIFF_APPROX = parseFloat(process.env.RVN_SHARE_DIFF_APPROX || '1');
                const SCALE = parseFloat(process.env.RVN_SHARE_SCALE || '1');
                let credit = delta * BLOCK_REWARD_RVN * (SHARE_DIFF_APPROX / netDiff) * SCALE;
                if (credit < 0) credit = 0;
                if(credit>0){
                  global.__AUR_BALANCES__.rvn += credit;
                  try { if(typeof gauges!=='undefined' && gauges.rvnCreditTotal) gauges.rvnCreditTotal.inc(credit); } catch(_){ }
                  try { if(typeof gauges!=='undefined' && gauges.rvnCreditShares) gauges.rvnCreditShares.inc(delta); } catch(_){ }
                  try { if(typeof gauges!=='undefined' && gauges.rvnCreditLast) gauges.rvnCreditLast.set(credit); } catch(_){ }
                }
                global.__AUR_LAST_ACCEPTED_SHARES__ = accepted;
                try { const fs=require('fs'); if (process.env.BALANCE_PERSIST_INTERVAL_MS){ const interval=parseInt(process.env.BALANCE_PERSIST_INTERVAL_MS,10); if(!global.__AUR_LAST_BAL_PERSIST__ || Date.now()-global.__AUR_LAST_BAL_PERSIST__>interval){ const wrapped = balanceWrap(global.__AUR_BALANCES__); fs.writeFileSync(BAL_PATH, maybeEncrypt(wrapped)); global.__AUR_LAST_BAL_PERSIST__=Date.now(); } } } catch(_){ }
              }
              try { if(typeof gauges!=='undefined' && gauges.balanceRVN) gauges.balanceRVN.set(global.__AUR_BALANCES__.rvn); } catch(_){ }
              try { if(typeof gauges!=='undefined' && gauges.balanceBTC) gauges.balanceBTC.set(global.__AUR_BALANCES__.btc); } catch(_){ }
              try { if(typeof gauges!=='undefined' && gauges.balanceFREN) gauges.balanceFREN.set(global.__AUR_BALANCES__.fren); } catch(_){ }
              try { if(typeof gauges!=='undefined' && gauges.balanceKAS) gauges.balanceKAS.set(global.__AUR_BALANCES__.kas); } catch(_){ }
            } catch(_){ }
          }, parseInt(process.env.BALANCE_ACCRUE_MS||'10000',10)).unref();
      }
      if (req.url.startsWith('/debug/add-shares')){
        if (process.env.DEBUG_SHARE_ADD !== '1'){ res.writeHead(403); return res.end('disabled'); }
        try { const u=new URL(req.url,'http://x'); const delta=parseInt(u.searchParams.get('delta')||'0',10); if(!delta || delta<0){ res.writeHead(400); return res.end('bad_delta'); }
          if (!pipeline.shareStats) pipeline.shareStats={ accepted:0 };
          pipeline.shareStats.accepted += delta;
          res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, added:delta, newAccepted:pipeline.shareStats.accepted }));
        } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false, error:e.message })); }
      }
      if (!global.__AUR_SWAP_AUTO_LOOP__){
        function parseRoutes(){ const raw=process.env.SWAP_ROUTES || 'rvn:btc'; return raw.split(',').map(s=> s.trim()).filter(Boolean).reduce((m,p)=>{ const [a,b]=p.split(':'); if(a&&b) m[a.toLowerCase()]=b.toLowerCase(); return m; },{}); }
        // --- Risk Controls State & Helpers ---
        global.__AUR_SWAP_RISK__ = global.__AUR_SWAP_RISK__ || { window:[], fails:0, circuit:false, circuitReason:null, circuitSince:0 };
        function riskPrune(){ const now=Date.now(); const horizon=parseInt(process.env.SWAP_RISK_WINDOW_MS||'3600000',10); global.__AUR_SWAP_RISK__.window = global.__AUR_SWAP_RISK__.window.filter(ts=> now - ts < horizon); }
        function riskRecordSuccess(){ riskPrune(); global.__AUR_SWAP_RISK__.window.push(Date.now()); }
        function riskRecordFail(reason){ riskPrune(); global.__AUR_SWAP_RISK__.fails++; try { if(typeof gauges!=='undefined' && gauges.swapRiskFail) gauges.swapRiskFail.inc({ reason: (reason||'fail').substring(0,30) }); } catch(_){ }
          const failLimit=parseInt(process.env.SWAP_FAIL_LIMIT||'5',10); if(global.__AUR_SWAP_RISK__.fails >= failLimit){ global.__AUR_SWAP_RISK__.circuit=true; global.__AUR_SWAP_RISK__.circuitReason='fail_limit'; global.__AUR_SWAP_RISK__.circuitSince=Date.now(); console.error('[Swap][Risk] Circuit OPEN (fail limit)'); }
        }
        function riskAllowed(){
          if(global.__AUR_SWAP_RISK__.circuit){
            const autoResetMs=parseInt(process.env.SWAP_CIRCUIT_AUTO_RESET_MS||'0',10); if(autoResetMs>0 && Date.now()-global.__AUR_SWAP_RISK__.circuitSince>autoResetMs){ console.log('[Swap][Risk] Auto circuit reset'); global.__AUR_SWAP_RISK__.circuit=false; global.__AUR_SWAP_RISK__.fails=0; global.__AUR_SWAP_RISK__.circuitReason=null; }
          }
          if(global.__AUR_SWAP_RISK__.circuit) return false;
          riskPrune();
          const maxPerWindow=parseInt(process.env.SWAP_MAX_WINDOW_COUNT||'10',10);
          if(global.__AUR_SWAP_RISK__.window.length >= maxPerWindow) return false;
          return true;
        }
        if(process.env.SWAP_CIRCUIT_FORCE_OPEN==='1'){ global.__AUR_SWAP_RISK__.circuit=true; global.__AUR_SWAP_RISK__.circuitReason='forced'; global.__AUR_SWAP_RISK__.circuitSince=Date.now(); }
        if(process.env.SWAP_CIRCUIT_FORCE_CLOSE==='1'){ global.__AUR_SWAP_RISK__.circuit=false; global.__AUR_SWAP_RISK__.circuitReason=null; }
        global.__AUR_SWAP_AUTO_LOOP__ = setInterval(()=>{
          try {
            if(process.env.SWAP_AUTO!=='1') return;
            if(!riskAllowed()){ if(process.env.SWAP_AUTO_LOG==='1') console.log('[Swap][Risk] Skip: circuit open or rate limit exceeded'); return; }
            const routes=parseRoutes();
            const thresholds={ rvn: parseFloat(process.env.RVN_SWAP_THRESHOLD || '0'), fren: parseFloat(process.env.FREN_SWAP_THRESHOLD || '0'), kas: parseFloat(process.env.KAS_SWAP_THRESHOLD || '0') };
            for(const coin of Object.keys(routes)){
              const target=routes[coin]; const bal=global.__AUR_BALANCES__[coin]; const thr=thresholds[coin]||0;
              if(bal!=null && bal>=thr && thr>0){
                const amt=parseFloat(bal.toFixed(6));
                if(!swapAdapter) continue;
                swapAdapter.quote(coin,target,amt).then(q=>{
                  return swapAdapter.execute(coin,target,amt,q).then(exec=>{
                    const execId = exec.execId;
                    global.__AUR_SWAP_EXEC__.set(execId,{ ts:Date.now(), status:exec.status, detail:{ auto:true, live:exec.live }, from:coin, to:target, amount:amt, quote:q });
                    appendSwapLedger({ event:'auto_execute', id: execId, from: coin, to: target, amount: amt, rate: q.rate, live: exec.live, status: exec.status });
                    // Initial realization record (execution stage) capturing pre swap valuation
                    try {
                      const prices = ECON && ECON.state && ECON.state.price || {};
                      const usdFrom = prices[coin] || null; const usdBTC = prices.btc || null;
                      let preCreditUSD=null; if(usdFrom) preCreditUSD = Number((amt * usdFrom).toFixed(8));
                      appendEconRealization({ type:'swap_execute', swapId: execId, from: coin, to: target, amountFrom: amt, rateUsed: q.rate, usdBTC, usdRVN: prices.rvn||null, usdKAS: prices.kas||null, usdFREN: prices.fren||null, preCreditUSD, live: exec.live, status: exec.status });
                    } catch(_){ }
                    global.__AUR_BALANCES__[coin]=0; // reset after swap
                    riskRecordSuccess();
                    try { const fs=require('fs'); if(process.env.SWAP_EVENT_LOG_PATH){ fs.appendFileSync(process.env.SWAP_EVENT_LOG_PATH, JSON.stringify({ ts:Date.now(), type:'auto_swap', execId, coin, target, amount:amt, quote:q })+'\n'); } } catch(_){ }
                    if(process.env.SWAP_AUTO_LOG==='1') console.log('[Swap][Auto]', coin,'->',target,'execId',execId,'amount',amt,'rate',q.rate);
                    try { if(typeof gauges!=='undefined' && gauges.swapExecTotal) gauges.swapExecTotal.inc({ from:coin, to:target, mode: exec.live?'live':'dry' }); } catch(_){ }
                  });
                }).catch(err=>{ riskRecordFail(err && err.message); });
              }
            }
          } catch(_){ }
        }, parseInt(process.env.SWAP_AUTO_INTERVAL_MS||'20000',10)).unref();
      }
      // Lightweight secure RVN wallet generator (disabled unless explicitly allowed)
      if (req.url.startsWith('/wallet/generate')){
        if (process.env.AUR_ALLOW_WALLET_GEN !== '1'){
          res.writeHead(403,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:false, error:'disabled', message:'Enable with AUR_ALLOW_WALLET_GEN=1' }));
        }
        try {
          const crypto = require('crypto');
          let coin = 'rvn';
          try { const u = new URL(req.url, 'http://localhost'); const q = (u.searchParams.get('coin')||'').toLowerCase(); if (q) coin = q; } catch(_){ }
          // Generate 32-byte private key until within secp256k1 order
          const secp256k1n = BigInt('0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141');
          const { deriveBuffer } = require('./deterministic-util');
          let pk;
          // Deterministic iterative derivation until < curve order
          let ctr=0; do { pk = deriveBuffer('pk',32,pass,ctr++); } while (BigInt('0x'+pk.toString('hex')) >= secp256k1n);
          // Derive compressed pubkey via built-in subtle EC if available or fallback tiny-secp256k1
          let pub;
          try {
            const secp = require('tiny-secp256k1');
            const pubFull = secp.pointFromScalar(pk, true);
            pub = pubFull;
          } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false, error:'secp_unavailable', message:e.message })); }
          // HASH160(pubkey)
          const sha = crypto.createHash('sha256').update(pub).digest();
          const ripe = crypto.createHash('ripemd160').update(sha).digest();
          // Version byte selection
          let versionByte = 0x3c; // RVN default
          if (coin === 'fren'){ versionByte = 0x1e; } // Frencoin P2PKH
          const version = Buffer.from([versionByte]);
          const payload = Buffer.concat([version, ripe]);
          const checksum = crypto.createHash('sha256').update(
            crypto.createHash('sha256').update(payload).digest()
          ).digest().slice(0,4);
          const full = Buffer.concat([payload, checksum]);
          // Base58 encoding (manual minimal implementation)
          const ALPH = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
          function base58encode(buf){
            let x = BigInt('0x'+buf.toString('hex'));
            let out='';
            while (x>0n){ const r = x % 58n; x = x / 58n; out = ALPH[Number(r)] + out; }
            for (let i=0;i<buf.length && buf[i]===0;i++) out = '1'+out;
            return out || '1';
          }
          const address = base58encode(full);
          // WIF: 0x80 + pk (+0x01 for compressed) + checksum
          const wifPayload = Buffer.concat([Buffer.from([0x80]), pk, Buffer.from([0x01])]);
          const wifChecksum = crypto.createHash('sha256').update(
            crypto.createHash('sha256').update(wifPayload).digest()
          ).digest().slice(0,4);
          const wif = base58encode(Buffer.concat([wifPayload, wifChecksum]));
          res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, coin, address, wif, compressed:true, note:'Store WIF securely; this endpoint is for local dev only.' }));
        } catch(e){ res.writeHead(500,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:false, error:'wallet_gen_failed', message:e.message })); }
      }
      // --- Explorer Abstraction Endpoints ----------------------------------------
      if (req.url.startsWith('/explorer/')){
        try {
          const explorer = global.__AUR_EXPLORER__ || (global.__AUR_EXPLORER__ = require('./explorer-multi.js'));
          const u = new URL(req.url,'http://localhost');
          const action = u.pathname.split('/')[2]; // e.g. tx, addr, utxos, height, health
          const sym = (u.searchParams.get('coin')||'rvn').toLowerCase();
          if(action==='tx'){ const txid=u.searchParams.get('txid'); if(!txid){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_txid'})); }
            explorer.getTx(sym, txid).then(d=>{ res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, data:d })); }); return; }
          if(action==='addr'){ const addr=u.searchParams.get('addr'); if(!addr){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_addr'})); }
            explorer.getAddress(sym, addr).then(d=>{ res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, data:d })); }); return; }
          if(action==='utxos'){ const addr=u.searchParams.get('addr'); if(!addr){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_addr'})); }
            explorer.getUtxos(sym, addr).then(d=>{ res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, data:d })); }); return; }
          if(action==='height'){ explorer.getHeight(sym).then(d=>{ res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, data:d })); }); return; }
          if(action==='health'){ const h=explorer.health(); res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, health:h })); }
          res.writeHead(404); return res.end(JSON.stringify({ ok:false, error:'unknown_action' }));
        } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
      }
      if (req.url === '/self-check'){
        const snap = {
          parityInterval: pipeline.fusedParityInterval,
          batchSize: pipeline.currentBatchSize,
          rampActive: pipeline.fusedRampActive,
          rampTarget: pipeline.fusedRampTarget,
          speedupEst: global.__AUR_WASM_METRICS__.fusedSpeedupEst || 0,
          latencyCv: global.__AUR_WASM_METRICS__.fusedLatencyCv || 0,
          projectedNextDoubleNs: (function(){ const m = pipeline.rampLatencySamples.length? pipeline.rampLatencySamples.reduce((a,b)=>a+b,0)/pipeline.rampLatencySamples.length:0; return Math.round(m * (pipeline.currentBatchSize||0) * 2); })(),
          recoverAttempts: global.__AUR_WASM_METRICS__.fusedRecoverAttempts || 0,
          recoverSuccesses: global.__AUR_WASM_METRICS__.fusedRecoverSuccesses || 0,
          recoverFailures: global.__AUR_WASM_METRICS__.fusedRecoverFailures || 0,
          seed: GLOBAL_OCTO_SEED,
          burrowDepth: GLOBAL_BURROW_DEPTH,
          pruneThreshold: GLOBAL_PRUNE_THRESHOLD,
          multiHarmonic: MULTI_HARMONIC ? 1 : 0,
          planeAggMode: PLANE_AGG_MODE + (PLANE_WEIGHTED?'+w':''),
          minimal: MINING_MINIMAL ? 1 : 0,
          configHash: CONFIG_HASH,
          configHmac: CONFIG_HMAC,
          sourceManifestHash: SOURCE_MANIFEST_HASH,
          sourceManifestHmac: SOURCE_MANIFEST_HMAC,
          soloPoolActiveIndex: (typeof soloCycleIndex==='number')? soloCycleIndex : null,
          soloPoolSequence: SOLO_POOLS_SEQUENCE,
          soloPoolCycleEnabled: process.env.SOLO_POOL_CYCLE === '1'
        };
        // Economic autoswitch snapshot
        snap.econ = {
          active_coin: __ECON_ACTIVE_COIN,
          last_switch_ts: __ECON_LAST_SWITCH,
          last_reason: __ECON_LAST_SWITCH_REASON,
          cooldown_remaining_ms: Math.max(0, (__ECON_LAST_SWITCH_COOLDOWN_MS - (Date.now() - __ECON_LAST_SWITCH))),
          switches_total: __ECON_SWITCH_TOTAL,
          switches_fail: __ECON_SWITCH_FAIL,
          rollbacks: __ECON_ROLLBACK_COUNT_PERSIST
        };
        // Coin intelligence (non-invasive) - only descriptors, no behavior changes
        try {
          const { getCoinIntel } = require('./coin-intel.js');
          snap.coinIntel = getCoinIntel(pipeline.selectedCoin);
        } catch(_){ }
        if (pipeline.poolPerf && pipeline.poolPerf.map){
          const pools = {};
          for (const [k,v] of pipeline.poolPerf.map.entries()){
            pools[k] = {
              jobs: v.jobs,
              shares: v.shares,
              acceptanceRatio: v.acceptanceRatio,
              avgJobIntervalMs: v.avgJobIntervalMs,
              spinWeightedScore: v.spinWeightedScore,
              confidence: v.confidence
            };
          }
          // --- Reporting Endpoints --------------------------------------------------
          if (req.url === '/report/summary'){
            try {
              const prices = ECON && ECON.state && ECON.state.price || {};
              const diffs = ECON && ECON.state && ECON.state.diff || {};
              const balances = global.__AUR_BALANCES__ || {};
              const swapRisk = global.__AUR_SWAP_RISK__ || {};
              const econRecommend = ECON && ECON.state && ECON.state.recommend || null;
              // Score map (price/diff) deterministic
              const scores = {}; ['btc','rvn','kas','fren'].forEach(c=>{ if(prices[c] && diffs[c]) scores[c] = Number((prices[c]/diffs[c]).toFixed(12)); });
              // Realization PnL aggregation (sum pnlDeltaUSD from econ-realization-ledger)
              let pnlTotal = 0; let pnlCount=0; try { const fs=require('fs'); if(fs.existsSync('econ-realization-ledger.jsonl')){ const lines=fs.readFileSync('econ-realization-ledger.jsonl','utf8').trim().split(/\n+/); for(const ln of lines){ try { const o=JSON.parse(ln); if(typeof o.pnlDeltaUSD==='number') { pnlTotal += o.pnlDeltaUSD; pnlCount++; } } catch(_){ } } } } catch(_){ }
              const parityTip = typeof __PARITY_LAST_HASH !== 'undefined' ? __PARITY_LAST_HASH : null;
              const summary = { ts: Date.now(), prices, diffs, scores, econRecommend, balances, pnlTotal: Number(pnlTotal.toFixed(8)), pnlEvents: pnlCount, swapCircuit: !!swapRisk.circuit, parityChainTip: parityTip };
              res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, summary }));
            } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
          }
          if (req.url === '/report/pnl'){
            try {
              const fs=require('fs'); const out=[]; if(fs.existsSync('econ-realization-ledger.jsonl')){ const lines=fs.readFileSync('econ-realization-ledger.jsonl','utf8').trim().split(/\n+/); for(const ln of lines){ try { const o=JSON.parse(ln); out.push({ ts:o.ts, type:o.type, swapId:o.swapId, from:o.from, to:o.to, amountFrom:o.amountFrom, rateUsed:o.rateUsed, preCreditUSD:o.preCreditUSD, realizedUSD:o.realizedUSD, pnlDeltaUSD:o.pnlDeltaUSD, live:o.live, status:o.status }); } catch(_){ } } }
              res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, pnl: out }));
            } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
          }
          if (req.url === '/report/ledgers'){
            try { const fs=require('fs');
              function tip(file){ try { if(!fs.existsSync(file)) return null; const lines=fs.readFileSync(file,'utf8').trim().split(/\n+/); for(let i=lines.length-1;i>=0;i--){ try { const o=JSON.parse(lines[i]); if(o.chain_hash) return o.chain_hash; } catch(_){ } } return null; } catch(_){ return null; } }
              const data = {
                shareTip: tip('share-ledger.jsonl'),
                swapTip: tip('swap-ledger.jsonl'),
                parityTip: tip('parity-ledger.jsonl'),
                econRealTip: tip('econ-realization-ledger.jsonl'),
                priceTip: tip('price-ledger.jsonl')
              };
              res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, ledgers:data }));
            } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
          }
          // --- Governance Layer -----------------------------------------------------
          // Simple proposal system: submit config change proposals, hash + optional HMAC, require approvals.
          global.__AUR_GOV__ = global.__AUR_GOV__ || { proposals:new Map(), approvals:new Map(), loaded:false };
          const GOV_LEDGER_FILE = 'governance-ledger.jsonl';
          let __GOV_LAST_HASH = null;
          if(!global.__AUR_GOV__.loaded){
            try {
              const fs=require('fs');
              if(fs.existsSync(GOV_LEDGER_FILE)){
                const lines=fs.readFileSync(GOV_LEDGER_FILE,'utf8').trim().split(/\n+/).filter(Boolean);
                for(const ln of lines){
                  try {
                    const o=JSON.parse(ln);
                    if(o.chain_hash){
                      __GOV_LAST_HASH=o.chain_hash;
                      if(o.type==='proposal' && o.proposal){
                        global.__AUR_GOV__.proposals.set(o.proposal.hash, { ts:o.ts, obj:o.proposal.obj, hash:o.proposal.hash, seal:o.proposal.seal, approvals:o.approvals||[], activatedTs:o.activatedTs||null });
                      } else if(o.type==='approve' && o.hash){
                        const rec=global.__AUR_GOV__.proposals.get(o.hash);
                        if(rec){
                          rec.approvals=o.approvals||rec.approvals;
                          rec.activatedTs=o.activatedTs||rec.activatedTs;
                        }
                      }
                    }
                  } catch(_){ /* ignore parse errors */ }
                }
              }
            } catch(e){ console.warn('[GOV] load ledger failed', e.message); }
            global.__AUR_GOV__.loaded=true;
          }
          function govHash(obj){ const crypto=require('crypto'); return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex'); }
          function govSeal(hash){ if(process.env.GOV_HMAC_KEY){ try { const crypto=require('crypto'); return crypto.createHmac('sha256', process.env.GOV_HMAC_KEY).update(hash).digest('hex'); } catch(_){ } } return null; }
          function govAppend(entry){ try { const fs=require('fs'); const crypto=require('crypto'); const raw=JSON.stringify(entry); const chain=crypto.createHash('sha256').update((__GOV_LAST_HASH||'GENESIS')+raw).digest('hex'); const hmac= process.env.GOV_HMAC_KEY? crypto.createHmac('sha256', process.env.GOV_HMAC_KEY).update(chain).digest('hex'): null; fs.appendFileSync(GOV_LEDGER_FILE, JSON.stringify({ ...entry, chain_hash:chain, hmac })+'\n'); __GOV_LAST_HASH=chain; } catch(e){ console.warn('[GOV] append fail', e.message); } }
          if (req.url.startsWith('/gov/')){
            try {
              const u=new URL(req.url,'http://localhost'); const act=u.pathname.split('/')[2];
              if(act==='propose' && req.method==='POST'){
                let body=''; req.on('data',d=> body+=d); req.on('end',()=>{
                  try { const obj=JSON.parse(body||'{}'); if(!obj || !obj.type){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_type'})); }
                    const hash=govHash(obj); const seal=govSeal(hash); const rec={ ts:Date.now(), obj, hash, seal, approvals:[] };
                    global.__AUR_GOV__.proposals.set(hash, rec);
                    govAppend({ ts:Date.now(), type:'proposal', proposal:{ obj, hash, seal }, approvals:[], activatedTs:null });
                    res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, proposal: { hash, seal } }));
                  } catch(e){ res.writeHead(400); res.end(JSON.stringify({ ok:false,error:e.message })); }
                }); return;
              }
              if(act==='list'){
                const list=[...global.__AUR_GOV__.proposals.values()].map(p=>({ hash:p.hash, seal:p.seal, ts:p.ts, type:p.obj.type, approvals:p.approvals.length, activatedTs:p.activatedTs||null }));
                res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, proposals:list }));
              }
              if(act==='approve'){
                const hash=u.searchParams.get('hash'); const who=u.searchParams.get('who')||'anon'; if(!hash){ res.writeHead(400); return res.end(JSON.stringify({ ok:false,error:'missing_hash'})); }
                const rec=global.__AUR_GOV__.proposals.get(hash); if(!rec){ res.writeHead(404); return res.end(JSON.stringify({ ok:false,error:'not_found'})); }
                if(!rec.approvals.includes(who)) rec.approvals.push(who);
                const required=parseInt(process.env.GOV_REQUIRED_APPROVALS||'2',10);
                const ready = rec.approvals.length >= required;
                if(ready){
                  // Activation placeholder: would apply config change under STRICT review
                  rec.activatedTs=Date.now();
                }
                govAppend({ ts:Date.now(), type:'approve', hash, approvals:rec.approvals.slice(), activatedTs:rec.activatedTs||null });
                res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, hash, approvals:rec.approvals, ready, activatedTs: rec.activatedTs||null }));
              }
              res.writeHead(404); return res.end(JSON.stringify({ ok:false,error:'unknown_action'}));
            } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ ok:false,error:e.message })); }
          }
          snap.poolPerf = pools;
        }
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify(snap));
      } else if (req.url === '/solo-pools'){
        const pools = {};
        try {
          for (const [k,v] of (pipeline.poolPerf.map || [])){
            pools[k] = {
              jobs: v.jobs, shares: v.shares, acceptanceRatio: v.acceptanceRatio, avgJobIntervalMs: v.avgJobIntervalMs,
              confidence: v.confidence, spinWeightedScore: v.spinWeightedScore,
              backoffUntil: SOLO_POOL_BACKOFF.get(k) || null,
              lastNotifyDeltaMs: v.lastNotifyDeltaMs,
              staleShares: v.staleShares
            };
          }
        } catch(_){ }
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ t:Date.now(), pools, lastRotationReason: global.__AUR_LAST_ROTATION_REASON__ || null }));
      } else if (req.url === '/coin-intel'){
        try {
          const { listCoins } = require('./coin-intel.js');
          res.writeHead(200,{ 'Content-Type':'application/json'});
          return res.end(JSON.stringify({ t:Date.now(), coins: listCoins() }));
        } catch(e){ res.writeHead(500); return res.end(JSON.stringify({ error:'coin_intel_failure', message:e.message })); }
      } else if (req.url === '/solo-pools/flush-backoff'){
        // Manual flush: clear all backoffs or apply decay factor if ?decay=F provided
        const url = new URL(req.url, 'http://localhost');
        const decayStr = url.searchParams.get('decay');
        if (decayStr){
          const factor = Math.min(1, Math.max(0, parseFloat(decayStr)));
          const nowTs = Date.now();
          for (const [k,v] of SOLO_POOL_BACKOFF.entries()){
            if (v > nowTs){
              const remaining = v - nowTs; const newTs = nowTs + remaining * factor;
              SOLO_POOL_BACKOFF.set(k, newTs);
            }
          }
          console.log('[SoloRotate][ManualDecay] factor', factor);
        } else {
          SOLO_POOL_BACKOFF.clear(); console.log('[SoloRotate][ManualFlush] cleared backoff map');
        }
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, entries: SOLO_POOL_BACKOFF.size }));
      } else if (req.url === '/perf') {
        // Performance + economic + share efficiency snapshot
        const perf = {
          ts: Date.now(),
          hashes: pipeline.stats ? pipeline.stats.hashes : null,
          shares: pipeline.stats ? pipeline.stats.shares : null,
          ths: pipeline.stats ? pipeline.stats.ths : null,
          wasmTuner: {
            enabled: WASM_TUNER.enabled,
            batchSize: WASM_TUNER.batchSize,
            targetMs: WASM_TUNER.targetMs,
            emaLatency: WASM_TUNER.emaLatency,
            samples: WASM_TUNER.samples
          },
          adaptivePrune: pipeline.dynamicPruneThreshold || null,
          dynamicBurrowDepth: (pipeline.burrowAdapt && pipeline.burrowAdapt.enabled) ? pipeline.burrowAdapt.current : GLOBAL_BURROW_DEPTH,
          nodeCount: this.nodes ? this.nodes.length : null,
          geomCapacity: GEOM_CAPACITY,
          geomUtilization: this.nodes ? (this.nodes.length / (GEOM_CAPACITY||1)) : null,
          planeWeights: (pipeline.planeReinforce && pipeline.planeReinforce.weights) ? pipeline.planeReinforce.weights : null,
            econ: (function(){
              if (!ECON.enabled) return { enabled:false };
              return { enabled:true, state: ECON.state };
            })(),
          kawpowBatchSize: pipeline.selectedAlgo === 'kawpow' ? WASM_TUNER.batchSize : null,
          coinRecommendation: ECON.state.recommend || null,
          sharesEff: pipeline.shareStats ? {
            accepted: pipeline.shareStats.accepted,
            rejected: pipeline.shareStats.rejected,
            windowAcceptance: pipeline.shareStats.acceptanceRatio,
            emaSharesPerMin: pipeline.shareStats.emaSharesPerMin,
            instSharesPerMin: pipeline.shareStats.sharesPerMin
          } : undefined,
          configHash: CONFIG_HASH,
          geomRingTail: (this.geomRing && this.geomRing.buffer) ? this.geomRing.buffer.slice(-50) : null,
          lastTriggeredRule: this.lastTriggeredRule || null,
          ruleStats: this.ruleStats || null,
          spinPower: (function(){
            try {
              const acc = pipeline.shareStats ? (pipeline.shareStats.acceptanceRatio||0) : 0;
              const hrate = pipeline.stats && pipeline.stats.ths ? pipeline.stats.ths : 0;
              const util = (pipeline.nodes && GEOM_CAPACITY) ? (pipeline.nodes.length/GEOM_CAPACITY) : 0;
              const sp = acc * util * (hrate/1000);
              if (global.__AUR_SPIN_SAMPLES__){
                const arr = global.__AUR_SPIN_SAMPLES__;
                arr.push(sp); if (arr.length > global.__AUR_SPIN_SAMPLES_MAX__) arr.shift();
              }
              return sp;
            } catch(_){ return null; }
          })(),
          icoBlend: (function(){ try { return parseFloat(process.env.AUR_ICO_BLEND || '0.08'); } catch(_){ return null; } })()
        };
        if (this.hypercube){
          perf.hypercube = { blend: this.hypercube.blend, subsetIdx: this.hypercube.subsetIdx, rotateEvery: this.hypercube.rotateEvery };
          if (this.hypercube.activeSlice) perf.hypercube.slice = this.hypercube.activeSlice;
          // Add chernProxy if gauge sampled earlier
          try { if (global.__AUR_HYPERCUBE__ && this.hypercube.activeSlice){
            const slice = this.hypercube.activeSlice;
            const vecs = global.__AUR_HYPERCUBE__.vectors.slice(slice.start, slice.end);
            let changes=0,total=0; for (let i=1;i<vecs.length;i++){ const a=vecs[i-1], b=vecs[i]; const m=Math.min(8,a.length,b.length); for (let k=0;k<m;k++){ if (Math.sign(a[k])!==Math.sign(b[k])) changes++; total++; } }
            perf.hypercube.chernProxy = total>0? changes/total : 0;
          }} catch(_){ }
        }
        if (perf.spinPower != null && process.env.ISHE_ENABLED === '1'){
          const eff = parseFloat(process.env.ISHE_EFF || '0.10');
            perf.ishePower = perf.spinPower * eff;
        }
        // Add spin power percentiles if samples available
        if (global.__AUR_SPIN_SAMPLES__ && global.__AUR_SPIN_SAMPLES__.length){
          const cp = [...global.__AUR_SPIN_SAMPLES__].sort((a,b)=>a-b);
          function pct(p){ const i = Math.floor(p*(cp.length-1)); return cp[i]; }
          perf.spinPowerP = { p50:pct(0.50), p90:pct(0.90), p99:pct(0.99) };
        }
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify(perf));
      } else if (req.url.startsWith('/hypercube')) {
        const out = { ts: Date.now() };
        if (pipeline.hypercube && global.__AUR_HYPERCUBE__ && global.__AUR_HYPERCUBE__.vectors){
          const slice = pipeline.hypercube.activeSlice;
            out.state = { blend: pipeline.hypercube.blend, subsetIdx: pipeline.hypercube.subsetIdx, rotateEvery: pipeline.hypercube.rotateEvery };
          if (slice){
            const full = /full=1/.test(req.url);
            const rawSlice = global.__AUR_HYPERCUBE__.vectors.slice(slice.start, slice.end);
            const vecs = full ? rawSlice : rawSlice.map(v=> v.slice(0, Math.min(8, v.length))); // truncate unless full requested
            out.slice = { start: slice.start, end: slice.end, size: slice.size, vectors: vecs, truncated: full?0:1 };
          }
        }
        res.writeHead(200,{ 'Content-Type':'application/json'}); res.end(JSON.stringify(out));
      } else if (req.url === '/wallet/update' && req.method === 'POST'){
        // Update wallet and optional worker, persist in env for session, and reconnect if requested
        let body=''; req.on('data',c=> body+=c); req.on('end',()=>{
          try {
            const data = JSON.parse(body||'{}');
            const wallet = (data.wallet||'').trim();
            const worker = (data.worker||'').trim();
            const bypass = data.preflightBypass ? String(data.preflightBypass) : null;
            if (wallet){ process.env.RVN_LOCAL_ADDRESS = wallet; }
            if (worker){ process.env.AUR_DEFAULT_WORKER = worker; }
            if (bypass!=null){ process.env.RVN_PREFLIGHT_BYPASS = bypass==='1' || /^true$/i.test(bypass) ? '1':'0'; }
            if (data.reconnect){ try { pipeline.reconnectWithCurrent(); } catch(_e){} }
            res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, wallet: process.env.RVN_LOCAL_ADDRESS, worker: process.env.AUR_DEFAULT_WORKER||null, preflightBypass: process.env.RVN_PREFLIGHT_BYPASS||'0' }));
          } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'bad_json', message:e.message })); }
        });
      } else if (req.url === '/pool/update' && req.method === 'POST'){
        // Update current pool URL or host/port and reconnect
        let body=''; req.on('data',c=> body+=c); req.on('end',()=>{
          try {
            const data = JSON.parse(body||'{}');
            const url = (data.url||'').trim();
            const host = (data.host||'').trim();
            const port = parseInt(data.port,10);
            if (url){ process.env.RVN_POOL = /^stratum\+tcp:\/\//i.test(url)? url : `stratum+tcp://${url}`; }
            else if (host && port){ process.env.RVN_POOL_HOST = host; process.env.RVN_POOL_PORT = String(port); }
            pipeline.refreshRvnCandidates && pipeline.refreshRvnCandidates();
            if (data.reconnect){ try { pipeline.reconnectWithCurrent(); } catch(_e){} }
            const cand = (function(){ try { return (pipeline.selectedCoin==='rvn') ? 'rvn.2miners.com:6060 (default fallback) or custom' : `${host||''}:${port||''}`; } catch(_){ return null; } })();
            res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, rvn_pool: process.env.RVN_POOL || `${process.env.RVN_POOL_HOST||''}:${process.env.RVN_POOL_PORT||''}`, candidateHint: cand }));
          } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'bad_json', message:e.message })); }
        });
      } else if (req.url === '/wallet/info'){
        const mask = (s)=>{ try { const t=String(s||''); if (t.length<=10) return t.replace(/.(?=.{4}$)/g,'*'); return t.slice(0,4)+'***'+t.slice(-4); } catch{ return '(n/a)'; } };
        const info = {
          walletMasked: mask(process.env.RVN_LOCAL_ADDRESS || process.env.RVN_MINING_ADDRESS || process.env.RVN_PAYOUT_ADDRESS || ''),
          worker: process.env.AUR_DEFAULT_WORKER || null,
          pool: process.env.RVN_POOL || ((process.env.RVN_POOL_HOST && process.env.RVN_POOL_PORT)? `${process.env.RVN_POOL_HOST}:${process.env.RVN_POOL_PORT}`: null),
          preflightBypass: process.env.RVN_PREFLIGHT_BYPASS === '1' ? 1 : 0,
          coin: pipeline.selectedCoin,
          server: `${pipeline.poolServer||''}:${pipeline.poolPort||''}`
        };
        res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, info }));
      } else if (req.url.startsWith('/wallet/validate')){
        try {
          const url = new URL(req.url, 'http://localhost');
          const addr = (url.searchParams.get('address')||'').trim();
          const v = validateRvnAddressVerbose ? validateRvnAddressVerbose(addr) : { ok:false, reason:'validator_unavailable' };
          res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, address: addr, valid: !!v.ok, details: v }));
        } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'bad_request', message:e.message })); }
      } else if (req.url === '/wallet/ui'){
        const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>Aurrelia Wallet/Pool</title>
<style>body{font-family:system-ui,Segoe UI,Arial;margin:24px;max-width:760px}label{display:block;margin:.5rem 0 .25rem}input{width:100%;padding:.5rem;margin-bottom:.5rem}button{padding:.5rem 1rem}code{background:#f3f3f3;padding:.1rem .3rem}</style>
</head><body>
<h2>Aurrelia Wallet & Pool</h2>
<div id="info"></div>
<form id="walletForm"><h3>Update Wallet/Worker</h3>
<label>RVN Wallet</label><input id="wallet" placeholder="R..." />
<label>Worker</label><input id="worker" placeholder="R... .001" />
<label><input type="checkbox" id="bypass"/> Bypass local preflight (let pool validate)</label>
<button type="submit">Save & Reconnect</button></form>
<form id="poolForm"><h3>Update Pool</h3>
<label>Stratum URL</label><input id="url" placeholder="stratum+tcp://rvn.2miners.com:6060"/>
<button type="submit">Save & Reconnect</button></form>
<script>
async function refresh(){ try{ const r=await fetch('/wallet/info'); const j=await r.json(); document.getElementById('info').innerHTML = '<p><b>Current</b> Wallet: '+(j.info.walletMasked||'(none)')+' | Worker: '+(j.info.worker||'(none)')+' | Pool: '+(j.info.pool||'(default)')+' | Bypass: '+j.info.preflightBypass+'</p>'; }catch{}}
refresh();
document.getElementById('walletForm').addEventListener('submit', async (e)=>{ e.preventDefault(); const body={ wallet: document.getElementById('wallet').value, worker: document.getElementById('worker').value, preflightBypass: document.getElementById('bypass').checked? '1':'0', reconnect: true }; const r=await fetch('/wallet/update',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)}); const j=await r.json(); alert('Wallet saved: '+JSON.stringify(j)); refresh(); });
document.getElementById('poolForm').addEventListener('submit', async (e)=>{ e.preventDefault(); const body={ url: document.getElementById('url').value, reconnect: true }; const r=await fetch('/pool/update',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)}); const j=await r.json(); alert('Pool saved: '+JSON.stringify(j)); refresh(); });
</script>
</body></html>`;
        res.writeHead(200,{ 'Content-Type':'text/html'}); return res.end(html);
      } else if (req.url === '/pool/test' && req.method === 'POST'){
        let body=''; req.on('data',c=> body+=c); req.on('end',()=>{
          try {
            const data = JSON.parse(body||'{}');
            const urlLike = (data.url||'').trim();
            const host = (data.host||'').trim();
            let port = parseInt(data.port,10);
            let targetHost = host, targetPort = port;
            if (urlLike){
              const x = urlLike.replace(/^stratum\+tcp:\/\//i,'').replace(/^stratum:\/\//i,'').replace(/^tcp:\/\//i,'');
              const m = x.match(/^([^:]+):(\d{2,5})$/); if (m){ targetHost = m[1]; targetPort = parseInt(m[2],10); }
            }
            if (!targetHost || !targetPort){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'missing_target' })); }
            const net = require('net');
            const timeoutMs = parseInt(process.env.ECON_PREFLIGHT_TIMEOUT_MS || '2000',10);
            const started = Date.now();
            const s = net.createConnection({ host: targetHost, port: targetPort },()=>{ const latency=Date.now()-started; s.end(); res.writeHead(200,{ 'Content-Type':'application/json'}); return res.end(JSON.stringify({ ok:true, host:targetHost, port:targetPort, latencyMs:latency })); });
            s.setTimeout(timeoutMs,()=>{ s.destroy(); res.writeHead(504); return res.end(JSON.stringify({ ok:false, error:'timeout', host:targetHost, port:targetPort })); });
            s.on('error',err=>{ res.writeHead(502); return res.end(JSON.stringify({ ok:false, error:'connect_error', message: err && err.message || String(err), host:targetHost, port:targetPort })); });
          } catch(e){ res.writeHead(400); return res.end(JSON.stringify({ ok:false, error:'bad_json', message:e.message })); }
        });
      } else if (req.url === '/metrics') {
        initProm();
        if (registry){
          try {
            if (gauges.batchSize) gauges.batchSize.set(WASM_TUNER.batchSize);
            if (gauges.emaLatency && WASM_TUNER.emaLatency!=null) gauges.emaLatency.set(WASM_TUNER.emaLatency);
            if (gauges.sharesAccepted) gauges.sharesAccepted.reset && gauges.sharesAccepted.reset(); // counter - avoid double count export
            if (gauges.sharesRejected) gauges.sharesRejected.reset && gauges.sharesRejected.reset();
            // Instead of incrementing (to avoid persistence complexity), set via Gauge for snapshot counters
            if (!gauges.snapAccepted){ gauges.snapAccepted = new prom.Gauge({ name:'aurrelia_shares_accepted_snapshot', help:'Accepted shares snapshot' }); registry.registerMetric(gauges.snapAccepted);} 
            if (!gauges.snapRejected){ gauges.snapRejected = new prom.Gauge({ name:'aurrelia_shares_rejected_snapshot', help:'Rejected shares snapshot' }); registry.registerMetric(gauges.snapRejected);} 
            gauges.snapAccepted.set(pipeline.shareStats.accepted);
            gauges.snapRejected.set(pipeline.shareStats.rejected);
            if (gauges.acceptanceRatio) gauges.acceptanceRatio.set(pipeline.shareStats.acceptanceRatio || 0);
            if (gauges.acceptanceHist && pipeline.shareStats && pipeline.shareStats.acceptanceRatio!=null){ try { gauges.acceptanceHist.observe(pipeline.shareStats.acceptanceRatio); } catch(_e){} }
            if (gauges.acceptP50 && global.__AUR_ACCEPT_Q && global.__AUR_ACCEPT_Q.p50!=null){ gauges.acceptP50.set(global.__AUR_ACCEPT_Q.p50); }
            if (gauges.acceptP90 && global.__AUR_ACCEPT_Q && global.__AUR_ACCEPT_Q.p90!=null){ gauges.acceptP90.set(global.__AUR_ACCEPT_Q.p90); }
            if (gauges.acceptP99 && global.__AUR_ACCEPT_Q && global.__AUR_ACCEPT_Q.p99!=null){ gauges.acceptP99.set(global.__AUR_ACCEPT_Q.p99); }
            if (gauges.normThreshold && global.__AUR_NORM_THRESHOLD!=null){ gauges.normThreshold.set(global.__AUR_NORM_THRESHOLD); }
            // ECON autoswitch gauges (active coin & cooldown) – use persisted globals
            if (gauges.econActive && __ECON_ACTIVE_COIN){
              const codeMap = { btc:0, rvn:1, kas:2, fren:3 };
              const num = codeMap[__ECON_ACTIVE_COIN] != null ? codeMap[__ECON_ACTIVE_COIN] : 0;
              try { gauges.econActive.set({ coin: __ECON_ACTIVE_COIN }, num); } catch(_e){}
            }
            if (gauges.econCooldown){
              const cdMs = Math.max(0, ECON_SWITCH_COOLDOWN_MS - (Date.now() - __ECON_LAST_SWITCH));
              gauges.econCooldown.set(cdMs/1000);
            }
            if (gauges.emaSharesPerMin && pipeline.shareStats.emaSharesPerMin!=null) gauges.emaSharesPerMin.set(pipeline.shareStats.emaSharesPerMin);
            if (gauges.hashes) gauges.hashes.reset && gauges.hashes.reset();
            if (!gauges.hashesSnap){ gauges.hashesSnap = new prom.Gauge({ name:'aurrelia_hashes_snapshot', help:'Total hashes snapshot' }); registry.registerMetric(gauges.hashesSnap);} 
            gauges.hashesSnap.set(pipeline.stats.hashes);
            if (gauges.ths){ const thsVal = parseFloat(pipeline.stats.ths)||0; gauges.ths.set(thsVal); }
            // Extended gauges population
            if (gauges.spinPower){
              try {
                const acc = pipeline.shareStats ? (pipeline.shareStats.acceptanceRatio||0) : 0;
                const hrate = pipeline.stats && pipeline.stats.ths ? pipeline.stats.ths : 0; // use TH/s not raw hash count
                const alpha = (pipeline.nodes && GEOM_CAPACITY) ? (pipeline.nodes.length / GEOM_CAPACITY) : 0;
                const sp = acc * alpha * (hrate/1000); // scaled
                gauges.spinPower.set(sp);
                if (gauges.spinPowerHist) gauges.spinPowerHist.observe(sp);
              } catch(_){}
            }
            if (gauges.geomCapacity && GEOM_CAPACITY) gauges.geomCapacity.set(GEOM_CAPACITY);
            if (gauges.geomNodesMax){ const maxN = parseInt(process.env.NODE_GROWTH_MAX || '65536',10); gauges.geomNodesMax.set(maxN); }
            if (gauges.burrowDepth && pipeline.burrowAdapt && pipeline.burrowAdapt.enabled){ gauges.burrowDepth.set(pipeline.burrowAdapt.current); }
            if (gauges.nodeCount){ gauges.nodeCount.set(pipeline && pipeline.nodes ? pipeline.nodes.length : (global.__AUR_NODE_COUNT__||0)); }
            if (gauges.nodeGrowthAttempts && global.__AUR_NODE_GROWTH__){ gauges.nodeGrowthAttempts.inc(0); gauges.nodeGrowthPending.set(global.__AUR_NODE_GROWTH__.pending.length); }
            if (global.__AUR_NODE_GROWTH__ && global.__AUR_NODE_GROWTH__.lastReportCycle !== pipeline.cycleCount){
              // Update kept/reverted counters deterministically
              const NG = global.__AUR_NODE_GROWTH__;
              if (gauges.nodeGrowthKept && NG._reportedKept !== NG.kept){ gauges.nodeGrowthKept.inc(NG.kept - (NG._reportedKept||0)); NG._reportedKept = NG.kept; }
              if (gauges.nodeGrowthReverted && NG._reportedReverted !== NG.reverted){ gauges.nodeGrowthReverted.inc(NG.reverted - (NG._reportedReverted||0)); NG._reportedReverted = NG.reverted; }
              if (gauges.nodeGrowthAttempts && NG._reportedAttempts !== NG.attempts){ gauges.nodeGrowthAttempts.inc(NG.attempts - (NG._reportedAttempts||0)); NG._reportedAttempts = NG.attempts; }
              NG.lastReportCycle = pipeline.cycleCount;
            }
            if (gauges.geomUtil){ const util = (pipeline && pipeline.nodes) ? (pipeline.nodes.length / (GEOM_CAPACITY||1)) : 0; gauges.geomUtil.set(util); }
            if (gauges.hypercubeBlend && pipeline.hypercube){
              // Adaptive blend: if acceptance < 0.60 gently raise, if spinGap ratio >1.6 lower
              try {
                const acc = pipeline.shareStats.acceptanceRatio || 0;
                let blend = pipeline.hypercube.blend;
                if (acc < 0.60) blend = Math.min(blend * 1.05 + 0.002, 0.25);
                // Suppress or widen based on stored spinGapRatio from ruleStats.spin.gapRatio
                const sgr = pipeline.spinGapRatio;
                if (sgr != null){
                  const target = parseFloat(process.env.RASHBA_TARGET_GAP || '0.35');
                  if (sgr > target * 1.3) blend = Math.max(0.01, blend * 0.90 - 0.002);
                  else if (sgr < target * 0.75) blend = Math.min(0.25, blend * 1.04 + 0.002);
                }
                // Structured agent actions (blend + indirect prune influence)
                if (global.__AUR_LAST_AGENT_SUGGEST__){
                  const act = global.__AUR_LAST_AGENT_SUGGEST__;
                  if (act.action === 'adjust_blend' && typeof act.delta === 'number'){
                    const d = Math.max(-0.06, Math.min(0.06, act.delta));
                    const before = blend;
                    blend = Math.min(0.30, Math.max(0.005, blend + d));
                    if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] adjust_blend delta', d.toFixed(5), 'before', before.toFixed(5), 'after', blend.toFixed(5));
                  } else if (act.action === 'adjust_prune' && typeof act.delta === 'number'){
                    // prune delta softly nudges blend (exploration coupling)
                    const damp = Math.max(-0.05, Math.min(0.05, act.delta))*0.3;
                    const before = blend;
                    blend = Math.min(0.30, Math.max(0.005, blend + damp));
                    if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] adjust_prune->blend damp', damp.toFixed(5), 'before', before.toFixed(5), 'after', blend.toFixed(5));
                  }
                }
                pipeline.hypercube.blend = blend;
                gauges.hypercubeBlend.set(blend);
              } catch(_){ gauges.hypercubeBlend.set(pipeline.hypercube.blend); }
            }
            if (gauges.hypercubeSubset && pipeline.hypercube){ gauges.hypercubeSubset.set(pipeline.hypercube.subsetIdx); }
            if (gauges.hypercubeSliceSize && pipeline.hypercube && pipeline.hypercube.activeSlice){ gauges.hypercubeSliceSize.set(pipeline.hypercube.activeSlice.size); }
            if (gauges.chernProxy && pipeline.hypercube && pipeline.hypercube.activeSlice && global.__AUR_HYPERCUBE__){
              try {
                const slice = pipeline.hypercube.activeSlice;
                const vecs = global.__AUR_HYPERCUBE__.vectors.slice(slice.start, slice.end);
                let changes = 0; let total = 0;
                for (let i=1;i<vecs.length;i++){
                  const a = vecs[i-1]; const b = vecs[i];
                  const m = Math.min(8, a.length, b.length);
                  for (let k=0;k<m;k++){ if (Math.sign(a[k]) !== Math.sign(b[k])) changes++; total++; }
                }
                const density = total>0 ? changes/total : 0;
                gauges.chernProxy.set(density);
              } catch(_){ }
            }
            if (gauges.mlLatency && pipeline.lastMlLatencyMs != null){ gauges.mlLatency.set(pipeline.lastMlLatencyMs); if (gauges.mlLatencyHist){ gauges.mlLatencyHist.observe(pipeline.lastMlLatencyMs); } }
            if (gauges.mlLatencyP50 && pipeline.mlLatencyP50 != null){ gauges.mlLatencyP50.set(pipeline.mlLatencyP50); }
            if (gauges.mlLatencyP90 && pipeline.mlLatencyP90 != null){ gauges.mlLatencyP90.set(pipeline.mlLatencyP90); }
            if (gauges.mlLatencyP99 && pipeline.mlLatencyP99 != null){ gauges.mlLatencyP99.set(pipeline.mlLatencyP99); }
            try { if (pipeline.ruleStats && pipeline.ruleStats.spin && pipeline.ruleStats.spin.gapRatio){ pipeline.spinGapRatio = pipeline.ruleStats.spin.gapRatio; } } catch(_){ }
            // Spin percentiles for adaptive Rashba (if samples present)
            if (global.__AUR_SPIN_SAMPLES__ && global.__AUR_SPIN_SAMPLES__.length >= 8){
              const cp = [...global.__AUR_SPIN_SAMPLES__].sort((a,b)=>a-b);
              const p50 = cp[Math.floor(0.50*(cp.length-1))];
              const p90 = cp[Math.floor(0.90*(cp.length-1))];
              const gap = p90 - p50;
              if (gauges.spinGap) gauges.spinGap.set(gap);
              if (gauges.rashbaTargetGap || gauges.rashbaGapRatio){
                const avg = cp.reduce((a,b)=>a+b,0)/cp.length;
                const targetGap = avg * 0.25;
                if (gauges.rashbaTargetGap) gauges.rashbaTargetGap.set(targetGap);
                if (gauges.rashbaGapRatio && targetGap>0) gauges.rashbaGapRatio.set(gap/targetGap);
              }
              if (process.env.RASHBA_ADAPT === '1' && global.__AUR_SPIN_SAMPLES__.length >= 32){
                const now = Date.now();
                if (now - (global.__AUR_RASHBA_LAST_ADAPT__||0) > 15000){
                  const avg = cp.reduce((a,b)=>a+b,0)/cp.length;
                  const targetGap = avg * 0.25; // heuristic anchor
                  const current = global.__AUR_RASHBA_GAIN__ || parseFloat(process.env.RASHBA_GAIN || '0.15');
                  let next = current;
                  if (gap < targetGap*0.7) next = Math.min(current * 1.08 + 0.005, 0.60);
                  else if (gap > targetGap*1.4) next = Math.max(current * 0.90 - 0.005, 0.02);
                  // Structured agent action (burrowAdapt -> adjust_prune OR mlLatencyMitigate -> adjust_latency_budget) and Rashba plane weight tuning
                  if (global.__AUR_LAST_AGENT_SUGGEST__){
                    const act = global.__AUR_LAST_AGENT_SUGGEST__;
                    if (act.action === 'adjust_prune' && typeof act.delta === 'number'){
                      // Map prune delta into Rashba gain subtle tweak (shared adaptive substrate)
                      const before = next;
                      const adj = Math.max(-0.05, Math.min(0.05, act.delta));
                      next = Math.min(0.70, Math.max(0.015, next + adj*0.5));
                      if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] adjust_prune->rashbaGain delta', adj.toFixed(5), 'before', before.toFixed(5), 'after', next.toFixed(5));
                      if (pipeline && pipeline.dynamicPruneThreshold){
                        const pBefore = pipeline.dynamicPruneThreshold;
                        const pAdj = adj * 0.6;
                        pipeline.dynamicPruneThreshold = Math.min(pipeline.pruneMax || pBefore+1, Math.max(pipeline.pruneMin || 1.0, pBefore + pAdj));
                        if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] dynamicPruneThreshold', pBefore.toFixed(4),'->', pipeline.dynamicPruneThreshold.toFixed(4),'adj', pAdj.toFixed(5));
                      }
                    } else if (act.action === 'skew_plane_weights' && typeof act.delta === 'number'){
                      // plane weight skew influences targetGap scaling
                      const skew = Math.max(-0.06, Math.min(0.06, act.delta));
                      if (!global.__AUR_PLANE_WEIGHT_SKEW__) global.__AUR_PLANE_WEIGHT_SKEW__ = 0;
                      const beforeSkew = global.__AUR_PLANE_WEIGHT_SKEW__;
                      global.__AUR_PLANE_WEIGHT_SKEW__ = Math.max(-0.25, Math.min(0.25, beforeSkew + skew));
                      if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] skew_plane_weights delta', skew.toFixed(5), 'accum', global.__AUR_PLANE_WEIGHT_SKEW__.toFixed(5));
                    } else if (act.action === 'adjust_latency_budget' && typeof act.delta === 'number'){
                      // Latency budget influences ML skip threshold (stored scalar)
                      const adj = Math.max(-0.20, Math.min(0.20, act.delta));
                      if (!global.__AUR_ML_LAT_BUDGET__) global.__AUR_ML_LAT_BUDGET__ = parseFloat(process.env.ML_LAT_BASE || '120');
                      const beforeB = global.__AUR_ML_LAT_BUDGET__;
                      global.__AUR_ML_LAT_BUDGET__ = Math.min(500, Math.max(30, beforeB + adj*50));
                      if (process.env.AGENT_ACTION_LOG==='1') console.log('[AgentAction] adjust_latency_budget delta', adj.toFixed(5), 'before', beforeB.toFixed(2), 'after', global.__AUR_ML_LAT_BUDGET__.toFixed(2));
                    }
                  }
                  if (Math.abs(next - current) > 0.0005){ global.__AUR_RASHBA_GAIN__ = next; global.__AUR_RASHBA_LAST_ADAPT__ = now; }
                }
              }
            }
            if (gauges.rashbaGain && typeof global.__AUR_RASHBA_GAIN__ === 'number') gauges.rashbaGain.set(global.__AUR_RASHBA_GAIN__);
            if (gauges.isheEff) gauges.isheEff.set(parseFloat(process.env.ISHE_EFF || '0.10'));
            // ML model signature gauge refresh (recompute if file mtime changes)
            if (gauges.mlModelSignature){
              try {
                const fs = require('fs');
                const sigPath = process.env.TRT_ENGINE_PATH || process.env.CORAL_MODEL_PATH;
                if (sigPath && fs.existsSync(sigPath)){
                  const st = fs.statSync(sigPath);
                  if (!global.__AUR_ML_MODEL_SIG_STATE__ || global.__AUR_ML_MODEL_SIG_STATE__.mtimeMs !== st.mtimeMs){
                    const buf = fs.readFileSync(sigPath);
                    const h = crypto.createHash('sha256').update(buf).digest('hex');
                    gauges.mlModelSignature.set(parseInt(h.slice(0,12),16) % 1e9);
                    if (!global.__AUR_AGENT_STATS__) global.__AUR_AGENT_STATS__ = { count:0, lastSig:null };
                    global.__AUR_AGENT_STATS__.mlModelHex = h.slice(0,32);
                    global.__AUR_ML_MODEL_SIG_STATE__ = { mtimeMs: st.mtimeMs, hex: h };
                    if (process.env.ML_MODEL_SIG_LOG==='1') console.log('[ML][Signature] refreshed', h.slice(0,32));
                  }
                }
              } catch(e){ /* ignore */ }
            }
            // Spin sample ring maintenance (trim while preserving distribution)
            if (global.__AUR_SPIN_SAMPLES__ && global.__AUR_SPIN_SAMPLES__.length > 4000){
              try {
                const arr = global.__AUR_SPIN_SAMPLES__;
                // Keep recent 1000 + stratified 1000 from earlier portion
                const recent = arr.slice(-1000);
                const older = arr.slice(0, arr.length - 1000);
                const stride = Math.max(1, Math.floor(older.length / 1000));
                const strat = [];
                for (let i=0;i<older.length && strat.length<1000;i+=stride){ strat.push(older[i]); }
                global.__AUR_SPIN_SAMPLES__ = strat.concat(recent);
                if (process.env.SPIN_RING_LOG==='1') console.log('[SpinRing] trimmed samples from', arr.length, 'to', global.__AUR_SPIN_SAMPLES__.length);
              } catch(e){ /* ignore */ }
            }
            // Additional stratified maintenance for moderate growth >512
            if (global.__AUR_SPIN_SAMPLES__ && global.__AUR_SPIN_SAMPLES__.length > 512 && global.__AUR_SPIN_SAMPLES__.length <= 4000){
              try {
                const arr = global.__AUR_SPIN_SAMPLES__;
                const recent = arr.slice(-256);
                const older = arr.slice(0, arr.length - 256);
                const stride = Math.max(1, Math.floor(older.length / 256));
                const strat = [];
                for (let i=0;i<older.length && strat.length<256;i+=stride){ strat.push(older[i]); }
                global.__AUR_SPIN_SAMPLES__ = strat.concat(recent);
              } catch(e){ /* ignore */ }
            }
            if (ECON.enabled && ECON.state && ECON.state.price && ECON.state.diff){
              let btcScore=null, rvnScore=null, kasScore=null;
              if (ECON.state.price.btc && ECON.state.diff.btc) btcScore = ECON.state.price.btc / ECON.state.diff.btc;
              if (ECON.state.price.rvn && ECON.state.diff.rvn) rvnScore = ECON.state.price.rvn / ECON.state.diff.rvn;
              if (ECON.state.price.kas && ECON.state.diff.kas) kasScore = ECON.state.price.kas / ECON.state.diff.kas;
              // econScore gauge: use btc/rvn ratio if both exist, else btc/average(other)
              if (gauges.econScore){
                let ratio = 0;
                if (btcScore!=null && rvnScore!=null) ratio = rvnScore ? btcScore/rvnScore : 0;
                else if (btcScore!=null && kasScore!=null) ratio = kasScore ? btcScore/kasScore : 0;
                gauges.econScore.set(ratio);
              }
              if (gauges.recommend){
                let val = 0; // default btc
                if (ECON.state.recommend==='rvn') val=1; else if (ECON.state.recommend==='kas') val=2; else if (ECON.state.recommend==='fren') val=4;
                gauges.recommend.set(val);
              }
              if (gauges.coinActive){
                let active = 0;
                const c = pipeline.selectedCoin;
                if (c==='rvn') active=1; else if (c==='kas') active=2; else if (c==='ltc') active=3; else if (c==='fren') active=4;
                gauges.coinActive.set(active);
              }
              if (gauges.econCooldown){
                const cdMs = Math.max(0, (__ECON_LAST_SWITCH_COOLDOWN_MS||ECON_SWITCH_COOLDOWN_MS) - (Date.now() - __ECON_LAST_SWITCH));
                gauges.econCooldown.set(cdMs/1000);
              }
            }
            // Structured metrics flush log (throttled every 60s)
            if (!global.__AUR_LAST_METRICS_LOG__ || Date.now() - global.__AUR_LAST_METRICS_LOG__ > 60000){
              econStructuredLog('metrics_flush', {
                hashes: pipeline.stats.hashes,
                ths: pipeline.stats.ths,
                accept: pipeline.shareStats.acceptanceRatio,
                coin: pipeline.selectedCoin,
                normThreshold: global.__AUR_NORM_THRESHOLD,
                econReason: __ECON_LAST_SWITCH_REASON,
                cooldownRemainingSec: Math.max(0, ((__ECON_LAST_SWITCH_COOLDOWN_MS||ECON_SWITCH_COOLDOWN_MS) - (Date.now()-__ECON_LAST_SWITCH))/1000)
              });
              global.__AUR_LAST_METRICS_LOG__ = Date.now();
            }
            res.writeHead(200, { 'Content-Type': registry.contentType });
            registry.metrics().then(m=> res.end(m));
          } catch(e){ res.writeHead(500); res.end('metrics error '+e.message); }
        } else { res.writeHead(404); res.end('metrics unavailable'); }
      } else { res.writeHead(404); res.end('not found'); }
    }).listen(selfPort, ()=> console.log('[SelfCheck] HTTP endpoint listening on', selfPort));
  }
  // Self-check command interface: if SELF_CHECK=1 print adaptive snapshot once then exit
  if (process.env.SELF_CHECK === '1'){
    setTimeout(()=>{
      const snap = {
        parityInterval: pipeline.fusedParityInterval,
        batchSize: pipeline.currentBatchSize,
        rampActive: pipeline.fusedRampActive,
        rampTarget: pipeline.fusedRampTarget,
        speedupEst: (global.__AUR_WASM_METRICS__ && global.__AUR_WASM_METRICS__.fusedSpeedupEst) || 0,
        latencyCv: (global.__AUR_WASM_METRICS__ && global.__AUR_WASM_METRICS__.fusedLatencyCv) || 0,
        recoverAttempts: (global.__AUR_WASM_METRICS__ && global.__AUR_WASM_METRICS__.fusedRecoverAttempts) || 0,
        recoverSuccesses: (global.__AUR_WASM_METRICS__ && global.__AUR_WASM_METRICS__.fusedRecoverSuccesses) || 0,
        recoverFailures: (global.__AUR_WASM_METRICS__ && global.__AUR_WASM_METRICS__.fusedRecoverFailures) || 0
      };
      console.log('[SELF_CHECK]', JSON.stringify(snap));
      process.exit(0);
    }, 2000);
  }
  // Single-worker graceful shutdown
  process.on('SIGINT', () => process.exit(0));
}

// Optional exports for external tooling (reload CIDs, etc.)

// End of aurrelia-pico-mesh-miner.js

// --- Repro cycle finalizer (injected) ---
try {
  if (__REPRO_CYCLE_LIMIT>0){
    // Attach periodic cycle increment to main pipeline tick if present
    if (global.pipeline && typeof global.pipeline.tick === 'function' && !global.pipeline.__reproWrapped){
      const origTick = global.pipeline.tick.bind(global.pipeline);
      global.pipeline.tick = function reproWrappedTick(){
        const ret = origTick();
        __REPRO_CYCLE_COUNT++;
        if (__REPRO_CYCLE_COUNT <= __REPRO_CYCLE_LIMIT){
          __reproDigestUpdate('cycle', { c: __REPRO_CYCLE_COUNT, coin: this.selectedCoin, acc: this.shareStats?.acceptanceRatio||null });
        }
        if (__REPRO_CYCLE_COUNT === __REPRO_CYCLE_LIMIT){
          __reproDigestUpdate('final', { cycles: __REPRO_CYCLE_COUNT });
          __reproPersistState();
          console.log(`[REPRO] limit reached cycles=${__REPRO_CYCLE_COUNT} digest=${__REPRO_DIGEST_CHAIN}`);
          process.exit(0);
        }
        return ret;
      };
      global.pipeline.__reproWrapped = true;
      console.log(`[REPRO] cycle limit active limit=${__REPRO_CYCLE_LIMIT}`);
    }
  }
} catch(e){ console.warn('[REPRO] finalizer error', e.message); }


// Safe export (avoid shadowing if symbols missing)
module.exports = {
  PicoCrystalTuner: (typeof PicoCrystalTuner !== 'undefined') ? PicoCrystalTuner : (global.PicoCrystalTuner || null),
  RomanDecoderWheel: (typeof RomanDecoderWheel !== 'undefined') ? RomanDecoderWheel : (global.RomanDecoderWheel || null),
  SimpleOcto: (typeof SimpleOcto !== 'undefined') ? SimpleOcto : (global.SimpleOcto || null)
};