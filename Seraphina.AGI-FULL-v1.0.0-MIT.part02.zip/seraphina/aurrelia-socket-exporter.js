// aurrelia-socket-exporter.js
// Unix domain socket / Windows named pipe low-latency exporter for merged metrics.
// Usage (Unix): node aurrelia-socket-exporter.js --file=aurrelia-metrics-merged.jsonl --socket=/tmp/aurrelia.sock
// On Windows: --pipe=\\\\.\\pipe\\aurrelia_metrics

const fs = require('fs');
const net = require('net');
const os = require('os');
const args = process.argv.slice(2);
function getArg(n,d){ const a=args.find(x=>x.startsWith(`--${n}=`)); return a? a.split('=')[1]: d; }
const file = getArg('file','aurrelia-metrics-merged.jsonl');
const socketPath = getArg('socket','');
const pipeName = getArg('pipe','');
const intervalMs = parseInt(getArg('interval','2000'),10);
let lastSize=0;
function readNew(){
  try { const data=fs.readFileSync(file,'utf8'); if (data.length===lastSize) return []; const slice=data.slice(lastSize); lastSize=data.length; return slice.split(/\n/).filter(Boolean); } catch(_){ return []; }
}
function startServerUnix(){
  if (fs.existsSync(socketPath)) try { fs.unlinkSync(socketPath); } catch(_){ }
  const server = net.createServer((conn)=>{
    conn.write('{"stream":"aurrelia","schema":"metrics-v2"}\n');
    const timer = setInterval(()=>{
      const lines = readNew();
      for (const l of lines) conn.write(l+'\n');
    }, intervalMs);
    conn.on('close',()=> clearInterval(timer));
  });
  server.listen(socketPath, ()=> console.log('[SocketExporter] listening on', socketPath));
}
function startServerPipe(){
  const server = net.createServer((conn)=>{
    conn.write('{"stream":"aurrelia","schema":"metrics-v2"}\n');
    const timer = setInterval(()=>{ const lines=readNew(); for (const l of lines) conn.write(l+'\n'); }, intervalMs);
    conn.on('close',()=> clearInterval(timer));
  });
  server.listen(pipeName, ()=> console.log('[SocketExporter] listening on pipe', pipeName));
}
if (socketPath) startServerUnix(); else if (pipeName) startServerPipe(); else console.error('Provide --socket or --pipe');
