// benchmark-seraphina-train.js
// Compares loop vs vectorized training runtime for Seraphina logistic model.
// Usage: node benchmark-seraphina-train.js

const { run: trainRun } = require('./seraphina-model-train.js');
const fs = require('fs');

function synthDataset(path, n){
  const lines=[];
  for(let i=0;i<n;i++){
    lines.push(JSON.stringify({ personality:{ ethical_alignment: Math.random(), empathy:Math.random() }, econSignals:{ frenRevenueNorm: Math.random(), marketVolatility:Math.random(), demandIndex:Math.random() }, vector:[Math.random(),Math.random(),Math.random(),Math.random(),Math.random(),Math.random()] }));
  }
  fs.writeFileSync(path, lines.join('\n'));
}

function time(fn){ const s=process.hrtime.bigint(); const r=fn(); const e=process.hrtime.bigint(); return { r, ms: Number(e-s)/1e6 }; }

function benchmark(){
  const path='bench-train-dataset.jsonl';
  const N = parseInt(process.env.BENCH_TRAIN_N || '15000',10);
  const RUNS = parseInt(process.env.BENCH_TRAIN_RUNS || '1',10);
  synthDataset(path,N);
  process.env.SERAPHINA_DATASET_PATH=path;
  process.env.MAX_RESERVOIR='0';
  // Ensure large streaming dataset env vars disabled for consistency
  delete process.env.SERAPHINA_LARGE_DATASET_PATH;
  delete process.env.SERAPHINA_STREAM_RESERVOIR_SIZE;
  delete process.env.SERAPHINA_STREAM_SAMPLE_PCT;
  const loopTimes=[]; const vecTimes=[]; let accLoop=0; let accVec=0;
  for(let r=0;r<RUNS;r++){
    delete process.env.SERAPHINA_VECTORIZE; const lr = time(()=> trainRun()); loopTimes.push(lr.ms); accLoop = lr.r?.scoreboard?.acc || accLoop;
    process.env.SERAPHINA_VECTORIZE='1'; const vr = time(()=> trainRun()); vecTimes.push(vr.ms); accVec = vr.r?.scoreboard?.acc || accVec;
  }
  function stats(arr){ const mean = arr.reduce((a,b)=>a+b,0)/arr.length; const varc = arr.reduce((a,b)=>a+(b-mean)**2,0)/arr.length; return { mean, sd: Math.sqrt(varc) }; }
  const stLoop = stats(loopTimes); const stVec = stats(vecTimes);
  const out = { N, runs: RUNS, loop_ms_mean: stLoop.mean, loop_ms_sd: stLoop.sd, vector_ms_mean: stVec.mean, vector_ms_sd: stVec.sd, speedup_mean: stLoop.mean/stVec.mean, acc_loop: accLoop, acc_vec: accVec };
  console.log('[BenchmarkTrain]', JSON.stringify(out));
  fs.writeFileSync('benchmark-train-results.json', JSON.stringify(out,null,2));
}

if(require.main===module){ benchmark(); }
