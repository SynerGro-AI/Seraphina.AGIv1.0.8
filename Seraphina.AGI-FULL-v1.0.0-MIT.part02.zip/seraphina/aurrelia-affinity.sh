#!/usr/bin/env bash
# aurrelia-affinity.sh
# Simple helper to launch N cluster instances with CPU core pinning on Linux.
# Requires: taskset (util-linux). Adjust CORE_STRIDE or mapping as needed.
# Example: ./aurrelia-affinity.sh 8 "node aurrelia-cluster.js --instances=8 --base-seed=5000 -- --algo=sha256d --url=... --user=... --pass=x"

set -euo pipefail
COUNT=${1:-8}
shift || true
CMD="$@"
if [[ -z "$CMD" ]]; then
  echo "Usage: $0 <instances> <command-with-args>" >&2
  exit 1
fi

echo "[Affinity] Launching $COUNT instances (logical separation)"
for i in $(seq 0 $((COUNT-1))); do
  CORE=$i
  echo "[Affinity] taskset core $CORE -> instance $i"
  # Each instance gets AUR_SEED offset and instance index env
  (AUR_SEED=$((42 + i)) AUR_INSTANCE_INDEX=$i taskset -c $CORE $CMD &) 
  sleep 0.2
done

wait
