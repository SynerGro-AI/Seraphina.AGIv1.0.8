const fs = require('fs');
const crypto = require('crypto');

/**
 * LatticeSecurityManager
 * ----------------------
 * Provides tamper-evident hashing and persistence for the 8x8x8 crystal lattice.
 * Every learned node (and optionally firing event) is appended as a chain element:
 *   hash = sha256(prevHash + nodeId + layer + position + spectral|type + ts + kind)
 * A JSONL ledger (default: lattice-chain.jsonl) plus a head file persists continuity.
 * Verification replays the chain and sets compromised=true if a break is detected.
 */
class LatticeSecurityManager {
  constructor(options={}){
    this.ledgerPath = options.ledgerPath || 'lattice-chain.jsonl';
    this.headPath = options.headPath || 'lattice-chain-head.json';
    this.autoFlush = options.autoFlush !== false;
    this.cache = []; // pending entries before flush
    this.head = { height: 0, hash: 'GENESIS', compromised: false, lastTs: 0 };
    this._loadHead();
  }

  _loadHead(){
    try {
      if(fs.existsSync(this.headPath)){
        const data = JSON.parse(fs.readFileSync(this.headPath,'utf8'));
        if(data && data.hash) this.head = data;
      }
    } catch(e){ /* ignore */ }
  }

  _persistHead(){
    try { fs.writeFileSync(this.headPath, JSON.stringify(this.head,null,2)); } catch(e){/* ignore */}
  }

  _hashEntry(entry){
    const h = crypto.createHash('sha256');
    h.update(String(entry.prevHash||''));
    h.update(entry.nodeId||'');
    h.update(String(entry.layer));
    h.update((entry.position||[]).join(','));
    h.update(entry.spectral||entry.type||'');
    h.update(String(entry.ts));
    h.update(entry.kind||'learned');
    return h.digest('hex');
  }

  recordLearnedNode(node){
    const ts = Date.now();
    const entry = {
      kind: 'learned',
      nodeId: node.id,
      layer: node.layer,
      position: node.position,
      spectral: node.knowledge && node.knowledge.spectral,
      prevHash: this.head.hash,
      height: this.head.height + 1,
      ts
    };
    entry.hash = this._hashEntry(entry);
    this.head = { height: entry.height, hash: entry.hash, compromised: false, lastTs: ts };
    this.cache.push(entry);
    if(this.autoFlush) this.flush(); else this._persistHead();
    return entry.hash;
  }

  recordFiring(node){
    const ts = Date.now();
    const entry = {
      kind: 'fire',
      nodeId: node.id,
      layer: node.layer,
      position: node.position,
      type: node.knowledge && node.knowledge.type,
      prevHash: this.head.hash,
      height: this.head.height + 1,
      ts
    };
    entry.hash = this._hashEntry(entry);
    this.head = { height: entry.height, hash: entry.hash, compromised: false, lastTs: ts };
    this.cache.push(entry);
    if(this.autoFlush && this.cache.length >= 5) this.flush(); else this._persistHead();
    return entry.hash;
  }

  flush(){
    if(!this.cache.length) return;
    try {
      const lines = this.cache.map(e=>JSON.stringify(e)).join('\n') + '\n';
      fs.appendFileSync(this.ledgerPath, lines);
      this.cache = [];
      this._persistHead();
    } catch(e){ /* ignore */ }
  }

  verify(){
    try {
      if(!fs.existsSync(this.ledgerPath)) return { ok:true, height:this.head.height, head:this.head.hash };
      const lines = fs.readFileSync(this.ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean);
      let prev = 'GENESIS';
      let height = 0;
      for(const line of lines){
        const entry = JSON.parse(line);
        const expected = this._hashEntry(entry);
        if(expected !== entry.hash || entry.prevHash !== prev){
          this.head.compromised = true;
          return { ok:false, breakHeight:entry.height, expected, found:entry.hash };
        }
        prev = entry.hash; height = entry.height;
      }
      return { ok:true, height, head: prev };
    } catch(e){ return { ok:false, error:e.message }; }
  }
}

module.exports = { LatticeSecurityManager };
