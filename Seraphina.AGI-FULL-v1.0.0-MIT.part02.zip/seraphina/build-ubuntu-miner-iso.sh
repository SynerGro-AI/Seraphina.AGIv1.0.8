#!/usr/bin/env bash
# Build customized Ubuntu 24.04 live server ISO with embedded Seraphina miner (autoinstall).
# Usage: sudo bash build-ubuntu-miner-iso.sh ubuntu-24.04.3-live-server-amd64.iso /path/to/mining
set -euo pipefail
ORIG_ISO=${1:-ubuntu-24.04.3-live-server-amd64.iso}
MINER_SRC=${2:-$(pwd)}
WORK_DIR=$(pwd)/iso24-work
EXTRACT_DIR=$WORK_DIR/extract
NEW_ISO=seraphina-ubuntu-24.04-autoinstall.iso

mkdir -p "$WORK_DIR" "$EXTRACT_DIR"
cp "$ORIG_ISO" "$WORK_DIR"/
cd "$WORK_DIR"

# Extract ISO (xorriso can list; we use 7z for convenience)
if ! command -v 7z >/dev/null 2>&1; then
  echo "[ERROR] 7z required (apt install p7zip-full)" >&2; exit 3
fi
7z x "$ORIG_ISO" -o"$EXTRACT_DIR"
cd "$EXTRACT_DIR"

# Create nocloud data source
mkdir -p nocloud
cat > nocloud/meta-data <<EOF
instance-id: seraphina-miner-24
local-hostname: seraphina24
EOF

# Use existing autoinstall-user-data.yaml if present in miner source, else fallback
if [ -f "$MINER_SRC/autoinstall-user-data.yaml" ]; then
  cp "$MINER_SRC/autoinstall-user-data.yaml" nocloud/user-data
else
  cat > nocloud/user-data <<'EOF'
#cloud-config
autoinstall:
  version: 1
  locale: en_US
  keyboard:
    layout: us
  identity:
    hostname: seraphina24
    username: seraphina
    password: "$6$rounds=4096$abcdefghijklmnop$QyROJYhBqUopYkqE3SVoBqL2mICdaTq9tOEpOzXgqBvP8kVjsiD6s5JXq5mxgGumctvqYdGmYaQwaaqdG6C1P."
  ssh:
    install-server: true
  storage:
    layout:
      name: direct
  packages:
    - curl
    - gnupg
    - nodejs
    - npm
  late-commands:
    - curtin in-target --target=/target -- bash /cdrom/seraphina/install-seraphina.sh /cdrom/seraphina/mining /opt/seraphina
  updates: security
  user-data:
    disable_root: true
EOF
fi

# Copy miner workspace
mkdir -p seraphina
rsync -a --exclude node_modules --exclude .git "$MINER_SRC"/ seraphina/mining/
cp "$MINER_SRC"/install-seraphina.sh seraphina/
cp "$MINER_SRC"/artifact-hashes.json seraphina/ 2>/dev/null || true

# Patch boot config for 24.04 (GRUB kernel cmdline)
GRUBCFG=boot/grub/grub.cfg
if grep -q 'autoinstall' "$GRUBCFG"; then
  echo "[INFO] autoinstall already present"
else
  sed -i 's/quiet splash/quiet splash autoinstall ds=nocloud\;s=\/cdrom\/nocloud/g' "$GRUBCFG"
fi

# Repack ISO
cd ..
if ! command -v xorriso >/dev/null 2>&1; then
  echo "[ERROR] xorriso required (apt install xorriso)" >&2; exit 4
fi
xorriso -as mkisofs -r -V "SERAPHINA_24_AUTOINSTALL" -J -l -iso-level 3 -o "$NEW_ISO" extract

echo "[BUILD] Created $NEW_ISO"
echo "Flash with balenaEtcher selecting: $WORK_DIR/$NEW_ISO"
