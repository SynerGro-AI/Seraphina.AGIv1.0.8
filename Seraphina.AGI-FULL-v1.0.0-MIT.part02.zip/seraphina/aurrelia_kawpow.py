# aurrelia_kawpow.py
# Aurrelia.AI: Self-optimizing KawPow miner prototype for RVN/FREN (Python port skeleton)
# NOTE: This is a prototype integration layer for real KawPow hashing using the 'kawpow' Python package.
# It does NOT yet implement full stratum networking or production share submission logic.
# Deterministic math paths mirror JS octonion logic; extend before production use.

import os, asyncio, time, hashlib, json
from datetime import datetime
try:
    from kawpow import kawpow_hash  # pip install kawpow
except Exception as e:
    kawpow_hash = None
try:
    import aiohttp
except Exception:
    aiohttp = None
import numpy as np

GLOBAL_OCTO_SEED = int(os.environ.get('GLOBAL_OCTO_SEED', '123456'))
GLOBAL_BURROW_DEPTH = int(os.environ.get('GLOBAL_BURROW_DEPTH', '5'))
GLOBAL_PRUNE_THRESHOLD = float(os.environ.get('GLOBAL_PRUNE_THRESHOLD', '2.5'))
HARMONICS = [432, 528, 964, 1056]
MULTI_HARMONIC = os.environ.get('MULTI_HARMONIC','0')=='1'
PLANE_AGG_MODE = os.environ.get('PLANE_AGG_MODE','xor').lower()
PLANE_WEIGHTED = os.environ.get('PLANE_WEIGHTED','0')=='1'

class SimpleOcto:
    def __init__(self, coeffs):
        self.coeffs = np.array(coeffs, dtype=np.float64)
    def norm(self):
        return float(np.sqrt(np.sum(self.coeffs**2)))
    def multiply(self, other):
        a,b = self.coeffs, other.coeffs
        prod = np.zeros(8)
        prod[0] = a[0]*b[0] - np.sum(a[1:]*b[1:])
        prod[1:] = a[0]*b[1:] + b[0]*a[1:]
        return SimpleOcto(prod)
    def power(self, d=2):
        if d==2: return self.multiply(self)
        return self
    def add(self, other):
        return SimpleOcto(self.coeffs + other.coeffs)

class AurreliaNode:
    def __init__(self, id):
        self.id=id
        self.harmonic_index=id % len(HARMONICS)
        self.freq = HARMONICS[self.harmonic_index]
        self.engine={'burrow_depth': GLOBAL_BURROW_DEPTH,'prune_threshold': GLOBAL_PRUNE_THRESHOLD,'theta_base': 2*np.pi/self.freq}
        self.successes=0; self.attempts=0; self.pico_theta=0; self.interference_gain=1.5
        self.octo = SimpleOcto(hash_to_octonion(f'node{id}')['coeffs'])
    def generate_nonce(self, seed_str, n_time_hex, plane_seeds):
        c = SimpleOcto(hash_to_octonion(seed_str)['coeffs'])
        theta = self.engine['theta_base'] * (self.freq/432)
        z = SimpleOcto(np.zeros(8)).power(2).add(c.multiply(SimpleOcto([theta, theta]+[0]*6))).power(2).add(c)
        cross=0
        for i,ps in enumerate(plane_seeds):
            oct_ps = SimpleOcto(hash_to_octonion(ps)['coeffs'])
            cross += oct_ps.norm() * HARMONICS[i % len(HARMONICS)]/432 * self.engine['theta_base']
        self.pico_theta += theta
        z.coeffs[0] += cross * self.interference_gain * np.sin(self.pico_theta)
        nonce = int(abs(z.coeffs[0]) * 0xffffffff) & 0xffffffff
        return {'nonce': nonce, 'norm': z.norm(), 'cross': cross}
    def verify_nonce(self, nonce_hex, seed_str, n_time_hex):
        c = SimpleOcto(hash_to_octonion(seed_str + nonce_hex)['coeffs'])
        theta = self.engine['theta_base']*(self.freq/432)
        z = SimpleOcto(np.zeros(8))
        for i in range(self.engine['burrow_depth']):
            z = z.power(2).add(c.multiply(SimpleOcto([np.cos(8*theta*i), np.sin(8*theta*i)] + [0]*6)))
            if z.norm() > self.engine['prune_threshold']:
                return {'valid': False, 'iter': i, 'norm': z.norm()}
        return {'valid': True, 'iter': self.engine['burrow_depth']-1, 'norm': z.norm()}
    def feedback(self, success):
        self.attempts +=1
        if success: self.successes +=1
        if self.attempts % 32 ==0:
            rate = self.successes/self.attempts if self.attempts else 0
            if rate <0.01:
                self.harmonic_index=(self.harmonic_index+1)%len(HARMONICS)
                self.freq=HARMONICS[self.harmonic_index]
                self.engine['theta_base']=2*np.pi/self.freq
                self.interference_gain=max(0.4, self.interference_gain*0.85)
            elif rate>0.05:
                self.interference_gain=min(2.5, self.interference_gain*1.1)
            self.successes=0; self.attempts=0

def hash_to_octonion(data_str):
    h=0
    for ch in data_str:
        h = ((h<<5)-h) + ord(ch) ^ (GLOBAL_OCTO_SEED & 0xff)
        h &= 0xffffffffffffffff
    coeffs=[]
    for i in range(8):
        chunk = (h >> (i*4)) & 0xffff
        coeffs.append((chunk % 10000)/5000 -1)
    return {'coeffs': coeffs}

def build_coinbase(c1, ex1, ex2, c2): return c1+ex1+ex2+c2

def double_sha256(b: bytes): return hashlib.sha256(hashlib.sha256(b).digest()).digest()

def build_merkle_root(tx_hex, branches):
    merkle = double_sha256(bytes.fromhex(tx_hex))
    for br in branches:
        merkle = double_sha256(merkle + bytes.fromhex(br))
    return merkle.hex()

def reverse_bytes(h): return bytes(reversed(bytes.fromhex(h))).hex()

def nbits_to_target(nbits):
    n=int(nbits,16); exp=n>>24; mant=n & 0xffffff; return mant << (8*(exp-3))

def build_block_header(job, merkle_root, ntime, nbits, nonce):
    ver=reverse_bytes(job['version'].zfill(8)); prev=reverse_bytes(job['prevhash']); merk=reverse_bytes(merkle_root)
    time_hex=reverse_bytes(ntime.zfill(8)); bits=reverse_bytes(nbits.zfill(8)); non=reverse_bytes(nonce.zfill(8))
    return ver+prev+merk+time_hex+bits+non

def kawpow_hash_header(header_hex, height=1, seed=b'\x00'*32, nonce=None):
    header_bytes=bytes.fromhex(header_hex)
    if kawpow_hash:
        try:
            if nonce is None: nonce=int(header_hex[-8:],16)
            mix = kawpow_hash(header_bytes, height, seed, nonce)
            return mix.hex()
        except Exception:
            pass
    h1=hashlib.sha256(header_bytes).digest(); h2=hashlib.sha256(h1).digest(); return h2.hex()

def aggregate_seed(plane_seeds, mode, weighted):
    if not plane_seeds: return '0'*64
    if mode=='avg':
        nibs=[list(s.ljust(64,'0')) for s in plane_seeds]
        out=[]
        for i in range(64):
            if weighted:
                accum=sum(int(n[i],16) for n in nibs)
                out.append(f'{(accum//len(nibs)) & 0xF:x}')
            else:
                s=sum(int(n[i],16) for n in nibs); out.append(f'{(s//len(nibs)) & 0xF:x}')
        return ''.join(out)
    else:
        out=[]
        for i in range(64):
            s=sum(int(ps[i],16) if i < len(ps) else 0 for ps in plane_seeds)
            out.append(f'{s & 0xF:x}')
        return ''.join(out)

async def main():
    coin=os.environ.get('COIN','rvn')
    # Mock job until stratum integration
    job={'jobId':'mock','prevhash':'00'*32,'coinb1':'01','coinb2':'02','merkle_branch':[],'version':'04000000','nbits':'1d00ffff','ntime':'64f11600'}
    extranonce1='00'; extranonce2_size=8; extranonce2=0
    nodes=[AurreliaNode(i) for i in range(8)]
    hashes=0; start=time.time()
    while True:
        coinbase=build_coinbase(job['coinb1'], extranonce1, f'{extranonce2:016x}', job['coinb2'])
        merkle=build_merkle_root(coinbase, job['merkle_branch'])
        ntime_hex=f'{int(job['ntime'],16)+extranonce2:08x}'
        plane_input=(coinbase[:256]+ntime_hex)
        plane_seeds=[plane_input[i:i+64] for i in range(0, min(len(plane_input),256),64)]
        roman_seed=aggregate_seed(plane_seeds, PLANE_AGG_MODE, PLANE_WEIGHTED)
        for nd in nodes:
            gen=nd.generate_nonce(roman_seed, ntime_hex, plane_seeds)
            ver=nd.verify_nonce(f'{gen['nonce']:08x}', roman_seed, ntime_hex)
            if ver['valid']:
                header_hex=build_block_header(job, merkle, ntime_hex, job['nbits'], f'{gen['nonce']:08x}')
                hh=kawpow_hash_header(header_hex)
                if int(hh,16) <= nbits_to_target(job['nbits']):
                    hashes+=1
            nd.feedback(ver['valid'])
        extranonce2=(extranonce2+1) % (1 << (extranonce2_size*8))
        elapsed=time.time()-start
        ths = (hashes/elapsed)/1e12 if elapsed>0 else 0
        print(f'[PyKawPow] {hashes} hashes TH/s={ths:.6f} coin={coin}')
        await asyncio.sleep(0.05)

if __name__=='__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Exiting...')
