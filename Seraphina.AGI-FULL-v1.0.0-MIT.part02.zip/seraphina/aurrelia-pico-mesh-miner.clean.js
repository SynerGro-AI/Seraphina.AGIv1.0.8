// aurrelia-pico-mesh-miner.clean.js
// Enhanced clean recovery build: real Keccak-f[1600] (trimmed MIT/CC0 style), simplified ProgPOW/KawPow-like mix, nonce batching,
// parity sampling, Rashba-style deterministic gain modulation, and Prometheus metrics. Incremental step – not full spec KawPow.

const crypto = require('crypto');
const http = require('http');
const { keccakF1600, keccak256 } = require('./lib/hash/keccak');
const { kawpowJs, kawpowJsNoMem } = require('./lib/hash/kawpow');
const { createKawpowMetrics, promClient } = require('./lib/metrics/registry');
// Swarm (added)
let swarm = null; try { swarm = require('./lib/swarm/swarm'); } catch(_) {}
let RealStratumClient = null; try { ({ RealStratumClient } = require('./real-stratum-client.js')); } catch(_){ }
const { assembleHeader } = require('./lib/stratum/rvn-header');

function doubleSha256(hex){ const b = Buffer.isBuffer(hex)? hex : Buffer.from(hex,'hex'); const h1 = crypto.createHash('sha256').update(b).digest(); return crypto.createHash('sha256').update(h1).digest('hex'); }


// Attempt native KawPow
let kawpowNative = null; 
try { 
  if (process.env.KAWPOW_JS_ONLY!=='1'){
    const override = process.env.KAWPOW_NATIVE_MODULE;
    if (override) {
      try { kawpowNative = require(override); } catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[Clean][KawPow] override load fail', e.message); }
    }
    if (!kawpowNative){
      try { kawpowNative = require('./build/Release/kawpowhash.node'); } catch(e1){
        try { kawpowNative = require('./build/Release/kawpow_native.node'); } catch(e2){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[Clean][KawPow] native load fail', e1.message, '| fallback', e2.message); }
      }
    }
  }
} catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[Clean][KawPow] native load fail', e.message); }
let kawpowNativeDisabled = false; // native-gate flag
let detFailsLocal = 0; let detChecksLocal = 0; // local counters

function kawpowHash(headerHex, height, seedHex, nonce){
  const headerBuf = Buffer.from(headerHex,'hex');
  const seedBuf = seedHex? Buffer.from(seedHex,'hex') : Buffer.alloc(32,0);
  if (kawpowNative && !kawpowNativeDisabled && kawpowNative.hash){
    try {
      const out = kawpowNative.hash(headerBuf, height, seedBuf, nonce>>>0);
      if (out && out.finalHash){
        return { finalHash: out.finalHash.toString('hex'), mixHash: out.mixHash? out.mixHash.toString('hex'): out.finalHash.toString('hex'), native:true };
      }
    } catch(e){ if (process.env.KAWPOW_VERBOSE==='1') console.warn('[Clean][KawPow] native error', e.message); }
  }
  const js = kawpowJs(headerBuf, height, seedBuf, nonce);
  js.native=false; return js;
}

const HASH_STRATEGIES = {
  sha256d: { id:'sha256d', hashHeader: h=> doubleSha256(h), parityEnabled:true },
  kawpow: { id:'kawpow', hashHeader: (headerHex, height=0, seedHex='', nonce=0)=> kawpowHash(headerHex, height, seedHex, nonce).finalHash }
};

// Prometheus metrics
let kawpowMetrics = createKawpowMetrics();
if (kawpowMetrics) kawpowMetrics.nativeEnabled.set(kawpowNative && !kawpowNativeDisabled ? 1 : 0);

// ----- Metrics HTTP Endpoint (optional) -----
let metricsServerStarted = false;
function startMetricsServer(){
  if (!promClient || metricsServerStarted) return;
  const port = parseInt(process.env.KAWPOW_METRICS_PORT || '9464',10);
  try {
    const server = http.createServer(async (req,res)=>{
      if (req.url === '/metrics'){
        try {
          const content = await promClient.register.metrics();
          res.writeHead(200, { 'Content-Type':'text/plain; version=0.0.4' });
          res.end(content);
        } catch(e){ res.writeHead(500); res.end(e.message); }
        return;
      }
      if (req.url === '/health'){
        res.writeHead(200, {'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true })); return;
      }
      if (req.url === '/swarm'){
        if (swarm){
          try { const peers = swarm.listPeers(); res.writeHead(200, {'Content-Type':'application/json'}); res.end(JSON.stringify({ peers, ts:Date.now() })); }
          catch(e){ res.writeHead(500, {'Content-Type':'application/json'}); res.end(JSON.stringify({ error:e.message })); }
        } else { res.writeHead(503, {'Content-Type':'application/json'}); res.end(JSON.stringify({ error:'swarm disabled' })); }
        return;
      }
      res.writeHead(404); res.end('not found');
    });
    server.listen(port, ()=> console.log('[Metrics] Listening on', port, '/metrics'));
    metricsServerStarted = true;
  } catch(e){ console.warn('[Metrics] Failed to start metrics server:', e.message); }
}

if (process.env.KAWPOW_METRICS!=='0') startMetricsServer();

// Simple mock job provider (fallback if no stratum)
function mockJob(){
  return {
    headerTemplate: (nonce)=> crypto.createHash('sha256').update('job'+nonce).digest('hex').padEnd(160,'0').slice(0,160),
    targetPrefix: process.env.KAWPOW_TARGET_PREFIX || '00000',
    height: parseInt(process.env.KAWPOW_HEIGHT||'0',10),
    seed: process.env.KAWPOW_SEED || '00'.repeat(32)
  };
}

// Optional stratum (RVN/FREN) minimal wire – expects RealStratumClient available
let activeStratum = null; let currentJob = null; let extranonce1=''; let extranonce2Size=8;
function initStratum(){
  if (!RealStratumClient || process.env.KAWPOW_STRATUM!=='1') return false;
  const host = process.env.STRATUM_HOST || 'rvn.2miners.com';
  const port = parseInt(process.env.STRATUM_PORT||'6060',10);
  const user = process.env.STRATUM_USER || 'WALLET.WORKER';
  const pass = process.env.STRATUM_PASS || 'x';
  activeStratum = new RealStratumClient({ host, port, coin:'RVN', worker:user, password:pass });
  activeStratum.on('subscribed', s=>{ extranonce1 = s.extranonce1||''; extranonce2Size = s.extranonce2Size||8; console.log('[Stratum][Subscribed]', extranonce1, extranonce2Size); });
  activeStratum.on('job', job=>{ currentJob = job; });
  activeStratum.on('accepted', ()=> { if (kawpowMetrics) kawpowMetrics.shares.inc(); });
  return true;
}

// --- Stratum (RVN/FREN) header assembly helpers ---

let extranonce2Counter = 0; // will increment per share submission when stratum active

function assembleHeaderBase(job, providedEx2){
  if (!job) return null;
  const ex2 = providedEx2 || (++extranonce2Counter).toString(16).padStart(extranonce2Size*2,'0').slice(0,extranonce2Size*2);
  const assembled = assembleHeader(job, extranonce1, ex2);
  return { headerBaseHex: assembled.headerBaseHex, targetBig: assembled.targetDecoded? assembled.targetDecoded.targetBig:null, targetHex: assembled.targetDecoded? assembled.targetDecoded.targetHex:null, extranonce2: ex2, merkleRootLE: assembled.merkleRootLE };
}

function getActiveJob(){
  if (currentJob){
    const cached = assembleHeaderBase(currentJob); // baseline (will be reassembled for each share anyway)
    return {
      headerTemplate: (nonce, ex2Override)=> {
        const rebuild = assembleHeaderBase(currentJob, ex2Override);
        const nonceBuf = Buffer.alloc(4); nonceBuf.writeUInt32LE(nonce>>>0,0);
        return { full: rebuild.headerBaseHex + nonceBuf.toString('hex'), targetBig: rebuild.targetBig, targetHex: rebuild.targetHex, extranonce2: rebuild.extranonce2 };
      },
      targetPrefix: (process.env.KAWPOW_TARGET_PREFIX || '00000'),
      targetBig: cached.targetBig,
      targetHex: cached.targetHex,
      height: parseInt(currentJob.height || currentJob.blockheight || '0',10),
      seed: currentJob.prevhash ? currentJob.prevhash.slice(0,64) : '00'.repeat(32)
    };
  }
  return mockJob();
}

async function mineKawpow(){
  if (initStratum()) console.log('[Clean] Stratum mode enabled');
  const batchSize = parseInt(process.env.KAWPOW_BATCH || '64',10);
  const parityEvery = parseInt(process.env.KAWPOW_PARITY_EVERY || '16',10);
  let batchCounter=0; let nonceSeed=0; const rashbaGain = parseFloat(process.env.RASHBA_GAIN || '0.15'); if (kawpowMetrics) kawpowMetrics.rashbaGain.set(rashbaGain);
  while(true){
    const job = getActiveJob();
    const startNonce = nonceSeed;
    const prefix = job.targetPrefix;
    for (let n=0;n<batchSize;n++){
      const nonce = startNonce + n;
    const ex2Local = activeStratum ? (++extranonce2Counter).toString(16).padStart(extranonce2Size*2,'0').slice(0,extranonce2Size*2) : '00'.repeat(extranonce2Size);
    const built = typeof job.headerTemplate === 'function' ? job.headerTemplate(nonce, ex2Local) : { full: job.headerTemplate(nonce), extranonce2: ex2Local, targetBig: job.targetBig };
    const headerHex = built.full || built;
      const seedHex = job.seed;
      const out = kawpowHash(headerHex, job.height, seedHex, nonce);
      if (kawpowMetrics) kawpowMetrics.nonces.inc();
  if (kawpowMetrics && out.memReads) kawpowMetrics.memReads.inc(out.memReads);
      let shareCandidate = false;
      // Prefix heuristic OR target compare if available
      if (built.targetBig){
        try {
          const hBig = BigInt('0x'+out.finalHash);
          if (hBig <= built.targetBig) shareCandidate = true;
        } catch(_){}
      }
      if (!shareCandidate && out.finalHash.startsWith(prefix)) shareCandidate = true;
      if (shareCandidate){
        if (activeStratum && currentJob){
          try {
            if (kawpowMetrics) kawpowMetrics.sharesSubmitted.inc();
            const nonceHex = nonce.toString(16).padStart(8,'0');
            const resp = activeStratum.submitShare({ jobId: currentJob.jobId, extranonce2: built.extranonce2, ntime: currentJob.ntime || '00000000', nonce: nonceHex, mixHash: out.mixHash, headerHex });
            // acceptance events captured by client; we attach listeners once
          } catch(_){ }
        }
        if (kawpowMetrics) kawpowMetrics.shares.inc();
        if (process.env.KAWPOW_VERBOSE==='1') console.log('[KawPow][ShareCandidate]', nonce, out.finalHash.slice(0,32));
      }
    }
    batchCounter++;
    if (kawpowMetrics){ kawpowMetrics.batches.inc(); kawpowMetrics.lastBatch.set(batchSize); kawpowMetrics.parityInterval.set(parityEvery); }
    if (batchCounter % parityEvery === 0){
  // Deprecated sample randomness (deterministic migration). File slated for black/ relocation.
  const { deriveInt } = require('./deterministic-util');
  const testNonce = startNonce + deriveInt('clean-nonce', batchSize, startNonce, batchSize);
      const builtTest = typeof job.headerTemplate === 'function' ? job.headerTemplate(testNonce) : { full: job.headerTemplate(testNonce) };
      const headerHex = builtTest.full || builtTest;
      const seedHex = job.seed;
      const native = kawpowHash(headerHex, job.height, seedHex, testNonce);
      const jsMem = kawpowJs(Buffer.from(headerHex,'hex'), job.height, Buffer.from(seedHex,'hex'), testNonce);
      if (native.finalHash !== jsMem.finalHash && kawpowMetrics){ kawpowMetrics.mismatches.inc(); if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow][ParityMismatch]', native.finalHash.slice(0,16), jsMem.finalHash.slice(0,16)); }
      // Recompute mem variant (determinism test)
      const jsMem2 = kawpowJs(Buffer.from(headerHex,'hex'), job.height, Buffer.from(seedHex,'hex'), testNonce);
      if (jsMem2.finalHash !== jsMem.finalHash && kawpowMetrics){
        kawpowMetrics.memParityDeterminismFails.inc();
        detFailsLocal++;
        if (process.env.KAWPOW_VERBOSE==='1') console.warn('[KawPow][MemDeterminismFail]', jsMem.finalHash.slice(0,16), jsMem2.finalHash.slice(0,16));
      }
      // No-mem baseline
      const jsNoMem = kawpowJsNoMem(Buffer.from(headerHex,'hex'), job.height, Buffer.from(seedHex,'hex'), testNonce);
      if (kawpowMetrics){
        kawpowMetrics.memParityChecks.inc();
        detChecksLocal++;
        try {
          const a = BigInt('0x'+jsNoMem.finalHash);
          const b = BigInt('0x'+jsMem.finalHash);
          if (b !== 0n){
            // Compute a clamped ratio (avoid overflow) using double division on Number but cap 10
            let ratio = Number(a) / Number(b);
            if (!isFinite(ratio) || ratio <= 0) ratio = 1; // sanity
            if (ratio > 10) ratio = 10; // clamp
            kawpowMetrics.memEffectRatio.set(ratio);
            // Leading zero bits comparison (higher zero bits = "stronger")
            function leadingZeroBits(hex){
              const bin = BigInt('0x'+hex).toString(2).padStart(256,'0');
              let i=0; while(i<bin.length && bin[i]==='0') i++; return i;
            }
            const lzNo = leadingZeroBits(jsNoMem.finalHash);
            const lzMem = leadingZeroBits(jsMem.finalHash);
            const delta = lzNo - lzMem; // positive -> no-mem has more zeros (worse mem mix?), negative -> mem stronger
            kawpowMetrics.memEffectDeltaBits.set(delta);
            if (process.env.KAWPOW_VERBOSE==='1') console.log('[MemEffect]', 'ratio', ratio.toFixed(4), 'deltaBits', delta);
          }
        } catch(_){ }
      }
      // Native-gate evaluation
      const threshold = parseFloat(process.env.KAWPOW_MEM_DET_THRESHOLD || '0.05');
      const minChecks = parseInt(process.env.KAWPOW_MEM_DET_MIN_CHECKS || '20',10);
      if (detChecksLocal >= minChecks){
        const ratio = detFailsLocal / (detChecksLocal || 1);
        if (kawpowMetrics) kawpowMetrics.memDeterminismFailRatio.set(ratio);
        if (kawpowNative && !kawpowNativeDisabled && ratio > threshold){
          kawpowNativeDisabled = true;
            if (kawpowMetrics){
              kawpowMetrics.nativeDisableEvents.inc();
              kawpowMetrics.nativeEnabled.set(0);
            }
          console.warn('[KawPow][NativeGate] Disabled native hashing path (determinism fail ratio', ratio.toFixed(4), '>', threshold, ')');
        }
      } else {
        const ratio = detFailsLocal / (detChecksLocal || 1);
        if (kawpowMetrics) kawpowMetrics.memDeterminismFailRatio.set(ratio);
      }
    }
    nonceSeed += batchSize;
    await new Promise(r=> setImmediate(r));
  }
}

if (process.env.KAWPOW_ONLY==='1'){
  console.log('[Clean] Starting enhanced KawPow batched miner');
  // Start swarm skeleton if enabled
  if (process.env.SWARM_ENABLE==='1' && swarm){
    try {
      if (kawpowMetrics && swarm.integrateMetrics) swarm.integrateMetrics(kawpowMetrics);
      swarm.start(()=>({ nativeEnabled: kawpowNative && !kawpowNativeDisabled ? 1 : 0 }), (peer)=>{
        if (kawpowMetrics){ try { kawpowMetrics.swarmPeers.set(swarm.listPeers().length); } catch(_){ } }
        if (process.env.SWARM_VERBOSE==='1') console.log('[Swarm][Peer]', peer.id || peer.hn || 'unknown');
      });
      console.log('[Swarm] Skeleton started (UDP:', process.env.SWARM_UDP !== '0', 'mDNS:', process.env.SWARM_MDNS==='1', ')');
      // Peer determinism consensus voting: disable native if majority peers report high memdf
      const voteInterval = parseInt(process.env.SWARM_VOTE_INTERVAL_MS || '10000',10);
      const memdfThreshold = parseFloat(process.env.KAWPOW_MEM_DET_THRESHOLD || '0.05');
      setInterval(()=>{
        try {
          const peersList = swarm.listPeers(); if (!peersList.length) return;
          const votes = peersList.filter(p=> p.payload && typeof p.payload.memdf==='number' && p.payload.memdf > memdfThreshold).length;
          if (votes > peersList.length/2 && kawpowNative && !kawpowNativeDisabled){
            kawpowNativeDisabled = true;
            if (kawpowMetrics){ kawpowMetrics.nativeDisableEvents.inc(); kawpowMetrics.nativeEnabled.set(0); }
            console.warn('[Swarm][Consensus] Native hashing disabled by peer majority determinism vote (', votes,'/', peersList.length, 'memdf>', memdfThreshold, ')');
          }
        } catch(_){ }
      }, voteInterval).unref();
    } catch(e){ console.warn('[Swarm] start failed', e.message); }
  }
  if (activeStratum){
    activeStratum.on('shareAccepted', ()=>{
      if (kawpowMetrics){ kawpowMetrics.sharesAccepted.inc(); try { const acc = kawpowMetrics.sharesAccepted.hashes || 0; const sub = kawpowMetrics.sharesSubmitted.hashes || 0; if (sub>0) kawpowMetrics.shareAcceptRatio.set(acc/sub); } catch(_){} }
    });
    activeStratum.on('shareRejected', ()=>{
      if (kawpowMetrics){ kawpowMetrics.sharesRejected.inc(); try { const acc = kawpowMetrics.sharesAccepted.hashes || 0; const sub = kawpowMetrics.sharesSubmitted.hashes || 0; if (sub>0) kawpowMetrics.shareAcceptRatio.set(acc/sub); } catch(_){} }
    });
  }
  mineKawpow();
}

module.exports = { HASH_STRATEGIES, mineKawpow, kawpowHash, kawpowJs, keccakF1600 };