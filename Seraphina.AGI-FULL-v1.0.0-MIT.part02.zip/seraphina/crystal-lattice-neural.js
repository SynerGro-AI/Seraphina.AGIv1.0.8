// Crystal Lattice Neural Node - 8-point octagonal recursive structure
// Each node is a set of overlapping octagon rings, recursively built inward
// Each firing/lesson creates a new inward ring, hashed and (optionally) encrypted
// Author: SynerGroAI / Wilson of Orange

const crypto = require('crypto');

class CrystalLatticeNode {
    constructor(depth = 0, parent = null) {
        this.depth = depth; // How many inward rings
        this.parent = parent;
        this.rings = []; // Each ring: { orientation: [x,y,z], points: [octagon points] }
        this.children = [];
        this.hash = null;
        this.energy = 1.0; // Placeholder for energy/activation
        this.created = Date.now();
        this.compressedSummary = null; // Holds aggregated data if subtree compressed
        // Build initial 3 orthogonal rings
        this._initBaseRings();
    }

    _initBaseRings() {
        // 3 orthogonal octagon rings, centered at origin
        this.rings.push(this._makeRing([1,0,0])); // X axis
        this.rings.push(this._makeRing([0,1,0])); // Y axis (90°)
        this.rings.push(this._makeRing([0,0,1])); // Z axis (90° horz+vert)
    }

    _makeRing(axis) {
        // Returns 8 points in a ring, oriented by axis
        // For simplicity, points are just vectors; real geometry can be added later
        const points = [];
        const r = 1.0 * Math.pow(0.9, this.depth); // Shrink inward
        for (let i = 0; i < 8; ++i) {
            const theta = (Math.PI * 2 * i) / 8;
            let x = r * Math.cos(theta), y = r * Math.sin(theta), z = 0;
            // Rotate according to axis
            if (axis[0]) { [x, y, z] = [x, y, z]; }
            if (axis[1]) { [x, y, z] = [z, x, y]; }
            if (axis[2]) { [x, y, z] = [y, z, x]; }
            points.push({ x, y, z });
        }
        return { axis, points };
    }

    fire(lessonData) {
        // Firing: create a new inward node, add as child
        const newDepth = this.depth + 1;
        const child = new CrystalLatticeNode(newDepth, this);
        child.energy = this.energy * 0.9; // Decay inward
        child.hash = this._hashLesson(lessonData, newDepth);
        this.children.push(child);
        return child;
    }

    /**
     * Fractal-aware refinement: uses Mandelbrot-style escape-time to gate inward growth.
     * shareData: { hash: hexString, metrics: { efficiency, hashRate, sharesPerMinute, ... } }
     * options: { maxIter, maxChildrenPerRefine, compressionThreshold }
     */
    fractalRefine(shareData, options = {}) {
        if (!shareData || !shareData.hash) return { spawned: 0, reason: 'no-hash' };
        const {
            maxIter = 128,
            maxChildrenPerRefine = 3,
            compressionThreshold = 64,
            julia = false, // if true treat mapped complex as c and vary z0 seeds
            order = 2 // generalized Multibrot exponent d (>=2); d=2 => classical Mandelbrot
        } = options;

        if (order < 2) {
            return { spawned: 0, reason: 'unsupported-order', order };
        }

        // Prevent runaway if already compressed
        if (this.compressedSummary) return { spawned: 0, reason: 'compressed-subtree' };

        // Map hash to complex plane coordinate c
        const c = this._mapHashToComplex(shareData.hash);
        const metrics = shareData.metrics || {};

        // Efficiency influence: adjust maxIter adaptively
        const eff = metrics.efficiency || 0;
        const dynamicMaxIter = Math.min(maxIter + Math.floor(Math.log10(eff || 1)), 512);

        // Run escape-time
    const escapeInfo = this._multibrotEscape(c, order, dynamicMaxIter, julia);

        // Density score: higher if close to boundary (escaped late)
        const densityScore = (escapeInfo.escaped ? escapeInfo.iter : dynamicMaxIter);

        // Decide how many children to spawn (R) based on densityScore windowing
        let R = 0;
        if (!escapeInfo.escaped) {
            // Inside set -> stable region: modest controlled refinement
            R = 1;
        } else if (densityScore > dynamicMaxIter * 0.75) {
            // Near boundary -> rich structure
            R = 2;
        } else if (densityScore > dynamicMaxIter * 0.50) {
            R = 1;
        }

        // Efficiency boost can add an extra child (burst) capped
        if (eff > 400000 && R > 0) R += 1;
        R = Math.min(R, maxChildrenPerRefine);

        // Memory / subtree size gating
        if (this.children.length > compressionThreshold) {
            this._compressSubtree();
            return { spawned: 0, reason: 'compressed', densityScore, escapeInfo };
        }

        // Spawn children
        let spawned = 0;
        for (let i = 0; i < R; i++) {
            const lesson = {
                shareHash: shareData.hash,
                part: i,
                c,
                depth: this.depth + 1,
                densityScore,
                eff
            };
            this.fire(lesson);
            spawned++;
        }
        return { spawned, densityScore, escapeInfo, eff };
    }

    /** Map a hex hash to complex coordinate in a canonical Mandelbrot window. */
    _mapHashToComplex(hash) {
        const clean = hash.replace(/[^0-9a-f]/gi, '').padEnd(32, '0');
        const realHex = clean.slice(0, 8);
        const imagHex = clean.slice(8, 16);
        const realInt = parseInt(realHex, 16);
        const imagInt = parseInt(imagHex, 16);
        // Scale to ranges: real in [-2.5, 1], imag in [-1.25, 1.25]
        const real = -2.5 + (realInt / 0xffffffff) * 3.5;
        const imag = -1.25 + (imagInt / 0xffffffff) * 2.5;
        return { real, imag };
    }

    /** Mandelbrot (or Julia) escape-time algorithm. */
    _mandelbrotEscape(c, maxIter = 128, juliaMode = false) { // retained for backward compatibility
        return this._multibrotEscape(c, 2, maxIter, juliaMode);
    }

    /** Generalized Multibrot (or Julia) escape-time for order d >= 2 (integer). */
    _multibrotEscape(c, d = 2, maxIter = 128, juliaMode = false) {
        // Implementation notes:
        // For d != 2 we compute z^d using polar form each iteration to avoid expensive repeated multiplication.
        // z = r * e^{i theta}; z^d = r^d * e^{i d theta}.
        let zr, zi, cr, ci;
        if (juliaMode) {
            cr = c.real; ci = c.imag;
            zr = c.imag; zi = c.real * 0.5; // seed variation
        } else {
            zr = 0; zi = 0; cr = c.real; ci = c.imag;
        }
        let iter = 0;
        const escapeRadiusSq = 4; // Classical bailout radius^2
        for (; iter < maxIter; iter++) {
            // Compute magnitude^2 early for bailout & polar conversion
            const magSqPre = zr * zr + zi * zi;
            if (magSqPre > escapeRadiusSq) {
                return { escaped: true, iter };
            }

            if (d === 2) {
                // Fast path quadratic
                const zr2 = zr * zr - zi * zi + cr;
                const zi2 = 2 * zr * zi + ci;
                zr = zr2; zi = zi2;
            } else {
                // Polar conversion
                const r = Math.sqrt(magSqPre);
                // Avoid log(0) for r=0
                let theta = Math.atan2(zi, zr);
                const rPow = Math.pow(r, d);
                theta = theta * d;
                zr = rPow * Math.cos(theta) + cr;
                zi = rPow * Math.sin(theta) + ci;
            }
        }
        // One final bailout check
        if ((zr * zr + zi * zi) > escapeRadiusSq) {
            return { escaped: true, iter };
        }
        return { escaped: false, iter: maxIter };
    }

    /** Compress (summarize) subtree to prevent runaway memory. */
    _compressSubtree() {
        if (this.compressedSummary) return; // already compressed
        const summary = {
            totalChildren: this._countDescendants(),
            avgEnergy: this._averageEnergy(),
            firstHash: this.children[0]?.hash || null,
            compressedAt: Date.now(),
            depth: this.depth
        };
        // Free heavy child references while keeping summary
        this.children = [];
        this.compressedSummary = summary;
    }

    _countDescendants() {
        let count = 0;
        const stack = [...this.children];
        while (stack.length) {
            const n = stack.pop();
            count++;
            for (const ch of n.children) stack.push(ch);
        }
        return count;
    }

    _averageEnergy() {
        let sum = 0, count = 0;
        const stack = [...this.children];
        while (stack.length) {
            const n = stack.pop();
            sum += (n.energy || 0);
            count++;
            for (const ch of n.children) stack.push(ch);
        }
        return count ? sum / count : 0;
    }

    _hashLesson(data, depth) {
        // Hash lesson data + depth + parent hash
        const h = crypto.createHash('sha256');
        h.update(JSON.stringify(data));
        h.update(String(depth));
        if (this.hash) h.update(this.hash);
        return h.digest('hex');
    }

    serialize() {
        // For persistence or visualization
        return {
            depth: this.depth,
            created: this.created,
            energy: this.energy,
            hash: this.hash,
            rings: this.rings,
            compressed: this.compressedSummary,
            children: this.children.map(c => c.serialize())
        };
    }
}

module.exports = { CrystalLatticeNode };
