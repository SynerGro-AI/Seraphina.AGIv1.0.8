// aurrelia-cluster.js
// Lightweight orchestrator to launch a local pico-mesh of multiple independent miner processes
// Each child runs its own Stratum session, metrics log, self-check HTTP endpoint, and deterministic seed offset.
// Goal: spin up N (default 8) instances for a real multi-process trial without modifying core miner internals.

const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');
const path = require('path');

// --- CLI PARSE -----------------------------------------------------------
const argv = process.argv.slice(2);
function getArg(name, def){
  const p = argv.find(a=>a.startsWith(`--${name}=`));
  if (!p) return def; return p.split('=')[1];
}
const INSTANCES = parseInt(getArg('instances', process.env.AUR_CLUSTER_INSTANCES || '8'),10) || 8;
const BASE_SEED = parseInt(getArg('base-seed', process.env.AUR_SEED || '42'),10) >>> 0;
const BASE_PORT = parseInt(getArg('base-port', process.env.SELF_CHECK_PORT_BASE || '9786'),10) || 9786; // self-check port base
const WORKER_NAME_BASE = getArg('worker-base', process.env.STRATUM_WORKER_BASE || 'aurrelia');
// Pass through any remaining args (excluding cluster-specific ones)
const passthroughArgs = argv.filter(a=>!a.startsWith('--instances=') && !a.startsWith('--base-seed=') && !a.startsWith('--base-port=') && !a.startsWith('--worker-base='));

console.log(`[Cluster] Spawning ${INSTANCES} miner instances (baseSeed=${BASE_SEED}) basePort=${BASE_PORT}`);

// --- CHILD MANAGEMENT ----------------------------------------------------
const children = new Map();
let shuttingDown = false;

function spawnOne(idx){
  const seed = (BASE_SEED + idx) >>> 0; // deterministic offset per instance
  const selfPort = BASE_PORT + idx;
  const metricsFile = `aurrelia-metrics-${idx}.jsonl`;
  const logPrefix = `[M${idx}]`;
  const workerName = `${WORKER_NAME_BASE}${idx}`; // appended index ensures distinct Stratum worker name

  // Build environment: inherit, override some
  const env = {
    ...process.env,
    AUR_SEED: seed.toString(),
    AUR_INSTANCE_INDEX: idx.toString(),
    METRICS_LOG: metricsFile,
    SELF_CHECK_HTTP: '1',
    SELF_CHECK_PORT: selfPort.toString(),
    WORKERS: process.env.CLUSTER_WORKERS || '1', // keep each process light by default
    STRATUM_WORKER: workerName,
    AUR_CLUSTER: '1'
  };
  // Provide minimal mode override at cluster-level if desired
  if (process.env.CLUSTER_MINIMAL === '1') env.MINING_MINIMAL = '1';

  const minerPath = path.join(__dirname, 'aurrelia-pico-mesh-miner.js');
  if (!fs.existsSync(minerPath)){
    console.error('[Cluster] Miner entry script not found at', minerPath);
    process.exit(1);
  }

  // Extra: ensure unique metrics file starts fresh (optional)
  try { if (fs.existsSync(metricsFile)) fs.renameSync(metricsFile, metricsFile + '.prev'); } catch(_){ }

  const child = spawn(process.execPath, [minerPath, ...passthroughArgs], {
    env,
    stdio: ['ignore','pipe','pipe']
  });

  children.set(idx, { proc: child, port: selfPort, seed, metricsFile, workerName, restartCount: 0 });

  child.stdout.on('data', d=>{
    const lines = d.toString().split(/\r?\n/).filter(Boolean);
    for (const line of lines){
      // Compress noise: prefix each line
      console.log(`${logPrefix} ${line}`);
    }
  });
  child.stderr.on('data', d=>{
    const lines = d.toString().split(/\r?\n/).filter(Boolean);
    for (const line of lines){
      console.error(`${logPrefix}[err] ${line}`);
    }
  });
  child.on('exit', (code, sig)=>{
    console.warn(`${logPrefix} exited code=${code} sig=${sig}`);
    if (!shuttingDown){
      const meta = children.get(idx);
      if (meta){ meta.restartCount++; }
  const { deriveInt } = require('./deterministic-util');
  const offset = deriveInt('respawn-delay', 1000, idx, Date.now());
  setTimeout(()=>spawnOne(idx), 2000 + offset); // deterministic stagger respawn
    }
  });

  console.log(`${logPrefix} launched seed=${seed} worker=${workerName} metrics=${metricsFile} port=${selfPort}`);
}

for (let i=0;i<INSTANCES;i++) spawnOne(i);

// --- AGGREGATOR ----------------------------------------------------------
function fetchSelfCheck(idx){
  const meta = children.get(idx); if (!meta) return Promise.resolve(null);
  return new Promise(resolve=>{
    const req = http.get({ host:'127.0.0.1', port: meta.port, path:'/self-check', timeout: 800 }, res=>{
      let buf=''; res.on('data', c=> buf+=c); res.on('end', ()=>{
        try { resolve(JSON.parse(buf)); } catch(_){ resolve(null); }
      });
    });
    req.on('error', ()=> resolve(null));
    req.on('timeout', ()=>{ req.destroy(); resolve(null); });
  });
}

async function aggregate(){
  const snaps = await Promise.all([...children.keys()].map(fetchSelfCheck));
  const live = snaps.filter(Boolean);
  if (!live.length){
    console.log('[Cluster] No self-check responses yet');
    return;
  }
  // Aggregate simple stats
  let avgBatch = 0, rampActive = 0, totalSpeedup = 0, totalLatencyCv = 0;
  for (const s of live){
    avgBatch += (s.batchSize||0);
    if (s.rampActive) rampActive++;
    totalSpeedup += (s.speedupEst||0);
    totalLatencyCv += (s.latencyCv||0);
  }
  avgBatch /= live.length;
  const avgSpeedup = totalSpeedup / live.length;
  const avgLatencyCv = totalLatencyCv / live.length;
  const line = `[Cluster][Status] instances=${live.length}/${children.size} avgBatch=${avgBatch.toFixed(1)} rampActive=${rampActive} avgSpeedup=${avgSpeedup.toFixed(2)} avgLatencyCv=${avgLatencyCv.toFixed(3)} seedBase=${BASE_SEED}`;
  console.log(line);

  // --- Harmonic Weight Derivation (simple proportional inverse load) ---
  try {
    // Collect per-harmonic attempt counts if exposed
    const harmonicStats = {}; // {h0:{attempts:..,accepts:..}}
    for (const s of live){
      if (s.partitions && s.partitions.attempts){
        for (const [hk,v] of Object.entries(s.partitions.attempts)){
          if (!harmonicStats[hk]) harmonicStats[hk] = { attempts:0, accepts:0 };
          harmonicStats[hk].attempts += v;
        }
      }
      if (s.partitions && s.partitions.accepts){
        for (const [hk,v] of Object.entries(s.partitions.accepts)){
          if (!harmonicStats[hk]) harmonicStats[hk] = { attempts:0, accepts:0 };
          harmonicStats[hk].accepts += v;
        }
      }
    }
    // Compute inverse-attempt weighting (less-attempted gets higher weight) then normalize
    const attemptEntries = Object.entries(harmonicStats).filter(([k,val])=> val.attempts > 0);
    if (attemptEntries.length){
      const maxAttempt = Math.max(...attemptEntries.map(e=>e[1].attempts));
      const rawWeights = attemptEntries.map(([hk,stat])=> [hk, (maxAttempt - stat.attempts + 1)]);
      const sumRaw = rawWeights.reduce((s,[_k,v])=>s+v,0);
      const normWeights = {}; rawWeights.forEach(([hk,v])=> normWeights[hk] = v / sumRaw);
      // Broadcast to children via WEIGHT_UPDATE
      for (const [idx, meta] of children.entries()){
        try { meta.proc.send && meta.proc.send({ type:'WEIGHT_UPDATE', weights: normWeights }); } catch(_){ }
      }
      console.log('[Cluster][Weights] Broadcast', Object.entries(normWeights).map(([k,v])=> `${k}=${v.toFixed(3)}`).join(' '));
    }
  } catch(e){ console.warn('[Cluster][Weights] derivation error', e.message); }
}

setInterval(aggregate, parseInt(process.env.CLUSTER_AGG_INTERVAL_MS || '15000',10));
setTimeout(aggregate, 5000);

// Optional tail-based share count aggregator (lightweight)
function tallyShares(){
  let accepted = 0; let linesChecked = 0;
  for (const { metricsFile } of children.values()){
    try {
      if (!fs.existsSync(metricsFile)) continue;
      const data = fs.readFileSync(metricsFile,'utf8').trim().split(/\n/);
      const last = data.slice(-50); // sample tail
      for (const l of last){
        try { const j = JSON.parse(l); if (j.acceptedShares) accepted += j.acceptedShares; } catch(_){ }
      }
      linesChecked += last.length;
    } catch(_){ }
  }
  console.log(`[Cluster][Shares] sampledLines=${linesChecked} acceptedApprox=${accepted}`);
}
setInterval(()=>{ try { tallyShares(); } catch(_){ } }, parseInt(process.env.CLUSTER_SHARE_SAMPLE_MS || '60000',10));

// Graceful shutdown
function shutdown(){
  if (shuttingDown) return; shuttingDown = true;
  console.log('[Cluster] Shutting down all instances...');
  for (const [idx, meta] of children.entries()){
    try { meta.proc.kill('SIGINT'); } catch(_){ }
  }
  setTimeout(()=> process.exit(0), 1200);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// Health watchdog for runaway restarts
setInterval(()=>{
  for (const [idx, meta] of children.entries()){
    if (meta.restartCount > 10){
      console.warn(`[Cluster][Watchdog] Instance ${idx} excessive restarts (${meta.restartCount})`);
    }
  }
}, 30000);

// Usage Hint
if (argv.includes('--help') || argv.includes('-h')){
  console.log(`\nAurrelia Cluster Orchestrator\nUsage: node aurrelia-cluster.js [clusterArgs] -- <minerArgs>\n\nCluster Args:\n  --instances=N         Number of miner processes (default 8)\n  --base-seed=SEED      Base deterministic seed (default 42 or $AUR_SEED)\n  --base-port=PORT      Starting port for self-check endpoints (default 9786)\n  --worker-base=NAME    Base worker name prefix (default 'aurrelia')\n\nEnvironment Overrides:\n  AUR_CLUSTER_INSTANCES, AUR_SEED, SELF_CHECK_PORT_BASE, STRATUM_WORKER_BASE, CLUSTER_WORKERS\n  CLUSTER_MINIMAL=1      Force each instance into MINING_MINIMAL mode\n\nExample:\n  node aurrelia-cluster.js --instances=8 --base-seed=1000 --worker-base=trial -- --algo=sha256d --url=stratum+tcp://pool:3333 --user=wallet --pass=x\n`);
}
