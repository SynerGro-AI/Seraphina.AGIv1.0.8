// aurrelia-trading-engine.js
// Deterministic trading decision simulation (no real market orders).
// Objective: produce reproducible coin hold/swap signals based on income, latency, and bias-adjusted context.
// All randomness removed; tie-breakers use hash of coin labels.
// Signals are advisory only and must be validated before operational execution.

'use strict';

const crypto = require('crypto');

// Configuration bounds
const MAX_SWAP_PER_HOUR = 2; // limit churn
const BASE_MIN_SPREAD_FOR_SWAP = parseFloat(process.env.MIN_SPREAD_FOR_SWAP || '0.05'); // baseline required advantage
const VOL_WINDOW = parseInt(process.env.TRADING_VOL_WINDOW || '24',10); // number of recent signals to compute volatility
const VOL_MIN = parseFloat(process.env.TRADING_VOL_MIN || '0.01'); // clamp volatility lower bound
const VOL_MAX = parseFloat(process.env.TRADING_VOL_MAX || '0.30'); // clamp volatility upper bound
const VOL_SENSITIVITY = parseFloat(process.env.TRADING_VOL_SENS || '0.5'); // how strongly volatility scales threshold
let recentSpreads = []; // rolling spreads for volatility calc
// Learned strategy state (in-memory) for adaptive threshold above volatility baseline
const FEE_RATE = parseFloat(process.env.SWAP_FEE_RATE || '0.002'); // 0.2% default hypothetical fee/slippage cost
const LEARNED_PATH = process.env.TRADING_LEARNED_PATH || 'trading-learned-state.jsonl';
const LEARNED_ENABLE = process.env.TRADING_LEARNED_ENABLE === '1';
// Adaptive multiplier range
const LEARNED_MIN_MULTI = parseFloat(process.env.LEARNED_MIN_MULTI || '1.0');
const LEARNED_MAX_MULTI = parseFloat(process.env.LEARNED_MAX_MULTI || '1.8');
let learnedMultiplier = parseFloat(process.env.LEARNED_START_MULTI || '1.2');
let learnedPrevHash = 'GENESIS';
let currentRegime = 'unknown'; // calm | moderate | turbulent
let provisionalRegime = 'unknown';
let regimeConfirmCount = 0;
const REGIME_CONFIRM_REQUIRED = parseInt(process.env.TRADING_REGIME_CONFIRM || '3',10); // consecutive classifications needed
function classifyRegime(vol){
  if (vol < 0.02) return 'calm';
  if (vol < 0.07) return 'moderate';
  return 'turbulent';
}
function clamp(v,min,max){ return v<min?min: v>max?max: v; }
function recordLearned(entry){
  if(!LEARNED_ENABLE) return;
  try {
    const fs = require('fs');
    if (learnedPrevHash === 'GENESIS' && fs.existsSync(LEARNED_PATH)){
      try { const lines = fs.readFileSync(LEARNED_PATH,'utf8').trim().split(/\n+/); const last=lines[lines.length-1]; const obj=JSON.parse(last); learnedPrevHash = obj.chainHash||'GENESIS'; } catch(_){ }
    }
    entry.prevHash = learnedPrevHash;
    const chainHash = stableHash(entry);
    entry.chainHash = chainHash;
    fs.appendFileSync(LEARNED_PATH, JSON.stringify(entry)+"\n");
    learnedPrevHash = chainHash;
  } catch(e){ /* ignore */ }
}
function computeVolatility(){
  if (recentSpreads.length < 4) return 0; // insufficient data -> treat as stable
  const mean = recentSpreads.reduce((a,b)=>a+b,0)/recentSpreads.length;
  const variance = recentSpreads.reduce((a,b)=> a + Math.pow(b-mean,2),0)/recentSpreads.length;
  const std = Math.sqrt(variance);
  return std;
}
function dynamicThreshold(){
  const vol = computeVolatility();
  // Normalize volatility into [VOL_MIN, VOL_MAX]
  const clamped = Math.min(VOL_MAX, Math.max(VOL_MIN, vol));
  // Increase threshold when volatility high (avoid churn), decrease when stable
  // scale = 1 + VOL_SENSITIVITY * (clamped - VOL_MIN) / (VOL_MAX - VOL_MIN)
  const scale = 1 + VOL_SENSITIVITY * ((clamped - VOL_MIN)/ (VOL_MAX - VOL_MIN));
  const dyn = Number((BASE_MIN_SPREAD_FOR_SWAP * scale).toFixed(6));
  return { dyn, vol: Number(vol.toFixed(6)), scale: Number(scale.toFixed(6)) };
}
const COOLDOWN_MS = 30 * 60 * 1000; // 30 min between swaps
// Strategy B latency weight factor (if enabled): incomeB = incomeBiased / (1 + latency/latRef)
const LAT_WEIGHT_REF_MS = parseFloat(process.env.TRADING_LAT_REF_MS || '400');
const ENABLE_AB = process.env.TRADING_AB_ENABLE === '1';
const AB_LEDGER_PATH = process.env.TRADING_AB_LEDGER_PATH || 'trade-ab-ledger.jsonl';
let __AB_LAST_HASH = null;

let state = {
  lastSwapTs: 0,
  lastSignalHash: null,
  lastCoin: null,
  swapCountHour: 0,
  hourWindowStart: 0
};

function stableHash(v){ return crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex'); }

function resetHour(now){ state.hourWindowStart = now; state.swapCountHour = 0; }

function evaluate(incomeRaw, incomeBiased, latencyMsMap, recommendCoin){
  const now = Date.now();
  if (!state.hourWindowStart || now - state.hourWindowStart >= 3600000) resetHour(now);

  // Determine ranking by biased income (Strategy A)
  const entries = Object.entries(incomeBiased || {});
  if (!entries.length){ return wrapSignal({ action:'hold', coin: recommendCoin || null }, 'no-income'); }

  const ranked = entries.sort((a,b)=>{
    if (b[1] === a[1]){
      const ha = parseInt(stableHash(a[0]).slice(0,8),16);
      const hb = parseInt(stableHash(b[0]).slice(0,8),16);
      return ha - hb;
    }
    return b[1] - a[1];
  });
  const topCoin = ranked[0][0];
  const secondCoin = ranked[1] ? ranked[1][0] : null;
  const topIncome = ranked[0][1];
  const secondIncome = secondCoin ? ranked[1][1] : 0;
  const spread = topIncome > 0 ? (topIncome - secondIncome)/topIncome : 0;

  // Latency penalty: if top coin has latency > 2x median, degrade spread
  let adjustedSpread = spread;
  if (latencyMsMap && topCoin in latencyMsMap){
    const latVals = Object.values(latencyMsMap).filter(x=> typeof x === 'number');
    if (latVals.length){
      const sortedLat = latVals.slice().sort((a,b)=>a-b);
      const median = sortedLat[Math.floor(sortedLat.length/2)];
      const topLat = latencyMsMap[topCoin];
      if (topLat > 2 * median){ adjustedSpread *= 0.7; }
    }
  }

  // Swap decision logic
  const timeSinceLast = now - state.lastSwapTs;
  let action = 'hold';
  let reason = 'default-hold';
  // Update volatility window
  recentSpreads.push(spread);
  if (recentSpreads.length > VOL_WINDOW){ recentSpreads.shift(); }
  const { dyn: threshold, vol, scale } = dynamicThreshold();
  const regime = classifyRegime(vol);
  if (regime === provisionalRegime){
    regimeConfirmCount++;
    if (regimeConfirmCount >= REGIME_CONFIRM_REQUIRED && regime !== currentRegime){
      currentRegime = regime;
    }
  } else {
    provisionalRegime = regime;
    regimeConfirmCount = 1;
  }
  // Adjust learned multiplier bounds per regime deterministically
  let regimeMin = LEARNED_MIN_MULTI, regimeMax = LEARNED_MAX_MULTI;
  if (regime === 'calm'){ regimeMax = Math.min(regimeMax, LEARNED_MAX_MULTI * 0.9); }
  else if (regime === 'turbulent'){ regimeMax = Math.min(LEARNED_MAX_MULTI * 1.0, LEARNED_MAX_MULTI); regimeMin = Math.max(LEARNED_MIN_MULTI * 0.95, LEARNED_MIN_MULTI); }
  // Fee-aware net spread (remove fee cost if swap considered)
  const netSpread = adjustedSpread - FEE_RATE;
  // Learned adaptive multiplier adjusts effective threshold above volatility baseline
  if (LEARNED_ENABLE){
    // Simple deterministic rule: if previous swap was profitable vs hold, gently decrease multiplier; if missed profitable opportunity, increase.
    // We inspect recentSpreads length and netSpread.
    if (netSpread > threshold * learnedMultiplier){
      // executing would have been allowed; set slight decay to encourage capture
      learnedMultiplier = clamp(Number((learnedMultiplier * 0.995).toFixed(6)), regimeMin, regimeMax);
    } else if (netSpread > 0 && adjustedSpread > threshold){
      // threshold met but multiplier blocked; missed opportunity: increase multiplier moderately
      learnedMultiplier = clamp(Number((learnedMultiplier * 1.01).toFixed(6)), regimeMin, regimeMax);
    } else if (netSpread < 0){
      // negative net advantage: be stricter
      learnedMultiplier = clamp(Number((learnedMultiplier * 1.005).toFixed(6)), regimeMin, regimeMax);
    }
  }
  const learnedThreshold = LEARNED_ENABLE ? Number((threshold * learnedMultiplier).toFixed(6)) : threshold;
  if (topCoin !== state.lastCoin && adjustedSpread >= learnedThreshold){
    if (timeSinceLast >= COOLDOWN_MS){
      if (state.swapCountHour < MAX_SWAP_PER_HOUR){
        action = 'swap'; reason = 'spread+cooldown-ok';
      } else { reason = 'hourly-swap-cap'; }
    } else { reason = 'cooldown-active'; }
  } else if (topCoin !== state.lastCoin){
    reason = 'spread-too-low';
  } else {
    reason = 'already-on-top';
  }

  // Strategy B (latency weighted) evaluation (advisory only)
  let stratB = null;
  if (ENABLE_AB && latencyMsMap && Object.keys(incomeBiased||{}).length){
    const latVals = Object.values(latencyMsMap).filter(v=> typeof v === 'number');
    const latMedian = latVals.length? latVals.slice().sort((a,b)=>a-b)[Math.floor(latVals.length/2)] : LAT_WEIGHT_REF_MS;
    const ref = latMedian || LAT_WEIGHT_REF_MS;
    const incomeBMap = {};
    for(const [coin,val] of Object.entries(incomeBiased)){
      const lat = latencyMsMap[coin];
      const wIncome = (lat && lat>0) ? (val / (1 + (lat/ref))) : val;
      incomeBMap[coin] = Number(wIncome.toFixed(12));
    }
    const rankedB = Object.entries(incomeBMap).sort((a,b)=>{
      if (b[1] === a[1]){ const ha = parseInt(stableHash(a[0]).slice(0,8),16); const hb = parseInt(stableHash(b[0]).slice(0,8),16); return ha - hb; }
      return b[1] - a[1];
    });
    const topB = rankedB[0][0];
    stratB = { top: topB, incomeTop: rankedB[0][1], incomeSecond: rankedB[1]? rankedB[1][1]:0, spread: rankedB[0][1]>0? (rankedB[0][1]- (rankedB[1]?rankedB[1][1]:0))/rankedB[0][1] : 0 };
    stratB.spread = Number(stratB.spread.toFixed(6));
  }
  const signal = { action, coin: action==='swap'? topCoin : (state.lastCoin || topCoin), recommend: recommendCoin || topCoin, spread: Number(spread.toFixed(6)), adjustedSpread: Number(adjustedSpread.toFixed(6)), threshold, learnedThreshold, learnedMultiplier: LEARNED_ENABLE? learnedMultiplier:null, feeRate: FEE_RATE, netSpread: Number(netSpread.toFixed(6)), volatility: vol, thresholdScale: scale, regime: currentRegime, stratBTop: stratB?stratB.top:null, stratBSpread: stratB?stratB.spread:null };
  const hash = stableHash({ signal, prev: state.lastSignalHash || 'GENESIS' });

  if (action === 'swap'){
    state.lastSwapTs = now;
    state.lastCoin = topCoin;
    state.swapCountHour++;
    recordLearned({ t:now, event:'swap', coin:topCoin, netSpread:Number(netSpread.toFixed(6)), learnedMultiplier, threshold, learnedThreshold });
  } else if (!state.lastCoin){
    state.lastCoin = topCoin;
    recordLearned({ t:now, event:'init', coin:topCoin, learnedMultiplier, threshold, learnedThreshold });
  } else if (topCoin !== state.lastCoin){
    // hold decision; record potential missed opportunity context
    recordLearned({ t:now, event:'hold', coin:topCoin, netSpread:Number(netSpread.toFixed(6)), learnedMultiplier, threshold, learnedThreshold });
  }

  state.lastSignalHash = hash;
  // AB ledger append (hash-chained)
  if (ENABLE_AB && stratB){
    try {
      const fs = require('fs');
      if (!__AB_LAST_HASH){
        if (fs.existsSync(AB_LEDGER_PATH)){
          try { const lines = fs.readFileSync(AB_LEDGER_PATH,'utf8').trim().split(/\n+/); const last=lines[lines.length-1]; const obj=JSON.parse(last); __AB_LAST_HASH = obj.chainHash || 'GENESIS'; } catch(_){ __AB_LAST_HASH='GENESIS'; }
        } else { __AB_LAST_HASH='GENESIS'; }
      }
      const entry = { t: Date.now(), stratA:{ top:topCoin, spread:Number(spread.toFixed(6)) }, stratB, decision:signal.action, prevHash: __AB_LAST_HASH };
      const chainHash = stableHash(entry);
      entry.chainHash = chainHash;
      fs.appendFileSync(AB_LEDGER_PATH, JSON.stringify(entry)+"\n");
      __AB_LAST_HASH = chainHash;
    } catch(e){ /* ignore ledger errors */ }
  }
  // Structured JSONL logging (optional)
  if (process.env.TRADING_STRUCTURED_LOG === '1'){
    try {
      const fs = require('fs');
      const path = process.env.TRADING_STRUCTURED_PATH || 'trading-signals.jsonl';
      const entry = { t: Date.now(), signal, hash, reason, prev: state.lastSignalHash||'GENESIS' };
      fs.appendFileSync(path, JSON.stringify(entry) + "\n");
    } catch(e){ /* ignore logging errors */ }
  }
  return { signal, hash, reason };
}

function wrapSignal(signal, reason){
  const hash = stableHash({ signal, reason, prev: state.lastSignalHash || 'GENESIS', ts: Date.now() });
  state.lastSignalHash = hash;
  return { signal, hash, reason };
}

module.exports = { evaluate };
// Structured logging (optional) appended inside evaluate when env TRADING_STRUCTURED_LOG=1
