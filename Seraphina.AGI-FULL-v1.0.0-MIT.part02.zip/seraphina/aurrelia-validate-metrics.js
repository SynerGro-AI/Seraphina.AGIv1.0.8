// aurrelia-validate-metrics.js
// Validate a metrics JSONL file against the metrics schema and inject schemaVersion if missing.
// Usage: node aurrelia-validate-metrics.js --in=aurrelia-metrics-merged.jsonl --out=validated.jsonl

const fs = require('fs');
const path = require('path');
const args = process.argv.slice(2);
function getArg(n,d){ const a=args.find(x=>x.startsWith(`--${n}=`)); return a? a.split('=')[1]: d; }
const inFile = getArg('in','aurrelia-metrics-merged.jsonl');
const outFile = getArg('out','aurrelia-metrics-validated.jsonl');
const schemaPath = getArg('schema','aurrelia-metrics-schema.json');

let schema; try { schema = JSON.parse(fs.readFileSync(schemaPath,'utf8')); } catch(e){ console.error('[Schema] load error', e.message); process.exit(1); }

// Minimal inline validator (avoid external deps). Only checks required, type basic.
function validate(obj){
  if (!obj || typeof obj !== 'object') return false;
  for (const r of (schema.required||[])){ if (!(r in obj)) return false; }
  return true;
}

const lines = fs.existsSync(inFile)? fs.readFileSync(inFile,'utf8').trim().split(/\n/).filter(Boolean): [];
let valid=0, invalid=0; const out=[];
for (const l of lines){
  try { const o = JSON.parse(l); if (!o.schemaVersion) o.schemaVersion = 'metrics-v1'; if (validate(o)){ valid++; out.push(JSON.stringify(o)); } else { invalid++; } } catch(_){ invalid++; }
}
fs.writeFileSync(outFile, out.join('\n')+'\n');
console.log(`[Validate] valid=${valid} invalid=${invalid} -> ${outFile}`);
