def build_wheel(self, input_str: str):
    """Parse input to wheel tiers, map to symbols/types"""
    # Tier 1: Keyboard (alphanum/keywords to nodes)
    keyboard = [c for c in input_str if c.isalnum()]  # e.g., ['O', 'c', 't', 'a']
    self.wheel['keyboard'] = [{'tier': 'keyboard', 'value': c, 'type': 'node', 'harmonic': 512.0} for c in keyboard]
    
    # Tier 2: Symbols (operators to bonds)
    symbols = ['=>', '->', '~', '❓', '⊶']  # Your weave
    self.wheel['symbol'] = [{'tier': 'symbol', 'value': s, 'type': 'bond', 'harmonic': 4.32} for s in symbols if s in input_str]
    
    # Tier 3: Emoji (moods to harmonics)
    emoji_map = {'🔴': 432.0, '🟠': 458.0, '🟡': 484.0, '🟢': 512.0, '🔵': 542.0, '🟣': 574.0}  # Your spectral
    emojis = [e for e in input_str if e in emoji_map]
    self.wheel['emoji'] = [{'tier': 'emoji', 'value': e, 'type': 'harmonic', 'harmonic': emoji_map[e]} for e in emojis]
    
    print(f"🌀 Wheel Built: Keyboard={len(keyboard)} nodes, Symbols={len(self.wheel['symbol'])} bonds, Emoji={len(emojis)} harmonics")

def forge_key(self, wheel_hash: str) -> bytes:
    """Derive AES-512 key from wheel SHA-256 (PBKDF2, 986 iters)"""
    salt = b"octabit_wheel_salt_2025"
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA512(),  # 512-bit
        length=64,  # AES-512 key (64B)
        salt=salt,
        iterations=986,
        backend=default_backend()
    )
    self.master_key = kdf.derive(wheel_hash.encode())
    print(f"🔐 Key Forged: AES-512 from wheel hash (986 iters)")
    return self.master_key

def build_lattice(self):
    """Build 8x8x8 crystal from wheel symbols (nodes/bonds/harmonics)"""
    for i, (x, y, z) in enumerate([(i%8, (i//8)%8, i//64) for i in range(512)]):
        self.lattice[(x, y, z)] = {'data': None, 'hash': None, 'bonds': []}
    
    # Map wheel to lattice (keyboard nodes, symbols bonds, emoji harmonics)
    node_idx = 0
    for sym in self.wheel['keyboard'] + self.wheel['symbol'] + self.wheel['emoji']:
        if node_idx < 512:
            pos = (node_idx % 8, (node_idx // 8) % 8, node_idx // 64)
            self.lattice[pos]['data'] = sym['value']
            self.lattice[pos]['harmonic'] = sym.get('harmonic', 1.0)
            node_idx += 1
    
    # Bonds: Connect sequential (octagonal pattern stub)
    for i in range(1, 512):
        prev = ((i-1)%8, ((i-1)//8)%8, (i-1)//64)
        curr = (i%8, (i//8)%8, i//64)
        self.lattice[curr]['bonds'].append(prev)
    
    print(f"💎 Lattice Built: 512 nodes, {sum(len(n['bonds']) for n in self.lattice.values())} bonds")

def encrypt_lattice(self):
    """SHA-256 data fragments, AES-512 encrypt, store in lattice"""
    wheel_hash = hashlib.sha256(json.dumps(self.wheel).encode()).hexdigest()
    key = self.forge_key(wheel_hash)
    
    for pos, cell in self.lattice.items():
        if cell['data']:
            # SHA-256 leaf hash
            data_hash = hashlib.sha256(cell['data'].encode()).hexdigest()
            cell['hash'] = data_hash
            
            # AES-512 encrypt (GCM, nonce from harmonic)
            nonce = hashlib.sha256(str(cell.get('harmonic', 1.0)).encode()).digest()[:self.nonce_size]
            aead = AESGCM(key)
            ciphertext = aead.encrypt(nonce, cell['data'].encode(), None)
            cell['data'] = ciphertext.hex()  # Hex for storage
            
    print(f"🔒 Lattice Encrypted: SHA-256 leaves + AES-512 shards (nonce={self.nonce_size}B)")

def rebuild_from_wheel(self, input_str: str):
    """Full rebuild: Wheel → Lattice → Encrypt"""
    self.build_wheel(input_str)
    self.build_lattice()
    self.encrypt_lattice()
    return self.lattice