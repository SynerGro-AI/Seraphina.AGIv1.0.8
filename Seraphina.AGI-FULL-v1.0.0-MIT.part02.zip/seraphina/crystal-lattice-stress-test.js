// Stress test for CrystalLatticeNode: grows thousands of inward nodes, logs performance and structure
const { CrystalLatticeNode } = require('./crystal-lattice-neural');
const fs = require('fs');

const N = 10000; // Number of nodes to grow (adjust for deeper stress)
const root = new CrystalLatticeNode();
let current = root;
console.log(`Starting lattice stress test: growing ${N} inward nodes...`);
const t0 = Date.now();
for (let i = 0; i < N; ++i) {
  // Simulate a lesson with color/frequency/energy
  const lesson = {
    color: `hsl(${i%360},100%,50%)`,
    freq: 440 + (i%100),
    energy: Math.exp(-i/1000)
  };
  current = current.fire(lesson);
  if ((i+1)%1000 === 0) console.log(`  ...${i+1} nodes grown`);
}
const t1 = Date.now();
console.log(`Done. Total time: ${(t1-t0)/1000}s`);

// Export a summary for visualization
const summary = {
  totalNodes: N+1,
  depth: current.depth,
  lastHash: current.hash,
  rootHash: root.hash,
  samplePath: []
};
// Walk back from current to root to get a sample path
let node = current;
while (node) {
  summary.samplePath.push({ depth: node.depth, hash: node.hash, energy: node.energy });
  node = node.parent;
}
summary.samplePath.reverse();
fs.writeFileSync('lattice-stress-summary.json', JSON.stringify(summary,null,2));
console.log('Summary written to lattice-stress-summary.json');
