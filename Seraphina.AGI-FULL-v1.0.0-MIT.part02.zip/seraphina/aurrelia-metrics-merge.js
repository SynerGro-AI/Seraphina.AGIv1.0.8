// aurrelia-metrics-merge.js
// Consolidate multiple instance metrics JSONL into a unified stream.
// Usage: node aurrelia-metrics-merge.js --out=merged.jsonl metrics-0.jsonl metrics-1.jsonl ...
// If no files passed, glob pattern aurrelia-metrics-*.jsonl is used.

const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
function getArg(name, def){ const a=args.find(x=>x.startsWith(`--${name}=`)); return a? a.split('=')[1]: def; }
const outFile = getArg('out', 'aurrelia-metrics-merged.jsonl');
const follow = args.includes('--follow');
const baseLabel = getArg('label','cluster');
const files = args.filter(a=>!a.startsWith('--') && !a.includes('=*'));
let sources = files;
if (!sources.length){
  // Discover pattern
  sources = fs.readdirSync(process.cwd()).filter(f=> /^aurrelia-metrics-\d+\.jsonl$/.test(f));
}
if (!sources.length){
  console.error('[Merge] No source metrics files found');
  process.exit(1);
}
console.log('[Merge] Sources:', sources.join(', '),'->', outFile, follow? '(follow mode)': '');

// Maintain file offsets for follow mode
const state = new Map(); // file -> offset
for (const f of sources) state.set(f, 0);

function processOnce(){
  const mergedLines = [];
  for (const f of sources){
    try {
      const data = fs.readFileSync(f,'utf8');
      const prevOff = state.get(f)||0;
      const slice = data.slice(prevOff);
      const lines = slice.split(/\n/).filter(Boolean);
      // update offset
      state.set(f, data.length);
      for (const line of lines){
        try { const obj = JSON.parse(line); obj.__src = f; obj.__clusterLabel = baseLabel; mergedLines.push(JSON.stringify(obj)); } catch(_){ }
      }
    } catch(e){ /* ignore missing */ }
  }
  if (mergedLines.length){
    fs.appendFileSync(outFile, mergedLines.join('\n')+'\n');
    console.log(`[Merge] appended ${mergedLines.length} records`);
  }
}

processOnce();
if (follow){ setInterval(processOnce, parseInt(process.env.MERGE_INTERVAL_MS || '5000',10)); }
