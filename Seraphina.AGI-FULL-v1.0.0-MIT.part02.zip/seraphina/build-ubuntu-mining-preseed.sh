#!/usr/bin/env bash
# build-ubuntu-mining-preseed.sh (reconstructed)
# Hybrid OctaLang + Ubuntu minimal mining installer ISO builder.
# WARNING: This script prepares an ISO that can wipe a target disk. Use with caution.
# Usage: ./build-ubuntu-mining-preseed.sh [--msi-disk /dev/nvme0n1] [--output octalang-mining.iso] [--no-wipe]
set -eo pipefail

DISK_TARGET="/dev/sda"
OUTPUT="octalang-mining.iso"
UBUNTU_RELEASE="noble"
UBUNTU_MIRROR="http://archive.ubuntu.com/ubuntu/"
NO_WIPE=false
NVIDIA_ENABLE=false
SEAL_ENABLE=false
ISO_SEAL_KEY=""
COPILOT_ENABLE=false
OCTAPS_ENABLE=false
FRESH_ROOT=false
WORKDIR=$(pwd)/hybrid-iso-build
OCTALANG_SRC_DIR=$(pwd)/minimal-os/baremetal-build/out
USE_UBUNTU_KERNEL=false
NVIDIA_CACHE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --msi-disk) DISK_TARGET="$2"; shift 2 ;;
    --output) OUTPUT="$2"; shift 2 ;;
    --no-wipe) NO_WIPE=true; shift ;;
    --nvidia) NVIDIA_ENABLE=true; shift ;;
    --seal) SEAL_ENABLE=true; shift ;;
    --seal-key) ISO_SEAL_KEY="$2"; shift 2 ;;
    --copilot) COPILOT_ENABLE=true; shift ;;
    --octaps) OCTAPS_ENABLE=true; shift ;;
    --fresh) FRESH_ROOT=true; shift ;;
    --nvidia-cache) NVIDIA_CACHE="$2"; shift 2 ;;
    *) echo "[ERROR] Unknown arg: $1"; exit 1 ;;
  esac
done

echo "[INFO] Hybrid build (DISK_TARGET=$DISK_TARGET OUTPUT=$OUTPUT NO_WIPE=$NO_WIPE COPILOT=$COPILOT_ENABLE OCTAPS=$OCTAPS_ENABLE SEAL=$SEAL_ENABLE)"
mkdir -p "$WORKDIR" && cd "$WORKDIR"

if $FRESH_ROOT && [[ -d ubuntu-root ]]; then
  echo "[INFO] --fresh: removing existing ubuntu-root"
  for m in proc sys dev/pts dev; do
    if mountpoint -q "ubuntu-root/$m"; then sudo umount -lf "ubuntu-root/$m" || true; fi
  done
  sudo rm -rf ubuntu-root || true
fi

EXTRA_PKGS="linux-image-generic,grub-pc,apt"
if [[ ! -d ubuntu-root ]]; then
  echo "[INFO] debootstrap minimal $UBUNTU_RELEASE (include: $EXTRA_PKGS)"
  sudo debootstrap --variant=minbase --include="$EXTRA_PKGS" --arch=amd64 "$UBUNTU_RELEASE" ubuntu-root "$UBUNTU_MIRROR" || { echo "[ERROR] debootstrap failed"; exit 1; }
fi

sudo mount --bind /proc ubuntu-root/proc || echo "[WARN] bind /proc failed"
sudo mount --bind /sys ubuntu-root/sys || echo "[WARN] bind /sys failed"
sudo mount --bind /dev ubuntu-root/dev || echo "[WARN] bind /dev failed"
sudo mkdir -p ubuntu-root/dev/pts && sudo mount --bind /dev/pts ubuntu-root/dev/pts || echo "[WARN] bind /dev/pts failed"
sudo mkdir -p ubuntu-root/run

if [[ ! -f "$OCTALANG_SRC_DIR/bzImage" ]]; then
  echo "[WARN] OctaLang kernel missing; using preinstalled Ubuntu generic kernel"
  USE_UBUNTU_KERNEL=true
else
  echo "[INFO] OctaLang bzImage found"
  sudo mkdir -p ubuntu-root/boot
  sudo cp "$OCTALANG_SRC_DIR/bzImage" ubuntu-root/boot/bzImage || echo "[WARN] copy bzImage failed"
  [[ -f "$OCTALANG_SRC_DIR/initramfs-seraphina.img" ]] && sudo cp "$OCTALANG_SRC_DIR/initramfs-seraphina.img" ubuntu-root/boot/initramfs-seraphina.img || echo "[WARN] initramfs missing"
fi

sudo mkdir -p ubuntu-root/boot/octalang
sudo mkdir -p ubuntu-root/etc/systemd/system/multi-user.target.wants
sudo mkdir -p ubuntu-root/usr/local/bin

echo "[INFO] Creating miner service units"
cat <<'UNIT' | sudo tee ubuntu-root/etc/systemd/system/triad-miner.service >/dev/null
[Unit]
Description=OctaLang Triad Mining Stub
After=network.target
[Service]
ExecStart=/usr/bin/node /boot/octalang/triad_miner.js --f2pool --msi
Restart=always
User=root
[Install]
WantedBy=multi-user.target
UNIT

cat <<'UNIT' | sudo tee ubuntu-root/etc/systemd/system/aurelia-miner.service >/dev/null
[Unit]
Description=Aurelia GPU Miner Stub
After=multi-user.target
[Service]
Type=simple
ExecStart=/usr/bin/node /boot/octalang/aurelia_miner.js --cuda --pool=f2pool --msi --rate-cap=1000
Restart=always
User=root
[Install]
WantedBy=multi-user.target
UNIT

echo "[INFO] Writing miner stubs"
cat <<'TRIAD' | sudo tee ubuntu-root/boot/octalang/triad_miner.js >/dev/null
#!/usr/bin/env node
console.log('[TriadMiner] stub starting');
setInterval(()=> console.log('[TriadMiner] heartbeat '+Date.now()),15000);
TRIAD
sudo chmod +x ubuntu-root/boot/octalang/triad_miner.js

cat <<'AURELIA' | sudo tee ubuntu-root/boot/octalang/aurelia_miner.js >/dev/null
#!/usr/bin/env node
console.log('[AureliaMiner] GPU stub starting');
let i=0; setInterval(()=>{ i++; console.log('[AureliaMiner] gpu-heartbeat '+i); },12000);
AURELIA
sudo chmod +x ubuntu-root/boot/octalang/aurelia_miner.js

echo "[INFO] Adding GRUB custom entry"
sudo mkdir -p ubuntu-root/etc/grub.d
cat <<GRUBCFG | sudo tee ubuntu-root/etc/grub.d/40_octalang >/dev/null
#!/bin/sh
exec tail -n +3 $0
menuentry "OctaLang Mining" {
  linux /boot/$( $USE_UBUNTU_KERNEL && echo vmlinuz || echo bzImage ) root=/dev/sda1 octalang.mode=binary phi.seed=1.618
  initrd /boot/$( $USE_UBUNTU_KERNEL && echo initrd.img || echo initramfs-seraphina.img )
}
GRUBCFG
sudo chmod +x ubuntu-root/etc/grub.d/40_octalang || true

if $COPILOT_ENABLE; then
  echo "[INFO] Embedding copilot"
  cat <<'COPILOT' | sudo tee ubuntu-root/boot/octalang/octa-copilot-service.js >/dev/null
#!/usr/bin/env node
const http=require('http'); const crypto=require('crypto');
function h(x){return crypto.createHash('sha256').update(x).digest('hex').slice(0,32);} 
const shield=/\.ssh|id_rsa|wallet|seed|mnemonic|passphrase|artifact-hashes\.json|source-manifest|package\.json|node_modules|\.env/i;
http.createServer((req,res)=>{ if(req.method!=='POST'){res.writeHead(405);return res.end('Method Not Allowed');}
  let b=''; req.on('data',c=>b+=c); req.on('end',()=>{ let d={}; try{d=JSON.parse(b);}catch{}; const p=(d.prompt||'');
    if(shield.test(p)){ res.writeHead(200,{"Content-Type":"application/json"}); return res.end(JSON.stringify({blocked:true})); }
    const lang=d.language||'js'; const digest=h(lang+':'+p.replace(/\s+/g,' ').trim());
    res.writeHead(200,{"Content-Type":"application/json"}); res.end(JSON.stringify({language:lang,prompt:p,digest,suggestion:'// digest:'+digest,ts:Date.now()})); }); }).listen(8123,()=>console.log('[Copilot] 8123')); 
COPILOT
  sudo chmod +x ubuntu-root/boot/octalang/octa-copilot-service.js
  cat <<'UNIT' | sudo tee ubuntu-root/etc/systemd/system/octa-copilot.service >/dev/null
[Unit]
Description=Deterministic Octa Copilot
After=network.target
[Service]
ExecStart=/usr/bin/node /boot/octalang/octa-copilot-service.js
Restart=always
User=root
[Install]
WantedBy=multi-user.target
UNIT
  sudo ln -sf /etc/systemd/system/octa-copilot.service ubuntu-root/etc/systemd/system/multi-user.target.wants/octa-copilot.service || true
fi

if $OCTAPS_ENABLE; then
  echo "[INFO] Embedding OctaPowershell install unit"
  cat <<'APS' | sudo tee ubuntu-root/etc/systemd/system/octaps-install.service >/dev/null
[Unit]
Description=Install PowerShell Core (OctaPowershell)
After=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/bin/bash -c "wget -q https://packages.microsoft.com/config/ubuntu/24.04/packages-microsoft-prod.deb -O /tmp/ms.deb && dpkg -i /tmp/ms.deb && apt-get update -y && apt-get install -y powershell && rm -f /tmp/ms.deb || true"
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
APS
  sudo ln -sf /etc/systemd/system/octaps-install.service ubuntu-root/etc/systemd/system/multi-user.target.wants/octaps-install.service || true
fi

echo "[INFO] Weaving chroot dirs"
sudo mkdir -p ubuntu-root/etc/systemd/system/multi-user.target.wants || true
sudo mkdir -p ubuntu-root/usr/local/bin || true

if [[ -f ubuntu-root/etc/systemd/system/octa-copilot.service ]]; then
  sudo ln -sf /etc/systemd/system/octa-copilot.service ubuntu-root/etc/systemd/system/multi-user.target.wants/octa-copilot.service && echo "[OK] octa-copilot.service symlinked" || echo "[WARN] copilot symlink failed"
else
  echo "[WARN] octa-copilot.service missing (copilot disabled?)"
fi

if [[ -f ubuntu-root/etc/systemd/system/octaps-install.service ]]; then
  sudo ln -sf /etc/systemd/system/octaps-install.service ubuntu-root/etc/systemd/system/multi-user.target.wants/octaps-install.service && echo "[OK] octaps-install.service symlinked" || echo "[WARN] octaps symlink failed"
else
  echo "[WARN] octaps-install.service missing (octaps disabled?)"
fi

echo "[INFO] Generating preseed.cfg"
cat <<'PRESEED' | sudo tee ubuntu-root/preseed.cfg >/dev/null
d-i netcfg/choose_interface select auto
d-i clock-setup/utc boolean true
d-i mirror/country string manual
d-i mirror/http/proxy string
d-i pkgsel/include string openssh-server nodejs npm
d-i pkgsel/update-policy select none
d-i grub-installer/only_debian boolean true
d-i finish-install/reboot_in_progress note
PRESEED

if ! $NO_WIPE; then
  echo "[INFO] Adding first-boot wipe script"
  cat <<WIPE | sudo tee ubuntu-root/usr/local/bin/msi-wipe-build.sh >/dev/null
#!/bin/bash
set -euo pipefail
TARGET_DISK='$DISK_TARGET'
CONFIRM="${WIPE_CONFIRM:-}"
if [[ "$CONFIRM" != 'YES' ]]; then echo '[WIPE] Skipping disk wipe (set WIPE_CONFIRM=YES)'; exit 0; fi
echo '[WIPE] Wiping first 100MB of disk:' $TARGET_DISK
dd if=/dev/zero of=$TARGET_DISK bs=1M count=100 status=progress || true
parted -s $TARGET_DISK mklabel gpt
parted -s $TARGET_DISK mkpart ESP fat32 1MiB 512MiB
parted -s $TARGET_DISK set 1 esp on
parted -s $TARGET_DISK mkpart primary ext4 512MiB 100%
mkfs.fat -F32 ${TARGET_DISK}p1
mkfs.ext4 -F ${TARGET_DISK}p2
echo '[WIPE] Partitioning complete.'
WIPE
  sudo chmod +x ubuntu-root/usr/local/bin/msi-wipe-build.sh
fi

echo "[INFO] Staging ISO tree"
mkdir -p iso/boot/grub iso/casper
sudo rsync -a ubuntu-root/ iso/ || true

if $USE_UBUNTU_KERNEL; then
  ub_vmlinuz=$(ls -1 ubuntu-root/boot/vmlinuz* 2>/dev/null | tail -n 1)
  ub_initrd=$(ls -1 ubuntu-root/boot/initrd.img* 2>/dev/null | tail -n 1)
  cp "$ub_vmlinuz" iso/casper/vmlinuz
  cp "$ub_initrd" iso/casper/initrd
else
  cp ubuntu-root/boot/bzImage iso/casper/vmlinuz || true
  cp ubuntu-root/boot/initramfs-seraphina.img iso/casper/initrd || touch iso/casper/initrd
fi

cat <<GRUBISO > iso/boot/grub/grub.cfg
set default=0
set timeout=5
menuentry 'Install OctaLang Mining (Non-Destructive)' {
  linux /casper/vmlinuz boot=casper preseed/file=/preseed.cfg noprompt
  initrd /casper/initrd
}
menuentry 'Install OctaLang Mining (WIPE ENABLED)' {
  linux /casper/vmlinuz boot=casper preseed/file=/preseed.cfg WIPE_CONFIRM=YES noprompt
  initrd /casper/initrd
}
GRUBISO

if $SEAL_ENABLE; then
  echo "[INFO] Building manifest & seal"
  MANIFEST_FILE=iso/iso-manifest.json
  SEAL_FILE=iso/iso-manifest.seal.json
  echo '[' > "$MANIFEST_FILE"; first=true
  while IFS= read -r -d '' f; do
    rel="${f#iso/}"; sha=$(sha256sum "$f" | awk '{print $1}'); size=$(stat -c %s "$f")
    $first || echo ',' >> "$MANIFEST_FILE"; first=false
    printf '{"path":"%s","sha256":"%s","size":%s}' "$rel" "$sha" "$size" >> "$MANIFEST_FILE"
  done < <(find iso -type f -print0 | sort -z)
  echo ']' >> "$MANIFEST_FILE"
  if [[ -z "$ISO_SEAL_KEY" ]]; then
    fc=$(grep -c 'sha256' "$MANIFEST_FILE"); ts=$(grep -o '"size":[0-9]*' "$MANIFEST_FILE" | awk -F: '{s+=$2} END{print s}')
    ISO_SEAL_KEY=$(printf '%s:%s' "$fc" "$ts" | sha256sum | awk '{print $1}')
    echo "[WARN] Using fallback seal key $ISO_SEAL_KEY"
  fi
  seal_hmac=$(openssl dgst -sha256 -hmac "$ISO_SEAL_KEY" "$MANIFEST_FILE" | awk '{print $2}')
  files_count=$(grep -c 'sha256' "$MANIFEST_FILE")
  printf '{"hmac_sha256":"%s","key_provided":%s,"generated_at":"%s","files":%s}' "$seal_hmac" $([[ -z "$ISO_SEAL_KEY" ]] && echo false || echo true) "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$files_count" > "$SEAL_FILE"
fi

echo "[INFO] Building ISO: $OUTPUT"
if ! xorriso -as mkisofs -r -V 'OctaLangMining' -J -l -o "$OUTPUT" iso/ 2>&1 | tee "$WORKDIR/xorriso.log"; then
  echo "[ERROR] xorriso failed"; exit 1
fi
[[ -f "$OUTPUT" ]] || { echo "[ERROR] ISO missing"; exit 1; }
echo "[OK] ISO ready: $WORKDIR/$OUTPUT"
for a in "$WORKDIR/$OUTPUT" "iso/iso-manifest.json" "iso/iso-manifest.seal.json"; do
  [[ -f "$a" ]] && ls -lh "$a" || echo "[MISS] $a"
done
echo "[HINT] Flash with: sudo dd if=$WORKDIR/$OUTPUT of=/dev/sdX bs=4M status=progress && sync"

cleanup() {
  for d in /proc /sys /dev/pts /dev; do
    if mountpoint -q "ubuntu-root$d" 2>/dev/null; then sudo umount "ubuntu-root$d" || true; fi
  done
}
trap cleanup EXIT
  if [[ -f "$(pwd)/../octa-powershell.ps1" ]]; then
    sudo cp "$(pwd)/../octa-powershell.ps1" ubuntu-root/opt/octalang/scripts/
  elif [[ -f "$(pwd)/octa-powershell.ps1" ]]; then
    sudo cp "$(pwd)/octa-powershell.ps1" ubuntu-root/opt/octalang/scripts/
  else
    echo "[WARN] octa-powershell.ps1 not found in source root; skipping copy"
  fi
  sudo bash -c 'cat > ubuntu-root/etc/systemd/system/octaps-install.service <<'APS'
[Unit]
Description=Install PowerShell Core for OctaPowershell
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/bash -c "wget -q https://packages.microsoft.com/config/ubuntu/24.04/packages-microsoft-prod.deb -O /tmp/ms.deb && dpkg -i /tmp/ms.deb && apt-get update -y && apt-get install -y powershell && rm -f /tmp/ms.deb || true"
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
APS'
  sudo ln -sf /etc/systemd/system/octaps-install.service ubuntu-root/etc/systemd/system/multi-user.target.wants/octaps-install.service || true
fi

echo "[INFO] Generating preseed (NO_WIPE=$NO_WIPE)"
sudo bash -c "cat > ubuntu-root/preseed.cfg <<'PRESEED'
d-i netcfg/choose_interface select auto
d-i clock-setup/utc boolean true
d-i mirror/country string manual
d-i mirror/http/proxy string
d-i pkgsel/include string openssh-server nodejs npm
d-i pkgsel/update-policy select none
d-i grub-installer/only_debian boolean true
d-i finish-install/reboot_in_progress note
PRESEED"

if ! $NO_WIPE; then
  echo "[INFO] Adding first-boot wipe script (msi-wipe-build.sh)"
  cat <<WIPE | sudo tee ubuntu-root/usr/local/bin/msi-wipe-build.sh >/dev/null
#!/bin/bash
set -euo pipefail
TARGET_DISK='${DISK_TARGET}'
CONFIRM="${WIPE_CONFIRM:-}"
if [[ "$CONFIRM" != 'YES' ]]; then
  echo '[WIPE] Skipping disk wipe: set WIPE_CONFIRM=YES to proceed.'
  exit 0
fi
echo '[WIPE] Wiping first 100MB of disk:' $TARGET_DISK
dd if=/dev/zero of=$TARGET_DISK bs=1M count=100 status=progress || true
parted -s $TARGET_DISK mklabel gpt
parted -s $TARGET_DISK mkpart ESP fat32 1MiB 512MiB
parted -s $TARGET_DISK set 1 esp on
parted -s $TARGET_DISK mkpart primary ext4 512MiB 100%
mkfs.fat -F32 ${TARGET_DISK}p1
mkfs.ext4 -F ${TARGET_DISK}p2
echo '[WIPE] Partitioning complete.'
WIPE
  sudo chmod +x ubuntu-root/usr/local/bin/msi-wipe-build.sh
  if $NVIDIA_ENABLE; then
    echo "[INFO] Staging NVIDIA driver version $NVIDIA_VERSION"
    sudo bash -c "cat > ubuntu-root/usr/local/bin/nvidia-driver-install.sh <<'NVID'
#!/bin/bash
set -euo pipefail
VER='${NVIDIA_VERSION}'
EXPECTED='${NVIDIA_HASH}'
URL="https://us.download.nvidia.com/XFree86/Linux-x86_64/${NVIDIA_VERSION}/NVIDIA-Linux-x86_64-${NVIDIA_VERSION}.run"
cd /tmp
echo '[NVIDIA] Downloading driver:' $URL
if [[ -n '${NVIDIA_CACHE}' && -f '/boot/octalang/${NVIDIA_CACHE}' ]]; then
  echo '[NVIDIA] Using cached driver file: /boot/octalang/${NVIDIA_CACHE}'
  cp /boot/octalang/${NVIDIA_CACHE} nvidia.run
else
  wget -q $URL -O nvidia.run
fi
ACTUAL=$(sha256sum nvidia.run | awk '{print $1}')
if [[ "$ACTUAL" != "$EXPECTED" ]]; then
  echo '[NVIDIA] SHA256 mismatch! Expected '"$EXPECTED"' got '"$ACTUAL"''
  exit 1
fi
echo '[NVIDIA] Hash verified.'
chmod +x nvidia.run
./nvidia.run --silent --no-questions --no-nouveau-check --dkms --run-nvidia-modprobe || { echo '[NVIDIA] Install failed'; exit 1; }
rm -f nvidia.run
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi | head -n 5
else
  echo '[NVIDIA] nvidia-smi not found after install'
fi
NVID"
    sudo chmod +x ubuntu-root/usr/local/bin/nvidia-driver-install.sh
    sudo bash -c "cat > ubuntu-root/etc/systemd/system/nvidia-install.service <<'NU'
[Unit]
Description=Install NVIDIA Driver on First Boot
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/nvidia-driver-install.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
NU"
    sudo ln -sf /etc/systemd/system/nvidia-install.service ubuntu-root/etc/systemd/system/multi-user.target.wants/nvidia-install.service || true
  fi
else
  echo "[INFO] NO_WIPE set: skipping destructive script"
fi

echo "[INFO] Preparing ISO staging"
mkdir -p iso/boot/grub iso/casper
sudo rsync -a ubuntu-root/ iso/ || true
if $NVIDIA_ENABLE && [[ -n "$NVIDIA_CACHE" && -f "$NVIDIA_CACHE" ]]; then
  echo "[INFO] Copying NVIDIA cache file into ISO for offline install"
  sudo cp "$NVIDIA_CACHE" iso/boot/octalang/ || echo "[WARN] Provided NVIDIA cache file not found: $NVIDIA_CACHE"
fi

# Kernel/initrd for installer boot: prefer OctaLang artifacts, else Ubuntu kernel installed in chroot
if $USE_UBUNTU_KERNEL; then
  echo "[INFO] Using Ubuntu kernel for installer boot"
  # Copy latest vmlinuz and initrd.img found in chroot /boot
  ub_vmlinuz=$(ls -1 ubuntu-root/boot/vmlinuz* 2>/dev/null | tail -n 1)
  ub_initrd=$(ls -1 ubuntu-root/boot/initrd.img* 2>/dev/null | tail -n 1)
  if [[ -z "$ub_vmlinuz" || -z "$ub_initrd" ]]; then
    echo "[ERROR] Ubuntu kernel files not found in chroot /boot"; exit 1
  fi
  cp "$ub_vmlinuz" iso/casper/vmlinuz
  cp "$ub_initrd" iso/casper/initrd
else
  echo "[INFO] Using OctaLang kernel for installer boot"
  cp ubuntu-root/boot/bzImage iso/casper/vmlinuz || true
  cp ubuntu-root/boot/initramfs-seraphina.img iso/casper/initrd || touch iso/casper/initrd
fi

cat > iso/boot/grub/grub.cfg <<'GRUBISO'
set default=0
set timeout=5
menuentry 'Install OctaLang Mining (Non-Destructive)' {
  linux /casper/vmlinuz boot=casper preseed/file=/preseed.cfg noprompt NVIDIA_ENABLE=$NVIDIA_ENABLE
  initrd /casper/initrd
}
menuentry 'Install OctaLang Mining (WIPE ENABLED)' {
  linux /casper/vmlinuz boot=casper preseed/file=/preseed.cfg WIPE_CONFIRM=YES noprompt NVIDIA_ENABLE=$NVIDIA_ENABLE
  initrd /casper/initrd
}
GRUBISO

echo "[INFO] Building ISO: $OUTPUT"
xset_manifest() { :; }
if $SEAL_ENABLE; then
  echo "[INFO] Generating ISO manifest & seal"
  MANIFEST_FILE=iso/iso-manifest.json
  SEAL_FILE=iso/iso-manifest.seal.json
  echo '[' > "$MANIFEST_FILE"
  first=true
  while IFS= read -r -d '' f; do
    rel="${f#iso/}"
    sha=$(sha256sum "$f" | awk '{print $1}')
    size=$(stat -c %s "$f")
    if ! $first; then echo ',' >> "$MANIFEST_FILE"; else first=false; fi
    printf '{"path":"%s","sha256":"%s","size":%s}' "$rel" "$sha" "$size" >> "$MANIFEST_FILE"
  done < <(find iso -type f -print0 | sort -z)
  echo ']' >> "$MANIFEST_FILE"
  if [[ -z "$ISO_SEAL_KEY" ]]; then
    file_count=$(jq length "$MANIFEST_FILE" 2>/dev/null || grep -c 'sha256' "$MANIFEST_FILE")
    total_size=$(grep -o '"size":[0-9]*' "$MANIFEST_FILE" | awk -F: '{s+=$2} END{print s}')
    ISO_SEAL_KEY=$(printf '%s:%s' "$file_count" "$total_size" | sha256sum | awk '{print $1}')
    echo "[WARN] ISO_SEAL_KEY not provided; using deterministic fallback key digest $ISO_SEAL_KEY"
  fi
  seal_hmac=$(openssl dgst -sha256 -hmac "$ISO_SEAL_KEY" "$MANIFEST_FILE" | awk '{print $2}')
  files_count=$(jq length "$MANIFEST_FILE" 2>/dev/null || echo 0)
  key_provided=$([ -z "$ISO_SEAL_KEY" ] && echo false || echo true)
  generated_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  cat > "$SEAL_FILE" <<EOF
{
  "hmac_sha256": "$seal_hmac",
  "key_provided": $key_provided,
  "generated_at": "$generated_at",
  "files": $files_count
}
EOF
  echo "[INFO] Seal written: $SEAL_FILE"
fi
echo "[TriadInstrument] Xorriso start ts=$(date +%s) payload_size=$(du -sh iso 2>/dev/null | awk '{print $1}')"
if ! xorriso -as mkisofs -r -V 'OctaLangMining' -J -l \
  -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin \
  -partition_offset 16 \
  -append_partition 2 0xef iso/boot/grub/grub.cfg \
  -o "$OUTPUT" iso/ 2>&1 | tee -a "$WORKDIR/xorriso.log"; then
  echo "[TriadInstrument][ERROR] xorriso failed; tail follows:" >&2
  tail -20 "$WORKDIR/xorriso.log" >&2 || true
  exit 1
fi
if [[ ! -f "$OUTPUT" ]]; then
  echo "[TriadInstrument][FATAL] ISO missing after xorriso: $OUTPUT" >&2
  exit 1
fi
echo "[TriadInstrument] Xorriso end ts=$(date +%s) size_bytes=$(stat -c %s "$OUTPUT" 2>/dev/null || echo 0)"
echo "[OK] ISO ready: $WORKDIR/$OUTPUT"
echo "[INFO] Artifact summary:"
for a in "$WORKDIR/$OUTPUT" "iso/iso-manifest.json" "iso/iso-manifest.seal.json"; do
  if [[ -f "$a" ]]; then ls -lh "$a"; else echo "[MISS] $a"; fi
done
echo "[HINT] Flash with: sudo dd if=$WORKDIR/$OUTPUT of=/dev/sdX bs=4M status=progress && sync"

# Single cleanup trap (bind mounts)
cleanup_binds() {
  for d in /proc /sys /dev/pts /dev; do
    if mountpoint -q "ubuntu-root${d}" 2>/dev/null; then
      sudo umount "ubuntu-root${d}" || echo "[WARN] Failed unmount ubuntu-root${d}"
    fi
  done
}
trap cleanup_binds EXIT