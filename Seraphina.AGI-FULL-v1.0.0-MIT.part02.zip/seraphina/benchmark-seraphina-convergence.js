// benchmark-seraphina-convergence.js
// Measures epochs required to reach target accuracy for loop, native, and mathjs modes.
'use strict';
const { performance } = require('perf_hooks');
const child_process = require('child_process');

function runTrain(env){
  return new Promise((resolve)=>{
    const t0 = performance.now();
    const proc = child_process.spawn(process.execPath, ['seraphina-model-train.js'], { env:{...process.env, ...env}, stdio:['ignore','pipe','pipe'] });
    let out='';
    proc.stdout.on('data',d=> out+=d.toString());
    proc.stderr.on('data',d=> out+=d.toString());
    proc.on('exit',()=>{ resolve({ ms: performance.now()-t0, log: out }); });
  });
}

async function main(){
  const targetAcc = parseFloat(process.env.CONVERGENCE_TARGET_ACC || '0.85');
  const baseEpochs = parseInt(process.env.CONVERGENCE_BASE_EPOCHS || '30',10);
  const increment = parseInt(process.env.CONVERGENCE_EPOCH_INC || '30',10);
  const maxEpochs = parseInt(process.env.CONVERGENCE_MAX_EPOCHS || '600',10);
  // dataset size override for stability
  const benchN = process.env.BENCH_TRAIN_N || '20000';
  let results = [];
  async function searchMode(label, extraEnv){
    for(let ep=baseEpochs; ep<=maxEpochs; ep+=increment){
      const env = {
        SERAPHINA_MODEL_EPOCHS: String(ep),
        SERAPHINA_VECTORIZE: extraEnv.SERAPHINA_VECTORIZE||'0',
        SERAPHINA_VECTORIZE_MODE: extraEnv.SERAPHINA_VECTORIZE_MODE||'',
        BENCH_TRAIN_N: benchN,
        // force full batch for deterministic comparison
        SERAPHINA_BATCH_SIZE: '0'
      };
      const r = await runTrain(env);
      let acc=null; let lossA=null;
      const m = /\"acc\":\s*(\d+\.\d+)/.exec(r.log);
      if(m) acc = parseFloat(m[1]);
      const l = /\"lossA\":\s*(\d+\.\d+)/.exec(r.log);
      if(l) lossA = parseFloat(l[1]);
      if(acc!==null){
        results.push({ mode:label, epochs:ep, acc, lossA, ms:r.ms });
        if(acc >= targetAcc) break;
      }
    }
  }
  await searchMode('loop', { SERAPHINA_VECTORIZE:'0' });
  await searchMode('native', { SERAPHINA_VECTORIZE:'1', SERAPHINA_VECTORIZE_MODE:'native' });
  await searchMode('mathjs', { SERAPHINA_VECTORIZE:'1', SERAPHINA_VECTORIZE_MODE:'mathjs' });
  const summary = { ts:Date.now(), targetAcc, results };
  console.log('[ConvergenceBenchmark] '+JSON.stringify(summary, null, 2));
  // Ledger append via chain module
  try { const { appendWithChain } = require('./ledger-chain-rotate'); appendWithChain(summary); } catch(e){ console.warn('[ConvergenceBenchmarkLedger] chain append error', e.message); }
}
main().catch(e=>{ console.error(e); process.exit(1); });
