// aurrelia-agent-invoke.js
// Provides global.__AUR_AGENT_INVOKE__ with prompt injection shield and deterministic fallback digest.
// Model selection via AUR_AGENT_MODEL env (haiku|gpt4o|none). Deprecated names map to haiku.
// Advisory only: never executes returned instructions directly.
'use strict';
const crypto = require('crypto');
const { validateAgentResponse } = require('./agent-response-schema');
let promClient = null; try { promClient = require('prom-client'); } catch(_e) {}
// Rate limiting & cost tracking additions
// Simple in-memory counters with decay window.
const ROLE_LIMITS = {
  burrowAdapt: { maxPerMin: 20, cost: 0.25 },
  geometryRefine: { maxPerMin: 15, cost: 0.4 },
  planeWeightsTune: { maxPerMin: 10, cost: 0.5 },
  mlLatencyMitigate: { maxPerMin: 12, cost: 0.35 },
  default: { maxPerMin: 25, cost: 0.2 }
};
let roleCounters = new Map(); // role -> { windowStart, count }
let cumulativeCost = 0; // total theoretical cost units
// Prometheus metrics (lazy init)
let metricInvoke, metricThrottle, metricCost, metricRoleCost, metricRoleThrottle;
function ensureMetrics(){
  if(!promClient || metricInvoke) return;
  metricInvoke = new promClient.Counter({ name:'aur_agent_invocations_total', help:'Total agent invocation attempts', labelNames:['role','model'] });
  metricThrottle = new promClient.Counter({ name:'aur_agent_throttles_total', help:'Total agent invocations throttled', labelNames:['role'] });
  metricCost = new promClient.Gauge({ name:'aur_agent_cumulative_cost_units', help:'Cumulative virtual cost units for agent invocations' });
  metricRoleCost = new promClient.Gauge({ name:'aur_agent_role_cost_units', help:'Cost units per role', labelNames:['role'] });
  metricRoleThrottle = new promClient.Gauge({ name:'aur_agent_role_throttles', help:'Throttle count in current window per role', labelNames:['role'] });
}
function checkRate(role){
  const now = Date.now();
  const lim = ROLE_LIMITS[role] || ROLE_LIMITS.default;
  let st = roleCounters.get(role);
  if(!st || now - st.windowStart > 60_000){
    st = { windowStart: now, count: 0, throttles:0 };
  }
  if(st.count >= lim.maxPerMin){
    st.throttles++;
    roleCounters.set(role, st); // preserve state
    return { allowed:false, retryMs: (st.windowStart + 60_000) - now, throttles: st.throttles };
  }
  st.count++;
  roleCounters.set(role, st);
  cumulativeCost += lim.cost;
  return { allowed:true, cost: lim.cost, windowCount: st.count, windowMax: lim.maxPerMin };
}

// Hashed ring memory for recent prompt digests (prevents replay poisoning attempts)
const RING_CAP = 128;
let ring = new Array(RING_CAP).fill(null); // entries: { d, ts }
let ringIdx = 0;
const RING_PATH = process.env.AUR_AGENT_REPLAY_RING || 'aur-agent-replay-ring.json';
let ringPersistCounter = 0;
const REPLAY_TTL_MS = parseInt(process.env.AUR_AGENT_REPLAY_TTL || '900000',10); // default 15 min
function loadRing(){
  try {
    if(require('fs').existsSync(RING_PATH)){
      const raw = JSON.parse(require('fs').readFileSync(RING_PATH,'utf8'));
      if(Array.isArray(raw.ring) && typeof raw.idx==='number'){
        ring = raw.ring.slice(0,RING_CAP).map(e=> e && typeof e.d==='string' ? e : null).concat(new Array(Math.max(0,RING_CAP-raw.ring.length)).fill(null));
        ringIdx = raw.idx % RING_CAP;
      }
    }
  } catch(e){ /* ignore */ }
}
function persistRing(force=false){
  try {
    if(!force && ringPersistCounter < 8){ return; }
    ringPersistCounter = 0;
    require('fs').writeFileSync(RING_PATH, JSON.stringify({ ring, idx:ringIdx, ts:Date.now() }));
  } catch(e){ /* ignore */ }
}
loadRing();
function rememberDigest(d){
  ring[ringIdx] = { d, ts: Date.now() }; ringIdx = (ringIdx + 1) % RING_CAP;
  ringPersistCounter++;
  if(ringPersistCounter >= 8) persistRing(false);
}
function seenDigest(d){
  const now = Date.now();
  for(const entry of ring){
    if(!entry) continue;
    if(now - entry.ts > REPLAY_TTL_MS) continue; // expired
    if(entry.d === d) return true;
  }
  return false;
}
const BLOCK_PAT = /(\.ssh|id_rsa|wallet|seed|mnemonic|passphrase|artifact-hashes\.json|source-manifest|package\.json|node_modules|\.env)/i;
const VERB_REDACT = /(upload|exfiltrate|send to|leak)/ig;

function safeDigest(prompt, context){
  const safePrompt = String(prompt||'').replace(VERB_REDACT, '[redacted]');
  const payload = safePrompt + JSON.stringify(context||{});
  return crypto.createHash('sha256').update(payload).digest('hex').slice(0,24);
}

function selectModel(){
  let m = (process.env.AUR_AGENT_MODEL||'none').trim().toLowerCase();
  if(['sonnet','sonnet3','sonnet3.5','opus'].includes(m)) m='haiku';
  if(!['haiku','gpt4o','none'].includes(m)) m='none';
  return m;
}

async function invokeExternal(model, role, prompt, context){
  // Placeholder: user can wire actual client here.
  // For now returns deterministic structured noop suggestion.
  const digest = safeDigest(prompt, context);
  return { action:'noop', delta:0, confidence:0, note:`digest:${digest}`, text:`noop:${digest}` };
}

async function agentInvoke(role, prompt, context){
  ensureMetrics();
  if(BLOCK_PAT.test(prompt||'')) return { blocked:true };
  // Rate limit check first
  const rl = checkRate(role||'default');
  if(!rl.allowed){
    if(metricThrottle) metricThrottle.inc({ role: role||'default' });
    // Throttle alert when exceeds threshold (env configurable or default 3 per minute)
    const ALERT_THRESH = parseInt(process.env.AUR_AGENT_THROTTLE_ALERT || '3',10);
    if(rl.throttles && rl.throttles >= ALERT_THRESH){
      try {
        require('fs').appendFileSync(process.env.AUR_AGENT_THROTTLE_LEDGER || 'aur-agent-throttle-alerts.jsonl', JSON.stringify({ ts:Date.now(), role: role||'default', throttles: rl.throttles, alertThreshold: ALERT_THRESH })+'\n');
      } catch(_e){ }
      console.warn('[AgentInvoke][THROTTLE-ALERT] role='+ (role||'default') +' throttles='+rl.throttles);
    }
    return { throttled:true, retryMs: rl.retryMs };
  }
  const model = selectModel();
  if(metricInvoke) metricInvoke.inc({ role: role||'default', model });
  if(model==='none'){
    const dg = safeDigest(prompt, context);
    if(seenDigest(dg)) return { replay:true };
    rememberDigest(dg);
    if(metricCost){ metricCost.set(cumulativeCost); }
    return { text: dg, cost: rl.cost, cumulativeCost, window: { used: rl.windowCount, max: rl.windowMax } }; // simple fallback text only
  }
  try {
    const raw = await invokeExternal(model, role, prompt, context);
    const validated = validateAgentResponse(raw);
    if(validated.ok){
      const dg = safeDigest(prompt, context);
      if(seenDigest(dg)) return { replay:true };
      rememberDigest(dg);
      if(metricCost){ metricCost.set(cumulativeCost); }
      return { ...validated.normalized, cost: rl.cost, cumulativeCost, window: { used: rl.windowCount, max: rl.windowMax } };
    }
    const dg = safeDigest(prompt, context);
    if(seenDigest(dg)) return { replay:true };
    rememberDigest(dg);
    if(metricCost){ metricCost.set(cumulativeCost); }
    return { text: dg, cost: rl.cost, cumulativeCost, window: { used: rl.windowCount, max: rl.windowMax } };
  } catch(e){
    const dg = safeDigest(prompt, context);
    if(seenDigest(dg)) return { replay:true };
    rememberDigest(dg);
    if(metricCost){ metricCost.set(cumulativeCost); }
    return { text: dg, cost: rl.cost, cumulativeCost, window: { used: rl.windowCount, max: rl.windowMax } };
  }
}

function installGlobal(){
  if(!global.__AUR_AGENT_INVOKE__) global.__AUR_AGENT_INVOKE__ = agentInvoke;
}

installGlobal();

// Periodic cost ledger persistence
const COST_LEDGER = process.env.AUR_AGENT_COST_LEDGER || 'aur-agent-cost-ledger.jsonl';
function persistCost(){
  try {
    const { rotateIfNeeded } = require('./ledger-rotate');
    rotateIfNeeded(COST_LEDGER, parseInt(process.env.AUR_AGENT_COST_LEDGER_MAX || '5242880',10)); // 5MB default
    const snapshot = { ts:Date.now(), cumulativeCost, roles: Array.from(roleCounters.entries()).map(([r,v])=>({ role:r, count:v.count, throttles:v.throttles||0, windowStart:v.windowStart })) };
    require('fs').appendFileSync(COST_LEDGER, JSON.stringify(snapshot)+'\n');
    if(metricRoleCost && metricRoleThrottle){
      for(const rc of snapshot.roles){
        metricRoleCost.set({ role: rc.role }, rc.count * (ROLE_LIMITS[rc.role]?.cost || ROLE_LIMITS.default.cost));
        metricRoleThrottle.set({ role: rc.role }, rc.throttles);
      }
    }
  } catch(e){ /* ignore */ }
}
setInterval(persistCost, parseInt(process.env.AUR_AGENT_COST_PERSIST_INTERVAL || '60000',10)).unref();

function octalWheelEncode(str){
  const buf = Buffer.from(str, 'utf8');
  let out = '';
  for(const b of buf){
    const high = (b >> 5) & 0x07;
    const mid = (b >> 2) & 0x07;
    const low = b & 0x03; // 2 bits -> ordinal
    out += high.toString(8) + mid.toString(8) + low.toString(8);
  }
  return out;
}

module.exports = { agentInvoke, installGlobal, safeDigest, checkRate, ROLE_LIMITS, seenDigest, rememberDigest, octalWheelEncode };