#!/usr/bin/env bash
# Bootstrap installer for Aurrelia / Seraphina Miner on fresh Ubuntu from USB.
# Performs: dependency install, user creation, copy runtime, npm install --production, systemd service + optional timer.
set -euo pipefail
SRC_DIR=${1:-/mnt/usb/mining}
DEST_DIR=${2:-/opt/seraphina}
USER_NAME=${SERAPHINA_USER:-seraphina}
NODE_BIN=${NODE_BIN:-/usr/bin/node}
ENABLE_TIMER=${ENABLE_TIMER:-1}
INTERVAL_SEC=${MONITOR_INTERVAL_SEC:-300}
RATE_LIMIT_MS=${AUDIT_MONITOR_MIN_INTERVAL_MS:-240000}
TEXTFILE_DIR=${TEXTFILE_DIR:-/var/lib/node_exporter/textfile}
INSTALL_PYTHON_SOURCE=${INSTALL_PYTHON_SOURCE:-0}
PY_SRC_VERSION=${PY_SRC_VERSION:-3.12.5}

if [ ! -d "$SRC_DIR" ]; then
  echo "[INSTALL] Source directory $SRC_DIR not found" >&2
  exit 2
fi

if ! command -v node >/dev/null 2>&1; then
  echo "[INSTALL] Node.js missing - installing LTS"
  curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
  apt-get install -y nodejs
fi

# Optional Python source build (private offline assurance)
if [ "$INSTALL_PYTHON_SOURCE" = "1" ]; then
  echo "[PYTHON] Building Python $PY_SRC_VERSION from source (optional)";
  TB_NAME=Python-$PY_SRC_VERSION.tgz
  if [ -f "$SRC_DIR/$TB_NAME" ]; then
    cp "$SRC_DIR/$TB_NAME" /tmp/
    bash "$SRC_DIR/build-python-offline.sh" "/tmp/$TB_NAME" || echo "[PYTHON][WARN] build script failed"
  else
    echo "[PYTHON][WARN] Tarball $TB_NAME not found in source dir; skip build"
  fi
fi

if ! id "$USER_NAME" &>/dev/null; then
  useradd -r -s /bin/false "$USER_NAME" || true
fi
mkdir -p "$DEST_DIR"
rsync -a --exclude node_modules --exclude dist "$SRC_DIR"/ "$DEST_DIR"/
chown -R "$USER_NAME":"$USER_NAME" "$DEST_DIR"
cd "$DEST_DIR"

# Production install
npm install --omit=dev || npm ci --only=prod || true

# Build/verify manifest if not present
if [ ! -f artifact-hashes.json ]; then
  echo "[INSTALL] Generating manifest"
  sudo -u "$USER_NAME" $NODE_BIN generate-usb-manifest.js || true
fi

# Systemd service
SERVICE_FILE=/etc/systemd/system/seraphina-miner.service
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Seraphina Aurrelia Pico Mesh Miner
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$DEST_DIR
Environment=REAL_STRICT=1
ExecStart=$NODE_BIN aurrelia-pico-mesh-miner.js
Restart=on-failure
RestartSec=8
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
LimitNOFILE=65535
EOF

# Optional monitor timer
if [ "$ENABLE_TIMER" = "1" ]; then
  MON_SERVICE=/etc/systemd/system/seraphina-monitor.service
  MON_TIMER=/etc/systemd/system/seraphina-monitor.timer
  cat > "$MON_SERVICE" <<EOF
[Unit]
Description=Seraphina Audit Monitor
After=network.target

[Service]
Type=oneshot
User=$USER_NAME
WorkingDirectory=$DEST_DIR
Environment=AUDIT_MONITOR_MIN_INTERVAL_MS=$RATE_LIMIT_MS
ExecStart=$NODE_BIN audit-monitor.js
ExecStartPost=$NODE_BIN export-chain-tips-prom.js
StandardOutput=append:$DEST_DIR/audit-monitor.log
StandardError=append:$DEST_DIR/audit-monitor.err
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
EOF
  cat > "$MON_TIMER" <<EOF
[Unit]
Description=Run Seraphina Audit Monitor every $INTERVAL_SEC seconds

[Timer]
OnBootSec=90
OnUnitActiveSec=$INTERVAL_SEC
AccuracySec=10s
Persistent=true

[Install]
WantedBy=timers.target
EOF
fi

systemctl daemon-reload
systemctl enable --now seraphina-miner.service
if [ "$ENABLE_TIMER" = "1" ]; then
  systemctl enable --now seraphina-monitor.timer
fi

# Textfile collector optional wiring
mkdir -p "$TEXTFILE_DIR" || true
if [ -f chain-tips.prom ]; then
  cp chain-tips.prom "$TEXTFILE_DIR"/ || true
fi

echo "[INSTALL] Complete. Miner service active. Timer=${ENABLE_TIMER} Interval=${INTERVAL_SEC}s"