<#
Build-Baremetal-WSL.ps1
Invokes wsl-build-kernel.sh inside WSL with selectable fast mode and workdir.
#>
param(
  [switch]$Fast,
  [string]$Workdir = "$env:USERPROFILE\octalang-wsl",
  [switch]$NoOctaLang,
  [switch]$NoValidate
)

$repoRel = "$env:USERPROFILE/OneDrive/AppData/Documents/mining"
$fastFlag = if($Fast){ '--fast' } else { '' }
$octaFlag = if($NoOctaLang){ '--no-octalang' } else { '--octalang' }
$valFlag = if($NoValidate){ '--no-validate' } else { '' }

$wslCmd = "cd '$repoRel' && chmod +x wsl-build-kernel.sh && ./wsl-build-kernel.sh $fastFlag --workdir '$Workdir' $octaFlag $valFlag"
Write-Host "[INFO] WSL build invoking: $wslCmd"
wsl bash -c $wslCmd

if($LASTEXITCODE -ne 0){
  Write-Host "[ERROR] WSL build failed (exit $LASTEXITCODE)" -ForegroundColor Red
  exit $LASTEXITCODE
}
Write-Host "[OK] WSL build completed"
