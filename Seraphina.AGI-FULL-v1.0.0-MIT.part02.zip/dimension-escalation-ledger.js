// dimension-escalation-ledger.js
// Hash-chained ledger for dimension escalation / rollback events.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const LEDGER = 'dimension-escalation-ledger.jsonl';

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function appendDimensionEvent(evt){
  let prev = 'GENESIS';
  if(fs.existsSync(LEDGER)){
    try {
      const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ const last = JSON.parse(lines[lines.length-1]); prev = last.chainHash || 'GENESIS'; }
    } catch(_){}
  }
  evt.prevHash = prev;
  evt.chainHash = sha256(evt);
  fs.appendFileSync(LEDGER, JSON.stringify(evt)+'\n');
  return evt.chainHash;
}

module.exports = { appendDimensionEvent };