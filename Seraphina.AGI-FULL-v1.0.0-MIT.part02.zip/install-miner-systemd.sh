#!/usr/bin/env bash
set -euo pipefail

echo "[install-miner-systemd] Installing Seraphina miner & security systemd units"

TARGET_DIR="/opt/seraphina/mining"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo)." >&2
  exit 1
fi

mkdir -p "$TARGET_DIR"
rsync -a --delete "$SRC_DIR/" "$TARGET_DIR/"

echo "[install-miner-systemd] Copying systemd units"
cp "$SRC_DIR/seraphina-miner.service" /etc/systemd/system/ || echo "Miner service not found (OK if intentional)"
if [[ -f "$SRC_DIR/security/seraphina-security.service" ]]; then
  cp "$SRC_DIR/security/seraphina-security.service" /etc/systemd/system/
fi
if [[ -f "$SRC_DIR/security/seraphina-security.timer" ]]; then
  cp "$SRC_DIR/security/seraphina-security.timer" /etc/systemd/system/
fi

echo "[install-miner-systemd] AppArmor profile (if present)"
if [[ -f "$SRC_DIR/seraphina-miner.apparmor" ]]; then
  cp "$SRC_DIR/seraphina-miner.apparmor" /etc/apparmor.d/seraphina-miner
  apparmor_parser -r /etc/apparmor.d/seraphina-miner || echo "AppArmor parser failed; ensure AppArmor installed"
fi
if [[ -f "$SRC_DIR/security/seraphina-security.apparmor" ]]; then
  cp "$SRC_DIR/security/seraphina-security.apparmor" /etc/apparmor.d/seraphina-security
  apparmor_parser -r /etc/apparmor.d/seraphina-security || echo "AppArmor parser failed for security profile"
fi

systemctl daemon-reload
echo "[install-miner-systemd] Enabling miner service"
systemctl enable --now seraphina-miner.service || echo "Miner service enable failed"
if systemctl list-unit-files | grep -q seraphina-security.timer; then
  echo "[install-miner-systemd] Enabling security timer"
  systemctl enable --now seraphina-security.timer || echo "Security timer enable failed"
fi

echo "[install-miner-systemd] Status summary:"
systemctl status seraphina-miner.service --no-pager || true
systemctl status seraphina-security.timer --no-pager || true

echo "[install-miner-systemd] Done."