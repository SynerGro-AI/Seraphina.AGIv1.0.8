// grpc-metrics-server.js
// Minimal gRPC metrics streaming server using aurrelia_metrics.proto definitions.
// NOTE: This is a scaffold; user must install @grpc/grpc-js and @grpc/proto-loader manually.

const fs = require('fs');
const path = require('path');
let grpc, protoLoader;
try {
  grpc = require('@grpc/grpc-js');
  protoLoader = require('@grpc/proto-loader');
} catch(e){
  console.error('[gRPC] Missing dependencies. Install with: npm install @grpc/grpc-js @grpc/proto-loader');
  process.exit(1);
}

const PROTO_PATH = path.join(__dirname, 'proto', 'aurrelia_metrics.proto');
const packageDef = protoLoader.loadSync(PROTO_PATH, { keepCase:true, longs:String, enums:String, defaults:true });
const proto = grpc.loadPackageDefinition(packageDef).aurrelia;

const METRICS_FILE = process.env.GRPC_METRICS_FILE || 'aurrelia-metrics-merged.jsonl';
const PORT = process.env.GRPC_METRICS_PORT || '0.0.0.0:50551';
const AUTH_TOKEN = process.env.GRPC_AUTH_TOKEN || '';

function tailFile(lastSize){
  try {
    const st = fs.statSync(METRICS_FILE); if (st.size === lastSize) return { lines:[], size:lastSize };
    const data = fs.readFileSync(METRICS_FILE,'utf8');
    const slice = data.slice(lastSize);
    const lines = slice.split(/\n/).filter(Boolean);
    return { lines, size: data.length };
  } catch(_) { return { lines:[], size:lastSize }; }
}

function streamMetrics(call){
  if (AUTH_TOKEN && call.metadata.get('authorization')[0] !== `Bearer ${AUTH_TOKEN}`){
    call.destroy(new Error('unauthorized'));
    return;
  }
  let lastSize = 0;
  const interval = setInterval(()=>{
    const { lines, size } = tailFile(lastSize);
    lastSize = size;
    for (const l of lines){
      try { const o = JSON.parse(l); call.write(mapRecord(o)); } catch(_){ }
    }
  }, parseInt(process.env.GRPC_POLL_MS || '3000',10));
  call.on('cancelled', ()=> clearInterval(interval));
  call.on('error', ()=> clearInterval(interval));
  call.on('close', ()=> clearInterval(interval));
}

function mapRecord(o){
  return {
    t: o.t||Date.now(),
    hashes: o.hashes||0,
    shares: o.shares||0,
    attempted: o.attempted||0,
    algo: o.algo||'',
    coin: o.coin||'',
    seed: o.seed||0,
    burrowDepth: o.burrowDepth||0,
    pruneThreshold: o.pruneThreshold||0,
    configHash: o.configHash||'',
    schemaVersion: o.schemaVersion||'metrics-v2',
    schemaHmac: o.schemaHmac||'',
    difficulty: o.difficulty? { p50:o.difficulty.p50||0, p90:o.difficulty.p90||0, p95:o.difficulty.p95||0, p99:o.difficulty.p99||0, window: o.difficulty.window||0 }: undefined,
    ths: parseFloat(o.ths)||0,
    acceptRate: (o.hashEff && o.attempted)? (o.hashEff):0,
    assignedFreq: o.assignedFreq||0,
    wasm: (o.wasm && o.wasm.fused)? { latency_count: o.wasm.fused.latencyCount||0, latency_total_ns: o.wasm.fused.latencyTotalNs||0, latency_cv: o.wasm.fused.latencyCv||0, current_batch_size: o.wasm.fused.currentBatchSize||0, speedup_est: o.wasm.fused.speedupEst||0, fused_available: o.wasm.fusedAvailable?true:false }: undefined
  };
}

function main(){
  const server = new grpc.Server();
  server.addService(proto.MetricsStream.service, {
    StreamMetrics: streamMetrics
  });
  server.bindAsync(PORT, grpc.ServerCredentials.createInsecure(), (err)=>{
    if (err){ console.error('[gRPC] bind error', err.message); process.exit(1); }
    console.log('[gRPC] Metrics server listening on', PORT, 'file=', METRICS_FILE);
    server.start();
  });
}

main();
