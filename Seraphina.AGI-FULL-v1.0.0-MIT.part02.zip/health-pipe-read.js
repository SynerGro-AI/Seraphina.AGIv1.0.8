#!/usr/bin/env node
'use strict';
// health-pipe-read.js: Reads health snapshot lines from named pipe.
// On Windows creates the pipe server and waits for client writes (or vice versa depending on write strategy).
const fs = require('fs');
const net = require('net');

const PIPE_PATH = process.platform==='win32' ? '\\?\pipe\seraphina-health' : '/tmp/seraphina-health.sock';

function startPipeServer(){
  if(process.platform==='win32'){
    const server = net.createServer(conn => {
      conn.on('data', buf => { process.stdout.write('[PipeData] '+buf.toString()); });
      conn.on('error', e=> console.error('[PipeConnError]', e.message));
    });
    server.on('error', e=> console.error('[PipeServerError]', e.message));
    server.listen(PIPE_PATH, ()=> console.log('[PipeServer] listening', PIPE_PATH));
  } else {
    try { if(fs.existsSync(PIPE_PATH)) fs.unlinkSync(PIPE_PATH); } catch(_e){}
    const server = net.createServer(conn => {
      conn.on('data', buf => { process.stdout.write('[PipeData] '+buf.toString()); });
    });
    server.listen(PIPE_PATH, ()=> console.log('[PipeServer] listening', PIPE_PATH));
  }
}

if(require.main===module){ startPipeServer(); }
