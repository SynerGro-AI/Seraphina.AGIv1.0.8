// intrinsic-motivation-engine.js
// Deterministic intrinsic motivation metrics derived from knowledge shards.
// Provides curiosity, novelty, empowerment scores without randomness.
// Curiosity: average unseen fact density vs total facts.
// Novelty: hash-distance diversity contribution of latest shard vs rolling window.
// Empowerment: branching potential estimated from conceptual vector variance.
// Integration (new): cross-domain linkage density = (# shared conceptual pattern hits) / (domains^2) using simple fact prefix/domain mapping.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const SHARDS_PATH = process.env.KNOWLEDGE_SHARDS_PATH || 'knowledge-shards.json';
const WINDOW = 12; // rolling window size for novelty/empowerment context

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x : JSON.stringify(x)).digest('hex'); }

function loadShards(){
  if(!fs.existsSync(SHARDS_PATH)) return [];
  try { return JSON.parse(fs.readFileSync(SHARDS_PATH,'utf8')); } catch(e){ return []; }
}

function computeMetrics(state){
  // state: { seenFacts:Set<string>, recentShardHashes:Array<string> }
  const shards = loadShards();
  if(!shards.length) return { curiosity:0, novelty:0, empowerment:0, integration:0, shardCount:0 };
  let newFacts=0, totalFacts=0;
  const recentHashes = state.recentShardHashes || [];
  const seenFacts = state.seenFacts || new Set();
  const conceptVectors=[];
  const domainFacts = new Map(); // domain -> Set of fact roots
  for(const shard of shards){
    const facts = shard.coreFacts||[];
    for(const f of facts){ totalFacts++; if(!seenFacts.has(f)) newFacts++; }
    conceptVectors.push(shard.conceptVector || []);
    // Build domain fact roots (split on first underscore)
    const roots = new Set();
    for(const f of facts){ const root = f.split('_')[0]; roots.add(root); }
    if(!domainFacts.has(shard.domain)) domainFacts.set(shard.domain, new Set());
    const setRef = domainFacts.get(shard.domain);
    for(const r of roots) setRef.add(r);
  }
  // Curiosity: fraction of facts not yet seen
  const curiosity = totalFacts? newFacts/totalFacts : 0;
  // Novelty: hash diversity of shard ids vs rolling window
  const joinedIds = shards.map(s=>s.id).join('|');
  const currentHash = sha256(joinedIds).slice(0,16);
  const windowSet = new Set(recentHashes);
  const novelty = windowSet.has(currentHash)? 0 : 1; // binary novelty
  // Empowerment: mean variance across concept vector dimensions (normalized)
  let empowerment = 0;
  if(conceptVectors.length){
    const dims = Math.max(...conceptVectors.map(v=>v.length));
    const variances=[];
    for(let d=0; d<dims; d++){
      const vals = conceptVectors.map(v=> typeof v[d]==='number'? v[d]:0);
      const mean = vals.reduce((a,b)=>a+b,0)/vals.length;
      const varc = vals.reduce((a,b)=>a+Math.pow(b-mean,2),0)/vals.length;
      variances.push(varc);
    }
    const avgVar = variances.reduce((a,b)=>a+b,0)/variances.length;
    empowerment = avgVar; // raw variance already deterministic
  }
  // Integration: count overlaps between domain fact root sets
  let integration = 0;
  const domains = Array.from(domainFacts.keys());
  if(domains.length > 1){
    let pairs=0, overlapSum=0;
    for(let i=0;i<domains.length;i++){
      for(let j=i+1;j<domains.length;j++){
        pairs++;
        const a = domainFacts.get(domains[i]);
        const b = domainFacts.get(domains[j]);
        let overlap=0; for(const r of a){ if(b.has(r)) overlap++; }
        const denom = Math.max(1, Math.min(a.size,b.size));
        overlapSum += overlap/denom;
      }
    }
    integration = pairs? overlapSum/pairs : 0;
  }

  // Normalized integration scaling (integrationNorm): divide by (domains.length - 1) to smooth growth
  const integrationNorm = domains.length > 1 ? integration / (domains.length - 1) : 0;

  // Update state deterministically
  for(const shard of shards){ for(const f of shard.coreFacts||[]) seenFacts.add(f); }
  const updatedRecent = recentHashes.concat([currentHash]).slice(-WINDOW);
  return { curiosity, novelty, empowerment, integration, integrationNorm, shardCount: shards.length, state: { seenFacts, recentShardHashes: updatedRecent }, diversityHash: currentHash };
}

module.exports = { computeMetrics };
