"use strict";
// hypercube-48d.js – Deterministic 48D vector lattice generator with phi scaling & rank proxy
// Exports: generateHypercube(job, opts) -> { vectors, rankProxy, signVar }

const crypto = require('crypto');
const PHI = (1+Math.sqrt(5))/2;

function hashChain(seedHex, count){
  let cur = Buffer.from(seedHex,'hex');
  const out=[];
  for (let i=0;i<count;i++){
    cur = crypto.createHash('sha256').update(cur).digest();
    out.push(cur);
  }
  return out;
}

function vectorFromHash(buf, dim){
  // Map bytes to +/- scaled floats; use sign from high bit, magnitude from nibble ratio
  const v = new Array(dim); let j=0;
  for (let i=0;i<dim;i++){
    if (j >= buf.length) j = 0;
    const b = buf[j++];
    const sign = (b & 0x80) ? 1 : -1;
    const mag = ((b & 0x7F) / 127); // 0..1
    v[i] = sign * mag;
  }
  return v;
}

function applyPhiScaling(v, phiExp){
  if (!phiExp) return v;
  const scale = Math.pow(PHI, phiExp);
  return v.map(x=> x/scale);
}

function rankProxy(vectors){
  // Simple proxy: average absolute Pearson correlation complement among first 24 dims
  if (!vectors.length) return 0;
  const n = Math.min(64, vectors.length);
  const d = Math.min(24, vectors[0].length);
  const means = new Array(d).fill(0);
  for (let k=0;k<n;k++) for (let i=0;i<d;i++) means[i]+=vectors[k][i];
  for (let i=0;i<d;i++) means[i]/=n;
  const vars = new Array(d).fill(0);
  for (let k=0;k<n;k++) for (let i=0;i<d;i++){ const diff=vectors[k][i]-means[i]; vars[i]+=diff*diff; }
  for (let i=0;i<d;i++) vars[i]=Math.sqrt(vars[i]/(n||1))+1e-9;
  let corrSum=0; let pairs=0;
  for (let a=0;a<d;a++) for (let b=a+1;b<d;b++){
    let cov=0; for (let k=0;k<n;k++){ cov += (vectors[k][a]-means[a])*(vectors[k][b]-means[b]); }
    const corr = cov / ((n||1)*vars[a]*vars[b]);
    corrSum += Math.abs(corr); pairs++;
  }
  const avgCorr = pairs? corrSum/pairs : 0;
  return 1 - avgCorr; // closer to 1 => lower inter-dim correlation
}

function signVariance(vectors){
  if (!vectors.length) return 0;
  let pos=0, neg=0;
  for (const v of vectors){ for (const x of v){ if (x>=0) pos++; else neg++; } }
  const total = pos+neg || 1; const p = pos/total; return 1 - (p*p + (1-p)*(1-p));
}

function generateHypercube(job, opts={}){
  const dim = 48;
  const count = opts.count || 1024;
  const phiExpBase = opts.phiExpBase || (job && job.jobId ? (parseInt(job.jobId.slice(0,2),16)%5)/50 : 0.02);
  const jobSeed = crypto.createHash('sha256').update((job?.jobId||'') + (job?.prevhash||'') + (opts.extranonce1||'')).digest('hex');
  const chain = hashChain(jobSeed, count);
  const vectors = new Array(count);
  for (let i=0;i<count;i++){
    const rawV = vectorFromHash(chain[i], dim);
    const phiAdj = (i%dim) < 16 ? phiExpBase : phiExpBase*0.5; // damp after 32
    vectors[i] = applyPhiScaling(rawV, phiAdj);
  }
  const rp = rankProxy(vectors.slice(0,128));
  const sv = signVariance(vectors.slice(0,128));
  return { vectors, rankProxy: rp, signVar: sv };
}

module.exports = { generateHypercube };
