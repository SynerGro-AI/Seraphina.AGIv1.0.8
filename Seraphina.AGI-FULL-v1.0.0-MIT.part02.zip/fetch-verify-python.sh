#!/usr/bin/env bash
# Securely fetch and verify Python source tarball + signature & GPG key.
# Usage: bash fetch-verify-python.sh 3.12.5
set -euo pipefail
VER=${1:-3.12.5}
BASE=https://www.python.org/ftp/python/$VER
TARBALL=Python-$VER.tgz
SIG=$TARBALL.asc
KEYSERVER=${KEYSERVER:-keyserver.ubuntu.com}

curl -fSLO $BASE/$TARBALL
curl -fSLO $BASE/$SIG || curl -fSLO $BASE/$TARBALL.asc

# Import Python release manager keys (example key IDs; update as needed)
KEYS=(E3FF2839C048B25C084DEBE9B26995E310250568)
for k in "${KEYS[@]}"; do
  gpg --keyserver "$KEYSERVER" --recv-keys "$k" || echo "[WARN] GPG key fetch failed for $k"
done

echo "[INFO] Verifying signature";
if gpg --verify $SIG $TARBALL 2>&1 | grep -q 'Good signature'; then
  echo "[OK] Python source signature verified for $TARBALL"
else
  echo "[FAIL] Signature verification failed" >&2; exit 2
fi

sha256sum $TARBALL | tee python-tarball.sha256
