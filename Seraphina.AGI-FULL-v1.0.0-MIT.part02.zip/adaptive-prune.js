"use strict";
// adaptive-prune.js – EWMA / window acceptance driven prune threshold adjuster + share feedback + persistence
// Export: createAdaptivePrune(cfg)
// cfg: { base,min,max,step,targetAccept,window,adjustMs,persistFile,persistMs }
// New methods returned: recordShare(accepted, stale)
// Persistence stores JSON: { threshold, recent:[{norm,ok}], shareRecent:['A'|'S'|'R'] }

const fs = require('fs');

function loadState(path){
  try { return JSON.parse(fs.readFileSync(path,'utf8')); } catch(_){ return null; }
}
function saveState(path, obj){
  try { fs.writeFileSync(path, JSON.stringify(obj)); } catch(_){ }
}

function createAdaptivePrune(cfg){
  const persistFile = cfg.persistFile || process.env.AUR_PRUNE_STATE_FILE || 'adaptive-prune-state.json';
  const loaded = loadState(persistFile);
  const baseThr = cfg.base;
  const state = { attempts:0, accepted:0, recent:[], lastAdjust:0, threshold: baseThr, shareRecent:[], min: cfg.min, max: cfg.max };
  if (loaded){
    if (typeof loaded.threshold === 'number') state.threshold = Math.min(cfg.max, Math.max(cfg.min, loaded.threshold));
    if (Array.isArray(loaded.recent)) state.recent = loaded.recent.slice(-cfg.window);
    if (Array.isArray(loaded.shareRecent)) state.shareRecent = loaded.shareRecent.slice(-Math.max(32, Math.floor(cfg.window/8)));
  }
  function record(norm, ok){
    state.attempts++; if (ok) state.accepted++; if (norm!=null){ state.recent.push({ norm, ok }); if (state.recent.length>cfg.window) state.recent.shift(); }
  }
  function recordShare(accepted, stale){
    state.shareRecent.push(accepted? 'A' : (stale? 'S':'R'));
    const maxShareWin = Math.max(32, Math.floor(cfg.window/8));
    if (state.shareRecent.length > maxShareWin) state.shareRecent.shift();
    maybeShareAdjust();
  }
  function maybeAdjust(now=Date.now()){
    if (now - state.lastAdjust < cfg.adjustMs) return state.threshold;
    const win = state.recent.slice(-cfg.window);
    const acc = win.filter(r=> r.ok).length;
    const ratio = win.length? acc / win.length : 0;
    if (ratio < cfg.targetAccept*0.8 && state.threshold < cfg.max){ state.threshold = Math.min(cfg.max, state.threshold + cfg.step); }
    else if (ratio > cfg.targetAccept*1.2 && state.threshold > cfg.min){ state.threshold = Math.max(cfg.min, state.threshold - cfg.step); }
    state.lastAdjust = now; return state.threshold;
  }
  function maybeShareAdjust(){
    const arr = state.shareRecent; if (!arr.length) return;
    const acc = arr.filter(x=>x==='A').length / arr.length;
    // Use coarser band so share acceptance influences slower than norm loop
    if (acc < cfg.targetAccept*0.5 && state.threshold < cfg.max){ state.threshold = Math.min(cfg.max, state.threshold + cfg.step*0.5); }
    else if (acc > cfg.targetAccept*1.6 && state.threshold > cfg.min){ state.threshold = Math.max(cfg.min, state.threshold - cfg.step*0.5); }
  }
  const persistMs = cfg.persistMs || parseInt(process.env.AUR_PRUNE_PERSIST_MS || '15000',10);
  if (persistMs > 0){
    setInterval(()=> saveState(persistFile, { threshold: state.threshold, recent: state.recent.slice(-cfg.window), shareRecent: state.shareRecent }), persistMs).unref();
    process.once('exit', ()=> saveState(persistFile, { threshold: state.threshold, recent: state.recent.slice(-cfg.window), shareRecent: state.shareRecent }));
  }
  return { record, recordShare, maybeAdjust, state };
}

module.exports = { createAdaptivePrune };
