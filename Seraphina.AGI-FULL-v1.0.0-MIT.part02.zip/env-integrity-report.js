#!/usr/bin/env node
/**
 * Environment Integrity Report
 * ----------------------------
 * Produces a structured JSON report including:
 *  - All environment keys currently set that are considered critical or match policy prefixes
 *  - SHA256 for each value (optionally redacted value presence for secrets)
 *  - HMAC(VAULT_PASS, canonicalKeyValueString) if VAULT_PASS set; else plain SHA256
 *  - Optional cross-reference with env-tracer access log (latest snapshot) if available
 *
 * Config:
 *   ENV_INTEGRITY_INCLUDE_SECRETS=1 -> include raw values (otherwise only length + hash for keys matching /PASS|KEY|SECRET|API/i)
 *   ENV_TRACER_LOG=path -> override tracer log path (default ./env-access-log.jsonl)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const INCLUDE_SECRETS = process.env.ENV_INTEGRITY_INCLUDE_SECRETS === '1';
const TRACER_LOG = process.env.ENV_TRACER_LOG || path.join(process.cwd(),'env-access-log.jsonl');

// Mirror logic from environment audit (known critical) plus dynamic prefixes
const STATIC_KEYS = [
  'REAL_STRICT','DISABLE_DOTENV','BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','KRAKEN_BTC_ADDRESS',
  'RVN_LOCAL_ADDRESS','RVN_MINING_ADDRESS','RVN_PAYOUT_ADDRESS','RPC_BTC_URL','RPC_BTC_USER','RPC_BTC_PASS',
  'RPC_RVN_URL','RPC_RVN_USER','RPC_RVN_PASS','VAULT_PASS','SIMPLESWAP_API_KEY','SIMPLESWAP_MODE',
  'BTC_FEE_TARGET_CONF','BTC_FEE_MIN_SATS_VB','RVN_SPEND_THRESHOLD','RVN_SWAP_THRESHOLD','RVN_SPEND_POLL_MS',
  'BTC_CONFIRM_POLL_MS','ANCHOR_INTERVAL_MS','KAWPOW_NATIVE_MODULE','EXTERNAL_KAWPOW_MINER','EXTERNAL_KAWPOW_ARGS',
  'TRIAD_CONFIG_HASH','TRIAD_GOV_MODE','SHARE_API_KEY','SHARE_API_SECRET','MINING_WS_PORT_EXT',
  'NEURAL_TUNER_BASE_PATH','INTEGRITY_DIGEST_INTERVAL_MS'
];
const PREFIXES = ['RVN_','BTC_','LTC_','FREN_'];

function isSecretKey(k){ return /(PASS|SECRET|KEY|API|TOKEN)/i.test(k); }

const all = Object.keys(process.env);
const considered = new Set();
for (const k of STATIC_KEYS) considered.add(k);
for (const k of all){ if (PREFIXES.some(p=>k.startsWith(p))) considered.add(k); }

const entries = Array.from(considered).filter(k=>process.env[k] !== undefined).sort();
const detail = entries.map(k=>{
  const v = process.env[k];
  const hash = crypto.createHash('sha256').update(v).digest('hex');
  if (!INCLUDE_SECRETS && isSecretKey(k)) {
    return { key:k, sha256:hash, length:v.length, redacted:true };
  }
  return { key:k, value:v, sha256:hash, length:v.length };
});

const canonical = detail.map(d=>`${d.key}=${INCLUDE_SECRETS||!d.redacted?d.value:'<redacted>'}`).join('\n');

let digestAlgo = 'sha256';
let integrityDigest;
if (process.env.VAULT_PASS){
  integrityDigest = crypto.createHmac('sha256', process.env.VAULT_PASS).update(canonical).digest('hex');
  digestAlgo = 'hmac-sha256(vault_pass)';
} else {
  integrityDigest = crypto.createHash('sha256').update(canonical).digest('hex');
}

// Attempt to read last tracer snapshot
let tracerRef = null;
try {
  if (fs.existsSync(TRACER_LOG)) {
    const lines = fs.readFileSync(TRACER_LOG,'utf8').trim().split(/\n/).filter(Boolean);
    if (lines.length){ tracerRef = JSON.parse(lines[lines.length-1]); }
  }
} catch(e){ tracerRef = { error:e.message }; }

const report = {
  ts: Date.now(),
  count: detail.length,
  digestAlgo,
  integrityDigest,
  env: detail,
  tracer: tracerRef ? { uniqueAccesses: tracerRef.unique, lastSnapshotTs: tracerRef.ts, hash: tracerRef.accesses ? crypto.createHash('sha256').update(JSON.stringify(tracerRef.accesses.map(a=>a.key).sort())).digest('hex') : null } : null
};

console.log(JSON.stringify(report,null,2));
