# Governance Engine (Deterministic Parameter Proposals)

## Purpose
Provide a safe, deterministic mechanism to propose and approve bounded parameter changes (bias multipliers, hysteresis cycles, trading spread thresholds) without ad-hoc edits.

## Files
- `governance-proposals.jsonl`: Append-only proposals.
- `governance-decisions.jsonl`: Hash-chained decisions (approved / rejected + applied params).

## Proposal Schema
```json
{
  "id": "prop-2025-10-19-01",
  "t": 1758200000000,
  "params": { "ECON_FREN_BIAS": 1.12, "TRADING_MIN_SPREAD_FOR_SWAP": 0.06 },
  "participants": ["wallet1", "wallet2", "wallet3"]
}
```

## Deterministic Quorum Simulation
- For each participant id (string), compute `sha256(id)` and take first 8 hex chars as integer, mod 100.
- If shard < `GOV_APPROVAL_PCT` (default 60) counts as approval.
- Approved if `(approvals/participants)*100 >= GOV_APPROVAL_PCT`.

## Bounds Enforcement
Parameters only applied if within `PARAM_BOUNDS`. Values outside range are clamped to nearest bound.

## Hash Chain
Decision entry includes previous decision hash to form chain:
```json
{
  "t": 1758200050000,
  "id": "prop-2025-10-19-01",
  "status": "approved",
  "approvalRate": 0.6667,
  "applied": { "ECON_FREN_BIAS": 1.12 },
  "prevHash": "GENESIS",
  "chainHash": "..."
}
```

## Environment Flags
```
GOVERNANCE_ENGINE=1
GOV_INTERVAL_MS=300000
GOV_APPROVAL_PCT=60
GOV_PROPOSALS_PATH=governance-proposals.jsonl
GOV_DECISIONS_PATH=governance-decisions.jsonl
GOVERNANCE_LOG=1
```

## Adding a Proposal
Append a line (JSON) to `governance-proposals.jsonl`. Engine periodically evaluates latest proposal only. To batch future proposals, schedule them sequentially with unique ids.

## Safety Notes
- No direct code execution; only whitelisted parameters are applied.
- Applied params written into `process.env`; miner may need restart for certain static reads.
- Extend bounds cautiously; maintain deterministic clamp logic.

---
End of GOVERNANCE-ENGINE.md.
