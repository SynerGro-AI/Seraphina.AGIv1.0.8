// ltc-revenue-estimator.js
// Quick estimator for LTC + merged F2Pool auxiliary rewards based on daily ratio per GH/s you provided.
// Usage: node ltc-revenue-estimator.js <hashrateGHs> [ltc_price_usd] [doge_price_usd]
// Hashrate is in GH/s (e.g. 5000 for 5 TH/s).

/* Reference baseline (per 1 GH/s per day):
   LTC:   0.00124939
   DOGE:  4.67228748
   BELLS: 0.00103496
   LKY:   0.00142422
   PEP:   4.38699621
   JKC:   0.00519456
   DINGO: 5.02631752
   SHIC:  29.12824417
   CRC:   0.00152682
*/

const baseline = {
  LTC: 0.00124939,
  DOGE: 4.67228748,
  BELLS: 0.00103496,
  LKY: 0.00142422,
  PEP: 4.38699621,
  JKC: 0.00519456,
  DINGO: 5.02631752,
  SHIC: 29.12824417,
  CRC: 0.00152682,
};

const gh = parseFloat(process.argv[2] || '1');
if (isNaN(gh) || gh <= 0) {
  console.error('Provide hashrate in GH/s, e.g. node ltc-revenue-estimator.js 5000');
  process.exit(1);
}

// Optional simple fiat assumptions
const ltcUsd = parseFloat(process.argv[3] || process.env.LTC_PRICE_USD || '70');
const dogeUsd = parseFloat(process.argv[4] || process.env.DOGE_PRICE_USD || '0.12');

const daily = Object.fromEntries(Object.entries(baseline).map(([k,v])=>[k, v * gh]));

// Crude USD approximation (only LTC & DOGE counted unless you supply others via env e.g. PEP_PRICE_USD)
function price(sym){
  if (sym==='LTC') return ltcUsd;
  if (sym==='DOGE') return dogeUsd;
  const envKey = sym + '_PRICE_USD';
  return parseFloat(process.env[envKey] || '0');
}

const dailyUsd = Object.entries(daily).reduce((sum,[k,v])=> sum + v * price(k), 0);
const weeklyUsd = dailyUsd * 7;
const monthlyUsd = dailyUsd * 30;

console.log(JSON.stringify({ hashrate_GHs: gh, baselinePerGHs: baseline, daily, fiatAssumptions: { LTC: ltcUsd, DOGE: dogeUsd }, dailyUsd, weeklyUsd, monthlyUsd }, null, 2));
