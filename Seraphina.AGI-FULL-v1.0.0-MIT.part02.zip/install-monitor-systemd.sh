#!/usr/bin/env bash
# Install systemd service + timer for audit-monitor and chain tips Prom exporter.
# Usage: sudo bash install-monitor-systemd.sh /opt/seraphina
set -euo pipefail
APP_DIR=${1:-/opt/seraphina}
NODE_BIN=${NODE_BIN:-/usr/bin/node}
USER_NAME=${SERAPHINA_USER:-seraphina}
INTERVAL_SEC=${MONITOR_INTERVAL_SEC:-300}
PROM_EXPORT=${PROM_EXPORT:-1}
TEXTFILE_DIR=${TEXTFILE_DIR:-/var/lib/node_exporter/textfile}
RATE_LIMIT_MS=${AUDIT_MONITOR_MIN_INTERVAL_MS:-240000}

mkdir -p "$APP_DIR"
if ! id "$USER_NAME" &>/dev/null; then
  useradd -r -s /bin/false "$USER_NAME" || true
fi

SERVICE_FILE=/etc/systemd/system/seraphina-monitor.service
TIMER_FILE=/etc/systemd/system/seraphina-monitor.timer

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Seraphina Audit Monitor
After=network.target

[Service]
Type=oneshot
User=$USER_NAME
WorkingDirectory=$APP_DIR
Environment=AUDIT_MONITOR_MIN_INTERVAL_MS=$RATE_LIMIT_MS
ExecStart=$NODE_BIN audit-monitor.js
ExecStartPost=$NODE_BIN export-chain-tips-prom.js
StandardOutput=append:$APP_DIR/audit-monitor.log
StandardError=append:$APP_DIR/audit-monitor.err
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
EOF

cat > "$TIMER_FILE" <<EOF
[Unit]
Description=Run Seraphina Audit Monitor every $INTERVAL_SEC seconds

[Timer]
OnBootSec=120
OnUnitActiveSec=$INTERVAL_SEC
AccuracySec=15s
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now seraphina-monitor.timer

echo "[INSTALL] systemd timer installed. Textfile export: $PROM_EXPORT";
if [ "$PROM_EXPORT" = "1" ]; then
  mkdir -p "$TEXTFILE_DIR"
  # Move prom file path if needed
  echo "Configure node_exporter with --collector.textfile.directory=$TEXTFILE_DIR"
fi
