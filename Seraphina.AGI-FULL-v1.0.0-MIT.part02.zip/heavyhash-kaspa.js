"use strict";
// heavyhash-kaspa.js – deterministic kHeavyHash (simplified reference) for Kaspa support
// Provides: kheavyHash(headerHex) returning final hex digest
// kHeavyHash: Keccak-256(header) -> matrix (64x64 uint16) * vector (512 bytes) -> Blake2b
// We approximate with: derive 64x64 matrix from Keccak digest stream; rank sentinel; multiply by 64x64 (uint32) vector derived from header mid-hash; feed Blake2b.

const crypto = require('crypto');

function keccak256Hex(hex){ return crypto.createHash('keccak256').update(Buffer.from(hex,'hex')).digest('hex'); }
function blake2bHex(buf){ return crypto.createHash('blake2b512').update(buf).digest('hex'); }

function deriveMatrix(seedHex){
  // Expand seed via SHA256 chaining deterministically
  let cur = seedHex;
  const mat = new Array(64); for (let r=0;r<64;r++){ mat[r] = new Uint16Array(64); }
  for (let r=0;r<64;r++){
    for (let c=0;c<64;c++){
      const h = crypto.createHash('sha256').update(cur + r.toString(16)+c.toString(16)).digest();
      mat[r][c] = (h[0] << 8) | h[1];
      cur = h.toString('hex');
    }
  }
  return mat;
}

function matrixRankApprox(mat){
  // Very cheap rank proxy: count non-zero rows after xor-folding
  let rows=0; for (let r=0;r<mat.length;r++){ let acc=0; const row=mat[r]; for (let c=0;c<row.length;c+=4){ acc ^= row[c]; } if (acc!==0) rows++; }
  return rows; // 0..64
}

function deriveVector(headerHex){
  // Use chained sha256 blocks to produce 64*64*2 bytes but we only need 64 values
  const out = new Uint32Array(64);
  let cur = crypto.createHash('sha256').update(Buffer.from(headerHex,'hex')).digest();
  for (let i=0;i<64;i++){
    cur = crypto.createHash('sha256').update(cur).digest();
    out[i] = cur.readUInt32BE(0);
  }
  return out;
}

function mulMatVec(mat, vec){
  const acc = new Uint32Array(64);
  for (let r=0;r<64;r++){
    let sum=0; const row=mat[r];
    for (let c=0;c<64;c++) sum = (sum + row[c]* (vec[c]&0xffff)) & 0xffffffff;
    acc[r] = sum>>>0;
  }
  return acc;
}

function kheavyHash(headerHex, height=0){
  // base seed from keccak(header + heightLE)
  const hBuf = Buffer.from(headerHex,'hex');
  const heightBuf = Buffer.alloc(4); heightBuf.writeUInt32LE(height>>>0,0);
  const seed = crypto.createHash('keccak256').update(Buffer.concat([hBuf, heightBuf])).digest('hex');
  let mat = deriveMatrix(seed);
  let rank = matrixRankApprox(mat);
  if (rank < 63){
    // sentinel reseed
    const reseed = crypto.createHash('sha256').update(seed + height.toString(16)).digest('hex');
    mat = deriveMatrix(reseed); rank = matrixRankApprox(mat);
  }
  const vec = deriveVector(headerHex);
  const prod = mulMatVec(mat, vec);
  const prodBuf = Buffer.alloc(64*4); for (let i=0;i<64;i++) prodBuf.writeUInt32BE(prod[i]>>>0, i*4);
  const final = blake2bHex(prodBuf).slice(0,64); // 256-bit final
  return final;
}

module.exports = { kheavyHash };
