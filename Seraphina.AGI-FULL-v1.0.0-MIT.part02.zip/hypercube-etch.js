#!/usr/bin/env node
/**
 * hypercube-etch.js
 * Deterministic scaffold generator for a golden-ratio scaled hypercube subset.
 * Produces a reproducible sample of +/-1 (optionally phi‑scaled) vectors in D dimensions
 * without exploding to 2^D vertices. Intended as a geometry seed file for Aurrelia miner.
 *
 * Usage:
 *   node hypercube-etch.js --dim=48 --count=2048 --phi-scale=1 --seed=jobB6ya6ZuzW --out=hypercube-d48.json
 * Flags:
 *   --dim (AUR_DIM)          Dimension (default 48; supports 36,42,48,64)
 *   --count                  Sample vertex count (default 1024)
 *   --seed                   Deterministic seed string (default 'aurrelia')
 *   --phi-scale              If 1, scale coordinate i by phi^((i mod period)/period)
 *   --phi-period             Period for exponent cycling (default 8)
 *   --out                    Output JSON file (default auto hypercube-d{dim}.json)
 *   --project2               If 1, include 2D projection array for first two dims
 *   --stats                  If 1, print variance/norm stats summary
 *
 * Output schema: aurrelia.hypercube.v1
 */
const crypto = require('crypto');

function parseArgs(){
  const a = process.argv.slice(2); const flags={};
  for (const tok of a){ if(!tok.startsWith('--')) continue; const eq=tok.indexOf('=');
    if(eq>0){ flags[tok.slice(2,eq)] = tok.slice(eq+1);} else { flags[tok.slice(2)]='1'; }
  }
  return flags;
}
const flags = parseArgs();
const phi = (1+Math.sqrt(5))/2;
const dim = parseInt(flags.dim || process.env.AUR_DIM || '48',10);
const count = parseInt(flags.count || '1024',10);
const seed = flags.seed || 'aurrelia';
const phiScale = (flags['phi-scale'] || '1') === '1';
const phiPeriod = parseInt(flags['phi-period'] || '8',10);
const outFile = flags.out || `hypercube-d${dim}.json`;
const includeProj2 = (flags.project2 || '0') === '1';
const doStats = (flags.stats || '0') === '1';

function hashBytes(str){ return crypto.createHash('sha256').update(str).digest(); }

// Deterministic pseudo-random bit / sign generator from index + seed
function signVector(idx){
  const h = hashBytes(seed+':'+idx);
  const signs = new Array(dim);
  for (let i=0;i<dim;i++){
    const byte = h[i%h.length];
    const bit = (byte >> (i%8)) & 1;
    signs[i] = bit ? 1 : -1;
  }
  return signs;
}

function scaleVector(v){
  if(!phiScale) return v;
  return v.map((x,i)=> x * Math.pow(phi, (i % phiPeriod)/phiPeriod - 0.5));
}

const vectors = [];
for (let i=0;i<count;i++){
  const raw = signVector(i);
  const scaled = scaleVector(raw);
  vectors.push(scaled);
}

function stats(vs){
  let sum=0, sum2=0; let norms=[];
  for (const v of vs){
    for (const x of v){ sum+=x; sum2+=x*x; }
    const n = Math.sqrt(v.reduce((a,b)=>a+b*b,0)); norms.push(n);
  }
  const N=vs.length*dim; const mean=sum/N; const var_=(sum2/N)-mean*mean; const stdev=Math.sqrt(var_);
  norms.sort((a,b)=>a-b);
  const p = q=> norms[Math.floor(q*(norms.length-1))];
  return { mean, stdev, norm:{ p50:p(0.5), p90:p(0.9), p99:p(0.99) } };
}
let summary=null; if (doStats) summary=stats(vectors);

const proj2 = includeProj2 ? vectors.map(v=> [v[0], v[1]]) : undefined;

const artifact = {
  schema: 'aurrelia.hypercube.v1',
  dim, count, seed, phiScale, phiPeriod,
  phi: Number(phi.toFixed(12)),
  vectors,
  proj2,
  stats: summary || undefined
};

require('fs').writeFileSync(outFile, JSON.stringify(artifact,null,2));
console.log(`[Hypercube] Wrote ${count} vectors @ dim=${dim} -> ${outFile}` + (summary? ` stdev=${summary.stdev.toFixed(4)}`:''));
