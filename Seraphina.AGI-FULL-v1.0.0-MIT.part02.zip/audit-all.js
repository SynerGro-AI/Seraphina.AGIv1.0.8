#!/usr/bin/env node
// Unified audit orchestrator: runs integrity audit, environment audit snapshot, manifest + verification, outputs consolidated report JSON.
const { execSync } = require('child_process');
const fs = require('fs');

function run(cmd){
  try { return execSync(cmd,{stdio:'pipe'}).toString(); } catch(e){ return e.stdout?.toString()||e.message; }
}

// 1. Integrity audit
const stamp = new Date().toISOString().replace(/[:T]/g,'-').split('.')[0];
const integrityFile = `audit-${stamp}.json`;
run(`node integrity-audit.js > ${integrityFile}`);
let integrityData=null;
try { integrityData = JSON.parse(fs.readFileSync(integrityFile,'utf8')); } catch {}

// 2. Environment audit (append snapshot line) & chain verify
try { run("node -e \"require('./environment-audit').auditEnvironment()\""); } catch {}
let envChainInfo = null;
try {
  const { verifyChain } = require('./environment-audit');
  envChainInfo = verifyChain();
} catch {}

// 3. Manifest + verification
run('node generate-usb-manifest.js');
const manifest = JSON.parse(fs.readFileSync('artifact-hashes.json','utf8'));
const verifyOut = run('node verify-manifest.js artifact-hashes.json');

// 4. Collect ledger stats & build chain tips summary
function ledgerStats(file){
  if(!fs.existsSync(file)) return null;
  const lines = fs.readFileSync(file,'utf8').trim().split(/\n+/);
  let lastChainHash=null;
  try {
    const lastObj = JSON.parse(lines[lines.length-1]);
    lastChainHash = lastObj.chain_hash || null;
  } catch {}
  return { file, lines: lines.length, lastLine: lines[lines.length-1], lastChainHash }; }
const ledgers = ['share-ledger.jsonl','swap-ledger.jsonl','parity-ledger.jsonl','econ-realization-ledger.jsonl','price-ledger.jsonl','governance-ledger.jsonl']
  .map(ledgerStats);
const chainTips = {};
for (const l of ledgers) { if(l && l.lastChainHash){ chainTips[l.file]=l.lastChainHash; } }
try { fs.writeFileSync('chain-tips.json', JSON.stringify({ ts: Date.now(), tips: chainTips }, null, 2)); } catch {}

// 5. Consolidated report
const integrityRoot = integrityData?.globalMerkleRoot || integrityData?.root || integrityData?.merkleRoot || null;
const auditRootMatches = integrityRoot && manifest.auditMerkleRoot ? (integrityRoot === manifest.auditMerkleRoot) : null;
let verificationStatus = /\[OK\]/.test(verifyOut) ? 'OK' : 'FAIL';
if(auditRootMatches === false){ verificationStatus = 'FAIL_AUDIT_ROOT_MISMATCH'; }
const report = {
  ts: Date.now(),
  integrityFile,
  integrityRoot,
  manifestRoot: manifest.merkleRoot,
  manifestAuditRoot: manifest.auditMerkleRoot,
  manifestHmacSeal: manifest.hmacSeal || null,
  auditRootMatches,
  environmentChainOk: envChainInfo?.ok || false,
  environmentSnapshots: envChainInfo?.total || 0,
  verification: verificationStatus,
  hmacPresent: !!manifest.hmacSeal,
  ledgers,
  chainTips
};
fs.writeFileSync('audit-consolidated-report.json', JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
// Exit codes: 0 OK, 2 mismatch, 1 other fail
if(verificationStatus === 'FAIL_AUDIT_ROOT_MISMATCH') process.exit(2);
if(verificationStatus !== 'OK') process.exit(1);
