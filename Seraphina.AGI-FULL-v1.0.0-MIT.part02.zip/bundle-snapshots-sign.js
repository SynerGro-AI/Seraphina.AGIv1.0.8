// bundle-snapshots-sign.js
// Creates a bundle manifest of recent snapshots and generates detached signature.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const SNAP_DIR = process.env.SERAPHINA_SNAPSHOT_DIR || 'seraphina-snapshots';
const OUT_DIR = process.env.SERAPHINA_SNAPSHOT_BUNDLE_DIR || 'seraphina-snapshot-bundles';
if(!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR,{recursive:true});
const BUNDLE_COUNT = parseInt(process.env.SERAPHINA_SNAPSHOT_BUNDLE_COUNT || '5',10);
const HMAC_KEY = process.env.SERAPHINA_SNAPSHOT_HMAC_KEY || '';

function sha256(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }
function hmac(buf){ if(!HMAC_KEY) return null; return crypto.createHmac('sha256', HMAC_KEY).update(buf).digest('hex'); }

function listSnapshots(){
  if(!fs.existsSync(SNAP_DIR)) return [];
  return fs.readdirSync(SNAP_DIR).filter(f=> f.startsWith('snapshot-') && f.endsWith('.json')).sort();
}

function buildBundle(){
  const snaps = listSnapshots();
  if(!snaps.length){ console.log('[BundleSnapshots] No snapshots'); return null; }
  const chosen = snaps.slice(-BUNDLE_COUNT);
  const entries = [];
  for(const f of chosen){
    const p = SNAP_DIR+'/'+f; const content = fs.readFileSync(p); const hash = sha256(content);
    entries.push({ file:f, sha256:hash, bytes: content.length });
  }
  const manifest = { ts: Date.now(), iso: new Date().toISOString(), count: entries.length, snapshots: entries };
  const manifestBuf = Buffer.from(JSON.stringify(manifest));
  manifest.sha256 = sha256(manifestBuf);
  manifest.hmac = hmac(manifestBuf);
  const outFile = OUT_DIR + '/bundle-' + manifest.iso.replace(/[:.]/g,'-') + '.json';
  fs.writeFileSync(outFile, JSON.stringify(manifest,null,2));
  const sigObj = { bundle: outFile, sha256: manifest.sha256, hmac: manifest.hmac, ts: manifest.ts };
  const sigFile = outFile.replace(/\.json$/, '.sig.json');
  fs.writeFileSync(sigFile, JSON.stringify(sigObj,null,2));
  console.log('[BundleSnapshots] Bundle written', outFile, 'sha='+manifest.sha256.slice(0,16));
  return { manifestFile: outFile, sigFile };
}

if(require.main===module){ buildBundle(); }
module.exports = { buildBundle };
