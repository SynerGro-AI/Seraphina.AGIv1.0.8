# Aurrelia Holodeck DNS Virtualization & Attack Simulation

## Purpose
The Holodeck DNS layer provides a fully deterministic, sandboxed DNS resolution surface for mining + network scenario testing. It replaces live resolver calls with:
- Mapped or synthetic IP answers (stable across runs)
- Per‑host latency, TTL and negative caching
- Controlled failure injection & rate limiting
- Deterministic poisoning waves (Phase 2)
- Response size amplification profiling (simulating DNS amplification behavior without real packets)
- Rolling trace ring for post‑scenario forensics

No real network traffic or external DNS queries occur. All behavior is reproducible given the same environment variables and seed.

## Activation Flags
| Variable | Type | Description |
|----------|------|-------------|
| `HOLODECK_ENABLE` | bool | Master holodeck switch (time, feeds, etc.). Must be `1` for DNS layer to matter. |
| `HOLODECK_DNS_ENABLE` | bool | Enables DNS virtualization when `1`. |
| `HOLODECK_ROOT` | path | `F:/` | Base holodeck sandbox root used when resolving relative DNS map file paths. Defaults to `F:/` if unset. |

### Holodeck Root Location (Dataland F:/)
If your sandbox ("dataland") lives on `F:/`, keep any external DNS map or related scenario files on that drive for isolation, e.g.:
```
HOLODECK_DNS_FILE=F:/holo-config/dns-map.json
```
All generated state (trace, stats in logs) remains process-local unless you explicitly write to a file under `F:/`. This maintains the guarantee that no real system locations (like `C:/Windows/...`) are touched.

## Core Mapping & Synthesis (Phase 1)
| Variable | Type | Example | Notes |
|----------|------|---------|-------|
| `HOLODECK_DNS_MAP` | JSON-ish | `{"example.com":"<IP>","*.pool":"<IP>"}` | Inline mapping; loose JSON (quotes auto-repaired). Patterns may use leading or trailing `*` for substring match. |
| `HOLODECK_DNS_FILE` | path | `C:/path/dns-map.json` | External file overriding inline map. File is read once at startup. |
| `HOLODECK_DNS_LATENCY_MAP` | JSON-ish | `{ "*.slow":180, "fast.example":5 }` | Per-host base latency in ms. Unlisted hosts get default randomish deterministic base (if implemented) or near-zero. |
| `HOLODECK_DNS_TTL_MAP` | JSON-ish | `{ "*.cache":30000, "volatile.example":500 }` | Per-host TTL override (ms). |
| `HOLODECK_DNS_NEG_TTL` | int | `5000` | Time negative (failed) lookups are cached before retry. |

### Deterministic Synthetic IP Generation
If a host is not in the map, a synthetic IPv4 (and IPv6 where requested) is generated deterministically from the host + seed. This ensures stability across runs.

### Caching Behavior
- Positive answers cached until `ttl` expires.
- Negative answers cached `HOLODECK_DNS_NEG_TTL` ms.
- Cache stats logged periodically when logging enabled.

## Attack Simulation (Phase 2)
| Variable | Type | Example | Description |
|----------|------|---------|-------------|
| `HOLODECK_DNS_POISON_MAP` | JSON-ish | `{ "*.malware":"<IP>", "bad.example":"<IP>" }` | Patterns mapped to poison IP targets. |
| `HOLODECK_DNS_POISON_RATE` | float [0..1] | `0.25` | Probability a susceptible lookup is poisoned (deterministic dice roll). |
| `HOLODECK_DNS_POISON_HEAL_TTL` | int ms | `60000` | Duration after first poison that host remains poisoned before healing. |
| `HOLODECK_DNS_RATE_LIMIT` | int | `120` | Max lookups per window. >limit responses become RATE_LIMIT failures. 0 disables. |
| `HOLODECK_DNS_RATE_WINDOW_MS` | int ms | `1000` | Rolling window length for rate limiter. |
| `HOLODECK_DNS_AMP_PROFILE` | JSON-ish | `{ "default":64, "large":512, "dnssec":1024 }` | Byte size classes simulating amplification potential. |
| `HOLODECK_DNS_AMP_MAP` | JSON-ish | `{ "*.big": "large", "secure.example": "dnssec" }` | Pattern -> amplification class. |
| `HOLODECK_DNS_TRACE_MAX` | int | `200` | Max entries retained in trace ring. Old entries evicted FIFO. |

### Poisoning Flow
1. Host matches a pattern in `POISON_MAP`.
2. Deterministic SHA256(seed + host + lookupCounter) first byte scaled to [0,1].
3. If `dice < POISON_RATE` or host already poisoned (within healing TTL), answer replaced with poison IP.
4. Poison state heals after `POISON_HEAL_TTL` ms.

### Rate Limiting
Per-process sliding window counts lookups. When count surpasses `RATE_LIMIT` within `RATE_WINDOW_MS`, lookup fails with synthetic `RATE_LIMIT` error (tracked in stats).

### Amplification Profiling
Designed to mimic inflated DNS response size classes (no real packet flood). Each successful lookup logs `ampBytes=<size>` derived from profile mapping. `ampLarge` counter increments for class `large`.

### Trace Ring
Global: `global.__HOLO_DNS_TRACE__` (array of most recent events). Each event structure:
```js
{ host, ip, mapped, ttl, ampBytes, poisoned, error?, v6?, ts }
```
Use for scenario forensics, poisoning wave analysis, rate limit hit timing.

## Stats & Counters
Periodically logged when DNS logging enabled (see existing logger integration):
- `lookups` total attempted
- `mapped` direct map hits
- `synth` synthetic answers
- `fail` failures (including RATE_LIMIT, ENOTFOUND)
- `cacheHits` positive cache hits
- `cacheMisses` positive misses
- `negHits` negative cache hits
- `poisoned` poisoned answers served
- `rateLimited` rate limit failures
- `ampLarge` count of large amplification class answers
- `traceSize` current trace ring length

## Example Configuration (Windows PowerShell)
Prefer setting env vars in a script rather than a long one-liner to avoid quoting issues.
```powershell
# Enable Holodeck DNS
$env:HOLODECK_ENABLE = '1'
$env:HOLODECK_DNS_ENABLE = '1'
$env:HOLODECK_ROOT = 'F:/'

# Basic mapping
$env:HOLODECK_DNS_MAP = '{"pool.example":"<IP>","*.fast":"<IP>"}'
$env:HOLODECK_DNS_LATENCY_MAP = '{"*.fast":5,"*.slow":180}'
$env:HOLODECK_DNS_TTL_MAP = '{"*.fast":5000,"pool.example":30000}'
$env:HOLODECK_DNS_NEG_TTL = '4000'

# Phase 2 attack sim
$env:HOLODECK_DNS_POISON_MAP = '{"*.malware":"<IP>"}'
$env:HOLODECK_DNS_POISON_RATE = '0.30'
$env:HOLODECK_DNS_POISON_HEAL_TTL = '60000'
$env:HOLODECK_DNS_RATE_LIMIT = '120'
$env:HOLODECK_DNS_RATE_WINDOW_MS = '1000'
$env:HOLODECK_DNS_AMP_PROFILE = '{"default":64,"large":512,"dnssec":1024}'
$env:HOLODECK_DNS_AMP_MAP = '{"*.big":"large","secure.example":"dnssec"}'
$env:HOLODECK_DNS_TRACE_MAX = '300'

# Start miner
node aurrelia-pico-mesh-miner.js
```

### .env File Alternative
For complex JSON maps, consider a `.env` file and a loader (e.g. `dotenv`). Escape quotes minimally:
```
HOLODECK_ENABLE=1
HOLODECK_DNS_ENABLE=1
HOLODECK_DNS_MAP={"pool.example":"<IP>","*.fast":"<IP>"}
HOLODECK_DNS_POISON_MAP={"*.malware":"<IP>"}
HOLODECK_DNS_AMP_PROFILE={"default":64,"large":512,"dnssec":1024}
HOLODECK_ROOT=F:/
```

## Pattern Matching Notes
Current implementation treats patterns with leading or trailing `*` as substring match anchors. (e.g. `*.fast` matches suffix `.fast`; `malware*` matches prefix `malware`). Plain hostnames match exact. Avoid overly broad patterns to keep deterministic behavior analyzable.

## Determinism Guarantees
- Synthetic IPs: Stable given `(seed, host)`.
- Poison decision: Stable given `(seed, host, lookupIndex)`.
- Amplification class: Stable via pattern mapping.
- Rate limit: Deterministic time windows (local clock under Holodeck time virtualization).

## Safety & Isolation
All actions remain advisory/simulated. No real DNS queries, no network poisoning, no amplification packets. This is purely an internal training & resilience surface.
Never pipe agent output directly into operational config without human or deterministic validator review.

## Operational Tips
- Keep `POISON_RATE` low (<=0.3) for realistic sporadic contamination.
- Use `POISON_HEAL_TTL` to study recovery logic; shorter TTL for rapid cycling tests.
- Combine latency + amplification to emulate stress (high latency + large amp responses).
- Monitor `rateLimited` to tune client backoff strategies.

## Forensics Workflow Example
```js
// Inspect recent poisoned events
const trace = global.__HOLO_DNS_TRACE__ || [];
const poisoned = trace.filter(e => e.poisoned);
console.log('Poisoned events', poisoned.length); console.dir(poisoned.slice(-5));
```

## Roadmap (Future Phases)
1. DNSSEC Simulation Layer (deterministic signature sizes, failure injection).
2. Cost / rate tracking per pattern for adaptive throttle.
3. Structured JSON export of trace + stats for external ML latency mitigation agent.
4. Replay Shield (hash ring) to detect repeated poison attempts patterns.

## Troubleshooting
| Symptom | Cause | Fix |
|---------|-------|-----|
| Stats not logging | Logging disabled or interval suppressed | Ensure global logging flag / start script includes DNS log enable. |
| All lookups RATE_LIMIT | `RATE_LIMIT` too low or bursty test harness | Increase limit or widen `RATE_WINDOW_MS`. |
| No poisoning observed | Pattern mis-match or `POISON_RATE=0` | Verify pattern format & raise `POISON_RATE` temporarily. |
| Amplification always default | `AMP_MAP` class names not in `AMP_PROFILE` | Add missing class size to profile. |

## Minimal Quick Start
```powershell
$env:HOLODECK_ENABLE='1'
$env:HOLODECK_DNS_ENABLE='1'
$env:HOLODECK_DNS_MAP='{"pool":"<IP>"}'
node aurrelia-pico-mesh-miner.js
```

---
Document version: 1.0 (Phase 2). Update when new phases land.
