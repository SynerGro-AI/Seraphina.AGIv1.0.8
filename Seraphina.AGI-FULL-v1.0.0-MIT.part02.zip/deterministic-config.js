// deterministic-config.js
// Centralized deterministic parameter resolution (single source of truth)

// Parse CLI once (idempotent; safe to require multiple times)
const ARG_SEED = (process.argv.find(a=>a.startsWith('--seed='))||'').split('=')[1];
const ARG_BURROW = (process.argv.find(a=>a.startsWith('--burrow-depth='))||'').split('=')[1];
const ARG_PRUNE = (process.argv.find(a=>a.startsWith('--prune-threshold='))||'').split('=')[1];

const GLOBAL_OCTO_SEED = parseInt(process.env.AUR_SEED || ARG_SEED || '42', 10) >>> 0;
// Default kept shallow (5) to avoid explosive norm growth; adaptivity / overrides can raise.
const GLOBAL_BURROW_DEPTH = parseInt(process.env.AUR_BURROW_DEPTH || ARG_BURROW || '5', 10);
const GLOBAL_PRUNE_THRESHOLD = parseFloat(process.env.AUR_PRUNE_THRESHOLD || ARG_PRUNE || '2.5');
// Externalized adaptive & telemetry thresholds
const SKIP_VAR_THRESH = parseFloat(process.env.SKIP_VAR_THRESH || '0.90');
const SKIP_EMA_ALPHA = parseFloat(process.env.SKIP_EMA_ALPHA || '0.90'); // smoothing for skip rate EMA (closer to 1 = slower)
let RANK_BUCKET_EDGES = (process.env.RANK_BUCKET_EDGES || '0.8,0.9,1.0,1.1,1.2,1.3').split(',').map(s=>parseFloat(s.trim())).filter(n=>!isNaN(n));
// Optional persisted dynamic bucket extensions
try {
  const fs = require('fs'); const path = require('path');
  const persisted = path.join(process.cwd(),'rank-buckets.json');
  if (fs.existsSync(persisted)){
    const arr = JSON.parse(fs.readFileSync(persisted,'utf8'));
    if (Array.isArray(arr) && arr.every(x=>typeof x==='number' && isFinite(x))){
      const MAX = parseInt(process.env.MAX_RANK_BUCKETS || '16',10);
      RANK_BUCKET_EDGES = arr.slice(0,MAX).sort((a,b)=>a-b);
    }
  }
} catch(_){ }
const CHERN_VAR_ALPHA = parseFloat(process.env.CHERN_VAR_ALPHA || '0.85'); // EWMA for variance
const CHERN_ALERT = parseFloat(process.env.CHERN_ALERT || '0.02'); // alert threshold
const crypto = require('crypto');
const CONFIG_HASH = crypto.createHash('sha256').update([
  GLOBAL_OCTO_SEED, GLOBAL_BURROW_DEPTH, GLOBAL_PRUNE_THRESHOLD,
  SKIP_VAR_THRESH, SKIP_EMA_ALPHA, RANK_BUCKET_EDGES.join('|'), CHERN_VAR_ALPHA, CHERN_ALERT
].join(':')).digest('hex');
const VAULT_HMAC = process.env.VAULT_PASS ? crypto.createHmac('sha256', process.env.VAULT_PASS).update(CONFIG_HASH).digest('hex') : null;

function getDeterministicConfig(extra = {}) {
  return {
    seed: GLOBAL_OCTO_SEED,
    burrowDepth: GLOBAL_BURROW_DEPTH,
    pruneThreshold: GLOBAL_PRUNE_THRESHOLD,
    skipVarThresh: SKIP_VAR_THRESH,
    skipEmaAlpha: SKIP_EMA_ALPHA,
    rankBucketEdges: RANK_BUCKET_EDGES,
    chernVarAlpha: CHERN_VAR_ALPHA,
    chernAlert: CHERN_ALERT,
    ...extra
  };
}

module.exports = {
  GLOBAL_OCTO_SEED,
  GLOBAL_BURROW_DEPTH,
  GLOBAL_PRUNE_THRESHOLD,
  SKIP_VAR_THRESH,
  SKIP_EMA_ALPHA,
  RANK_BUCKET_EDGES,
  CHERN_VAR_ALPHA,
  CHERN_ALERT,
  getDeterministicConfig,
  CONFIG_HASH,
  VAULT_HMAC
};
