#!/usr/bin/env node
// life-drawing-manifest-verify.js
// Verify last signature in signature log matches current manifest digest.
'use strict';
const fs = require('fs');
const path = require('path');
const nacl = require('tweetnacl');
const crypto = require('crypto');
function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function verify(){
  const manifestPath = path.join(__dirname,'life-drawing-analytics-manifest.json');
  const sigPath = path.join(__dirname,'life-drawing-manifest-signatures.json');
  if(!fs.existsSync(manifestPath)) return { ok:false, message:'Manifest missing' };
  if(!fs.existsSync(sigPath)) return { ok:false, message:'No signatures yet' };
  let manifest, sigs;
  try { manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8')); } catch(e){ return { ok:false, message:'Manifest parse error '+e.message }; }
  try { sigs = JSON.parse(fs.readFileSync(sigPath,'utf8')); } catch(e){ return { ok:false, message:'Signature log parse error '+e.message }; }
  if(!manifest.digest) manifest.digest = sha256(manifest);
  if(!Array.isArray(sigs) || !sigs.length) return { ok:false, message:'Empty signature log' };
  const last = sigs[sigs.length-1];
  const digestHex = manifest.digest;
  const sigBuf = Buffer.from(last.signature,'hex');
  const pubBuf = Buffer.from(last.publicKey,'hex');
  const digBuf = Buffer.from(digestHex,'hex');
  const valid = nacl.sign.open(sigBuf, pubBuf) ? true : false; // open returns message if valid
  const messageMatches = valid && Buffer.from(nacl.sign.open(sigBuf, pubBuf)).equals(digBuf);
  return { ok: !!(valid && messageMatches), digest: digestHex, signature: last.signature.slice(0,40)+'...', publicKey: last.publicKey, ts: last.ts };
}

if(require.main === module){
  console.log(JSON.stringify(verify(), null, 2));
}

module.exports = { verify };
