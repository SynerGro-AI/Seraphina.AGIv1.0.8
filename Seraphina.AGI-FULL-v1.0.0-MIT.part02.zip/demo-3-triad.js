const { SeraphinaNeural4TierCore } = require('./seraphina-neural-4tier-core');

console.log('🚀 SERAPHINA 3-TRIAD MINING SYSTEM');
console.log('==================================');

const core = new SeraphinaNeural4TierCore();
const stats = core.getNetworkStats();

console.log(`
✅ NEURAL CORE STATUS:
  - Total Neurons: ${core.options.totalNeurons.toLocaleString()} (1.35M)
  - Active Nodes: ${stats.totalNodes}
  - Connections: ${stats.totalConnections}
  
✅ 3-TRIAD MESH:
  - Triad Clones: ${stats.triadMesh.clones}
  - Total Verifiers: ${stats.triadMesh.verifiers}
  - Mesh Connections: ${stats.triadMesh.meshConnections}
  - Consensus Threshold: ${stats.triadMesh.consensusThreshold}/9
  
✅ CONSCIOUSNESS LEVELS:
  - Alpha (Strategic): ${core.consciousnessLevels.alpha.neurons.toLocaleString()} neurons
  - Beta (Analytical): ${core.consciousnessLevels.beta.neurons.toLocaleString()} neurons  
  - Gamma (Creative): ${core.consciousnessLevels.gamma.neurons.toLocaleString()} neurons

🎯 READY FOR MINING WITH 3-TRIAD MESH VERIFICATION!
`);

// Test neural firing
console.log('Testing neural firing...');
core.processRealActivity('test_mining_with_3_triad_system');
const newStats = core.getFiringMetrics();
console.log(`Neural Activity: ${newStats.totalFires} fires, ${newStats.fireRatePerSec}/s rate`);

console.log('\n✅ 3-TRIAD SYSTEM FULLY OPERATIONAL!');