// life-drawing-next-exam-recommend.js
// Suggest weakest 3 fields and produce augmented exam JSON with focus hints.
'use strict';
const { generateLifeDrawingExam } = require('./life-drawing-exam');
const { generateReport } = require('./life-drawing-coverage-report');

function recommendWeakFields(){
  const report = generateReport();
  if(!report.ok) return { list: [], detail: [] };
  return { list: report.recommended || [], detail: report.recommendationDetail || [] };
}

function generateFocusedExam(opts={}){
  const { list, detail } = recommendWeakFields();
  const limit = opts.limit || 5;
  const exam = generateLifeDrawingExam({ limit });
  if(list.length){
    exam.focus = {
      weakFields: list,
      fieldsOrdered: detail.map(d=> d.field),
      scores: detail.map(d=> ({ field: d.field, score: Number(d.score.toFixed(4)) })),
      note: 'Emphasize practice (ordered by blended score): '+ list.join(', ')
    };
  }
  return exam;
}

if(require.main === module){
  const exam = generateFocusedExam({ limit: process.env.LIFE_DRAWING_EXAM_LIMIT? parseInt(process.env.LIFE_DRAWING_EXAM_LIMIT,10): 6 });
  console.log(JSON.stringify(exam,null,2));
}

module.exports = { generateFocusedExam };