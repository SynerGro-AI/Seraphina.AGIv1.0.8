#!/usr/bin/env node
// life-drawing-manifest-sign.js
// Ed25519 signature over analytics manifest digest (deterministic seed) for authenticity.
'use strict';
const fs = require('fs');
const path = require('path');
const nacl = require('tweetnacl');
const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function deriveSeed(){
  // Deterministic seed from env or fallback phrase
  const raw = process.env.LIFE_DRAWING_SIG_SEED || 'life-drawing-default-seed-v1';
  // Expand to 32 bytes by hashing
  const seedHex = sha256(raw).slice(0,64); // 32 bytes hex
  const seed = Buffer.from(seedHex,'hex');
  return seed;
}

function signManifest(){
  const manifestPath = path.join(__dirname,'life-drawing-analytics-manifest.json');
  if(!fs.existsSync(manifestPath)) return { ok:false, message:'Manifest missing. Run analytics-manifest script first.' };
  let manifest; try { manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8')); } catch(e){ return { ok:false, message:'Manifest parse error: '+e.message }; }
  if(!manifest.digest) manifest.digest = sha256(manifest);
  const seed = deriveSeed();
  const keyPair = nacl.sign.keyPair.fromSeed(new Uint8Array(seed));
  const digestBytes = Buffer.from(manifest.digest,'hex');
  const sig = nacl.sign(digestBytes, keyPair.secretKey);
  const signatureHex = Buffer.from(sig).toString('hex');
  const publicKeyHex = Buffer.from(keyPair.publicKey).toString('hex');
  const record = { ts: new Date().toISOString(), digest: manifest.digest, signature: signatureHex, publicKey: publicKeyHex, seedHash: sha256(seed) };
  const sigLogPath = path.join(__dirname,'life-drawing-manifest-signatures.json');
  let log = []; if(fs.existsSync(sigLogPath)){ try { log = JSON.parse(fs.readFileSync(sigLogPath,'utf8')); } catch(_){ } }
  log.push(record);
  fs.writeFileSync(sigLogPath, JSON.stringify(log,null,2));
  return { ok:true, signature: signatureHex, publicKey: publicKeyHex, count: log.length };
}

if(require.main === module){
  console.log(JSON.stringify(signManifest(), null, 2));
}

module.exports = { signManifest };
