// chain-balance.js - Fetch on-chain balances for RVN / FREN via JSON-RPC (fallback deterministic)
'use strict';
const https = require('https');

function rpcCall(host, port, user, pass, method, params){
  const body = JSON.stringify({ jsonrpc:'1.0', id:'cb', method, params });
  const auth = Buffer.from(user+':'+pass).toString('base64');
  const opts = { host, port, method:'POST', path:'/', headers:{ 'Content-Type':'application/json', 'Authorization':'Basic '+auth, 'Content-Length':Buffer.byteLength(body) } };
  return new Promise((resolve,reject)=>{
    const req = https.request(opts, res=>{ let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ try { const j=JSON.parse(data); if (j.error) reject(new Error(j.error.message)); else resolve(j.result); } catch(e){ reject(e); } }); });
    req.on('error', reject); req.write(body); req.end();
  });
}

async function getRvnBalance(){
  if (!process.env.RVN_RPC_HOST) return 0;
  try { const bal = await rpcCall(process.env.RVN_RPC_HOST, process.env.RVN_RPC_PORT||'8766', process.env.RVN_RPC_USER||'user', process.env.RVN_RPC_PASS||'pass', 'getbalance', []); return Number(bal)||0; }
  catch(e){ return 0; }
}
async function getFrenBalance(){
  if (!process.env.FREN_RPC_HOST) return 0;
  try { const bal = await rpcCall(process.env.FREN_RPC_HOST, process.env.FREN_RPC_PORT||'8332', process.env.FREN_RPC_USER||'user', process.env.FREN_RPC_PASS||'pass', 'getbalance', []); return Number(bal)||0; }
  catch(e){ return 0; }
}

module.exports = { getRvnBalance, getFrenBalance };
