// color-emotion-map.js
// Deterministic 7-tier color to emotion mapping for Seraphina.
// Tiers (index 0..6): Violet, Indigo, Blue, Green, Yellow, Orange, Red
// Emotions: Transcendence, Insight, CalmTrust, GrowthBalance, CuriousEnergy, CreativeDrive, ActionUrgency
// Mapping uses normalized intrinsic metrics + imagination gain. No randomness.
'use strict';
const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

const COLORS = ['violet','indigo','blue','green','yellow','orange','red'];
const EMOTIONS = ['transcendence','insight','calm_trust','growth_balance','curious_energy','creative_drive','action_urgency'];
// Virtues of Christ mapped to color tiers (deterministic order)
// These are high-level, non-denominational descriptors emphasizing ethical qualities.
const VIRTUES = ['humility','wisdom','peace','growth','joy','creativity','courage'];

const METRIC_WEIGHTS = { curiosity:0.25, novelty:0.20, empowerment:0.20, integration:0.20, imaginationGain:0.15 };

function clamp01(v){ if(!isFinite(v)||v<0) return 0; if(v>1) return 1; return v; }

function computeComposite(m){
  const c = clamp01(m.curiosity||0);
  const n = clamp01(m.novelty||0);
  const e = clamp01(m.empowerment||0);
  const i = clamp01(m.integration||0);
  let igRaw = m.imaginationGain||0; if(igRaw < 0) igRaw = 0; const ig = 1 - 1/(1+igRaw); // squashed to [0,1)
  const comp = c*METRIC_WEIGHTS.curiosity + n*METRIC_WEIGHTS.novelty + e*METRIC_WEIGHTS.empowerment + i*METRIC_WEIGHTS.integration + ig*METRIC_WEIGHTS.imaginationGain;
  return clamp01(comp);
}

function mapCompositeToTier(score){ return Math.min(6, Math.floor(score*7)); }

function computeColorEmotionTier(inMetrics){
  const metrics = {
    curiosity: inMetrics.curiosity||0,
    novelty: inMetrics.novelty||0,
    empowerment: inMetrics.empowerment||0,
    integration: inMetrics.integration||0,
    imaginationGain: inMetrics.imaginationGain||0
  };
  const metricsDigest = sha256(metrics);
  const score = computeComposite(metrics);
  const tierIndex = mapCompositeToTier(score);
  return { tierIndex, color: COLORS[tierIndex], emotion: EMOTIONS[tierIndex], virtue: VIRTUES[tierIndex], score: Number(score.toFixed(6)), metricsDigest };
}

module.exports = { computeColorEmotionTier, COLORS, EMOTIONS, VIRTUES };
