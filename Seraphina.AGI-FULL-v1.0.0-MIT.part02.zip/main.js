const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let miningProcess;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    icon: path.join(__dirname, 'icon.ico')
  });

  mainWindow.loadFile('index.html');

  // Create menu
  const template = [
    {
      label: 'Mining',
      submenu: [
        {
          label: 'Start Mining',
          click: () => startMining()
        },
        {
          label: 'Stop Mining',
          click: () => stopMining()
        },
        { type: 'separator' },
        {
          label: 'Exit',
          click: () => app.quit()
        }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

function startMining() {
  if (miningProcess) {
    console.log('Mining already running');
    return;
  }

  miningProcess = spawn('node', ['seraphina-REAL-mining-extended.js'], {
    cwd: __dirname,
    stdio: 'pipe'
  });

  miningProcess.stdout.on('data', (data) => {
    console.log(`Mining: ${data}`);
    if (mainWindow) {
      mainWindow.webContents.send('mining-log', data.toString());
    }
  });

  miningProcess.stderr.on('data', (data) => {
    console.error(`Mining Error: ${data}`);
    if (mainWindow) {
      mainWindow.webContents.send('mining-error', data.toString());
    }
  });

  miningProcess.on('close', (code) => {
    console.log(`Mining process exited with code ${code}`);
    miningProcess = null;
    if (mainWindow) {
      mainWindow.webContents.send('mining-stopped', code);
    }
  });
}

function stopMining() {
  if (miningProcess) {
    miningProcess.kill();
    miningProcess = null;
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  stopMining();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC handlers
ipcMain.on('start-mining', () => startMining());
ipcMain.on('stop-mining', () => stopMining());