'use strict';
// deposit-manager.js - Automate on-chain -> exchange deposits (dry-run capable)
// Triggers when on-chain balance crosses configured threshold.
// ENV:
//  RVN_DEPOSIT_MIN, FREN_DEPOSIT_MIN (numeric, coins)
//  RVN_DEPOSIT_ADDR, FREN_DEPOSIT_ADDR (target exchange deposit addresses)
//  *_RPC_HOST / PORT / USER / PASS already used by chain-balance.js
//  DEPOSIT_DRY_RUN=1 for simulation only
//  DEPOSIT_INTERVAL_MS (default 180000)
//  DEPOSIT_SEND_PCT (fraction of balance to send, default 0.9)

const https = require('https');

function rpcCall(host, port, user, pass, method, params){
  const body = JSON.stringify({ jsonrpc:'1.0', id:'dep', method, params });
  const auth = Buffer.from(user+':'+pass).toString('base64');
  const opts = { host, port, method:'POST', path:'/', headers:{ 'Content-Type':'application/json', 'Authorization':'Basic '+auth, 'Content-Length':Buffer.byteLength(body) } };
  return new Promise((resolve,reject)=>{
    const req = https.request(opts, res=>{ let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ try { const j=JSON.parse(data); if (j.error) reject(new Error(j.error.message)); else resolve(j.result); } catch(e){ reject(e); } }); });
    req.on('error', reject); req.write(body); req.end();
  });
}

class DepositManager {
  constructor(pipeline){
    this.pipeline = pipeline;
    this.dry = process.env.DEPOSIT_DRY_RUN === '1';
    this.intervalMs = parseInt(process.env.DEPOSIT_INTERVAL_MS||'180000',10);
    this.sendPct = Math.min(0.999, Math.max(0.01, parseFloat(process.env.DEPOSIT_SEND_PCT||'0.9')));
    this._lastAttempt = 0;
    this._loop();
  }
  async _loop(){
    try { await this._tick(); } catch(e){ console.warn('[Deposit][TickErr]', e.message); }
    setTimeout(()=>this._loop(), this.intervalMs).unref();
  }
  async _tick(){
    const coin = this.pipeline.selectedCoin;
    if (!['rvn','fren'].includes(coin)) return; // only for implemented RPC coins
    const bal = (this.pipeline.trader && this.pipeline.trader.onChainBalances[coin]) || 0;
    const minEnv = (coin==='rvn'? process.env.RVN_DEPOSIT_MIN : process.env.FREN_DEPOSIT_MIN) || '0';
    const min = parseFloat(minEnv)||0;
    if (bal < min || min<=0) return;
    const addr = coin==='rvn' ? process.env.RVN_DEPOSIT_ADDR : process.env.FREN_DEPOSIT_ADDR;
    if (!addr){ console.warn('[Deposit] Threshold met but no deposit address for', coin); return; }
    const amount = +(bal * this.sendPct).toFixed(8);
    // Basic rate limit: avoid spamming
    if (Date.now()-this._lastAttempt < this.intervalMs/2) return;
    this._lastAttempt = Date.now();
    if (this.dry){ console.log('[Deposit][DRY]', { coin, balance: bal, amount, addr }); return; }
    try {
      // Use coin-specific RPC credentials
      const host = process.env[(coin==='rvn'?'RVN':'FREN')+'_RPC_HOST'];
      const port = process.env[(coin==='rvn'?'RVN':'FREN')+'_RPC_PORT'];
      const user = process.env[(coin==='rvn'?'RVN':'FREN')+'_RPC_USER'];
      const pass = process.env[(coin==='rvn'?'RVN':'FREN')+'_RPC_PASS'];
      if (!host){ console.warn('[Deposit] Missing RPC host for', coin); return; }
      const txid = await rpcCall(host, port|| (coin==='rvn'?'8766':'8332'), user||'user', pass||'pass', 'sendtoaddress', [addr, amount]);
      console.log('[Deposit][Sent]', { coin, amount, addr, txid });
    } catch(e){ console.error('[Deposit][Error]', e.message); }
  }
}

module.exports = DepositManager;
