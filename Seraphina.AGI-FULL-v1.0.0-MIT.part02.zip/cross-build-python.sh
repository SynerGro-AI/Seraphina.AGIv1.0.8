#!/usr/bin/env bash
# Multi-arch Python build helper using Docker buildx (x86_64 + arm64) producing tarball artifacts.
# Requires: docker, buildx initialized.
# Usage: bash cross-build-python.sh 3.12.5
set -euo pipefail
VER=${1:-3.12.5}
IMAGE_BASE=python-src-build
PLATFORMS=${PLATFORMS:-linux/amd64,linux/arm64}
OUT_DIR=${OUT_DIR:-python-multiarch-dist}
mkdir -p "$OUT_DIR"

cat > Dockerfile.cross <<EOF
FROM ubuntu:22.04 AS build
ARG VER
RUN apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y \
    build-essential wget xz-utils libssl-dev libbz2-dev libreadline-dev libffi-dev zlib1g-dev && rm -rf /var/lib/apt/lists/*
WORKDIR /src
RUN wget https://www.python.org/ftp/python/$VER/Python-$VER.tgz && tar xf Python-$VER.tgz
WORKDIR /src/Python-$VER
RUN ./configure --prefix=/opt/python --enable-optimizations --with-lto && make -j$(nproc) && make altinstall && ln -sf /opt/python/bin/python3.* /opt/python/bin/python3
RUN tar czf /tmp/python-$VER-root.tar.gz -C /opt python
CMD ["/bin/bash"]
EOF

docker buildx build --platform $PLATFORMS --build-arg VER=$VER -t $IMAGE_BASE:$VER --output type=local,dest=$OUT_DIR .

echo "[OK] Multi-arch artifacts in $OUT_DIR (each image filesystem snapshot)."