# External GPU Hasher Hook (Design)

Environment Flags:
  GPU_HASHER_CMD   - Command to spawn (e.g. kawpowminer path)
  GPU_HASHER_PROTO - 'stdin-json' (default) | future protocols

Protocol (stdin-json):
  We send lines:
    {"type":"job","jobId":...,"headerParts":{...},"targetHex":"...","extranonce1":"...","ex2Size":8}
  External process responds with lines:
    {"type":"share","jobId":"...","ex2":"...","ntime":"...","nonce":"...","mixHash":"..."}

The mining-core will validate jobId and call submitShare().

Next Step: integrate optional spawning & line parsing in mining-core.
