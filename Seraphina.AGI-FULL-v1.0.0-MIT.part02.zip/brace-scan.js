const fs = require('fs');
const lines = fs.readFileSync('aurrelia-pico-mesh-miner.js','utf8').split(/\r?\n/);
const stack = [];
const problems = [];
for (let i=0;i<lines.length;i++){
  const line = lines[i];
  for (let j=0;j<line.length;j++){
    const ch = line[j];
    if (ch === '{') stack.push({ line: i+1, col: j+1 });
    else if (ch === '}') {
      if (stack.length===0) problems.push({ type:'unexpected_close', line:i+1, col:j+1 });
      else stack.pop();
    }
  }
}
console.log('Total opens remaining:', stack.length);
console.log('Unclosed openings:', stack.slice(-20));
console.log('Unexpected closes:', problems);
