// deterministic-util.js
// Provides hash-based deterministic derivations to eliminate runtime randomness.
// NOTE: Using deterministic IVs / keys reduces cryptographic confidentiality; only enable if full determinism is mandated.
const crypto = require('crypto');

function deriveHex(label, ...parts) {
  const h = crypto.createHash('sha256');
  h.update(String(label));
  for (const p of parts) h.update(String(p));
  return h.digest('hex');
}

function deriveInt(label, modulo, ...parts) {
  if (!Number.isFinite(modulo) || modulo <= 0) throw new Error('deriveInt modulo must be >0');
  const hex = deriveHex(label, ...parts);
  // Use first 12 hex chars for int space, mod by provided bound.
  return parseInt(hex.slice(0, 12), 16) % modulo;
}

function deriveBuffer(label, length, ...parts) {
  if (!Number.isFinite(length) || length <= 0) throw new Error('deriveBuffer length must be >0');
  let hex = '';
  let counter = 0;
  while (hex.length < length * 2) {
    hex += deriveHex(label + ':' + counter, ...parts);
    counter++;
  }
  return Buffer.from(hex.slice(0, length * 2), 'hex');
}

function deriveId(label, ...parts) {
  const hex = deriveHex(label, ...parts);
  return label + '-' + hex.slice(0, 16);
}

module.exports = { deriveHex, deriveInt, deriveBuffer, deriveId };
