"use strict";
// crystal-tuner.js – trimmed deterministic PicoCrystalTuner
// Purpose: deterministic frequency weighting & optional ring persistence (disabled in minimal rebuild unless explicitly enabled)

const crypto = require('crypto');
const fs = require('fs');
const { SimpleOcto } = require('./geometry-octo.js');

class PicoCrystalTuner {
  constructor(baseFreq=432){
    this.base = baseFreq;
    this.crystals = [];
    this.totalCrystals = 0; this.sumNorm=0; this.lastAvgNorm=0;
    this.persistEnabled = process.env.CRYSTAL_PERSIST === '1';
    this.persistPath = process.env.CRYSTAL_PERSIST_PATH || 'crystal-ring.jsonl';
    this.persistBatch = parseInt(process.env.CRYSTAL_PERSIST_BATCH || '200',10);
    this.persistBuffer = [];
  }
  meshDataHash(dataHash, nodeFreq, sweepSeed){
    const hash = crypto.createHash('sha256').update(dataHash).digest('hex');
    const coeffs = Array.from(hash.match(/.{1,2}/g)).reduce((acc,h,i)=>{ acc[i%8]+= parseInt(h,16)/255; return acc; }, Array(8).fill(0));
    const crystal = new SimpleOcto(coeffs);
    const norm = crystal.norm();
    this.crystals.push(crystal); this.totalCrystals++; this.sumNorm += norm;
    if (this.totalCrystals % 5000 === 0){ this.lastAvgNorm = this.sumNorm/this.totalCrystals; console.log(`[CrystalTuner] crystals=${this.totalCrystals} avgNorm=${this.lastAvgNorm.toFixed(4)}`); }
    if (this.persistEnabled){ this.persistBuffer.push({ t:Date.now(), n:+norm.toFixed(6), h:dataHash.slice(0,16) }); if (this.persistBuffer.length >= this.persistBatch) this.flush(); }
    const phase = parseInt(hash.slice(0,8),16) / 0xFFFFFFFF; // 0..1
    const resonance = Math.cos(phase * Math.PI*2);
    return nodeFreq + (norm%1) * resonance * 0.5; // bounded adjustment
  }
  flush(){ if (!this.persistEnabled || !this.persistBuffer.length) return; try { fs.appendFileSync(this.persistPath, this.persistBuffer.map(r=> JSON.stringify(r)).join('\n')+'\n'); this.persistBuffer=[]; } catch(_){} }
}

module.exports = PicoCrystalTuner;
