// fused_wasm.js - high-level JS wrapper for sha256_fused.wasm
// Provides: initFused(), doubleSha256Header(headerBuf80), doubleSha256Batch(headersArray)
// All hashing fully inside WASM (no midstate handoff). Returns Buffer digests (32 bytes) big-endian words.

const fs = require('fs');
const path = require('path');
let wasm=null, ready=false, disabled=false; let stats={ calls:0, batches:0, totalHeaders:0, ns:0, selfTest:{ ran:false, mismatches:0, cases:0 } };

async function initFused(){
  if (ready || disabled) return;
  try {
    const p = path.join(__dirname,'sha256_fused.wasm');
    if (!fs.existsSync(p)) throw new Error('sha256_fused.wasm missing');
    const bytes = fs.readFileSync(p);
    const mod = await WebAssembly.instantiate(bytes, {});
    wasm = mod.instance.exports;
    if (!wasm || !wasm.memory || !wasm.double_sha256_header) throw new Error('Invalid exports');
    ready = true;
  } catch(e){ disabled=true; throw e; }
}

function ensureReady(){ if (!ready) throw new Error('fused wasm not initialized'); }

function doubleSha256Header(headerBuf){
  ensureReady();
  if (headerBuf.length !== 80) throw new Error('Need 80-byte header');
  const mem = new Uint8Array(wasm.memory.buffer);
  const ptrIn = wasm.malloc(80);
  const ptrOut = wasm.malloc(32);
  mem.set(headerBuf, ptrIn);
  wasm.double_sha256_header(ptrIn, ptrOut);
  const out = Buffer.from(mem.slice(ptrOut, ptrOut+32));
  wasm.free(ptrIn); wasm.free(ptrOut);
  stats.calls++; stats.totalHeaders++; return out;
}

function doubleSha256Batch(headers){
  ensureReady();
  if (!Array.isArray(headers) || !headers.length) return [];
  const count = headers.length;
  const mem = new Uint8Array(wasm.memory.buffer);
  const ptrIn = wasm.malloc(count*80);
  const ptrOut = wasm.malloc(count*32);
  for (let i=0;i<count;i++){
    const h = headers[i]; if (h.length !== 80) throw new Error('header len');
    mem.set(h, ptrIn + i*80);
  }
  const t0 = process.hrtime.bigint();
  wasm.double_sha256_batch(ptrIn, count, ptrOut);
  const t1 = process.hrtime.bigint();
  const outArr = new Array(count);
  for (let i=0;i<count;i++) outArr[i] = Buffer.from(mem.slice(ptrOut + i*32, ptrOut + (i+1)*32));
  wasm.free(ptrIn); wasm.free(ptrOut);
  stats.batches++; stats.totalHeaders += count; stats.ns += Number(t1 - t0); stats.calls += count;
  return outArr;
}

// Lightweight parity self-test (default 8 cases) comparing to Node crypto double SHA256
async function selfTest(cases=8){
  if (disabled) return { ok:false, reason:'disabled previously' };
  await initFused();
  if (stats.selfTest.ran) return { ok: stats.selfTest.mismatches===0, mismatches: stats.selfTest.mismatches, cases: stats.selfTest.cases };
  const crypto = require('crypto');
  const refDouble = (buf)=>{ const h1=crypto.createHash('sha256').update(buf).digest(); return crypto.createHash('sha256').update(h1).digest(); };
  let mismatches=0;
  for (let i=0;i<cases;i++){
    const hdr = crypto.randomBytes(80);
    const wasmOut = doubleSha256Header(hdr);
    const ref = refDouble(hdr);
    if (!wasmOut.equals(ref)){
      mismatches++; if (mismatches===1) console.error('[fused-wasm] Parity mismatch example idx='+i+' wasm='+wasmOut.toString('hex')+' ref='+ref.toString('hex'));
      if (mismatches > 2) break; // early stop
    }
  }
  stats.selfTest = { ran:true, mismatches, cases };
  if (mismatches){
    console.error(`[fused-wasm] Self-test failed (${mismatches}/${cases}). Disabling fused path.`);
    disabled = true; ready=false; wasm=null;
  }
  return { ok: mismatches===0, mismatches, cases };
}

module.exports = { initFused, selfTest, doubleSha256Header, doubleSha256Batch, _stats: stats };
