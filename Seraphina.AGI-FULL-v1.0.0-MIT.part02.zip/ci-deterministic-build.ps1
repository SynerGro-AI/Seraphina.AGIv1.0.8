<#
ci-deterministic-build.ps1

Pipeline sequence:
 1. System reproducibility verification (system-repro-verify.js)
 2. Final multi-coin mining test (final-mining-test.js)
 3. ISO build + manifest + reproducibility summary (build-production-iso.ps1)
 4. Optional GPG signing (if -SignManifest and gpg present)

Exit codes:
 0 success, non-zero failure at respective stage.

Parameters:
  -StageDir        staging directory for ISO build (default ./iso_stage)
  -IsoName         output ISO file name
  -SkipISO         skip ISO creation (just verify + test)
  -SignManifest    sign manifest during ISO build
  -GpgKeyId        key id/email for gpg
  -PromPort        expose metrics during final test (sets EXPORT_PROM=1)
  -Coins           override test coins list (e.g. BTC,RVN)
  -CycleLimit      override AUR_REPRO_CYCLE_LIMIT (default 6)
  -WalletValidate  enable wallet validation pre-flight (VALIDATE_WALLETS=1)

Example:
  powershell -File ./ci-deterministic-build.ps1 -IsoName Aurrelia.iso -SignManifest -GpgKeyId dev@aur -PromPort 9310 -Coins BTC,RVN -CycleLimit 5 -WalletValidate
#>
param(
  [string]$StageDir = './iso_stage',
  [string]$IsoName = 'Aurrelia-Deterministic.iso',
  [switch]$SkipISO,
  [switch]$SignManifest,
  [string]$GpgKeyId,
  [int]$PromPort = 0,
  [string]$Coins,
  [int]$CycleLimit = 6,
  [switch]$WalletValidate
)

$ErrorActionPreference='Stop'
Write-Host "[CI] Starting deterministic build pipeline"

# 1. System reproducibility verify
if(-not (Test-Path './system-repro-verify.js')){ Write-Error 'system-repro-verify.js missing'; exit 2 }
$env:SERAPHINA_STRICT_DETERMINISM='1'
if(-not $env:SERAPHINA_SEED){ $env:SERAPHINA_SEED='ci-seed' }
$env:AUR_REPRO_CYCLE_LIMIT=$CycleLimit
node ./system-repro-verify.js | Tee-Object -Variable reproOut
if($LASTEXITCODE -ne 0){ Write-Error "[CI] system-repro-verify failed"; exit 3 }

# 2. Final mining test
if(-not (Test-Path './final-mining-test.js')){ Write-Error 'final-mining-test.js missing'; exit 4 }
if($Coins){ $env:TEST_COINS=$Coins }
$env:AUR_REPRO_CYCLE_LIMIT=$CycleLimit
if($PromPort -gt 0){ $env:EXPORT_PROM='1'; $env:PROM_PORT=[string]$PromPort }
if($WalletValidate){ $env:VALIDATE_WALLETS='1' }
node ./final-mining-test.js | Tee-Object -Variable finalOut
if($LASTEXITCODE -ne 0){ Write-Error "[CI] final-mining-test failed"; exit 5 }

# 2b. SBOM generation (before ISO packaging) if script present
if(Test-Path './sbom-generate.js'){
  Write-Host '[CI] Generating SBOM'
  node ./sbom-generate.js | Tee-Object -Variable sbomOut
  if($LASTEXITCODE -ne 0){ Write-Warning '[CI] SBOM generation returned non-zero' }
}

# 2c. Pool latency snapshot (informational) if script present
if(Test-Path './pool-latency-snapshot.js'){
  Write-Host '[CI] Capturing pool latency snapshot'
  node ./pool-latency-snapshot.js | Tee-Object -Variable latencyOut
  if($LASTEXITCODE -ne 0){ Write-Warning '[CI] latency snapshot returned non-zero' }
}

# 2d. Ledger chain verification (fail on any broken chain)
if(Test-Path './ledger-chain-verify.js'){
  Write-Host '[CI] Verifying ledger chains'
  node ./ledger-chain-verify.js | Tee-Object -Variable ledgerVerifyOut
  if($LASTEXITCODE -ne 0){ Write-Error '[CI] ledger-chain-verify failed (integrity issues)'; exit 6 }
}

# 2e. Optional deterministic ML training before ISO build
if($env:ML_TRAIN_BEFORE_BUILD -eq '1'){
  if(Test-Path './ml-train-deterministic.js'){
    Write-Host '[CI] Running deterministic ML training phase'
    node ./ml-train-deterministic.js | Tee-Object -Variable trainOut
    if($LASTEXITCODE -ne 0){ Write-Warning '[CI] ML training script returned non-zero' }
    # Improvement gate: if GLOBAL_MIN_IMPROVEMENT defined, enforce acceptance
    if(Test-Path './ml-train-scoreboard.json'){
      try {
        $scoreboard = Get-Content './ml-train-scoreboard.json' | Out-String | ConvertFrom-Json
        $improv = [double]$scoreboard.improvementPct
        $accepted = $scoreboard.improvementAccepted
        $minReq = [double]($env:GLOBAL_MIN_IMPROVEMENT)
        if($env:GLOBAL_MIN_IMPROVEMENT){
          if(-not $accepted -or $improv -lt $minReq){
            Write-Error "[CI] Improvement gate failed: improvementPct=$improv minRequired=$minReq accepted=$accepted"
            exit 8
          } else { Write-Host "[CI] Improvement gate passed: $improv >= $minReq" }
        }
      } catch { Write-Warning '[CI] Unable to parse ml-train-scoreboard.json for improvement gate' }
    }
  } else {
    Write-Warning '[CI] ML training requested but ml-train-deterministic.js missing'
  }
}

# Parse metaDigest from final test
$metaDigest=$null
try {
  $jsonLine = ($finalOut -split "`n")[-1]
  $parsed = $jsonLine | ConvertFrom-Json
  $metaDigest = $parsed.metaDigest
} catch {}

# 3. ISO build (optional)
if(-not $SkipISO){
  if(-not (Test-Path './build-production-iso.ps1')){ Write-Error 'build-production-iso.ps1 missing'; exit 6 }
  $isoArgs = @('-StageDir', $StageDir, '-IsoName', $IsoName, '-SummarySourceScript','system-repro-test.js')
  if($SignManifest){ $isoArgs += '-SignManifest'; if($GpgKeyId){ $isoArgs += @('-GpgKeyId',$GpgKeyId) } }
  Write-Host "[CI] Running ISO build script"
  powershell -ExecutionPolicy Bypass -File ./build-production-iso.ps1 @isoArgs
  if($LASTEXITCODE -ne 0){ Write-Error '[CI] ISO build failed'; exit 7 }
}

Write-Host "[CI] Pipeline complete metaDigest=$metaDigest"
exit 0
