"use strict";
// kraken-advanced-exec.js
// Advanced order execution scaffolding: maker bias, fee tier modeling, batch sizing.
// Integrates with existing wallet-portfolio (assumes functions getHoldings(), submitSwap(order)).
// No live trading until KRAKEN_TRADING_ENABLED=1 and minimal safety conditions pass.

const crypto = require('crypto');
const fetch = require('node:https').request; // placeholder; replace with proper HTTPS client if needed

function hmac(secret, message){ return crypto.createHmac('sha512', Buffer.from(secret,'utf8')).update(message).digest('base64'); }

class KrakenAdvancedExec {
  constructor(cfg){
    this.apiKey = process.env.KRAKEN_API_KEY || cfg.apiKey;
    this.apiSecret = process.env.KRAKEN_API_SECRET || cfg.apiSecret;
    this.enabled = process.env.KRAKEN_TRADING_ENABLED === '1';
    this.minNotional = parseFloat(process.env.KRAKEN_MIN_NOTIONAL || '10'); // USD equivalent
    this.makerBias = parseFloat(process.env.KRAKEN_MAKER_BIAS || '0.001'); // place limit better by 0.1%
    this.tierFeeMaker = parseFloat(process.env.KRAKEN_FEE_MAKER || '0.0016');
    this.tierFeeTaker = parseFloat(process.env.KRAKEN_FEE_TAKER || '0.0026');
    this.requoteSecs = parseInt(process.env.KRAKEN_REQUOTE_SECS || '45',10);
    this.priceStaleSecs = parseInt(process.env.KRAKEN_PRICE_STALE_SECS || '30',10);
    this.pending = new Map(); // clientOrderId -> { ts, pair, side, vol, price }
  }
  assessFeeImpact(side, vol, price){
    const notional = vol * price; const maker = notional * this.tierFeeMaker; const taker = notional * this.tierFeeTaker;
    return { notional, maker, taker, edge: taker - maker };
  }
  buildLimitPrice(bestBid, bestAsk, side){
    if (side === 'sell') return bestAsk * (1 + this.makerBias); // slightly above ask to rest
    else return bestBid * (1 - this.makerBias); // slightly below bid to rest
  }
  maybePlace(orderCtx){
    if (!this.enabled){ return { skipped:true, reason:'disabled' }; }
    if (!this.apiKey || !this.apiSecret) return { skipped:true, reason:'no_api_keys' };
    const { pair, side, vol, bestBid, bestAsk, mid, ts } = orderCtx;
    if (!bestBid || !bestAsk) return { skipped:true, reason:'no_book' };
    const price = this.buildLimitPrice(bestBid, bestAsk, side);
    const fee = this.assessFeeImpact(side, vol, price);
    if (fee.notional < this.minNotional) return { skipped:true, reason:'below_min_notional' };
  const { deriveHex } = require('./deterministic-util');
  const clientOrderId = 'AUR'+deriveHex('client-order', Date.now(), side, symbol).slice(0,10);
    const payload = { pair, type: side, ordertype:'limit', price: price.toFixed(8), volume: vol.toFixed(8), oflags:'post' };
    this.pending.set(clientOrderId, { ts: Date.now(), pair, side, vol, price, fee });
    // TODO: perform authenticated REST POST to Kraken /0/private/AddOrder
    // For now we just return simulated struct
    return { submitted:true, clientOrderId, payload, fee };
  }
  cullExpired(){
    const now = Date.now();
    for (const [id, o] of this.pending){ if (now - o.ts > this.requoteSecs*1000){ this.pending.delete(id); } }
  }
}

module.exports = { KrakenAdvancedExec };
