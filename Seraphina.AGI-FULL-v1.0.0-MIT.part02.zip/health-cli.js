#!/usr/bin/env node
'use strict';
// health-cli.js : Pretty-print current Seraphina health and last N alerts.
const fs = require('fs');
const path = require('path');

const HEALTH_FILE = path.join(process.cwd(),'seraphina-health.json');
const ALERT_LEDGER = process.env.SERAPHINA_EMA_MEDIAN_ALERT_LEDGER || 'seraphina-ema-median-alert-ledger.jsonl';

function readHealth(){
  try { return JSON.parse(fs.readFileSync(HEALTH_FILE,'utf8')); } catch { return null; }
}
function readAlerts(limit=10){
  if(!fs.existsSync(ALERT_LEDGER)) return [];
  try {
    const lines = fs.readFileSync(ALERT_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
    return lines.slice(-limit).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean);
  } catch { return []; }
}

function fmtPct(v){ return (v*100).toFixed(2)+'%'; }

function main(){
  const healthWrap = readHealth();
  if(!healthWrap){ console.error('No health snapshot found at', HEALTH_FILE); process.exit(1); }
  const h = healthWrap.health || {};
  const status = h.status || 'unknown';
  const noise = h.noise || {};
  const lastAlert = h.lastAlert || null;
  console.log('Seraphina Health Snapshot');
  console.log('==========================');
  console.log('Status        :', status);
  console.log('Label Flip Pct:', (noise.labelFlipPct!=null? (noise.labelFlipPct*100).toFixed(2)+'%':'N/A'));
  console.log('Latest Delta  :', noise.emaVsMedianDeltaLatest);
  console.log('Rolling Avg   :', noise.emaVsMedianDeltaRollingAvg);
  if(h.histogram){
    console.log('Histogram p50 :', h.histogram.p50);
    console.log('Histogram p90 :', h.histogram.p90);
  }
  if(lastAlert){
    console.log('Last Alert    :', lastAlert.type, 'severity='+lastAlert.severity, 'delta='+lastAlert.emaVsMedianDelta, 'rolling='+lastAlert.rollingEmaVsMedianAvg, 'thr='+lastAlert.threshold);
  } else {
    console.log('Last Alert    : none');
  }
  const alerts = readAlerts();
  if(alerts.length){
    console.log('\nRecent Alerts');
    console.log('-------------');
    let sevCounts = { info:0, warning:0, critical:0 };
    for(const a of alerts){
      if(a.severity && sevCounts[a.severity]!=null){ sevCounts[a.severity]++; }
      console.log(new Date(a.ts).toISOString(), a.type, 'severity='+a.severity, 'delta='+a.emaVsMedianDelta, 'roll='+a.rollingEmaVsMedianAvg, 'thr='+a.threshold);
    }
    console.log('\nSeverity Counts:', Object.entries(sevCounts).map(([k,v])=>k+':'+v).join(', '));
  } else {
    console.log('\nRecent Alerts: none');
  }
}

if(require.main===module){ main(); }
