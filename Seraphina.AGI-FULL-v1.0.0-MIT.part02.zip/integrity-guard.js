"use strict";
// integrity-guard.js – manifest & config HMAC validation + enforcement
// Exports: runIntegrityChecks(options)
// options: { strictEnv:boolean }

const fs = require('fs');
const crypto = require('crypto');

function runIntegrityChecks(opts={}){
  const strict = opts.strictEnv || process.env.STRICT_INTEGRITY === '1' || process.argv.includes('--strict-integrity');
  let manifestHash=null, manifestHmac=null, configHash=null, configHmac=null;
  try {
    if (fs.existsSync('deterministic-config.js')){
      const mod = require('./deterministic-config.js');
      configHash = mod.CONFIG_HASH;
      if (process.env.CONFIG_HMAC_KEY && configHash){ configHmac = crypto.createHmac('sha256', process.env.CONFIG_HMAC_KEY).update(configHash).digest('hex'); }
    }
  } catch(_){ }
  try {
    if (fs.existsSync('source-manifest.json')){
      const m = JSON.parse(fs.readFileSync('source-manifest.json','utf8'));
      manifestHash = m.aggregateHash || crypto.createHash('sha256').update(JSON.stringify(m)).digest('hex');
      if (fs.existsSync('source-manifest.hmac.json')){
        const sig = JSON.parse(fs.readFileSync('source-manifest.hmac.json','utf8'));
        manifestHmac = sig.hmac || null;
        if (process.env.MANIFEST_HMAC_KEY && manifestHash){
          const recomputed = crypto.createHmac('sha256', process.env.MANIFEST_HMAC_KEY).update(manifestHash).digest('hex');
          if (recomputed !== manifestHmac){ console.warn('[Integrity] Manifest HMAC mismatch'); if (strict) throw new Error('manifest hmac mismatch'); }
        }
      }
    }
  } catch(e){ if (strict) throw e; }
  if (strict){
    if (!manifestHash) throw new Error('missing manifest hash');
    if (process.env.MANIFEST_HMAC_KEY && !manifestHmac) throw new Error('missing manifest hmac');
    if (process.env.CONFIG_HMAC_KEY && !configHmac) throw new Error('missing config hmac');
  }
  console.log(`[Integrity] manifestHash=${manifestHash||'na'} configHash=${configHash||'na'}` + (strict?' strict':' soft'));
  return { manifestHash, manifestHmac, configHash, configHmac };
}

module.exports = { runIntegrityChecks };
