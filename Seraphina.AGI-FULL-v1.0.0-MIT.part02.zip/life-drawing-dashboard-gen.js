// life-drawing-dashboard-gen.js
// Generate static HTML dashboard with coverage, trends, retention, sparklines.
// Environment Variables:
//   LIFE_DRAWING_DASHBOARD_THEME -> 'light' | 'dark' (default 'light') selects base color palette.
// Dependencies: coverage report, trend report, retention computation modules.
// CLI Args:
//   out=filename.html  -> custom output file (default life-drawing-dashboard.html)
//   theme=dark|light    -> override theme for single invocation (takes precedence over env var)
// Validation:
//   Minimal check ensures coverage, trends, retention objects exist; prints warning banner if missing.
// Output:
//   Static HTML file with tables + unicode sparklines for score/completeness.
'use strict';
const fs = require('fs');
const path = require('path');
const { generateReport } = require('./life-drawing-coverage-report');
const { computeTrends } = require('./life-drawing-trend-report');
const { computeRetention } = require('./life-drawing-retention');
const { computeTrend: computeAuditTrend } = require('./life-drawing-audit-trend');

function esc(x){ return String(x).replace(/[&<>]/g, c=> ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }

function buildTable(headers, rows){
  return `<table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>`+
    rows.map(r=> `<tr>${r.map(c=> `<td>${esc(c)}</td>`).join('')}</tr>`).join('') + '</tbody></table>';
}

function validate(source){
  // Minimal structural validation
  if(!source.coverage || !source.trends || !source.retention) return false;
  return true;
}

function sparkline(nums){
  if(!Array.isArray(nums) || !nums.length) return '';
  const blocks = ['▁','▂','▃','▄','▅','▆','▇','█'];
  const min = Math.min(...nums); const max = Math.max(...nums);
  const range = max-min || 1;
  return nums.map(v=> blocks[Math.min(blocks.length-1, Math.floor(((v-min)/range)*(blocks.length-1)))]).join('');
}

function generateHTML(opts={}){
  const coverage = generateReport();
  const trends = computeTrends();
  const retention = computeRetention();
  const auditTrend = computeAuditTrend();
  const theme = opts.theme || process.env.LIFE_DRAWING_DASHBOARD_THEME || 'light';
  const dark = theme === 'dark';
  const coverageRows = coverage.ok ? coverage.fields.map(f=> [f.field, f.count, (f.pct).toFixed(4), f.weaknessPercentile.toFixed(4)]) : [];
  const trendImproving = trends.ok ? trends.improvingFields.map(f=> [f.field, f.first, f.second, f.delta]) : [];
  const trendDeclining = trends.ok ? trends.decliningFields.map(f=> [f.field, f.first, f.second, f.delta]) : [];
  const retentionRows = retention.ok ? retention.fields.map(f=> [f.field, f.retention.toFixed(4)]) : [];
  const scoreSpark = trends.scoreSpark || ''; const compSpark = trends.completenessSpark || '';
  const recommended = coverage.recommended ? coverage.recommended.join(', ') : '';
  const source = { coverage, trends, retention, auditTrend };
  const valid = validate(source);
  const baseCss = `body{font-family:Arial,sans-serif;margin:20px;}${dark? 'body{background:#121212;color:#eee;} a{color:#8ab4f8;} table{color:#eee;} th{background:#1e1e1e;} td{background:#1a1a1a;}':'body{background:#fff;color:#222;}'}h1{margin-top:0}table{border-collapse:collapse;margin:12px 0}th,td{border:1px solid #ccc;padding:4px 8px;font-size:13px}th{background:${dark?'#1e1e1e':'#f5f5f5'};}code{background:${dark?'#272727':'#eee'};padding:2px 4px;border-radius:3px} .spark{font-size:20px;letter-spacing:2px} .section{margin-bottom:28px}`;
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"/><title>Life Drawing Dashboard</title>
  <style>${baseCss}</style></head><body>
  <h1>Life Drawing Analytics</h1>
  ${valid? '':'<p style="color:red">[Schema validation failed: missing sections]</p>'}
  <div class="section"><h2>Coverage</h2>${coverage.ok? buildTable(['Field','Count','Pct Sessions','Weakness %tile'], coverageRows):'<p>No coverage data.</p>'}
  <p><strong>Recommended Focus:</strong> ${esc(recommended)}</p></div>
  <div class="section"><h2>Trends</h2>${trends.ok? `<p>Sessions: ${trends.totalSessions} Window: ${trends.windowSize} ScoreSlope: ${trends.scoreSlope} CompletenessSlope: ${trends.completenessSlope}</p><p class='spark'>Score ${esc(scoreSpark)}</p><p class='spark'>Completeness ${esc(compSpark)}</p>`:'<p>No trend data.</p>'}
  <h3>Improving Fields</h3>${trendImproving.length? buildTable(['Field','First Half','Second Half','Delta'], trendImproving):'<p>None.</p>'}
  <h3>Declining Fields</h3>${trendDeclining.length? buildTable(['Field','First Half','Second Half','Delta'], trendDeclining):'<p>None.</p>'}</div>
  <div class="section"><h2>Retention</h2>${retention.ok? buildTable(['Field','Retention'], retentionRows):'<p>No retention data.</p>'}</div>
  <div class="section"><h2>Audit Vulnerability Trend</h2>${auditTrend.ok? buildTable(['Severity','Latest','Slope','Rolling Avg Spark'], auditTrend.severities.map(s=> [s.severity, s.latest, s.slope, sparkline(s.rollingAvg)])):'<p>No audit trend data.</p>'}
  ${auditTrend.ok? `<p><small>Entries: ${auditTrend.count} | Window Size: ${auditTrend.windowSize}</small></p>`:''}</div>
  <footer><small>Generated ${new Date().toISOString()} | Half-life: ${retention.halfLife || ''}</small></footer>
  </body></html>`;
  return html;
}

function writeDashboard(outName='life-drawing-dashboard.html', opts={}){
  const html = generateHTML(opts);
  const outPath = path.join(__dirname, outName);
  fs.writeFileSync(outPath, html, 'utf8');
  return outPath;
}

if(require.main === module){
  const outArg = process.argv.find(a=> a.startsWith('out='));
  const themeArg = process.argv.find(a=> a.startsWith('theme='));
  const outName = outArg? outArg.split('=')[1] : 'life-drawing-dashboard.html';
  const theme = themeArg? themeArg.split('=')[1] : undefined;
  const out = writeDashboard(outName, { theme });
  console.log(JSON.stringify({ ok:true, file: out, theme: theme||'light' }, null, 2));
}

module.exports = { writeDashboard, generateHTML };
