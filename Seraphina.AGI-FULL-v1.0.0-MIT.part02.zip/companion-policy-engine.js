// companion-policy-engine.js
// Deterministic policy engine for wallet companion suggestions.
// Scope: validate advisory entries against static allowlist and bounds before any operational effect.
// Jurisdictional Compliance: Operates under assumption of adherence to all applicable Alberta, Canada laws and regulations.
// This engine NEVER executes external code; only evaluates structured suggestions originating from deterministic companion module.
// If suggestion set violates any rule, a noop decision is returned.

'use strict';

const crypto = require('crypto');

// Allowlisted action types (extend cautiously)
const ALLOW_ACTIONS = new Set(['adjust_bias']);

// Maximum absolute bias delta permitted per evaluation (normalized units)
const MAX_ABS_DELTA = 0.10; // 10% normalized bias change cap

// Cooldown (ms) between accepted bias adjustments to prevent rapid oscillation
const BIAS_ADJ_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

// Chain state in-memory (not persisted here; ledger already records suggestions)
let lastBiasAdjTs = 0;
let lastBiasDigest = null;

function stableHash(obj){
  return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex');
}

// Validate numeric delta
function validateDelta(d){
  if (typeof d !== 'number' || !isFinite(d)) return false;
  if (Math.abs(d) > MAX_ABS_DELTA) return false;
  // Deterministic precision trim to avoid FP drift
  return Number(d.toFixed(8));
}

// Primary evaluation entrypoint
// inputs: suggestionDigest (hex), suggestions [{id,type,conf}], context { recommend }
// returns: { decision:{ action:'noop'|'apply_bias', coin, delta }, hash, reason }
function evaluateSuggestions(suggestionDigest, suggestions, context){
  try {
    const now = Date.now();
    if (!Array.isArray(suggestions) || !suggestions.length){
      return wrapDecision({ action:'noop' }, 'empty');
    }
    // Filter to bias-type suggestions
    const biasCandidates = suggestions.filter(s=> ALLOW_ACTIONS.has(s.type));
    if (!biasCandidates.length){
      return wrapDecision({ action:'noop' }, 'no-allowlisted');
    }
    // Deterministic best candidate: highest confidence; tie by hash of id
    const sorted = biasCandidates.slice().sort((a,b)=>{
      if (b.confidence === a.confidence){
        const ha = parseInt(stableHash(a.id).slice(0,8),16);
        const hb = parseInt(stableHash(b.id).slice(0,8),16);
        return ha - hb;
      }
      return b.confidence - a.confidence;
    });
    const top = sorted[0];
    // Expected fields: top.delta (proposed bias adjustment) OR top.biasDelta
    const rawDelta = (typeof top.delta === 'number') ? top.delta : (typeof top.biasDelta === 'number' ? top.biasDelta : 0);
    const delta = validateDelta(rawDelta);
    if (delta === false){
      return wrapDecision({ action:'noop' }, 'delta-out-of-bounds');
    }
    if (now - lastBiasAdjTs < BIAS_ADJ_COOLDOWN_MS){
      return wrapDecision({ action:'noop' }, 'cooldown-active');
    }
    // Bind coin to current recommendation for deterministic selection
    const coin = (context && context.recommend) ? context.recommend : null;
    if (!coin){
      return wrapDecision({ action:'noop' }, 'no-recommendation');
    }
    const decision = { action:'apply_bias', coin, delta };
    const hash = stableHash({ suggestionDigest, decision, prev:lastBiasDigest || 'GENESIS' });
    lastBiasDigest = hash; lastBiasAdjTs = now;
    return { decision, hash, reason:'accepted' };
  } catch(e){
    return wrapDecision({ action:'noop' }, 'exception:'+e.message.slice(0,60));
  }
}

function wrapDecision(decision, reason){
  const hash = stableHash({ decision, reason, ts: Date.now(), prev:lastBiasDigest || 'GENESIS' });
  return { decision, hash, reason };
}

module.exports = { evaluateSuggestions };
