// life-drawing-session.js
// Timed life drawing session scoring (deterministic structure).
// Environment Variables:
//   LIFE_DRAWING_FOCUS_EMPHASIS      -> base multiplier applied to weights for weak focus fields (default 1.25)
//   LIFE_DRAWING_FOCUS_ADAPT_FACTOR  -> scales additional boost by weaknessPercentile (default 0.5)
//       EffectiveWeight = baseWeight * (FOCUS_EMPHASIS + weaknessPercentile * FOCUS_ADAPT_FACTOR)
//   LIFE_DRAWING_STAGE_DECAY_START   -> session count after which staging time factor starts decaying (default 10)
//   LIFE_DRAWING_STAGE_DECAY_RATE    -> linear decay per session beyond start (default 0.02)
//   LIFE_DRAWING_STAGE_MIN_FACTOR    -> floor multiplier for staging time factor (default 0.5)
//   LIFE_DRAWING_COMPLETENESS_MIN    -> threshold to emit completeness warnings per question (default 0.5)
// Mechanics:
//   - Weak fields listed in exam.focus.weakFields get adaptive weight amplification.
//   - Staging reduces time advantage as practitioner accumulates sessions (anti-inflation).
'use strict';
const crypto = require('crypto');
const { loadAnatomyWeights } = require('./life-drawing-anatomy-weights');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function startSession(exam){
  if(!exam || !Array.isArray(exam.questions)) throw new Error('exam.questions required');
  return {
    id: sha256(exam.questions.map(q=>q.id).join('|')).slice(0,16),
    startedAt: Date.now(),
    responses: [],
    questionIds: exam.questions.map(q=> q.id)
  };
}

function recordResponse(session, { questionId, answers }){
  if(!session || !session.startedAt) throw new Error('invalid session');
  if(!session.questionIds.includes(questionId)) throw new Error('unknown questionId');
  const ts = Date.now();
  const elapsedMs = ts - session.startedAt;
  session.responses.push({ questionId, answers, ts, elapsedMs });
}

function finalizeSession(session, exam){
  const finishedAt = Date.now();
  const durationMs = finishedAt - session.startedAt;
  const weights = loadAnatomyWeights();
  const questionMap = new Map((exam?.questions||[]).map(q=> [q.id, q.expectedFields || []]));
  const completenessThreshold = parseFloat(process.env.LIFE_DRAWING_COMPLETENESS_MIN || '0.5');
  const warnings = [];
  const focusWeak = Array.isArray(exam?.focus?.weakFields) ? new Set(exam.focus.weakFields) : null;
  const baseFocusMultiplier = parseFloat(process.env.LIFE_DRAWING_FOCUS_EMPHASIS || '1.25');
  // Adaptive multiplier: base + (weaknessPercentile * adaptiveFactor)
  const adaptiveFactor = parseFloat(process.env.LIFE_DRAWING_FOCUS_ADAPT_FACTOR || '0.5');
  // Load coverage weakness percentiles if file exists
  let weaknessMap = null;
  if(focusWeak){
    try {
      const fs = require('fs');
      const path = require('path');
      const coveragePath = path.join(__dirname,'life-drawing-field-coverage.json');
      if(fs.existsSync(coveragePath)){
        const coverage = JSON.parse(fs.readFileSync(coveragePath,'utf8'));
        weaknessMap = {};
        const totalSessions = coverage.totalSessions||1;
        // Reconstruct weakness percentile similar to coverage-report logic
        const entries = Object.entries(coverage.fields||{}).map(([f,obj])=>({ field:f, count: obj.count||0 }));
        const asc = entries.slice().sort((a,b)=> a.count - b.count);
        asc.forEach((f,i)=>{ const p = asc.length>1 ? (i/(asc.length-1)) : 1; weaknessMap[f.field] = p; });
      }
    } catch(_){ }
  }
  // Difficulty staging: reduce timeFactor benefit over accumulated sessions
  let sessionCountPrior = 0;
  try {
    const fs = require('fs');
    const path = require('path');
    const ledgerPath = path.join(__dirname,'life-drawing-session-ledger.jsonl');
    if(fs.existsSync(ledgerPath)){
      const lines = fs.readFileSync(ledgerPath,'utf8').trim().split(/\n+/).filter(Boolean);
      sessionCountPrior = lines.length;
    }
  } catch(_){ }
  const stageDecayStart = parseInt(process.env.LIFE_DRAWING_STAGE_DECAY_START || '10',10);
  const stageDecayRate = parseFloat(process.env.LIFE_DRAWING_STAGE_DECAY_RATE || '0.02'); // per session beyond start
  const stageMinFactor = parseFloat(process.env.LIFE_DRAWING_STAGE_MIN_FACTOR || '0.5');
  const extraSessions = Math.max(0, sessionCountPrior - stageDecayStart);
  const stageMultiplier = Math.max(stageMinFactor, 1 - extraSessions * stageDecayRate);
  const perQuestion = session.responses.map(r => {
    const expected = questionMap.get(r.questionId) || [];
    const answersObj = Array.isArray(r.answers) ? (()=>{ const o={}; r.answers.forEach((a,i)=> o['field_'+i]=a); return o; })() : (r.answers||{});
    let weightedSum = 0, maxPossible = 0, filled = 0;
    for(const f of expected){
      let w = weights[f] || 0.5;
      if(focusWeak && focusWeak.has(f)){
        const wp = weaknessMap && weaknessMap[f] != null ? weaknessMap[f] : 0;
        w *= (baseFocusMultiplier + wp * adaptiveFactor);
      }
      maxPossible += w;
      if(answersObj[f]){ weightedSum += w; filled++; }
    }
    for(const extra of ['proportionCheck','negativeSpace']){
      if(answersObj[extra]){
        let w = weights[extra] || 0.4;
        if(focusWeak && focusWeak.has(extra)){
          const wp = weaknessMap && weaknessMap[extra] != null ? weaknessMap[extra] : 0;
          w *= (baseFocusMultiplier + wp * adaptiveFactor);
        }
        weightedSum += w; maxPossible += w;
      }
    }
    const completeness = maxPossible>0 ? (weightedSum / maxPossible) : 0;
    const timeAdj = (1 - Math.min(0.9, (r.elapsedMs / (durationMs||1)))) * stageMultiplier;
    const score = completeness * timeAdj * 10;
    const compFixed = Number(completeness.toFixed(4));
    if(compFixed < completenessThreshold){ warnings.push({ questionId: r.questionId, completeness: compFixed, threshold: completenessThreshold }); }
    return { questionId: r.questionId, score: Number(score.toFixed(4)), completeness: compFixed, expectedCount: expected.length, filledCount: filled, elapsedMs: r.elapsedMs };
  });
  const totalScore = perQuestion.reduce((a,b)=> a+b.score,0);
  const avgCompleteness = perQuestion.length ? perQuestion.reduce((a,b)=> a+b.completeness,0)/perQuestion.length : 0;
  const summary = { id: session.id, startedAt: session.startedAt, finishedAt, durationMs, totalScore: Number(totalScore.toFixed(4)), avgCompleteness: Number(avgCompleteness.toFixed(4)), perQuestion, warnings: warnings.length? warnings: null };
  // Ledger persistence (privacy: hash answers, no raw text stored)
  try {
    const fs = require('fs');
    const path = require('path');
    const ledgerPath = path.join(__dirname,'life-drawing-session-ledger.jsonl');
    const fieldSet = new Set();
    session.responses.forEach(r=>{
      const ansObj = Array.isArray(r.answers)? (()=>{ const o={}; r.answers.forEach((a,i)=>{ o['field_'+i]=a; }); return o; })() : (r.answers||{});
      Object.keys(ansObj).forEach(f=> fieldSet.add(f));
    });
    const fieldCoverageSnapshot = Array.from(fieldSet).sort();
    const hashedResponses = session.responses.map(r=> ({ q: r.questionId, elapsedMs: r.elapsedMs, answersHash: sha256(r.answers) }));
    const line = JSON.stringify({ ts: finishedAt, id: session.id, totalScore: summary.totalScore, avgCompleteness: summary.avgCompleteness, fieldCoverageSnapshot, responses: hashedResponses });
    fs.appendFileSync(ledgerPath, line+'\n');
    // Field coverage stats
    try {
      const coveragePath = path.join(__dirname,'life-drawing-field-coverage.json');
      let coverage = { totalSessions:0, fields:{} };
      if(fs.existsSync(coveragePath)){
        try { coverage = JSON.parse(fs.readFileSync(coveragePath,'utf8')); } catch(_){ }
      }
      coverage.totalSessions += 1;
      session.responses.forEach(r=>{
        const ansObj = Array.isArray(r.answers)? {} : r.answers||{};
        Object.keys(ansObj).forEach(f=>{
          if(!coverage.fields[f]) coverage.fields[f] = { count:0 };
          coverage.fields[f].count += 1;
        });
      });
      fs.writeFileSync(coveragePath, JSON.stringify(coverage,null,2));
    } catch(_){ }
  } catch(_){ }
  return summary;
}

module.exports = { startSession, recordResponse, finalizeSession };
