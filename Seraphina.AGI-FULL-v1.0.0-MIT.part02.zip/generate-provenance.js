#!/usr/bin/env node
// Generate combined provenance: Node version, Python build manifest (if present), miner manifest roots.
const fs = require('fs'); const crypto = require('crypto');
const prov = { ts: Date.now(), nodeVersion: process.version };
try { const pyMan = JSON.parse(fs.readFileSync('/opt/python/python-build-manifest.json','utf8')); prov.python = pyMan; } catch{}
try { const stdlib = JSON.parse(fs.readFileSync('/opt/python/python-stdlib-hashes.json','utf8')); prov.pythonStdlibHashRoot = crypto.createHash('sha256').update(Object.values(stdlib.files).sort().join('')).digest('hex'); prov.pythonStdlibCount = stdlib.count; } catch{}
try { const art = JSON.parse(fs.readFileSync('artifact-hashes.json','utf8')); prov.minerMerkleRoot = art.merkleRoot; prov.minerAuditRoot = art.auditMerkleRoot || null; } catch{}
try { const min = JSON.parse(fs.readFileSync('minimal-runtime-manifest.json','utf8')); prov.minimalMerkleRoot = min.merkleRoot; } catch{}
fs.writeFileSync('provenance.json', JSON.stringify(prov,null,2));
console.log(JSON.stringify(prov,null,2));
