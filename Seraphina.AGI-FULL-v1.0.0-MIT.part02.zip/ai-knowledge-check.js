// ai-knowledge-check.js
// Deterministic exam generator covering coding, accounting basics, virtues, moral gate.
'use strict';
const crypto = require('crypto');
const { VIRTUES } = require('./color-emotion-map');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

const QUESTION_BANK = [
  { id:'coding-encryption', topic:'coding', q:'What does the engine use for encryption per language?', answer:'Octabit frequency XOR' },
  { id:'coding-supported-count', topic:'coding', q:'Which method lists programming languages supported?', answer:'listSupportedCodes' },
  { id:'accounting-gst-net', topic:'accounting', q:'How is net GST payable determined?', answer:'Output GST minus input credits' },
  { id:'accounting-taxable-income', topic:'accounting', q:'What forms taxable income in exclusive GST computation?', answer:'Revenue excluding GST minus wages' },
  { id:'virtue-mapping', topic:'virtue', q:'What virtue corresponds to tier index 0?', answer: VIRTUES[0] },
  { id:'virtue-courage-index', topic:'virtue', q:'Which tier index maps to courage?', answer: String(VIRTUES.indexOf('courage')) },
  { id:'moral-gate-high', topic:'moral', q:'What risk level does the moral gate block outright?', answer:'HIGH' },
  { id:'moral-gate-function', topic:'moral', q:'Which function evaluates a batch of commands for moral gating?', answer:'validateCommands' },
  { id:'governance-bounds', topic:'governance', q:'What ensures parameters stay within allowed min/max values?', answer:'PARAM_BOUNDS' },
  { id:'pareto-epsilon-purpose', topic:'pareto', q:'Why is epsilon pruning used in the Pareto optimizer?', answer:'Reduce near-duplicate candidates' },
  { id:'dimension-escalation-trigger', topic:'dimension', q:'Name one metric factor that can trigger dimension escalation.', answer:'variance' },
  { id:'dimension-ramp-limit', topic:'dimension', q:'Which mechanism caps immediate jump size in dimension escalation?', answer:'rampStep' },
  { id:'autonomy-draft-condition', topic:'autonomy', q:'What condition can trigger autonomy weight increase proposal?', answer:'negative slope and avgEff below minRequired' }
  ,{ id:'regression-diff-purpose', topic:'regression', q:'What does regression diff compare?', answer:'current vs baseline effectiveImprovement' }
  ,{ id:'empowerment-stability-definition', topic:'empowerment', q:'How is empowerment stability derived?', answer:'1 minus coefficient of variation' }
];

function generateExam(){
  // Return full set (small) with digest; deterministic ordering.
  const ordered = QUESTION_BANK.slice().sort((a,b)=> a.id.localeCompare(b.id));
  return { questions: ordered.map(({id, q, topic})=> ({ id, q, topic })), digest: sha256(ordered.map(o=>o.id).join('|')) };
}

function evaluateAnswers(submissions){
  // submissions: [{id, answer}]
  const answerMap = new Map(QUESTION_BANK.map(q=> [q.id, q.answer]));
  let correct=0;
  const details = submissions.map(s=> {
    const expected = answerMap.get(s.id);
    const isCorrect = typeof expected==='string' && typeof s.answer==='string' && s.answer.trim().toLowerCase() === expected.trim().toLowerCase();
    if(isCorrect) correct++;
    return { id:s.id, provided:s.answer, expected, correct:isCorrect };
  });
  const scorePct = answerMap.size? (correct / answerMap.size) * 100 : 0;
  return { total: answerMap.size, correct, scorePct: Number(scorePct.toFixed(2)), details, submissionsDigest: sha256(submissions) };
}

if(require.main === module){
  const exam = generateExam();
  process.stdout.write(JSON.stringify(exam,null,2)+'\n');
}

module.exports = { generateExam, evaluateAnswers };
