// generate-source-manifest.js
// Scans selected source files, computes per-file sha256 and aggregate hash.
// Optional HMAC signing if MANIFEST_HMAC_KEY env is set.

const fs = require('fs');
const crypto = require('crypto');

const INCLUDE_GLOBS = [
  'aurrelia-pico-mesh-miner.js',
  'deterministic-config.js',
  'real-stratum-client.js',
  'coin-config.js'
];

function hashFile(path){
  try { const data = fs.readFileSync(path); return crypto.createHash('sha256').update(data).digest('hex'); } catch(e){ return null; }
}

function main(){
  const manifest = { generated: Date.now(), files: {} };
  for (const f of INCLUDE_GLOBS){
    const h = hashFile(f);
    if (h) manifest.files[f] = h; else manifest.files[f] = null;
  }
  // Aggregate hash: stable canonical JSON of files object only
  const canonical = JSON.stringify(Object.keys(manifest.files).sort().reduce((o,k)=>{ o[k]=manifest.files[k]; return o; },{}));
  manifest.aggregateHash = crypto.createHash('sha256').update(canonical).digest('hex');
  fs.writeFileSync('source-manifest.json', JSON.stringify(manifest,null,2));
  console.log('[Manifest] Wrote source-manifest.json aggregateHash=' + manifest.aggregateHash);
  if (process.env.MANIFEST_HMAC_KEY){
    const hmac = crypto.createHmac('sha256', process.env.MANIFEST_HMAC_KEY).update(manifest.aggregateHash).digest('hex');
    fs.writeFileSync('source-manifest.hmac.json', JSON.stringify({ hmac, aggregateHash: manifest.aggregateHash, t: Date.now() },null,2));
    console.log('[Manifest] Wrote source-manifest.hmac.json');
  }
}

if (require.main === module) main();
module.exports = { main };
