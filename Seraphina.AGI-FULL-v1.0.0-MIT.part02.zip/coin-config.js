// coin-config.js
// Central mapping for supported coins and pool/algo parameters.
// Focus remains on BTC (sha256d). Non-BTC entries are experimental placeholders.
function parsePoolEnv(envUrl, fallbackHost, fallbackPort){
  try {
    if (!envUrl) return { host: fallbackHost, port: fallbackPort };
    // Accept forms: 'stratum+tcp://host:port', 'host:port', or plain host
    let host = fallbackHost; let port = fallbackPort;
    let u = envUrl.trim();
    u = u.replace(/^stratum\+tcp:\/\//i,'').replace(/^stratum:\/\//i,'').replace(/^tcp:\/\//i,'');
    const m = u.match(/^\[?([^\]]+)\]?:(\d{2,5})$/) || u.match(/^([^:]+):(\d{2,5})$/);
    if (m){ host = m[1]; port = parseInt(m[2],10); }
    else if (/^\d+$/.test(u)) { port = parseInt(u,10); }
    else if (u) { host = u; }
    return { host, port };
  } catch(_) { return { host: fallbackHost, port: fallbackPort }; }
}

module.exports = {
  btc: {
    server: process.env.BTC_POOL_HOST || 'btc.f2pool.com',
    port: parseInt(process.env.BTC_POOL_PORT || '1314', 10),
    algo: 'sha256d',
    parity: true,
    experimental: false
  },
  btc_ckpool: {
    // Solo CKPool (no account registration; username = wallet address, password arbitrary)
    server: process.env.CKPOOL_HOST || 'solo.ckpool.org',
    port: parseInt(process.env.CKPOOL_PORT || '3333', 10),
    algo: 'sha256d',
    parity: true,
    experimental: false
  },
  btc_solomining: {
    // btc.solomining.io solo pool (username = BTC wallet address)
    server: process.env.BTC_SOLOMINING_HOST || 'btc.solomining.io',
    port: parseInt(process.env.BTC_SOLOMINING_PORT || '3333',10),
    algo: 'sha256d', parity: true, experimental: true
  },
  btc_vkbit: {
    // vkbit.com solo (username = BTC wallet)
    server: process.env.BTC_VKBIT_HOST || 'vkbit.com',
    port: parseInt(process.env.BTC_VKBIT_PORT || '3333',10),
    algo: 'sha256d', parity: true, experimental: true
  },
  btc_pyblock: {
    // pyblockpool.com solo
    server: process.env.BTC_PYBLOCK_HOST || 'pyblockpool.com',
    port: parseInt(process.env.BTC_PYBLOCK_PORT || '3333',10),
    algo: 'sha256d', parity: true, experimental: true
  },
  btc_kano: {
    // kano.is solo (stratum host kano.is:3333) - note missing colon protocol in description corrected here
    server: process.env.BTC_KANO_HOST || 'kano.is',
    port: parseInt(process.env.BTC_KANO_PORT || '3333',10),
    algo: 'sha256d', parity: true, experimental: true
  },
  btc_braiins_solo: {
    // Braiins Pool solo (username needs 'solo' + wallet address e.g. solo:WALLET)
    server: process.env.BTC_BRAIINS_HOST || 'stratum.braiins.com',
    port: parseInt(process.env.BTC_BRAIINS_PORT || '3333',10),
    algo: 'sha256d', parity: true, experimental: true,
    requiresSoloPrefix: true
  },
  ltc: {
    // Real scrypt hashing implemented via scryptsy in aurrelia-pico-mesh-miner.
    // Defaults align with F2Pool LTC (adjust host/port / region via env):
    server: process.env.LTC_POOL_HOST || 'ltc.f2pool.com',
    port: parseInt(process.env.LTC_POOL_PORT || '3335', 10),
    algo: 'scrypt',
    parity: false,
    experimental: false // now considered stable path once scryptsy installed
  },
  rvn: {
    // Ravencoin KawPow (experimental) – default to current F2Pool endpoint; allow RVN_POOL URL or host/port overrides
    // F2Pool current docs: raven.f2pool.com:3636 (also asia.raven.f2pool.com, us.raven.f2pool.com)
    ...(function(){
      const parsed = parsePoolEnv(process.env.RVN_POOL, process.env.RVN_POOL_HOST || 'raven.f2pool.com', parseInt(process.env.RVN_POOL_PORT || '3636',10));
      return { server: parsed.host, port: parsed.port };
    })(),
    algo: 'kawpow',
    parity: false,
    experimental: true,
    diff1bits: '1d00ffff'
  },
  kas: {
    // Kaspa kHeavyHash (experimental) – optional kheavyhash-js library; fallback deterministic doubleSha256
    server: process.env.KAS_POOL_HOST || 'kas.f2pool.com',
    port: parseInt(process.env.KAS_POOL_PORT || '8888',10),
    algo: 'kheavy',
    parity: false,
    experimental: true,
    diff1bits: '1d00ffff'
  }
  ,fren: {
    // Frencoin KawPow (experimental) – pool host assumptions; adjust env overrides if different
    server: process.env.FREN_POOL_HOST || 'fren.aikapool.com',
    port: parseInt(process.env.FREN_POOL_PORT || '3333',10),
    algo: 'kawpow',
    parity: false,
    experimental: true,
    diff1bits: '1d00ffff'
  }
};