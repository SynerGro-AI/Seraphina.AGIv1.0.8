#!/usr/bin/env node
// Produce HMAC seal for artifact-hashes.json using VAULT_PASS or KEY_FILE.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function loadKey(){
  if(process.env.VAULT_PASS) return process.env.VAULT_PASS.trim();
  if(process.env.KEY_FILE && fs.existsSync(process.env.KEY_FILE)){
    return fs.readFileSync(process.env.KEY_FILE,'utf8').trim();
  }
  throw new Error('No key source (VAULT_PASS or KEY_FILE) provided');
}

function main(){
  const manifestFile = path.join(__dirname,'artifact-hashes.json');
  if(!fs.existsSync(manifestFile)){
    console.error('[hmac-seal] artifact-hashes.json missing');
    process.exit(2);
    return;
  }
  const key = loadKey();
  const data = JSON.parse(fs.readFileSync(manifestFile,'utf8'));
  const h = crypto.createHmac('sha256', key).update(JSON.stringify(data)).digest('hex');
  data.hmacSeal = h;
  data.hmacTs = Date.now();
  fs.writeFileSync(manifestFile, JSON.stringify(data,null,2));
  console.log('[hmac-seal] sealed artifact-hashes.json with hmacSeal:', h.slice(0,32)+'...');
}

if(require.main === module){
  try { main(); } catch(e){ console.error('[hmac-seal] error:', e.message); process.exit(3); }
}
module.exports = { main };