"use strict";
// geometry-octo.js – minimal deterministic octonion / plane / hypercube helpers
// Exports: SimpleOcto, RomanDecoderWheel, buildPlaneSeeds(job, extranonce1, opts)

const crypto = require('crypto');

function hashToOctonion(dataStr, seed=0){
  let hash=0; for (let i=0;i<dataStr.length;i++){ const ch = dataStr.charCodeAt(i) ^ (seed & 0xFF); hash = ((hash<<5)-hash)+ch; hash|=0; }
  const coeffs=[]; for (let i=0;i<8;i++){ const chunk=(hash >>> (i*4)) & 0xFFFF; coeffs.push((chunk % 10000 / 5000 - 1)); }
  return coeffs;
}

class SimpleOcto {
  constructor(coeffs){ this.coeffs = coeffs.slice(0,8); }
  norm(){ return Math.sqrt(this.coeffs.reduce((s,c)=> s + c*c, 0)); }
  add(o){ return new SimpleOcto(this.coeffs.map((c,i)=> c + o.coeffs[i])); }
  multiply(o){
    const prod = new Array(8).fill(0);
    prod[0] = this.coeffs[0]*o.coeffs[0] - this.coeffs.slice(1).reduce((s,c,i)=> s + c*o.coeffs[i+1],0);
    for (let i=1;i<8;i++) prod[i] = this.coeffs[0]*o.coeffs[i] + o.coeffs[0]*this.coeffs[i];
    return new SimpleOcto(prod);
  }
  power(d=2){ return d===2? this.multiply(this): this; }
}

class RomanDecoderWheel {
  constructor(plane='xy', freq=432, hue=600){ this.plane=plane; this.freq=freq; this.hue=hue; this.theta=0; this.r = hue/1000; }
  decodeData(hex){ this.theta += 2*Math.PI*(this.freq/432)/8; const spiralR = this.r*(Math.cos(8*this.theta)+1.5)/2.5; const decoded=[]; for (let i=0;i<hex.length;i+=8){ const chunk=hex.slice(i,i+8); const oct = chunk.split('').reduce((a,c,j)=>{ a[j%8]+=parseInt(c,16); return a; }, Array(8).fill(0)); const n=new SimpleOcto(oct).norm()*spiralR; if (n<=2) decoded.push(chunk); } return decoded.join(''); }
}

function buildPlaneSeeds(job, extranonce1, opts={}){
  if (!job) return { planeSeeds:[], aggregate:null };
  const baseInput = (job.part1||job.coinb1||'') + (extranonce1||'') + (job.jobId||'');
  const seedHex = crypto.createHash('sha256').update(baseInput).digest('hex');
  const segs = [0,8,16,24].map(o=> parseInt(seedHex.slice(o,o+8),16));
  const mkWheel = (plane, idx)=> new RomanDecoderWheel(plane, 432 + ((segs[idx]%33)-16), 560 + (segs[idx]%120));
  const baseWheels = [ mkWheel('xy',0), mkWheel('xz',1), mkWheel('yz',2), mkWheel('w4d',3) ];
  let wheels = baseWheels;
  if (process.env.MULTI_PLANE_HYPER === '1'){
    // Derive 4 additional wheels from hash extensions (deterministic)
    for (let k=0;k<4;k++){
      const off = 32 + k*8;
      const seg = parseInt(seedHex.slice(off, off+8) || seedHex.slice(0,8),16);
      wheels.push(new RomanDecoderWheel('h'+k, 432 + ((seg%45)-22), 520 + (seg%140)));
    }
  }
  const planeInput = (job.part1||job.coinb1||'').slice(0,256).padEnd(256,'0');
  const decoded = wheels.map(w=> w.decodeData(planeInput));
  const planeSeeds = decoded.map(p=> (p && p.length? p: planeInput).slice(0,64).padEnd(64,'0'));
  // Aggregate seed using xor or avg depending on mode
  const mode = (process.env.PLANE_AGG_MODE === 'avg') ? 'avg' : 'xor';
  let aggregate;
  if (!planeSeeds.length) aggregate = planeInput.slice(0,64);
  else if (mode==='xor'){
    const nib = planeSeeds.map(s=> s.split(''));
    const out=[]; for (let i=0;i<64;i++){ let acc=0; for (const arr of nib) acc ^= parseInt(arr[i],16); out.push(acc.toString(16)); }
    aggregate = out.join('');
  } else {
    const nib = planeSeeds.map(s=> s.split(''));
    const out=[]; for (let i=0;i<64;i++){ let sum=0; for (const arr of nib) sum += parseInt(arr[i],16); out.push(Math.floor(sum/nib.length).toString(16)); }
    aggregate = out.join('');
  }
  return { planeSeeds, aggregate, wheels };
}

module.exports = { SimpleOcto, RomanDecoderWheel, buildPlaneSeeds };
