#!/usr/bin/env node
"use strict";
// duckdb-snapshot-loader.js
// Ingest wheel-metrics.jsonl (and optionally rule-stats-ring.jsonl) into a DuckDB file for ad‑hoc ML / analytics.
// Usage: node duckdb-snapshot-loader.js --db snapshots.duckdb --input wheel-metrics.jsonl --table wheel_snapshots
// Requires: duckdb (npm install duckdb) OR run with an existing dependency environment.
// Features:
//  * Creates table schema based on first JSON line keys (simple TEXT/FLOAT/INTEGER inference)
//  * Batch inserts for speed
//  * Optional secondary file ingest (e.g., rule-stats-ring)
//  * Provides a sample query set when run with --examples

const fs = require('fs');
const path = require('path');

let DuckDB; try { DuckDB = require('duckdb'); } catch(e){
  console.error('[DuckDB] Module not found. Install with: npm install duckdb');
  process.exit(1);
}

function parseArgs(){
  const args = process.argv.slice(2); const out={};
  for (let i=0;i<args.length;i++){
    if (args[i].startsWith('--')){ const k=args[i].replace(/^--/,''); const v=args[i+1] && !args[i+1].startsWith('--') ? args[++i] : true; out[k]=v; }
  }
  return out;
}

function inferType(value){
  if (value === null || value === undefined) return 'TEXT';
  if (typeof value === 'number'){
    if (Number.isInteger(value)) return 'BIGINT';
    return 'DOUBLE';
  }
  if (typeof value === 'string'){
    // Attempt number parse
    const asNum = +value; if (!isNaN(asNum)) return Number.isInteger(asNum)? 'BIGINT':'DOUBLE';
    return 'TEXT';
  }
  if (typeof value === 'boolean') return 'BOOLEAN';
  return 'TEXT';
}

function buildSchema(record){
  const schema = {}; Object.keys(record).forEach(k=>{ schema[k]=inferType(record[k]); });
  return schema;
}

function createTable(conn, table, schema){
  const cols = Object.entries(schema).map(([k,t])=> `"${k}" ${t}`).join(', ');
  conn.run(`CREATE TABLE IF NOT EXISTS ${table} (${cols});`);
}

function prepareInsert(conn, table, schema){
  const cols = Object.keys(schema); const placeholders = cols.map(()=> '?').join(',');
  return conn.prepare(`INSERT INTO ${table} (${cols.map(c=>`"${c}"`).join(',')}) VALUES (${placeholders});`);
}

function coerce(value, type){
  if (value === null || value === undefined) return null;
  if (type==='BIGINT'){ try { return parseInt(value); } catch(_){ return null; } }
  if (type==='DOUBLE'){ try { return parseFloat(value); } catch(_){ return null; } }
  if (type==='BOOLEAN'){ return !!value; }
  return value; // TEXT etc
}

async function ingestFile(conn, filePath, table){
  if (!fs.existsSync(filePath)){ console.warn(`[Ingest] File not found: ${filePath}`); return; }
  const lines = fs.readFileSync(filePath,'utf8').trim().split(/\n/).filter(Boolean);
  if (!lines.length){ console.warn('[Ingest] No lines to ingest'); return; }
  let firstObj=null;
  for (const ln of lines){ try { firstObj = JSON.parse(ln); break; } catch(_){ } }
  if (!firstObj){ console.warn('[Ingest] Could not parse any JSON lines'); return; }
  const schema = buildSchema(firstObj);
  createTable(conn, table, schema);
  const stmt = prepareInsert(conn, table, schema);
  const cols = Object.keys(schema);
  let inserted=0, failed=0;
  for (const ln of lines){
    try {
      const obj = JSON.parse(ln);
      const params = cols.map(c=> coerce(obj[c], schema[c]));
      stmt.run(params);
      inserted++;
    } catch(e){ failed++; }
  }
  stmt.finalize();
  console.log(`[Ingest] ${filePath}: inserted=${inserted} failed=${failed}`);
}

async function main(){
  const args = parseArgs();
  const dbFile = args.db || 'snapshots.duckdb';
  const primary = args.input || 'wheel-metrics.jsonl';
  const primaryTable = args.table || 'wheel_snapshots';
  const secondary = args.rule || 'rule-stats-ring.jsonl';
  const secondaryTable = args.ruleTable || 'rule_stats';
  const examples = !!args.examples;

  const db = new DuckDB.Database(dbFile);
  const conn = db.connect();
  await ingestFile(conn, path.resolve(primary), primaryTable);
  await ingestFile(conn, path.resolve(secondary), secondaryTable);

  if (examples){
    const queries = [
      `SELECT COUNT(*) AS rows, AVG(variance) AS avg_var FROM ${primaryTable};`,
      `SELECT mood, AVG(spin_stddev) AS avg_std FROM ${primaryTable} WHERE mood IS NOT NULL GROUP BY mood ORDER BY avg_std;`,
      `SELECT datetime(t/1000) AS ts, aggregate_wheel_spin FROM ${primaryTable} ORDER BY ts DESC LIMIT 10;`
    ];
    for (const q of queries){
      try { const res = conn.all(q); console.log('\n[Query]', q); console.table(res); } catch(e){ console.warn('[QueryError]', e.message); }
    }
  }
  conn.close();
}

main().catch(e=>{ console.error(e); process.exit(1); });
