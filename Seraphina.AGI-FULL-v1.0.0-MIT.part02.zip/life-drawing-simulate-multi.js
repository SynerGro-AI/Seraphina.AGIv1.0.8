// life-drawing-simulate-multi.js
// Run multiple sessions to build trend & coverage data.
'use strict';
const { generateFocusedExam } = require('./life-drawing-next-exam-recommend');
const { startSession, recordResponse, finalizeSession } = require('./life-drawing-session');

function randomAnswer(fields){
  const obj={};
  fields.forEach(f=>{ if(Math.random()<0.6) obj[f] = 'ok'; });
  if(Math.random()<0.5) obj.proportionCheck='ok';
  if(Math.random()<0.5) obj.negativeSpace='ok';
  return obj;
}

function runMany(count){
  const summaries=[];
  for(let i=0;i<count;i++){
    const exam = generateFocusedExam({ limit: 4 });
    const session = startSession(exam);
    exam.questions.forEach(q=>{
      const answers = randomAnswer(q.expectedFields||[]);
      recordResponse(session, { questionId: q.id, answers });
    });
    const summary = finalizeSession(session, exam);
    summaries.push(summary);
  }
  return summaries;
}

if(require.main === module){
  const count = process.argv.find(a=> a.startsWith('count=')) ? parseInt(process.argv.find(a=> a.startsWith('count=')).split('=')[1],10) : 5;
  const summaries = runMany(count);
  console.log(JSON.stringify({ ran: count, summaries }, null, 2));
}

module.exports = { runMany };