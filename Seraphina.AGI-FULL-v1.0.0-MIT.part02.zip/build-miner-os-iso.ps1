Param(
  [string]$WSLDistro = 'Ubuntu',
  [string]$Version = '1.0.0',
  [switch]$IncludeNode,
  [string]$NodeVersion = 'v20.11.1',
  [string]$IsoOutput = 'seraphina-miner-os.iso',
  [switch]$AutoUSB,
  [int]$UsbDiskNumber = -1,
  [switch]$Force,
  [string]$Arch = 'amd64'
)
$ErrorActionPreference = 'Stop'
Write-Host "[ISO] Starting one-click ISO build (Version $Version)" -ForegroundColor Cyan

function Require-WSL {
  if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) { throw 'WSL not installed. Install WSL: wsl --install' }
}
Require-WSL

# Verify distro presence
$distros = wsl.exe -l -q | ForEach-Object { $_.Trim() } | Where-Object { $_ }
if ($WSLDistro -notin $distros) {
  Write-Host "Installing WSL distro $WSLDistro (requires internet)" -ForegroundColor Yellow
  if ($WSLDistro -eq 'Ubuntu') { wsl.exe --install -d Ubuntu } else { throw "Distro $WSLDistro not found; install it manually." }
  Write-Host "Restart shell after WSL install if prompted." -ForegroundColor Yellow
}

$includeNodeFlag = if ($IncludeNode) { '1' } else { '0' }
$archLower = $Arch.ToLower()
if ($archLower -notin @('amd64','arm64')) { throw "Unsupported Arch '$Arch' (use amd64 or arm64)" }
# Node architecture label mapping
$nodeArch = if ($archLower -eq 'amd64') { 'linux-x64' } else { 'linux-arm64' }

# Inline bash script executed inside WSL
$bash = @"
set -euo pipefail
apt-get update
apt-get install -y debootstrap rsync curl xz-utils squashfs-tools grub-common grub-pc-bin xorriso jq

BUILD_DIR=/mnt/c/Users/$env:USERNAME/OneDrive/AppData/Documents/mining/minimal-os
cd "${BUILD_DIR}"
# Sync config overrides
sed -i "s/^INCLUDE_NODE=.*/INCLUDE_NODE=$includeNodeFlag/" config.env
sed -i "s/^NODE_VERSION=.*/NODE_VERSION=$NodeVersion/" config.env
sed -i "s/^ARCH=.*/ARCH=$archLower/" config.env

bash build-rootfs.sh
bash build-iso.sh

# Rename ISO with version tag
if [ -f seraphina-miner-os.iso ]; then
  mv seraphina-miner-os.iso seraphina-miner-os-${Version}-${archLower}.iso
fi
# Emit SHA256
sha256sum seraphina-miner-os-${Version}-${archLower}.iso > seraphina-miner-os-${Version}-${archLower}.sha256

"@

Write-Host "[ISO] Invoking WSL build pipeline..." -ForegroundColor Cyan
wsl.exe -d $WSLDistro -- bash -c "$bash"

# After ISO build success
$isoPath = Join-Path (Join-Path $PSScriptRoot 'minimal-os') "seraphina-miner-os-$Version-$archLower.iso"
if (-not (Test-Path $isoPath)) { throw "ISO build failed; file not found: $isoPath" }
Write-Host "[ISO] Build complete: $isoPath" -ForegroundColor Green
Write-Host "[ISO] SHA256:" -ForegroundColor DarkGray
Get-Content (Join-Path $PSScriptRoot 'minimal-os' "seraphina-miner-os-$Version-$archLower.sha256") | Write-Host

if ($AutoUSB) {
  Write-Host "[USB] Beginning USB flashing workflow" -ForegroundColor Cyan
  if ($UsbDiskNumber -lt 0) {
    # Interactive selection of removable disks
    $removable = Get-Disk | Where-Object { $_.BusType -in @('USB') -and $_.PartitionStyle -ne 'RAW' -or $_.BusType -eq 'USB' } | Select-Object Number, FriendlyName, Size
    if (-not $removable) { Write-Warning 'No USB disks detected.'; return }
    Write-Host 'Available USB disks:' -ForegroundColor DarkGray
    $removable | ForEach-Object { Write-Host "  Disk $_.Number  Name='$_.FriendlyName'  Size=$([Math]::Round($_.Size/1GB,2))GB" }
    $inputNum = Read-Host 'Enter disk number to overwrite (ALL DATA LOST)' 
    if (-not [int]::TryParse($inputNum, [ref]$UsbDiskNumber)) { Write-Warning 'Invalid disk number.'; return }
  }
  $disk = Get-Disk -Number $UsbDiskNumber -ErrorAction SilentlyContinue
  if (-not $disk) { Write-Warning "Disk $UsbDiskNumber not found."; return }
  if ($disk.IsBoot -and -not $Force) { Write-Warning 'Refusing to overwrite boot/system disk. Use -Force to override (NOT RECOMMENDED).'; return }
  if ($disk.BusType -ne 'USB') { Write-Warning 'Selected disk not reported as USB; aborting.'; return }

  $confirm = Read-Host "Type 'YES' to confirm wiping disk $UsbDiskNumber ($([Math]::Round($disk.Size/1GB,2))GB)"
  if ($confirm -ne 'YES') { Write-Host 'Aborted by user.'; return }

  Write-Host '[USB] Clearing existing partitions...' -ForegroundColor Yellow
  $disk | Clear-Disk -RemoveData -Confirm:$false
  $disk | Set-Disk -IsReadOnly $false
  $disk | Set-Disk -IsOffline $false

  # Create single partition to hold raw image (we will dd directly to device though)
  Write-Host '[USB] Identifying WSL block device mapping...' -ForegroundColor DarkGray
  # Use wsl lsblk to map size and model; choose device with matching size
  $lsblk = wsl.exe -d $WSLDistro -- bash -c "lsblk -b -o NAME,SIZE,MODEL,TRAN | sed '1d'" | ForEach-Object { $_.Trim() } | Where-Object { $_ }
  $targetDev = $null
  foreach ($line in $lsblk) {
    $parts = $line -split '\s+'
    if ($parts.Count -ge 2) {
      $name = $parts[0]; $size = [int64]$parts[1]
      # Match size within 1% tolerance
      $pctDiff = [Math]::Abs(($size - $disk.Size) / [double]$disk.Size)
      if ($pctDiff -lt 0.01 -and $name -match '^sd') { $targetDev = $name; break }
    }
  }
  if (-not $targetDev) { Write-Warning 'Unable to map USB disk to WSL device (sdX).'; return }
  Write-Host "[USB] Mapped to /dev/$targetDev" -ForegroundColor Cyan

  # Perform dd write
  $ddCmd = "sudo dd if=/mnt/c/Users/$env:USERNAME/OneDrive/AppData/Documents/mining/minimal-os/seraphina-miner-os-$Version-$archLower.iso of=/dev/$targetDev bs=4M conv=fsync status=progress"
  Write-Host "[USB] Writing image (this may take several minutes)..." -ForegroundColor Yellow
  wsl.exe -d $WSLDistro -- bash -c "$ddCmd" 
  Write-Host '[USB] Syncing...' -ForegroundColor DarkGray
  wsl.exe -d $WSLDistro -- bash -c "sync"
  Write-Host '[USB] Flash complete.' -ForegroundColor Green
}
