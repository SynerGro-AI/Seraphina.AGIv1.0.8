const fs = require('fs');
const path = require('path');

// Function to get the correct data directory based on execution context
function getDataDirectory() {
  // If running as packaged executable, use directory relative to executable
  if (process.pkg) {
    const exeDir = path.dirname(process.execPath);
    return path.join(exeDir, 'seraphina_data');
  }
  // If running from source, use persistent_data in current directory
  return path.join(__dirname, 'persistent_data');
}

// Function to ensure directory exists
function ensureDataDirectory() {
  const dataDir = getDataDirectory();
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  return dataDir;
}

// Function to get file path in data directory
function getDataFilePath(filename) {
  const dataDir = ensureDataDirectory();
  return path.join(dataDir, filename);
}

module.exports = {
  getDataDirectory,
  ensureDataDirectory,
  getDataFilePath
};