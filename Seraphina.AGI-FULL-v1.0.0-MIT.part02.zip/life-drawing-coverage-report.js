// life-drawing-coverage-report.js
// Parse coverage stats and emit sorted field usage + under-covered suggestions.
// Environment Variables (Recommendation Blending):
//   LIFE_DRAWING_RECOMMEND_ALPHA -> weight (0..1) for weaknessPercentile component (default 0.5)
//   LIFE_DRAWING_RECOMMEND_BETA  -> weight (0..1) for inverse retention (1 - retention) component (default 0.5)
// Formula:
//   recommendationScore = alpha * weaknessPercentile + beta * (1 - retention)
//   weaknessPercentile: 0 = strongest coverage (high practice), 1 = weakest coverage (low practice)
// Retention Source:
//   Provided via `life-drawing-retention.js` computeRetention(); if missing, inverse retention defaults to 0.5.
// CLI Flags:
//   --csv       -> output CSV instead of JSON
//   --sparkline -> output sparkline summary (JSON with sparkline legend)
// Output Fields:
//   recommended (top 3), underCovered (heuristic: weakness>=0.7 or pct<0.3), recommendationDetail (scores).
'use strict';
const fs = require('fs');
const path = require('path');

function loadCoverage(){
  const coveragePath = path.join(__dirname,'life-drawing-field-coverage.json');
  if(!fs.existsSync(coveragePath)) return null;
  try { return JSON.parse(fs.readFileSync(coveragePath,'utf8')); } catch(e){
    console.error('[coverage] parse error', e.message); return null;
  }
}

function loadRetention(){
  try {
    const mod = require('./life-drawing-retention');
    const r = mod.computeRetention ? mod.computeRetention() : null;
    return r && r.ok ? r : null;
  } catch(_){ return null; }
}

function generateReport(opts={}){
  const data = loadCoverage();
  if(!data){ return { ok:false, message:'No coverage file yet.' }; }
  const totalSessions = data.totalSessions || 0;
  const fieldsRaw = Object.entries(data.fields||{}).map(([f,obj])=>({ field:f, count: obj.count||0, pct: totalSessions? ((obj.count||0)/totalSessions):0 }));
  // Sort descending by count for ranking
  fieldsRaw.sort((a,b)=> b.count - a.count);
  // Percentile rank (0=highest count? we'll do 0 for lowest for intuitive weakness) => compute ascending by count
  const asc = [...fieldsRaw].sort((a,b)=> a.count - b.count);
  const percentileMap = new Map();
  asc.forEach((f,i)=>{ const p = asc.length>1 ? (i/(asc.length-1)) : 1; percentileMap.set(f.field, Number(p.toFixed(4))); });
  const fields = fieldsRaw.map(f=> ({ ...f, weaknessPercentile: percentileMap.get(f.field) }));
  // Under-covered: weaknessPercentile >= 0.7 or pct < 0.3
  const underCovered = fields.filter(f=> f.weaknessPercentile >= 0.7 || f.pct < 0.3);
  // Retention-weighted recommendation blending
  const retention = loadRetention();
  const alpha = parseFloat(process.env.LIFE_DRAWING_RECOMMEND_ALPHA || '0.5'); // weight for weaknessPercentile
  const beta = parseFloat(process.env.LIFE_DRAWING_RECOMMEND_BETA || '0.5');  // weight for inverse retention
  const retentionMap = {};
  if(retention){ retention.fields.forEach(f=> retentionMap[f.field] = f.retention); }
  const scored = fields.map(f=>{
    const invRet = retentionMap[f.field] != null ? (1 - retentionMap[f.field]) : 0.5; // default mid if missing
    const score = alpha * f.weaknessPercentile + beta * invRet;
    return { field: f.field, score, weaknessPercentile: f.weaknessPercentile, inverseRetention: invRet };
  }).sort((a,b)=> b.score - a.score);
  const recommended = scored.slice(0,3).map(s=> s.field);
  const report = { ok:true, totalSessions, fields, underCovered, recommended, recommendationDetail: scored };
  if(opts.sparkline){
    // Simple sparkline using unicode blocks based on normalized count
    const counts = fields.map(f=> f.count);
    const max = Math.max(...counts,1);
    const blocks = ['▁','▂','▃','▄','▅','▆','▇','█'];
    const line = fields.map(f=>{
      const idx = Math.min(blocks.length-1, Math.floor((f.count/max)*(blocks.length-1)));
      return blocks[idx];
    }).join('');
    return { ok:true, sparkline: line, legend: fields.map(f=> f.field) };
  }
  if(opts.format === 'csv'){
    const header = 'field,count,pct,weaknessPercentile';
    const rows = fields.map(f=> [f.field, f.count, f.pct.toFixed(4), f.weaknessPercentile.toFixed(4)].join(','));
    return header+'\n'+rows.join('\n');
  }
  return report;
}

if(require.main === module){
  const format = process.argv.includes('--csv') ? 'csv' : 'json';
  const sparkline = process.argv.includes('--sparkline');
  const report = generateReport({ format, sparkline });
  if(sparkline){ console.log(JSON.stringify(report,null,2)); }
  else if(format==='csv') console.log(report); else console.log(JSON.stringify(report,null,2));
}

module.exports = { generateReport };
