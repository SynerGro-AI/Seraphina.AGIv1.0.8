"use strict";
// holodeck-smoke-test.js (enhanced)
// Single-process miner + holodeck activation; extended runtime + ledger simulation.
process.env.HOLODECK_ENABLE = '1';
process.env.ALLOW_DOTENV_IN_STRICT = '1'; // override strict dotenv block for test
process.env.HOLODECK_SCENARIO = process.env.HOLODECK_SCENARIO || 'default';
process.env.HOLODECK_BLOCK_INTERVAL_MS = process.env.HOLODECK_BLOCK_INTERVAL_MS || '250';
process.env.HOLODECK_FORK_SCHEDULE = process.env.HOLODECK_FORK_SCHEDULE || '20,45';
process.env.SHARE_LEDGER_PATH = process.env.SHARE_LEDGER_PATH || 'share-ledger-smoke.jsonl';
process.env.LEDGER_ROTATE_INTERVAL_MS = process.env.LEDGER_ROTATE_INTERVAL_MS || '600000'; // 10m for test
process.env.HOLODECK_LEDGER_VERIFY_MS = process.env.HOLODECK_LEDGER_VERIFY_MS || '1000'; // faster verify for smoke
require('./holodeck/holodeck-loader');

const seen = { block:0, forkEvt:0, scenarioEvt:0 };
const ledgerSamples=[];
const blockSamples=[]; // capture every block height
const forkEvents=[];   // capture fork start/end events
const origLog = console.log;
console.log = function(...args){
  try {
    if (/Holodeck\]\[Block/.test(args[0])) seen.block++;
    if (/Holodeck\]\[ForkEvt/.test(args[0])) seen.forkEvt++;
    if (/Holodeck\]\[ScenarioEvt/.test(args[0])) seen.scenarioEvt++;
  } catch(_){ }
  return origLog.apply(this, args);
};

// Direct scenario event subscription for counting (loader only prints if prefixed)
try {
  if (global.__HOLO_SCENARIO__){
    global.__HOLO_SCENARIO__.on(ev=>{
      if (ev && ev.type==='scenario_event'){
        seen.scenarioEvt++;
        origLog('[Holodeck][ScenarioEvt]', ev.data.label, 'at', ev.data.at);
      }
    });
  }
  if (global.__HOLO_FORKS__){
    global.__HOLO_FORKS__.on(ev=>{
      if (ev && ev.type==='block'){
        blockSamples.push({ h: ev.height, fork: !!ev.block.forkActive });
        // Keep memory bounded
        if (blockSamples.length > 500) blockSamples.shift();
      } else if (ev && (ev.type==='fork_start' || ev.type==='fork_end')){
        forkEvents.push({ type: ev.type, h: ev.height });
        if (forkEvents.length > 100) forkEvents.shift();
      }
    });
  }
} catch(_sce){}

// Start miner core
let minerLoaded = false; try { require('./aurrelia-pico-mesh-miner.js'); minerLoaded=true; } catch(e){ console.error('[SmokeTest] miner load failed', e.message); }

// Periodically sample ledger status
setInterval(()=>{
  const st = global.__HOLO_LEDGER_STATUS__;
  if (st && typeof st.count==='number' && ledgerSamples.length < 10){ ledgerSamples.push({ t:Date.now(), ok:st.ok, count:st.count }); }
}, 400).unref();

// Append deterministic ledger lines mid-run
function simulateLedgerBurst(){
  try {
    const { append } = require('./ledger-hmac-chain');
    const file = process.env.SHARE_LEDGER_PATH;
    for(let i=0;i<12;i++) append(file,{ t: Date.now(), jobId:'simJob'+i, ex2:i.toString(16), real: i%2, sim: (i%2?0:1), norm: i*0.015, rankProxy:1.01+i*0.0005, signVar:1.0 });
    // Force immediate status update after burst
    try {
      const verify = require('./ledger-hmac-chain').verifyAllEpochs(file);
      global.__HOLO_LEDGER_STATUS__ = verify;
    } catch(_v){}
  } catch(e){ /* ignore */ }
}
setTimeout(simulateLedgerBurst, 3000).unref();

const START_TS = Date.now();
const END_MS = parseInt(process.env.HOLODECK_SMOKE_MS || '7000',10);
setTimeout(()=>{
  let ledgerVerify=null; try { ledgerVerify = require('./ledger-hmac-chain').verifyAllEpochs(process.env.SHARE_LEDGER_PATH); } catch(_){ }
  const totalBytes = (typeof global.__HOLO_BYTES_PROCESSED__ === 'number') ? global.__HOLO_BYTES_PROCESSED__ : null;
  const elapsedSec = (Date.now() - START_TS)/1000;
  const bytesPerSec = totalBytes != null ? Number((totalBytes / (elapsedSec||1)).toFixed(2)) : null;
  const report = {
    minerLoaded,
    seen,
    virtualHeight: global.__HOLO_FORKS__ ? global.__HOLO_FORKS__.getHeight() : null,
    forkActive: global.__HOLO_FORKS__ ? global.__HOLO_FORKS__.isForkActive() : null,
    scenario: process.env.HOLODECK_SCENARIO,
    ledger: global.__HOLO_LEDGER_STATUS__ || null,
    ledgerSamples,
    ledgerVerify,
    blockSampleCount: blockSamples.length,
    blockFirst: blockSamples.length? blockSamples[0].h : null,
    blockLast: blockSamples.length? blockSamples[blockSamples.length-1].h : null,
    forkEvents,
    blockSamplesPreview: blockSamples.slice(0, Math.min(blockSamples.length, 20))
    , holoHashCount: (typeof global.__HOLO_HASH_COUNT__==='number'? global.__HOLO_HASH_COUNT__: null)
    , holoBytesProcessed: totalBytes
    , holoBytesPerSec: bytesPerSec
    , selectedCoin: global.__AUR_SELECTED_COIN__ || null
    , selectedAlgo: global.__AUR_SELECTED_ALGO__ || null
  };
  console.log('[HolodeckSmokeReport]', JSON.stringify(report, null, 2));
  process.exit(report.minerLoaded && report.seen.block > 0 ? 0 : 3);
}, END_MS);
