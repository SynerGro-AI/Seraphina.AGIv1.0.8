'use strict';
// kraken-exporter.js - Scaffold for creating Kraken withdrawal/export payloads.
// Real Kraken integration would use authenticated REST (private/AddOrder, Withdraw, etc.).
// Here we provide:
//  buildWithdrawal(symbol, address, amount) -> writes JSON artifact
//  exportAddresses(symbol, addresses[]) -> CSV for manual import/reference

const fs = require('fs');

function normSymbol(sym){ return sym.toUpperCase(); }

function buildWithdrawal(symbol, address, amount){
  const payload = {
    exchange: 'Kraken',
    type: 'withdrawal-request-stub',
    symbol: normSymbol(symbol),
    address,
    amount,
    created: Date.now(),
    note: 'This is a scaffold artifact. Use Kraken API to submit real withdrawal.'
  };
  const file = `kraken-withdraw-${symbol}-${Date.now()}.json`;
  try { fs.writeFileSync(file, JSON.stringify(payload,null,2)); } catch(e){ /* ignore */ }
  return file;
}

function exportAddresses(symbol, addresses){
  const header = 'symbol,address,ts\n';
  const lines = addresses.map(a=>`${normSymbol(symbol)},${a},${Date.now()}`);
  const file = `kraken-addresses-${symbol}-${Date.now()}.csv`;
  try { fs.writeFileSync(file, header+lines.join('\n')); } catch(e){ /* ignore */ }
  return file;
}

module.exports = { buildWithdrawal, exportAddresses };
