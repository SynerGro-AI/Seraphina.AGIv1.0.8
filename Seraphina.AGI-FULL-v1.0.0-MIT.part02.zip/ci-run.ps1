# ci-run.ps1
param(
  [string]$PromEndpoint = "http://localhost:9090/metrics"
)
Write-Host "[CI] Starting Aurrelia CI run"
$ErrorActionPreference = 'Stop'
# Example env vars (adjust as needed)
$env:AUTONOMY_ENABLED='1'
$env:GLOBAL_MIN_IMPROVEMENT='0'
# Run aggregated tests
Write-Host "[CI] Running test-run-all.js"
$testResult = node test-run-all.js | Out-String
Write-Host $testResult
$json = $testResult | ConvertFrom-Json
if($json.failed -gt 0){
  Write-Host "[CI] Test failures detected: $($json.failed)" -ForegroundColor Red
  exit 1
}
Write-Host "[CI] Tests passed"
# Optional scrape
try {
  $resp = Invoke-WebRequest -Uri $PromEndpoint -Method GET -TimeoutSec 5
  Write-Host "[CI] Prometheus scrape length: $($resp.Content.Length)"
} catch { Write-Host "[CI] Prometheus scrape skipped/failed: $($_.Exception.Message)" }
Write-Host "[CI] Completed"
exit 0
