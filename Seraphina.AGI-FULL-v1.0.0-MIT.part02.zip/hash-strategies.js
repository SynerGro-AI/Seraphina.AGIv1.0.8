"use strict";
// hash-strategies.js – isolated hashing backends (deterministic, no hidden RNG)
// Exports:
//   HASH_STRATEGIES: { id, hashHeader(hex,[height],[seedHex]) }
//   doubleSha256(hex|string|Buffer)
//   ensureMidstate() lazy init for wasm midstate (no-op if unavailable)

const crypto = require('crypto');

function doubleSha256(input){
  const buf = Buffer.isBuffer(input)? input : Buffer.from(input, 'hex');
  const h1 = crypto.createHash('sha256').update(buf).digest();
  return crypto.createHash('sha256').update(h1).digest('hex');
}

let fusedHash = null; try { fusedHash = require('./fused_wasm.js'); } catch(_) { /* optional */ }
let midstate = null; try { midstate = require('./midstate.js'); } catch(_) { /* optional */ }
let kawpowNative = null; 
try {
  const override = process.env.KAWPOW_NATIVE_MODULE;
  if (override){ try { kawpowNative = require(override); } catch(_){} }
  if (!kawpowNative){ try { kawpowNative = require('./build/Release/kawpowhash.node'); } catch(e1){ try { kawpowNative = require('./build/Release/kawpow_native.node'); } catch(_){} } }
} catch(_){ }
let litecoinScryptHash = null; try { litecoinScryptHash = require('scryptsy'); } catch(_) {}
let kheavy = null; try { ({ kheavyHash: kheavy } = require('./heavyhash-kaspa.js')); } catch(_){ }

// Midstate helpers (lazy) – used by higher level if available
function ensureMidstate(){
  if (!midstate || typeof midstate.init !== 'function') return false;
  if (global.__AUR_MIDSTATE_INIT__) return true;
  try { midstate.init(); global.__AUR_MIDSTATE_INIT__ = 1; return true; } catch(_) { return false; }
}

const HASH_STRATEGIES = {
  sha256d: { id:'sha256d', hashHeader: (h)=> doubleSha256(h), parityEnabled:true },
  kawpow: kawpowNative ? { id:'kawpow', parityEnabled:true, nativeLoaded:true, hashHeader: (headerHex, height=0, seedHex='')=>{
      try {
        const headerBuf = Buffer.from(headerHex,'hex');
        const seedBuf = seedHex? Buffer.from(seedHex,'hex') : Buffer.alloc(32,0);
        const out = kawpowNative.hash(headerBuf, height, seedBuf, 0);
        try { const j = JSON.parse(out); return j.finalHash || j.mixHash || doubleSha256(headerHex); } catch(_) { return doubleSha256(headerHex); }
      } catch(e){ return doubleSha256(headerHex); }
    } } : null,
  scrypt: (typeof litecoinScryptHash === 'function') ? { id:'scrypt', parityEnabled:false, hashHeader: (h)=>{
      const raw = Buffer.from(h,'hex');
      const out = litecoinScryptHash(raw, raw, 1024, 1, 1, 32);
      return Buffer.from(out).toString('hex');
    } } : null,
  kheavy: kheavy ? { id:'kheavy', parityEnabled:false, hashHeader: (h, height=0)=> kheavy(h, height) } : null
};

Object.keys(HASH_STRATEGIES).forEach(k=> { if(!HASH_STRATEGIES[k]) delete HASH_STRATEGIES[k]; });

module.exports = { HASH_STRATEGIES, doubleSha256, ensureMidstate, fusedHash };
