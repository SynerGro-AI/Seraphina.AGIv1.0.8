// life-drawing-exam.js
// Generates deterministic life drawing practice exam referencing pose image directories.
// No image content loaded into memory; only filenames and hashed metadata.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { analyzeFilename } = require('./life-drawing-detection');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function loadPoseDirs(){
  const defaultDirs = [
    'C:/Users/jmwil/Downloads/Poses for Artists - Veronica (small)',
    'C:/Users/jmwil/Downloads/Poses for Artists - Chanon (small)'
  ];
  // ENV override: LIFE_DRAWING_DIRS=dir1;dir2;dir3
  let dirs = defaultDirs.slice();
  if(process.env.LIFE_DRAWING_DIRS){
    const envDirs = process.env.LIFE_DRAWING_DIRS.split(/;+/).map(s=> s.trim()).filter(Boolean);
    if(envDirs.length) dirs = envDirs;
  }
  // Config file override life-drawing-config.json { "poseDirs": ["path1", ...] }
  try {
    const cfgPath = path.join(__dirname,'life-drawing-config.json');
    if(fs.existsSync(cfgPath)){
      const raw = fs.readFileSync(cfgPath,'utf8');
      const cfg = JSON.parse(raw);
      if(Array.isArray(cfg.poseDirs) && cfg.poseDirs.length){
        const cleaned = cfg.poseDirs.map(s=> String(s).trim()).filter(Boolean);
        if(cleaned.length) dirs = cleaned;
      }
    }
  } catch(_){ /* ignore malformed config */ }
  // Deduplicate & sort for determinism
  dirs = Array.from(new Set(dirs));
  dirs.sort((a,b)=> a.localeCompare(b));
  return dirs;
}

function listPoseFiles(dir){
  try {
    const files = fs.readdirSync(dir).filter(f=> /\.(png|jpe?g)$/i.test(f));
    files.sort((a,b)=> a.localeCompare(b));
    return files.slice(0,50); // cap for determinism
  } catch(_){ return []; }
}

function buildCatalog(){
  const catalog = [];
  const poseDirs = loadPoseDirs();
  poseDirs.forEach(d=>{
    const files = listPoseFiles(d);
    const digest = sha256(files.join('|'));
    catalog.push({ dir:d, count:files.length, digest, sample: files.slice(0,5) });
  });
  return catalog;
}

// Question generation: ask anatomical / gesture estimation tasks based on filename ordering.
function generateLifeDrawingExam(){
  const catalog = buildCatalog();
  const questions = [];
  catalog.forEach(entry=>{
    entry.sample.forEach((file, idx)=>{
      const det = analyzeFilename(file);
      const fields = ['gestureDirection','centerOfGravity','dominantMass','balanceAssessment'];
      if(det.proportionCheck) fields.push('proportionCheck');
      if(det.negativeSpace) fields.push('negativeSpace');
      questions.push({
        id: sha256(entry.dir + ':' + file).slice(0,12),
        poseFile: file,
        sourceDirDigest: sha256(entry.dir),
        prompt: `Identify primary gesture line direction and center of gravity for pose file '${file}' (#${idx+1} sample from directory).`,
        expectedFields: fields
      });
    });
  });
  // Deterministic ordering
  questions.sort((a,b)=> a.id.localeCompare(b.id));
  return { ts: new Date().toISOString(), questionCount: questions.length, catalogDigest: sha256(catalog), catalog, questionsDigest: sha256(questions.map(q=>q.id).join('|')), questions };
}

if(require.main === module){
  const exam = generateLifeDrawingExam();
  process.stdout.write(JSON.stringify(exam,null,2)+'\n');
}

module.exports = { generateLifeDrawingExam, loadPoseDirs };
