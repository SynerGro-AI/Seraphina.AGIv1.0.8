const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const OUT_DIR = process.env.MANIFEST_DIR || path.join(ROOT, 'persistent_data');
const INCLUDE_EXT = new Set(['.js', '.json', '.ps1', '.bat', '.octa']);
const EXCLUDE_DIR = new Set(['node_modules', 'dist', 'dist-electron', '.git']);

function hashFile(fp){
  try { return crypto.createHash('sha256').update(fs.readFileSync(fp)).digest('hex'); } catch { return null; }
}

function walk(dir, list=[]) {
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes:true }); } catch { return list; }
  for(const e of entries){
    if(e.name.startsWith('.git')) continue;
    const full = path.join(dir, e.name);
    if(e.isDirectory()){
      if(EXCLUDE_DIR.has(e.name)) continue;
      walk(full, list);
    } else {
      const ext = path.extname(e.name).toLowerCase();
      if(!INCLUDE_EXT.has(ext)) continue;
      const rel = path.relative(ROOT, full).replace(/\\/g,'/');
      let stat; try { stat = fs.statSync(full); } catch { continue; }
      const hash = hashFile(full);
      list.push({ file: rel, size: stat.size, hash });
    }
  }
  return list;
}

function main(){
  try { if(!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive:true }); } catch{}
  const files = walk(ROOT).sort((a,b)=>a.file.localeCompare(b.file));
  const summary = {
    ts: Date.now(),
    count: files.length,
    files
  };
  const ts = new Date().toISOString().replace(/[:T]/g,'-').replace(/\..+/,'');
  const outFile = path.join(OUT_DIR, `manifest-${ts}.json`);
  try { fs.writeFileSync(outFile, JSON.stringify(summary, null, 2)); } catch(e){ console.error('[MANIFEST_WRITE_FAIL]', e.message); }
  console.log('[MANIFEST] Wrote', outFile, 'files=', files.length);
}

if(require.main === module) main();
