#!/usr/bin/env node
// ensure-wasm.js - builds sha256_mid.wasm if missing.
const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const wasmPath = path.join(__dirname,'sha256_mid.wasm');
const fusedPath = path.join(__dirname,'sha256_fused.wasm');

function hasEmcc(){
  // First attempt: plain spawn (works on most *nix)
  try {
    const r = spawnSync('emcc',['--version'], { stdio:'pipe' });
    if (r && r.status === 0) return true;
  } catch(_) {}
  // Second attempt: shell invocation (PowerShell/CMD can resolve emcc.ps1/.bat even if spawn failed)
  try {
    const rShell = spawnSync('emcc --version', { shell: true, stdio:'pipe' });
    if (rShell && rShell.status === 0) return true;
  } catch(_) {}
  // Third attempt: direct path via EMSDK env var
  if (process.env.EMSDK){
    const candidates = [
      path.join(process.env.EMSDK, 'upstream','emscripten','emcc.bat'),
      path.join(process.env.EMSDK, 'upstream','emscripten','emcc.cmd'),
      path.join(process.env.EMSDK, 'upstream','emscripten','emcc'),
    ];
    for (const c of candidates){
      if (fs.existsSync(c)){
        try {
          const rC = spawnSync(`${process.platform==='win32'? '"'+c+'"':c} --version`, { shell:true, stdio:'pipe' });
          if (rC && rC.status === 0) {
            // Inject directory to PATH for subsequent npm scripts if missing
            const dir = path.dirname(c);
            if (!(process.env.PATH || '').split(path.delimiter).includes(dir)){
              process.env.PATH = dir + path.delimiter + process.env.PATH;
            }
            return true;
          }
        } catch(_) {}
      }
    }
  }
  return false;
}

let needMid = !(fs.existsSync(wasmPath) && fs.statSync(wasmPath).size > 300);
let needFused = !(fs.existsSync(fusedPath) && fs.statSync(fusedPath).size > 300);
if (!needMid && !needFused){
  console.log('[ensure-wasm] sha256_mid.wasm present (size='+fs.statSync(wasmPath).size+' bytes)');
  console.log('[ensure-wasm] sha256_fused.wasm present (size='+fs.statSync(fusedPath).size+' bytes)');
  process.exit(0);
}
const missingList = [needMid? 'sha256_mid.wasm': null, needFused? 'sha256_fused.wasm': null].filter(Boolean).join(', ');
console.log('[ensure-wasm] building wasm modules (missing -> ' + missingList + ')');
if (!hasEmcc()){
  console.error(`[ensure-wasm] emcc (Emscripten) not found after multi-strategy lookup. Cannot build: ${missingList}`);
  console.error('Detected EMSDK=' + (process.env.EMSDK || '(unset)'));
  console.error('Install / Activate steps (Windows PowerShell):');
  console.error('  git clone https://github.com/emscripten-core/emsdk.git $HOME/emsdk');
  console.error('  cd $HOME/emsdk');
  console.error('  ./emsdk install latest');
  console.error('  ./emsdk activate latest');
  console.error('  ./emsdk_env.ps1  (or add to $PROFILE for persistence)');
  console.error('Then re-run:  npm run ensure:wasm');
  process.exit(2);
}
try {
  if (needMid) execSync('npm run build:wasm', { stdio: 'inherit' });
  if (needFused){
    try {
      execSync('npm run build:wasm:fused', { stdio: 'inherit' });
    } catch(e){
      console.warn('[ensure-wasm] SIMD fused build failed, attempting non-SIMD fallback...');
      execSync('npm run build:wasm:fused:nosimd', { stdio: 'inherit' });
    }
  }
  if (fs.existsSync(wasmPath) && fs.existsSync(fusedPath)) {
    console.log('[ensure-wasm] build complete');
    process.exit(0);
  } else {
    console.error('[ensure-wasm] build command finished but wasm still missing');
    process.exit(1);
  }
} catch (e) {
  console.error('[ensure-wasm] build failed:', e.message);
  process.exit(1);
}
