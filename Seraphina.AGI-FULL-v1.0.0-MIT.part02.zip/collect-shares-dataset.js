#!/usr/bin/env node
// collect-shares-dataset.js
// Deterministically build training/validation dataset from aurrelia-shares-ledger.jsonl.
'use strict';
const fs = require('fs');
const crypto = require('crypto');

function shaSeedInt(str){
  return parseInt(crypto.createHash('sha256').update(str).digest('hex').slice(0,8),16);
}

function loadLedger(path){
  if(!fs.existsSync(path)) return [];
  return fs.readFileSync(path,'utf8').trim().split(/\n+/).filter(Boolean).map(l=> { try { return JSON.parse(l); } catch(_){ return null; } }).filter(Boolean);
}

function normalizeColumn(arr){
  const min = Math.min(...arr); const max = Math.max(...arr); const range = (max-min) || 1; return arr.map(v=> (v-min)/range);
}

function buildDataset(entries){
  // Filter to rows with required fields
  const rows = entries.filter(e=> typeof e.node_freq==='number' && typeof e.recent_success_rate==='number' && typeof e.job_difficulty==='number' && typeof e.accepted==='boolean');
  if(!rows.length) return { train:{X:[],y:[]}, val:{X:[],y:[]}, total:0 };
  const freq = rows.map(r=> r.node_freq);
  const rate = rows.map(r=> r.recent_success_rate);
  const diff = rows.map(r=> r.job_difficulty);
  const lab = rows.map(r=> r.accepted?1:0);
  const nf = normalizeColumn(freq);
  const nr = normalizeColumn(rate);
  const nd = normalizeColumn(diff);
  const features = nf.map((_,i)=> [nf[i], nr[i], nd[i]]);
  // Deterministic split 80/20 using hashed shuffle index
  const seed = shaSeedInt(process.env.SHARE_DATASET_SEED || 'seraphina-shares-2025');
  const idx = features.map((f,i)=>({i, h: (seed * (i+1) + i*i) % 0xFFFFFFFF }));
  idx.sort((a,b)=> a.h - b.h);
  const cut = Math.floor(idx.length * 0.8);
  const trainIdx = new Set(idx.slice(0,cut).map(o=> o.i));
  const X_train = []; const y_train = []; const X_val=[]; const y_val=[];
  for(let i=0;i<features.length;i++){
    if(trainIdx.has(i)){ X_train.push(features[i]); y_train.push(lab[i]); } else { X_val.push(features[i]); y_val.push(lab[i]); }
  }
  return { train:{X:X_train,y:y_train}, val:{X:X_val,y:y_val}, total: rows.length };
}

function main(){
  const ledgerPath = 'aurrelia-shares-ledger.jsonl';
  const entries = loadLedger(ledgerPath);
  const ds = buildDataset(entries);
  fs.writeFileSync('shares-dataset.json', JSON.stringify(ds,null,2));
  console.log(JSON.stringify({ ok:true, total: ds.total, train: ds.train.X.length, val: ds.val.X.length }, null, 2));
}

if(require.main === module){ main(); }

module.exports = { buildDataset };
