#!/usr/bin/env node
// Minimal SBOM generator: lists files & hashes from minimal-runtime-manifest plus provenance roots.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }

const minimal = fs.existsSync('minimal-runtime-manifest.json') ? JSON.parse(fs.readFileSync('minimal-runtime-manifest.json','utf8')) : null;
const provenance = fs.existsSync('provenance.json') ? JSON.parse(fs.readFileSync('provenance.json','utf8')) : null;

const files = (minimal?.artifacts || []).map(a=>({ file: a.file, sha256: a.sha256, size: a.size }));
// include script inventory (top-level .js only)
for(const f of fs.readdirSync('.')){
  if(/\.js$/.test(f) && !files.find(x=>x.file===f)){
    try { const data = fs.readFileSync(f); files.push({ file: f, sha256: sha256(data), size: data.length }); } catch {}
  }
}

const sbom = {
  generated: new Date().toISOString(),
  tool: 'seraphina-sbom-gen',
  minimalMerkleRoot: minimal?.merkleRoot || null,
  provenanceRoots: provenance ? {
    minerMerkleRoot: provenance.minerMerkleRoot,
    minerAuditRoot: provenance.minerAuditRoot,
    minimalMerkleRoot: provenance.minimalMerkleRoot
  } : null,
  files
};

process.stdout.write(JSON.stringify(sbom,null,2));