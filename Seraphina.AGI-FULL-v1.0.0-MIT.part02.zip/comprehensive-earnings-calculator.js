// COMPREHENSIVE EARNINGS CALCULATOR WITH REAL PRICES
const https = require('https');

class ComprehensiveEarningsCalculator {
    constructor() {
        // Your real configuration from .env.bak
        this.wallets = {
            BTC_MINING: '1QF4sh6yqZ4ZgAbTnGXRt1WwCXiVtBFddz',
            BTC_KRAKEN: '34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf',
            RVN_LOCAL: 'RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7'
        };
        
        // Mining hardware specs (ASIC estimates)
        this.hardware = {
            btcHashRate: 110e12, // 110 TH/s (Antminer S19 Pro)
            rvnHashRate: 65e6,   // 65 MH/s (RTX 3080)
            btcPower: 3250,      // 3.25 kW
            rvnPower: 320,       // 320W
            electricityRate: 0.12 // $0.12/kWh
        };
        
        // Network stats
        this.network = {
            btcDifficulty: 85000000000000,
            rvnDifficulty: 170000,
            btcBlockReward: 3.125,
            rvnBlockReward: 2500,
            btcBlockTime: 600,    // 10 minutes
            rvnBlockTime: 60,     // 1 minute
            poolFee: 0.015        // 1.5%
        };
        
        this.prices = { BTC: 0, RVN: 0 };
        
        console.log('💰 COMPREHENSIVE EARNINGS CALCULATOR');
        console.log('🏦 Using your real wallet addresses');
        console.log('⚡ ASIC-grade mining projections');
    }
    
    async fetchRealPrices() {
        console.log('\n📡 Fetching real cryptocurrency prices...');
        
        try {
            this.prices.BTC = await this.getPrice('bitcoin');
            this.prices.RVN = await this.getPrice('ravencoin');
            
            console.log(`💰 BTC Price: $${this.prices.BTC.toLocaleString()}`);
            console.log(`🔸 RVN Price: $${this.prices.RVN.toFixed(4)}`);
            
            return true;
        } catch (error) {
            console.log('⚠️ Using fallback prices...');
            this.prices.BTC = 67500;
            this.prices.RVN = 0.0285;
            return false;
        }
    }
    
    getPrice(coinId) {
        return new Promise((resolve, reject) => {
            const url = `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd`;
            
            https.get(url, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        resolve(json[coinId]?.usd || 0);
                    } catch (e) {
                        reject(e);
                    }
                });
            }).on('error', reject);
        });
    }
    
    calculateEarnings() {
        console.log('\n⚡ CALCULATING MINING EARNINGS...');
        console.log('═'.repeat(80));
        
        // BTC Calculations
        const btcHashesPerBlock = this.network.btcDifficulty * Math.pow(2, 32);
        const btcNetworkHashRate = btcHashesPerBlock / this.network.btcBlockTime;
        const btcMyShare = this.hardware.btcHashRate / btcNetworkHashRate;
        const btcRewardPerSecond = (this.network.btcBlockReward / this.network.btcBlockTime) * btcMyShare * (1 - this.network.poolFee);
        
        // RVN Calculations  
        const rvnHashesPerBlock = this.network.rvnDifficulty * Math.pow(2, 32);
        const rvnNetworkHashRate = rvnHashesPerBlock / this.network.rvnBlockTime;
        const rvnMyShare = this.hardware.rvnHashRate / rvnNetworkHashRate;
        const rvnRewardPerSecond = (this.network.rvnBlockReward / this.network.rvnBlockTime) * rvnMyShare * (1 - this.network.poolFee);
        
        // Power costs
        const btcPowerCostPerSecond = (this.hardware.btcPower / 1000) * this.hardware.electricityRate / 3600;
        const rvnPowerCostPerSecond = (this.hardware.rvnPower / 1000) * this.hardware.electricityRate / 3600;
        
        return {
            BTC: {
                rewardPerSecond: btcRewardPerSecond,
                rewardPerHour: btcRewardPerSecond * 3600,
                rewardPerDay: btcRewardPerSecond * 86400,
                valuePerSecond: btcRewardPerSecond * this.prices.BTC,
                valuePerHour: btcRewardPerSecond * 3600 * this.prices.BTC,
                valuePerDay: btcRewardPerSecond * 86400 * this.prices.BTC,
                powerCostPerSecond: btcPowerCostPerSecond,
                powerCostPerHour: btcPowerCostPerSecond * 3600,
                powerCostPerDay: btcPowerCostPerSecond * 86400,
                netPerSecond: (btcRewardPerSecond * this.prices.BTC) - btcPowerCostPerSecond,
                netPerHour: (btcRewardPerSecond * 3600 * this.prices.BTC) - (btcPowerCostPerSecond * 3600),
                netPerDay: (btcRewardPerSecond * 86400 * this.prices.BTC) - (btcPowerCostPerSecond * 86400)
            },
            RVN: {
                rewardPerSecond: rvnRewardPerSecond,
                rewardPerHour: rvnRewardPerSecond * 3600,
                rewardPerDay: rvnRewardPerSecond * 86400,
                valuePerSecond: rvnRewardPerSecond * this.prices.RVN,
                valuePerHour: rvnRewardPerSecond * 3600 * this.prices.RVN,
                valuePerDay: rvnRewardPerSecond * 86400 * this.prices.RVN,
                powerCostPerSecond: rvnPowerCostPerSecond,
                powerCostPerHour: rvnPowerCostPerSecond * 3600,
                powerCostPerDay: rvnPowerCostPerSecond * 86400,
                netPerSecond: (rvnRewardPerSecond * this.prices.RVN) - rvnPowerCostPerSecond,
                netPerHour: (rvnRewardPerSecond * 3600 * this.prices.RVN) - (rvnPowerCostPerSecond * 3600),
                netPerDay: (rvnRewardPerSecond * 86400 * this.prices.RVN) - (rvnPowerCostPerSecond * 86400)
            }
        };
    }
    
    showDetailedEarnings(earnings) {
        console.log('\n🪙 BITCOIN (BTC) MINING PROJECTIONS:');
        console.log(`   Hardware:     ${(this.hardware.btcHashRate / 1e12).toFixed(1)} TH/s @ ${this.hardware.btcPower}W`);
        console.log(`   Per Second:   ${earnings.BTC.rewardPerSecond.toFixed(8)} BTC = $${earnings.BTC.valuePerSecond.toFixed(4)}`);
        console.log(`   Per Hour:     ${earnings.BTC.rewardPerHour.toFixed(6)} BTC = $${earnings.BTC.valuePerHour.toFixed(2)}`);
        console.log(`   Per Day:      ${earnings.BTC.rewardPerDay.toFixed(5)} BTC = $${earnings.BTC.valuePerDay.toFixed(2)}`);
        console.log(`   Power Cost:   $${earnings.BTC.powerCostPerDay.toFixed(2)}/day`);
        console.log(`   Net Profit:   $${earnings.BTC.netPerDay.toFixed(2)}/day`);
        console.log();
        
        console.log('🔸 RAVENCOIN (RVN) MINING PROJECTIONS:');
        console.log(`   Hardware:     ${(this.hardware.rvnHashRate / 1e6).toFixed(1)} MH/s @ ${this.hardware.rvnPower}W`);
        console.log(`   Per Second:   ${earnings.RVN.rewardPerSecond.toFixed(4)} RVN = $${earnings.RVN.valuePerSecond.toFixed(6)}`);
        console.log(`   Per Hour:     ${earnings.RVN.rewardPerHour.toFixed(2)} RVN = $${earnings.RVN.valuePerHour.toFixed(4)}`);
        console.log(`   Per Day:      ${earnings.RVN.rewardPerDay.toFixed(0)} RVN = $${earnings.RVN.valuePerDay.toFixed(2)}`);
        console.log(`   Power Cost:   $${earnings.RVN.powerCostPerDay.toFixed(2)}/day`);
        console.log(`   Net Profit:   $${earnings.RVN.netPerDay.toFixed(2)}/day`);
        console.log();
        
        const totalDaily = earnings.BTC.netPerDay + earnings.RVN.netPerDay;
        const totalMonthly = totalDaily * 30;
        const totalYearly = totalDaily * 365;
        
        console.log('💰 COMBINED MINING PROJECTIONS:');
        console.log(`   Daily Profit:    $${totalDaily.toFixed(2)}`);
        console.log(`   Monthly Profit:  $${totalMonthly.toFixed(2)}`);
        console.log(`   Yearly Profit:   $${totalYearly.toFixed(2)}`);
        console.log();
        
        console.log('🏦 WALLET ADDRESSES:');
        console.log(`   BTC Mining:   ${this.wallets.BTC_MINING}`);
        console.log(`   BTC Kraken:   ${this.wallets.BTC_KRAKEN}`);
        console.log(`   RVN Local:    ${this.wallets.RVN_LOCAL}`);
    }
    
    async run() {
        await this.fetchRealPrices();
        const earnings = this.calculateEarnings();
        this.showDetailedEarnings(earnings);
        
        console.log('\n🚀 SERAPHINA MINING: REAL PROJECTIONS WITH YOUR INFRASTRUCTURE! 🚀');
    }
}

// Run if called directly
if (require.main === module) {
    const calculator = new ComprehensiveEarningsCalculator();
    calculator.run();
}

module.exports = { ComprehensiveEarningsCalculator };