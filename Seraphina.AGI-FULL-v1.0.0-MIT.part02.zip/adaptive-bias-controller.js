"use strict";
// adaptive-bias-controller.js
// Dynamically adjusts extranonce bias strategy (xor/add/mix/none) based on Prometheus-observed
// wheel variance & share acceptance to stabilize performance.
// Design Goals:
//  - Poll local Prometheus HTTP API (if enabled) OR read recent snapshot JSONL to avoid network.
//  - Compute rolling windows of: share acceptance ratio, wheel_aggregate_spin_variance_hw (or generic variance), verifier latency p95.
//  - Decision rules (deterministic):
//       * If variance > (BASELINE_VAR * (1 + VAR_TOL)) => downgrade to 'xor' (stable) or 'none'.
//       * If acceptance improves >= MIN_ACCEPT_DELTA over baseline AND variance within tolerance => try 'mix' (aggressive) else 'add'.
//       * Cooldown between changes to avoid flapping.
//  - Persist last decisions to adaptive-bias-state.json for continuity.
//  - Provide global.__AUR_ADAPTIVE_BIAS_MODE for mining-core consumption.
//  - Fallback gracefully if metrics unavailable (no changes).
//
// Environment Variables:
//  ADAPTIVE_BIAS_ENABLED=1      Enable controller (gated outside as well)
//  PROM_HOST (default http://localhost:9090)
//  PROM_QUERY_WINDOW=5m         Window for range queries
//  BIAS_BASELINE_VAR=0.25       Expected stable variance baseline
//  BIAS_VAR_TOL=0.20            Allowable +% before downgrade
//  BIAS_ACCEPT_MIN_DELTA=0.03   Required acceptance ratio improvement to escalate bias
//  BIAS_COOLDOWN_SEC=300        Minimum seconds between mode transitions
//  BIAS_POLL_INTERVAL_MS=60000  Poll frequency
//  BIAS_MODE_ORDER=xor,add,mix  Escalation order (comma list)
//  BIAS_MIN_SAMPLES=30          Require at least this many variance samples
//  BIAS_LATENCY_P95_MAX=3       If verifier latency p95 exceeds, restrict to xor
//  SNAPSHOT_FILE=wheel-metrics.jsonl optional local metrics artifact
//  SNAPSHOT_MAX_READ=1200 lines to scan for recent stats
//
// Prometheus Queries (instant):
//  share accept ratio: aurrelia_share_accept_ratio
//  variance (per hw): wheel_aggregate_spin_variance_hw
//  generic variance: wheel_aggregate_spin_variance
//  verifier latency histogram: sum(rate(wheel_verifier_latency_seconds_bucket[5m])) to calc p95 (approx via buckets)
// We implement a simplified p95 by taking cumulative buckets from /api/v1/query.

const fs = require('fs');
const path = require('path');
const http = require('http');

function httpGetJson(url, timeoutMs=4000){
  return new Promise((resolve,reject)=>{
    const req = http.get(url, { timeout: timeoutMs }, res=>{
      let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ try{ resolve(JSON.parse(data)); }catch(e){ reject(e); } });
    });
    req.on('error', reject); req.on('timeout',()=>{ req.destroy(new Error('timeout')); });
  });
}

function readRecentSnapshotLines(file, maxLines){
  try {
    const stat = fs.statSync(file); if (stat.size === 0) return [];
    // Read tail portion (~ last 128k) to avoid loading huge file
    const tailBytes = 128*1024; const fd = fs.openSync(file,'r');
    const start = Math.max(0, stat.size - tailBytes);
    const buf = Buffer.alloc(stat.size - start);
    fs.readSync(fd, buf, 0, buf.length, start); fs.closeSync(fd);
    const lines = buf.toString('utf8').trim().split(/\n/);
    return lines.slice(-maxLines);
  } catch(e){ return []; }
}

function parseSnapshots(lines){
  // Expect each line JSON with fields: t, coin, aggregate, variance, verifier? etc. We'll extract variance & accept if present.
  const vars=[]; const accepts=[]; const latencies=[];
  for (const ln of lines){
    try { const o = JSON.parse(ln); if (typeof o.variance === 'number') vars.push(o.variance); if (typeof o.acceptRatio === 'number') accepts.push(o.acceptRatio); if (typeof o.verifierP95 === 'number') latencies.push(o.verifierP95); } catch(_){ }
  }
  return { vars, accepts, latencies };
}

function percentile(arr, p){ if (!arr.length) return null; const s=[...arr].sort((a,b)=>a-b); const idx = Math.min(s.length-1, Math.floor(s.length*p)); return s[idx]; }

const stateFile = path.join(process.cwd(),'adaptive-bias-state.json');
function loadState(){ try { return JSON.parse(fs.readFileSync(stateFile,'utf8')); } catch(_){ return { lastMode:null, lastChange:0, baselineVar:null, baselineAccept:null }; } }
function saveState(s){ try { fs.writeFileSync(stateFile, JSON.stringify(s,null,2)); } catch(_){ } }

async function pollPrometheus(promHost, window){
  const queries = {
    accept: `/api/v1/query?query=aurrelia_share_accept_ratio`,
    varianceHW: `/api/v1/query?query=wheel_aggregate_spin_variance_hw`,
    variance: `/api/v1/query?query=wheel_aggregate_spin_variance`,
    verifierLatencyBuckets: `/api/v1/query?query=wheel_verifier_latency_seconds_bucket`
  };
  const results = {};
  for (const [k,q] of Object.entries(queries)){
    try { const url = promHost + q; const js = await httpGetJson(url); if (js.status==='success') results[k]=js.data.result; } catch(_){ }
  }
  // Acceptance
  let accept=null; if (Array.isArray(results.accept) && results.accept.length){ try { accept = parseFloat(results.accept[0].value[1]); } catch(_){ } }
  // Variance
  let variances=[];
  if (Array.isArray(results.varianceHW) && results.varianceHW.length){ for (const r of results.varianceHW){ try { variances.push(parseFloat(r.value[1])); }catch(_){ } } }
  if (!variances.length && Array.isArray(results.variance) && results.variance.length){ for (const r of results.variance){ try { variances.push(parseFloat(r.value[1])); }catch(_){ } } }
  const varianceAvg = variances.length ? variances.reduce((a,b)=>a+b,0)/variances.length : null;
  // Verifier latency p95 approximation from buckets (instant snapshot)
  let verifierP95=null;
  try {
    const buckets = results.verifierLatencyBuckets || [];
    // Aggregate counts by 'le'
    const agg = new Map();
    for (const series of buckets){
      const le = series.metric && series.metric.le; if (!le) continue;
      const valStr = series.value && series.value[1]; const val = parseFloat(valStr); if (isNaN(val)) continue;
      agg.set(le, (agg.get(le)||0)+val);
    }
    if (agg.size){
      const sorted = [...agg.entries()].filter(([le])=>le!=='+Inf').map(([le,v])=>({ le: parseFloat(le), v })).sort((a,b)=>a.le-b.le);
      if (sorted.length){
        const total = sorted[sorted.length-1].v;
        if (total>0){
          const target = total*0.95;
            for (const b of sorted){ if (b.v >= target){ verifierP95 = b.le; break; } }
        }
      }
    }
  } catch(_){ }
  return { accept, varianceAvg, verifierP95 };
}

function decide(nextCtx){
  const {
    varianceAvg, accept, verifierP95, state, cfg
  } = nextCtx;
  const now = Date.now()/1000;
  const cooldown = cfg.cooldownSec;
  const modeOrder = cfg.modeOrder;
  const current = state.lastMode || cfg.initialMode;
  // Initialize baselines if null
  if (state.baselineVar == null && varianceAvg != null) state.baselineVar = varianceAvg;
  if (state.baselineAccept == null && accept != null) state.baselineAccept = accept;
  const baselineVar = state.baselineVar || cfg.baselineVar;
  const baselineAccept = state.baselineAccept || accept || 0;
  // Re-center baselineVar slowly (EWMA) to track drift
  if (varianceAvg != null){ state.baselineVar = state.baselineVar == null ? varianceAvg : state.baselineVar*0.95 + varianceAvg*0.05; }
  // Acceptance baseline update only if improved modestly
  if (accept != null && baselineAccept>0){ state.baselineAccept = baselineAccept*0.98 + accept*0.02; }

  let desired = current;
  let reason = 'hold';
  const varTol = baselineVar * (1 + cfg.varTol);
  const acceptDeltaRaw = (accept != null && baselineAccept>0) ? (accept - baselineAccept) : 0;
  // Early ramp lowering of threshold
  const runtimeSec = now - state.startTime;
  const minAcceptDeltaEff = (runtimeSec < cfg.rampSec) ? Math.min(cfg.minAcceptDelta, cfg.rampMinAcceptDelta) : cfg.minAcceptDelta;
  const acceptDelta = acceptDeltaRaw;
  if (varianceAvg != null && varianceAvg > varTol){
    // Too turbulent: regress to safest earlier mode
    const safe = modeOrder[0];
    if (current !== safe && (now - state.lastChange) > cooldown){ desired = safe; reason = `variance ${varianceAvg.toFixed(4)} > tol ${varTol.toFixed(4)}`; }
  } else if (verifierP95 != null && verifierP95 > cfg.latencyP95Max){
    // Latency gating: regress if too high
    const safe = modeOrder[0];
    if (current !== safe && (now - state.lastChange) > cooldown){ desired = safe; reason = `latency p95 ${verifierP95.toFixed(3)} > ${cfg.latencyP95Max}`; }
  } else if (acceptDelta >= minAcceptDeltaEff && varianceAvg != null && varianceAvg <= varTol && (verifierP95 == null || verifierP95 <= cfg.latencyP95Max)){
    // Consider escalation if not already at highest mode
    const idx = modeOrder.indexOf(current);
    if (idx >=0 && idx < modeOrder.length-1 && (now - state.lastChange) > cooldown){
      desired = modeOrder[idx+1]; reason = `acceptDelta ${acceptDelta.toFixed(4)} >= ${minAcceptDeltaEff}`;
    }
  }
  return { desired, reason, current };
}

function startAdaptiveBiasController(){
  const cfg = {
    promHost: process.env.PROM_HOST || 'http://localhost:9090',
    window: process.env.PROM_QUERY_WINDOW || '5m',
    baselineVar: parseFloat(process.env.BIAS_BASELINE_VAR || '0.25'),
    varTol: parseFloat(process.env.BIAS_VAR_TOL || '0.20'),
    minAcceptDelta: parseFloat(process.env.BIAS_ACCEPT_MIN_DELTA || '0.03'),
    cooldownSec: parseInt(process.env.BIAS_COOLDOWN_SEC || '300',10),
    pollMs: parseInt(process.env.BIAS_POLL_INTERVAL_MS || '60000',10),
    modeOrder: (process.env.BIAS_MODE_ORDER || 'xor,add,mix').split(/\s*,\s*/),
    initialMode: process.env.AUR_WHEEL_EXTRANONCE_BIAS || 'xor',
    minSamples: parseInt(process.env.BIAS_MIN_SAMPLES || '30',10),
    latencyP95Max: parseFloat(process.env.BIAS_LATENCY_P95_MAX || '3'),
    rampSec: parseInt(process.env.BIAS_RAMP_SEC || '1800',10),
    rampMinAcceptDelta: parseFloat(process.env.BIAS_RAMP_MIN_ACCEPT_DELTA || '0.01'),
    snapshotFile: process.env.SNAPSHOT_FILE || path.join(process.cwd(),'wheel-metrics.jsonl'),
    snapshotMaxRead: parseInt(process.env.SNAPSHOT_MAX_READ || '1200',10)
  };
  const state = loadState();
  if (!state.startTime) state.startTime = Date.now()/1000;
  global.__AUR_ADAPTIVE_BIAS_MODE = state.lastMode || cfg.initialMode;
  console.log(`[AdaptiveBias] started with initial mode=${global.__AUR_ADAPTIVE_BIAS_MODE}`);
  // Optional Prometheus gauge
  let promGauge=null; let promClient=null; let varianceHist=null; let latencyGauge=null; let startGauge=null;
  try { promClient = require('prom-client'); } catch(_){ }
  if (promClient){
    try {
      const reg = promClient.register;
  promGauge = reg.getSingleMetric('aurrelia_adaptive_bias_mode') || new promClient.Gauge({ name:'aurrelia_adaptive_bias_mode', help:'Current extranonce adaptive bias mode (xor=0, add=1, mix=2, none=-1)', labelNames:['mode'] });
      varianceHist = reg.getSingleMetric('aurrelia_adaptive_variance_hist') || new promClient.Histogram({ name:'aurrelia_adaptive_variance_hist', help:'Observed variance samples feeding bias controller', buckets:[0.05,0.1,0.15,0.2,0.25,0.3,0.4,0.5,1] });
      latencyGauge = reg.getSingleMetric('aurrelia_verifier_latency_p95') || new promClient.Gauge({ name:'aurrelia_verifier_latency_p95', help:'Approx instantaneous verifier latency p95 seconds' });
  startGauge = reg.getSingleMetric('aurrelia_adaptive_start_ts') || new promClient.Gauge({ name:'aurrelia_adaptive_start_ts', help:'Epoch seconds when adaptive bias controller started' });
  try { startGauge.set(state.startTime); } catch(_){ }
      setGauge(global.__AUR_ADAPTIVE_BIAS_MODE);
    } catch(_){ }
  }

  function setGauge(mode){
    if (!promGauge) return;
    const map = { none:-1, xor:0, add:1, mix:2 };
    const val = map[mode] != null ? map[mode] : -1;
    try { promGauge.reset(); promGauge.labels(mode).set(val); } catch(_){ }
  }

  async function loop(){
    try {
      let varianceAvg=null, accept=null, verifierP95=null;
      // Primary: Prometheus
      const prom = await pollPrometheus(cfg.promHost, cfg.window).catch(()=>null);
      if (prom){ varianceAvg = prom.varianceAvg; accept = prom.accept; verifierP95 = prom.verifierP95; }
      // Secondary fallback: snapshot JSONL
      if (varianceAvg == null){
        const lines = readRecentSnapshotLines(cfg.snapshotFile, cfg.snapshotMaxRead);
        const parsed = parseSnapshots(lines);
        if (parsed.vars.length >= cfg.minSamples){
          varianceAvg = parsed.vars.reduce((a,b)=>a+b,0)/parsed.vars.length;
        }
        if (parsed.accepts.length){ accept = parsed.accepts[parsed.accepts.length-1]; }
      }
      if (varianceAvg == null && accept == null){ return schedule(); }
      // Observe metrics
      if (varianceHist && varianceAvg != null) varianceHist.observe(varianceAvg);
      if (latencyGauge && verifierP95 != null) latencyGauge.set(verifierP95);
      const { desired, reason, current } = decide({ varianceAvg, accept, verifierP95, state, cfg });
      if (desired !== current){
        const now = Date.now()/1000; state.lastMode = desired; state.lastChange = now;
        global.__AUR_ADAPTIVE_BIAS_MODE = desired;
        saveState(state);
        console.log(`[AdaptiveBias] mode change ${current} -> ${desired} (${reason}) var=${varianceAvg!=null?varianceAvg.toFixed(4):'n/a'} accept=${accept!=null?accept.toFixed(4):'n/a'} p95=${verifierP95!=null?verifierP95.toFixed(3):'n/a'}`);
        setGauge(desired);
      }
    } catch(e){ /* silent */ }
    schedule();
  }
  function schedule(){ setTimeout(loop, cfg.pollMs).unref(); }
  schedule();
}

module.exports = { startAdaptiveBiasController };
