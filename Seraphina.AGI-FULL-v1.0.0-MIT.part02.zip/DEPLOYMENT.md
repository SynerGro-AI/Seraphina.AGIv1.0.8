# Deployment Guide (Deterministic Real Mining)

## 1. Objectives
Provide a reproducible, deterministic deployment for the Aurrelia/Seraphina mining stack with:
- Real Stratum mining (BTC/RVN/KAS/FREN optional) – no simulation.
- Integrity-protected ledgers (share, swap, parity, econ realization, price) with hash + optional HMAC.
- Deterministic economic data blending (Coingecko + Kraken with fallback hashing).
- Risk-controlled autonomous swaps.

## 2. Host Requirements
- OS: Windows 10/11 or Linux x86_64 (Node.js >= 18 LTS).
- Memory: >= 2 GB free (more if GPU hashing modules compiled).
- Disk: Fast SSD (ledger append pattern is sequential; low fragmentation helps).
- Network: Stable low-latency to mining pools & Kraken public API.

## 3. Node & Dependencies
Install Node.js 18+ (LTS). Then inside `mining/`:
```
npm install
```
GPU / kawpow native (optional):
```
npm run build:kawpow
```
(Ensure toolchain for node-gyp present.)

## 4. Environment Configuration (.env)
Key required variables (see `.env.bak`):
- REAL_STRICT=1 : Enforces integrity & aborts on signature mismatch.
- BTC_MINING_ADDRESS, RVN_LOCAL_ADDRESS, etc.
- RPC_*_URL / USER / PASS for each coin/pool.
- SIMPLESWAP_API_KEY + SIMPLESWAP_MODE=auto (enable swap logic; set `SIMPLESWAP_LIVE=1` only after dry-run confidence).
- LEDGER_HMAC_KEY (root default HMAC secret) + optional specific: SHARE_LEDGER_HMAC_KEY, SWAP_LEDGER_HMAC_KEY, BALANCE_HMAC_KEY, PARITY_LEDGER_HMAC_KEY.
- KRAKEN_FEED_ENABLED=1 for blended pricing.
- BALANCE_PERSIST_INTERVAL_MS (e.g. 60000) and BALANCE_ENCRYPT=1 + VAULT_PASS for at-rest encryption.

Risk control tuning:
- SWAP_RISK_WINDOW_MS, SWAP_MAX_WINDOW_COUNT, SWAP_FAIL_LIMIT, SWAP_CIRCUIT_AUTO_RESET_MS.
- RVN_SWAP_THRESHOLD (and other coin thresholds) to trigger autoswaps.

## 5. Deterministic Fallbacks
- Kraken fallback uses SHA256(pair|seed) – configure `KRAKEN_FALLBACK_SEED` to lock synthetic price space.
- Swap adapter dry-run rates hash from pair; live mode only when explicitly enabled.

## 6. Startup
```
node aurrelia-pico-mesh-miner.js
```
Optional coin selection via env `AUR_COIN=rvn` etc.
Expose metrics/report endpoints behind reverse proxy (optional). Ensure firewall allows mining pool outbound ports only.

## 7. Multi-Rig / Horizontal
- Each rig uses distinct WORKER_NAME but shared payout addresses.
- Central aggregator can tail ledgers from each rig (rsync or periodic snapshot) and recompute chain integrity.
- Consider dedicated HMAC key per rig + master auditor key to build a higher-level Merkle root across rigs.

## 8. Backup & Rotation
- Append-only ledgers: implement external logrotate (copy & compress older lines) then store last chain_hash to seed next segment.
- Back up encrypted `balances.json` and all `*-ledger.jsonl` hourly.

## 9. Secure Secrets Handling
- NEVER commit .env to repo.
- Provide secrets via secure secret manager or machine-level protected store.
- Replace keys periodically – rollover by supporting dual verification window (derive alternate HMAC on read then rewrite with new key).

## 10. Observability
- Prometheus metrics via `prom-client` (ensure endpoint exposed or scraped).
- `/readiness` and `/report/*` endpoints integrate into monitoring (alert if `readiness.ok` false or circuitOpen true > threshold time).

## 11. Swap Operational Runbook
1. Run with SIMPLESWAP_MODE=auto; leave SIMPLESWAP_LIVE unset to observe dry-run exec & settlement simulation.
2. Validate swap-ledger continuity & risk counters.
3. Set `SIMPLESWAP_LIVE=1` and small thresholds for pilot (e.g. RVN_SWAP_THRESHOLD=10) before scaling.
4. Review PnL via `/report/pnl` and econ-realization ledger chain integrity.

## 12. Recovery Procedures
- If ledger HMAC mismatch under REAL_STRICT: system aborts; isolate host, diff ledger vs backup, identify first broken chain_hash line, reconstruct or mark truncated.
- If swap circuit opens: inspect reasons (failure counts), optionally reset by clearing env forcing close or waiting auto reset.

## 13. Hardening
- Run under least-privileged OS user.
- Set `NODE_OPTIONS=--no-experimental-fetch` if not used; lock Node flags.
- Optionally chroot / containerize; mount ledgers on dedicated volume.

## 14. Compliance & Audit
- Keep an external script that recomputes all chain hashes (share, parity, swap, econ, price) nightly and emits a Merkle root signed by a hardware key.

---
End Deployment Guide.
