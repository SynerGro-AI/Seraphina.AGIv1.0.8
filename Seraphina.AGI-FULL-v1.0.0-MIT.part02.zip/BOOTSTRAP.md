# Seraphina / Aurrelia Miner USB Bootstrap (Ubuntu)

This guide covers installing the miner from a prepared USB flash drive onto a fresh Ubuntu system (MSI motherboard, Raspberry Pi, BigTreeTech boards) with automated services.

## Contents Expected on USB
- Entire `mining/` workspace (excluding heavy dev artifacts if desired)
- `install-seraphina.sh` bootstrap script
- `artifact-hashes.json` (pre-generated or to be generated on target)
- Optionally: `node-vX.Y.Z-linux-x64` tarball if offline

## Quick Install
```bash
sudo bash install-seraphina.sh /media/usb/mining /opt/seraphina
```
Arguments:
1. Source directory (USB mount path) containing the mining workspace.
2. Destination directory for runtime deployment.

Environment overrides (set before script):
- `SERAPHINA_USER` (default seraphina)
- `MONITOR_INTERVAL_SEC` (default 300)
- `AUDIT_MONITOR_MIN_INTERVAL_MS` (default 240000)
- `ENABLE_TIMER=0` to disable audit monitor scheduling
- `TEXTFILE_DIR` for Prometheus textfile collector target

## What the Script Does
1. Installs Node.js LTS if missing.
2. Creates dedicated unprivileged user.
3. Rsyncs workspace to destination (excluding `node_modules` for fresh install).
4. Performs production dependency install (omits dev).
5. Generates `artifact-hashes.json` if absent.
6. Installs systemd miner service + optional audit monitor timer.
7. Enables and starts services immediately.
8. Wires Prometheus textfile export (copies `chain-tips.prom` if present).

## Systemd Units
- Service: `seraphina-miner.service` launches `aurrelia-pico-mesh-miner.js`.
- Timer/Service: `seraphina-monitor.timer` triggers `seraphina-monitor.service` (audit-monitor + Prom export).

## Post-Install Verification
```bash
systemctl status seraphina-miner.service --no-pager
journalctl -u seraphina-miner.service -n 50 --no-pager
systemctl status seraphina-monitor.timer --no-pager
ls -l /opt/seraphina/chain-tips.json
ls -l /var/lib/node_exporter/textfile/chain-tips.prom
```

## Integrity & Audit
Manual trigger:
```bash
cd /opt/seraphina
sudo -u seraphina npm run audit:all
sudo -u seraphina npm run export:tips:prom
```

## Vault / HMAC Key Handling
Set vault env before generating manifest (if regenerating on target):
```bash
export VAULT_PASS="<vault-pass>"
export VAULT_MANIFEST_KEY_LABEL="manifest_hmac_key"
node generate-usb-manifest.js
```

## Optional Offline Prep
If deploying to air-gapped system:
1. Download Node.js binaries and place in USB root.
2. Pre-install dependencies on staging host and include `node_modules`.
3. Verify manifest (`verify-manifest.js`) before transport.

## Safe Update Procedure
```bash
sudo systemctl stop seraphina-miner.service
rsync -a --delete /media/usb/mining/ /opt/seraphina/
cd /opt/seraphina && npm install --omit=dev
sudo -u seraphina npm run full:package
sudo systemctl start seraphina-miner.service
```
Check audit root consistency after update.

## Troubleshooting
| Symptom | Action |
|---------|--------|
| Miner service fails start | `journalctl -u seraphina-miner.service -n 100` |
| Audit monitor missing prom file | Run `npm run export:tips:prom` manually |
| HMAC seal absent | Ensure `USB_MANIFEST_HMAC_KEY` or vault variables set |
| Stratum auth failures | Validate pool credentials in `.env` or environment |
| High restart frequency | Inspect logs for pool connectivity / addon errors |

## Removal
```bash
sudo systemctl disable --now seraphina-monitor.timer || true
sudo systemctl disable --now seraphina-miner.service
sudo rm -f /etc/systemd/system/seraphina-monitor.* /etc/systemd/system/seraphina-miner.service
sudo rm -rf /opt/seraphina
sudo systemctl daemon-reload
```

---
All core scripts (miner, audits, manifest generation, monitoring) are self-contained for portability.
