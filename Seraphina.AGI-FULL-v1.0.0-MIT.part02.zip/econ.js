"use strict";
// econ.js – profitability polling + RVN/FREN priority override + hysteresis + lag-aware autoswitch
// Exports: initEcon(onRecommend), forceUpdate(), state

const https = require('https');
const http = require('http');
let prom=null; try { prom=require('prom-client'); } catch(_){}

function fetchJson(url){
  return new Promise(res=>{
    const mod = url.startsWith('https')? https : http;
    const t=Date.now();
    const rq = mod.get(url, r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try { res({ data: JSON.parse(d), lat: Date.now()-t }); } catch(_){ res({ data:null, lat: Date.now()-t }); } }); });
    rq.on('error',()=> res({ data:null, lat: Date.now()-t }));
    rq.setTimeout(5000,()=>{ rq.destroy(); res({ data:null, lat: Date.now()-t }); });
  });
}
function fetchText(url){
  return new Promise(res=>{
    const mod = url.startsWith('https')? https : http;
    const t=Date.now();
    const rq = mod.get(url, r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=> res({ data:d.trim(), lat: Date.now()-t })); });
    rq.on('error',()=> res({ data:null, lat: Date.now()-t }));
    rq.setTimeout(5000,()=>{ rq.destroy(); res({ data:null, lat: Date.now()-t }); });
  });
}

const state = { price:{}, diff:{}, recommend:null, override:0, stableCycles:0, last:0, lagSamples:[], lagMax:32 };

const PRIORITY_ON = process.env.AUR_PRIORITY_RVN_FREN !== '0';
const PRIORITY_THRESHOLD = parseFloat(process.env.AUR_PRIORITY_THRESH || '0.90');
const PRIORITY_SEQUENCE = (process.env.AUR_PRIORITY_ORDER ? process.env.AUR_PRIORITY_ORDER.split(',').map(s=>s.trim()).filter(Boolean) : ['rvn','fren']);

let gauges=null;
function ensureGauges(){
  if (!prom || gauges) return;
  try {
    gauges = {
      rec: new prom.Gauge({ name:'aurrelia_coin_recommendation', help:'Recommended coin (0=other,1=rvn,2=btc,3=kas,4=fren)' }),
      prio: new prom.Gauge({ name:'aurrelia_coin_priority_override', help:'1 if RVN/FREN priority override applied' }),
      stable: new prom.Gauge({ name:'aurrelia_coin_stable_cycles', help:'Consecutive stable recommendation cycles' }),
      lag: new prom.Gauge({ name:'aurrelia_coin_net_lag_ms', help:'Median network fetch latency ms' })
    };
  } catch(_){}
}

function median(a){ if(!a.length) return null; const s=[...a].sort((x,y)=>x-y); const m=Math.floor(s.length/2); return s.length%2? s[m] : (s[m-1]+s[m])/2; }

async function poll(onRecommend){
  const now = Date.now();
  const interval = parseInt(process.env.AUR_ECON_INTERVAL_MS || (6*60*60*1000).toString(),10);
  if (now - state.last < interval) return;
  state.last = now;
  // Prices
  const priceResp = await fetchJson('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ravencoin,kaspa,frencoin&vs_currencies=usd');
  if (priceResp.data){ state.price.btc=priceResp.data.bitcoin?.usd; state.price.rvn=priceResp.data.ravencoin?.usd; state.price.kas=priceResp.data.kaspa?.usd; state.price.fren=priceResp.data.frencoin?.usd; }
  if (priceResp.lat!=null){ recordLatency(priceResp.lat); }
  // Difficulties (parallel)
  const diffUrls = {
    btc:'https://blockchain.info/q/getdifficulty',
    rvn:'https://ravencoin.network/api/v2/network/difficulty',
    kas:'https://api.kaspa.org/insights/difficulty',
    fren: process.env.FREN_DIFF_URL || 'https://explorer.frencoin.org/api/getdifficulty'
  };
  const diffResults = await Promise.all(Object.entries(diffUrls).map(async ([k,u])=>({ k, r: await fetchText(u) })));
  diffResults.forEach(o=>{ if (o.r.data) state.diff[o.k] = parseFloat(o.r.data); if (o.r.lat!=null) recordLatency(o.r.lat); });
  // Profitability score base: price/diff; augment with block reward for mined coins (except BTC already implicit).
  const BLOCK_REWARD = {
    btc: parseFloat(process.env.BTC_BLOCK_REWARD || '3.125'),
    rvn: parseFloat(process.env.RVN_BLOCK_REWARD || '5000'),
    kas: parseFloat(process.env.KAS_BLOCK_REWARD || '110'),
    fren: parseFloat(process.env.FREN_BLOCK_REWARD || '1000')
  };
  const scores={}; ['btc','rvn','kas','fren'].forEach(c=>{
    if(state.price[c] && state.diff[c]){
      const base = state.price[c] * (BLOCK_REWARD[c]||1) / state.diff[c];
      scores[c] = base;
    }
  });
  // Track FREN revenue per hash separately (normalized) for ML feature consumption.
  if (scores.fren){
    state.frenRevenuePerHash = scores.fren;
    // Volatility smoothing via simple EMA over revenue metric
    const alpha = parseFloat(process.env.FREN_VOL_ALPHA || '0.3');
    if (typeof state.frenRevenuePerHashSmoothed !== 'number') state.frenRevenuePerHashSmoothed = state.frenRevenuePerHash;
    state.frenRevenuePerHashSmoothed = (alpha * state.frenRevenuePerHash) + ((1-alpha) * state.frenRevenuePerHashSmoothed);
  }
  if (Object.keys(scores).length < 2) return;
  let bestCoin=null; let bestScore=-Infinity; state.override=0;
  for (const [c,s] of Object.entries(scores)){ if (s>bestScore){ bestScore=s; bestCoin=c; } }
  if (PRIORITY_ON && bestScore>0){
    for (const pc of PRIORITY_SEQUENCE){ const sc=scores[pc]; if (sc!=null && sc >= bestScore*PRIORITY_THRESHOLD){ if (bestCoin!==pc) state.override=1; bestCoin=pc; break; } }
  }
  if (state.recommend === bestCoin) state.stableCycles++; else { state.stableCycles=1; state.recommend=bestCoin; }
  const med = median(state.lagSamples);
  if (gauges){
    try {
      const map={rvn:1,btc:2,kas:3,fren:4};
      gauges.rec.set(map[bestCoin]||0);
      gauges.prio.set(state.override);
      gauges.stable.set(state.stableCycles);
      if (med!=null) gauges.lag.set(med);
    } catch(_){}
  }
  console.log(`[ECON] scores btc=${scores.btc?.toExponential(3)} rvn=${scores.rvn?.toExponential(3)} kas=${scores.kas?.toExponential(3)} fren=${scores.fren?.toExponential(3)} => ${bestCoin}${state.override?' [override]':''} stable=${state.stableCycles} medLag=${med??'na'}ms`);
  if (typeof onRecommend === 'function') onRecommend(bestCoin, { override: !!state.override, stable: state.stableCycles, medLag: med });
}

function recordLatency(ms){ if (typeof ms==='number' && isFinite(ms) && ms>=0){ state.lagSamples.push(ms); if (state.lagSamples.length>state.lagMax) state.lagSamples.shift(); } }

function initEcon(onRecommend){
  if (process.env.AUR_ECON_ENABLED !== '1') return;
  ensureGauges();
  setInterval(()=> poll(onRecommend).catch(()=>{}), 60_000).unref();
  poll(onRecommend).catch(()=>{});
}

function forceUpdate(onRecommend){ return poll(onRecommend); }

module.exports = { initEcon, forceUpdate, state };
