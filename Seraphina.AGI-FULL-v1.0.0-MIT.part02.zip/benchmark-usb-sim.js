// benchmark-usb-sim.js
// Simulates compressed USB telemetry batching to approximate throughput MB/s.
// Usage: node benchmark-usb-sim.js

const zlib = require('zlib');

function simulate(batchSize=512, iterations=5000){
  let totalOut=0; let totalIn=0;
  for(let i=0;i<iterations;i++){
    const payload = { idx: i%64, hashes: Math.floor(Math.random()*1e6), surplusW: Math.random()*200, ths: 0.95, retentionFields: Array.from({length:8},(_,k)=>({ time_min:5+k, coverage_pct:Math.random(), prior_retention:Math.random(), difficulty:0.7 })) };
    const raw = Buffer.from(JSON.stringify(payload));
    const gz = zlib.gzipSync(raw);
    totalOut += Math.min(gz.length, batchSize);
    // Simulate inbound echo
    const echo = { retentionFields: payload.retentionFields.map(f=> ({...f, predicted_retention: Math.random()})) };
    const echoRaw = Buffer.from(JSON.stringify(echo));
    const echoGz = zlib.gzipSync(echoRaw);
    totalIn += Math.min(echoGz.length, batchSize);
  }
  return { totalBytes: totalOut+totalIn, iterations };
}

function benchmark(){
  const BATCH = parseInt(process.env.USB_BATCH_SIZE || '512',10);
  const ITERS = parseInt(process.env.USB_SIM_ITERS || '8000',10);
  const start = process.hrtime.bigint();
  const res = simulate(BATCH, ITERS);
  const end = process.hrtime.bigint();
  const ms = Number(end-start)/1e6;
  const seconds = ms/1000;
  const mb = res.totalBytes/(1024*1024);
  console.log('[BenchmarkUSBSim]', JSON.stringify({ batch:BATCH, iterations:ITERS, mb, seconds, mbps: mb/seconds }));
}

if(require.main===module){ benchmark(); }
