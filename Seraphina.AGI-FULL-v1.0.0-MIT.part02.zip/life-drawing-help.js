#!/usr/bin/env node
// life-drawing-help.js
// Usage & environment reference for life drawing analytics suite.
'use strict';
const fs = require('fs');
const path = require('path');

const SECTIONS = {
  focus: {
    title: 'Adaptive Focus & Staging',
    env: [
      ['LIFE_DRAWING_FOCUS_EMPHASIS','Base multiplier for weak focus fields (default 1.25)'],
      ['LIFE_DRAWING_FOCUS_ADAPT_FACTOR','Adds weaknessPercentile * factor (default 0.5)'],
      ['LIFE_DRAWING_STAGE_DECAY_START','Session count to start time factor decay (default 10)'],
      ['LIFE_DRAWING_STAGE_DECAY_RATE','Linear decay per session after start (default 0.02)'],
      ['LIFE_DRAWING_STAGE_MIN_FACTOR','Minimum staging multiplier (default 0.5)'],
      ['LIFE_DRAWING_COMPLETENESS_MIN','Warn if per-question completeness below (default 0.5)']
    ],
    notes: [
      'EffectiveWeight = baseWeight * (FOCUS_EMPHASIS + weaknessPercentile * FOCUS_ADAPT_FACTOR)',
      'Stage multiplier lowers time benefit as sessions accumulate.'
    ]
  },
  retention: {
    title: 'Retention & Recommendation',
    env: [
      ['LIFE_DRAWING_RETENTION_HALF_LIFE','Sessions for constant presence to halve influence (default 20)'],
      ['LIFE_DRAWING_RETENTION_DECAY_FACTOR','Adaptive extra decay for heavily practiced fields (default 0.3)'],
      ['LIFE_DRAWING_RECOMMEND_ALPHA','Weight for weaknessPercentile (default 0.5)'],
      ['LIFE_DRAWING_RECOMMEND_BETA','Weight for inverse retention (default 0.5)']
    ],
    notes: [
      'recommendationScore = alpha * weaknessPercentile + beta * (1 - retention)',
      'Lower retention => less recent reinforcement / or penalized by over-practice.'
    ]
  },
  dashboard: {
    title: 'Dashboard Generation',
    env: [
      ['LIFE_DRAWING_DASHBOARD_THEME','light | dark (default light)']
    ],
    cli: [
      'node life-drawing-dashboard-gen.js theme=dark out=custom-dashboard.html'
    ]
  },
  scripts: {
    title: 'Key Scripts',
    cli: [
      'node life-drawing-session.js (consumed internally)',
      'node life-drawing-coverage-report.js --sparkline',
      'node life-drawing-trend-report.js',
      'node life-drawing-retention.js --hist',
      'node life-drawing-dashboard-gen.js theme=dark',
      'node life-drawing-next-exam-recommend.js',
      'node life-drawing-simulate-multi.js --sessions=50'
    ]
  }
};

function formatSection(key){
  const s = SECTIONS[key];
  if(!s) return '';
  let out = `\n=== ${s.title} ===\n`;
  if(s.env){ out += 'Env:\n' + s.env.map(e=> `  ${e[0]}  -> ${e[1]}`).join('\n') + '\n'; }
  if(s.cli){ out += 'CLI Examples:\n' + s.cli.map(c=> `  ${c}`).join('\n') + '\n'; }
  if(s.notes){ out += 'Notes:\n' + s.notes.map(n=> `  - ${n}`).join('\n') + '\n'; }
  return out;
}

function initEnv(){
  const example = path.join(__dirname,'.env.life-drawing.example');
  const target = path.join(__dirname,'.env.life-drawing');
  if(!fs.existsSync(example)){ console.error('Example env file missing:', example); return 1; }
  if(fs.existsSync(target)){ console.log('Env file already exists:', target); return 0; }
  fs.copyFileSync(example, target);
  console.log('Created env file:', target);
  return 0;
}

function main(){
  const args = process.argv.slice(2);
  if(args.includes('--init-env')) return process.exit(initEnv());
  const only = args.find(a=> a.startsWith('--section='));
  if(only){
    const key = only.split('=')[1];
    console.log(formatSection(key));
    return;
  }
  console.log('Life Drawing Analytics Help');
  console.log('Use --section=<focus|retention|dashboard|scripts> to view a single section.');
  console.log('Use --init-env to create local .env.life-drawing from example.');
  Object.keys(SECTIONS).forEach(k=> console.log(formatSection(k)));
}

if(require.main === module){
  main();
}

module.exports = { formatSection, initEnv };
