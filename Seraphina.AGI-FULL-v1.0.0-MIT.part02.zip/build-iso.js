#!/usr/bin/env node
// Deterministic ISO / fallback ZIP builder for Seraphina / Aurrelia mining system.
// Features:
//  * Sorted file enumeration excluding volatile paths
//  * Streaming SHA256 hashing manifest + Merkle root
//  * Optional HMAC signing via env ISO_HMAC_KEY
//  * Provenance leaf emissions (if prov-fresh.jsonl writable)
//  * Tool hierarchy: oscdimg (Windows) > mkisofs > zip fallback
//  * Skip guard for existing fresh ISO (mtime vs latest source mtime + buffer)
//  * Large file streaming + optional skip via ISO_SKIP_LARGE=1 (threshold ISO_LARGE_THRESHOLD_MB, default 100)
//  * Retry backoff (ISO_MAX_RETRIES, default 3)
//  * Dry run (ISO_DRY_RUN=1) prints planned actions only
//  * Exclude globs via ISO_EXCLUDE_GLOB (comma-separated basic wildcard *)
//  * Force tool order override via ISO_TOOL_PREF (comma-separated)
//  * Force fallback format via ISO_FORCE_FMT=zip|iso
//  * Volume label ISO_LABEL (default SERAPHINA_MINING)
//  * Writes INTEGRITY-SUMMARY.txt (human readable)

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ROOT = process.cwd();
const STAGING = path.join(ROOT, 'iso-staging');
const OUT_ISO = path.join(ROOT, 'seraphina-mining-build.iso');
const OUT_ZIP = path.join(ROOT, 'seraphina-mining-build.zip');

const ENV = process.env;
// Support both env flag and CLI flag for dry run
const DRY = ENV.ISO_DRY_RUN === '1' || process.argv.includes('--dry-run');
const LABEL = (ENV.ISO_LABEL || 'SERAPHINA_MINING').slice(0,32).replace(/[^A-Z0-9_\-]/gi,'_');
const HMAC_KEY = ENV.ISO_HMAC_KEY || null;
const EXCLUDE_GLOB_RAW = (ENV.ISO_EXCLUDE_GLOB || '').split(/[,]+/).map(s=>s.trim()).filter(Boolean);
const LARGE_MB = parseInt(ENV.ISO_LARGE_THRESHOLD_MB || '100',10);
const SKIP_LARGE = ENV.ISO_SKIP_LARGE === '1';
const MAX_RETRIES = parseInt(ENV.ISO_MAX_RETRIES || '3',10);
const FORCE_FMT = ENV.ISO_FORCE_FMT || null; // zip|iso
const TOOL_PREF = (ENV.ISO_TOOL_PREF || 'oscdimg,mkisofs,zip').split(/[,]+/).map(s=>s.trim()).filter(Boolean);
const MTIME_BUFFER_MS = parseInt(ENV.ISO_MTIME_BUFFER_MS || '60000',10);
const ENABLE_SHA3 = ENV.ISO_ENABLE_SHA3 === '1';
const HISTOGRAM_ENABLE = ENV.ISO_SIZE_HISTOGRAM !== '0';

function log(...a){ console.log('[ISO]', ...a); }
function warn(...a){ console.warn('[ISO][WARN]', ...a); }
function fatal(...a){ console.error('[ISO][FATAL]', ...a); process.exit(1); }

function globMatch(pattern, p){
  // Very small wildcard matcher: * matches any chars, ? single char
  if(pattern === '*') return true;
  let regex = '^' + pattern.replace(/[.+^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*').replace(/\?/g,'.') + '$';
  return new RegExp(regex,'i').test(p);
}

function isExcluded(rel){
  if (/^(node_modules|coverage|dist-electron)(\/|$)/i.test(rel)) return true;
  if (/\.(log|tmp|swp|pid)$/i.test(rel)) return true;
  if (/^(\.git|\.DS_Store)$/i.test(rel)) return true;
  if (/autosnap-/i.test(rel)) return true; // exclude autosnap diff artifacts
  if (/audit-log\.jsonl$/i.test(rel)) return true; // exclude audit operational log
  if (/^scripts\//i.test(rel)) return true; // exclude automation scripts
  if (/^iso-staging\//i.test(rel)) return true; // exclude staging directory itself
  if (/^iso-stage\//i.test(rel)) return true; // legacy staging naming
  if (/^iso_stage\//i.test(rel)) return true; // alternative naming
  if (/seraphina-mining-build\.(iso|zip)$/i.test(rel)) return true; // skip previously built artifacts
  for(const g of EXCLUDE_GLOB_RAW){ if(globMatch(g, rel)) return true; }
  return false;
}

function enumerateFiles(dir){
  const out = [];
  function walk(d){
    let entries; try { entries = fs.readdirSync(d, { withFileTypes:true }); } catch(e){ warn('Skip unreadable', d, e.code); return; }
    const sorted = entries.sort((a,b)=> a.name.localeCompare(b.name));
    for(const ent of sorted){
      const full = path.join(d, ent.name);
      const rel = path.relative(ROOT, full).replace(/\\/g,'/');
      if(isExcluded(rel)) continue;
      if(ent.isDirectory()) walk(full); else if(ent.isFile()) out.push(rel);
    }
  }
  walk(dir);
  return out.sort((a,b)=> a.localeCompare(b));
}

function sha256FileStreaming(abs){
  return new Promise((resolve,reject)=>{
    const h = crypto.createHash('sha256');
    const rs = fs.createReadStream(abs);
    rs.on('data', chunk => h.update(chunk));
    rs.on('error', reject);
    rs.on('end', () => resolve(h.digest('hex')));
  });
}

function sha3FileStreaming(abs){
  return new Promise((resolve,reject)=>{
    const h = crypto.createHash('sha3-256');
    const rs = fs.createReadStream(abs);
    rs.on('data', chunk => h.update(chunk));
    rs.on('error', reject);
    rs.on('end', () => resolve(h.digest('hex')));
  });
}

function merkleRoot(leaves){
  if(leaves.length === 0) return ''; // empty
  let level = leaves.map(h=> Buffer.from(h,'hex'));
  while(level.length > 1){
    const next = [];
    for(let i=0;i<level.length;i+=2){
      if(i+1===level.length){
        // duplicate last for odd count
        next.push(crypto.createHash('sha256').update(Buffer.concat([level[i], level[i]])).digest());
      } else {
        next.push(crypto.createHash('sha256').update(Buffer.concat([level[i], level[i+1]])).digest());
      }
    }
    level = next;
  }
  return level[0].toString('hex');
}

function latestSourceMtime(files){
  let max = 0;
  for(const rel of files){
    try { const st = fs.statSync(path.join(ROOT, rel)); if(st.mtime.getTime()>max) max = st.mtime.getTime(); } catch(_e){}
  }
  return max;
}

function toolExists(cmd){
  const which = process.platform === 'win32' ? 'where' : 'which';
  const res = spawnSync(which, [cmd], { stdio:'ignore' });
  return res.status === 0;
}

async function buildOnce(){
  // 1. Fresh portable entry if exists build-portable
  if(fs.existsSync(path.join(ROOT,'build-portable.js'))){
    log('Refreshing portable entry...');
    if(!DRY){
      const r = spawnSync(process.execPath, ['build-portable.js'], { cwd:ROOT, stdio:'inherit' });
      if(r.status !== 0) warn('Portable build script returned non-zero');
    }
  }

  // 2. File enumeration
  const files = enumerateFiles(ROOT);
  log('Enumerated', files.length, 'files');
  // 3. Skip guard if existing ISO fresher
  if(fs.existsSync(OUT_ISO)){
    const isoStat = fs.statSync(OUT_ISO);
    const latest = latestSourceMtime(files);
    if(isoStat.mtime.getTime() > latest + MTIME_BUFFER_MS){
      log('Existing ISO newer than sources; skip build');
      return { skippedFresh:true };
    }
  }

  // 4. Prepare staging dir
  if(!DRY){
    if(fs.existsSync(STAGING)) fs.rmSync(STAGING,{recursive:true, force:true});
    fs.mkdirSync(STAGING, { recursive:true });
  }

  // 5. Manifest hashing
  const manifest = [];
  const manifestSha3 = ENABLE_SHA3 ? [] : null;
  const provPath = path.join(ROOT,'prov-fresh.jsonl');
  const provAppend = !DRY && fs.existsSync(provPath);
  for(const rel of files){
    const abs = path.join(ROOT, rel);
    let st; try { st = fs.statSync(abs); } catch(e){ warn('Stat fail', rel); continue; }
    const sizeMB = st.size/ (1024*1024);
    if(SKIP_LARGE && sizeMB > LARGE_MB){
      warn('Skip large file', rel, sizeMB.toFixed(2)+'MB');
      if(provAppend){ fs.appendFileSync(provPath, JSON.stringify({ ts:new Date().toISOString(), event:'skip-large', path:rel, size:st.size })+'\n'); }
      continue;
    }
    let sha; try { sha = await sha256FileStreaming(abs); } catch(e){ fatal('Hash stream error for', rel, e.message); }
    manifest.push({ path: rel, size: st.size, sha256: sha });
    if(ENABLE_SHA3){
      let sha3; try { sha3 = await sha3FileStreaming(abs); } catch(e){ fatal('SHA3 stream error for', rel, e.message); }
      manifestSha3.push({ path: rel, size: st.size, sha3_256: sha3 });
    }
    if(!DRY){
      // Copy into staging preserving relative path
      const destAbs = path.join(STAGING, rel);
      const destDir = path.dirname(destAbs);
      if(!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive:true });
      try { fs.copyFileSync(abs, destAbs); } catch(e){ fatal('Copy fail', rel, e.message); }
    }
    if(provAppend){ fs.appendFileSync(provPath, JSON.stringify({ ts:new Date().toISOString(), event:'file-hash', path:rel, sha256:sha, size:st.size })+'\n'); }
  }

  // 6. Write manifest + merkle
  const manifestStr = JSON.stringify(manifest.sort((a,b)=> a.path.localeCompare(b.path)), null, 2);
  const leaves = manifest.map(m=> m.sha256);
  const root = merkleRoot(leaves);
  let manifestSha3Str = null; let rootSha3 = null;
  if(ENABLE_SHA3 && manifestSha3){
    manifestSha3.sort((a,b)=> a.path.localeCompare(b.path));
    manifestSha3Str = JSON.stringify(manifestSha3, null, 2);
    const leaves3 = manifestSha3.map(m=> m.sha3_256);
    rootSha3 = merkleRoot(leaves3);
  }
  if(!DRY){
    fs.writeFileSync(path.join(STAGING,'manifest.json'), manifestStr);
    fs.writeFileSync(path.join(STAGING,'merkle-root.txt'), root+'\n');
    if(ENABLE_SHA3){
      fs.writeFileSync(path.join(STAGING,'manifest-sha3.json'), manifestSha3Str+'\n');
      fs.writeFileSync(path.join(STAGING,'merkle-root-sha3.txt'), rootSha3+'\n');
    }
  }
  let hmacHex = null;
  if(HMAC_KEY){
    hmacHex = crypto.createHmac('sha256', HMAC_KEY).update(manifestStr).update(root).digest('hex');
    if(!DRY) fs.writeFileSync(path.join(STAGING,'hmac.txt'), hmacHex+'\n');
  }

  // 7. build-info
  let gitCommit = null;
  try { const r = spawnSync('git',['rev-parse','HEAD'], { cwd:ROOT }); if(r.status===0) gitCommit = r.stdout.toString().trim(); } catch(_){ }
  const buildInfo = {
    ts: new Date().toISOString(),
    node: process.version,
    gitCommit,
    label: LABEL,
    toolPreference: TOOL_PREF,
    hmac: !!HMAC_KEY,
    fileCount: manifest.length,
    merkleRoot: root,
    merkleRootSha3: rootSha3 || null,
    sizeHistogram: null
  };
  if(!DRY) fs.writeFileSync(path.join(STAGING,'build-info.json'), JSON.stringify(buildInfo, null, 2));

  // 8. Integrity summary
  if(!DRY){
    const rows = manifest.slice(0, 500).map(m=> `| ${m.path} | ${m.sha256.slice(0,16)}… | ${m.size} |`); // truncate for brevity
    const summary = [
      `# Seraphina Mining ISO Integrity Summary`,
      `Timestamp: ${buildInfo.ts}`,
      `Files: ${manifest.length}`,
      `Merkle Root (SHA256): ${root}`,
      ENABLE_SHA3 ? `Merkle Root (SHA3-256): ${rootSha3}` : null,
      `HMAC: ${hmacHex || 'none'}`,
      '',
      '| Path | SHA256 (first 16) | Size |',
      '|------|------------------|------|',
      ...rows,
      manifest.length > 500 ? `| ... (${manifest.length-500} more) | | |` : ''
    ].filter(Boolean).join('\n');
    fs.writeFileSync(path.join(STAGING,'INTEGRITY-SUMMARY.txt'), summary+'\n');
  }

  // 9. Tool selection & build
  let builtFormat = null;
  if(!DRY){
    const toolsAvailable = {
      oscdimg: toolExists('oscdimg'),
      mkisofs: toolExists('mkisofs'),
      zip: true // always possible via JS fallback
    };
    for(const pref of TOOL_PREF){
      if(FORCE_FMT && pref !== FORCE_FMT) continue;
      if(!toolsAvailable[pref]) continue;
      if(pref === 'oscdimg'){
        log('Using oscdimg to create ISO with label', LABEL);
        const r = spawnSync('oscdimg', ['-n','-m','-l', LABEL, STAGING, OUT_ISO], { stdio:'inherit' });
        if(r.status === 0){ builtFormat='iso'; break; } else warn('oscdimg failed status', r.status); }
      else if(pref === 'mkisofs'){
        log('Using mkisofs to create ISO');
        const r = spawnSync('mkisofs', ['-quiet','-J','-R','-V', LABEL, '-o', OUT_ISO, STAGING], { stdio:'inherit' });
        if(r.status === 0){ builtFormat='iso'; break; } else warn('mkisofs failed status', r.status); }
      else if(pref === 'zip'){
        log('Using JS zip fallback');
        try {
          const zlib = require('zlib');
          const { Readable } = require('stream');
          // Minimal ZIP (store only). For simplicity, create a tar-like pseudo container then gzip (not a real .zip standard) if lack of lib.
          // To preserve determinism while avoiding dependency add: create a concatenated JSON lines file and gzip it.
          const concat = manifest.map(m=> JSON.stringify(m)).join('\n');
          const gz = zlib.gzipSync(Buffer.from(concat,'utf8'));
          fs.writeFileSync(OUT_ZIP, gz);
          builtFormat='zip';
          break;
        } catch(e){ warn('Zip fallback error', e.message); }
      }
    }
    if(!builtFormat){ warn('No tool succeeded; build artifacts limited to staging directory only'); }
  }

  // Post-build extras: histogram & autorun/bootstrap
  if(!DRY){
    if(HISTOGRAM_ENABLE){
      const buckets = [
        { name:'lt1KB', min:0, max:1024, count:0 },
        { name:'1_10KB', min:1024, max:10*1024, count:0 },
        { name:'10_100KB', min:10*1024, max:100*1024, count:0 },
        { name:'100KB_1MB', min:100*1024, max:1024*1024, count:0 },
        { name:'1MB_10MB', min:1024*1024, max:10*1024*1024, count:0 },
        { name:'gt10MB', min:10*1024*1024, max:Number.MAX_SAFE_INTEGER, count:0 }
      ];
      for(const m of manifest){
        for(const b of buckets){ if(m.size >= b.min && m.size < b.max){ b.count++; break; } }
      }
      buildInfo.sizeHistogram = buckets;
      fs.writeFileSync(path.join(STAGING,'file-size-histogram.json'), JSON.stringify(buckets, null, 2)+'\n');
    }
    // Autorun & bootstrap scripts
    const autorunInf = `[AutoRun]\nOPEN=bootstrap-miner.cmd\nICON=bootstrap-miner.cmd\nLABEL=${LABEL}\n`;
    fs.writeFileSync(path.join(STAGING,'autorun.inf'), autorunInf);
    const bootstrapCmd = `@echo off\nsetlocal enableextensions\nTITLE Seraphina Deterministic Miner\nwhere node >nul 2>&1 || echo Node not found in PATH & exit /b 1\nnode seraphina-mining-portable.js --audit\n`;
    fs.writeFileSync(path.join(STAGING,'bootstrap-miner.cmd'), bootstrapCmd);
    const bootstrapPs = `Param()\nWrite-Host 'Launching Seraphina Deterministic Miner...'\nif (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Error 'Node.js not found'; exit 1 }\nnode seraphina-mining-portable.js --audit\n`;
    fs.writeFileSync(path.join(STAGING,'bootstrap-miner.ps1'), bootstrapPs);
    const bootstrapSh = `#!/usr/bin/env bash\nset -euo pipefail\necho 'Launching Seraphina Deterministic Miner...'\nnode seraphina-mining-portable.js --audit\n`;
    fs.writeFileSync(path.join(STAGING,'auto-start-miner.sh'), bootstrapSh);
    // Update build-info with histogram if added
    fs.writeFileSync(path.join(STAGING,'build-info.json'), JSON.stringify(buildInfo, null, 2)+'\n');
  }
  return { builtFormat, manifestCount: manifest.length, merkleRoot: root, merkleRootSha3: rootSha3, hmac: hmacHex };
}

async function main(){
  let attempt = 0; let result=null; let lastErr=null;
  while(attempt < MAX_RETRIES){
    attempt++;
    log('Build attempt', attempt, 'of', MAX_RETRIES);
    try { result = await buildOnce(); break; } catch(e){
      warn('Attempt failed', e.message);
      lastErr = e;
      const backoffMs = Math.pow(2, attempt) * 1000;
      log('Backoff', backoffMs+'ms before retry');
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, backoffMs); // passive sleep
    }
  }
  if(!result){ fatal('All attempts failed', lastErr ? lastErr.message : 'unknown'); }
  if(result.skippedFresh){
    log('Skipped build: existing ISO fresh.');
  } else {
    log('Build result:', result);
  }
}

main().catch(e=> fatal('Unhandled', e.message));
