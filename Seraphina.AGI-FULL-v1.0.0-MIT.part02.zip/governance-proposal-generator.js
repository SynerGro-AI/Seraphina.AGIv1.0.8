// governance-proposal-generator.js
// Deterministic helper to craft governance proposals with projected approval outcome.
// Usage examples:
//  node governance-proposal-generator.js --id=proposal-123 --param GLOBAL_MIN_IMPROVEMENT=0.05 --param IMAGINATION_GAIN_WEIGHT=1.2 --participants=addr1,addr2,... [--emit]
//  node governance-proposal-generator.js --id=raise-floor --param GLOBAL_MIN_IMPROVEMENT=0.03 --participants addrA,addrB,addrC
// Multi-set simulation (dry-run only):
//  node governance-proposal-generator.js --id=raise-floor --param GLOBAL_MIN_IMPROVEMENT=0.03 --sets=addrA,addrB;addrC,addrD,addrE
// Flags:
//  --emit                actually append proposal to governance-proposals.jsonl after validation
//  --participants[=]LIST single participant set (comma separated)
//  --sets=SET1;SET2;...  multiple participant sets for projection (each comma separated)
// New governance params (examples):
//  SANDBOX_ENABLED (0/1) – enable sandbox intrinsic motivation layer
//  CURIOSITY_GAIN_WEIGHT (0..5) – weight applied to sandbox curiosity in effective improvement
//  (Existing) IMAGINATION_GAIN_WEIGHT, GLOBAL_MIN_IMPROVEMENT, IMAGINATION_MAX_SCENARIOS
// Schema validation ensures:
//  - id: non-empty string
//  - params: keys within allowed PARAM_BOUNDS (loaded dynamically from governance-engine if available) numeric parseable
//  - participants: non-empty array of distinct strings
// If validation fails on emit, exits non-zero.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const PROP_FILE = process.env.GOV_PROPOSALS_PATH || 'governance-proposals.jsonl';
const APPROVAL_PCT = parseInt(process.env.GOV_APPROVAL_PCT || '60',10);
// Attempt to load governance-engine bounds for validation (avoid circular require issues gracefully)
let PARAM_BOUNDS = null;
try { PARAM_BOUNDS = require('./governance-engine.js').PARAM_BOUNDS || null; } catch(_) { PARAM_BOUNDS = null; }

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x : JSON.stringify(x)).digest('hex'); }

function parseArgs(){
  const args = process.argv.slice(2);
  const out={ id:null, params:{}, participants:[], emit:false, sets:[] };
  let i=0;
  while(i<args.length){
    const a=args[i];
    if(a.startsWith('--id=')) out.id = a.substring(5);
    else if(a==='--emit') out.emit=true;
    else if(a.startsWith('--param')){
      const kv = a.split('=');
      if(kv.length===3){ const key=kv[1].trim(); const val=kv[2]; out.params[key]=val; }
    } else if(a.startsWith('--participants=')){
      const list = a.split('=')[1];
      out.participants = list.split(',').map(s=>s.trim()).filter(Boolean);
    } else if(a==='--participants'){ // space separated list next arg
      const list = args[i+1] || '';
      out.participants = list.split(',').map(s=>s.trim()).filter(Boolean); i++; // consume next token
    } else if(a.startsWith('--sets=')){
      const raw = a.split('=')[1];
      const groups = raw.split(';').map(g=> g.split(',').map(s=>s.trim()).filter(Boolean)).filter(g=>g.length);
      out.sets = groups;
    }
    i++;
  }
  return out;
}

function validateProposal(id, params, participants){
  if(!id || typeof id !== 'string' || !id.trim()) return { ok:false, reason:'invalid-id' };
  if(!participants || !Array.isArray(participants) || !participants.length) return { ok:false, reason:'no-participants' };
  const distinct = new Set(participants);
  if(distinct.size !== participants.length) return { ok:false, reason:'duplicate-participants' };
  // If PARAM_BOUNDS present, ensure params keys allowed and parse numeric
  if(PARAM_BOUNDS){
    for(const [k,v] of Object.entries(params)){
      if(!(k in PARAM_BOUNDS)) return { ok:false, reason:'param-key-out-of-bounds:'+k };
      const num = parseFloat(v);
      if(!isFinite(num)) return { ok:false, reason:'non-numeric-value:'+k };
      const [min,max] = PARAM_BOUNDS[k];
      if(num < min || num > max) return { ok:false, reason:'value-out-of-range:'+k };
    }
  }
  return { ok:true };
}

function projectApproval(participants){
  let approvals=0;
  for(const addr of participants){
    const h = sha256(addr);
    const shard = parseInt(h.slice(0,8),16) % 100;
    if(shard < APPROVAL_PCT) approvals++;
  }
  const rate = participants.length? approvals/participants.length : 0;
  return { approvals, total: participants.length, approvalRate: rate, willApprove: (rate*100) >= APPROVAL_PCT };
}

function emitProposal(p){
  const entry = { id: p.id, t: Date.now(), params: p.params, participants: p.participants };
  fs.appendFileSync(PROP_FILE, JSON.stringify(entry)+'\n');
  return entry;
}

function main(){
  const cfg = parseArgs();
  if(!cfg.id){ console.error('Missing --id'); process.exit(1); }
  // Multi-set simulation mode if --sets provided (ignores single participants for projection array)
  let simulations=[];
  if(cfg.sets && cfg.sets.length){
    for(const set of cfg.sets){
      const proj = projectApproval(set);
      simulations.push({ participants:set.length, approvalRate:Number(proj.approvalRate.toFixed(4)), willApprove:proj.willApprove, sample:set.slice(0,3) });
    }
  }
  if(!cfg.participants.length && !simulations.length){ console.error('Missing --participants'); process.exit(1); }
  const projection = cfg.participants.length? projectApproval(cfg.participants) : null;
  const validation = validateProposal(cfg.id, cfg.params, cfg.participants);
  if(cfg.emit && !validation.ok){ console.error('Validation failed:', validation.reason); process.exit(2); }
  const report = {
    proposalId: cfg.id,
    params: cfg.params,
    participants: cfg.participants.length,
    projectedApprovalRate: projection? Number(projection.approvalRate.toFixed(4)) : null,
    willApprove: projection? projection.willApprove : null,
    simulations,
    validation: validation.ok ? 'ok' : validation.reason
  };
  if(cfg.emit){
    const entry = emitProposal(cfg);
    report.emitted=true; report.entryHash = sha256(entry);
  } else { report.emitted=false; }
  process.stdout.write(JSON.stringify(report,null,2)+'\n');
}

if(require.main === module){ main(); }

module.exports = { projectApproval };
