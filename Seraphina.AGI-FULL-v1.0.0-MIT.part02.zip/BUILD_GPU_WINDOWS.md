# Windows GPU Build Guide (CUDA SHA-256d Addon)

## Prerequisites
1. NVIDIA GPU with recent driver (CUDA 12.x compatible)
2. Visual Studio 2019 Build Tools (already detected in your log)
3. CUDA Toolkit installed (ensure `nvcc` on PATH) – e.g. `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.x\bin`
4. Python 3 (node-gyp requirement) – already found.
5. Node.js 22.x (installed) and matching node-gyp cache.

## Install Dev Dependencies
```powershell
npm install --include=dev
```

## Configure then Build
Node 22 occasionally needs explicit configure before build on Windows when using custom .cu sources.
```powershell
# Ensure environment sees nvcc
$env:Path = "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.4\bin;" + $env:Path
node-gyp configure
node-gyp build
```
If that succeeds you should see `build\Release\gpu_sha256d.node`.

## Common Issues
| Symptom | Cause | Fix |
|---------|-------|-----|
| `Cannot find module 'node-addon-api'` | Dev dep not installed before build | Run `npm install --include=dev` |
| `fatal error: cuda_runtime_api.h: No such file` | CUDA toolkit not on PATH/include | Add CUDA include dir to `INCLUDE` env or modify binding.gyp |
| `unresolved external symbol cuda...` | Missing cudart library link | Add library path to `LIB` env or add `libraries` entry with absolute path |
| `You must run node-gyp configure first` | Direct build without prior configure in edge cases | Run `node-gyp configure` manually |

## Optional: Forcing 64-bit Build
```powershell
node-gyp configure --arch=x64
node-gyp build --arch=x64
```

## Verifying Addon Load
```powershell
node -e "console.log(require('./gpu_sha256d_native.js'))"
```
Should print an object with `available: true`.

## Integrate With Miner
```powershell
$env:AUR_GPU="1"
node aurrelia-pico-mesh-miner.js --algo=sha256d
```
If batch metrics appear in Prometheus (`aurrelia_gpu_batches_total`), GPU path active.

## Troubleshooting Steps Quick Script
```powershell
node -p "process.versions" | ConvertTo-Json
(Get-Command nvcc).Path
```
If `nvcc` missing, reinstall / re-add CUDA bin path.

## Next Optimization Targets
- Add `--use_fast_math` and `-O3` flags in nvcc compile.
- Precompute message schedule in shared memory per block.
- Launch occupancy tuning: experiment with 128 vs 256 threads per block.

---
Generated helper doc for local Windows environment.
