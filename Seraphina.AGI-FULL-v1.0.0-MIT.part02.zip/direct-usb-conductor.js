// direct-usb-conductor.js
// Direct MSI→Cube conductor without Pi emulation; HID endpoints used for batched compressed telemetry & tuning pulses.
// Env Vars:
//   MAX_CUBES (default 35)
//   USB_VID / USB_PID (override vendor/product IDs)
//   USB_BATCH_SIZE (default 512)
//   USB_POLL_MS (default 10)
//   USB_BASE_FREQ (default 17)
//   USB_RETENTION_DELTA (default 2) -> Hz increment if predicted_retention above threshold
//   USB_RETENTION_THRESH (default 0.6)
//   USB_THROUGHPUT_GAUGE=1 -> attempt Prometheus gauge update via global registry
// Security: Prediction values sanitized to [0,1]; frequency bounded [1,255]; compression only applied to locally constructed payload.
// Ledger: Hash-chained JSONL entries (prevHash + sha256(entry)). No execution of cube data.

'use strict';
const usb = safeRequire('usb');
const zlib = require('zlib');
const crypto = require('crypto');
const fs = require('fs');
const { promisify } = require('util');
const path = require('path');
function safeRequire(m){ try{ return require(m);}catch{ return null; } }

const argvRig = process.argv.find(a=> a.startsWith('--rig-id='));
const RIG_ID = argvRig? argvRig.split('=')[1] : (process.env.RIG_ID || 'eternal-forge-genesis');
const MAX_CUBES = parseInt(process.env.MAX_CUBES || '35',10);
const USB_VID = process.env.USB_VID? parseInt(process.env.USB_VID,10) : 0x2341;
const USB_PID = process.env.USB_PID? parseInt(process.env.USB_PID,10) : 0x8036;
const BATCH_SIZE = parseInt(process.env.USB_BATCH_SIZE || '512',10);
const POLL_MS = parseInt(process.env.USB_POLL_MS || '10',10);
const BASE_FREQ = parseInt(process.env.USB_BASE_FREQ || '17',10);
const RET_DELTA = parseInt(process.env.USB_RETENTION_DELTA || '2',10);
const RET_THRESH = parseFloat(process.env.USB_RETENTION_THRESH || '0.6');
const PROM_GAUGE = process.env.USB_THROUGHPUT_GAUGE === '1';
const LEDGER_PATH = process.env.USB_DIRECT_LEDGER || 'direct-swarm-ledger.jsonl';

let RetentionOracle=null; try { ({ RetentionOracle } = require('./aurrelia-retention-infer.js')); } catch { RetentionOracle=null; }

class DirectConductor {
  constructor(){
    this.seed = `seraphina-swarm-${RIG_ID}-${Date.now()}`;
    this.chainHash = crypto.createHash('sha256').update(this.seed).digest('hex');
    this.cubes=[];
    this.throughput={ totalBytes:0, start:Date.now() };
    this.oracle = RetentionOracle? new RetentionOracle() : null;
    if(this.oracle){ this.oracle.load().then(()=> this.detectCubes()); } else { this.detectCubes(); }
  }
  shaSeedOrder(indices,suffix){
    const seedHash = crypto.createHash('sha256').update(this.seed+'|'+suffix).digest();
    return indices.map(i=> ({i,h:seedHash[i%seedHash.length]})).sort((a,b)=>a.h-b.h).map(e=>e.i);
  }
  detectCubes(){
    if(!usb){ console.warn('[DirectUSB] usb module unavailable'); return; }
    const devs = usb.getDeviceList();
    const candidates = devs.filter(d=> d && d.deviceDescriptor && d.deviceDescriptor.idVendor===USB_VID && d.deviceDescriptor.idProduct===USB_PID);
    const ordered = this.shaSeedOrder(Array.from({length:candidates.length},(_,i)=>i),'usb-discovery');
    this.cubes = ordered.map(i=> candidates[i]).slice(0, MAX_CUBES);
    this.cubes.forEach((cube,i)=> this.initCube(cube,i));
    this.appendLedger({ ts:Date.now(), cubes:this.cubes.length, event:'detect' });
    if(this.cubes.length) setInterval(()=> this.pollSwarm(), POLL_MS);
  }
  initCube(cube, idx){
    try {
      cube.open();
      cube.controlTransfer(0x40, 0x01, 0, 0, Buffer.from([100])); // PD negotiation
      this.sendPulse(cube,{ freq:BASE_FREQ, idx });
      console.log(`[DirectUSB] Cube ${idx} online baseFreq=${BASE_FREQ}`);
    } catch(e){ console.warn(`[DirectUSB] Cube ${idx} init failed: ${e.message}`); }
  }
  sendPulse(cube, payload){
    try {
      const bufRaw = Buffer.from(JSON.stringify(payload));
      const gz = zlib.gzipSync(bufRaw);
      const out = Buffer.alloc(BATCH_SIZE);
      gz.copy(out,0,0,Math.min(gz.length,BATCH_SIZE));
      if(cube.transferOut) cube.transferOut(1,out);
      this.throughput.totalBytes += out.length; // outbound only
    } catch(e){ console.warn('[DirectUSB] sendPulse error:', e.message); }
  }
  async pollSwarm(){
    for(let i=0;i<this.cubes.length;i++){
      const cube = this.cubes[i];
      try {
        const status = cube.transferIn? await promisify(cube.transferIn.bind(cube))(1, BATCH_SIZE) : null;
        if(!status) continue;
        // Assume status contains gzipped JSON terminated by null padding.
        const cut = status.indexOf(0); const slice = cut>0? status.slice(0,cut) : status;
        let parsed={};
        try { parsed = JSON.parse(zlib.gunzipSync(slice).toString('utf8')); } catch{ parsed={}; }
        const retentionFields = Array.isArray(parsed.retentionFields)? parsed.retentionFields : [];
        // sanitize fields for oracle consumption
        const sanitized = retentionFields.map(f=> ({
          time_min: clampNumber(f.time_min,0,1000,5),
          coverage_pct: clampNumber(f.coverage_pct,0,1,0.5),
          prior_retention: clampNumber(f.prior_retention,0,1,0.5),
          difficulty: clampNumber(f.difficulty,0,2,0.7)
        }));
        let sorted = sanitized;
        if(this.oracle && this.oracle.sortFields){
          try { sorted = this.oracle.sortFields(sanitized).map(f=> ({...f, predicted_retention: clampNumber(f.predicted_retention,0,1,f.prior_retention)})); } catch{ sorted = sanitized; }
        }
        sorted.forEach((f,_fIdx)=>{
          const tunedHz = BASE_FREQ + (f.predicted_retention>RET_THRESH? RET_DELTA:0);
          const finalHz = Math.max(1, Math.min(255, tunedHz));
          this.sendPulse(cube,{ freq:finalHz, idx:i, tuned:true });
        });
        if(PROM_GAUGE) this.updateThroughputGauge();
      } catch(e){ console.warn(`[DirectUSB] poll cube ${i} error: ${e.message}`); }
    }
  }
  updateThroughputGauge(){
    const now = Date.now();
    const elapsed = (now - this.throughput.start)/1000;
    const mbps = (this.throughput.totalBytes/(1024*1024))/ (elapsed||1);
    if(global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges && global.__AUR_METRICS_REG__.gauges.usbThroughput){
      try { global.__AUR_METRICS_REG__.gauges.usbThroughput.set(Number(mbps.toFixed(2))); } catch{}
    }
    if(Math.random() < 0.05) console.log(`[DirectUSB] Throughput ${mbps.toFixed(2)} MB/s elapsed=${elapsed.toFixed(1)}s`);
  }
  appendLedger(entry){
    entry.prevHash = this.chainHash;
    entry.chainHash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    try { fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n'); this.chainHash = entry.chainHash; } catch(e){ console.warn('[DirectUSB] ledger append failed:', e.message); }
  }
}

function clampNumber(val,min,max,def){ if(typeof val!=='number'||!isFinite(val)) return def; if(val<min) return min; if(val>max) return max; return val; }

if(require.main === module){ new DirectConductor(); }

module.exports = { DirectConductor };
