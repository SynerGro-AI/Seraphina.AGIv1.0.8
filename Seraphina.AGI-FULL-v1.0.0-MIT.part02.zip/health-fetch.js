// Simple node fetch for /health
const http = require('http');
http.get('http://localhost:8999/health', res => { let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ console.log(data); process.exit(0); }); }).on('error', e=>{ console.error('FetchError', e.message); process.exit(1); });