// keystore.js - Encrypted HD seed + deterministic derivation
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const bip39 = require('bip39');
const { hdkey } = (()=>{ try { return require('ethereumjs-wallet'); } catch{ return {}; } })();

function deriveSeed(mnemonic){
  if (!bip39.validateMnemonic(mnemonic)) throw new Error('invalid mnemonic');
  return bip39.mnemonicToSeedSync(mnemonic); // Buffer
}
function encrypt(data, pass){
  const key = crypto.createHash('sha256').update(pass).digest();
  const { deriveBuffer } = require('./deterministic-util');
  const iv = deriveBuffer('keystore-iv', 12, passphrase, label);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(data), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { iv: iv.toString('hex'), ct: ct.toString('base64'), tag: tag.toString('hex') };
}
function decrypt(obj, pass){
  const key = crypto.createHash('sha256').update(pass).digest();
  const iv = Buffer.from(obj.iv,'hex');
  const ct = Buffer.from(obj.ct,'base64');
  const tag = Buffer.from(obj.tag,'hex');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]);
}
function saveKeystore(file, encObj){ fs.writeFileSync(file, JSON.stringify(encObj,null,2)); }
function loadKeystore(file){ if (!fs.existsSync(file)) return null; return JSON.parse(fs.readFileSync(file,'utf8')); }

function ensureMnemonic(file, pass){
  if (fs.existsSync(file)) return 'exists';
  const mnemonic = bip39.generateMnemonic(256);
  const seed = deriveSeed(mnemonic);
  const enc = encrypt(seed, pass);
  enc.mnemonicHint = mnemonic.split(' ').slice(0,2).join(' '); // do NOT store full mnemonic here
  saveKeystore(file, enc);
  fs.writeFileSync(file+'.hint', 'KEEP YOUR MNEMONIC OFFLINE. FIRST TWO WORDS: '+enc.mnemonicHint+'\n');
  return 'created';
}

module.exports = { deriveSeed, encrypt, decrypt, saveKeystore, loadKeystore, ensureMnemonic };
