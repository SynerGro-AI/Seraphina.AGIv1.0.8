/**
 * Environment Variable Access Tracer
 * ----------------------------------
 * Lightweight runtime probe that intercepts process.env property GETs and logs unique accesses.
 * Activation: (any of)
 *   1. Require this module early:   require('./env-tracer');
 *   2. Use helper launcher:         node run-with-trace.js <your-script.js> [args]
 *   3. NODE_OPTIONS="-r ./env-tracer" node your-script.js
 * Control:
 *   ENV_TRACE=0        -> disables interception (module becomes no-op)
 *   ENV_TRACE_FILE=path -> destination JSONL (default env-access-log.jsonl)
 *   ENV_TRACE_STACK=1   -> include first external stack frame (can slow down)
 *   ENV_TRACE_FLUSH_MS=ms -> periodic flush interval (default 5000)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

if (process.env.ENV_TRACE === '0') {
  module.exports = { active:false };
  return;
}

// Avoid double wrapping if already active (cluster / multiple requires)
if (process.__ENV_TRACER_ACTIVE__) {
  module.exports = process.__ENV_TRACER_ACTIVE__;
  return;
}

const LOG_FILE = process.env.ENV_TRACE_FILE || path.join(process.cwd(), 'env-access-log.jsonl');
const INCLUDE_STACK = process.env.ENV_TRACE_STACK === '1';
const FLUSH_MS = parseInt(process.env.ENV_TRACE_FLUSH_MS || '5000', 10);

const accessed = new Map(); // key -> { count, first, last, stack? }
const originalEnv = process.env; // Keep reference

function captureStack() {
  if (!INCLUDE_STACK) return undefined;
  const err = new Error();
  const lines = (err.stack || '').split(/\r?\n/).slice(3); // skip first frames
  const ext = lines.find(l => !l.includes('env-tracer.js'));
  return ext || lines[0];
}

const proxy = new Proxy(originalEnv, {
  get(target, prop, receiver) {
    if (typeof prop === 'string') {
      let meta = accessed.get(prop);
      if (!meta) {
        meta = { count:0, first:Date.now(), last:0 };
        accessed.set(prop, meta);
      }
      meta.count++;
      meta.last = Date.now();
      if (INCLUDE_STACK && !meta.stack) meta.stack = captureStack();
    }
    return Reflect.get(target, prop, receiver);
  },
  // Preserve enumeration semantics
  ownKeys(target){ return Reflect.ownKeys(target); },
  getOwnPropertyDescriptor(target, prop){ return Object.getOwnPropertyDescriptor(target, prop); }
});

try { process.env = proxy; } catch (e) {
  // In very old Node versions process.env might be non-configurable; fallback soft mode
  console.warn('[ENV_TRACER] Failed to proxy process.env:', e.message);
}

function dumpSummary(final=false){
  try {
    const arr = Array.from(accessed.entries()).map(([k,v])=>({
      key:k, count:v.count, first:v.first, last:v.last, age_ms: Date.now()-v.first, stack:v.stack || undefined
    }));
    const summary = {
      ts: Date.now(),
      final, unique: arr.length,
      accesses: arr.sort((a,b)=>b.count - a.count).slice(0, 500) // cap list
    };
    fs.appendFileSync(LOG_FILE, JSON.stringify(summary)+'\n');
  } catch(e){
    console.error('[ENV_TRACER] Write fail', e.message);
  }
}

const interval = setInterval(()=>dumpSummary(false), FLUSH_MS).unref();
process.once('exit', ()=>{ dumpSummary(true); });
process.once('SIGINT', ()=>{ dumpSummary(true); process.exit(130); });

const api = {
  active: true,
  logFile: LOG_FILE,
  getAccessed(){ return Array.from(accessed.keys()); },
  getDetail(){ return accessed; },
  forceFlush(){ dumpSummary(false); },
  hashAccessSet(){
    const list = Array.from(accessed.keys()).sort().join('\n');
    return crypto.createHash('sha256').update(list).digest('hex');
  }
};

process.__ENV_TRACER_ACTIVE__ = api;
module.exports = api;
