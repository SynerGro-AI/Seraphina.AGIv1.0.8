Param(
  [string]$TargetRoot = "$Env:ProgramFiles/SeraphinaMiner",
  [switch]$Force
)

$ErrorActionPreference = 'Stop'
Write-Host "[Seraphina-Installer] Starting installation..." -ForegroundColor Cyan

# Validate Node.js
$node = (Get-Command node -ErrorAction SilentlyContinue)
if (-not $node) { Write-Warning "Node.js not found in PATH. Please install Node.js LTS first."; if (-not $Force) { throw "Node.js missing" } }

# Source directory (current script directory) - mining folder root
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "Source: $src"

if (Test-Path $TargetRoot) {
  if ($Force) {
    Write-Host "Target exists; removing due to -Force" -ForegroundColor Yellow
    Remove-Item -Recurse -Force $TargetRoot
  } else {
    Write-Warning "Target $TargetRoot already exists. Use -Force to overwrite."; throw "Target exists"
  }
}

Write-Host "Creating target root $TargetRoot"
New-Item -ItemType Directory -Force -Path $TargetRoot | Out-Null

Write-Host "Copying miner files..."
Copy-Item -Recurse -Force -Path (Join-Path $src '*') -Destination $TargetRoot

# Preserve original env backup as .env if not present
$envFile = Join-Path $TargetRoot '.env'
if (-not (Test-Path $envFile)) {
  $envBak = Join-Path $TargetRoot '.env.bak'
  if (Test-Path $envBak) { Copy-Item $envBak $envFile }
}

# Create run script
$runScript = @'
Param(
  [switch]$NoEnv
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$envPath = Join-Path $root '.env'
if ((-not $NoEnv) -and (Test-Path $envPath)) {
  Write-Host "Loading environment from $envPath" -ForegroundColor DarkGray
  Get-Content $envPath | ForEach-Object {
    if ($_ -match '^[A-Za-z_][A-Za-z0-9_]*=') {
      $k,$v = $_.Split('=',2)
      $Env:$k = $v
    }
  }
}

# Logs directory
$logDir = Join-Path $root 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
$ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
$log = Join-Path $logDir "miner-$ts.log"
Write-Host "Logging to $log" -ForegroundColor DarkGray

# Choose main miner file
$minerCandidates = @('aurrelia-self-optimizing-miner.js','aurrelia-pico-mesh-miner.js','actual-real-miner.js')
$minerFile = $minerCandidates | ForEach-Object { if (Test-Path (Join-Path $root $_)) { $_ } } | Select-Object -First 1
if (-not $minerFile) { throw "No miner entrypoint found" }

Write-Host "Starting miner: $minerFile" -ForegroundColor Green
node $minerFile 2>&1 | Tee-Object -FilePath $log
'@

$runScriptPath = Join-Path $TargetRoot 'run-miner.ps1'
Set-Content -Path $runScriptPath -Value $runScript -Encoding UTF8

# Scheduled Task (runs at logon with highest privileges)
$taskName = 'SeraphinaMinerAuto'
Write-Host "Registering scheduled task $taskName" -ForegroundColor Cyan
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$runScriptPath`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
try {
  $existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($existing) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false }
  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Description 'Seraphina Miner auto-start at logon' -RunLevel Highest
} catch {
  Write-Warning "Failed to register scheduled task: $_"
}

# Desktop shortcut
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Seraphina Miner.lnk'
Write-Host "Creating desktop shortcut $shortcutPath" -ForegroundColor Cyan
$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($shortcutPath)
$sc.TargetPath = 'powershell.exe'
$sc.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$runScriptPath`""
$sc.WorkingDirectory = $TargetRoot
$sc.IconLocation = (Join-Path $TargetRoot 'seraphina.ico')
$sc.Description = 'Launch Seraphina Miner'
$sc.Save()

Write-Host "Installation complete." -ForegroundColor Green
