#!/usr/bin/env bash
set -euo pipefail
PROM_ENDPOINT="${1:-http://localhost:9090/metrics}"
echo "[CI] Starting Aurrelia CI run"
export AUTONOMY_ENABLED=1
export GLOBAL_MIN_IMPROVEMENT=0
echo "[CI] Running test-run-all.js"
RESULT=$(node test-run-all.js)
echo "$RESULT"
FAILED=$(echo "$RESULT" | grep -E '"failed"' | sed -E 's/.*"failed"[^0-9]*([0-9]+).*/\1/')
if [ -n "$FAILED" ] && [ "$FAILED" -gt 0 ]; then
  echo "[CI] Test failures detected: $FAILED" >&2
  exit 1
fi
echo "[CI] Tests passed"
# Optional Prometheus scrape
if command -v curl >/dev/null 2>&1; then
  if curl -m 5 -fsS "$PROM_ENDPOINT" >/dev/null; then
    SIZE=$(curl -m 5 -fsS "$PROM_ENDPOINT" | wc -c)
    echo "[CI] Prometheus scrape size: $SIZE bytes"
  else
    echo "[CI] Prometheus scrape failed"
  fi
else
  echo "[CI] curl not available; skipping metrics scrape"
fi
echo "[CI] Completed"
