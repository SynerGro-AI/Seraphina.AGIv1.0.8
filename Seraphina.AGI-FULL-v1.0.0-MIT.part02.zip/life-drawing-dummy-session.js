// life-drawing-dummy-session.js
// Generate a single dummy session to populate ledger & coverage for demo.
'use strict';
const { generateLifeDrawingExam } = require('./life-drawing-exam');
const { startSession, recordResponse, finalizeSession } = require('./life-drawing-session');

function createDummyAnswers(expected){
  const answers = {};
  expected.forEach(f=>{ // mark half randomly
    if(Math.random() < 0.55){ answers[f] = 'y'; }
  });
  // occasionally include proportion/negativeSpace hints
  if(Math.random()<0.7) answers.proportionCheck = 'ok';
  if(Math.random()<0.5) answers.negativeSpace = 'noted';
  return answers;
}

function runDummy(){
  const exam = generateLifeDrawingExam({ limit: 5 });
  const session = startSession(exam);
  exam.questions.forEach((q,i)=>{
    // Simulate staggered answering
    const answers = createDummyAnswers(q.expectedFields||[]);
    recordResponse(session, { questionId: q.id, answers });
  });
  const summary = finalizeSession(session, exam);
  console.log(JSON.stringify({ dummy:true, summary }, null, 2));
  return summary;
}

if(require.main === module){
  runDummy();
}

module.exports = { runDummy };