// Deterministic Kraken feed adapter with fallback hashing
// Real mode: fetch public ticker endpoint for specified pairs.
// Deterministic fallback: SHA256(pair + GLOBAL_SEED) to derive synthetic price if network fails.

const https = require('https');

const PAIRS = (process.env.KRAKEN_PAIRS || 'BTC/USD,BTC/USDT,RVN/BTC,KAS/BTC').split(',').map(s=>s.trim()).filter(Boolean);
const GLOBAL_SEED = process.env.KRAKEN_FALLBACK_SEED || 'AURRELIA_KRAKEN_SEED_V1';

function fetchTicker(pair){
  return new Promise((resolve)=>{
    if(process.env.KRAKEN_DISABLE==='1'){ return resolve({ pair, disabled:true }); }
    const krPair = pair.replace('/', ''); // Kraken pair formatting can vary; keep simple
    const url = `https://api.kraken.com/0/public/Ticker?pair=${encodeURIComponent(krPair)}`;
    const req = https.get(url, (res)=>{
      let data='';
      res.on('data', d=> data+=d);
      res.on('end', ()=>{
        try {
          const o = JSON.parse(data);
          if(o && o.result){
            const keys = Object.keys(o.result);
            if(keys.length){
              const k = keys[0];
              const r = o.result[k];
              const last = r.c && r.c[0] ? parseFloat(r.c[0]) : null;
              const ask = r.a && r.a[0] ? parseFloat(r.a[0]) : null;
              const bid = r.b && r.b[0] ? parseFloat(r.b[0]) : null;
              return resolve({ pair, last, ask, bid, live:true });
            }
          }
          return resolve(fallbackTicker(pair));
        } catch(e){ return resolve(fallbackTicker(pair)); }
      });
    });
    req.on('error', ()=> resolve(fallbackTicker(pair)));
    req.setTimeout(parseInt(process.env.KRAKEN_TIMEOUT_MS||'5000',10), ()=>{ try { req.destroy(); } catch(_){} resolve(fallbackTicker(pair)); });
  });
}

function fallbackTicker(pair){
  const crypto = require('crypto');
  const h = crypto.createHash('sha256').update(pair + '|' + GLOBAL_SEED).digest('hex');
  // derive deterministic synthetic prices (not random) from hash segments
  const base = parseInt(h.slice(0,8),16) / 1e8; // 0..~42 range
  const scale = parseInt(h.slice(8,16),16) / 1e8;
  let raw = (base + scale);
  // Pair-specific scaling heuristics (keep deterministic)
  if(/BTC\//i.test(pair)) raw = raw * 50000;
  else if(/RVN\/BTC/i.test(pair)) raw = raw / 2000; // RVN/BTC small ratio
  else if(/KAS\/BTC/i.test(pair)) raw = raw / 500;  // approximate order
  const last = Number(raw.toFixed(8));
  const ask = Number((last * 1.001).toFixed(8));
  const bid = Number((last * 0.999).toFixed(8));
  return { pair, last, ask, bid, live:false };
}

async function snapshot(){
  const out = {};
  for(const p of PAIRS){ out[p] = await fetchTicker(p); }
  return out;
}

module.exports = { snapshot, fetchTicker, fallbackTicker };
