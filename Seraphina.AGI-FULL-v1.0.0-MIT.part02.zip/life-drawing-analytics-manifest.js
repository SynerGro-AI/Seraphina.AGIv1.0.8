#!/usr/bin/env node
// life-drawing-analytics-manifest.js
// Consolidate analytics outputs into a single deterministic manifest with SHA256 digest.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { generateReport } = require('./life-drawing-coverage-report');
const { computeTrends } = require('./life-drawing-trend-report');
const { computeRetention } = require('./life-drawing-retention');
const { computeTrend: computeAuditTrend } = require('./life-drawing-audit-trend');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function buildManifest(){
  const coverage = generateReport();
  const trends = computeTrends();
  const retention = computeRetention();
  const auditTrend = computeAuditTrend();
  const manifest = {
    createdAt: new Date().toISOString(),
    coverage,
    trends,
    retention,
    auditTrend: auditTrend.ok ? {
      count: auditTrend.count,
      windowSize: auditTrend.windowSize,
      severities: auditTrend.severities.map(s=> ({ severity: s.severity, latest: s.latest, slope: s.slope }))
    } : { ok:false }
  };
  // Deterministic digest: we canonicalize by removing volatile timestamps inside nested objects if any.
  const sanitized = JSON.parse(JSON.stringify(manifest));
  // Remove potential dynamic warning arrays from coverage/trends if needed (none currently dynamic beyond data).
  const digest = sha256(sanitized).slice(0,32);
  manifest.digest = digest;
  return manifest;
}

function writeManifest(){
  const m = buildManifest();
  const outPath = path.join(__dirname,'life-drawing-analytics-manifest.json');
  fs.writeFileSync(outPath, JSON.stringify(m,null,2));
  return outPath;
}

if(require.main === module){
  const out = writeManifest();
  console.log(JSON.stringify({ ok:true, file: out }, null, 2));
}

module.exports = { buildManifest };
