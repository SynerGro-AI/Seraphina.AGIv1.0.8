// life-drawing-detection.js
// Simple filename-based heuristic detection for proportionCheck & negativeSpace relevance.
'use strict';

function analyzeFilename(file){
  const name = file.toLowerCase();
  const tokens = name.split(/[^a-z0-9]+/).filter(Boolean);
  let proportionCheck = false;
  let negativeSpace = false;
  if(tokens.some(t=> /long|tall|wide|foreshorten|scale/.test(t))) proportionCheck = true;
  if(tokens.some(t=> /arch|loop|gap|triangle|window/.test(t))) negativeSpace = true;
  return { file, proportionCheck, negativeSpace };
}

module.exports = { analyzeFilename };
