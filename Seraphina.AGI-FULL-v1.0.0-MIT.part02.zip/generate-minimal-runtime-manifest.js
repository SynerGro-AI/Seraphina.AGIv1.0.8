#!/usr/bin/env node
// Generate a manifest listing only essential runtime files (exclude benchmarks, stress tests, experimental and docs).
const fs = require('fs');
const crypto = require('crypto');

const KEEP_PATTERNS = [
  /^aurrelia-pico-mesh-miner\.js$/,
  /^real-stratum-client\.js$/,
  /^integrity-audit\.js$/,
  /^environment-audit\.js$/,
  /^audit-all\.js$/,
  /^audit-monitor\.js$/,
  /^diff-chain-tips\.js$/,
  /^generate-usb-manifest\.js$/,
  /^verify-manifest\.js$/,
  /^export-chain-tips-prom\.js$/,
  /^seraphina-key-vault\.js$/,
  /^agent-response-schema\.js$/,
  /^install-seraphina\.sh$/,
  /^install-monitor-systemd\.sh$/,
  /^fetch-verify-python\.sh$/,
  /^build-python-offline\.sh$/,
  /^cross-build-python\.sh$/,
  /^PYTHON-INTEGRATION\.md$/,
  /^ISO-BUILD\.md$/,
  /^PACKAGING\.md$/,
  /^BOOTSTRAP\.md$/,
  /^python-build-manifest\.json$/,
  /^python-stdlib-hashes\.json$/,
  /-ledger\.jsonl$/
];

function shouldKeep(name){
  return KEEP_PATTERNS.some(re=>re.test(name));
}

const files = fs.readdirSync('.').filter(f=> shouldKeep(f) && fs.statSync(f).isFile());
const artifacts = files.map(f=> {
  const data = fs.readFileSync(f);
  return { file: f, size: data.length, sha256: crypto.createHash('sha256').update(data).digest('hex') };
});
const merkleLeaves = artifacts.map(a=>a.sha256);
function merkle(leaves){
  if(!leaves.length) return null;
  let layer = leaves.slice();
  while(layer.length>1){
    const next=[]; for(let i=0;i<layer.length;i+=2){ const left=layer[i]; const right=layer[i+1]||left; next.push(crypto.createHash('sha256').update(left+right).digest('hex')); }
    layer=next;
  }
  return layer[0];
}
const root = merkle(merkleLeaves);
const manifest = { generated: Date.now(), count: artifacts.length, merkleRoot: root, artifacts };
fs.writeFileSync('minimal-runtime-manifest.json', JSON.stringify(manifest,null,2));
console.log(JSON.stringify(manifest,null,2));
