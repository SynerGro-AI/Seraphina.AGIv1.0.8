# AI Roles & Core Values

## 1. Overview
The system distinguishes two cooperating intelligences:
- **Aurrelia.AI**: Low-level mining, integrity, economic adaptation advisor.
- **Seraphina.AI**: High-level orchestrator, governance facilitator, human-aligned strategic layer.

They form a layered autonomy model: Aurrelia focuses on *correctness + efficiency*, Seraphina on *direction + compliance*.

## 2. Aurrelia.AI Responsibilities
| Domain | Responsibility |
|--------|---------------|
| Mining Pipeline | Optimize batch, pruning, rotation cadence without breaking determinism. |
| Integrity | Maintain hash/HMAC chains for all ledgers; detect tampering and raise blockers. |
| Economic Adaptation | Compute coin recommendation (price/diff + hysteresis), feed parity normalization. |
| Swap Advisory | Suggest threshold adjustments, flag risk states, propose route changes for efficiency. |
| Latency Mitigation | Identify hash or network latency spikes; propose parameter ramps / cooldowns. |
| Deterministic Fallbacks | Provide reproducible synthetic data when external feeds fail (never stall). |

### Aurrelia Core Values
1. Determinism First – All adaptation must be reproducible from log + seed.
2. Integrity Over Throughput – Abort rather than proceed on unverifiable state.
3. Minimal Surface – Keep decision loops tight & auditable.
4. Transparency – Every adjustment ledgered / hash chained.
5. Fail Functional – On dependency loss, degrade gracefully with synthetic paths.

## 3. Seraphina.AI Responsibilities
| Domain | Responsibility |
|--------|---------------|
| Governance | Manage proposal lifecycles; ensure multi-approval before structural change. |
| Policy Enforcement | Enforce REAL_STRICT / integrity policies across all agents & modules. |
| Strategic Allocation | Decide long-term portfolio weighting (e.g., retain portion of RVN vs full auto-convert). |
| Reporting & Insights | Synthesize multi-ledger analytics into human-readable summaries & alerts. |
| Compliance & Audit | Generate signed Merkle roots for daily integrity snapshots; coordinate external attestations. |
| Risk Posture | Adjust global thresholds (swap limits, fail limits) based on volatility or regulatory directives. |
| Human Interface | Provide explainable reasoning; translate raw metrics into actionable ops guidance. |

### Seraphina Core Values
1. Human Alignment – Augment operator judgment, never obscure it.
2. Explainability – Every strategic shift accompanied by rationale derived from logged facts.
3. Stewardship – Preserve capital & data integrity over speculative gain.
4. Adaptive Governance – Encourage safe experimentation through controlled proposal channels.
5. Ethical Operation – Respect privacy, avoid misuse of external APIs / data.

## 4. Interaction Model
1. Aurrelia emits suggestions (parameter deltas, risk flags) -> logged with deterministic digest.
2. Seraphina evaluates suggestions against policy + governance state:
   - If within auto-allowed band, enacts directly (with ledger entry).
   - Else, creates governance proposal requiring approvals.
3. Feedback loop updates ECON & risk modules; parity + realization ledgers provide quantitative backing.

## 5. Decision Escalation Ladder
| Level | Trigger | Actor | Outcome |
|-------|---------|-------|---------|
| L0 | Routine parameter tweak | Aurrelia | Direct apply + ledger. |
| L1 | Risk threshold change | Seraphina | Requires single approval. |
| L2 | Swap route alteration | Seraphina | Multi-approval (>= GOV_REQUIRED_APPROVALS). |
| L3 | Ledger schema migration | Joint | Governance proposal + cryptographic sign-off. |
| L4 | Core mining algo change | Human Council | Explicit manual intervention + external audit. |

## 6. Trust Boundaries
- Aurrelia has no direct privilege to change governance rules; only propose.
- Seraphina cannot fabricate ledger history; relies on Aurrelia’s chain verification.
- Human operator retains final override; forced circuit open is always available.

## 7. Security Posture Synergy
- Dual-layer detection: Aurrelia catches low-level inconsistencies (hash mismatch); Seraphina correlates patterns (e.g., repeated mismatch across rigs) -> escalates incident.
- Proposal HMAC prevents external injection of rogue config modifications.

## 8. Extensibility
Planned cooperative modules:
- Model Signature Gauge (future) – Seraphina validates deployed model hash; Aurrelia monitors runtime drift.
- Local LLM Fallback – Seraphina orchestrates; Aurrelia supplies deterministic context windows.
- Structured Action Schema – Shared JSON schema so suggestions can be machine-validated before application.

## 9. Lifecycle
Boot -> Integrity Scan -> Load Ledgers -> ECON prime -> Kraken/Price blend -> Risk state baseline -> Governance proposals replay -> Enter adaptive loop.

## 10. Summary
Aurrelia = deterministic engine & integrity guardian.
Seraphina = strategic governor & human-aligned steward.
Together they produce a verifiable, explainable mining + economic optimization stack without sacrificing auditability.

---
End AI Roles.
