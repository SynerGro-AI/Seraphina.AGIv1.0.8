# Seraphina Agent Metrics & Integrity Audit

## Overview
This document maps implemented agent-related features to original requirements and lists Prometheus metrics, tests, and integrity mechanisms now present in the codebase.

## Implemented Components
- Agent Wrapper (`seraphina-agent-wrapper.js`): Prompt shielding, structured response normalization, integrity digest, fallback digest.
- API Facade (`seraphina-api.js`): Invocation, stats accumulation, Prometheus exporter metrics.
- Response Schema (`agent-response-schema.js`): Validation of `action`, `delta`, `confidence`, `note`.
- Training Integrity (`seraphina-model-train.js`): Parameter & metrics digests + integrity hash.
- Cache Integrity: Each simulation cache entry stores SHA256 of metrics; mismatch scan gauges.
- Rate Limiter: Token bucket with capacity, refill interval, hits, blocked counts.

## Prometheus Metrics
### Core Agent Invocation
- seraphina_agent_invocations_total (counter)
- seraphina_agent_blocked_total (counter) – prompt shield or rate limit early block aggregated.
- seraphina_agent_action_total{action="<label>"} (counter per action label)
- seraphina_agent_last_action{action="<label>"} (gauge =1 for last action)
- seraphina_agent_last_confidence (gauge) – confidence of last suggestion
- seraphina_agent_invalid_suggestions_total (counter) – new: invalid (schema-rejected) suggestions

### Rate Limiter (Primary Naming)
- seraphina_agent_rate_limit_enabled (gauge 1/0)
- seraphina_agent_rate_limit_capacity (gauge)
- seraphina_agent_rate_limit_tokens_remaining (gauge)
- seraphina_agent_rate_limit_hits_total (counter)
- seraphina_agent_rate_limit_blocked_total (counter)
- seraphina_agent_rate_limit_refill_seconds (gauge)

### Rate Limiter (Extended / Alias Set)
- seraphina_agent_rate_enabled (gauge)
- seraphina_agent_rate_tokens_remaining (gauge)
- seraphina_agent_rate_tokens_capacity (gauge)
- seraphina_agent_rate_hits_total (counter)
- seraphina_agent_rate_blocked_total (counter)
- seraphina_agent_rate_last_refill_timestamp_ms (gauge)
- seraphina_agent_rate_refill_interval_ms (gauge)

### Cache Integrity
- seraphina_sim_cache_integrity_mismatches (gauge)
- seraphina_sim_cache_integrity_scanned (gauge)

### Training Integrity & Performance
- seraphina_train_acc (gauge)
- seraphina_train_acc_ethical (gauge)
- seraphina_train_loss_a (gauge)
- seraphina_train_loss_b (gauge)
- seraphina_train_epoch_avg_ms (gauge)
- seraphina_train_integrity_hash_len (gauge)
- seraphina_train_last_promoted (gauge)
- seraphina_train_ema_vs_median_delta (gauge)

### Exporter Meta
- seraphina_api_version{version="<semver>"} (gauge)
- seraphina_start_timestamp_ms (gauge)
- seraphina_metrics_scrapes (counter)
- seraphina_exporter_protocol{protocol="http|https"} (gauge)

### Planned / Potential Future (Not Implemented Yet)
- seraphina_agent_model_sig – model signature digest (future enhancement)
- seraphina_agent_cost_total – cost tracking
- seraphina_agent_rate_limited_duration_ms – block duration distribution

## Integrity Mechanisms
| Layer | Mechanism | Details |
|-------|-----------|---------|
| Agent Response | Schema validation + integrity digest | Rejects invalid fields; increments invalid counter; fallback noop with note. |
| Training | SHA256 over params + metrics digests | Stored in scoreboard with integrity hash length metric. |
| Simulation Cache | Per-entry SHA256 of metrics | Recomputed during scrape; mismatches counted. |
| Rate Limiter | Deterministic token bucket state | Stats exported; config accessible via meta API. |

## Tests
| File | Purpose |
|------|---------|
| test-agent-counters.js | Ensures action counters increment; verifies multiple actions distribution. |
| test-cache-integrity-scan.js | Corrupts one cache entry and detects mismatch via scan logic. |
| test-agent-rate-limiter.js | Validates token depletion, blocked invocation, refill aftermath. |
| test-agent-wrapper.js (existing) | Prompt shield behavior + integrity digest correctness. |
| test-training-integrity.js | Confirms reproducibility and integrity hash stability. |

## Metrics–Requirement Mapping
| Requirement | Implemented Metric(s) | Status |
|-------------|-----------------------|--------|
| Total invocations tracking | seraphina_agent_invocations_total | Done |
| Blocked prompt shield count | seraphina_agent_blocked_total | Done |
| Per-action decision counters | seraphina_agent_action_total | Done |
| Last action visibility | seraphina_agent_last_action | Done |
| Confidence surfacing | seraphina_agent_last_confidence | Done |
| Invalid suggestion capture | seraphina_agent_invalid_suggestions_total | Done |
| Rate limiter capacity & tokens | seraphina_agent_rate_limit_capacity, _tokens_remaining | Done |
| Rate limiter enabled flag | seraphina_agent_rate_limit_enabled / seraphina_agent_rate_enabled | Done |
| Rate limiter hits/blocked | seraphina_agent_rate_limit_hits_total / _blocked_total | Done |
| Refill timing | seraphina_agent_rate_limit_refill_seconds, _last_refill_timestamp_ms, _refill_interval_ms | Done |
| Cache integrity scan counters | seraphina_sim_cache_integrity_mismatches, _scanned | Done |
| Training performance & integrity | seraphina_train_* metrics | Done |
| Exporter protocol/version | seraphina_api_version, seraphina_exporter_protocol | Done |

## Recommendations / Follow-Ups
1. Consolidate rate limiter naming: choose either `rate_limit_*` or `rate_*` to reduce duplication; maintain aliases temporarily if external dashboards depend on both.
2. Add invalid suggestion rate metric (percentage) if needed: derive from invalidSuggestions / invocations in a recording rule.
3. Implement model signature metric (`seraphina_agent_model_sig`) once external model binding is added.
4. Add histogram metrics for latency or decision confidence distribution (e.g., `seraphina_agent_confidence_bucket`).
5. Document scrape performance considerations (integrity scan complexity O(N) per scrape).
6. Provide sample Prometheus recording rules in docs for composite KPIs (block ratio, token exhaustion frequency, integrity mismatch rate).

## Versioning
All new metrics added after version 0.2.3 should trigger a version bump (e.g., 0.2.4). Update `API_CONTRACT.md` with changes:
- Added hybrid processor & STL generator (non-Prometheus features but API surface adjuncts).
- Added invalid suggestions counter & enabled gauges.

## Conclusion
The agent observability and integrity feature set meets and extends initial requirements. Remaining work is mostly consolidation, advanced histograms, and model signature exposure.

---
Generated on: 2025-11-11T00:00:00Z (UTC placeholder)