# Custom Ubuntu Autoinstall ISO with Seraphina / Aurrelia Miner

This guide creates a self-contained Ubuntu Server ISO that auto-installs the OS and deploys the miner (no manual USB copy step). Uses Ubuntu autoinstall (cloud-init) with a `nocloud/` data source.

## Overview
1. Download Ubuntu Server ISO (e.g. 22.04 LTS).
2. Extract ISO contents to a working directory.
3. Inject `nocloud/` directory containing `user-data` and `meta-data`.
4. Copy the `mining/` workspace + installer script into ISO (e.g. under `seraphina/`).
5. Update boot config to automatically use autoinstall.
6. Repack ISO and flash with balenaEtcher.

## Requirements
- Host Linux (for loop mount, genisoimage or xorriso).
- Packages: `xorriso`, `squashfs-tools`, `isoinfo`, `p7zip-full` (optional).

## Step-by-Step
```bash
# 1. Variables
ISO=ubuntu-22.04.4-live-server-amd64.iso
WORK=iso-work
EXTRACT=iso-extract
MINER_SRC=/path/to/mining

mkdir -p "$WORK" "$EXTRACT"
cp "$ISO" "$WORK"/
cd "$WORK"

# 2. Extract ISO
7z x "$ISO" -o"$EXTRACT"
cd "$EXTRACT"

# 3. Create nocloud data source
mkdir -p nocloud
cat > nocloud/meta-data <<EOF
instance-id: seraphina-miner-01
local-hostname: seraphina-host
EOF

cat > nocloud/user-data <<'EOF'
#cloud-config
autoinstall:
  version: 1
  locale: en_US
  keyboard:
    layout: us
  identity:
    hostname: seraphina-host
    username: seraphina
    password: "$6$rounds=4096$abcdefghijklmnop$QyROJYhBqUopYkqE3SVoBqL2mICdaTq9tOEpOzXgqBvP8kVjsiD6s5JXq5mxgGumctvqYdGmYaQwaaqdG6C1P."
  ssh:
    install-server: true
  storage:
    layout:
      name: direct
  packages:
    - curl
    - gnupg
    - nodejs
    - npm
  late-commands:
    - curtin in-target --target=/target -- bash /cdrom/seraphina/install-seraphina.sh /cdrom/seraphina/mining /opt/seraphina
  user-data:
    disable_root: true
  updates: security
EOF

# (Password above is example hashed; replace.)

# 4. Copy miner workspace
mkdir -p seraphina
rsync -a --exclude node_modules "$MINER_SRC"/ seraphina/mining/
cp "$MINER_SRC"/install-seraphina.sh seraphina/
cp "$MINER_SRC"/artifact-hashes.json seraphina/ 2>/dev/null || true

# 5. Enable autoinstall kernel parameter
# Modify grub.cfg or isolinux.cfg depending on ISO structure.
if grep -q 'grub.cfg' ./boot/grub/grub.cfg; then
  sed -i 's/---/ autoinstall ds=nocloud\;s=\/cdrom\/nocloud ---/' ./boot/grub/grub.cfg
fi
if [ -f isolinux/txt.cfg ]; then
  sed -i 's/---/ autoinstall ds=nocloud\;s=\/cdrom\/nocloud ---/' isolinux/txt.cfg || true
fi

# 6. Rebuild ISO
cd ..
NEW_ISO=seraphina-ubuntu-autoinstall.iso
xorriso -as mkisofs -r -V "SERAPHINA_AUTOINSTALL" -J -l \
  -iso-level 3 -o "$NEW_ISO" "$EXTRACT"

echo "Created $NEW_ISO"
```

## Adjustments
## Ubuntu 24.04 Specific Notes
Ubuntu 24.04 live server images retain similar autoinstall mechanics; key differences:
- Kernel cmdline often includes `quiet splash` only; patch that line in `boot/grub/grub.cfg` to append `autoinstall ds=nocloud;s=/cdrom/nocloud`.
- If using secure boot, additional signing steps may be enforced; not covered here.
- Cloud-init schema unchanged for basic fields; advanced networking (Netplan YAML) can be embedded if static IP desirable.

Use the helper script:
```bash
sudo bash build-ubuntu-miner-iso.sh ubuntu-24.04.3-live-server-amd64.iso /path/to/mining
```
Resulting ISO: `seraphina-ubuntu-24.04-autoinstall.iso`.

Validation after install:
```bash
systemctl status seraphina-miner.service --no-pager
systemctl list-timers | grep seraphina
ls /opt/seraphina
```
### Optional Python Source Build
Place a verified `Python-<version>.tgz` in the mining source directory and set `INSTALL_PYTHON_SOURCE=1 PY_SRC_VERSION=<version>` (either in cloud-init or before running `install-seraphina.sh`). The installer will build an audited Python into `/opt/python` for private runtime usage. See `PYTHON-INTEGRATION.md`.
## Late-Command Notes
`curtin in-target` runs inside the installed target root (not the live environment). Using `/cdrom/seraphina/install-seraphina.sh` ensures the script is accessible from the mounted ISO.

## Validation
After flashing the new ISO:
1. Boot target machine; installation proceeds unattended.
2. Post first boot:
   ```bash
   systemctl status seraphina-miner.service --no-pager
   ls /opt/seraphina
   ```
3. Check monitor timer:
   ```bash
   systemctl list-timers | grep seraphina
   ```

## Troubleshooting
| Issue | Resolution |
|-------|------------|
| Autoinstall ignored | Ensure kernel line has `autoinstall ds=nocloud\;s=/cdrom/nocloud` |
| Late-command failed | Inspect `/var/log/installer/curtin-install.log` inside installed system |
| Service missing | Check that `install-seraphina.sh` executed and systemd units present |
| Node.js absent | Verify packages list or add tarball extraction in late-commands |

## Security Considerations
- Avoid embedding plaintext secrets (API keys, wallet seeds) in ISO. Provide them later via environment or vault file.
- Remove unnecessary scripts or dev tools to reduce attack surface.
- Validate `artifact-hashes.json` on target and compare HMAC seals externally.

## Next Steps
- Add Prometheus node_exporter to ISO packages if you want monitoring out of the box.
- Integrate firewall rules via cloud-init (ufw allow required ports).
- Add secondary late-command for immediate integrity audit and metrics export.

---
This ISO build process eliminates manual USB copy steps and ensures miner is active after unattended install.
