#!/usr/bin/env node
// Generate artifact-hashes.json with file list, sizes, sha256, Merkle root and optional HMAC seal.
const fs = require('fs');
const crypto = require('crypto');

const INCLUDE = [
  'aurrelia-pico-mesh-miner.js',
  'seraphina-mining-portable.js',
  'integrity-audit.js',
  'environment-audit.js',
  'package.json',
  'governance-ledger.jsonl',
  'share-ledger.jsonl',
  'swap-ledger.jsonl',
  'parity-ledger.jsonl',
  'econ-realization-ledger.jsonl',
  'price-ledger.jsonl',
  'tests/run-tests.js'
];

function fileInfo(f){
  try { const st=fs.statSync(f); const data=fs.readFileSync(f); return { file:f, size:st.size, sha256: crypto.createHash('sha256').update(data).digest('hex') }; } catch { return null; }
}

const artifacts = INCLUDE.map(fileInfo).filter(Boolean);
// Merkle root
let layer = artifacts.map(a=> a.sha256);
while(layer.length>1){
  const next=[];
  for(let i=0;i<layer.length;i+=2){
    const left=layer[i]; const right= layer[i+1] || left;
    next.push(crypto.createHash('sha256').update(left+right).digest('hex'));
  }
  layer=next;
}
const merkleRoot = layer.length? layer[0]: null;
// HMAC seal: attempt vault load if env var absent
let hmacSeal = null;
let manifestKey = process.env.USB_MANIFEST_HMAC_KEY || null;
if(!manifestKey && process.env.VAULT_PASS && process.env.VAULT_MANIFEST_KEY_LABEL){
  try {
    const { loadVaultSafe } = require('./seraphina-key-vault');
    const vault = loadVaultSafe(process.env.VAULT_PASS);
    const rec = vault[process.env.VAULT_MANIFEST_KEY_LABEL];
    if(rec && rec.value && /^[0-9a-fA-F]{64,128}$/.test(rec.value.trim())){
      manifestKey = rec.value.trim();
    }
  } catch(e){ /* ignore vault load errors */ }
}
if(manifestKey && merkleRoot){
  hmacSeal = crypto.createHmac('sha256', manifestKey).update(merkleRoot).digest('hex');
}
// Attempt to include latest integrity audit Merkle root if file present.
let auditMerkleRoot = null;
try {
  const auditFiles = fs.readdirSync('.').filter(f=>/^audit-.*\.json$/.test(f));
  let chosen=null; let chosenData=null; let maxTs=-1;
  for(const f of auditFiles){
    try {
      const data = JSON.parse(fs.readFileSync(f,'utf8'));
      const ts = typeof data.ts === 'number' ? data.ts : fs.statSync(f).mtimeMs;
      if(ts > maxTs){ maxTs = ts; chosen = f; chosenData = data; }
    } catch {}
  }
  if(chosenData){
    auditMerkleRoot = chosenData.globalMerkleRoot || chosenData.root || chosenData.merkleRoot || null;
  }
} catch(e){ /* silent */ }
const manifest = { generated: Date.now(), artifacts, merkleRoot, auditMerkleRoot, hmacSeal, count: artifacts.length };
fs.writeFileSync('artifact-hashes.json', JSON.stringify(manifest,null,2));
console.log(JSON.stringify(manifest));
