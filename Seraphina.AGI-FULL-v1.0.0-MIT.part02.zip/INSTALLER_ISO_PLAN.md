# Seraphina Full Operating System Installer ISO Plan

## Goal
Produce a bootable installer ISO (not just a live image) that installs a hardened Seraphina Miner OS onto a target disk with:
- Partitioning + filesystem creation
- Copying rootfs (from squashfs or pre-expanded tarball)
- Setting up bootloader (GRUB) on target
- Injecting configuration (hostname, networking, miner env)
- Enabling systemd services (miner, attest, reverify) post-install

## Current State
Existing scripts in `minimal-os/` build a Debian-based live ISO:
- `build-rootfs.sh`: Creates rootfs and integrity manifest + HMAC seal
- `build-iso.sh`: Builds squashfs, GRUB rescue ISO
- Services: `seraphina-miner.service` plus timers for attestation & reverify (can be extended)

This produces a *live* ISO that boots and runs in RAM using squashfs. For persistence, an installer phase is needed.

## Installer Strategy
1. Embed an installer script (`/usr/local/sbin/seraphina-installer`) inside the live environment.
2. On boot, user can select “Install Seraphina Miner OS” from GRUB or run `seraphina-installer` manually.
3. Script performs:
   - Disk selection / confirmation
   - Partition scheme creation (GPT):
     - EFI System Partition (if UEFI) 512MB (FAT32)
     - Root partition (ext4) remaining space
   - Format partitions
   - Mount target root (e.g., `/mnt/target`) and extract rootfs:
     - Option A: unsquashfs then rsync to /mnt/target
     - Option B: maintain a tarball (`rootfs.tar.gz`) for direct extraction
   - Install GRUB to target (UEFI + BIOS compatibility)
   - Copy manifest + seal into target `/` (for post-install verification)
   - Inject user config (hostname, env file) & optional SSH key
   - Enable miner services in target root (`chroot /mnt/target systemctl enable ...`)
   - Generate machine-specific HMAC (optional re-derivation using target serial)

## Autoinstall (Optional)
Provide kernel boot parameters to run installer unattended:
```
linux /boot/vmlinuz boot=live quiet seraphina.auto=1 seraphina.disk=/dev/sda seraphina.hostname=miner01 seraphina.seed=prod-seed
```
GRUB parses these and writes an answers file consumed by installer script.

## Security Hardening Steps
- After install, remount root as read-only except write points (/var/log, /opt/SeraphinaMiner/state).
- AppArmor profiles enforced (already added for miner process minimal set; extend rules file `seraphina-miner.profile`).
- Add fail2ban / minimal SSH; default passwordless root disabled.
- Optional full-disk encryption (future: integrate `cryptsetup luksFormat`).

## New Files To Add
- `minimal-os/seraphina-installer.sh` (installer logic)
- `minimal-os/grub-extra.cfg` (additional menu entry for installer)
- `minimal-os/parse-kernel-params.sh` (extract autoinstall variables)
- Update `build-iso.sh` to include installer entry

## Installer Script Outline
```
#!/bin/bash
set -euo pipefail
TARGET_DISK=${SERAPHINA_DISK:-"/dev/sda"}
# confirm wipe
# create partitions (sgdisk or parted) EFI + root
# format: mkfs.vfat /dev/sda1, mkfs.ext4 /dev/sda2
# mount root at /mnt/target
unsquashfs -f -d /mnt/target /boot/rootfs.squashfs
# or tar xzf rootfs.tar.gz -C /mnt/target
mount --bind /dev /mnt/target/dev; mount --bind /proc /mnt/target/proc; mount --bind /sys /mnt/target/sys
chroot /mnt/target update-initramfs -u
chroot /mnt/target grub-install $TARGET_DISK
chroot /mnt/target grub-mkconfig -o /boot/grub/grub.cfg
# enable services
chroot /mnt/target systemctl enable seraphina-miner.service seraphina-reverify.timer seraphina-attest.timer
# finalize
umount -R /mnt/target
```

## Balena Etcher Compatibility
Etcher requires a hybrid ISO with a standard boot structure. `grub-mkrescue` output is suitable. Ensure final ISO contains GPT + El Torito boot entries.

## Verification Flow Post-Install
1. On first boot from installed disk, service pre-scripts verify integrity manifest matches seal.
2. Attestation timer posts aggregate root.
3. Reverify timer schedules integrity checks.

## Rollback & Updates
Keep `releases/` structure in `/opt/SeraphinaMiner/`. Installer seeds initial release metadata. Subsequent updates use the existing update/rollback scripts.

## Next Steps Implementation Checklist
1. Add installer script & autoinstall parser.
2. Modify `build-iso.sh` to append GRUB menu entry.
3. Provide kernel params documentation in README-ISO.
4. Optional: create `rootfs.tar.gz` during build-rootfs for faster installation.
5. Test install in a VM, validate services start.
6. Generate signed manifest + record test anchor.

## Optional Enhancements
- Integrate cloud-init style config for early customization.
- Add network configuration selection (DHCP/static) pre-install.
- Allow selecting disk via GRUB (basic menu entries `/dev/sda`, `/dev/sdb`).
- Provide offline update bundle ingestion (USB second partition).

---
This plan enables evolution from a live image to a full installer ISO ready for flashing via Balena Etcher.
