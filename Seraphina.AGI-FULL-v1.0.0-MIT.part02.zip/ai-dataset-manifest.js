// ai-dataset-manifest.js
// Deterministic dataset manifest builder: hashes configured artifacts for reproducibility.
// Missing files are noted with null digest but retained for forward compatibility.
// Usage: node ai-dataset-manifest.js > ai-dataset-manifest.json

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256File(fp){
  try {
    const data = fs.readFileSync(fp);
    return crypto.createHash('sha256').update(data).digest('hex');
  } catch(e){
    return null; // missing or unreadable
  }
}

function loadConfig(){
  const cfgPath = path.join(__dirname,'ai-learning-config.json');
  const raw = fs.readFileSync(cfgPath,'utf8');
  return JSON.parse(raw);
}

function buildManifest(){
  const cfg = loadConfig();
  const root = __dirname;
  const now = new Date().toISOString();
  const manifest = {
    version: 1,
    generatedAt: now,
    configDigest: sha256File(path.join(root,'ai-learning-config.json')),
    artifacts: []
  };

  // Helper to register file
  function reg(label, rel){
    const full = path.join(root, rel);
    manifest.artifacts.push({ label, file: rel, exists: fs.existsSync(full), sha256: sha256File(full) });
  }

  // ML Advisor artifacts
  if(cfg.modules?.mlAdvisor){
    const m = cfg.modules.mlAdvisor;
    reg('mlAdvisor.weights', m.weightsFile);
    reg('mlAdvisor.scoreboard', m.scoreboard);
    reg('mlAdvisor.ledger', m.ledger);
  }

  // Trading artifacts
  if(cfg.modules?.trading){
    const t = cfg.modules.trading;
    reg('trading.signals', t.signals);
    reg('trading.learnedLedger', t.learnedLedger);
    reg('trading.performanceScoreboard', t.performanceScoreboard);
  }

  // Governance artifacts
  if(cfg.governance){
    reg('governance.proposals', cfg.governance.proposalFile);
    reg('governance.decisions', cfg.governance.decisionFile);
  }

  // Training ledgers (generic)
  reg('training.mlTrainLedger', 'ml-train-ledger.jsonl');
  reg('training.mlTrainScoreboard', 'ml-train-scoreboard.json');

  // Sort artifacts deterministically by label
  manifest.artifacts.sort((a,b)=> a.label.localeCompare(b.label));

  // Aggregate digest (chain) for integrity: hash of concatenated label+sha256 (null as '-')
  const chainSource = manifest.artifacts.map(a => a.label + ':' + (a.sha256 || '-')).join('|');
  manifest.aggregateChainDigest = crypto.createHash('sha256').update(chainSource).digest('hex');

  return manifest;
}

if(require.main === module){
  const manifest = buildManifest();
  process.stdout.write(JSON.stringify(manifest,null,2)+'\n');
}

module.exports = { buildManifest };
