// empowerment-stability.js
// Tracks sliding window of empowerment values and computes stability score.
// Stability metric: 1 - (coeffOfVariation) clamped to [0,1]; higher = more stable.
// Deterministic; window kept in JSON sidecar file.
'use strict';
const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname,'empowerment-stability-state.json');
const DEFAULT_WINDOW = parseInt(process.env.EMPOWERMENT_STABILITY_WINDOW || '20',10);

function loadState(){
  if(!fs.existsSync(STATE_FILE)) return { window: DEFAULT_WINDOW, values: [] };
  try { return JSON.parse(fs.readFileSync(STATE_FILE,'utf8')); } catch(_){ return { window: DEFAULT_WINDOW, values: [] }; }
}

function saveState(s){
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(s,null,2)); } catch(_){ }
}

function computeStats(arr){
  if(!arr.length) return {mean:0, stdev:0, cov:1};
  const mean = arr.reduce((a,b)=>a+b,0)/arr.length;
  const variance = arr.reduce((a,b)=> a + (b-mean)*(b-mean),0)/arr.length;
  const stdev = Math.sqrt(variance);
  const cov = mean === 0 ? 1 : stdev/mean; // if mean 0 treat as fully unstable
  return {mean, stdev, cov};
}

function recordEmpowerment(value){
  const state = loadState();
  state.values.push(Number(value||0));
  if(state.values.length > state.window) state.values = state.values.slice(-state.window);
  const stats = computeStats(state.values);
  // stability = 1 - normalized cov (cap cov at 1 for mapping)
  const stability = Math.max(0, 1 - Math.min(1, stats.cov));
  state.stability = Number(stability.toFixed(6));
  state.mean = Number(stats.mean.toFixed(6));
  state.stdev = Number(stats.stdev.toFixed(6));
  saveState(state);
  return state;
}

module.exports = { recordEmpowerment };
