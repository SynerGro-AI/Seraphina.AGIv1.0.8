// extranonce2-guard.js
// Provides a unique, random-but-deterministically-seeded extranonce2 generator per instance.
// Integrate by requiring this module and using nextExtranonce2(size) instead of raw counters.
// Ensures no collision across AUR_INSTANCE_INDEX processes via (seed ^ index) domain separation.

const crypto = require('crypto');
const baseSeed = parseInt(process.env.AUR_SEED || '42',10) >>> 0;
const instIndex = parseInt(process.env.AUR_INSTANCE_INDEX || '0',10) >>> 0;
let counter = 0;

function deriveKey(){
  return crypto.createHash('sha256').update(`ex2:${baseSeed}:${instIndex}`).digest();
}
const key = deriveKey();

function nextExtranonce2(size){
  // size in bytes (pool provided), produce hex string of that size deterministically evolving
  // Combine: key xor counter hash for drifted uniqueness
  const h = crypto.createHash('sha256').update(key).update(Buffer.from([counter & 0xFF, (counter>>>8)&0xFF, (counter>>>16)&0xFF, (counter>>>24)&0xFF])).digest();
  counter++;
  return h.slice(0,size).toString('hex');
}

module.exports = { nextExtranonce2 };
