'use strict';
// autonomy-decision-engine.js – drafts parameter changes based on deterministic trends.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { PARAM_BOUNDS } = require('./governance-engine.js');
const moral = require('./moral-check.js');

const SUMMARY_LEDGER = path.join(__dirname,'ai-learning-summary-ledger.jsonl');
const DRAFT_FILE = path.join(__dirname,'governance-proposal-drafts.jsonl');
const PENDING_COMMANDS_FILE = path.join(__dirname,'pending-commands-drafts.jsonl');
const { classify } = require('./command-risk-classifier.js');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }
function loadRecentSummaries(n){
  if(!fs.existsSync(SUMMARY_LEDGER)) return [];
  const lines = fs.readFileSync(SUMMARY_LEDGER,'utf8').trim().split(/\n+/).slice(-n);
  return lines.map(l=>{ try{return JSON.parse(l);}catch(_){return null;} }).filter(Boolean);
}
function trendAdjust(values){ if(values.length<3) return 0; return (values[values.length-1]-values[0])/values.length; }
function propose(params){
  const validation = moral.validateProposal(params);
  if(!validation.ok) return null;
  return { id:'auto-'+Date.now()+'-'+sha256(params).slice(0,8), params, rationale:{ ts:Date.now(), motive:'autonomy-trend-adjust' }, guidelines: validation.guidelines };
}
function autonomousCycle(){
  if(process.env.AUTONOMY_ENABLED !== '1') return null;
  // Batch high-risk command rejection (advisory ledger) before any parameter proposal
  try {
    if(process.env.AUTONOMY_REJECT_HIGH_COMMANDS === '1' && fs.existsSync(PENDING_COMMANDS_FILE)){
      const lines = fs.readFileSync(PENDING_COMMANDS_FILE,'utf8').trim().split(/\n+/).filter(Boolean);
      const kept=[]; const rejected=[];
      lines.forEach(l=>{
        try {
          const obj = JSON.parse(l);
          if(obj && obj.command){
            const res = classify(String(obj.command));
            if(res.risk === 'HIGH'){ rejected.push({ command: obj.command, reasons: res.reasons }); }
            else kept.push(l);
          } else { kept.push(l); }
        } catch(_){ kept.push(l); }
      });
      if(rejected.length){
        // Rewrite pending file with kept only (deterministic order)
        fs.writeFileSync(PENDING_COMMANDS_FILE, kept.join('\n') + (kept.length?'\n':''));
        // Append rejection ledger file
        const rejFile = path.join(__dirname,'autonomy-command-rejections.jsonl');
        rejected.forEach(r=>{
          const entry = { ts:Date.now(), type:'command-reject', command:r.command, reasons:r.reasons };
          try { fs.appendFileSync(rejFile, JSON.stringify(entry)+'\n'); } catch(_){ }
        });
        // Metrics gauge update (if registry available)
        try {
          if(global.__AUR_METRICS_REG__ && global.__AUR_METRICS_REG__.gauges){
            const prom = require('prom-client');
            const g = global.__AUR_METRICS_REG__.gauges;
            if(!g.autonomyCommandRejections){ g.autonomyCommandRejections = new prom.Gauge({ name:'aurrelia_autonomy_command_rejections', help:'High-risk commands rejected this autonomy cycle' }); global.__AUR_METRICS_REG__.registry.registerMetric(g.autonomyCommandRejections); }
            g.autonomyCommandRejections.set(rejected.length);
          }
        } catch(_){ }
      }
    }
  } catch(_){ }
  const windowSize = parseInt(process.env.REGRESSION_WINDOW_SIZE || '10',10);
  const summaries = loadRecentSummaries(windowSize);
  if(!summaries.length) return null;
  const effs = summaries.map(s=> s.improvement?.effectiveImprovement||0);
  const slope = trendAdjust(effs);
  const avgEff = effs.reduce((a,b)=>a+b,0)/effs.length;
  const minRequired = parseFloat(process.env.GLOBAL_MIN_IMPROVEMENT||'0');
  const maxDelta = parseFloat(process.env.AUTONOMY_MAX_PARAM_DELTA||'0');
  let draft = null;
  if(slope < 0 && avgEff < minRequired){
    const curImagW = parseFloat(process.env.IMAGINATION_GAIN_WEIGHT||'0');
    const bounds = PARAM_BOUNDS.IMAGINATION_GAIN_WEIGHT;
    const target = Math.min(bounds[1], curImagW + Math.min(maxDelta, 0.25));
    if(target !== curImagW) draft = propose({ IMAGINATION_GAIN_WEIGHT: Number(target.toFixed(4)) });
  }
  const last = summaries[summaries.length-1];
  if(!draft && last && typeof last.dimensionCost === 'number'){
    const altLimit = parseFloat(process.env.IMAGINATION_DIM_COST_ALT_LIMIT||'0');
    if(altLimit>0 && last.dimensionCost > altLimit){
      const curTarget = parseInt(process.env.IMAGINATION_DIM_TARGET||process.env.IMAGINATION_DIM||'3',10);
      const newTarget = Math.max(3, Math.floor(curTarget*0.9));
      if(newTarget < curTarget){ draft = propose({ IMAGINATION_DIM_TARGET: newTarget }); }
    }
  }
  if(draft){ try { fs.appendFileSync(DRAFT_FILE, JSON.stringify(draft)+'\n'); } catch(_){ } return draft; }
  return null;
}
module.exports = { autonomousCycle };