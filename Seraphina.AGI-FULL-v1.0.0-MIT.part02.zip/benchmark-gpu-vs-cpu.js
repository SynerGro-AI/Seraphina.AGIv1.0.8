// benchmark-gpu-vs-cpu.js
// Simple comparative harness: CPU doubleSha256 vs GPU batch (if available)
// Usage: AUR_GPU=1 node benchmark-gpu-vs-cpu.js [N]

const crypto = require('crypto');
const { performance } = require('perf_hooks');
const N = parseInt(process.argv[2] || '4096',10);

function doubleSha256(hex){
  const buf = Buffer.from(hex,'hex');
  const h1 = crypto.createHash('sha256').update(buf).digest();
  const h2 = crypto.createHash('sha256').update(h1).digest();
  return h2;
}

let gpu = null; let gpuEnabled=false;
try { gpu = require('./gpu_sha256d_native.js'); if (gpu && gpu.available) gpuEnabled=true; } catch(_){ }
if (!gpuEnabled){
  console.log('[Benchmark] GPU native addon not available; CPU-only baseline. Build with npm run build:gpu');
}

// Generate deterministic random-ish headers (80 bytes) by hashing index
const headers = [];
for (let i=0;i<N;i++){
  const seed = crypto.createHash('sha256').update('hdr:'+i).digest();
  // Assemble 80 bytes: first 32 from seed, next 32 from sha(seed), last 16 from sha(i||seed)
  const seed2 = crypto.createHash('sha256').update(seed).digest();
  const seed3 = crypto.createHash('sha256').update(seed2).digest();
  const h80 = Buffer.concat([seed, seed2, seed3.slice(0,16)]); // 32+32+16=80
  headers.push(h80);
}

// CPU baseline
const t0 = performance.now();
for (let i=0;i<N;i++) doubleSha256(headers[i].toString('hex'));
const t1 = performance.now();
const cpuMs = t1 - t0;
console.log(`[Benchmark] CPU sha256d ${N} headers in ${cpuMs.toFixed(2)} ms -> ${(N/cpuMs).toFixed(2)} h/ms -> ${(N/cpuMs*1000).toFixed(0)} h/s`);

if (gpuEnabled){
  const batchHex = headers.map(b=> b.toString('hex'));
  const t2 = performance.now();
  const digests = gpu.hashBatch(headers); // expects array<Buffer>
  const t3 = performance.now();
  const gpuMs = t3 - t2;
  console.log(`[Benchmark] GPU sha256d ${N} headers in ${gpuMs.toFixed(2)} ms -> ${(N/gpuMs).toFixed(2)} h/ms -> ${(N/gpuMs*1000).toFixed(0)} h/s`);
  // Parity sample (first 5)
  let mismatches=0;
  for (let i=0;i<Math.min(5,N);i++){
    const ref = doubleSha256(batchHex[i]);
    if (!digests[i].equals(ref)) mismatches++;
  }
  if (mismatches) console.warn(`[Benchmark] Parity mismatches in sample: ${mismatches}`);
  console.log(`[Benchmark] Speedup x${(cpuMs/gpuMs).toFixed(2)} (approx)`);
}
