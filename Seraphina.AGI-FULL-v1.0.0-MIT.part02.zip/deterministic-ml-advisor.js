// deterministic-ml-advisor.js
// Deterministic ML advisory stub using static quantized weights.
// Produces normalized recommendation score adjustments without randomness.
// All outputs are advisory only; policy engine still required for parameter changes.

'use strict';
const crypto = require('crypto');
const fs = require('fs');

// External weights loading with deterministic fallback
const WEIGHTS_PATH = process.env.ML_ADVISOR_WEIGHTS_PATH || 'ml-advisor-weights.json';
let WEIGHTS = {
  version: 'stub-q1',
  // Added optional frenRevenueNorm feature (if provided context includes it) at end of vector.
  features: ['acceptRatio','latencyMedian','incomeSpread','biasFREN','biasRVN','frenRevenueNorm'],
  vector: [0.33, -0.14, 0.24, 0.17, 0.06, 0.34]
};
try {
  if (fs.existsSync(WEIGHTS_PATH)){
    const data = JSON.parse(fs.readFileSync(WEIGHTS_PATH,'utf8'));
    if (Array.isArray(data.vector) && Array.isArray(data.features) && data.vector.length === data.features.length){
      WEIGHTS = data;
    }
  }
} catch(e){ /* fallback to embedded weights */ }
const WEIGHTS_VERSION_HASH = crypto.createHash('sha256').update(JSON.stringify({v:WEIGHTS.version, vec:WEIGHTS.vector})).digest('hex');

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function extractFeatures(ctx){
  const acceptRatio = typeof ctx.acceptRatio === 'number'? ctx.acceptRatio : 0;
  const latencyMedian = typeof ctx.latencyMedian === 'number'? ctx.latencyMedian : 0;
  const incomeSpread = typeof ctx.incomeSpread === 'number'? ctx.incomeSpread : 0;
  const biasFREN = typeof ctx.biasFREN === 'number'? ctx.biasFREN : 1;
  const biasRVN = typeof ctx.biasRVN === 'number'? ctx.biasRVN : 1;
  const frenRevenueNorm = typeof ctx.frenRevenueNorm === 'number'? ctx.frenRevenueNorm : 0; // normalized FREN revenue per hash (0-1)
  return [acceptRatio, latencyMedian, incomeSpread, biasFREN, biasRVN, frenRevenueNorm];
}

function advise(ctx){
  try {
    const feats = extractFeatures(ctx);
    // Deterministic dot product
    let score = 0;
    for(let i=0;i<WEIGHTS.vector.length;i++){
      score += WEIGHTS.vector[i] * feats[i];
    }
    // Normalize to [0,1] with logistic-like clamp
    const norm = 1/(1+Math.exp(-score));
    const rounded = Number(norm.toFixed(8));
    const digest = stableHash({ feats, score: Number(score.toFixed(12)) });
    // Suggest potential bias delta toward top recommended coin if confidence low
    let action = 'noop'; let delta = 0;
    if (rounded < 0.45){ action='suggest_bias_increase'; delta=0.02; }
    else if (rounded > 0.85){ action='suggest_bias_reduce'; delta=-0.015; }
    return { modelVersion: WEIGHTS.version, versionHash: WEIGHTS_VERSION_HASH, score: rounded, action, delta, digest };
  } catch(e){ return { modelVersion: WEIGHTS.version, versionHash: WEIGHTS_VERSION_HASH, error:e.message }; }
}
module.exports = { advise, WEIGHTS_VERSION_HASH, WEIGHTS };
