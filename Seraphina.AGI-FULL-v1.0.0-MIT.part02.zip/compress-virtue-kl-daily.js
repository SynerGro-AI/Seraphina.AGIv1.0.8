// compress-virtue-kl-daily.js
// Aggregates last 24h of moral safety, advisory, and drift ledgers into daily summary.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const SAFETY_LEDGER = process.env.SERAPHINA_MORAL_SAFETY_LEDGER || 'seraphina-moral-safety-ledger.jsonl';
const ADVISORY_LEDGER = process.env.SERAPHINA_ADVISORY_LEDGER || 'seraphina-advisory-ledger.jsonl';
const DRIFT_LEDGER = process.env.SERAPHINA_DRIFT_LEDGER || 'seraphina-drift-ledger.jsonl';
const OUT_LEDGER = process.env.SERAPHINA_DAILY_SUMMARY_LEDGER || 'seraphina-daily-summary-ledger.jsonl';
const WINDOW_MS = 24*3600*1000;

function readLines(path){ if(!fs.existsSync(path)) return []; return fs.readFileSync(path,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean); }
function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

function aggregate(){
  const now = Date.now();
  const since = now - WINDOW_MS;
  const safety = readLines(SAFETY_LEDGER).filter(e=> e.ts >= since);
  const advisory = readLines(ADVISORY_LEDGER).filter(e=> e.ts >= since);
  const drift = readLines(DRIFT_LEDGER).filter(e=> e.ts >= since);
  const avgVirtue = (name)=>{
    const vals = safety.map(e=> e.virtues && e.virtues[name]).filter(v=> typeof v==='number');
    if(!vals.length) return 0; return Number((vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(6));
  };
  const avgKL = drift.length? Number((drift.reduce((a,b)=> a + (b.kl||0),0)/drift.length).toFixed(6)) : 0;
  const actionsDist = advisory.reduce((acc,e)=>{ acc[e.action] = (acc[e.action]||0)+1; return acc; },{});
  const summary = {
    ts: now,
    iso: new Date(now).toISOString(),
    windowMs: WINDOW_MS,
    counts: { safety: safety.length, advisory: advisory.length, drift: drift.length },
    avgVirtues: {
      empathy: avgVirtue('empathy'), prudence: avgVirtue('prudence'), temperance: avgVirtue('temperance'), justice: avgVirtue('justice'), beneficence: avgVirtue('beneficence'), integrity: avgVirtue('integrity')
    },
    avgKL,
    actionsDist
  };
  let prev='GENESIS';
  if(fs.existsSync(OUT_LEDGER)){
    const lines = fs.readFileSync(OUT_LEDGER,'utf8').trim().split(/\n+/); if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch{} }
  }
  summary.prevHash=prev; summary.chainHash=stableHash(summary);
  fs.appendFileSync(OUT_LEDGER, JSON.stringify(summary)+'\n');
  console.log('[DailyCompress] Summary appended', summary.iso, 'avgKL='+summary.avgKL);
  return summary;
}

if(require.main===module){ aggregate(); }
module.exports = { aggregate };
