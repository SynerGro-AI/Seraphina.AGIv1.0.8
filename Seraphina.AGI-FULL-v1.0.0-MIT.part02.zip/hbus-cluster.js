// hbus-cluster.js
// Cluster-level HBUS integration for rankProxy damp factor.
// Reads a local file (JSONL) cluster-rank-feed.jsonl with entries { t, proxy }.
// Provides: getClusterRank(), getDampFactor(localMean)

const fs = require('fs');
const path = require('path');
const FEED_FILE = process.env.HBUS_FEED_FILE || path.join(process.cwd(),'cluster-rank-feed.jsonl');
const WINDOW = parseInt(process.env.HBUS_FEED_WINDOW || '100',10);
let cache={ avg:null, lastM:0 };

function _read(){
  try {
    const st = fs.statSync(FEED_FILE);
    if (st.mtimeMs <= cache.lastM) return cache.avg;
    const lines = fs.readFileSync(FEED_FILE,'utf8').trim().split(/\n/).slice(-WINDOW);
    const vals=[];
    for (const l of lines){ try { const o=JSON.parse(l); const v=o.proxy??o.rankProxy; if (typeof v==='number' && isFinite(v)) vals.push(v); } catch(_){ } }
    if (vals.length){ cache.avg = vals.reduce((a,b)=>a+b,0)/vals.length; } else { cache.avg=null; }
    cache.lastM = st.mtimeMs; return cache.avg;
  } catch(_){ return cache.avg; }
}

function getClusterRank(){ return _read(); }
function getDampFactor(localMean){ const c=_read(); const ref = c!=null? c : localMean; if (ref==null) return 1.0; return ref < 1.05 ? 0.97 : 1.0; }

module.exports = { getClusterRank, getDampFactor };
