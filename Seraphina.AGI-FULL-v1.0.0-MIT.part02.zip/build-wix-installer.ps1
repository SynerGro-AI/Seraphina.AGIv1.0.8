Param(
  [string]$SourceDir = "$PSScriptRoot",
  [string]$OutDir = "$PSScriptRoot\dist-wix",
  [string]$Version = '1.0.0'
)
$ErrorActionPreference = 'Stop'
Write-Host "[WiX] Building MSI installer..." -ForegroundColor Cyan
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

# Requirements: WiX Toolset (candle.exe, light.exe, heat.exe) on PATH
$candle = Get-Command candle.exe -ErrorAction SilentlyContinue
$light = Get-Command light.exe -ErrorAction SilentlyContinue
$heat = Get-Command heat.exe -ErrorAction SilentlyContinue
if (-not $candle -or -not $light -or -not $heat) { throw "WiX Toolset not found (candle.exe, light.exe, heat.exe must be on PATH)." }

# Harvest source directory files (excluding node_modules if huge)
$harvestWxs = Join-Path $OutDir 'Harvest.wxs'
Write-Host "[WiX] Harvesting $SourceDir" -ForegroundColor DarkGray
& $heat dir $SourceDir -dr INSTALLDIR -cg HarvestComponents -gg -sreg -sfrag -srd -out $harvestWxs -platform x64 -var var.SourceDir -t $SourceDir\SeraphinaMiner.wxs | Out-Null

# Merge base .wxs (ensure version override)
$baseWxs = Join-Path $SourceDir 'SeraphinaMiner.wxs'
if (-not (Test-Path $baseWxs)) { throw "Base SeraphinaMiner.wxs not found." }

# Compile
Write-Host "[WiX] Compiling .wxs files" -ForegroundColor DarkGray
& $candle -dSourceDir=$SourceDir -dVersion=$Version -out (Join-Path $OutDir 'SeraphinaMiner.wixobj') $baseWxs | Out-Null
& $candle -dSourceDir=$SourceDir -dVersion=$Version -out (Join-Path $OutDir 'Harvest.wixobj') $harvestWxs | Out-Null

# Link
$msiPath = Join-Path $OutDir "SeraphinaMiner-$Version-x64.msi"
Write-Host "[WiX] Linking -> $msiPath" -ForegroundColor DarkGray
& $light -ext WixUIExtension -out $msiPath (Join-Path $OutDir 'SeraphinaMiner.wixobj') (Join-Path $OutDir 'Harvest.wixobj') | Out-Null

if (-not (Test-Path $msiPath)) { throw "MSI build failed" }

# Hash manifest
$sha256 = (Get-FileHash -Path $msiPath -Algorithm SHA256).Hash
$manifestObj = [ordered]@{ name = (Split-Path $msiPath -Leaf); version = $Version; built = (Get-Date).ToString('o'); sha256 = $sha256 }
$manifestJson = ($manifestObj | ConvertTo-Json -Depth 4)
Set-Content -Path (Join-Path $OutDir 'msi-manifest.json') -Value $manifestJson -Encoding UTF8
Set-Content -Path (Join-Path $OutDir 'msi.sha256') -Value "$sha256  $(Split-Path $msiPath -Leaf)" -Encoding ASCII
Write-Host "[WiX] Build complete." -ForegroundColor Green
