'use strict';
// command-risk-classifier.js
// Deterministic classification of shell commands into LOW / MED / HIGH risk categories.
// Outputs structured object with fields: { command, risk, reasons:[...], tokens:[], hash }
// No external execution; purely static analysis heuristics.

const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

// Regex groups (order matters; first matching reason sets at least that risk level, but we accumulate all reasons).
let PATTERNS = [
  { risk:'HIGH', regex:/\b(wipefs|dd|mkfs\w*|grub-install|update-grub|parted|fdisk|mkswap|cryptsetup)\b/i, reason:'Disk/boot modification' },
  { risk:'HIGH', regex:/\brm\s+-rf\b/i, reason:'Recursive force delete' },
  { risk:'HIGH', regex:/\bpasswd\b.*\broot\b/i, reason:'Root password change' },
  { risk:'HIGH', regex:/\bmount\b.*\bdev\/sd[a-z]\d?\b/i, reason:'Direct disk mount (verify device)' },
  { risk:'HIGH', regex:/\bchown\b.*\broot:root\b/i, reason:'Ownership change to root' },
  { risk:'MED',  regex:/\bapt\s+(remove|purge|install|upgrade)\b/i, reason:'Package manager state change' },
  { risk:'MED',  regex:/\bsed\s+-i\b/i, reason:'In-place file edit' },
  { risk:'MED',  regex:/\bchmod\b\s+7[0-7]{2}/i, reason:'Broad permission grant' },
  { risk:'MED',  regex:/\bmount\b.*-o\s+loop/i, reason:'Loop mount (verify ISO integrity)' },
  { risk:'MED',  regex:/\bkill\b.*-9/i, reason:'Force process termination' },
  { risk:'LOW',  regex:/\b(ls|cat|echo|pwd|whoami|uptime|date)\b/i, reason:'Informational command' },
  { risk:'LOW',  regex:/\bping\b/i, reason:'Network reachability check' },
];

// Optional external pattern loading (deterministic append) when COMMAND_RISK_PATTERNS_ENABLE=1
try {
  if(process.env.COMMAND_RISK_PATTERNS_ENABLE === '1'){
    const fs = require('fs');
    const path = require('path');
    const extPath = path.join(__dirname,'command-risk-patterns.json');
    if(fs.existsSync(extPath)){
      const raw = fs.readFileSync(extPath,'utf8');
      const arr = JSON.parse(raw);
      if(Array.isArray(arr)){
        const extra = arr.filter(p=> p && typeof p.regex==='string' && typeof p.reason==='string' && /^(LOW|MED|HIGH)$/.test(p.risk)).map(p=> ({
          risk: p.risk,
          regex: new RegExp(p.regex, 'i'),
          reason: p.reason
        }));
        if(extra.length){ PATTERNS = PATTERNS.concat(extra); }
      }
    }
  }
} catch(_){ /* ignore malformed pattern file */ }

function tokenize(cmd){
  return cmd.split(/\s+/).filter(Boolean);
}

function classify(cmd){
  const tokens = tokenize(cmd);
  const reasons=[]; let risk='LOW';
  PATTERNS.forEach(p=>{ if(p.regex.test(cmd)){ reasons.push(p.reason); if(p.risk === 'HIGH') risk='HIGH'; else if(p.risk==='MED' && risk!=='HIGH') risk='MED'; } });
  // Additional heuristic escalations
  if(/sudo\b/.test(cmd) && risk==='LOW'){ risk='MED'; reasons.push('Elevated privilege via sudo'); }
  if(/--force\b/.test(cmd) && risk!=='HIGH'){ risk='MED'; reasons.push('Force flag present'); }
  if(/\b(systemd.unit=emergency.target|init=\/bin\/bash)\b/.test(cmd)){ risk='HIGH'; reasons.push('Boot override / emergency mode'); }
  const structured = { command:cmd, risk, reasons:[...new Set(reasons)], tokens, hash: sha256(cmd) };
  return structured;
}

function classifyBatch(lines){
  return lines.map(l=> classify(l));
}

if(require.main === module){
  const args = process.argv.slice(2);
  const stdin = process.stdin;
  if(args.includes('--batch')){
    // Read lines from stdin
    let raw='';
    stdin.setEncoding('utf8');
    stdin.on('data', chunk=> raw+=chunk);
    stdin.on('end', ()=>{
      const lines = raw.split(/\n+/).filter(Boolean);
      const out = classifyBatch(lines);
      process.stdout.write(JSON.stringify(out,null,2)+'\n');
    });
  } else {
    const cmd = args.join(' ');
    process.stdout.write(JSON.stringify(classify(cmd),null,2)+'\n');
  }
}

module.exports = { classify, classifyBatch };
