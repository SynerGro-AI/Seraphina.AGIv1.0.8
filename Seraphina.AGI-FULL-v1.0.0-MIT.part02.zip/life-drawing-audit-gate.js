#!/usr/bin/env node
// life-drawing-audit-gate.js
// Parses `npm audit --json` from stdin or executes audit, enforcing severity thresholds.
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function readAuditJson(){
  let input = '';
  if(!process.stdin.isTTY){
    try { input = require('fs').readFileSync(0,'utf8'); } catch(_){ }
  }
  if(input.trim()){ try { return JSON.parse(input); } catch(e){ return null; } }
  const res = spawnSync('npm',['audit','--json'], { encoding:'utf8' });
  if(res.status !== 0 && !res.stdout) return null;
  try { return JSON.parse(res.stdout); } catch(e){ return null; }
}

function gate(audit){
  if(!audit){
    // fallback to cached latest history
    try {
      const histPath = path.join(__dirname,'life-drawing-audit-history.jsonl');
      if(fs.existsSync(histPath)){
        const lines = fs.readFileSync(histPath,'utf8').trim().split(/\n+/).filter(Boolean);
        const last = lines.length? JSON.parse(lines[lines.length-1]) : null;
        if(last && last.counts){
          const maxHigh = parseInt(process.env.AUDIT_GATE_MAX_HIGH || '5',10);
          const maxCritical = parseInt(process.env.AUDIT_GATE_MAX_CRITICAL || '0',10);
          const pass = last.counts.high <= maxHigh && last.counts.critical <= maxCritical;
          return { ok: pass, counts: last.counts, cached: true, ts: last.ts, thresholds: { high: maxHigh, critical: maxCritical } };
        }
      }
    } catch(_){ }
    return { ok:false, message:'No audit data' };
  }
  // Count advisories by severity
  const counts = { low:0, moderate:0, high:0, critical:0 };
  const advisories = audit.advisories || audit.vulnerabilities || {};
  // npm v7+ structure uses vulnerabilities object
  if(advisories && !Array.isArray(advisories)){
    Object.values(advisories).forEach(v=>{
      if(v.severity && counts[v.severity] != null) counts[v.severity] += 1;
    });
  }
  const maxHigh = parseInt(process.env.AUDIT_GATE_MAX_HIGH || '5',10);
  const maxCritical = parseInt(process.env.AUDIT_GATE_MAX_CRITICAL || '0',10);
  const pass = counts.high <= maxHigh && counts.critical <= maxCritical;
  return { ok: pass, counts, thresholds: { high: maxHigh, critical: maxCritical } };
}

if(require.main === module){
  const audit = readAuditJson();
  console.log(JSON.stringify(gate(audit), null, 2));
}

module.exports = { gate };
