// ledger-hmac-chain.js
// Provides append + verify for real share/economic ledgers using chained HMAC for tamper evidence.
// Usage: const chain = require('./ledger-hmac-chain'); chain.append('share-ledger.jsonl', obj);
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

function _rawSecret(){ return process.env.LEDGER_CHAIN_SECRET || 'LEDGER_CHAIN_DEV_SECRET'; }
function _epochMs(){ return parseInt(process.env.LEDGER_ROTATE_INTERVAL_MS || '3600000',10); }
function _epochIndex(ts){ return Math.floor(ts / _epochMs()); }
function key(epochIdx){
  const secret = _rawSecret();
  const base = crypto.createHash('sha256').update(secret).digest('hex');
  return crypto.createHash('sha256').update(base + ':' + epochIdx).digest();
}

function append(file, obj){
  const full = path.isAbsolute(file) ? file : path.join(process.cwd(), file);
  const lines = fs.existsSync(full) ? fs.readFileSync(full,'utf8').trim().split(/\n/).filter(Boolean) : [];
  const prev = lines.length ? JSON.parse(lines[lines.length-1]) : null;
  const core = { ...obj }; // exclude chain fields from base string
  const baseStr = JSON.stringify(core);
  const ts = typeof core.t === 'number' ? core.t : Date.now();
  const epochIdx = _epochIndex(ts);
  const chainInput = (prev?prev.lineHmac:'GENESIS') + '|' + baseStr + '|' + epochIdx;
  const lineHmac = crypto.createHmac('sha256', key(epochIdx)).update(chainInput).digest('hex');
  const rec = { ...core, prevHmac: prev?prev.lineHmac:null, lineHmac, epoch: epochIdx };
  fs.appendFileSync(full, JSON.stringify(rec) + '\n');
  return rec;
}

function verify(file){
  const full = path.isAbsolute(file) ? file : path.join(process.cwd(), file);
  if (!fs.existsSync(full)) return { ok:true, count:0 };
  const lines = fs.readFileSync(full,'utf8').trim().split(/\n/).filter(Boolean).map(l=>JSON.parse(l));
  let prev=null; for (let i=0;i<lines.length;i++){
    const cur = lines[i];
    const core = { ...cur }; delete core.prevHmac; delete core.lineHmac; delete core.epoch;
    const baseStr = JSON.stringify(core);
    const epochIdx = typeof cur.epoch === 'number' ? cur.epoch : _epochIndex(cur.t || Date.now());
    const chainInput = (prev?prev.lineHmac:'GENESIS') + '|' + baseStr + '|' + epochIdx;
    const expected = crypto.createHmac('sha256', key(epochIdx)).update(chainInput).digest('hex');
    if (expected !== cur.lineHmac){ return { ok:false, badIndex:i, count:lines.length }; }
    prev=cur;
  }
  return { ok:true, count:lines.length };
}

function verifyAllEpochs(file){
  const full = path.isAbsolute(file) ? file : path.join(process.cwd(), file);
  if (!fs.existsSync(full)) return { ok:true, epochs:[], count:0 };
  const lines = fs.readFileSync(full,'utf8').trim().split(/\n/).filter(Boolean).map(l=>JSON.parse(l));
  const epochs = new Set(); let prev=null;
  for (let i=0;i<lines.length;i++){
    const cur = lines[i]; epochs.add(cur.epoch);
    const core = { ...cur }; delete core.prevHmac; delete core.lineHmac; delete core.epoch;
    const baseStr = JSON.stringify(core);
    const chainInput = (prev?prev.lineHmac:'GENESIS') + '|' + baseStr + '|' + cur.epoch;
    const expected = crypto.createHmac('sha256', key(cur.epoch)).update(chainInput).digest('hex');
    if (expected !== cur.lineHmac){ return { ok:false, badIndex:i, count:lines.length, epochs:[...epochs] }; }
    prev=cur;
  }
  return { ok:true, count:lines.length, epochs:[...epochs].sort((a,b)=>a-b) };
}

module.exports = { append, verify, verifyAllEpochs };
