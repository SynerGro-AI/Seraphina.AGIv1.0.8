// Explorer Multi-Provider Abstraction (RVN + FREN placeholder)
// Goals:
//  - Deterministic provider rotation (round-robin with health scoring)
//  - Backoff & failover when providers error
//  - Normalized outputs for: getTx(txid), getAddress(addr), getUtxos(addr) (RVN only), getHeight()
//  - Caching layer (time-based) to reduce duplicate calls
//  - Dry-run deterministic fallback if no providers reachable (returns synthetic but hash-stable data)
//  - Integration hooks: future readiness endpoint can query explorer health via exported health snapshot

const crypto = require('crypto');
const https = require('https');

// Provider configuration from ENV (comma separated) else defaults
// Example: RVN_EXPLORERS="https://ravenexplorer.com/api,https://another-provider/api"
const RVN_PROVIDERS = (process.env.RVN_EXPLORERS || 'https://api.ravencoin.org/api').split(',').map(s=> s.trim()).filter(Boolean);
// FREN (fictional coin) placeholder explorers (can be updated via env FREN_EXPLORERS)
const FREN_PROVIDERS = (process.env.FREN_EXPLORERS || 'https://fren-explorer.invalid/api').split(',').map(s=> s.trim()).filter(Boolean);

// Internal provider state
const state = {
  rvn: RVN_PROVIDERS.map(url=>({ url, ok:true, failCount:0, lastFailTs:null, lastOkTs:Date.now() })),
  fren: FREN_PROVIDERS.map(url=>({ url, ok:false, failCount:0, lastFailTs:null, lastOkTs:0 })) // mark offline until first success
};

const CACHE_MS = parseInt(process.env.EXPLORER_CACHE_MS || '15000',10);
const cache = new Map(); // key -> { ts, data }

function cacheGet(key){ const v=cache.get(key); if(!v) return null; if(Date.now()-v.ts > CACHE_MS){ cache.delete(key); return null; } return v.data; }
function cacheSet(key,data){ cache.set(key,{ ts:Date.now(), data }); }

function pickProvider(sym){
  const list = state[sym]; if(!list || !list.length) return null;
  // Filter out providers in backoff (failCount exponential)
  const now = Date.now();
  const usable = list.filter(p=>{
    if(p.failCount===0) return true;
    const backoff = Math.min(60000, (2 ** p.failCount) * 1000); // capped at 60s
    return (now - p.lastFailTs) >= backoff;
  });
  if(!usable.length) return null;
  // Round-robin by sorting on lastOkTs ascending
  usable.sort((a,b)=> a.lastOkTs - b.lastOkTs);
  return usable[0];
}

function httpJson(url){
  return new Promise((resolve,reject)=>{
    try {
      https.get(url, r=>{ let d=''; r.on('data',c=> d+=c); r.on('end',()=>{ try { resolve(JSON.parse(d||'{}')); } catch(e){ reject(e); } }); r.on('error',err=> reject(err)); });
    } catch(e){ reject(e); }
  });
}

function markResult(sym, provider, ok){
  if(!provider) return; provider.ok = ok; if(ok){ provider.failCount = 0; provider.lastOkTs = Date.now(); } else { provider.failCount++; provider.lastFailTs = Date.now(); }
}

function syntheticTx(txid){
  const h = crypto.createHash('sha256').update('synthetic_tx_'+txid).digest('hex');
  return { txid, height: 0, confirmations: 0, synthetic: true, hashShard: h.slice(0,16), outputs:[{ address: 'SYNTH_'+h.slice(0,8), value: 0 }], inputs: [] };
}

function syntheticAddress(addr){
  const h = crypto.createHash('sha256').update('synthetic_addr_'+addr).digest('hex');
  return { address: addr, balance: 0, txCount: 0, lastSeenHeight: 0, synthetic:true, shard:h.slice(0,12) };
}

function syntheticUtxos(addr){
  return [];
}

async function getTx(sym, txid){
  const key = sym+':tx:'+txid; const cached=cacheGet(key); if(cached) return cached;
  const provider = pickProvider(sym);
  if(!provider){ const syn = syntheticTx(txid); cacheSet(key,syn); return syn; }
  try {
    let url;
    if(sym==='rvn'){ url = provider.url.replace(/\/$/,'')+'/tx/'+txid; }
    else if(sym==='fren'){ url = provider.url.replace(/\/$/,'')+'/tx/'+txid; }
    const raw = await httpJson(url);
    // Normalize (RVN typical explorer returns fields: txid, vin, vout, confirmations, blockheight)
    const norm = {
      txid: raw.txid || txid,
      height: raw.blockheight || raw.height || null,
      confirmations: raw.confirmations || (raw.blockheight ? 1 : 0),
      outputs: Array.isArray(raw.vout) ? raw.vout.map(o=>({ address: o.scriptPubKey && o.scriptPubKey.addresses ? o.scriptPubKey.addresses[0] : null, value: typeof o.value === 'number'? o.value : parseFloat(o.value||'0') })) : [],
      inputs: Array.isArray(raw.vin) ? raw.vin.map(v=>({ txid: v.txid, vout: v.vout })) : [],
      synthetic:false
    };
    markResult(sym, provider, true); cacheSet(key,norm); return norm;
  } catch(e){ markResult(sym, provider, false); const syn = syntheticTx(txid); cacheSet(key,syn); return syn; }
}

async function getAddress(sym, addr){
  const key = sym+':addr:'+addr; const cached=cacheGet(key); if(cached) return cached;
  const provider = pickProvider(sym);
  if(!provider){ const syn=syntheticAddress(addr); cacheSet(key,syn); return syn; }
  try {
    let url;
    if(sym==='rvn'){ url = provider.url.replace(/\/$/,'')+'/addr/'+addr; }
    else if(sym==='fren'){ url = provider.url.replace(/\/$/,'')+'/address/'+addr; }
    const raw = await httpJson(url);
    const norm = {
      address: addr,
      balance: raw.balance || raw.balanceSat || 0,
      txCount: raw.txApperances || raw.txCount || raw.transactions || 0,
      lastSeenHeight: raw.lastSeenHeight || null,
      synthetic:false
    };
    markResult(sym, provider, true); cacheSet(key,norm); return norm;
  } catch(e){ markResult(sym, provider, false); const syn=syntheticAddress(addr); cacheSet(key,syn); return syn; }
}

async function getUtxos(sym, addr){
  if(sym!=='rvn') return []; // only RVN utxos for now
  const key = sym+':utxos:'+addr; const cached=cacheGet(key); if(cached) return cached;
  const provider = pickProvider(sym);
  if(!provider){ const syn=syntheticUtxos(addr); cacheSet(key,syn); return syn; }
  try {
    const url = provider.url.replace(/\/$/,'')+'/addr/'+addr+'/utxo';
    const raw = await httpJson(url);
    const norm = Array.isArray(raw) ? raw.map(u=>({ txid: u.txid, vout: u.vout, value: u.satoshis || u.value || 0 })) : [];
    markResult(sym, provider, true); cacheSet(key,norm); return norm;
  } catch(e){ markResult(sym, provider, false); const syn=syntheticUtxos(addr); cacheSet(key,syn); return syn; }
}

async function getHeight(sym){
  const key = sym+':height'; const cached=cacheGet(key); if(cached) return cached;
  const provider = pickProvider(sym);
  if(!provider){ const h = { height:0, synthetic:true }; cacheSet(key,h); return h; }
  try {
    let url;
    if(sym==='rvn'){ url = provider.url.replace(/\/$/,'')+'/status'; }
    else if(sym==='fren'){ url = provider.url.replace(/\/$/,'')+'/status'; }
    const raw = await httpJson(url);
    const height = raw.blocks || raw.height || (raw.info && raw.info.blocks) || 0;
    const out = { height, synthetic:false };
    markResult(sym, provider, true); cacheSet(key,out); return out;
  } catch(e){ markResult(sym, provider, false); const h={ height:0, synthetic:true }; cacheSet(key,h); return h; }
}

function health(){
  const snap={ ts: Date.now(), providers:{} };
  for(const sym of Object.keys(state)){
    snap.providers[sym] = state[sym].map(p=>({ url:p.url, ok:p.ok, failCount:p.failCount, lastFailTs:p.lastFailTs, lastOkTs:p.lastOkTs }));
  }
  return snap;
}

module.exports = { getTx, getAddress, getUtxos, getHeight, health };
