# ci-dimension-tests.ps1
# Runs dimension related determinism and ledger integrity tests.
param(
    [string]$NodeExe = 'node'
)
Write-Host '--- Running dimension determinism tests ---'
$ErrorActionPreference = 'Stop'

$tests = @(
  'test-dimension-escalation.js',
  'test-dimension-bootstrap-rollback.js',
  'test-dimension-ramp-gating.js',
  'test-pareto-empowerment.js'
)
foreach($t in $tests){
  Write-Host "Running $t" -ForegroundColor Cyan
  & $NodeExe $t | Out-Host
}

Write-Host 'Verifying dimension escalation ledger integrity'
& $NodeExe dimension-ledger-verify.js | Out-Host

Write-Host '--- Dimension tests completed ---'
