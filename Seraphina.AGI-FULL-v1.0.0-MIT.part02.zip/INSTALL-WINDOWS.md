# Seraphina Miner Windows Installation Guide

## Overview
You can install Seraphina Miner on Windows using either a simple self-extracting Setup.exe (IExpress) or a richer MSI package (WiX Toolset). This guide explains both methods along with optional features: version tagging, SHA256 manifest, code signing, and bundling a portable Node.js runtime.

---
## Method 1: Self-Extracting Setup.exe
Built via `build-windows-setup.ps1`.

### Build
```powershell
# Basic build
./build-windows-setup.ps1 -Version 1.0.0

# With icon (auto-detects existing .ico; falls back to PNG conversion)
./build-windows-setup.ps1 -Version 1.0.0 -IconPng .\logo.png

# Include portable Node.js runtime
./build-windows-setup.ps1 -Version 1.0.0 -IncludeNode -NodeVersion v20.11.1

# Code sign (requires signtool & PFX certificate)
./build-windows-setup.ps1 -Version 1.0.0 -SignCertPath .\codesign.pfx -SignCertPassword "pfxPassword"
```
Output files appear in `dist-win/`:
- `SeraphinaMiner-Setup-<version>.exe` – Installer
- `installer-manifest.json` – Metadata (name, version, sha256)
- `installer.sha256` – SHA256 hash line

### Install
Double-click the EXE. It:
1. Extracts miner files to `C:\Program Files\SeraphinaMiner`
2. Runs `install-windows-miner.ps1` (creates scheduled task + desktop shortcut)
3. (Optional) Copies portable Node runtime if included

### Silent Install (limited)
```powershell
Start-Process .\dist-win\SeraphinaMiner-Setup-1.0.0.exe /Q -Wait
```
(IExpress provides minimal quiet mode; consider MSI for full control.)

### Uninstall
Double-click `Uninstall-Seraphina-Miner.cmd` in the original source folder or run:
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Program Files\SeraphinaMiner\uninstall-windows-miner.ps1" -Force
```

---
## Method 2: MSI (WiX Toolset)
Provides Apps & Features registration and standard repair/uninstall flows.

### Requirements
Install WiX Toolset (candle.exe, light.exe, heat.exe on PATH).

### Build
```powershell
./build-wix-installer.ps1 -Version 1.0.0
```
Outputs in `dist-wix/`:
- `SeraphinaMiner-1.0.0-x64.msi`
- `msi-manifest.json`
- `msi.sha256`

### Install
Double-click the MSI or run:
```powershell
msiexec /i .\dist-wix\SeraphinaMiner-1.0.0-x64.msi /qn
```

### Uninstall
```powershell
msiexec /x .\dist-wix\SeraphinaMiner-1.0.0-x64.msi /qn
```
(Or remove via Settings > Apps.)

---
## Portable Node Runtime
If `-IncludeNode` used, a portable Node is copied under `C:\Program Files\SeraphinaMiner\portable-node`. The miner scripts can be adapted to prefer this runtime when system Node is absent (future enhancement: wrapper script detection).

---
## Code Signing
If `signtool.exe` and a PFX certificate are provided, the EXE is signed with SHA256 and a timestamp URL. For MSI signing, add a step after build:
```powershell
signtool sign /f codesign.pfx /p pfxPassword /tr http://timestamp.digicert.com /td sha256 /fd sha256 .\dist-wix\SeraphinaMiner-1.0.0-x64.msi
```

---
## Integrity Verification
After download:
```powershell
Get-FileHash .\dist-win\SeraphinaMiner-Setup-1.0.0.exe -Algorithm SHA256
Get-Content .\dist-win\installer.sha256
```
Hashes must match. Same for MSI using `msi.sha256`.

---
## Parameters Summary (build-windows-setup.ps1)
- `-Version` : Adds version tag to Setup name and manifest.
- `-IconPng` : Source PNG to convert to ICO if no `.ico` found in source tree.
- `-NoIcon` : Skip icon entirely.
- `-IncludeNode` : Bundle portable Node runtime (increase size).
- `-NodeVersion` : Node release tag (default v20.11.1).
- `-SignCertPath` / `-SignCertPassword` : Code sign the EXE if `signtool` available.

---
## Future Enhancements (not yet implemented)
- Auto-preference portable Node when system Node missing.
- Digital signature verification script.
- Differential upgrade MSI with component versioning.
- Automatic harvesting exclusions (e.g., large logs/benchmarks).

---
## Troubleshooting
- Missing `iexpress.exe`: Some minimal Windows editions may not include it; use MSI path instead.
- WiX build fails: Ensure WiX v3+ installed and PATH updated.
- Script execution policy blocks PowerShell: Use elevated PowerShell with `Set-ExecutionPolicy RemoteSigned` or rely on the `.cmd` wrappers.

---
End of INSTALL-WINDOWS.
