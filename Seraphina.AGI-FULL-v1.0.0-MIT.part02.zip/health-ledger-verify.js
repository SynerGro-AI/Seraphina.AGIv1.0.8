#!/usr/bin/env node
'use strict';
// health-ledger-verify.js: validate chainHash integrity of seraphina-health-ledger.jsonl
const fs = require('fs');
const crypto = require('crypto');
const LEDGER = process.env.SERAPHINA_HEALTH_LEDGER || 'seraphina-health-ledger.jsonl';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

if(!fs.existsSync(LEDGER)){ console.error('Ledger not found', LEDGER); process.exit(1); }
const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
let prev='GENESIS'; let ok=true; let idx=0;
for(const l of lines){
  idx++;
  let e; try{ e=JSON.parse(l); }catch{ console.error('Invalid JSON line', idx); ok=false; break; }
  const chain = e.chainHash; const ph = e.prevHash;
  if(ph!==prev){ console.error('Prev hash mismatch at line', idx); ok=false; break; }
  const recompute = stableHash({ ts:e.ts, snapshot:e.snapshot, prevHash:e.prevHash });
  if(chain!==recompute){ console.error('Chain hash mismatch at line', idx); ok=false; break; }
  prev = chain;
}
if(ok){ console.log('HEALTH LEDGER OK lines='+lines.length); } else { process.exit(1); }
