'use strict';
const fs = require('fs');
const crypto = require('crypto');

function rotateIfNeeded(path, maxBytes){
  try {
    if(!fs.existsSync(path)) return null;
    const sz = fs.statSync(path).size;
    if(sz < maxBytes) return null;
    const stamp = new Date().toISOString().replace(/[:T\-]/g,'').slice(0,12);
    const newName = path.replace(/\.jsonl$/i, '') + '-rot-' + stamp + '.jsonl';
    fs.renameSync(path, newName);
    const digest = crypto.createHash('sha256').update(fs.readFileSync(newName)).digest('hex');
    return { rotated:true, file:newName, size:sz, sha256:digest };
  } catch(e){ return { error:e.message }; }
}

module.exports = { rotateIfNeeded };