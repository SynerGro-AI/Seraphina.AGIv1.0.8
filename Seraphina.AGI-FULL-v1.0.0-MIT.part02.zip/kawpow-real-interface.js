/**
 * kawpow-real-interface.js
 * ----------------------------------------------------
 * This module is the bridge between the Node orchestration layer
 * and a REAL KawPow hashing implementation. There are three escalating
 * integration tiers attempted in order:
 *  1. Native addon binding (./build/Release/kawpowhash.node) exposing:
 *       init(epoch, seedHashHex)
 *       hash(headerHashHex, nonceHex) -> { mixHash, finalHash }
 *  2. External miner child_process (kawpowminer / teamredminer / nbminer) with
 *     line-based stdout parsing for share found / accepted events.
 *  3. Fallback (explicit) that refuses operation in STRICT REAL MODE.
 *
 * STRICT MODE (REAL_STRICT=1) will NEVER accept pseudo hashes.
 * Non-strict mode permits structural validation fallback while native
 * binding or external miner are being provisioned.
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const EventEmitter = require('events');

class KawpowRealInterface extends EventEmitter {
  constructor(opts={}) {
    super();
    this.native = null;
    this.external = null;
    this.strict = process.env.REAL_STRICT === '1';
    this.logger = opts.logger || ((...a)=>console.log('[KAWPOW]', ...a));
    this._attemptNativeLoad();
  }

  _attemptNativeLoad() {
    try {
      // Allow explicit override via env var
      const override = process.env.KAWPOW_NATIVE_MODULE;
      if (override && fs.existsSync(override)){
        this.native = require(override);
        this.logger('Loaded native kawpow addon via override:', override);
        return;
      }
      // Typical node-gyp build output path. User must compile separately.
      const prefer = path.join(__dirname,'build','Release','kawpowhash.node');
      const fallback = path.join(__dirname,'build','Release','kawpow_native.node');
      if (fs.existsSync(prefer)) {
        this.native = require(prefer);
        this.logger('Loaded native kawpow addon:', prefer);
      } else if (fs.existsSync(fallback)) {
        this.native = require(fallback);
        this.logger('Loaded native kawpow addon (legacy name):', fallback);
      } else {
        this.logger('Native kawpow addon not present (expected build/Release/kawpowhash.node)');
      }
    } catch (e) {
      this.logger('Native load failed:', e.message);
      this.native = null;
    }
  }

  startExternalMiner({ poolUrl, wallet, worker='Seraphina', extraArgs=[], poolName }) {
    if (this.external) return;
    // Detect executable name via env override or common defaults
    const exe = process.env.KAWPOW_MINER || 'kawpowminer';
    const args = [ '-P', `${wallet}.${worker}@${poolUrl}`, ...extraArgs ];
    this.logger('Spawning external miner:', exe, args.join(' '));
    try {
      const child = spawn(exe, args, { stdio:['ignore','pipe','pipe'] });
  child.stdout.on('data', d=>this._parseMinerOutput(d.toString(), poolName));
      child.stderr.on('data', d=>this._parseMinerError(d.toString()));
      child.on('exit', code=>{ this.logger('External miner exited code', code); this.external=null; });
      this.external = child;
    } catch (e) {
      this.logger('Failed to spawn external miner:', e.message);
      if (this.strict) throw new Error('STRICT_MODE: Cannot proceed without real miner');
    }
  }

  _parseMinerOutput(line, poolName) {
    line.split(/\r?\n/).filter(Boolean).forEach(l=>{
      const t=l.trim();
      if (/share accepted/i.test(t)) {
        const m=t.match(/nonce[^0-9a-fA-F]*([0-9a-fA-F]{8,16})/i);
        const nonce = m?m[1]:null;
        this.emit('shareAccepted',{ poolName, raw:t, nonce });
        this.logger('External miner share accepted:', t);
      } else if (/share rejected/i.test(t)) {
        this.emit('shareRejected',{ poolName, raw:t });
        this.logger('External miner share rejected:', t);
      } else if (/new job|pool.*authorized|login/i.test(t)) {
        this.logger('Miner status:', t);
      }
    });
  }
  _parseMinerError(line) {
    line.split(/\r?\n/).filter(Boolean).forEach(l=>{
      this.logger('EXT ERR:', l.trim());
    });
  }

  ensureNative(epoch, seedHashHex) {
    if (!this.native) {
      if (this.strict) throw new Error('STRICT_MODE: Native KawPow binding missing');
      return false;
    }
    if (!this._initEpoch || this._initEpoch !== epoch) {
      this.native.init(epoch, seedHashHex);
      this._initEpoch = epoch;
    }
    return true;
  }

  computeHash({ epoch, seedHashHex, headerHashHex, nonceHex }) {
    if (this.native) {
      this.ensureNative(epoch, seedHashHex);
      return this.native.hash(headerHashHex, nonceHex);
    }
    if (this.strict) {
      throw new Error('STRICT_MODE: No real hashing path available');
    }
    return null; // caller may fallback to structural check
  }
}

module.exports = { KawpowRealInterface };
