// final-mining-test.js
// Deterministic multi-coin mining test harness.
// Iterates target coins (default: BTC,RVN,FREN) and runs the pico mesh miner for a limited number of cycles.
// Captures final reproducibility digest and basic share ledger stats per coin.
// Designed for CI / pre-production validation prior to ISO packaging.
//
// Environment variables (may be preset externally):
//   TEST_COINS            Comma list override (e.g. "RVN,FREN")
//   AUR_REPRO_CYCLE_LIMIT Miner cycle cap (default 6) for each coin test
//   AUR_REPRO_FAST        Should be unset/0 for real test (fast mode skips real loop)
//   WALLET_BTC / WALLET_RVN / WALLET_FREN  Wallet addresses required for pool auth (if miner enforces)
//   RVN_POOL / FREN_POOL  Optional pool URL overrides (see coin-config.js for defaults)
//   REAL_MINING_ENFORCED=1  If set, some scripts may restrict experimental coins unless ALLOW_EXPERIMENTAL=1
//   EXPORT_PROM=1           If set, export Prometheus metrics for digests
//   PROM_PORT               Metrics server port (default 9309)
//   VALIDATE_WALLETS=1      Perform pre-flight wallet validation (BTC/RVN/FREN)
//
// Output: JSON summary with array of per-coin results including digest, exitCode, durationMs, stderr (trimmed), and any parse errors.
//
// NOTE: Actual live pool work introduces non-deterministic upstream job changes. Deterministic digest stability relies on
//       controlled cycle limits and internal deterministic transformations. Network variance may still alter job headers.
//       For strict reproducibility comparisons across environments, use isolated test pools or deterministic job fixtures.

const { spawnSync } = require('child_process');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

let promClient=null, promRegistry=null, gMeta=null, gPerCoin=null, gMeta64=null, gPerCoin64=null;
if (process.env.EXPORT_PROM==='1'){
  try {
    promClient = require('prom-client');
    promRegistry = promClient.register;
    gMeta = promRegistry.getSingleMetric('aur_finaltest_meta_digest') || new promClient.Gauge({ name:'aur_finaltest_meta_digest', help:'Numeric fold of meta digest (lower 32 bits of first 8 hex bytes)' });
    gPerCoin = promRegistry.getSingleMetric('aur_finaltest_coin_digest') || new promClient.Gauge({ name:'aur_finaltest_coin_digest', help:'Per coin digest numeric fold', labelNames:['coin'] });
    // 64-bit fold gauges (lower 16 hex chars -> 64-bit) presented as float (JS number precise up to 53 bits)
    gMeta64 = promRegistry.getSingleMetric('aur_finaltest_meta_digest64') || new promClient.Gauge({ name:'aur_finaltest_meta_digest64', help:'Lower 64 bits fold of meta digest (first 16 hex chars as unsigned)' });
    gPerCoin64 = promRegistry.getSingleMetric('aur_finaltest_coin_digest64') || new promClient.Gauge({ name:'aur_finaltest_coin_digest64', help:'Lower 64 bits fold per coin digest', labelNames:['coin'] });
  } catch(e){ console.warn('[PROM] prom-client unavailable:', e.message); }
}
if (promClient && process.env.PROM_PORT){
  const http = require('http');
  const port = parseInt(process.env.PROM_PORT,10) || 9309;
  http.createServer(async (req,res)=>{
    if (req.url === '/metrics'){ res.writeHead(200,{'Content-Type':'text/plain'}); res.end(await promRegistry.metrics()); }
    else { res.writeHead(404); res.end('not found'); }
  }).listen(port, ()=> console.log('[PROM] listening on', port));
}

function digestFold(hex){ if(!hex || hex.length<16) return 0; return parseInt(hex.slice(0,8),16); }
function digestFold64(hex){ if(!hex || hex.length<16) return 0; // take first 16 hex chars -> 64 bits
  const slice = hex.slice(0,16);
  // Use BigInt to avoid precision loss then clamp to JS number (will lose >53 bits but acceptable for monitoring)
  try { const v = BigInt('0x'+slice); return Number(v & BigInt('0xffffffffffffffff')); } catch(_){ return 0; }
}

function validateWallets(coins){
  if (process.env.VALIDATE_WALLETS !== '1') return { performed:false };
  const results={}; const issues=[];
  const validators={ BTC:'verify-btc-address.js', RVN:'verify-rvn-address.js', FREN:'verify-fren-address.js' };
  for (const c of coins){
    const addr = process.env['WALLET_'+c];
    if (!addr){ issues.push(c+':missing'); results[c]={ ok:false, reason:'missing' }; continue; }
    const script = validators[c];
    if (script && fs.existsSync(path.join(__dirname, script))){
      const p = spawnSync(process.execPath, [path.join(__dirname, script), addr], { encoding:'utf8' });
      if (p.status!==0){ results[c]={ ok:false, reason:'exit '+p.status }; issues.push(c+':invalid'); }
      else {
        const out=(p.stdout||'').toLowerCase();
        const ok = out.includes('valid') || out.includes('ok');
        results[c]={ ok, raw: out.slice(0,120) };
        if(!ok) issues.push(c+':invalid');
      }
    } else {
      results[c]={ ok:true, skipped:true };
    }
  }
  return { performed:true, issues, results };
}

function runMinerForCoin(coin, cycles){
  const env = { ...process.env };
  env.AUR_COIN = coin;
  env.AUR_REPRO_CYCLE_LIMIT = String(cycles);
  // Ensure fast mode disabled for real hashing attempt
  if (env.AUR_REPRO_FAST) delete env.AUR_REPRO_FAST;
  const minerScript = path.join(__dirname, 'aurrelia-pico-mesh-miner.js');
  const start = Date.now();
  const proc = spawnSync(process.execPath, [minerScript], { env, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });
  const durationMs = Date.now() - start;
  let digest = null; let shareChainHead = null; let reproLine = null;
  if (proc.stdout){
    const lines = proc.stdout.split(/\r?\n/);
    for (const ln of lines){
      // Example reproducibility line patterns could include '[REPRO]' or JSON from system harness
      if (ln.includes('[REPRO]')){
        reproLine = ln.trim();
        const m = ln.match(/digest=([a-f0-9]{64})/i);
        if (m) digest = m[1];
      }
      if (ln.includes('[SHARE_LEDGER][HEAD]')){
        const m2 = ln.match(/HEAD\s*([a-f0-9]{64})/i);
        if (m2) shareChainHead = m2[1];
      }
    }
  }
  let stderr = proc.stderr ? proc.stderr.split(/\r?\n/).slice(-10).join('\n') : '';
  return { coin, exitCode: proc.status, durationMs, digest, shareChainHead, reproLine, stderr }; 
}

function main(){
  const coins = (process.env.TEST_COINS ? process.env.TEST_COINS.split(',') : ['BTC','RVN','FREN']).map(c=>c.trim()).filter(Boolean);
  const cycles = parseInt(process.env.AUR_REPRO_CYCLE_LIMIT || '6',10);
  const walletValidation = validateWallets(coins);
  const results = [];
  for (const coin of coins){
    console.log(`\n[FINAL-TEST] Starting coin=${coin} cycles=${cycles}`);
    const r = runMinerForCoin(coin, cycles);
    results.push(r);
    console.log(`[FINAL-TEST] Completed coin=${coin} exit=${r.exitCode} digest=${r.digest||'none'}`);
  }
  const metaBase = results.map(r=>`${r.coin}:${r.digest||'-'}`).join('|');
  const metaDigest = crypto.createHash('sha256').update(metaBase).digest('hex');
  if (gMeta && gPerCoin){
    try {
      gMeta.set(digestFold(metaDigest));
      results.forEach(r=> gPerCoin.labels(r.coin).set(digestFold(r.digest||'')) );
      if (gMeta64 && gPerCoin64){
        gMeta64.set(digestFold64(metaDigest));
        results.forEach(r=> gPerCoin64.labels(r.coin).set(digestFold64(r.digest||'')) );
      }
    } catch(e){ console.warn('[PROM] gauge set failed', e.message); }
  }
  const summary = { testCoins: coins, cycleLimit: cycles, metaDigest, results, walletValidation };
  console.log('\n' + JSON.stringify(summary, null, 2));
  const anyFail = results.some(r=> r.exitCode !== 0 || !r.digest) || (walletValidation.performed && walletValidation.issues.length>0);
  process.exit(anyFail ? 2 : 0);
}

main();