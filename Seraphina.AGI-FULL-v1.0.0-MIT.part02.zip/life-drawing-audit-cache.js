#!/usr/bin/env node
// life-drawing-audit-cache.js
// Run npm audit --json and append summarized counts to history file with timestamp and digest.
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function runAudit(){
  const res = spawnSync('npm',['audit','--json'], { encoding:'utf8' });
  if(res.error) return null;
  try { return JSON.parse(res.stdout); } catch(_){ return null; }
}

function summarize(audit){
  if(!audit) return null;
  const advisories = audit.advisories || audit.vulnerabilities || {};
  const counts = { low:0, moderate:0, high:0, critical:0 };
  if(advisories && !Array.isArray(advisories)){
    Object.values(advisories).forEach(v=>{ if(v.severity && counts[v.severity] != null) counts[v.severity] += 1; });
  }
  return counts;
}

function appendHistory(summary){
  const historyPath = path.join(__dirname,'life-drawing-audit-history.jsonl');
  const entry = { ts: new Date().toISOString(), counts: summary, digest: sha256(summary) };
  fs.appendFileSync(historyPath, JSON.stringify(entry)+'\n');
  return entry;
}

function main(){
  const audit = runAudit();
  const summary = summarize(audit);
  if(!summary){ console.log(JSON.stringify({ ok:false, message:'Audit unavailable' }, null, 2)); return; }
  const entry = appendHistory(summary);
  console.log(JSON.stringify({ ok:true, entry }, null, 2));
}

if(require.main === module){
  main();
}

module.exports = { runAudit, summarize };
