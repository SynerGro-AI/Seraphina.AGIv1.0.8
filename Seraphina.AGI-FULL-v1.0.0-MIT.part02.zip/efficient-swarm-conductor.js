// efficient-swarm-conductor.js
// Stratified direct USB conductor with compressed pulse/tune packets and throughput gauge.
// Env:
//  MAX_CUBES (default 35)
//  USB_VID / USB_PID (defaults 0x2341 / 0x8036)
//  USB_BATCH_SIZE (default 512)
//  USB_POLL_MS (default 5)
//  USB_STRATA_BUCKETS (default 5)
//  USB_THROUGHPUT_GAUGE=1 enable Prom gauge update
//  USB_LEDGER_PATH (default efficient-swarm-ledger.jsonl)
// Safety: Sanitizes predicted_retention; frequency bounded; hash-chained ledger.

'use strict';
const usb = safeRequire('usb');
const zlib = require('zlib');
const crypto = require('crypto');
const fs = require('fs');
const { promisify } = require('util');
let RetentionOracle=null; try { ({ RetentionOracle } = require('./aurrelia-retention-infer.js')); } catch {}

function safeRequire(m){ try{ return require(m);}catch{ return null; } }

const MAX_CUBES = parseInt(process.env.MAX_CUBES || '35',10);
const USB_VID = process.env.USB_VID? parseInt(process.env.USB_VID,10) : 0x2341;
const USB_PID = process.env.USB_PID? parseInt(process.env.USB_PID,10) : 0x8036;
const BATCH_SIZE = parseInt(process.env.USB_BATCH_SIZE || '512',10);
const POLL_MS = parseInt(process.env.USB_POLL_MS || '5',10);
const STRATA_BUCKETS = parseInt(process.env.USB_STRATA_BUCKETS || '5',10);
const LEDGER_PATH = process.env.USB_LEDGER_PATH || 'efficient-swarm-ledger.jsonl';
const PROM_GAUGE = process.env.USB_THROUGHPUT_GAUGE === '1';

class EfficientSwarmConductor {
  constructor(){
    this.seed = 'efficient-swarm-'+Date.now();
    this.cubes=[]; this.chainHash = crypto.createHash('sha256').update(this.seed).digest('hex');
    this.throughput={ totalBytes:0, start:Date.now() };
    this.oracle = RetentionOracle? new RetentionOracle(): null;
    if(this.oracle){ this.oracle.load().then(()=> this.detect()); } else { this.detect(); }
  }
  stratify(indices){
    const bucketSize = Math.floor(indices.length / STRATA_BUCKETS);
    const seedHash = crypto.createHash('sha256').update(this.seed+'|strat').digest();
    const pick=[];
    for(let b=0;b<STRATA_BUCKETS;b++){
      const slice = indices.slice(b*bucketSize,(b+1)*bucketSize);
      const ordered = slice.map(i=> ({ i, h: seedHash[i%seedHash.length] })).sort((a,b)=> a.h-b.h).map(e=> e.i);
      const take = Math.max(1, Math.floor(ordered.length / STRATA_BUCKETS));
      pick.push(...ordered.slice(0,take));
    }
    return pick.slice(0, MAX_CUBES);
  }
  detect(){
    if(!usb){ console.warn('[EfficientSwarm] usb module unavailable'); return; }
    const devs = usb.getDeviceList();
    const candidates = devs.filter(d=> d && d.deviceDescriptor && d.deviceDescriptor.idVendor===USB_VID && d.deviceDescriptor.idProduct===USB_PID);
    const ordered = this.stratify(Array.from({length:candidates.length},(_,i)=>i));
    this.cubes = ordered.map(i=> candidates[i]);
    this.cubes.forEach((cube,i)=> this.initCube(cube,i));
    this.appendLedger({ ts:Date.now(), cubes:this.cubes.length, event:'detect' });
    if(this.cubes.length) setInterval(()=> this.poll(), POLL_MS);
  }
  initCube(cube, idx){
    try { cube.open(); cube.controlTransfer(0x40,0x01,0,0,Buffer.from([100])); this.sendPulse(cube,{ freq:17, idx }); console.log('[EfficientSwarm] Cube '+idx+' online'); } catch(e){ console.warn('[EfficientSwarm] Cube '+idx+' init fail:', e.message); }
  }
  sendPulse(cube,payload){
    try {
      const raw = Buffer.from(JSON.stringify(payload));
      const gz = zlib.gzipSync(raw); const out = Buffer.alloc(BATCH_SIZE); gz.copy(out,0,0,Math.min(gz.length,BATCH_SIZE));
      if(cube.transferOut) cube.transferOut(1,out); this.throughput.totalBytes += out.length;
    } catch(e){ console.warn('[EfficientSwarm] sendPulse error:', e.message); }
  }
  async poll(){
    for(let i=0;i<this.cubes.length;i++){
      const cube=this.cubes[i];
      try {
        const status = cube.transferIn? await promisify(cube.transferIn.bind(cube))(1, BATCH_SIZE) : null;
        if(!status) continue;
        const cut = status.indexOf(0); const slice = cut>0? status.slice(0,cut): status;
        let parsed={}; try { parsed = JSON.parse(zlib.gunzipSync(slice).toString('utf8')); } catch {}
        const fields = Array.isArray(parsed.retentionFields)? parsed.retentionFields: [];
        const sanitized = fields.map(f=> ({ predicted_retention: clamp(f.predicted_retention, f.prior_retention||0.5), prior_retention: clamp(f.prior_retention,0.5), difficulty: clamp(f.difficulty,0.7), coverage_pct: clamp(f.coverage_pct,0.5) }));
        const sorted = this.oracle && this.oracle.sortFields? this.oracle.sortFields(sanitized): sanitized;
        sorted.forEach(f=> { const tuned = 17 + (f.predicted_retention>0.6?2:0); const finalHz = Math.max(1,Math.min(255,tuned)); this.sendPulse(cube,{ freq:finalHz, idx:i, tuned:true }); });
        if(PROM_GAUGE) this.updateGauge();
      } catch(e){ console.warn('[EfficientSwarm] poll error cube '+i+':', e.message); }
    }
  }
  updateGauge(){
    const elapsed=(Date.now()-this.throughput.start)/1000; const mbps=(this.throughput.totalBytes/(1024*1024))/(elapsed||1);
    if(global.__AUR_METRICS_REG__?.gauges?.usbThroughput){ try { global.__AUR_METRICS_REG__.gauges.usbThroughput.set(Number(mbps.toFixed(2))); } catch{} }
    if(Math.random()<0.05) console.log('[EfficientSwarm] throughput '+mbps.toFixed(2)+' MB/s');
  }
  appendLedger(entry){ entry.prevHash=this.chainHash; entry.chainHash=crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex'); try { fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n'); this.chainHash=entry.chainHash; } catch(e){ console.warn('[EfficientSwarm] ledger append fail:', e.message); } }
}

function clamp(v, fallback){ if(typeof v!=='number'||!isFinite(v)) return fallback; if(v<0) return 0; if(v>1) return 1; return v; }

module.exports = { EfficientSwarmConductor };
if(require.main===module){ new EfficientSwarmConductor(); }
