// fren-wallet-swap.js
// Frencoin (FREN) address generation + optional SimpleSwap BTC->FREN swap helper.
// Usage (basic):
//   node fren-wallet-swap.js --rpc-user user --rpc-pass pass --amount 0.001
// Full flags:
//   --rpc-host localhost --rpc-port 8332 --rpc-user user --rpc-pass pass \
//   --from-coin BTC --to-coin FREN --amount 0.001 --swap-api-key YOUR_KEY \
//   --refund-address YOUR_REFUND_ADDR --no-swap
// If RPC fails, falls back to local deterministic generation using bitcoinjs-lib with FREN params.
// NOTE: To actually mine FREN with Aurrelia set AUR_COIN=fren and FREN_WALLET=<address> (experimental KawPow path).
// DISCLAIMER: SimpleSwap interaction requires internet connectivity; this script does not custody funds.

const axios = require('axios');
const bitcoin = require('bitcoinjs-lib');
// bitcoinjs-lib v6+ ECPair not bundled; attempt dynamic load
let ECPairFactory = null; let ECPair = null;
try {
  const ecc = require('tiny-secp256k1');
  ECPairFactory = require('ecpair');
  ECPair = ECPairFactory.ECPairFactory(ecc);
} catch(e){ /* fallback to legacy bitcoin.ECPair if present */ }
const fs = require('fs');
let MultiChainWallet = null; // optional HD wallet lib
try { MultiChainWallet = require('multichain-crypto-wallet'); } catch(_) { /* optional */ }

const FREN_NETWORK = {
  messagePrefix: '\x18Frencoin Signed Message:\n',
  bech32: 'fr',
  bip32: { public: 0x0488b21e, private: 0x0488ade4 },
  pubKeyHash: 0x1e, // base58 prefix guess (adjust if core differs)
  scriptHash: 0x1c,
  wif: 0x80
};

function parseArgs() {
  const args = process.argv.slice(2);
  const out = {};
  for (let i=0;i<args.length;i++){
    if (!args[i].startsWith('--')) continue;
    const eq = args[i].indexOf('=');
    if (eq>0){ out[args[i].slice(2,eq)] = args[i].slice(eq+1); }
    else { out[args[i].slice(2)] = '1'; }
  }
  return out;
}

function generateHD(seedPhrase){
  if (!seedPhrase || !MultiChainWallet) return null;
  try {
    const wallet = new MultiChainWallet({ chain: 'frencoin', mnemonic: seedPhrase });
    const address = wallet.getAddress();
    return { address, source:'hd', seed: seedPhrase };
  } catch(e){
    console.warn('[FREN] HD wallet generation failed, fallback -> local. Reason:', e.message);
    return null;
  }
}

async function generateFRENAddress(rpcHost, rpcPort, rpcUser, rpcPass, seedPhrase) {
  // HD first if seed provided
  const hd = generateHD(seedPhrase);
  if (hd){
    console.log('[FREN] HD (BIP39) address:', hd.address);
    return hd;
  }
  // Try RPC first
  try {
    const payload = { jsonrpc:'2.0', id:1, method:'getnewaddress', params:['legacy'] };
    const resp = await axios.post(`http://${rpcHost}:${rpcPort}`, payload, {
      auth: { username: rpcUser, password: rpcPass },
      headers: { 'Content-Type': 'application/json' },
      timeout: 5000
    });
    if (resp.data && resp.data.result){
      console.log('[FREN] RPC generated address:', resp.data.result);
      return { address: resp.data.result, source: 'rpc' };
    }
    throw new Error(resp.data && resp.data.error ? resp.data.error.message : 'Unknown RPC response');
  } catch(e){
    console.warn('[FREN] RPC getnewaddress failed -> fallback local generation:', e.message);
  const keyPair = ECPair ? ECPair.makeRandom({ network: FREN_NETWORK }) : (bitcoin.ECPair && bitcoin.ECPair.makeRandom? bitcoin.ECPair.makeRandom({ network: FREN_NETWORK }) : null);
  if(!keyPair) throw new Error('ECPair unavailable');
  const pubkeyBuf = Buffer.isBuffer(keyPair.publicKey)? keyPair.publicKey : Buffer.from(keyPair.publicKey);
  const pay = bitcoin.payments.p2pkh({ pubkey: pubkeyBuf, network: FREN_NETWORK });
    console.log('[FREN] Locally generated address:', pay.address);
    return { address: pay.address, wif: keyPair.toWIF(), source: 'local' };
  }
}

function persistAddress(addrObj, path='fren-wallet.json'){
  try {
    fs.writeFileSync(path, JSON.stringify({ t:Date.now(), ...addrObj }, null, 2));
    console.log('[FREN] Persisted address to', path);
  } catch(e){ console.warn('[FREN] Persist persist error', e.message); }
}

function miningPoolInstructions(address, poolUrl='https://aikapool.com/fren/account'){
  return [
    `Add FREN address to mining pool: ${poolUrl}`,
    '1. Log in / create account.',
    '2. Navigate to Account > Wallet / Payout settings.',
    `3. Paste address: ${address}`,
    '4. Save changes. Pool payouts will credit this address.'
  ];
}

async function simpleSwap(fromCoin, toCoin, amount, frenAddress, apiKey, refundAddress){
  const apiBase = 'https://api.simpleswap.io/api/v1';
  try {
    // Quote
    const quoteUrl = `${apiBase}/market_data/simple?from=${fromCoin}&to=${toCoin}&amount=${amount}`;
    const quoteResp = await axios.get(quoteUrl, { timeout: 7000 });
    if (quoteResp.data && quoteResp.data.toAmount){
      console.log(`[Swap] Quote: ${amount} ${fromCoin} -> ~${quoteResp.data.toAmount} ${toCoin} (rate ${quoteResp.data.rate})`);
    } else {
      console.warn('[Swap] Quote incomplete response');
    }
    // Initiate
    const body = {
      from: fromCoin,
      to: toCoin,
      amount: amount,
      address: frenAddress,
      refund: refundAddress || undefined,
      affiliateId: apiKey || undefined
    };
    const createResp = await axios.post(`${apiBase}/exchange/create`, body, { timeout: 7000 });
    if (createResp.data && createResp.data.id){
      console.log('[Swap] Created swap ID:', createResp.data.id);
      console.log(`[Swap] Track: https://simpleswap.io/exchange/${createResp.data.id}`);
      return createResp.data;
    }
    console.warn('[Swap] Unexpected create response:', createResp.data);
    return null;
  } catch(e){
    console.error('[Swap] Error:', e.response?.data || e.message);
    return null;
  }
}

async function main(){
  const flags = parseArgs();
  const rpcHost = flags['rpc-host'] || 'localhost';
  const rpcPort = parseInt(flags['rpc-port'] || '8332',10);
  const rpcUser = flags['rpc-user'] || 'user';
  const rpcPass = flags['rpc-pass'] || 'pass';
  const seedPhrase = flags['fren-seed'] || process.env.FREN_SEED_PHRASE || null;
  const fromCoin = flags['from-coin'] || 'BTC';
  const toCoin = (flags['to-coin'] || 'FREN').toUpperCase();
  const amount = flags.amount || '0.001';
  const apiKey = flags['swap-api-key'] || null;
  const refundAddress = flags['refund-address'] || null;
  const noSwap = flags['no-swap'] === '1';

  const addrObj = await generateFRENAddress(rpcHost, rpcPort, rpcUser, rpcPass, seedPhrase);
  persistAddress(addrObj);
  console.log('--- Mining Pool Setup Steps ---');
  for (const line of miningPoolInstructions(addrObj.address)) console.log(line);
  // Export to env file for miner integration
  try { fs.writeFileSync('.fren-env', `FREN_WALLET=${addrObj.address}\n`); console.log('[FREN] Wrote .fren-env (source for env var injection)'); } catch(_){}

  if (!noSwap){
    console.log('--- Initiating Optional SimpleSwap ---');
    const swapData = await simpleSwap(fromCoin, toCoin, amount, addrObj.address, apiKey, refundAddress);
    if (swapData){
      console.log('[Swap] Result:', JSON.stringify({ id: swapData.id, status: swapData.status || 'pending' }));
    }
  } else {
    console.log('[Swap] Skipped (no-swap flag)');
  }

  console.log('\n[Done] FREN address ready. To mine: set AUR_COIN=fren FREN_WALLET=' + addrObj.address);
}

if (require.main === module){
  main().catch(e=>{ console.error('Fatal:', e.message); process.exit(1); });
}

module.exports = { generateFRENAddress, simpleSwap, FREN_NETWORK };