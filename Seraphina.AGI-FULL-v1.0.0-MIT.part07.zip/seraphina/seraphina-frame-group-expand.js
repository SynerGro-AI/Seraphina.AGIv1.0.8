#!/usr/bin/env node
/**
 * seraphina-frame-group-expand.js
 *
 * Rehydrates provenance JSONL containing frameHamGroup records into expanded synthetic per-frame entries.
 * Useful for forensic replay when compression grouping was enabled (SERAPHINA_FRAME_COMPRESS=1).
 *
 * Usage:
 *   node seraphina-frame-group-expand.js --input=prov.jsonl --output=expanded.jsonl [--writeOnly] [--noDigest]
 *
 * Flags:
 *   --input        Path to original provenance JSONL with frameHamGroup entries.
 *   --output       Path to write expanded JSONL (will overwrite if exists).
 *   --writeOnly    When set, only expands frames originally written (skips culled frames inside group).
 *   --noDigest     Skip recomputing synthetic hash chain fields (faster, non-integrity mode).
 *   --hmacKey=KEY  Optional HMAC key to recompute chainHmac for synthetic records.
 *
 * Expansion Logic:
 *   Each frameHamGroup record summarizes N grouped frames with ham stats.
 *   We reconstruct synthetic per-frame records approximating uniform distribution between hamMin..hamMax
 *   while preserving hamAvg (minor rounding). writtenFrames indicates how many of those would have been written.
 *
 * Integrity:
 *   If not --noDigest, we create a fresh chainPrev/chainHash chain over expanded records (only the synthetic ones)
 *   allowing downstream replay tools to validate continuity. Original records untouched.
 */
const fs = require('fs');
const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(x).digest('hex'); }
function hmac256(key, data){ return crypto.createHmac('sha256', key).update(data).digest('hex'); }

const args = process.argv.slice(2);
const getArg = (name, def=null) => {
  const pref = `--${name}=`;
  for(const a of args){ if(a.startsWith(pref)) return a.substring(pref.length); }
  if(args.includes(`--${name}`)) return true;
  return def;
};

const inputPath = getArg('input');
const outputPath = getArg('output');
if(!inputPath || !outputPath){
  console.error('[Expand][ERR] --input and --output required');
  process.exit(1);
}
const writeOnly = !!getArg('writeOnly', false);
const noDigest = !!getArg('noDigest', false);
const hmacKey = getArg('hmacKey', null);

let lines;
try { lines = fs.readFileSync(inputPath,'utf8').split(/\r?\n/).filter(l=>l.trim()); } catch(e){
  console.error('[Expand][ERR] read input failed:', e.message); process.exit(1);
}

let expanded = [];
let syntheticCount = 0;
for(const line of lines){
  let obj; try { obj = JSON.parse(line); } catch(_e){ continue; }
  if(obj.type === 'frameHamGroup' && obj.count && obj.hamMin !== undefined){
    // Reconstruct synthetic ham values
    const { count, hamMin, hamMax, hamAvg, writtenFrames } = obj;
    const synthetics = [];
    if(count === 1){ synthetics.push({ ham: hamAvg, written: writtenFrames ? true : false }); }
    else {
      // Linear interpolation baseline
      for(let i=0;i<count;i++){
        const ratio = count === 1 ? 0 : (i/(count-1));
        const hamEst = hamMin + (hamMax - hamMin)*ratio;
        synthetics.push({ ham: hamEst, written: i < writtenFrames });
      }
      // Adjust to match hamAvg (naive correction on last element)
      const currentAvg = synthetics.reduce((s,v)=>s+v.ham,0)/count;
  const diff = hamAvg - currentAvg;
  synthetics[synthetics.length-1].ham = Math.max(hamMin, Math.min(hamMax, synthetics[synthetics.length-1].ham + diff));
    }
    for(let i=0;i<synthetics.length;i++){
      const s = synthetics[i];
      if(writeOnly && !s.written) continue;
      expanded.push({ ts: obj.ts + i, type:'frameHam', ham: s.ham, written: s.written, syntheticFromGroup: true, groupTs: obj.ts, groupIndex: i, groupCount: count });
      syntheticCount++;
    }
  }
}

let chainPrev = null;
if(!noDigest){
  for(const rec of expanded){
    const payload = JSON.stringify({ ts: rec.ts, type: rec.type, ham: rec.ham, written: rec.written, syntheticFromGroup: rec.syntheticFromGroup, groupTs: rec.groupTs, groupIndex: rec.groupIndex, groupCount: rec.groupCount });
    const chainHash = sha256(payload + (chainPrev || ''));
    rec.chainPrev = chainPrev;
    rec.chainHash = chainHash;
    if(hmacKey){ rec.chainHmac = hmac256(hmacKey, chainHash); }
    chainPrev = chainHash;
  }
}

try {
  const outLines = expanded.map(o=>JSON.stringify(o));
  fs.writeFileSync(outputPath, outLines.join('\n') + '\n');
  console.log(JSON.stringify({ expanded: syntheticCount, output: outputPath, digestChain: !noDigest, hmacApplied: !!hmacKey }));
} catch(e){
  console.error('[Expand][ERR] write output failed:', e.message); process.exit(1);
}
