/**
 * SERAPHINA HASHER STUB / SHARE SIMULATOR
 * ----------------------------------------------------------
 * Feeds the mining service /api/submit-share endpoint with
 * synthetic share submissions derived from the current
 * Stratum job snapshot. This is a development/testing tool
 * ONLY and does NOT perform real PoW hashing.
 *
 * It will:
 *  1. Poll /api/real-stats for active stratum jobs.
 *  2. For each selected pool, generate N fake shares.
 *  3. POST each to /api/submit-share.
 *  4. Log success/error counts per cycle.
 *
 * Env Vars:
 *  HASHER_ENDPOINT=http://localhost:8888            (Mining server base)
 *  HASHER_INTERVAL_MS=5000                          (Cycle interval)
 *  HASHER_SUBMIT_BATCH=5                            (Shares per pool per cycle)
 *  HASHER_TARGET_POOLS=Antpool,F2Pool               (Limit to subset; else all)
 *  HASHER_LOG_LEVEL=info | debug
 */
if (process.env.REAL_STRICT === '1') {
  console.error('[HASHER_STUB] Disabled in REAL_STRICT mode (no simulated shares permitted).');
  process.exit(1);
}

const https = require('https');
const http = require('http');
const { URL } = require('url');

const BASE = process.env.HASHER_ENDPOINT || 'http://localhost:8888';
const INTERVAL = parseInt(process.env.HASHER_INTERVAL_MS || '5000', 10);
const BATCH = parseInt(process.env.HASHER_SUBMIT_BATCH || '5', 10);
const TARGET_POOLS = (process.env.HASHER_TARGET_POOLS || '').split(/[,;]+/).filter(Boolean);
const LOG_LEVEL = (process.env.HASHER_LOG_LEVEL || 'info').toLowerCase();

function logDebug(...a){ if(LOG_LEVEL==='debug') console.log('[HASHER]', ...a); }
function logInfo(...a){ console.log('[HASHER]', ...a); }

async function fetchJSON(urlStr){
  const u = new URL(urlStr);
  const mod = u.protocol === 'https:' ? https : http;
  return new Promise((resolve,reject)=>{
    const req = mod.request(u, res=>{
      let data='';
      res.on('data',c=>data+=c);
      res.on('end',()=>{
        try { resolve(JSON.parse(data)); } catch(e){ reject(e); }
      });
    });
    req.on('error',reject);
    req.end();
  });
}

async function postJSON(urlStr, obj){
  const u = new URL(urlStr);
  const mod = u.protocol === 'https:' ? https : http;
  return new Promise((resolve,reject)=>{
    const body = JSON.stringify(obj);
    const req = mod.request({ hostname: u.hostname, port: u.port, path: u.pathname, method:'POST', headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)} }, res=>{
      let data='';
      res.on('data',c=>data+=c);
      res.on('end',()=>{
        try { resolve(JSON.parse(data)); } catch(e){ resolve({ ok:false, raw:data }); }
      });
    });
    req.on('error',reject);
    req.write(body); req.end();
  });
}

function randomHex(bytes){ return [...crypto.getRandomValues(new Uint8Array(bytes))].map(b=>b.toString(16).padStart(2,'0')).join(''); }

// Fallback for Node <19 without crypto.getRandomValues
const crypto = globalThis.crypto || require('crypto');
if (!crypto.getRandomValues) {
  crypto.getRandomValues = (arr)=>{
    const buf = require('crypto').randomBytes(arr.length);
    for (let i=0;i<arr.length;i++) arr[i]=buf[i];
    return arr;
  };
}

async function cycle(){
  let stats;
  try { stats = await fetchJSON(BASE + '/api/real-stats'); } catch(e){ logInfo('Failed to fetch stats:', e.message); return; }
  const jobs = stats.stratumJobs || {};
  const poolNames = Object.keys(jobs).filter(p=>!TARGET_POOLS.length || TARGET_POOLS.includes(p));
  if (!poolNames.length) { logDebug('No jobs available this cycle'); return; }
  let total = 0, success=0, fail=0;
  for (const poolName of poolNames){
    const job = jobs[poolName];
    if(!job) continue;
    for (let i=0;i<BATCH;i++){
      total++;
      // Construct fake fields (NOT valid PoW)
      const extranonce2 = randomHex(4);
      const ntime = job.ntime || Math.floor(Date.now()/1000).toString(16);
      const nonce = randomHex(4);
      try {
        const resp = await postJSON(BASE + '/api/submit-share', { poolName, jobId: job.jobId, extranonce2, ntime, nonce });
        if (resp && resp.ok) success++; else fail++;
      } catch(e){ fail++; }
    }
  }
  logInfo(`Cycle: pools=${poolNames.length} submitted=${total} ok=${success} fail=${fail}`);
}

logInfo('Seraphina Hasher Stub started. Endpoint:', BASE);
setInterval(cycle, INTERVAL);
cycle();