/**
 * SERAPHINA MERKLE ROOT ANCHOR SERVICE
 * Periodically reads latest share_log_roots.chain entry and anchors its hash
 * via a timestamping provider (stub) or prepares on-chain anchor payload.
 * Future: integrate OpenTimestamp or OP_RETURN broadcast.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }

const INTERVAL_MS = parseInt(process.env.ANCHOR_INTERVAL_MS || '600000',10); // 10m
const ROOT_CHAIN = path.join(__dirname,'persistent_data','share_log_roots.chain');
const OUT_FILE = path.join(__dirname,'persistent_data','merkle_anchor_log.json');
const MAX_RECORDS = 5000;

function loadLog(){try{return JSON.parse(fs.readFileSync(OUT_FILE,'utf8'))}catch{return[]}}
function saveLog(arr){try{fs.writeFileSync(OUT_FILE,JSON.stringify(arr,null,2))}catch{}}

async function anchorOnce(){
  let lines=[];try{lines=fs.readFileSync(ROOT_CHAIN,'utf8').trim().split('\n').filter(Boolean);}catch{}
  if(!lines.length) return;
  const last=lines[lines.length-1];
  const hash=crypto.createHash('sha256').update(last+'\n').digest('hex');
  const ts=Date.now();
  // In REAL_STRICT we do not accept stub proofs; instead only record hash awaiting real anchor integration
  let providerReceipt;
  if (process.env.REAL_STRICT === '1') {
    providerReceipt={ provider:'pending-real-anchor', hash, ts, proof:null };
  } else {
    providerReceipt={ provider:'stub', hash, ts, proof:`stub-proof-${hash.slice(0,16)}` };
  }
  const log=loadLog();
  if(log.length && log[log.length-1].hash===hash) return; // already anchored
  log.push(providerReceipt);
  if(log.length>MAX_RECORDS) log.splice(0, log.length-MAX_RECORDS);
  saveLog(log);
  console.log('[ANCHOR] Anchored latest merkle root hash', hash);
}

setInterval(anchorOnce, INTERVAL_MS).unref();
anchorOnce();

module.exports={anchorOnce};
