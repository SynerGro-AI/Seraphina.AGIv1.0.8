'use strict';
// Generates synthetic dataset entries to enrich training set deterministically.
const fs = require('fs');
const crypto = require('crypto');
const OUT = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
let COUNT = parseInt(process.env.SERAPHINA_SYNTH_COUNT || '60',10);
let SPREAD = parseFloat(process.env.SERAPHINA_SYNTH_SPREAD || '0.15'); // scales personality variability
let VOL_MULT = parseFloat(process.env.SERAPHINA_SYNTH_VOL_MULT || '2.5'); // volatility exaggeration
let DECISION_BASE = parseFloat(process.env.SERAPHINA_SYNTH_DECISION_BASE || '0.25');
let DECISION_JITTER = parseFloat(process.env.SERAPHINA_SYNTH_DECISION_JITTER || '0.35');

// Simple CLI arg parser (--count=40 --spread=0.2 --volMult=3.1 --decisionBase=0.2 --decisionJitter=0.4)
for(const arg of process.argv.slice(2)){
  const m = /^--([^=]+)=(.+)$/.exec(arg);
  if(!m) continue;
  const key=m[1]; const val=m[2];
  switch(key){
    case 'count': COUNT = parseInt(val,10)||COUNT; break;
    case 'spread': SPREAD = parseFloat(val)||SPREAD; break;
    case 'volMult': VOL_MULT = parseFloat(val)||VOL_MULT; break;
    case 'decisionBase': DECISION_BASE = parseFloat(val)||DECISION_BASE; break;
    case 'decisionJitter': DECISION_JITTER = parseFloat(val)||DECISION_JITTER; break;
  }
}

function rand(seed, i){
  return crypto.createHash('sha256').update(seed+':'+i).digest()[0]/255;
}

function clamp01(x){ return x<0?0:x>1?1:x; }
function makeEntry(i){
  const personality = {
    openness: clamp01(rand('open',i)* (1+SPREAD) ),
    stability: clamp01(rand('stab',i)* (1+SPREAD/2) ),
    empathy: clamp01(rand('empathy',i)* (1+SPREAD) ),
    prudence: clamp01(rand('prudence',i)* (1+SPREAD) ),
    integrity: clamp01(rand('integrity',i)* (1+SPREAD) ),
    ethical_alignment: clamp01(rand('align',i)* (1+SPREAD) )
  };
  // Derived composite dimension adding mild correlation patterns
  const composite = (personality.openness*0.3 + personality.empathy*0.4 + personality.integrity*0.3);
  const econSignals = {
    frenRevenueNorm: clamp01( (rand('frenRev',i)*0.6 + composite*0.4) ),
    frenCostNorm: clamp01( rand('frenCost',i)* (1+SPREAD) ),
    frenVolatility: clamp01( Math.pow(rand('frenVol',i),0.8) * VOL_MULT / 3 )
  };
  const intensityRaw = DECISION_BASE + (rand('intensity',i)-0.5)*DECISION_JITTER + composite*0.15;
  return {
    ts: Date.now() + i,
    personality,
    econSignals,
    text: 'Synthetic advisory sample '+i+' explore adapt optimize imagine risk balance volatility adjust '+(i%11),
    decisionContext: { intensity: Number(clamp01(intensityRaw).toFixed(6)) }
  };
}

function run(){
  let appended=0;
  for(let i=0;i<COUNT;i++){
    const e = makeEntry(i);
    fs.appendFileSync(OUT, JSON.stringify(e)+'\n');
    appended++;
  }
  console.log('[SyntheticDataset] appended', appended,'to', OUT);
}

if(require.main===module){ run(); }
module.exports = { run };