#!/usr/bin/env node
'use strict';
// seraphina-cull-replay-validate.js
// Replay validator for frame culling adaptation integrity.
// Reads provenance JSONL and verifies adaptProof leaves by reconstructing hashed sorted distances.
// Usage: node seraphina-cull-replay-validate.js --provenance=provenance-cull.jsonl --ledgerLeaves=ledger.json --input=unified-octalang-gpu.js
// PowerShell ENV examples (Windows):
//   $env:SERAPHINA_REPLAY_SPIKE_THRESH = "0.12"
//   $env:SERAPHINA_REPLAY_METRICS_PORT = "9109"
//   $env:SERAPHINA_REPLAY_METRICS_EPHEMERAL = "1"   # optional: exit after printing JSON (no persistent metrics)
// Generate provenance first via unified-octalang-gpu:
//   $env:SERAPHINA_CODER_PROVENANCE_PATH = "provenance-cull.jsonl"
//   node .\unified-octalang-gpu.js --adapt --lock
// Then run validator:
//   node .\seraphina-cull-replay-validate.js --provenance=provenance-cull.jsonl --debug
// Scrape metrics (if persistent):
//   Invoke-WebRequest http://localhost:9109/metrics | Select-Object -ExpandProperty Content

const fs = require('fs');
const crypto = require('crypto');
function sha256(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

function parseArgs(){
  const args = process.argv.slice(2); const cfg={};
  for(const a of args){
    if(a.startsWith('--provenance=')) cfg.prov = a.split('=')[1];
    else if(a.startsWith('--ledgerLeaves=')) cfg.leaves = a.split('=')[1];
    else if(a.startsWith('--input=')) cfg.input = a.split('=')[1];
  }
  return cfg;
}

function readJSONL(path){
  return fs.readFileSync(path,'utf8').split(/\r?\n/).filter(Boolean).map(l=>{ try { return JSON.parse(l); } catch{ return null; } }).filter(Boolean);
}

class ReplayValidator {
  constructor(provenance){ this.prov = provenance || []; }
  validate(options={}){
    const adaptProofEvents = this.prov.filter(r=> r.type === 'adaptProof');
    let mismatches=0;
    const events=[];
    for(const ev of adaptProofEvents){
      const distances = Array.isArray(ev.distances)? ev.distances.map(d=> parseFloat(d)) : [];
      const sorted = [...distances].sort((a,b)=>a-b);
      // Use JSON.stringify(sorted) for stable proof reproduction
      const recomputed = sha256(JSON.stringify(sorted.map(x=> Number.isFinite(x)? Number(x.toFixed(12)): x)));
      if(recomputed !== ev.adaptProof){
        mismatches++;
        if(options.debug){ console.log(`[ReplayValidator][Mismatch] ts=${ev.ts} expected=${ev.adaptProof.slice(0,8)} recomputed=${recomputed.slice(0,8)} sorted=[${sorted.map(x=>x.toFixed(4)).join(',')}]`); }
        events.push({ ts:ev.ts, mismatch:true, adaptProof: ev.adaptProof, recomputed });
      } else {
        if(options.debug){ console.log(`[ReplayValidator][OK] ts=${ev.ts} proof=${ev.adaptProof.slice(0,8)}`); }
        events.push({ ts:ev.ts, mismatch:false, adaptProof: ev.adaptProof });
      }
    }
    // Collect ham values prioritizing frameHam records (uses 'ham' field)
    const frameHamRecords = this.prov.filter(r=> r.type === 'frameHam' && typeof r.ham === 'number');
    let hamVals;
    if(frameHamRecords.length){
      hamVals = frameHamRecords.map(r=> parseFloat(r.ham)).filter(v=> Number.isFinite(v));
    } else {
      hamVals = this.prov.map(p=> {
        if(typeof p.hamming === 'number') return p.hamming;
        if(typeof p.ham === 'number') return p.ham;
        return NaN;
      }).map(v=> parseFloat(v)).filter(v=> Number.isFinite(v));
    }
    const avgHam = hamVals.length? hamVals.reduce((s,v)=>s+v,0)/hamVals.length : NaN;
    // Optional EMA smoothing
    const emaAlpha = (()=>{ const a = parseFloat(process.env.SERAPHINA_REPLAY_EMA_ALPHA || '0'); return Number.isFinite(a)? a : 0; })();
    let emaHam = avgHam;
    if(emaAlpha > 0 && hamVals.length){
      let ema = hamVals[0];
      for(let i=1;i<hamVals.length;i++){ ema = emaAlpha*hamVals[i] + (1-emaAlpha)*ema; }
      emaHam = ema;
    }
    let health = 'pending';
    if(hamVals.length){
      // Classification uses EMA if enabled else raw average
      const basis = (emaAlpha > 0)? emaHam : avgHam;
      if(basis < 0.05) health='healthy'; else if(basis < 0.12) health='caution'; else health='critical';
    }
    // Escalation rule: promote healthy->caution if any single ham >= spike threshold
    const spikeThresh = parseFloat(process.env.SERAPHINA_REPLAY_SPIKE_THRESH || '0.12');
    const maxHam = hamVals.length? Math.max(...hamVals) : NaN;
    if(health === 'healthy' && Number.isFinite(maxHam) && maxHam >= spikeThresh){
      health = 'caution';
    }
    return { mismatches, health, avgHam, emaHam: (emaAlpha>0? emaHam : null), emaAlpha: (emaAlpha>0? emaAlpha : null), maxHam, spikeThresh, events, adaptProofCount: adaptProofEvents.length, frameHamCount: frameHamRecords.length };
  }
}

function cliMain(){
  const cfg = parseArgs();
  if(!cfg.prov){ console.error('Missing --provenance'); process.exit(1); }
  const debug = process.argv.includes('--debug');
  const prov = readJSONL(cfg.prov);
  const validator = new ReplayValidator(prov);
  const result = validator.validate({ debug });
  // Optional metrics export
  const metricsPort = process.env.SERAPHINA_REPLAY_METRICS_PORT;
  if(metricsPort){
    try {
      const prom = require('prom-client');
      const registry = new prom.Registry();
      prom.collectDefaultMetrics({ register: registry });
      const avgGauge = new prom.Gauge({ name:'seraphina_replay_avg_ham', help:'Average hamming distance across provenance frame series (raw)', registers:[registry] });
      avgGauge.set(Number.isFinite(result.avgHam)? result.avgHam : 0);
      if(result.emaHam !== null){
        const emaGauge = new prom.Gauge({ name:'seraphina_replay_ema_avg_ham', help:'Exponentially smoothed average hamming distance (EMA)', registers:[registry] });
        emaGauge.set(Number.isFinite(result.emaHam)? result.emaHam : 0);
      }
      const maxGauge = new prom.Gauge({ name:'seraphina_replay_max_ham', help:'Maximum single-frame hamming distance observed', registers:[registry] });
      if(Number.isFinite(result.maxHam)) maxGauge.set(result.maxHam); else maxGauge.set(0);
      const mismatchGauge = new prom.Gauge({ name:'seraphina_replay_mismatches', help:'Replay adaptProof mismatches encountered', registers:[registry] });
      mismatchGauge.set(result.mismatches);
      const healthGauge = new prom.Gauge({ name:'seraphina_replay_health_level', help:'Replay health classification (0=pending,1=healthy,2=caution,3=critical)', registers:[registry] });
      const healthMap = { pending:0, healthy:1, caution:2, critical:3 };
      healthGauge.set(healthMap[result.health] || 0);
      const http = require('http');
      const server = http.createServer(async (req,res)=>{
        if(req.url === '/metrics'){
          res.setHeader('Content-Type', registry.contentType);
          res.end(await registry.metrics());
        } else {
          res.writeHead(404); res.end();
        }
      });
      server.listen(parseInt(metricsPort,10), ()=>{ if(debug) console.log(`[ReplayValidator][Metrics] Listening on :${metricsPort}`); });
      // Keep process alive unless ephemeral metrics requested
      if(!/^(1|true)$/i.test(process.env.SERAPHINA_REPLAY_METRICS_EPHEMERAL || '')){
        console.log('[ReplayValidator] Persistent metrics enabled. Press Ctrl+C to stop.');
        // Prevent exit by scheduling a far-future timeout
        setInterval(()=>{}, 1<<30);
      }
    } catch(e){ if(debug) console.log('[ReplayValidator][Metrics][Disabled]', e.message); }
  }
  console.log(JSON.stringify(result, null, 2));
}

if(require.main === module){
  try { cliMain(); } catch(e){ console.error('[ReplayValidator][ERROR]', e); process.exit(1); }
}

module.exports = ReplayValidator;