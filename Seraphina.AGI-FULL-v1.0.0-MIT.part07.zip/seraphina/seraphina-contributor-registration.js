/**
 * Contributor Registration & Stats API
 * Rate-limited registration with JWT issuance and per-contributor stats.
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const PORT = parseInt(process.env.CONTRIB_PORT || '8970',10);
const DATA_DIR = path.join(__dirname,'persistent_data');
const REG_FILE = path.join(DATA_DIR,'contributors.json');
const JWT_SECRET = process.env.CONTRIB_JWT_SECRET || 'CHANGE_ME_CONTRIB_SECRET';
let ACTIVE_JWT_SECRET = JWT_SECRET;
let NEXT_JWT_SECRET = null;
const MAX_PER_HOUR = parseInt(process.env.CONTRIB_MAX_PER_HOUR || '50',10);
const WINDOW_MS = 3600_000;

function load(){try{return JSON.parse(fs.readFileSync(REG_FILE,'utf8'))}catch{return{contributors:{}, events:[]}}}
function save(d){try{fs.writeFileSync(REG_FILE, JSON.stringify(d,null,2))}catch{}}

const state=load();

function rateCheck(ip){
  const now=Date.now();
  state.events=state.events.filter(e=> now - e.ts < WINDOW_MS);
  const count=state.events.filter(e=>e.ip===ip).length;
  if(count>=MAX_PER_HOUR) return false;
  state.events.push({ ip, ts: now });
  return true;
}

function issueToken(id, roles){
  return jwt.sign({ sub:id, roles }, ACTIVE_JWT_SECRET, { expiresIn: '6h' });
}

const app=express();
app.use(express.json());

app.post('/register',(req,res)=>{
  const ip=req.headers['x-forwarded-for']||req.socket.remoteAddress;
  if(!rateCheck(ip)) return res.status(429).json({ ok:false, error:'RATE_LIMIT'});
  const { id, publicKey } = req.body || {};
  if(!id||!publicKey) return res.status(400).json({ ok:false, error:'MISSING_FIELDS'});
  if(state.contributors[id]) return res.status(409).json({ ok:false, error:'EXISTS'});
  state.contributors[id]={ publicKey, registered: Date.now(), roles:['submitter'] };
  save(state);
  const token=issueToken(id, ['submitter']);
  res.json({ ok:true, id, token });
});

app.get('/stats/:id',(req,res)=>{
  const c=state.contributors[req.params.id];
  if(!c) return res.status(404).json({ ok:false, error:'NOT_FOUND'});
  // Aggregate from share_contributors.json if present
  const ledgerPath=path.join(DATA_DIR,'share_contributors.json');
  let ledger={}; try{ledger=JSON.parse(fs.readFileSync(ledgerPath,'utf8'))}catch{}
  const agg=ledger[req.params.id]||{ BTC:{shares:0,earnings:0}, RVN:{shares:0,earnings:0} };
  res.json({ ok:true, id:req.params.id, registered:c.registered, roles:c.roles, aggregate:agg });
});

// Simple admin guard via header (for demo). In production triad-gate.
function adminCheck(req,res,next){
  if(req.headers['x-admin-key'] !== (process.env.CONTRIB_ADMIN_KEY||'dev-admin')) return res.status(403).json({ ok:false, error:'ADMIN_REQUIRED'});
  next();
}

app.delete('/revoke/:id', adminCheck, (req,res)=>{
  if(!state.contributors[req.params.id]) return res.status(404).json({ ok:false, error:'NOT_FOUND'});
  state.contributors[req.params.id].revoked = Date.now();
  save(state);
  res.json({ ok:true, id:req.params.id, revoked:true });
});

app.post('/rotate-secret', adminCheck, (req,res)=>{
  // Two-phase rotation: set NEXT, then promote.
  if(!NEXT_JWT_SECRET) {
    NEXT_JWT_SECRET = crypto.randomBytes(48).toString('hex');
    return res.json({ ok:true, phase:'staging', nextSet:true });
  }
  ACTIVE_JWT_SECRET = NEXT_JWT_SECRET;
  NEXT_JWT_SECRET = null;
  res.json({ ok:true, phase:'promoted' });
});

app.listen(PORT,()=>console.log(`[CONTRIB] Registration service on :${PORT}`));
