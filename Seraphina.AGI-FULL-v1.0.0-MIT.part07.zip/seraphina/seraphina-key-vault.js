/**
 * Encrypted Key Vault (Triad Unlock Scaffold)
 * Stores encrypted private keys for BTC / RVN payouts.
 */
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
let runProtectedAction=null;try{({runProtectedAction}=require('./triad-consensus-loader'))}catch{}

const VAULT_FILE=path.join(__dirname,'persistent_data','key_vault.enc');
const KDF_SALT_LEN=16;
const IV_LEN=12;

function kdf(password,salt){return crypto.pbkdf2Sync(password,salt,100000,32,'sha256');}

function saveVault(obj,password){
  const salt=crypto.randomBytes(KDF_SALT_LEN);
  const key=kdf(password,salt);
  const iv=crypto.randomBytes(IV_LEN);
  const cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
  const pt=Buffer.from(JSON.stringify(obj));
  const ct=Buffer.concat([cipher.update(pt), cipher.final()]);
  const tag=cipher.getAuthTag();
  fs.writeFileSync(VAULT_FILE, Buffer.concat([salt,iv,tag,ct]));
}

function loadVault(password){
  const buf=fs.readFileSync(VAULT_FILE);
  const salt=buf.slice(0,KDF_SALT_LEN);
  const iv=buf.slice(KDF_SALT_LEN,KDF_SALT_LEN+IV_LEN);
  const tag=buf.slice(KDF_SALT_LEN+IV_LEN,KDF_SALT_LEN+IV_LEN+16);
  const ct=buf.slice(KDF_SALT_LEN+IV_LEN+16);
  const key=kdf(password,salt);
  const dec=crypto.createDecipheriv('aes-256-gcm',key,iv); dec.setAuthTag(tag);
  const pt=Buffer.concat([dec.update(ct), dec.final()]);
  return JSON.parse(pt.toString('utf8'));
}

function loadVaultSafe(password){ try { return loadVault(password); } catch { return {}; } }

function ensureEd25519Key(label,password){
  if(!password) throw new Error('Password required for vault');
  let vault=loadVaultSafe(password);
  if(vault[label] && vault[label].privateHex && vault[label].publicHex) return vault[label];
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const privDer = privateKey.export({ format:'der', type:'pkcs8' });
  const pubDer = publicKey.export({ format:'der', type:'spki' });
  const rec = { type:'ed25519', privateHex: privDer.toString('hex'), publicHex: pubDer.toString('hex'), created: Date.now() };
  vault[label] = rec;
  saveVault(vault,password);
  return rec;
}

async function protectedStore(label, wifOrKey, password){
  const exec=()=>{
    let vault={}; try{ vault=loadVault(password);}catch{}
    vault[label]={ value:wifOrKey, stored:Date.now() };
    saveVault(vault,password);
    return true;
  };
  if(runProtectedAction) await runProtectedAction('vault_store',{ label }, exec); else exec();
}

module.exports={ protectedStore, loadVault, loadVaultSafe, ensureEd25519Key };
