// seraphina-dashboard.js
// Minimal HTTP dashboard: exposes Prometheus metrics endpoint and last advisory digest.
'use strict';
const http = require('http');
const net = require('net');
const fs = require('fs');
let promClient=null; try{ promClient=require('prom-client'); }catch{ promClient=null; }
const ADVISORY_LEDGER = process.env.SERAPHINA_ADVISORY_LEDGER || 'seraphina-advisory-ledger.jsonl';
const PORT = parseInt(process.env.SERAPHINA_DASH_PORT || '8999',10);
// Windows named pipe path uses \\.\pipe\NAME. Canonical path plus normalization of any \? prefix.
const PIPE_CANONICAL = '\\.?\\pipe\\seraphina-health';
const PIPE_PATH = process.platform === 'win32'
  ? (() => {
      const raw = process.env.SERAPHINA_PIPE_PATH || PIPE_CANONICAL;
      return raw.replace('\\?\\pipe','\\.\\pipe');
    })()
  : (process.env.SERAPHINA_PIPE_PATH || '/tmp/seraphina-health.sock');
let pipeServer=null; let pipeClients=new Set();
const HEALTH_LEDGER = process.env.SERAPHINA_HEALTH_LEDGER || 'seraphina-health-ledger.jsonl';
function stableHash(o){ const crypto = require('crypto'); return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }
// Ensure agent metrics module loaded so counters/gauges exist
try { require('./aurrelia-agent-invoke'); } catch(_e) { /* ignore */ }
const PROMOTION_LEDGER = process.env.SERAPHINA_CAL_PROMOTION_LEDGER || 'seraphina-calibration-promotion-ledger.jsonl';
const SUCCESS_LEDGER = process.env.SERAPHINA_SUCCESS_RATE_LEDGER || 'seraphina-success-rate-ledger.jsonl';
const LABEL_FLIP_PCT = parseFloat(process.env.SERAPHINA_LABEL_FLIP_PCT || '0');
const EMA_ALERT_LEDGER = process.env.SERAPHINA_EMA_MEDIAN_ALERT_LEDGER || 'seraphina-ema-median-alert-ledger.jsonl';

function lastAdvisory(){
  if(!fs.existsSync(ADVISORY_LEDGER)) return null;
  try {
    const lines = fs.readFileSync(ADVISORY_LEDGER,'utf8').trim().split(/\n+/); if(!lines.length) return null;
    return JSON.parse(lines[lines.length-1]);
  } catch{ return null; }
}

function recentPromotions(limit=10){
  if(!fs.existsSync(PROMOTION_LEDGER)) return [];
  try {
    const lines = fs.readFileSync(PROMOTION_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
    return lines.slice(-limit).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean);
  } catch{ return []; }
}

function recentSuccess(limit=15){
  if(!fs.existsSync(SUCCESS_LEDGER)) return [];
  try {
    const lines = fs.readFileSync(SUCCESS_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
    return lines.slice(-limit).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean);
  } catch{ return []; }
}

function noiseSnapshot(){
  const entries = recentSuccess(30);
  const deltas = entries.map(e=> typeof e.emaVsMedianDelta==='number'? e.emaVsMedianDelta : null).filter(v=> v!==null);
  const rollingAvg = deltas.length? deltas.reduce((a,b)=>a+b,0)/deltas.length : 0;
  const latest = deltas.length? deltas[deltas.length-1] : null;
  return {
    labelFlipPct: LABEL_FLIP_PCT,
    emaVsMedianDeltaLatest: latest,
    emaVsMedianDeltaRollingAvg: Number(rollingAvg.toFixed(6)),
    sampleCount: deltas.length
  };
}

function readEmaAlerts(limit=20){
  if(!fs.existsSync(EMA_ALERT_LEDGER)) return [];
  try {
    const lines = fs.readFileSync(EMA_ALERT_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
    return lines.slice(-limit).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean);
  } catch { return []; }
}

function histogramQuantiles(){
  if(!promClient) return null;
  try {
    const metric = promClient.register.getSingleMetric('seraphina_ema_vs_median_delta_hist');
    if(!metric) return null;
    const values = metric.get().values; // array of bucket counts + sum + count
    const buckets = values.filter(v=> v.labels && Object.prototype.hasOwnProperty.call(v.labels,'le'))
      .map(v=> ({ le: parseFloat(v.labels.le), count: v.value }))
      .sort((a,b)=> a.le - b.le);
    const total = buckets.length? buckets[buckets.length-1].count : 0;
    if(!total) return { p50:null,p90:null,buckets };
    const target50 = total*0.5; const target90 = total*0.9;
    let p50=null,p90=null;
    for(const b of buckets){ if(p50===null && b.count>=target50) p50=b.le; if(p90===null && b.count>=target90) { p90=b.le; break; } }
    return { p50, p90, buckets };
  } catch { return null; }
}

function healthSnapshot(){
  const noise = noiseSnapshot();
  const alerts = readEmaAlerts(10);
  const lastAlert = alerts.length? alerts[alerts.length-1] : null;
  const hist = histogramQuantiles();
  // derive status
  const status = (lastAlert && lastAlert.type==='emaMedian:high')? 'hot'
    : (lastAlert && lastAlert.type==='emaMedian:low')? 'cold'
    : 'normal';
  return { status, noise, lastAlert, alertCount: alerts.length, histogram: hist };
}

// Primary HTTP server; will fallback to raw net server if binding fails.
let server = http.createServer(async (req,res)=>{
  if(req.url==='/advisory'){ const adv = lastAdvisory(); res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, advisory: adv })); return; }
  if(req.url.startsWith('/promotions')){ const promos = recentPromotions(); res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, promotions: promos })); return; }
  if(req.url.startsWith('/success')){ const succ = recentSuccess(); res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, success: succ })); return; }
  if(req.url==='/noise'){ const snap = noiseSnapshot(); res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, noise: snap })); return; }
  if(req.url==='/health'){ const hs = healthSnapshot(); res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, health: hs })); return; }
  if(req.url==='/metrics'){
    if(promClient){
      res.writeHead(200,{'Content-Type': promClient.register.contentType});
      res.end(await promClient.register.metrics()); return;
    }
    res.writeHead(503); res.end('# Prometheus disabled'); return;
  }
  res.writeHead(404); res.end(JSON.stringify({ ok:false }));
  if(req.url==='/ping'){ res.writeHead(200,{'Content-Type':'application/json'}); res.end(JSON.stringify({ ok:true, ts:Date.now() })); return; }
});

function logProcessDiagnostics(){
  console.log('[Diag] execArgv', process.execArgv);
  console.log('[Diag] versions', process.versions);
  try { console.log('[Diag] net.Server keys', Object.getOwnPropertyNames(net.Server.prototype)); } catch(_e){}
}

function internalSelfCheck(port){
  try {
    http.get('http://localhost:'+port+'/health', resp => {
      let data=''; resp.on('data',d=>data+=d); resp.on('end',()=> console.log('[SelfCheck]', resp.statusCode, data.slice(0,200))); 
    }).on('error', e=> console.log('[SelfCheckError]', e.message));
  } catch(e){ console.log('[SelfCheckException]', e.message); }
}

function attachServerEvents(s){
  s.on('error', (err)=>{
    console.error('[DashboardError]', err.code, err.message);
    if(err.code==='EADDRINUSE'){
      console.error('[Dashboard] Port in use; fallback raw net server on 9100');
      startRawNetServer(9100);
    }
  });
  s.on('close', ()=> console.log('[DashboardEvent] close'));
  s.on('listening', ()=> console.log('[DashboardEvent] listening'));
}

function periodicConnections(s){
  try { s.getConnections((err,count)=>{ if(!err) console.log('[Connections] active='+count); }); } catch(_e){}
}

function startHttpServer(port){
  server.listen(port, '0.0.0.0', ()=> {
    const addr = server.address();
    console.log('[Dashboard] bound', addr);
    console.log('[Dashboard] http://localhost:'+port+' /advisory /metrics /health /ping');
    logProcessDiagnostics();
    console.log('[DashboardDiag] cwd', process.cwd());
    console.log('[DashboardDiag] __dirname', __dirname);
    // Debug file write
    try { fs.writeFileSync('dashboard-debug-write.txt', 'debug '+Date.now()); console.log('[DashboardDiag] wrote dashboard-debug-write.txt'); } catch(e){ console.error('[DashboardDiagWriteError]', e.message); }
    setTimeout(()=> internalSelfCheck(port), 500); // delayed self-check
    // Immediate health snapshot write with ledger entry
    try {
      const healthPath = require('path').join(process.cwd(),'seraphina-health.json');
      const rawHealth = healthSnapshot();
      let prev='GENESIS';
      if(fs.existsSync(HEALTH_LEDGER)){
        const lines = fs.readFileSync(HEALTH_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
        if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch{} }
      }
      const ledgerEntry = { ts: Date.now(), snapshot: rawHealth, prevHash: prev };
      ledgerEntry.chainHash = stableHash(ledgerEntry);
      fs.appendFileSync(HEALTH_LEDGER, JSON.stringify(ledgerEntry)+'\n');
      const snap = { ok:true, health: rawHealth, ts: ledgerEntry.ts, chainHash: ledgerEntry.chainHash, prevHash: ledgerEntry.prevHash };
      fs.writeFileSync(healthPath, JSON.stringify(snap,null,2));
      console.log('[HealthFileImmediateWrite]', healthPath, ledgerEntry.chainHash);
    } catch(e){ console.error('[HealthLedgerImmediateError]', e.message); }
  });
  attachServerEvents(server);
  setInterval(()=> periodicConnections(server), 20000);
  setInterval(()=>{ try{ const a=server.address(); console.log('[AddressCheck]', a); }catch(_e){} }, 25000);
  // File-based health snapshot fallback every 15s
  setInterval(()=>{
    try {
      const healthPath = require('path').join(process.cwd(),'seraphina-health.json');
      const rawHealth = healthSnapshot();
      let prev='GENESIS';
      if(fs.existsSync(HEALTH_LEDGER)){
        const lines = fs.readFileSync(HEALTH_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
        if(lines.length){ try{ prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch{} }
      }
      const ledgerEntry = { ts: Date.now(), snapshot: rawHealth, prevHash: prev };
      ledgerEntry.chainHash = stableHash(ledgerEntry);
      try { fs.appendFileSync(HEALTH_LEDGER, JSON.stringify(ledgerEntry)+'\n'); } catch(e){ console.error('[HealthLedgerAppendError]', e.message); }
      const snap = { ok:true, health: rawHealth, ts: ledgerEntry.ts, chainHash: ledgerEntry.chainHash, prevHash: ledgerEntry.prevHash };
      fs.writeFileSync(healthPath, JSON.stringify(snap,null,2));
      console.log('[HealthFilePeriodicWrite]', healthPath, ledgerEntry.chainHash);
      // Named pipe write attempt (Windows). For *nix we create a UNIX socket fallback.
      if(pipeServer){
        const line = JSON.stringify(snap)+'\n';
        for(const c of pipeClients){ try{ c.write(line); }catch(_e){} }
        if(pipeClients.size) console.log('[PipeBroadcast] clients='+pipeClients.size);
      }
    } catch(e){ console.error('[HealthFileWriteError]', e.message); }
  }, 15000);
}

function startRawNetServer(port){
  const raw = net.createServer(sock => {
    sock.on('data', buf => {
      const reqStr = buf.toString('utf8');
      let path = '/';
      const m = /^GET\s+([^\s]+)\s+HTTP\//.exec(reqStr);
      if(m) path = m[1];
      let body='';
      if(path==='/health'){ body = JSON.stringify({ ok:true, health: healthSnapshot() }); }
      else if(path==='/ping'){ body = JSON.stringify({ ok:true, ts:Date.now() }); }
      else if(path==='/noise'){ body = JSON.stringify({ ok:true, noise: noiseSnapshot() }); }
      else { body = JSON.stringify({ ok:false, path }); }
      const resp = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: '+Buffer.byteLength(body)+'\r\nConnection: close\r\n\r\n'+body;
      sock.write(resp);
      sock.end();
    });
  });
  raw.on('error', e=> console.error('[RawServerError]', e.code, e.message));
  raw.listen(port, '0.0.0.0', ()=>{
    console.log('[RawNetDashboard] listening on', port);
    setTimeout(()=> internalSelfCheck(port), 600);
  });
}

// Attempt primary HTTP server first; also attempt secondary port after delay for diagnostics.
startHttpServer(PORT);
setTimeout(()=>{ console.log('[Diag] Attempting secondary port 9100'); startRawNetServer(9100); }, 1500);
// Start named pipe server (dashboard as broadcaster)
try {
  const net = require('net');
  pipeServer = net.createServer(sock => {
    pipeClients.add(sock);
    console.log('[PipeClient] connected total='+pipeClients.size);
    sock.on('close', ()=>{ pipeClients.delete(sock); console.log('[PipeClient] disconnected total='+pipeClients.size); });
    sock.on('error', e=>{ pipeClients.delete(sock); console.log('[PipeClientError]', e.message); });
  });
  pipeServer.on('error', e=> {
    console.error('[PipeServerError]', e.code, e.message);
    if(e.code==='EACCES' && process.platform==='win32'){
      console.error('[PipeServerFallback] Permission denied creating pipe. Will continue without pipe broadcast. You can adjust SERAPHINA_PIPE_PATH or run elevated.');
    }
  });
  // For *nix cleanup existing socket
  if(process.platform!=='win32' && fs.existsSync(PIPE_PATH)) { try{ fs.unlinkSync(PIPE_PATH); }catch(_e){} }
  pipeServer.listen(PIPE_PATH, ()=> {
    console.log('[PipeServer] listening', PIPE_PATH);
    // Diagnostic client attempt
    setTimeout(()=>{
      try {
        const diag = net.createConnection(PIPE_PATH, ()=>{
          console.log('[PipeDiag] client connected OK');
          diag.destroy();
        });
        diag.on('error', err=> console.error('[PipeDiagError]', err.code, err.message));
      } catch(err){ console.error('[PipeDiagInitError]', err.message); }
    }, 500);
  });
} catch(e){ console.error('[PipeInitError]', e.message); }
// Additional bindings attempt 127.0.0.1 and ephemeral port
setTimeout(()=>{
  try {
    const extra = http.createServer((req,res)=>{ res.writeHead(200,{'Content-Type':'text/plain'}); res.end('extra'); });
    extra.on('error', e=> console.error('[ExtraBindError]', e.code, e.message));
    extra.listen(PORT+1, '127.0.0.1', ()=> console.log('[ExtraBind] 127.0.0.1 port', PORT+1));
    const ephemeral = http.createServer((req,res)=>{ res.writeHead(200); res.end('ephemeral'); });
    ephemeral.listen(0, '127.0.0.1', ()=> console.log('[EphemeralBind]', ephemeral.address()));
  } catch(e){ console.error('[ExtraBindException]', e.message); }
}, 2200);
// Keep process alive
try { if(process.stdin.isTTY){ process.stdin.resume(); } } catch(_){}
