'use strict';
// seraphina-hamming-monitor.js
// Hamming diff tracking for triad cycle digests (SHA-256 hex) - deterministic.

class TriadHammingMonitor {
  constructor(){
    this.prev = null;
    this.diffs = []; // { ts, hamming, digest }
  }
  _ham256(aHex, bHex){
    if(!aHex || !bHex) return 0;
    const a = BigInt('0x'+aHex);
    const b = BigInt('0x'+bHex);
    let xor = a ^ b; let dist = 0n;
    while(xor){ dist += xor & 1n; xor >>= 1n; }
    return Number(dist) / 256; // normalized
  }
  // Public helper for external modules needing a direct distance without recording state.
  hammingDistance(aHex, bHex){
    return this._ham256(aHex, bHex);
  }
  record(digest){
    if(this.prev){
      const h = this._ham256(this.prev, digest);
      const rec = { ts: Date.now(), hamming: h, digest };
      this.diffs.push(rec);
    }
    this.prev = digest;
  }
  avg(){ if(!this.diffs.length) return 0; return this.diffs.reduce((s,d)=> s + d.hamming,0)/this.diffs.length; }
  health(){ const a=this.avg(); if(a < 0.05) return 'healthy'; if(a < 0.12) return 'caution'; return 'critical'; }
  last(n=5){ return this.diffs.slice(-n); }
}

module.exports = { TriadHammingMonitor };