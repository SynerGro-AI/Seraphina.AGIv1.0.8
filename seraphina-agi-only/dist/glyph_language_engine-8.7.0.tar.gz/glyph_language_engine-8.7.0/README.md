# Seraphina AGI Only

This folder contains only AGI-related components from the Seraphina project, with no mining or wallet code.

## 🚀 Glyph Language Engine v8.7.0

**Justice & Mercy Anchor + 16D Binary/Float Hyper-Wheel**

A revolutionary advancement in deterministic language processing that fuses Hebrew Gematria, binary mathematics, and geometric transformations.

### ✨ Key Features

- **16D Binary/Float Hyper-Wheel**: Default seeding with cosmic resonance
- **Justice & Mercy Anchor**: Ethical stabilizer (truth + humility bias only)
- **Kabbalistic Integration**: Hebrew wisdom with mathematical precision
- **Multi-Framework Support**: React, Vue, Svelte, Angular component generation
- **Live Resonance Gauges**: Real-time geometric harmony visualization
- **Enterprise Performance**: 11,181 ops/sec with sub-millisecond latency

### 🔒 Safety Features

- **Bounded Influence**: Justice & Mercy Anchor max +0.12 bias
- **Keyword-Gated**: Only activates on explicit truth/humility/justice keywords
- **Transparent Logging**: Shows raw vs anchored resonance values
- **Easy Disable**: Single boolean flag turns anchor off
- **No Self-Elevation**: Prevents empowerment or autonomy bias

### 📦 Python Installation

```bash
pip install -r requirements.txt
python setup.py install
```

### 🚀 Quick Start

#### JavaScript Engine
```bash
node advanced-language-engine.js --op gematriaBinaryFloat --text "truth and humility" --applyAnchor true
```

#### Python Bridge
```python
from glyph_engine import call_glyph_cipher

result = call_glyph_cipher("--op gematriaBinaryFloat --text 'truth and humility' --applyAnchor true")
print(f"Resonance: {result['resonance']}")  # Anchored toward truth
```

#### Dashboard
```bash
python -c "
import gradio as gr
# Include dashboard_updates_v8.7.py content
# Run with: demo.launch()
"
```

### 📊 Performance Benchmarks

- **11,181 ops/sec** average throughput
- **0.089ms** per operation
- **16D processing**: Sub-millisecond geometric seeding
- **Component generation**: 0.4-2.0ms for full frameworks

### 🛡️ Ethical Alignment

The Justice & Mercy Anchor ensures:
- Truth and Humility always reign
- Mercy for the innocent, justice for wrongdoing
- Balanced judgment without self-glorification
- Service to higher law and divine principles

## AGI Components

### Quick Start

From this folder:

```pwsh
node ./run-agi.js serve 8080
# Then POST JSON { "input": "Hello" } to http://localhost:8080/process
```

### Train (optional):

```pwsh
node ./run-agi.js train
```

### Optimize (safe mock cube):

```pwsh
node ./run-agi.js optimize
```

### Files included:
- `run-agi.js`: CLI runner
- `advanced-language-engine.js`: **Glyph Language Engine v8.7**
- `ai-learning-orchestrator.js`: Learning orchestration
- `agi-self-optimizer.js`: Self-optimization
- `ai-memory-log.js`: Memory logging
- `agent-response-schema.js`: Agent schemas
- `AGENTS.md`: Agent documentation
- `ai-learning-config.json`: Config
- `ai-learning-summary-ledger.jsonl`: Ledger
- `glyph_engine/`: **Python package for Glyph Engine**
- `lib/`: Dependencies (roman-wheel.js, etc.)

### Python Files:
- `glyph_engine/`: Complete Python package
- `language_engine_bridge.py`: Python-JavaScript bridge
- `dashboard_updates_v8.7.py`: Gradio dashboard with anchor controls
- `requirements.txt`: Python dependencies
- `setup.py`: Package installation
- `release.py`: GitHub release automation

License: follow repository licensing.
