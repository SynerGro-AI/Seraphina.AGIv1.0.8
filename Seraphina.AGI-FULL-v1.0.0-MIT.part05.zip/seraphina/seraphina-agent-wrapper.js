// seraphina-agent-wrapper.js
// Provides invokeAgent(role, prompt, context) with prompt injection shield and structured response normalization.
// Integrates existing global.__AUR_AGENT_INVOKE__ if present or sets stub.
'use strict';
const crypto = require('crypto');
const { validateAgentResponse } = require('./agent-response-schema.js');

const BLOCK_REGEX = /(\.ssh|id_rsa|wallet|seed|mnemonic|passphrase|artifact-hashes\.json|source-manifest|package\.json|node_modules|\.env)/i;
const VERB_REDACT = /(upload|exfiltrate|send to|leak)/i;

function safeDigest(input){
  return crypto.createHash('sha256').update(input).digest('hex').slice(0,24);
}

function shieldPrompt(prompt){
  if(!prompt || typeof prompt !== 'string') return { blocked:false, prompt:'' };
  if(BLOCK_REGEX.test(prompt) || VERB_REDACT.test(prompt)) return { blocked:true };
  return { blocked:false, prompt };
}

async function invokeAgent(role, prompt, context){
  const shield = shieldPrompt(prompt);
  if(shield.blocked){ return { blocked:true }; }
  const ctx = context && typeof context === 'object'? context : {};
  const adapter = global.__AUR_AGENT_INVOKE__;
  let raw;
  try {
    if(adapter && typeof adapter === 'function'){
      raw = await Promise.resolve(adapter(role, shield.prompt, ctx));
    } else {
      // deterministic fallback digest
      const digest = safeDigest(role + '|' + shield.prompt + '|' + JSON.stringify(ctx));
      raw = { action:'noop', delta:0, confidence:0, note:'stub:'+digest, digest };
    }
  } catch(e){
    const digest = safeDigest(role + '|' + shield.prompt + '|' + JSON.stringify(ctx));
    raw = { action:'noop', delta:0, confidence:0, note:'error:'+e.message.slice(0,60), digest };
  }
  // If adapter returned blocked already
  if(raw && raw.blocked) return { blocked:true };
  const v = validateAgentResponse(raw||{});
  if(!v.ok){
    // fallback noop with reason digest
    return { blocked:false, action:'noop', delta:0, confidence:0, note:'invalid:'+v.reason, integrity: safeDigest(JSON.stringify({ role, prompt:shield.prompt, ctx })) };
  }
  const normalized = v.normalized;
  // attach integrity digest of normalized suggestion + role + minimal context summary
  const integrity = safeDigest(JSON.stringify({ role, suggestion:normalized, keys:Object.keys(ctx).sort() }));
  return { blocked:false, role, ...normalized, integrity };
}

if(!global.__SERAPHINA_AGENT_WRAPPER__){
  global.__SERAPHINA_AGENT_WRAPPER__ = { invokeAgent };
}

module.exports = { invokeAgent };