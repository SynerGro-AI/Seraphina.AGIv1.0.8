// seraphina-coder-ast.js
// Optional AST parsing using esprima. Provides structure findings.
'use strict';
let esprima=null; try { esprima = require('esprima'); } catch(_e){ /* optional */ }
const crypto = require('crypto');
function h(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

function parseAST(code){
  if(!esprima){ return { ok:true, ast:null, findings:[{ type:'ast_unavailable' }], digest:h('none|'+code.length) }; }
  try {
    const ast = esprima.parseScript(code, { tolerant:true, loc:true });
    const findings=[];
    let funcCount=0, classCount=0, depthMax=0;
    function walk(node, depth){
      if(!node || typeof node!=='object') return;
      if(depth>depthMax) depthMax=depth;
      switch(node.type){
        case 'FunctionDeclaration': funcCount++; break;
        case 'ClassDeclaration': classCount++; break;
      }
      for(const k of Object.keys(node)){
        const v=node[k];
        if(Array.isArray(v)){ v.forEach(ch=>walk(ch, depth+1)); }
        else if(v && typeof v==='object'){ walk(v, depth+1); }
      }
    }
    walk(ast,0);
    if(depthMax>50){ findings.push({ type:'ast_deep_nesting', depth:depthMax }); }
    if(funcCount===0){ findings.push({ type:'no_functions' }); }
    const digest = h(JSON.stringify({ funcCount,classCount,depthMax,findingsLength:findings.length }));
    return { ok: findings.length===0, funcCount, classCount, depthMax, findings, digest };
  } catch(e){
    return { ok:false, error:e.message, findings:[{ type:'ast_parse_error', message:e.message }], digest:h('err|'+e.message) };
  }
}

module.exports = { parseAST };
