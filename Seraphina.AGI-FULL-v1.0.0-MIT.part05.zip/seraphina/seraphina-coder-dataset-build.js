#!/usr/bin/env node
'use strict';
// seraphina-coder-dataset-build.js
// Scans .js files and emits JSONL feature rows for training.
// Features: lineCount, avgLineLen, todoDensity, funcCount, classCount, optimizationScore, astDepthMax, syntaxIssueCount, digest.

const fs = require('fs');
const path = require('path');
const { CoderTriad } = require('./seraphina-coder-triad.js');
const { analyzeSecurity } = require('./seraphina-code-security-heuristics.js');

function listJsFiles(root){
  const out = [];
  function walk(p){
    let entries=[]; try { entries = fs.readdirSync(p,{ withFileTypes:true }); } catch(_e){ return; }
    for(const e of entries){
      const full = path.join(p, e.name);
      if(e.isDirectory()) walk(full); else if(e.name.endsWith('.js')) out.push(full);
    }
  }
  walk(root);
  return out;
}

function extractBasic(code){
  const lines = code.split(/\r?\n/);
  const lineCount = lines.length;
  const avgLineLen = lineCount? lines.reduce((a,l)=>a+l.length,0)/lineCount : 0;
  const todoCount = code.match(/TODO|FIXME|HACK/g)?.length || 0;
  const todoDensity = lineCount? todoCount/lineCount : 0;
  const funcCount = (code.match(/function\s+[A-Za-z0-9_]+\s*\(/g)?.length || 0) + (code.match(/=>/g)?.length || 0);
  const classCount = code.match(/class\s+[A-Za-z0-9_]+/g)?.length || 0;
  return { lineCount, avgLineLen, todoDensity, funcCount, classCount, todoCount };
}

function main(){
  const root = process.argv[2] || process.cwd();
  const outFile = process.argv[3] || 'seraphina-coder-dataset.jsonl';
  const triad = new CoderTriad({ seed: process.env.SERAPHINA_CODER_SEED || 'dataset-seed' });
  const files = listJsFiles(root);
  let written=0;
  const fd = fs.openSync(outFile,'a');
  for(const f of files){
    let code; try { code = fs.readFileSync(f,'utf8'); } catch(_e){ continue; }
    triad.registerBlock(f, code);
    const triadRes = triad.triadCycle({ id:f, code });
    const basic = extractBasic(code);
    const sec = analyzeSecurity(code);
    const row = {
      file: path.relative(root, f),
      ...basic,
      optimizationScore: triadRes.optimization.score,
      astDepthMax: triadRes.ast.depthMax || 0,
      syntaxIssueCount: triadRes.syntax.issues.length,
      securityEvalCalls: sec.evalCalls,
      securityExecCalls: sec.execCalls,
      securityBase64Large: sec.base64LargeBlobs,
      securityEntropyApprox: sec.entropyApprox,
      securityObfuscatedScore: sec.obfuscatedScore,
      securityFindings: sec.findings,
      digest: triadRes.digest
    };
    fs.writeSync(fd, JSON.stringify(row)+'\n');
    written++;
  }
  fs.closeSync(fd);
  console.log('[DatasetBuild] rows=', written, 'output=', outFile);
}

if(require.main === module){ main(); }