#!/usr/bin/env node
'use strict';
// seraphina-code-health-train.js
// Trains linear regression for optimizationScore and classification (<0.75) from dataset JSONL.
// Dataset rows produced by seraphina-coder-dataset-build.js

const fs = require('fs');
const crypto = require('crypto');
const { vectorize } = require('./seraphina-code-health-features.js');

const DATASET = process.argv[2] || 'seraphina-coder-dataset.jsonl';
const OUT = process.argv[3] || 'seraphina-code-health-weights.json';
const L2 = parseFloat(process.env.SERAPHINA_CODE_HEALTH_L2 || '0');
const SEED = process.env.SERAPHINA_CODE_HEALTH_SEED || 'code-health-seed';

function readRows(file){
  if(!fs.existsSync(file)) return [];
  return fs.readFileSync(file,'utf8').trim().split(/\r?\n/).filter(Boolean).map(l=>{ try { return JSON.parse(l); } catch{ return null; } }).filter(Boolean);
}

function linearRegression(X, y){
  // X: n x d, y: n
  const n = X.length; const d = X[0].length;
  // Build augmented matrix A = X^T X (+ lambda I), b = X^T y
  const A = Array.from({ length:d }, ()=> Array(d).fill(0));
  const b = Array(d).fill(0);
  for(let i=0;i<n;i++){
    const row = X[i];
    for(let j=0;j<d;j++){
      b[j] += row[j]*y[i];
      for(let k=0;k<d;k++) A[j][k] += row[j]*row[k];
    }
  }
  if(L2>0){ for(let j=0;j<d;j++) A[j][j] += L2; }
  // Solve via Gaussian elimination (deterministic)
  return solveLinearSystem(A,b);
}

function solveLinearSystem(A,b){
  const n = A.length;
  // Augment
  for(let i=0;i<n;i++) A[i] = A[i].concat([b[i]]);
  for(let col=0; col<n; col++){
    // Pivot selection deterministic (max abs)
    let pivot = col;
    for(let r=col+1;r<n;r++) if(Math.abs(A[r][col]) > Math.abs(A[pivot][col])) pivot = r;
    if(pivot!==col){ const tmp = A[col]; A[col] = A[pivot]; A[pivot] = tmp; }
    const div = A[col][col] || 1e-12;
    for(let c=col;c<=n;c++) A[col][c] /= div;
    for(let r=0;r<n;r++){
      if(r===col) continue;
      const factor = A[r][col];
      for(let c=col;c<=n;c++) A[r][c] -= factor*A[col][c];
    }
  }
  return A.map(row=> row[n]);
}

function logisticTrain(X,y,epochs=200,lr=0.1){
  const n = X.length; const d = X[0].length;
  let w = Array(d).fill(0);
  for(let e=0;e<epochs;e++){
    const grad = Array(d).fill(0);
    for(let i=0;i<n;i++){
      const z = dot(w,X[i]);
      const p = 1/(1+Math.exp(-z));
      const err = p - y[i];
      for(let j=0;j<d;j++) grad[j] += err*X[i][j];
    }
    for(let j=0;j<d;j++) w[j] -= lr*(grad[j]/n + (L2>0? L2*w[j]:0));
  }
  return w;
}

function dot(a,b){ let s=0; for(let i=0;i<a.length;i++) s+=a[i]*b[i]; return s; }

function main(){
  const rows = readRows(DATASET);
  if(rows.length===0){ console.error('[CodeHealthTrain] Empty dataset'); process.exit(1); }
  const X=[]; const y=[]; const yCls=[];
  for(const r of rows){
    const v = vectorize(r);
    X.push(v);
    const target = typeof r.optimizationScore === 'number'? r.optimizationScore : 0;
    y.push(target);
    yCls.push(target < 0.75 ? 1 : 0); // 1 = needs improvement
  }
  // Normalize features (deterministic min-max) store meta
  const mins = Array(X[0].length).fill(Infinity);
  const maxs = Array(X[0].length).fill(-Infinity);
  for(const row of X){ for(let j=0;j<row.length;j++){ if(row[j] < mins[j]) mins[j]=row[j]; if(row[j] > maxs[j]) maxs[j]=row[j]; } }
  const Xn = X.map(row=> row.map((v,j)=> maxs[j]===mins[j]? 0 : (v - mins[j])/(maxs[j]-mins[j])));
  const wReg = linearRegression(Xn,y);
  const wCls = logisticTrain(Xn,yCls,150,0.2);
  // Quality metrics
  function predictReg(row){ return dot(wReg,row); }
  function predictCls(row){ return 1/(1+Math.exp(-dot(wCls,row))); }
  let mse=0, acc=0;
  for(let i=0;i<Xn.length;i++){
    const pr = predictReg(Xn[i]); mse += (pr - y[i])**2;
    const pc = predictCls(Xn[i]); const label = pc>=0.5?1:0; if(label===yCls[i]) acc++;
  }
  mse/=Xn.length; acc/=Xn.length;
  const meta = {
    seed: SEED,
    dims: X[0].length,
    featureOrder: ['lineCount','avgLineLen','funcCount','classCount','todoDensity'],
    mins, maxs, l2: L2,
    regressionWeights: wReg,
    classificationWeights: wCls,
    mse: +mse.toFixed(6), acc: +acc.toFixed(6), rows: rows.length,
    threshold: 0.75,
    hash: crypto.createHash('sha256').update(JSON.stringify(wReg)+JSON.stringify(wCls)).digest('hex')
  };
  fs.writeFileSync(OUT, JSON.stringify(meta,null,2));
  console.log('[CodeHealthTrain] rows='+rows.length+' mse='+meta.mse+' acc='+meta.acc+' out='+OUT);
}

if(require.main === module){ main(); }