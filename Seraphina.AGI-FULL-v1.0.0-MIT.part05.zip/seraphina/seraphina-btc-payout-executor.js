if (process.env.REAL_STRICT !== '1' && process.env.DISABLE_DOTENV !== '1') { try { require('dotenv').config(); } catch {} }
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }
/**
 * BTC Payout Executor (PSBT Distribution Scaffold)
 */
const fs=require('fs');
const path=require('path');
const bitcoin=require('bitcoinjs-lib');
const { listUnspentForAddress, sendRawTransaction, rpcCall } = require('./btc-node-rpc');
let runProtectedAction=null;try{({runProtectedAction}=require('./triad-consensus-loader'))}catch{}
const { loadVault } = require('./seraphina-key-vault');

const PLAN_FILE=path.join(__dirname,'persistent_data','payout_plan.json');
const VAULT_PASS=process.env.VAULT_PASS||''; // supply at runtime
const OUTPUT_FILE=path.join(__dirname,'persistent_data','btc_payout_psbt.hex');
const BROADCAST_FILE=path.join(__dirname,'persistent_data','btc_payout_txid.txt');

function loadPlan(){try{return JSON.parse(fs.readFileSync(PLAN_FILE,'utf8'))}catch{return null}}

async function selectUTXOs(address, neededSats){
  try {
    const utxos = await listUnspentForAddress(address, 1);
    utxos.sort((a,b)=>a.value-b.value);
    const chosen=[]; let total=0;
    for(const u of utxos){ chosen.push(u); total+=u.value; if(total>=neededSats) break; }
    return { selected: chosen, total };  
  } catch (e){
    console.log('[BTC_PAYOUT] UTXO selection failed:', e.message);
    return { selected:[], total:0 };
  }
}

async function buildAndSign(plan, vault){
  const net=bitcoin.networks.bitcoin;
  const psbt=new bitcoin.Psbt({ network: net });
  // Assume vault holds payout source under key 'btc_source' with address + WIF
  const source = vault['btc_source'];
  if(!source || !source.value || !source.valueAddress){ throw new Error('VAULT_MISSING_SOURCE'); }
  const wif = source.value;
  const keyPair = bitcoin.ECPair.fromWIF(wif, net);
  const fromAddress = source.valueAddress;
  const recipients = plan.recipients.filter(r=>r.coin==='BTC');
  const totalOut = recipients.reduce((a,r)=> a + Math.floor(r.amount*1e8), 0);
  // Rough fee estimate (will refine later): 180 vbytes per input, 34 per output, +10 overhead * satPerVByte
  const satPerVByte = await fetchDynamicFeeRate();
  const outputsCount = new Set(recipients.map(r=>'btc_'+r.id)).size;
  const estFee = (180 * 2 + 34 * (outputsCount+1) + 10) * satPerVByte; // assume 2 inputs typical
  const need = totalOut + estFee;
  const { selected, total } = await selectUTXOs(fromAddress, need);
  if (total < need) throw new Error('INSUFFICIENT_FUNDS');
  selected.forEach(u=> psbt.addInput({ hash:u.txid, index:u.vout, witnessUtxo:{ script: Buffer.from(u.scriptPubKey,'hex'), value:u.value } }));
  const totalsByRecipient={};
  plan.recipients.filter(r=>r.coin==='BTC').forEach(r=>{
    // Expect vault entry label: btc_<contributor>
    const key= 'btc_'+r.id;
    if(!vault[key]||!vault[key].valueAddress){return;} // store derived payout addresses ahead of time
    if(!totalsByRecipient[key]) totalsByRecipient[key]=0;
    totalsByRecipient[key]+=Math.floor(r.amount*100000000);
  });
  for(const [k,amt] of Object.entries(totalsByRecipient)){
    psbt.addOutput({ address: vault[k].valueAddress, value: amt });
  }
  // Change output (if any)
  const change = total - totalOut - estFee;
  if (change > 0) {
    psbt.addOutput({ address: fromAddress, value: change });
  }
  // Sign all inputs
  psbt.signAllInputs(keyPair);
  psbt.validateSignaturesOfAllInputs();
  psbt.finalizeAllInputs();
  const tx = psbt.extractTransaction();
  return { psbt, raw: tx.toHex() };
}

async function main(){
  const plan=loadPlan(); if(!plan) return console.log('[BTC_PAYOUT] No plan');
  let vault={}; try{vault=loadVault(VAULT_PASS);}catch{ return console.log('[BTC_PAYOUT] Vault load failed'); }
  const exec=async ()=>{
    try {
      const { psbt, raw } = await buildAndSign(plan, vault);
      fs.writeFileSync(OUTPUT_FILE, psbt.toHex());
      console.log('[BTC_PAYOUT] PSBT written', OUTPUT_FILE);
      if (process.env.BTC_AUTO_BROADCAST === '1') {
        const txid = await sendRawTransaction(raw);
        fs.writeFileSync(BROADCAST_FILE, txid + '\n');
        console.log('[BTC_PAYOUT] Broadcast TXID', txid);
      } else {
        console.log('[BTC_PAYOUT] Raw TX (not broadcast):', raw.slice(0,32)+'...');
      }
    } catch (e) {
      console.log('[BTC_PAYOUT] ERROR:', e.message);
    }
  };
  if(runProtectedAction){ runProtectedAction('btc_payout_build',{ ts:Date.now() }, exec).catch(e=>console.error(e.message)); }
  else exec();
}
main();

async function fetchDynamicFeeRate(){
  if (process.env.BTC_FEE_RATE) return parseInt(process.env.BTC_FEE_RATE,10);
  try { const est = await rpcCall('estimatesmartfee',[2]); if (est && est.feerate) return Math.max(1, Math.round(est.feerate * 100000)); } catch {}
  try {
    const https=require('https');
    const fee = await new Promise((res,rej)=>{ const r=https.request({host:'mempool.space',path:'/api/v1/fees/recommended'},m=>{let d='';m.on('data',c=>d+=c);m.on('end',()=>{try{res(JSON.parse(d))}catch(e){rej(e)}});}); r.on('error',rej); r.end(); });
    if (fee && fee.fastestFee) return fee.fastestFee;
  } catch {}
  return 8;
}
