'use strict';
// seraphina-autotest.js
// Autonomous test runner for Seraphina: periodically executes core self-checks.
// Provides on-demand runAllTests and background scheduler.

const crypto = require('crypto');

function now(){ return Date.now(); }

// Individual test contracts should return { name, ok, metrics?, error? }
function testSimulationBasic(api){
  const tStart = now();
  try {
    const targetPrudence = -0.2; const targetTruth = 0.3;
  const res = api.virtueSim.runSimulation({ n: 120, seed: 'autotest-seed', corrPrudence: targetPrudence, corrTruth: targetTruth });
    if(!res.ok) return { name:'simulation_basic', ok:false, error:res.code||'SIM_FAIL', durationMs: now()-tStart };
    const m = res.metrics;
    const duration = now()-tStart;
    const integrity = typeof m.n === 'number' && m.n >= 50 && Number.isFinite(m.corrPrudenceHarm) && Number.isFinite(m.corrTruthfulnessPass) && duration < 15000;
    return { name:'simulation_basic', ok: integrity, metrics:{ n:m.n, corrPrudenceHarm:m.corrPrudenceHarm, corrTruthfulnessPass:m.corrTruthfulnessPass, durationMs: duration }, durationMs: duration };
  } catch(e){ return { name:'simulation_basic', ok:false, error:e.message, durationMs: now()-tStart }; }
}

function testTrainingWrapper(api){
  const tStart = now();
  try {
    const out = api.training.trainModel({ epochs: 3 });
    if(!out || !out.ok) return { name:'training_wrapper', ok:false, error:(out && out.code)||'TRAIN_FAIL', durationMs: now()-tStart };
    const sb = out.result?.scoreboard || out.scoreboard || out.result?.result?.scoreboard;
    const integrity = !!(sb && sb.acc != null && sb.accEthical != null);
    return { name:'training_wrapper', ok: integrity, metrics:{ acc: sb? sb.acc:0, accEthical: sb? sb.accEthical:0 }, durationMs: now()-tStart };
  } catch(e){ return { name:'training_wrapper', ok:false, error:e.message, durationMs: now()-tStart }; }
}

function testAgentInvocation(api){
  const tStart = now();
  try {
    const resp = api.agent.invoke('burrowAdapt','autotest prompt', { acceptRatio: 0.5 });
    return Promise.resolve(resp).then(r=>{
      const ok = !r.blocked;
      const metrics = { action: r.action||'noop', confidence: typeof r.confidence==='number'? r.confidence : 0 };
      return { name:'agent_invoke', ok, metrics, durationMs: now()-tStart };
    }).catch(e=> ({ name:'agent_invoke', ok:false, error:e.message, durationMs: now()-tStart }));
  } catch(e){ return { name:'agent_invoke', ok:false, error:e.message, durationMs: now()-tStart }; }
}

function testCacheIntegrity(api){
  const tStart = now();
  try {
    // Run two simulations to populate cache then scan integrity
    api.virtueSim.runSimulation({ n: 64, seed:'cache-a' });
    api.virtueSim.runSimulation({ n: 64, seed:'cache-b' });
    const scan = api.meta.scanSimulationCacheIntegrity();
    const ok = scan && scan.ok && scan.scanned >= 2 && scan.mismatches === 0;
    return { name:'cache_integrity_scan', ok, metrics:{ scanned: scan.scanned, mismatches: scan.mismatches }, durationMs: now()-tStart };
  } catch(e){ return { name:'cache_integrity_scan', ok:false, error:e.message, durationMs: now()-tStart }; }
}

const TESTS = [ testSimulationBasic, testTrainingWrapper, testAgentInvocation, testCacheIntegrity ];

async function runAllTests(api){
  const started = now();
  const results = [];
  for(const t of TESTS){
    const r = t(api);
    const final = r && typeof r.then === 'function' ? await r : r;
    results.push(final);
  }
  const passCount = results.filter(r=>r.ok).length;
  const failCount = results.length - passCount;
  const digest = crypto.createHash('sha256').update(JSON.stringify(results.map(r=>({ name:r.name, ok:r.ok })))).digest('hex').slice(0,24);
  return { ok:true, started, finished: now(), passCount, failCount, total: results.length, digest, results };
}

// Scheduler
let intervalHandle=null; let lastReport=null; let config=null;
function startAutonomous(api, opts={}){
  if(intervalHandle) return { ok:true, already:true, intervalMs: config.intervalMs };
  const intervalMs = parseInt(opts.intervalMs != null? opts.intervalMs : (process.env.SERAPHINA_AUTOTEST_INTERVAL_MS||'600000'),10); // default 10m
  const jitterPct = parseFloat(opts.jitterPct != null? opts.jitterPct : (process.env.SERAPHINA_AUTOTEST_JITTER_PCT||'0.1')); // 10% jitter default
  config = { intervalMs, jitterPct };
  async function cycle(){
    try { lastReport = await runAllTests(api); } catch(e){ lastReport = { ok:false, error:e.message, started: now(), finished: now() }; }
    // schedule next with jitter
    const jitter = Math.floor(intervalMs * jitterPct * (Math.random()-0.5)*2); // +/- jitter
    intervalHandle = setTimeout(cycle, Math.max(1000, intervalMs + jitter));
  }
  cycle();
  return { ok:true, intervalMs };
}
function stopAutonomous(){ if(intervalHandle){ clearTimeout(intervalHandle); intervalHandle=null; return { ok:true, stopped:true }; } return { ok:false, code:'NOT_RUNNING' }; }
function getLastReport(){ return lastReport? JSON.parse(JSON.stringify(lastReport)) : null; }

module.exports = { runAllTests, startAutonomous, stopAutonomous, getLastReport };