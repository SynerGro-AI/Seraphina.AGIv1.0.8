// seraphina-coder-triad.js
// Orchestrator combining tier1 syntax, tier2 optimization, tier3 mesh.
'use strict';
const { analyzeSyntax } = require('./seraphina-coder-tier1.js');
const { optimizeHeuristic } = require('./seraphina-coder-tier2.js');
const { MeshRegistry } = require('./seraphina-coder-tier3.js');
const { parseAST } = require('./seraphina-coder-ast.js');
const crypto = require('crypto');

function h(s){ return crypto.createHash('sha256').update(s).digest('hex'); }

class CoderTriad {
  constructor(opts={}){
    this.seed = opts.seed || process.env.SERAPHINA_CODER_SEED || 'coder-triad-seed';
    this.mesh = new MeshRegistry(this.seed);
    this.metrics = { syntaxChecks:0, optimizations:0, meshLinks:0 };
    this.meshPath = process.env.SERAPHINA_CODER_MESH_PATH || null;
    this.provPath = process.env.SERAPHINA_CODER_PROVENANCE_PATH || null;
    if(this.meshPath){ this._loadMesh(); }
    // Prometheus optional
    try {
      const prom = require('prom-client');
      this.promSyntax = new prom.Counter({ name:'seraphina_coder_syntax_checks_total', help:'Total syntax audits'});
      this.promOpt = new prom.Counter({ name:'seraphina_coder_optimizations_total', help:'Total optimization runs'});
      this.promLinks = new prom.Counter({ name:'seraphina_coder_mesh_links_total', help:'Total mesh link suggestion cycles'});
      this.promQuality = new prom.Gauge({ name:'seraphina_coder_last_quality_score', help:'Last optimization quality score'});
    } catch(_e){ /* prom-client not present */ }
  }
  registerBlock(id, code){ return this.mesh.register(id, code); }
  _loadMesh(){
    try {
      const fs = require('fs');
      if(fs.existsSync(this.meshPath)){
        const raw = JSON.parse(fs.readFileSync(this.meshPath,'utf8'));
        if(Array.isArray(raw.blocks)){
          raw.blocks.forEach(b=> this.mesh.blocks.set(b.id, b));
        }
      }
    } catch(e){ /* ignore */ }
  }
  _saveMesh(){
    if(!this.meshPath) return;
    try {
      const fs = require('fs');
      const out = { savedAt: Date.now(), blocks: Array.from(this.mesh.blocks.values()) };
      fs.writeFileSync(this.meshPath, JSON.stringify(out,null,2));
    } catch(e){ /* ignore */ }
  }
  audit(code){
    const res = analyzeSyntax(code); this.metrics.syntaxChecks++; if(this.promSyntax) this.promSyntax.inc(); return res;
  }
  optimize(code){
    const res = optimizeHeuristic(code); this.metrics.optimizations++; if(this.promOpt){ this.promOpt.inc(); this.promQuality.set(res.score); } return res;
  }
  meshLinks(id){ const res = this.mesh.linkSuggestions(id); this.metrics.meshLinks++; if(this.promLinks) this.promLinks.inc(); return res; }
  triadCycle(block){
    // Optional shared mesh refresh for multi-agent pico mesh communication
    if(this.meshPath && process.env.SERAPHINA_CODER_MESH_REFRESH === '1'){
      // Reload before cycle to integrate other agents' registrations
      this._loadMesh();
    }
    const syntax = this.audit(block.code);
    const opt = this.optimize(block.code);
    const links = this.meshLinks(block.id);
    const astInfo = parseAST(block.code);
    const digest = h(JSON.stringify({ syntax: syntax.digest, opt: opt.digest, links: links.digest, ast: astInfo.digest, seed:this.seed }));
    // Persist mesh state periodically (every 5 syntax audits) when path set
    if(this.meshPath && (this.metrics.syntaxChecks % 5 === 0)) this._saveMesh();
    if(this.provPath){
      try {
        const fs = require('fs');
        const rec = {
          ts: Date.now(),
          syntaxDigest: syntax.digest,
          optDigest: opt.digest,
          astDigest: astInfo.digest,
          triadDigest: digest,
          checks: this.metrics.syntaxChecks,
          optScore: opt.score,
          linkCount: links.linkCount || 0
        };
        fs.appendFileSync(this.provPath, JSON.stringify(rec)+"\n");
      } catch(e){ /* ignore provenance errors */ }
    }
    return { syntax, optimization: opt, links, ast: astInfo, digest };
  }
}

module.exports = { CoderTriad };
