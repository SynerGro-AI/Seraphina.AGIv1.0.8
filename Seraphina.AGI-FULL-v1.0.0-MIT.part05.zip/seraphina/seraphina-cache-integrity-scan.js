// seraphina-cache-integrity-scan.js
// Utility to re-hash all simulation cache metrics and report mismatches.
'use strict';
const crypto = require('crypto');
const api = require('./seraphina-api.js');

function scanCache(){
  const stats = api.meta.getCacheStats();
  // Attempt to reach into module scope (simulation cache entries not exported). We re-require and scan its /cache JSON via direct function call by temporarily starting exporter.
  let mismatch = 0; let scanned = 0;
  // Start exporter if not started to leverage /cache route internally by constructing request object.
  if(!global.__SERAPHINA_FAKE_SCAN__){
    try { api.exporters.startPrometheusExporter({ port: 0 }); } catch(_e){}
  }
  // Simulate internal capture of cache keys using meta.forceMetricsSnapshot side-effect (doesn't list all). Instead, rely on persistence file if enabled.
  const persistEnabled = stats.persistence;
  if(persistEnabled && stats.path){
    const fs = require('fs');
    if(fs.existsSync(stats.path)){
      try {
        let buf = fs.readFileSync(stats.path);
        if(buf[0]===0x1f && buf[1]===0x8b){ const zlib=require('zlib'); buf = zlib.gunzipSync(buf); }
        const raw = JSON.parse(buf.toString('utf8'));
        if(raw && raw.entries){
          for(const [k,v] of Object.entries(raw.entries)){
            scanned++;
            const calc = crypto.createHash('sha256').update(JSON.stringify(v.metrics)).digest('hex');
            if(v.hash && v.hash !== calc) mismatch++;
          }
        }
      } catch(e){ return { ok:false, code:'SCAN_FAILED', message:e.message }; }
    }
  }
  return { ok:true, size: stats.size, scanned, mismatches: mismatch };
}

module.exports = { scanCache };