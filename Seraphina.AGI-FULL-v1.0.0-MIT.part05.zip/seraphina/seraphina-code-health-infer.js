#!/usr/bin/env node
'use strict';
// seraphina-code-health-infer.js
// Uses saved weights to score a code file or dataset row.
const fs = require('fs');
const { extractFromCode, vectorize } = require('./seraphina-code-health-features.js');

const WEIGHTS = process.argv[2] || 'seraphina-code-health-weights.json';
const TARGET_FILE = process.argv[3];

function loadWeights(path){ return JSON.parse(fs.readFileSync(path,'utf8')); }
function sigmoid(z){ return 1/(1+Math.exp(-z)); }

function normalize(vec, mins, maxs){ return vec.map((v,i)=> maxs[i]===mins[i]?0:(v-mins[i])/(maxs[i]-mins[i])); }

function scoreCode(code, meta){
  const feats = extractFromCode(code);
  const vec = vectorize(feats);
  const nv = normalize(vec, meta.mins, meta.maxs);
  const reg = meta.regressionWeights.reduce((s,w,i)=> s + w*nv[i],0);
  const clsZ = meta.classificationWeights.reduce((s,w,i)=> s + w*nv[i],0);
  const clsProb = sigmoid(clsZ);
  return { features: feats, regScore: reg, needsImprovementProb: clsProb, threshold: meta.threshold };
}

function main(){
  if(!fs.existsSync(WEIGHTS)){ console.error('[CodeHealthInfer] Missing weights', WEIGHTS); process.exit(1); }
  const meta = loadWeights(WEIGHTS);
  if(!TARGET_FILE){ console.error('Usage: node seraphina-code-health-infer.js <weights.json> <codeFile.js>'); process.exit(1); }
  const code = fs.readFileSync(TARGET_FILE,'utf8');
  const res = scoreCode(code, meta);
  console.log('[CodeHealthInfer]', JSON.stringify(res));
}

if(require.main === module){ main(); }