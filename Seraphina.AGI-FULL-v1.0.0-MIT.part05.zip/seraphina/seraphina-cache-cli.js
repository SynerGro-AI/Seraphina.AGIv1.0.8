'use strict';
// seraphina-cache-cli.js
// Simple CLI utility to inspect and control simulation cache persistence.
// Usage (PowerShell): node seraphina-cache-cli.js <command>
// Or after npm install -g (if published) via: seraphina-cache <command>
// Commands: stats, enable-persist, disable-persist, clear, prune

const api = require('./seraphina-api');

function print(obj){
  const prettyFlag = process.argv.includes('--pretty=false') ? false : true;
  process.stdout.write(JSON.stringify(obj, prettyFlag? null : undefined, prettyFlag? 2 : undefined)+'\n');
}

function stats(){
  const s = api.meta.getCacheStats();
  print(s);
}
function enablePersist(){
  const r = api.meta.toggleCachePersistence(true);
  print(r);
}
function disablePersist(){
  const r = api.meta.toggleCachePersistence(false);
  print(r);
}
function clear(){
  const r = api.meta.clearCache();
  print(r);
}
function prune(){
  // Optional arg --maxAgeMs=<number>
  const maxAgeArg = process.argv.find(a=> /^--maxAgeMs=/.test(a));
  const maxAgeMs = maxAgeArg? parseInt(maxAgeArg.split('=')[1],10) : 3600000; // default 1h
  const now = Date.now();
  let removed = 0;
  // Direct access to internal map not exported; rely on toggling persistence after filtering via snapshot
  const stats = api.meta.getLatestMetrics; // not suitable; need internal reflection -> fallback approach: run a dummy simulation to ensure API loaded
  // We can't access internal map directly; introduce lightweight hack: call forceMetricsSnapshot then toggle persistence to save, reload file to filter.
  const cacheStats = api.meta.getCacheStats();
  // Load file if exists and filter
  const path = cacheStats.path || process.env.SERAPHINA_SIM_CACHE_PATH;
  let applied=false;
  try {
    const fs = require('fs');
    if(path && fs.existsSync(path)){
      const raw = JSON.parse(fs.readFileSync(path,'utf8'));
      if(raw && raw.entries){
        for(const k of Object.keys(raw.entries)){
          const ent = raw.entries[k];
          if(now - (ent.lastAccessTs || ent.createdTs || 0) > maxAgeMs){ delete raw.entries[k]; removed++; }
        }
        raw.generatedTs = Date.now();
        fs.writeFileSync(path, JSON.stringify(raw,null,2));
        applied=true;
      }
    }
  } catch(e){ /* ignore */ }
  print({ ok:true, pruned: removed, applied, maxAgeMs });
}

function help(){
  console.log('seraphina-cache-cli commands:');
  console.log('  stats            Show cache size, capacity, persistence state');
  console.log('  enable-persist   Enable cache persistence (env overrides path)');
  console.log('  disable-persist  Disable cache persistence');
  console.log('  clear            Clear all cache entries');
  console.log('  prune            Remove persisted entries older than maxAgeMs (default 3600000)');
  console.log('Flags:');
  console.log('  --pretty=false   Output compact single-line JSON');
  console.log('  --maxAgeMs=<ms>  Age threshold for prune command');
  process.exit(0);
}

function main(){
  const cmd = process.argv[2];
  switch(cmd){
    case 'stats': return stats();
    case 'enable-persist': return enablePersist();
    case 'disable-persist': return disablePersist();
    case 'clear': return clear();
  case 'prune': return prune();
  case undefined: return help();
    default: console.error('Unknown command:', cmd); help();
  }
}

if(require.main === module){ main(); }
module.exports = { stats, enablePersist, disablePersist, clear };
