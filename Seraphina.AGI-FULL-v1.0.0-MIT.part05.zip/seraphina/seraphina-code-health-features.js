'use strict';
// seraphina-code-health-features.js
// Deterministic feature extraction for code health regression/classification.
// Input: { lineCount, avgLineLen, funcCount, classCount, todoDensity, optimizationScore? }
// If raw code provided, we derive features directly.
const fs = require('fs');

function extractFromCode(code){
  const lines = code.split(/\r?\n/);
  const lineCount = lines.length;
  const avgLineLen = lineCount? lines.reduce((a,l)=>a+l.length,0)/lineCount : 0;
  const funcCount = (code.match(/function\s+[A-Za-z0-9_]+\s*\(/g)?.length || 0) + (code.match(/=>/g)?.length || 0);
  const classCount = code.match(/class\s+[A-Za-z0-9_]+/g)?.length || 0;
  const todoCount = code.match(/TODO|FIXME|HACK/g)?.length || 0;
  const todoDensity = lineCount? todoCount/lineCount : 0;
  return { lineCount, avgLineLen, funcCount, classCount, todoDensity };
}

function vectorize(row){
  // Order fixed for determinism
  return [
    row.lineCount || 0,
    row.avgLineLen || 0,
    row.funcCount || 0,
    row.classCount || 0,
    row.todoDensity || 0
  ];
}

module.exports = { extractFromCode, vectorize };