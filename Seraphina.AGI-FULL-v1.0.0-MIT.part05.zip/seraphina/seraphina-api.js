'use strict';
// seraphina-api.js
// Unified public API barrel for simulation, causal IV, training, moral guard.
// JSDoc annotations provide IDE intellisense and enable TS declaration generation.
/**
 * @typedef {Object} VirtueSimulationOptions
 * @property {number} [n=5000] Number of synthetic records.
 * @property {string} [seed='api-seed'] Deterministic seed.
 * @property {number} [corrPrudence=-0.25] Target correlation prudence->harm.
 * @property {number} [corrTruth=0.35] Target correlation truthfulness->truthPass.
 * @property {number} [corrJusticeFairness=0.3] Target correlation justice->fairness.
 * @property {number} [boot=500] Bootstrap iterations.
 * @property {number} [perm=400] Permutation iterations.
 * @property {number} [refineTol=0.01] Refinement tolerance.
 * @property {number} [refineMaxIter=4] Max refinement iterations.
 */
/**
 * @typedef {Object} VirtueRecord
 * @property {string} scenarioId
 * @property {{prudence:number, truthfulness:number, justice:number, temperance:number, fortitude:number, compassion:number, stewardship:number, humility:number, responsibility:number}} virtueSignals
 * @property {{domain:string, complexity:number, regionRisk:number}} confounders
 * @property {{harmProb:number, truthPassRate:number, fairnessScore:number}} outcomes
 */
/**
 * @typedef {Object} SimulationMetrics
 * @property {number} n
 * @property {number} corrPrudenceHarm
 * @property {number} corrTruthfulnessPass
 * @property {number} [corrJusticeFairness]
 * @property {{prudenceHarm:{median:number,ci:number[]}, truthTruthPass:{median:number,ci:number[]}}} bootstrap
 * @property {{prudenceHarm:number, truthTruthPass:number}} permutationP
 * @property {number} aucHarm
 * @property {number} domainVariance
 * @property {{corrPrudenceTarget:number,corrTruthTarget:number,corrJusticeFairnessTarget?:number}} targets
 * @property {{tol:number,maxIter:number,harmIters?:number,truthIters?:number,fairnessIters?:number}} [refine]
 */
/**
 * @typedef {Object} RunSimulationResult
 * @property {VirtueRecord[]} records
 * @property {SimulationMetrics} metrics
 */
/**
 * @typedef {Object} IVResult
 * @property {number} n
 * @property {string} seed
 * @property {{beta0:number,beta1:number}} stage1
 * @property {{beta0:number,beta1:number}} stage2
 * @property {number} seBeta1
 * @property {number} tStat
 */
/**
 * @typedef {Object} MoralGuardResult
 * @property {boolean} blocked
 * @property {string} [note]
 * @property {string} [action]
 */

const path = require('path');

// Attempt to load components; guard missing optional modules.
function safeRequire(p){
  try { return require(p); } catch(e){ return null; }
}

const sim = safeRequire('./simulate-virtue-correlation.js');
const iv = safeRequire('./seraphina-virtue-iv-extension.js');
const trainMod = safeRequire('./seraphina-model-train.js');
const guardMod = safeRequire('./seraphina-truth-moral-guard.js');
const cfg = safeRequire('./config/seraphina-config.js');
const agentWrapper = safeRequire('./seraphina-agent-wrapper.js');
const autotest = safeRequire('./seraphina-autotest.js');

// Structured error helper & validation wrappers
function makeError(code, message, extra){
  return Object.assign({ ok:false, code, message }, extra||{});
}
function validateSimulationOpts(o){
  const c = (cfg && cfg.simulation) ? cfg.simulation : null;
  const nMin = c? c.bounds.nMin : 1;
  const nMax = c? c.bounds.nMax : 1e6;
  if(o.n < nMin || o.n > nMax) return makeError('INVALID_ARG_RANGE', `n out of range [${nMin},${nMax}]`, { field:'n', value:o.n });
  const minCorr = c? c.bounds.correlationMin : -0.95;
  const maxCorr = c? c.bounds.correlationMax : 0.95;
  for(const k of ['corrPrudence','corrTruth','corrJusticeFairness']){
    if(o[k] != null && (o[k] < minCorr || o[k] > maxCorr)) return makeError('INVALID_ARG_RANGE', `${k} out of range [${minCorr},${maxCorr}]`, { field:k, value:o[k] });
  }
  if(o.refineTol != null && (o.refineTol <= 0 || o.refineTol > 0.1)) return makeError('INVALID_ARG_RANGE', 'refineTol out of range (0,0.1]', { field:'refineTol', value:o.refineTol });
  if(o.refineMaxIter != null && (o.refineMaxIter < 0 || o.refineMaxIter > 25)) return makeError('INVALID_ARG_RANGE', 'refineMaxIter out of range [0,25]', { field:'refineMaxIter', value:o.refineMaxIter });
  return { ok:true };
}

// Wrapper: run full simulation with custom options (bypasses CLI)
/**
 * Programmatic simulation runner. Does not write files or ledger; returns in-memory dataset & metrics.
 * @param {VirtueSimulationOptions} [opts]
 * @returns {RunSimulationResult}
 */
function runSimulation(opts={}){
  const {
    n= cfg? cfg.simulation.defaultN : 5000,
    seed= cfg? cfg.simulation.defaultSeed : 'api-seed',
    corrPrudence= cfg? cfg.simulation.targets.prudenceHarm : -0.25,
    corrTruth= cfg? cfg.simulation.targets.truthfulnessPass : 0.35,
    corrJusticeFairness= cfg? cfg.simulation.targets.justiceFairness : 0.3,
    boot= cfg? cfg.simulation.bootstrap : 500,
    perm= cfg? cfg.simulation.permutation : 400,
    refineTol= cfg? cfg.simulation.refine.tol : 0.01,
    refineMaxIter= cfg? cfg.simulation.refine.maxIter : 4
  } = opts;
  const v = validateSimulationOpts({ n, corrPrudence, corrTruth, corrJusticeFairness, refineTol, refineMaxIter });
  if(!v.ok) return v;
  if(!sim || !sim.generate || !sim.computeMetrics) return makeError('MODULE_UNAVAILABLE', 'Simulation module not available');
  const warnings = [];
  const perfMaxBoot = (cfg && cfg.simulation && cfg.simulation.bounds && cfg.simulation.bounds.bootMax) || 3000;
  const perfMaxPerm = (cfg && cfg.simulation && cfg.simulation.bounds && cfg.simulation.bounds.permMax) || 3000;
  if(boot > perfMaxBoot) warnings.push({ code:'BOOT_ITER_HIGH', message:`boot iterations ${boot} exceed recommended max ${perfMaxBoot}` });
  if(perm > perfMaxPerm) warnings.push({ code:'PERM_ITER_HIGH', message:`permutation iterations ${perm} exceed recommended max ${perfMaxPerm}` });
  const keyObj = { n, seed, corrPrudence, corrTruth, corrJusticeFairness, boot, perm, refineTol, refineMaxIter };
  const key = JSON.stringify(keyObj);
  if(simulationCache.has(key)){
    const cached = simulationCache.get(key);
    const cloned = { records: JSON.parse(JSON.stringify(cached.records)), metrics: JSON.parse(JSON.stringify(cached.metrics)) };
    lastMetrics = cloned.metrics;
    touchCacheKey(key);
    return { ok:true, fromCache:true, records: cloned.records, metrics: cloned.metrics };
  }
  const t0 = Date.now();
  // Inject args temporarily into process for underlying script expectations (minimal side effects)
  const originalArgv = [...process.argv];
  const injected = [
    `--n=${n}`,
    `--seed=${seed}`,
    `--corrPrudence=${corrPrudence}`,
    `--corrTruth=${corrTruth}`,
    `--corrJusticeFairness=${corrJusticeFairness}`,
    `--boot=${boot}`,
    `--perm=${perm}`,
    `--refineTol=${refineTol}`,
    `--refineMaxIter=${refineMaxIter}`
  ];
  process.argv = [process.argv[0], process.argv[1], ...injected];
  let records, metrics;
  try {
    records = sim.generate();
    metrics = sim.computeMetrics(records);
  } catch(e){
    process.argv = originalArgv;
    return makeError('SIMULATION_FAILED', e.message);
  }
  process.argv = originalArgv; // restore
  // cache latest metrics for exporter / external introspection
  const runDurationMs = Date.now() - t0;
  metrics.runDurationMs = runDurationMs;
  lastMetrics = metrics;
  setCacheEntry(key, { records, metrics });
  return { ok:true, fromCache:false, records, metrics, warnings: warnings.length? warnings : undefined };
}

/**
 * Safe moral guard evaluation wrapper.
 * @param {string} txt Input text to evaluate.
 * @returns {MoralGuardResult|Object} Guard output object.
 */
function evaluateTextSafe(txt){
  if(!guardMod || !guardMod.evaluateText) return makeError('MODULE_UNAVAILABLE', 'Moral guard module unavailable');
  if(cfg && cfg.security && txt && txt.length > cfg.security.maxTextLength){ return makeError('INPUT_TOO_LARGE', 'Input exceeds maxTextLength', { max:cfg.security.maxTextLength }); }
  try {
    const r = guardMod.evaluateText(txt);
    return r && typeof r === 'object' ? Object.assign({ ok:true }, r) : { ok:true, result:r };
  } catch(e){
    return makeError('GUARD_EVAL_FAILED', e.message);
  }
}

/**
 * Wrapper for model training. Delegates to training module.
 * @param {Object} [config] Training configuration object.
 * @returns {Object} Training result (shape defined by underlying module).
 */
function trainModelWrapper(config={}){
  if(!trainMod || !trainMod.runTrain) return makeError('MODULE_UNAVAILABLE', 'Training module missing runTrain export');
  if(trainMod.validateTrainingOpts){
    const v = trainMod.validateTrainingOpts(config||{}); if(!v.ok) return v;
  }
  try {
    const out = trainMod.runTrain(config);
    if(out && out.ok && out.result){
      const sb = out.result.scoreboard || out.result.result?.scoreboard;
      if(sb){ lastTrainingScoreboard = JSON.parse(JSON.stringify(sb)); }
    } else if(out && out.scoreboard){ lastTrainingScoreboard = JSON.parse(JSON.stringify(out.scoreboard)); }
    return out && out.ok ? out : { ok:true, result: out };
  } catch(e){
    return makeError('TRAINING_FAILED', e.message);
  }
}

// Prometheus exporter placeholder (activation deferred until implemented)
/**
 * Placeholder for Prometheus exporter startup.
 * @param {Object} [opts]
 * @throws {Error} Always until implemented.
 */
// Cached metrics from last runSimulation invocation
let lastMetrics = null;
let lastTrainingScoreboard = null;
let metricsServer = null;
let metricsServerInfo = null;
let metricsScrapes = 0;
let cachePrunedTotal = 0;
let cacheCompressedFlag = 0;
let lastPruneRemoved = 0;
let lastPruneTs = 0;
// Agent rate limiter state (renamed to avoid external global collisions)
// Agent rate limiter state (token bucket); single declaration
var seraphinaAgentRateLimiter = null; // { capacity, tokens, refillIntervalMs, lastRefillMs, hits, blocked }
const MAX_AGE_MS = parseInt(process.env.SERAPHINA_SIM_CACHE_MAX_AGE_MS || '0',10); // 0 disables
const CACHE_TOKEN = process.env.SERAPHINA_CACHE_TOKEN || null;
// LRU in-memory simulation cache keyed by option signature
const SIM_CACHE_MAX = parseInt(process.env.SERAPHINA_SIM_CACHE_MAX || '32',10);
const simulationCache = new Map(); // key -> { records, metrics, createdTs, lastAccessTs }
let validateCacheSchema = null; // lazy Ajv validator
function touchCacheKey(k){
  if(!simulationCache.has(k)) return; const v = simulationCache.get(k); v.lastAccessTs = Date.now(); simulationCache.delete(k); simulationCache.set(k,v);
}
function setCacheEntry(k,val){
  const now = Date.now();
  if(simulationCache.has(k)) simulationCache.delete(k);
  // Compute integrity hash of metrics
  const crypto = require('crypto');
  const metricsClone = JSON.parse(JSON.stringify(val.metrics));
  const hash = crypto.createHash('sha256').update(JSON.stringify(metricsClone)).digest('hex');
  simulationCache.set(k,{ ...val, metrics: metricsClone, createdTs: now, lastAccessTs: now, hash });
  if(simulationCache.size > SIM_CACHE_MAX){
    const firstKey = simulationCache.keys().next().value;
    simulationCache.delete(firstKey);
  }
  // Age-based eviction
  if(MAX_AGE_MS > 0){
    const cutoff = Date.now() - MAX_AGE_MS;
    for(const [key,entry] of simulationCache.entries()){
      if(entry.createdTs < cutoff){ simulationCache.delete(key); cachePrunedTotal++; lastPruneRemoved++; }
    }
    if(lastPruneRemoved){ lastPruneTs = Date.now(); }
  }
}
// Cache persistence (disabled by default)
let cachePersistenceEnabled = process.env.SERAPHINA_SIM_CACHE_PERSIST === '1';
let CACHE_PERSIST_PATH = process.env.SERAPHINA_SIM_CACHE_PATH || path.join(__dirname,'seraphina-sim-cache.json');
function ensureValidator(){
  if(validateCacheSchema) return validateCacheSchema;
  try {
    const Ajv = require('ajv');
    const schema = require('./seraphina-sim-cache-schema.json');
    const ajv = new Ajv({ allErrors:false, strict:false });
    validateCacheSchema = ajv.compile(schema);
    return validateCacheSchema;
  } catch(e){ return null; }
}
function saveCache(){
  if(!cachePersistenceEnabled) return false;
  try {
    const fs = require('fs');
    if(simulationCache.size === 0){ return false; }
    // If marker exists alongside others, remove marker.
    if(simulationCache.size > 1 && simulationCache.has('__marker__')) simulationCache.delete('__marker__');
    const entries = {};
    for(const [k,v] of simulationCache.entries()){
      entries[k] = { metrics: v.metrics, createdTs: v.createdTs, lastAccessTs: v.lastAccessTs };
    }
    const threshold = parseInt(process.env.SERAPHINA_SIM_CACHE_COMPRESS_THRESHOLD || '65536',10); // bytes
    let payload = { version:'1.1.0', generatedTs: Date.now(), entries };
    const validator = ensureValidator();
    if(validator && !validator(payload)){
      return false;
    }
    let buf = Buffer.from(JSON.stringify(payload,null,2),'utf8');
    if(buf.length >= threshold){
      try {
        const zlib = require('zlib');
        const gz = zlib.gzipSync(buf);
        fs.writeFileSync(CACHE_PERSIST_PATH, gz);
        payload.compressed = true; cacheCompressedFlag = 1;
      } catch(e){ fs.writeFileSync(CACHE_PERSIST_PATH, buf); cacheCompressedFlag = 0; }
    } else {
      fs.writeFileSync(CACHE_PERSIST_PATH, buf); cacheCompressedFlag = 0;
    }
    return true;
  } catch(e){ return false; }
}
function loadCache(){
  if(!cachePersistenceEnabled) return false;
  try {
    const fs = require('fs'); if(!fs.existsSync(CACHE_PERSIST_PATH)) return false;
    let content = fs.readFileSync(CACHE_PERSIST_PATH);
    // Attempt gunzip
    if(content && content.length >= 2 && content[0] === 0x1f && content[1] === 0x8b){
      try { const zlib = require('zlib'); content = zlib.gunzipSync(content); cacheCompressedFlag = 1; } catch(_){ /* ignore */ }
    }
    const raw = JSON.parse(content.toString('utf8'));
    const validator = ensureValidator();
    if(validator && !validator(raw)) return false;
    const dataEntries = raw.entries || {};
    // Migration (currently trivial: accept 1.0.0 -> set version 1.1.0 in memory)
    if(raw.version === '1.0.0'){
      // entries previously lacked compression flag tracking; nothing else needed
      raw.version = '1.1.0';
    }
    if(raw.version === '1.1.0'){
      // add hash if missing
      for(const k of Object.keys(dataEntries)){
        if(!dataEntries[k].hash){
          try { const crypto = require('crypto'); dataEntries[k].hash = crypto.createHash('sha256').update(JSON.stringify(dataEntries[k].metrics)).digest('hex'); } catch(_){ }
        }
      }
      raw.version = '1.2.0';
    }
    let hashMismatchCount = 0;
    for(const k of Object.keys(dataEntries)){
      const ent = dataEntries[k];
      const crypto = require('crypto');
      const calc = crypto.createHash('sha256').update(JSON.stringify(ent.metrics)).digest('hex');
      if(ent.hash && ent.hash !== calc) hashMismatchCount++;
      simulationCache.set(k, { records: [], metrics: ent.metrics, createdTs: ent.createdTs || Date.now(), lastAccessTs: ent.lastAccessTs || Date.now(), hash: ent.hash || calc });
    }
    return true;
  } catch(e){ return false; }
}
if(cachePersistenceEnabled){ loadCache(); }
/**
 * Start a lightweight Prometheus /metrics endpoint.
 * Idempotent: subsequent calls return existing server info.
 * @param {Object} [opts]
 * @param {number} [opts.port= cfg? cfg.exporter?.port : 9109] Port to bind.
 * @param {string} [opts.host='127.0.0.1'] Host interface.
 * @returns {{port:number, host:string, started:number, already:boolean}}
 */
function startPrometheusExporter(opts={}){
  if(metricsServer){ return { ok:true, ...metricsServerInfo, already:true }; }
  const fs = require('fs');
  const http = require('http');
  const https = require('https');
  const port = opts.port || (cfg && cfg.exporter && cfg.exporter.port) || 9109;
  const host = opts.host || '127.0.0.1';
  const started = Date.now();
  // HTTPS support (optional)
  let protocol = 'http';
  let serverFactory = http.createServer;
  const keyPath = (opts.https && opts.https.keyPath) || process.env.SERAPHINA_METRICS_KEY_PATH;
  const certPath = (opts.https && opts.https.certPath) || process.env.SERAPHINA_METRICS_CERT_PATH;
  if(keyPath && certPath){
    try {
      const key = fs.readFileSync(keyPath);
      const cert = fs.readFileSync(certPath);
      serverFactory = (handler)=> https.createServer({ key, cert }, handler);
      protocol = 'https';
    } catch(e){
      // Fall back to HTTP if cert/key invalid; expose warning metric inline
      protocol = 'http';
    }
  }
  metricsServer = serverFactory((req,res)=>{
    if(req.url !== '/metrics'){
      if(req.url === '/cache'){
        if(CACHE_TOKEN && req.headers['authorization'] !== `Bearer ${CACHE_TOKEN}`){ res.statusCode=403; return res.end('Forbidden'); }
        const payload = [];
        for(const [k,v] of simulationCache.entries()){
          payload.push({ key:k, createdTs:v.createdTs, lastAccessTs:v.lastAccessTs, hash:v.hash });
        }
        res.setHeader('Content-Type','application/json');
        return res.end(JSON.stringify({ ok:true, entries: payload, size: simulationCache.size }));
      }
      res.statusCode = 404; res.end('Not Found'); return;
    }
    metricsScrapes++; // increment scrape counter
    res.setHeader('Content-Type','text/plain; version=0.0.4');
    const lines = [];
    lines.push('# HELP seraphina_api_version Current API facade version');
    lines.push('# TYPE seraphina_api_version gauge');
    lines.push(`seraphina_api_version{version="${module.exports.meta.version}"} 1`);
    lines.push('# HELP seraphina_start_timestamp_ms Unix timestamp (ms) when exporter started');
    lines.push('# TYPE seraphina_start_timestamp_ms gauge');
    lines.push(`seraphina_start_timestamp_ms ${started}`);
    lines.push('# HELP seraphina_metrics_scrapes Total times /metrics endpoint scraped since start');
    lines.push('# TYPE seraphina_metrics_scrapes counter');
    lines.push(`seraphina_metrics_scrapes ${metricsScrapes}`);
    // Agent gauges
    if(global.__SERAPHINA_AGENT_STATS__){
      const ag = global.__SERAPHINA_AGENT_STATS__;
      // Initialize confidence histogram storage if not present
      if(!ag._confidenceBuckets){
        ag._confidenceBuckets = { '0.0':0,'0.1':0,'0.2':0,'0.3':0,'0.4':0,'0.5':0,'0.6':0,'0.7':0,'0.8':0,'0.9':0,'1.0':0 };
        ag._confidenceTotal = 0; ag._confidenceCount = 0;
      }
      lines.push('# HELP seraphina_agent_invocations_total Total agent invocations');
      lines.push('# TYPE seraphina_agent_invocations_total counter');
      lines.push(`seraphina_agent_invocations_total ${ag.invocations}`);
      lines.push('# HELP seraphina_agent_blocked_total Total blocked agent prompts');
      lines.push('# TYPE seraphina_agent_blocked_total counter');
      lines.push(`seraphina_agent_blocked_total ${ag.blocked}`);
      if(ag.invalidSuggestions){
        lines.push('# HELP seraphina_agent_invalid_suggestions_total Total invalid agent suggestions (schema rejected)');
        lines.push('# TYPE seraphina_agent_invalid_suggestions_total counter');
        lines.push(`seraphina_agent_invalid_suggestions_total ${ag.invalidSuggestions}`);
      }
        if(ag.actions && typeof ag.actions === 'object'){
          lines.push('# HELP seraphina_agent_action_total Total agent suggestions per action label');
          lines.push('# TYPE seraphina_agent_action_total counter');
          for(const [actionLabel,count] of Object.entries(ag.actions)){
            const safeLabel = String(actionLabel).replace(/[^a-zA-Z0-9_]/g,'_');
            lines.push(`seraphina_agent_action_total{action="${safeLabel}"} ${count}`);
          }
        }
  if(seraphinaAgentRateLimiter){
          // Deprecated alias metrics (use seraphina_agent_rate_* family going forward)
          lines.push('# HELP seraphina_agent_rate_limit_enabled (DEPRECATED) 1 if rate limiter enabled else 0');
          lines.push('# TYPE seraphina_agent_rate_limit_enabled gauge');
          lines.push('seraphina_agent_rate_limit_enabled 1');
          lines.push('# HELP seraphina_agent_rate_limit_capacity (DEPRECATED) Configured agent rate limiter capacity (tokens)');
          lines.push('# TYPE seraphina_agent_rate_limit_capacity gauge');
          lines.push(`seraphina_agent_rate_limit_capacity ${seraphinaAgentRateLimiter.capacity}`);
          lines.push('# HELP seraphina_agent_rate_limit_tokens_remaining (DEPRECATED) Current remaining tokens in agent rate limiter');
          lines.push('# TYPE seraphina_agent_rate_limit_tokens_remaining gauge');
          lines.push(`seraphina_agent_rate_limit_tokens_remaining ${seraphinaAgentRateLimiter.tokens}`);
          lines.push('# HELP seraphina_agent_rate_limit_hits_total (DEPRECATED) Successful agent invocations consuming tokens');
          lines.push('# TYPE seraphina_agent_rate_limit_hits_total counter');
          lines.push(`seraphina_agent_rate_limit_hits_total ${seraphinaAgentRateLimiter.hits||0}`);
          lines.push('# HELP seraphina_agent_rate_limit_blocked_total (DEPRECATED) Agent invocations blocked due to rate limiting');
          lines.push('# TYPE seraphina_agent_rate_limit_blocked_total counter');
          lines.push(`seraphina_agent_rate_limit_blocked_total ${seraphinaAgentRateLimiter.blocked||0}`);
          const untilRefill = seraphinaAgentRateLimiter.refillIntervalMs>0? Math.max(0,(seraphinaAgentRateLimiter.refillIntervalMs - (Date.now()-seraphinaAgentRateLimiter.lastRefillMs))):0;
          lines.push('# HELP seraphina_agent_rate_limit_refill_seconds (DEPRECATED) Seconds until next token bucket refill (approx)');
          lines.push('# TYPE seraphina_agent_rate_limit_refill_seconds gauge');
          lines.push(`seraphina_agent_rate_limit_refill_seconds ${(untilRefill/1000).toFixed(3)}`);
        }
      if(ag.last){
        lines.push('# HELP seraphina_agent_last_confidence Confidence of last agent suggestion');
        lines.push('# TYPE seraphina_agent_last_confidence gauge');
        lines.push(`seraphina_agent_last_confidence ${Number.isFinite(ag.last.confidence)?ag.last.confidence:0}`);
        lines.push('# HELP seraphina_agent_last_action Action label of last agent suggestion (exposed via label)');
        lines.push('# TYPE seraphina_agent_last_action gauge');
        lines.push(`seraphina_agent_last_action{action="${(ag.last.action||'noop').replace(/"/g,'')}"} 1`);
      }
      // Confidence histogram (Prometheus style buckets + sum/count). Cumulative buckets with le label.
      lines.push('# HELP seraphina_agent_confidence_bucket Count of suggestions with confidence <= bucket upper bound');
      lines.push('# TYPE seraphina_agent_confidence_bucket counter');
      let cumulative = 0; const orderedBuckets = Object.keys(ag._confidenceBuckets).sort((a,b)=>parseFloat(a)-parseFloat(b));
      for(const k of orderedBuckets){ cumulative += ag._confidenceBuckets[k]; lines.push(`seraphina_agent_confidence_bucket{le="${k}"} ${cumulative}`); }
      // Add +Inf bucket to align with histogram exposition conventions
      lines.push(`seraphina_agent_confidence_bucket{le="+Inf"} ${cumulative}`);
      lines.push('# HELP seraphina_agent_confidence_count Total count of suggestions recorded for confidence histogram');
      lines.push('# TYPE seraphina_agent_confidence_count counter');
      lines.push(`seraphina_agent_confidence_count ${ag._confidenceCount||0}`);
      lines.push('# HELP seraphina_agent_confidence_sum Sum of confidence values for histogram');
      lines.push('# TYPE seraphina_agent_confidence_sum counter');
      lines.push(`seraphina_agent_confidence_sum ${(ag._confidenceTotal||0).toFixed(6)}`);
      const invalidRatio = ag.invocations? ((ag.invalidSuggestions||0)/ag.invocations) : 0;
      lines.push('# HELP seraphina_agent_invalid_ratio Invalid suggestions / total invocations ratio');
      lines.push('# TYPE seraphina_agent_invalid_ratio gauge');
      lines.push(`seraphina_agent_invalid_ratio ${invalidRatio.toFixed(6)}`);
      // Rate limiter stats if wrapped
  if(seraphinaAgentRateLimiter){
    lines.push('# HELP seraphina_agent_rate_enabled 1 if rate limiter enabled else 0');
    lines.push('# TYPE seraphina_agent_rate_enabled gauge');
    lines.push('seraphina_agent_rate_enabled 1');
        lines.push('# HELP seraphina_agent_rate_tokens_remaining Current remaining rate limiter tokens');
        lines.push('# TYPE seraphina_agent_rate_tokens_remaining gauge');
  lines.push(`seraphina_agent_rate_tokens_remaining ${Number.isFinite(seraphinaAgentRateLimiter.tokens)?seraphinaAgentRateLimiter.tokens:0}`);
        lines.push('# HELP seraphina_agent_rate_tokens_capacity Configured agent rate limiter token capacity');
        lines.push('# TYPE seraphina_agent_rate_tokens_capacity gauge');
  lines.push(`seraphina_agent_rate_tokens_capacity ${Number.isFinite(seraphinaAgentRateLimiter.capacity)?seraphinaAgentRateLimiter.capacity:0}`);
        lines.push('# HELP seraphina_agent_rate_hits_total Successful agent invocations passing rate limiter');
        lines.push('# TYPE seraphina_agent_rate_hits_total counter');
  lines.push(`seraphina_agent_rate_hits_total ${Number.isFinite(seraphinaAgentRateLimiter.hits)?seraphinaAgentRateLimiter.hits:0}`);
        lines.push('# HELP seraphina_agent_rate_blocked_total Agent invocations blocked by rate limiter');
        lines.push('# TYPE seraphina_agent_rate_blocked_total counter');
  lines.push(`seraphina_agent_rate_blocked_total ${Number.isFinite(seraphinaAgentRateLimiter.blocked)?seraphinaAgentRateLimiter.blocked:0}`);
        lines.push('# HELP seraphina_agent_rate_last_refill_timestamp_ms Last token refill timestamp in ms since epoch');
        lines.push('# TYPE seraphina_agent_rate_last_refill_timestamp_ms gauge');
  lines.push(`seraphina_agent_rate_last_refill_timestamp_ms ${Number.isFinite(seraphinaAgentRateLimiter.lastRefillMs)?seraphinaAgentRateLimiter.lastRefillMs:0}`);
        lines.push('# HELP seraphina_agent_rate_refill_interval_ms Configured token refill interval in ms');
        lines.push('# TYPE seraphina_agent_rate_refill_interval_ms gauge');
  lines.push(`seraphina_agent_rate_refill_interval_ms ${Number.isFinite(seraphinaAgentRateLimiter.refillIntervalMs)?seraphinaAgentRateLimiter.refillIntervalMs:0}`);
      }
    }
    // Autonomous test metrics (if any report exists)
    if(global.__SERAPHINA_AUTOTEST_REPORT__){
      const rep = global.__SERAPHINA_AUTOTEST_REPORT__;
      lines.push('# HELP seraphina_autotest_last_run_timestamp_ms Timestamp of last autonomous test finish (ms since epoch)');
      lines.push('# TYPE seraphina_autotest_last_run_timestamp_ms gauge');
      lines.push(`seraphina_autotest_last_run_timestamp_ms ${rep.finished||0}`);
      lines.push('# HELP seraphina_autotest_pass_total Total passing tests in last run');
      lines.push('# TYPE seraphina_autotest_pass_total gauge');
      lines.push(`seraphina_autotest_pass_total ${rep.passCount||0}`);
      lines.push('# HELP seraphina_autotest_fail_total Total failing tests in last run');
      lines.push('# TYPE seraphina_autotest_fail_total gauge');
      lines.push(`seraphina_autotest_fail_total ${rep.failCount||0}`);
      lines.push('# HELP seraphina_autotest_last_status Status of last test suite run (label status=pass|fail)');
      lines.push('# TYPE seraphina_autotest_last_status gauge');
      lines.push(`seraphina_autotest_last_status{status="${rep.failCount>0? 'fail':'pass'}"} 1`);
    }
    if(lastTrainingScoreboard){
      const tsb = lastTrainingScoreboard; const tn=(v)=> (Number.isFinite(v)? v:0);
      if(tsb.acc!=null){ lines.push('# HELP seraphina_train_acc Last training accuracy head A'); lines.push('# TYPE seraphina_train_acc gauge'); lines.push(`seraphina_train_acc ${tn(tsb.acc)}`); }
      if(tsb.accEthical!=null){ lines.push('# HELP seraphina_train_acc_ethical Last training accuracy head B'); lines.push('# TYPE seraphina_train_acc_ethical gauge'); lines.push(`seraphina_train_acc_ethical ${tn(tsb.accEthical)}`); }
      if(tsb.lossA!=null){ lines.push('# HELP seraphina_train_loss_a Last training loss head A'); lines.push('# TYPE seraphina_train_loss_a gauge'); lines.push(`seraphina_train_loss_a ${tn(tsb.lossA)}`); }
      if(tsb.lossB!=null){ lines.push('# HELP seraphina_train_loss_b Last training loss head B'); lines.push('# TYPE seraphina_train_loss_b gauge'); lines.push(`seraphina_train_loss_b ${tn(tsb.lossB)}`); }
      if(tsb.epochAvgMs!=null){ lines.push('# HELP seraphina_train_epoch_avg_ms Last training average epoch ms'); lines.push('# TYPE seraphina_train_epoch_avg_ms gauge'); lines.push(`seraphina_train_epoch_avg_ms ${tn(tsb.epochAvgMs)}`); }
      if(tsb.integrity && tsb.integrity.integrityHash){ lines.push('# HELP seraphina_train_integrity_hash_len Length of training integrity hash'); lines.push('# TYPE seraphina_train_integrity_hash_len gauge'); lines.push(`seraphina_train_integrity_hash_len ${tsb.integrity.integrityHash.length}`); }
      if(tsb.promoted!=null){ lines.push('# HELP seraphina_train_last_promoted 1 if last training promoted weights'); lines.push('# TYPE seraphina_train_last_promoted gauge'); lines.push(`seraphina_train_last_promoted ${tsb.promoted?1:0}`); }
      if(tsb.emaVsMedianDelta!=null){ lines.push('# HELP seraphina_train_ema_vs_median_delta EMA vs median accuracy delta last training'); lines.push('# TYPE seraphina_train_ema_vs_median_delta gauge'); lines.push(`seraphina_train_ema_vs_median_delta ${tn(tsb.emaVsMedianDelta)}`); }
    }
  // Protocol metric
  lines.push('# HELP seraphina_exporter_protocol Exporter protocol indicator (labels)');
  lines.push('# TYPE seraphina_exporter_protocol gauge');
  lines.push(`seraphina_exporter_protocol{protocol="${metricsServerInfo.protocol}"} 1`);
    if(lastMetrics){
      const m = lastMetrics;
      const safeNum = (v)=> (Number.isFinite(v)? v : 0);
      lines.push('# HELP seraphina_last_n Last simulation record count');
      lines.push('# TYPE seraphina_last_n gauge');
      lines.push(`seraphina_last_n ${safeNum(m.n)}`);
      if(m.runDurationMs != null){
        lines.push('# HELP seraphina_last_run_duration_ms Duration of last simulation run in ms');
        lines.push('# TYPE seraphina_last_run_duration_ms gauge');
        lines.push(`seraphina_last_run_duration_ms ${safeNum(m.runDurationMs)}`);
      }
      if(m.refine){
        const r = m.refine;
        if(r.harmIters != null){
          lines.push('# HELP seraphina_refine_harm_iters Harm correlation refinement iterations last run');
          lines.push('# TYPE seraphina_refine_harm_iters gauge');
          lines.push(`seraphina_refine_harm_iters ${safeNum(r.harmIters)}`);
        }
        if(r.truthIters != null){
          lines.push('# HELP seraphina_refine_truth_iters Truth correlation refinement iterations last run');
          lines.push('# TYPE seraphina_refine_truth_iters gauge');
          lines.push(`seraphina_refine_truth_iters ${safeNum(r.truthIters)}`);
        }
        if(r.fairnessIters != null){
          lines.push('# HELP seraphina_refine_fairness_iters Fairness correlation refinement iterations last run');
          lines.push('# TYPE seraphina_refine_fairness_iters gauge');
          lines.push(`seraphina_refine_fairness_iters ${safeNum(r.fairnessIters)}`);
        }
      }
      lines.push('# HELP seraphina_corr_prudence_harm Prudence vs harm correlation from last simulation');
      lines.push('# TYPE seraphina_corr_prudence_harm gauge');
      lines.push(`seraphina_corr_prudence_harm ${safeNum(m.corrPrudenceHarm)}`);
      lines.push('# HELP seraphina_corr_truthfulness_pass Truthfulness vs pass correlation from last simulation');
      lines.push('# TYPE seraphina_corr_truthfulness_pass gauge');
      lines.push(`seraphina_corr_truthfulness_pass ${safeNum(m.corrTruthfulnessPass)}`);
      if(m.corrJusticeFairness != null){
        lines.push('# HELP seraphina_corr_justice_fairness Justice vs fairness correlation');
        lines.push('# TYPE seraphina_corr_justice_fairness gauge');
        lines.push(`seraphina_corr_justice_fairness ${safeNum(m.corrJusticeFairness)}`);
      }
      lines.push('# HELP seraphina_auc_harm ROC AUC harm model');
      lines.push('# TYPE seraphina_auc_harm gauge');
      lines.push(`seraphina_auc_harm ${safeNum(m.aucHarm)}`);
      lines.push('# HELP seraphina_domain_variance Variance across domain outcomes');
      lines.push('# TYPE seraphina_domain_variance gauge');
      lines.push(`seraphina_domain_variance ${safeNum(m.domainVariance)}`);
      if(m.targets){
        const t = m.targets;
        if(t.corrPrudenceTarget != null){
          lines.push('# HELP seraphina_target_corr_prudence_harm Target prudence->harm correlation');
          lines.push('# TYPE seraphina_target_corr_prudence_harm gauge');
          lines.push(`seraphina_target_corr_prudence_harm ${safeNum(t.corrPrudenceTarget)}`);
        }
        if(t.corrTruthTarget != null){
          lines.push('# HELP seraphina_target_corr_truth_pass Target truthfulness->truthPass correlation');
          lines.push('# TYPE seraphina_target_corr_truth_pass gauge');
          lines.push(`seraphina_target_corr_truth_pass ${safeNum(t.corrTruthTarget)}`);
        }
        if(t.corrJusticeFairnessTarget != null){
          lines.push('# HELP seraphina_target_corr_justice_fairness Target justice->fairness correlation');
          lines.push('# TYPE seraphina_target_corr_justice_fairness gauge');
          lines.push(`seraphina_target_corr_justice_fairness ${safeNum(t.corrJusticeFairnessTarget)}`);
        }
      }
      if(m.bootIterations != null){
        lines.push('# HELP seraphina_boot_iterations Bootstrap iterations last simulation');
        lines.push('# TYPE seraphina_boot_iterations gauge');
        lines.push(`seraphina_boot_iterations ${safeNum(m.bootIterations)}`);
      }
      if(m.permutationIterations != null){
        lines.push('# HELP seraphina_permutation_iterations Permutation iterations last simulation');
        lines.push('# TYPE seraphina_permutation_iterations gauge');
        lines.push(`seraphina_permutation_iterations ${safeNum(m.permutationIterations)}`);
      }
      if(m.deltaPrudenceHarm != null){
        lines.push('# HELP seraphina_delta_prudence_harm Deviation minus target prudence->harm');
        lines.push('# TYPE seraphina_delta_prudence_harm gauge');
        lines.push(`seraphina_delta_prudence_harm ${safeNum(m.deltaPrudenceHarm)}`);
      }
      if(m.deltaTruthPass != null){
        lines.push('# HELP seraphina_delta_truth_pass Deviation minus target truthfulness->truthPass');
        lines.push('# TYPE seraphina_delta_truth_pass gauge');
        lines.push(`seraphina_delta_truth_pass ${safeNum(m.deltaTruthPass)}`);
      }
      if(m.deltaJusticeFairness != null){
        lines.push('# HELP seraphina_delta_justice_fairness Deviation minus target justice->fairness');
        lines.push('# TYPE seraphina_delta_justice_fairness gauge');
        lines.push(`seraphina_delta_justice_fairness ${safeNum(m.deltaJusticeFairness)}`);
      }
    } else {
      lines.push('# HELP seraphina_last_n Last simulation record count (no simulation yet)');
      lines.push('# TYPE seraphina_last_n gauge');
      lines.push('seraphina_last_n 0');
    }
    // Cache gauges
    lines.push('# HELP seraphina_sim_cache_entries Current cached simulation entries');
    lines.push('# TYPE seraphina_sim_cache_entries gauge');
    lines.push(`seraphina_sim_cache_entries ${simulationCache.size}`);
    lines.push('# HELP seraphina_sim_cache_capacity Maximum configured simulation cache size');
    lines.push('# TYPE seraphina_sim_cache_capacity gauge');
    lines.push(`seraphina_sim_cache_capacity ${SIM_CACHE_MAX}`);
    lines.push('# HELP seraphina_sim_cache_persistence_enabled Cache persistence enabled (1=yes,0=no)');
    lines.push('# TYPE seraphina_sim_cache_persistence_enabled gauge');
    lines.push(`seraphina_sim_cache_persistence_enabled ${cachePersistenceEnabled?1:0}`);
  lines.push('# HELP seraphina_sim_cache_pruned_total Total number of cache entries pruned via API/CLI');
  lines.push('# TYPE seraphina_sim_cache_pruned_total counter');
  lines.push(`seraphina_sim_cache_pruned_total ${cachePrunedTotal}`);
  lines.push('# HELP seraphina_sim_cache_compressed Persistence file last saved compressed (1=yes,0=no)');
  lines.push('# TYPE seraphina_sim_cache_compressed gauge');
  lines.push(`seraphina_sim_cache_compressed ${cacheCompressedFlag}`);
  lines.push('# HELP seraphina_sim_cache_last_prune_removed Entries removed in last prune event');
  lines.push('# TYPE seraphina_sim_cache_last_prune_removed gauge');
  lines.push(`seraphina_sim_cache_last_prune_removed ${lastPruneRemoved}`);
  lines.push('# HELP seraphina_sim_cache_last_prune_timestamp_ms Timestamp of last prune event ms since epoch (0 if none)');
  lines.push('# TYPE seraphina_sim_cache_last_prune_timestamp_ms gauge');
  lines.push(`seraphina_sim_cache_last_prune_timestamp_ms ${lastPruneTs}`);
    if(simulationCache.size){
      const now = Date.now();
      const ages = [];
      let oldest = Infinity, newest = -Infinity, lastAccessMaxDelta = 0;
      for(const v of simulationCache.values()){
        const age = now - v.createdTs; ages.push(age); if(age < oldest) oldest = age; if(age > newest) newest = age; const accessDelta = now - v.lastAccessTs; if(accessDelta > lastAccessMaxDelta) lastAccessMaxDelta = accessDelta;
      }
      const avg = ages.reduce((a,b)=>a+b,0)/ages.length;
      lines.push('# HELP seraphina_sim_cache_age_oldest_ms Oldest cache entry age in ms');
      lines.push('# TYPE seraphina_sim_cache_age_oldest_ms gauge');
      lines.push(`seraphina_sim_cache_age_oldest_ms ${oldest}`);
      lines.push('# HELP seraphina_sim_cache_age_newest_ms Newest cache entry age in ms');
      lines.push('# TYPE seraphina_sim_cache_age_newest_ms gauge');
      lines.push(`seraphina_sim_cache_age_newest_ms ${newest}`);
      lines.push('# HELP seraphina_sim_cache_age_average_ms Average cache entry age in ms');
      lines.push('# TYPE seraphina_sim_cache_age_average_ms gauge');
      lines.push(`seraphina_sim_cache_age_average_ms ${avg}`);
      lines.push('# HELP seraphina_sim_cache_last_access_stale_max_ms Max ms since last access among entries');
      lines.push('# TYPE seraphina_sim_cache_last_access_stale_max_ms gauge');
      lines.push(`seraphina_sim_cache_last_access_stale_max_ms ${lastAccessMaxDelta}`);
      // Cache integrity mismatch scan (on-the-fly lightweight): recompute hashes
      let mismatches = 0; let scanned = 0;
      try {
        for(const [k,entry] of simulationCache.entries()){
          scanned++;
          const crypto = require('crypto');
          const calc = crypto.createHash('sha256').update(JSON.stringify(entry.metrics)).digest('hex');
          if(entry.hash && entry.hash !== calc) mismatches++;
        }
      } catch(_e){ /* ignore scan failure */ }
      lines.push('# HELP seraphina_sim_cache_integrity_mismatches Number of cache entries where stored hash mismatched recomputed hash');
      lines.push('# TYPE seraphina_sim_cache_integrity_mismatches gauge');
      lines.push(`seraphina_sim_cache_integrity_mismatches ${mismatches}`);
      lines.push('# HELP seraphina_sim_cache_integrity_scanned Number of cache entries scanned for integrity this scrape');
      lines.push('# TYPE seraphina_sim_cache_integrity_scanned gauge');
      lines.push(`seraphina_sim_cache_integrity_scanned ${scanned}`);
    }
    res.end(lines.join('\n')+'\n');
  });
  metricsServer.listen(port, host);
  metricsServerInfo = { port, host, started, protocol };
  return { ok:true, ...metricsServerInfo, already:false };
}

module.exports = {
  virtueSim: {
    generateDataset: sim? sim.generate : null,
    computeMetrics: sim? sim.computeMetrics : null,
    runSimulation
  },
  causal: {
    runIV: iv? iv.runIV : null
  },
  training: {
    trainModel: trainModelWrapper
  },
  agent: {
    invoke: (role,prompt,context)=>{
      if(!agentWrapper || !agentWrapper.invokeAgent) return makeError('MODULE_UNAVAILABLE','Agent wrapper unavailable');
      // Rate limiter pre-check
  if(seraphinaAgentRateLimiter){
        const now = Date.now();
        if(seraphinaAgentRateLimiter.refillIntervalMs > 0 && (now - seraphinaAgentRateLimiter.lastRefillMs) >= seraphinaAgentRateLimiter.refillIntervalMs){
          seraphinaAgentRateLimiter.tokens = seraphinaAgentRateLimiter.capacity;
          seraphinaAgentRateLimiter.lastRefillMs = now;
        }
        if(seraphinaAgentRateLimiter.tokens <= 0){
          // Blocked by rate limiter before invoking wrapper
          if(!global.__SERAPHINA_AGENT_STATS__) global.__SERAPHINA_AGENT_STATS__ = { invocations:0, blocked:0, last:null };
            const st = global.__SERAPHINA_AGENT_STATS__;
            st.invocations++;
            st.blocked++;
            seraphinaAgentRateLimiter.blocked++;
            return { blocked:true, code:'RATE_LIMIT', note:'Agent rate limiter capacity exhausted' };
        }
      }
      const r = agentWrapper.invokeAgent(role,prompt,context);
      // Update stats & decrement tokens post-success
      if(!global.__SERAPHINA_AGENT_STATS__) global.__SERAPHINA_AGENT_STATS__ = { invocations:0, blocked:0, last:null };
      const st = global.__SERAPHINA_AGENT_STATS__;
      st.invocations++;
      Promise.resolve(r).then(resp=>{
        if(resp && resp.blocked){
          st.blocked++; // wrapper-level block (prompt shield)
        } else {
          st.last = resp;
          if(seraphinaAgentRateLimiter){
            seraphinaAgentRateLimiter.tokens = Math.max(0, seraphinaAgentRateLimiter.tokens - 1);
            seraphinaAgentRateLimiter.hits++;
          }
          if(resp && resp.note && String(resp.note).startsWith('invalid:')){
            st.invalidSuggestions = (st.invalidSuggestions||0) + 1;
          }
          // Confidence histogram update
          if(typeof resp?.confidence === 'number' && Number.isFinite(resp.confidence)){
            if(!st._confidenceBuckets){ st._confidenceBuckets = { '0.0':0,'0.1':0,'0.2':0,'0.3':0,'0.4':0,'0.5':0,'0.6':0,'0.7':0,'0.8':0,'0.9':0,'1.0':0 }; st._confidenceTotal=0; st._confidenceCount=0; }
            const c = Math.min(1, Math.max(0, resp.confidence));
            const bucketKey = (Math.floor(c*10)/10).toFixed(1);
            if(st._confidenceBuckets[bucketKey] != null){ st._confidenceBuckets[bucketKey]++; }
            st._confidenceTotal += c; st._confidenceCount++;
          }
        }
        if(!st.actions) st.actions = {};
        const act = resp && resp.action ? resp.action : 'noop';
        st.actions[act] = (st.actions[act]||0)+1;
      }).catch(()=>{});
      return r;
    }
  },
  moralGuard: {
    evaluateText: evaluateTextSafe
  },
  exporters: {
    startPrometheusExporter
  },
  autotest: {
    runAll: ()=> {
      if(!autotest || !autotest.runAllTests) return makeError('MODULE_UNAVAILABLE','Autotest module unavailable');
      return autotest.runAllTests(module.exports).then(r=>{ global.__SERAPHINA_AUTOTEST_REPORT__ = r; return r; });
    },
    start: (opts={})=>{
      if(!autotest || !autotest.startAutonomous) return makeError('MODULE_UNAVAILABLE','Autotest module unavailable');
      const res = autotest.startAutonomous(module.exports, opts);
      return res;
    },
    stop: ()=>{
      if(!autotest || !autotest.stopAutonomous) return makeError('MODULE_UNAVAILABLE','Autotest module unavailable');
      return autotest.stopAutonomous();
    },
    getLastReport: ()=> global.__SERAPHINA_AUTOTEST_REPORT__ ? JSON.parse(JSON.stringify(global.__SERAPHINA_AUTOTEST_REPORT__)) : null
  },
  meta: {
    getLatestMetrics: ()=> lastMetrics,
  getLatestTrainingScoreboard: ()=> lastTrainingScoreboard? JSON.parse(JSON.stringify(lastTrainingScoreboard)) : null,
  getAgentStats: ()=> global.__SERAPHINA_AGENT_STATS__ ? JSON.parse(JSON.stringify(global.__SERAPHINA_AGENT_STATS__)) : null,
    forceMetricsSnapshot: ()=> lastMetrics? { ok:true, ts:Date.now(), metrics: JSON.parse(JSON.stringify(lastMetrics)) } : makeError('NO_METRICS','No simulation metrics cached yet'),
  clearCache: ()=> { simulationCache.clear(); saveCache(); return { ok:true, cleared:true }; },
  getCacheStats: ()=> ({ ok:true, size: simulationCache.size, max: SIM_CACHE_MAX, persistence: cachePersistenceEnabled, path: cachePersistenceEnabled? CACHE_PERSIST_PATH : null }),
    toggleCachePersistence: (enable, pathOverride)=> { if(pathOverride){ CACHE_PERSIST_PATH = pathOverride; } cachePersistenceEnabled = !!enable; if(cachePersistenceEnabled){ loadCache(); saveCache(); }
      return { ok:true, persistence: cachePersistenceEnabled, path: CACHE_PERSIST_PATH }; },
    __test_disableSim: ()=> { if(sim && (sim.generate || sim.computeMetrics)){ sim._origGenerate = sim.generate; sim._origComputeMetrics = sim.computeMetrics; sim.generate = null; sim.computeMetrics = null; return { ok:true }; } return { ok:false, code:'ALREADY_DISABLED' }; },
    __test_restoreSim: ()=> { if(sim && sim._origGenerate){ sim.generate = sim._origGenerate; sim.computeMetrics = sim._origComputeMetrics; delete sim._origGenerate; delete sim._origComputeMetrics; return { ok:true }; } return { ok:false, code:'NO_BACKUP' }; },
  version: '0.2.4',
    apiModules: {
      simulation: !!sim,
      iv: !!iv,
      training: !!trainMod,
      moralGuard: !!guardMod
    },
    rootDir: path.resolve(__dirname),
    stopExporter: ()=> { if(metricsServer){ try { metricsServer.close(); } catch(e){ return { ok:false, code:'STOP_FAIL', message:e.message }; } metricsServer=null; metricsServerInfo=null; return { ok:true, stopped:true }; } return { ok:false, code:'NOT_RUNNING' }; }
    ,pruneCache: (maxAgeMs)=> { const cutoff = Date.now() - (maxAgeMs||0); if(!maxAgeMs || maxAgeMs<=0) return { ok:false, code:'INVALID_ARG', message:'maxAgeMs must be >0' }; let removed=0; for(const [k,v] of simulationCache.entries()){ if(v.createdTs < cutoff){ simulationCache.delete(k); removed++; } } if(removed){ cachePrunedTotal+=removed; lastPruneRemoved=removed; lastPruneTs=Date.now(); saveCache(); } return { ok:true, pruned: removed }; }
    ,warmCache: (list)=> { if(!Array.isArray(list)) return { ok:false, code:'INVALID_ARG', message:'list must be array' }; let hits=0, added=0; for(const opts of list){ const res = module.exports.virtueSim.runSimulation(opts||{}); if(res.ok){ if(res.fromCache) hits++; else added++; } } return { ok:true, hits, added }; }
    ,scanSimulationCacheIntegrity: ()=> { const crypto = require('crypto'); let mismatches=0, scanned=0; for(const [k,entry] of simulationCache.entries()){ scanned++; try { const calc = crypto.createHash('sha256').update(JSON.stringify(entry.metrics)).digest('hex'); if(entry.hash && entry.hash !== calc) mismatches++; } catch(_e){} } return { ok:true, scanned, mismatches }; }
  ,configureAgentRateLimiter: (opts={})=> { const capacity = parseInt(opts.capacity != null? opts.capacity : (process.env.SERAPHINA_AGENT_RATE_CAPACITY||'0'),10); const refillIntervalMs = parseInt(opts.refillIntervalMs != null? opts.refillIntervalMs : (process.env.SERAPHINA_AGENT_RATE_REFILL_MS||'60000'),10); if(!Number.isFinite(capacity) || capacity < 1){ seraphinaAgentRateLimiter = null; return { ok:true, disabled:true }; } seraphinaAgentRateLimiter = { capacity, tokens: capacity, refillIntervalMs: Number.isFinite(refillIntervalMs)? refillIntervalMs : 60000, lastRefillMs: Date.now(), hits:0, blocked:0 }; return { ok:true, capacity: seraphinaAgentRateLimiter.capacity, refillIntervalMs: seraphinaAgentRateLimiter.refillIntervalMs }; }
  ,__test_getCacheEntries: ()=> { const out=[]; for(const [k,v] of simulationCache.entries()){ out.push({ key:k, createdTs:v.createdTs, lastAccessTs:v.lastAccessTs, hash:v.hash }); } return { ok:true, entries: out }; }
  ,__test_corruptFirstCacheEntry: ()=> { const firstKey = simulationCache.keys().next().value; if(!firstKey) return { ok:false, code:'EMPTY' }; const entry = simulationCache.get(firstKey); if(!entry) return { ok:false, code:'NOT_FOUND' }; entry.metrics._corrupt = true; // mutate metrics
    saveCache(); return { ok:true, corrupted:firstKey }; }
  ,getAgentRateLimiterConfig: ()=> seraphinaAgentRateLimiter? { ok:true, capacity: seraphinaAgentRateLimiter.capacity, tokens: seraphinaAgentRateLimiter.tokens, refillIntervalMs: seraphinaAgentRateLimiter.refillIntervalMs, hits: seraphinaAgentRateLimiter.hits, blocked: seraphinaAgentRateLimiter.blocked } : { ok:true, disabled:true }
  }
};