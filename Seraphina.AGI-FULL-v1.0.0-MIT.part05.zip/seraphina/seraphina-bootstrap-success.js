'use strict';
// Computes bootstrap success metrics to start system with success rate rather than raw loss.
const fs = require('fs');
const { extractFeatures } = require('./seraphina-model-features');

const DATA_PATH = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
const WEIGHTS_PATH = process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json';
const OUT_PATH = process.env.SERAPHINA_BOOTSTRAP_SUCCESS || 'seraphina-bootstrap-success.json';
const SUCCESS_LEDGER = process.env.SERAPHINA_SUCCESS_RATE_LEDGER || 'seraphina-success-rate-ledger.jsonl';

function readLines(p){ if(!fs.existsSync(p)) return []; return fs.readFileSync(p,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean); }
function sigmoid(z){ return 1/(1+Math.exp(-z)); }

function compute(){
  const entries = readLines(DATA_PATH);
  if(!entries.length){ console.log('[BootstrapSuccess] No dataset entries'); return null; }
  if(!fs.existsSync(WEIGHTS_PATH)){ console.log('[BootstrapSuccess] No weights found'); return null; }
  let weights; try{ weights = JSON.parse(fs.readFileSync(WEIGHTS_PATH,'utf8')); }catch{ console.log('[BootstrapSuccess] Bad weights JSON'); return null; }
  if(!weights.headA || !weights.headB) { console.log('[BootstrapSuccess] Missing heads'); return null; }
  const { w: wA, b: bA } = weights.headA; const { w: wB, b: bB } = weights.headB;
  let correctA=0, correctB=0, total=0;
  for(const e of entries){
    const { vector } = extractFeatures(e);
    if(!vector || vector.length !== wA.length) continue;
    let zA=bA; for(let i=0;i<vector.length;i++){ zA += wA[i]*vector[i]; }
    let zB=bB; for(let i=0;i<vector.length;i++){ zB += wB[i]*vector[i]; }
    const pA=sigmoid(zA); const pB=sigmoid(zB);
    // Reconstruct labels (heuristic mirrored from train script)
    const econ = e.econSignals || {}; const decisionIntensity = vector[ vector.length-1 ];
    const frenRevenueNorm = econ.frenRevenueNorm || 0;
    // rough median approximations using thresholds (static fallback) to avoid recomputing full dataset medians twice
    const highA = decisionIntensity>0.3 && frenRevenueNorm >= 0; // median ~0 fallback
    const traits = e.personality || {}; const ethicalAlign = typeof traits.ethical_alignment==='number'? traits.ethical_alignment:0; const empathy = typeof traits.empathy==='number'? traits.empathy: ethicalAlign;
    const riskB = (ethicalAlign < 0.5 && empathy < 0.5);
    const labelA = highA?1:0; const labelB = riskB?1:0;
    if((pA>=0.5?1:0)===labelA) correctA++;
    if((pB>=0.5?1:0)===labelB) correctB++;
    total++;
  }
  const successRateA = total? correctA/total : 0;
  const successRateB = total? correctB/total : 0;
  const out = { ts:Date.now(), successRateA, successRateB, datasetSize: total, weightsVersion: weights.version };
  fs.writeFileSync(OUT_PATH, JSON.stringify(out,null,2));
  try { fs.appendFileSync(SUCCESS_LEDGER, JSON.stringify({ ts: out.ts, version: weights.version, successRate: successRateA, successRateEthical: successRateB })+'\n'); } catch(_e){}
  console.log('[BootstrapSuccess]', JSON.stringify(out));
  return out;
}

if(require.main===module){ compute(); }
module.exports = { compute };