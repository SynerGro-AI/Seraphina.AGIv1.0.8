// seraphina-coder-train.js
// Placeholder deterministic training adapter for coder triad (future expansion).
'use strict';
const fs = require('fs');
const crypto = require('crypto');

const DATA_PATH = process.env.SERAPHINA_CODER_DATASET || 'seraphina-coder-dataset.jsonl';
const OUT_WEIGHTS = process.env.SERAPHINA_CODER_WEIGHTS || 'seraphina-coder-weights.json';
const SEED = process.env.SERAPHINA_CODER_SEED || 'coder-triad-seed';

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }
function readLines(p){ if(!fs.existsSync(p)) return []; return fs.readFileSync(p,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean); }

// Dataset entry contract (example): { code:"string", label:1|0 }
// label 1 => high-quality code sample; 0 => needs improvement.

function buildDataset(){
  const entries = readLines(DATA_PATH);
  const vectors=[]; const labels=[];
  for(const e of entries){
    const code = (e.code||'');
    const lines = code.split(/\n/);
    // feature vector: [avgLen, commentDensity, todoCount, complexityTokensRatio]
    let totalLen=0, commentLines=0, todoCount=0, complexityTokens=0;
    lines.forEach(l=>{
      totalLen += l.length;
      if(/(^|\s)(\/\/|#)/.test(l)) commentLines++;
      if(/TODO|FIXME/.test(l)) todoCount++;
      complexityTokens += (l.match(/function|=>|class\s+[A-Z]/g)||[]).length;
    });
    const avgLen = lines.length? totalLen/lines.length : 0;
    const commentDensity = lines.length? commentLines/lines.length : 0;
    const complexityRatio = lines.length? complexityTokens/lines.length : 0;
    const v = [avgLen, commentDensity, todoCount, complexityRatio];
    vectors.push(v); labels.push(e.label===1?1:0);
  }
  return { X:vectors, y:labels };
}

function initWeights(dim){ const base = crypto.createHash('sha256').update(SEED).digest(); const w=[]; for(let i=0;i<dim;i++){ w.push(((base[i%base.length]/255)-0.5)*0.02); } return { w, b:0 }; }
function sigmoid(z){ return 1/(1+Math.exp(-z)); }

function train({ X, y }){
  if(!X.length) return null; const dim=X[0].length; let { w, b } = initWeights(dim); const LR=0.1; const EPOCHS=60;
  for(let epoch=0; epoch<EPOCHS; epoch++){
    let gradW=new Array(dim).fill(0), gradB=0;
    for(let i=0;i<X.length;i++){
      const xi = X[i]; const yi=y[i]; let z=b; for(let j=0;j<dim;j++){ z += w[j]*xi[j]; }
      const p=sigmoid(z); const err=p-yi; for(let j=0;j<dim;j++){ gradW[j]+=err*xi[j]; } gradB+=err;
    }
    const step=LR/X.length; for(let j=0;j<dim;j++){ w[j]-=step*gradW[j]; } b-=step*gradB;
  }
  return { w, b };
}

function main(){
  const ds=buildDataset(); const model=train(ds); if(!model){ console.error('[CoderTrain] empty dataset'); return; }
  const out={ seed:SEED, weights:model.w, bias:model.b, sampleCount:ds.X.length, featureDim: ds.X[0].length, digest:stableHash(model) };
  fs.writeFileSync(OUT_WEIGHTS, JSON.stringify(out,null,2));
  console.log('[CoderTrain] wrote', OUT_WEIGHTS, 'entries='+ds.X.length, 'digest='+out.digest);
}

if(require.main===module){ main(); }

module.exports = { buildDataset, train };
