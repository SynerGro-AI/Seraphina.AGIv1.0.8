// seraphina-coder-tier1.js
// Tier1 Syntax Analysis: deterministic lightweight parser / lint.
'use strict';
const crypto = require('crypto');

function hash(data){ return crypto.createHash('sha256').update(data).digest('hex'); }

// Simple token + structure scan (language-agnostic JS bias)
// Findings types: long_line, todo_marker, unbalanced_braces, trailing_space
function analyzeSyntax(code, opts={}){
  const lines = code.split(/\n/);
  const findings = [];
  let braceBalance=0; let curlyBalance=0; let squareBalance=0; let parenBalance=0;
  const maxLine = opts.maxLineLen || 120;
  lines.forEach((ln,i)=>{
    if(ln.length > maxLine){ findings.push({ type:'long_line', line:i+1, len:ln.length }); }
    if(/TODO|FIXME/.test(ln)){ findings.push({ type:'todo_marker', line:i+1 }); }
    if(/\s+$/.test(ln)){ findings.push({ type:'trailing_space', line:i+1 }); }
    // Rough balance tracking
    for(const ch of ln){
      if(ch==='{' ) curlyBalance++; else if(ch==='}') curlyBalance--;
      else if(ch==='(') parenBalance++; else if(ch===')') parenBalance--;
      else if(ch==='[') squareBalance++; else if(ch===']') squareBalance--;
    }
  });
  if(curlyBalance!==0){ findings.push({ type:'unbalanced_curly', delta:curlyBalance }); }
  if(parenBalance!==0){ findings.push({ type:'unbalanced_paren', delta:parenBalance }); }
  if(squareBalance!==0){ findings.push({ type:'unbalanced_square', delta:squareBalance }); }
  const digest = hash(JSON.stringify(findings));
  return { ok: findings.length===0, findings, digest, lineCount: lines.length };
}

module.exports = { analyzeSyntax };
