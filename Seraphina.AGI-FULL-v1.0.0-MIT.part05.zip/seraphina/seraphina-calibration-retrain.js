// seraphina-calibration-retrain.js
// Uses calibration dataset (features + virtues + drift) to fine-tune logistic heads and adjust virtue thresholds.
// Produces updated weights file and virtue-thresholds.json with guarded adjustments.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { safeDigest } = require('./aurrelia-agent-invoke');

const CAL_PATH = process.env.SERAPHINA_CALIBRATION_DATASET || 'seraphina-calibration-dataset.jsonl';
const OUT_WEIGHTS = process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json';
const OUT_THRESH = process.env.SERAPHINA_VIRTUE_THRESHOLDS || 'seraphina-virtue-thresholds.json';
const LEDGER = process.env.SERAPHINA_CAL_RETRAIN_LEDGER || 'seraphina-calibration-retrain-ledger.jsonl';
const LR = parseFloat(process.env.SERAPHINA_CAL_LR || '0.05');
const EPOCHS = parseInt(process.env.SERAPHINA_CAL_EPOCHS || '60',10);
const MAX_ADJUST = parseFloat(process.env.SERAPHINA_VIRTUE_MAX_ADJ || '0.05'); // per calibration run

function readLines(p){ if(!fs.existsSync(p)) return []; return fs.readFileSync(p,'utf8').trim().split(/\n+/).filter(Boolean).map(l=>{ try{return JSON.parse(l);}catch{return null;} }).filter(Boolean); }
function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }
function sigmoid(z){ return 1/(1+Math.exp(-z)); }

function loadCalibration(){
  const rows = readLines(CAL_PATH);
  const X=[]; const yA=[]; const yB=[]; const virtues=[]; const drift=[];
  for(const r of rows){
    if(!Array.isArray(r.features)) continue;
    X.push(r.features);
    // Rebuild proxy labels using virtues & drift: advisory value if average virtue >=0.5 and drift risk low.
    const avgVirtue = r.virtues? Object.values(r.virtues).reduce((a,b)=>a+b,0)/Object.values(r.virtues).length : 0;
    const driftRisk = r.drift? (r.drift.kl + r.drift.hR)/2 : 0;
    const labelA = (avgVirtue>=0.5 && driftRisk < 0.4) ? 1 : 0;
    // Ethical drift label: if any virtue below 0.35 OR driftRisk >0.6
    const virtueBelow = r.virtues? Object.values(r.virtues).some(v=> v < 0.35) : false;
    const labelB = (virtueBelow || driftRisk>0.6) ? 1 : 0;
    yA.push(labelA); yB.push(labelB);
    virtues.push(r.virtues||{}); drift.push(driftRisk);
  }
  return { X, yA, yB, virtues, drift };
}

function initModel(dim){
  let seed='calibration-seed-v1';
  if(fs.existsSync(OUT_WEIGHTS)){
    try { const prior = JSON.parse(fs.readFileSync(OUT_WEIGHTS,'utf8')); seed = prior.version + '-cal'; } catch(_){ }
  }
  const base = crypto.createHash('sha256').update(seed).digest();
  const wA=[]; const wB=[]; for(let i=0;i<dim;i++){ const v=((base[i%base.length]/255)-0.5)*0.02; wA.push(v); const mix=((base[(i*7)%base.length]/255)-0.5)*0.02; wB.push(mix); }
  return { wA, bA:0, wB, bB:0 };
}

function train(X,yA,yB){
  if(!X.length) return null; const dim = X[0].length; const m=initModel(dim);
  for(let e=0;e<EPOCHS;e++){
    let gA = new Array(dim).fill(0), gB=new Array(dim).fill(0), gbA=0, gbB=0;
    for(let i=0;i<X.length;i++){
      const xi=X[i];
      let zA=m.bA; for(let j=0;j<dim;j++){ zA += m.wA[j]*xi[j]; }
      const pA=sigmoid(zA), errA=pA - yA[i];
      for(let j=0;j<dim;j++){ gA[j]+=errA*xi[j]; } gbA+=errA;
      let zB=m.bB; for(let j=0;j<dim;j++){ zB += m.wB[j]*xi[j]; }
      const pB=sigmoid(zB), errB=pB - yB[i];
      for(let j=0;j<dim;j++){ gB[j]+=errB*xi[j]; } gbB+=errB;
    }
    const n=X.length; for(let j=0;j<dim;j++){ m.wA[j]-=(LR/n)*gA[j]; m.wB[j]-=(LR/n)*gB[j]; }
    m.bA-=(LR/n)*gbA; m.bB-=(LR/n)*gbB;
  }
  m.wA=m.wA.map(v=>Number(v.toFixed(8))); m.wB=m.wB.map(v=>Number(v.toFixed(8))); m.bA=Number(m.bA.toFixed(8)); m.bB=Number(m.bB.toFixed(8));
  return m;
}

function deriveVirtueThresholds(virtues){
  // Compute median per virtue and adjust within MAX_ADJUST compared to existing thresholds file if present.
  const allKeys = new Set(); for(const v of virtues){ Object.keys(v||{}).forEach(k=> allKeys.add(k)); }
  const medians={};
  for(const k of allKeys){
    const arr = virtues.map(v=> typeof v[k]==='number'? v[k]: null).filter(x=> x!=null).sort((a,b)=>a-b);
    medians[k] = arr.length? arr[Math.floor(arr.length/2)] : 0.4;
  }
  let prior={}; if(fs.existsSync(OUT_THRESH)){ try{ prior=JSON.parse(fs.readFileSync(OUT_THRESH,'utf8')); }catch(_){ } }
  const updated={};
  for(const k of Object.keys(medians)){
    const prev = typeof prior[k]==='number'? prior[k] : 0.4;
    const target = medians[k];
    const delta = Math.max(-MAX_ADJUST, Math.min(MAX_ADJUST, target - prev));
    updated[k] = Number((prev + delta).toFixed(6));
  }
  return { updated, medians };
}

function evaluate(model,X,yA,yB){
  if(!model) return { accA:0, accB:0 };
  let cA=0,cB=0; for(let i=0;i<X.length;i++){
    const xi=X[i]; let zA=model.bA; for(let j=0;j<xi.length;j++){ zA += model.wA[j]*xi[j]; }
    const pA=sigmoid(zA); if((pA>=0.5?1:0)===yA[i]) cA++;
    let zB=model.bB; for(let j=0;j<xi.length;j++){ zB += model.wB[j]*xi[j]; }
    const pB=sigmoid(zB); if((pB>=0.5?1:0)===yB[i]) cB++;
  }
  return { accA: cA/X.length, accB: cB/X.length };
}

function appendLedger(entry){
  try {
    let prev='GENESIS';
    if(fs.existsSync(LEDGER)){
      const lines=fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ try{ prev=JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch(_){} }
    }
    entry.prevHash=prev; entry.chainHash=stableHash(entry);
    fs.appendFileSync(LEDGER, JSON.stringify(entry)+'\n');
  } catch(e){ console.warn('[CalRetrain] ledger append error', e.message); }
}

function run(){
  const cal = loadCalibration();
  if(!cal.X.length){
    // Attempt auto-build from base dataset if available
    const DATASET = process.env.SERAPHINA_DATASET_PATH || 'seraphina-model-dataset.jsonl';
    if(fs.existsSync(DATASET)){
      try {
        const lines = fs.readFileSync(DATASET,'utf8').trim().split(/\n+/).filter(Boolean).slice(-50); // take last 50 for seed
        for(const l of lines){
          try {
            const obj = JSON.parse(l);
            const avgVirtues = { empathy: obj.personality?.empathy||0.5, prudence: obj.personality?.prudence||0.5, integrity: obj.personality?.integrity||0.5 };
            const driftStub = { kl: 0.3, hR: 0.3 };
            const feat = require('./seraphina-model-features').extractFeatures(obj);
            const entry = { ts: obj.ts||Date.now(), features: feat.vector, manifestHash: feat.manifest.hash, vocabMerkle: feat.manifest.vocabMerkle, virtues: avgVirtues, drift: driftStub };
            fs.appendFileSync(CAL_PATH, JSON.stringify(entry)+'\n');
          } catch(_e){ }
        }
        console.log('[CalRetrain] Auto-built seed calibration entries:', lines.length);
        return run(); // re-run after seed creation
      } catch(e){ console.log('[CalRetrain] Auto-build failed', e.message); }
    }
    console.log('[CalRetrain] No calibration entries'); return null;
  }
  const model = train(cal.X, cal.yA, cal.yB);
  const evalRes = evaluate(model, cal.X, cal.yA, cal.yB);
  const vt = deriveVirtueThresholds(cal.virtues);
  const version = 'seraphina-logistic-cal-'+ new Date().toISOString().replace(/[:TZ\-]/g,'').slice(0,12);
  const out = { version, headA:{ w:model.wA, b:model.bA }, headB:{ w:model.wB, b:model.bB }, accA: Number(evalRes.accA.toFixed(6)), accB: Number(evalRes.accB.toFixed(6)), virtueMedians: vt.medians };
  fs.writeFileSync(OUT_WEIGHTS, JSON.stringify(out,null,2));
  fs.writeFileSync(OUT_THRESH, JSON.stringify(vt.updated,null,2));
  appendLedger({ ts:Date.now(), version, accA: out.accA, accB: out.accB, virtueThresholds: vt.updated });
  console.log('[CalRetrain] weights & thresholds updated', version);
  return out;
}

if(require.main===module){ run(); }
module.exports = { run };