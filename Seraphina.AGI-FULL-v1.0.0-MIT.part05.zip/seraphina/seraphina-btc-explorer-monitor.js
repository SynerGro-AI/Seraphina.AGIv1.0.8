if (process.env.REAL_STRICT !== '1' && process.env.DISABLE_DOTENV !== '1') { try { require('dotenv').config(); } catch {} }
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }
/**
 * BTC Explorer Cross-Check Monitor
 * Polls broadcast txids from state and updates confirmation counts.
 */
const https=require('https');
const fs=require('fs');
const path=require('path');
const STATE_FILE=path.join(__dirname,'persistent_data','btc_transfer_state.json');
const CONF_FILE=path.join(__dirname,'persistent_data','btc_confirmations.json');
const INTERVAL_MS=parseInt(process.env.BTC_CONFIRM_POLL_MS||'180000',10);
const REORG_FILE=path.join(__dirname,'persistent_data','btc_reorg_events.json');
let lastBestHeight=null;

function loadJSON(p,def){try{return JSON.parse(fs.readFileSync(p,'utf8'))}catch{return def}}
function saveJSON(p,d){try{fs.writeFileSync(p,JSON.stringify(d,null,2))}catch{}}

function httpJson(host,pathUrl){return new Promise((res,rej)=>{const r=https.request({host,path:pathUrl,method:'GET'},m=>{let d='';m.on('data',c=>d+=c);m.on('end',()=>{try{res(JSON.parse(d))}catch(e){rej(e)}});});r.on('error',rej);r.end();});}

async function poll(){
  const st=loadJSON(STATE_FILE,{}); if(!st.lastTx||!st.lastTx.txid){setTimeout(poll,INTERVAL_MS).unref();return;}
  const txid=st.lastTx.txid; let info=null;
  try{ info=await httpJson('blockstream.info','/api/tx/'+txid); }catch{}
  if(info && info.status && info.status.confirmed){
    const tip=await httpJson('blockstream.info','/api/blocks/tip/height');
    const height= info.status.block_height; const conf = (typeof tip==='number'?tip:parseInt(tip,10)) - height + 1;
    const confState=loadJSON(CONF_FILE,{}); confState[txid]={ confirmations: conf, firstSeen: st.lastTx.broadcastAt || st.lastTx.preparedAt, lastCheck: Date.now() };
    saveJSON(CONF_FILE, confState);
    console.log('[BTC_CONFIRM]', txid, conf,'confirmations');
    try {
      const blockHash = await httpJson('blockstream.info','/api/block-height/'+height);
      if (lastBestHeight && height < lastBestHeight) {
        const reorgs=loadJSON(REORG_FILE,[]); reorgs.push({ ts:Date.now(), type:'HEIGHT_DROP', height }); saveJSON(REORG_FILE,reorgs); console.log('[BTC_REORG] Height regression detected');
      }
      lastBestHeight = Math.max(lastBestHeight||0,height);
    } catch {}
  }
  setTimeout(poll,INTERVAL_MS).unref();
}
poll();
