#!/usr/bin/env node
'use strict';
// seraphina-chain-verify.js
// Walk provenance JSONL and verify rolling chainPrev/chainDigest/chainHash/HMAC integrity.
// Usage: node seraphina-chain-verify.js --provenance=provenance-cull.jsonl [--hmacKey=secret] [--failFast]
// Exit code: 0 on success, 1 on any integrity failure.

const fs = require('fs');
const crypto = require('crypto');
function sha256(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

function parseArgs(){
  const cfg={};
  for(const a of process.argv.slice(2)){
    if(a.startsWith('--provenance=')) cfg.prov=a.split('=')[1];
    else if(a.startsWith('--hmacKey=')) cfg.hmacKey=a.split('=')[1];
    else if(a==='--failFast') cfg.failFast=true;
  }
  return cfg;
}

function readJSONL(path){
  return fs.readFileSync(path,'utf8').split(/\r?\n/).filter(Boolean).map(l=>{ try { return JSON.parse(l); } catch{ return null; } }).filter(Boolean);
}

function verifyChain(records, hmacKey, failFast){
  let prev=null; let failures=[]; let index=0; let firstHash=null;
  for(const rec of records){
    index++;
    const raw = JSON.stringify(Object.assign({}, rec, { chainPrev: undefined, chainDigest: undefined, chainHash: undefined, chainHmac: undefined }));
    const digest = sha256(raw);
    if(rec.chainDigest !== digest){ failures.push({ index, reason:'digest-mismatch', expected:digest, actual:rec.chainDigest }); if(failFast) break; }
    const expectedChainHash = sha256((prev||'') + ':' + rec.chainDigest);
    if(rec.chainHash !== expectedChainHash){ failures.push({ index, reason:'chainHash-mismatch', expected:expectedChainHash, actual:rec.chainHash }); if(failFast) break; }
    if(hmacKey){
      const expectedHmac = crypto.createHmac('sha256', hmacKey).update(rec.chainHash).digest('hex');
      if(rec.chainHmac && rec.chainHmac !== expectedHmac){ failures.push({ index, reason:'hmac-mismatch', expected:expectedHmac, actual:rec.chainHmac }); if(failFast) break; }
      if(!rec.chainHmac){ failures.push({ index, reason:'hmac-missing' }); if(failFast) break; }
    }
    if(!firstHash) firstHash = rec.chainHash;
    prev = rec.chainHash;
  }
  return { failures, total: records.length, firstHash, lastHash: prev };
}

function main(){
  const cfg = parseArgs();
  if(!cfg.prov){ console.error('Missing --provenance'); process.exit(1); }
  const recs = readJSONL(cfg.prov);
  const result = verifyChain(recs, cfg.hmacKey, cfg.failFast);
  console.log(JSON.stringify(result,null,2));
  if(result.failures.length){ process.exit(1); }
}

if(require.main === module){
  try { main(); } catch(e){ console.error('[ChainVerify][ERROR]', e); process.exit(1); }
}

module.exports = { verifyChain };
