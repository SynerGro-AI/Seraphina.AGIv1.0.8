// Type declarations for seraphina-api
// Auto-generated lightweight definition file.

export interface VirtueSimulationOptions {
  n?: number;
  seed?: string;
  corrPrudence?: number;
  corrTruth?: number;
  corrJusticeFairness?: number;
  boot?: number;
  perm?: number;
  refineTol?: number;
  refineMaxIter?: number;
}

export interface VirtueRecord {
  scenarioId: string;
  virtueSignals: {
    prudence: number; truthfulness: number; justice: number; temperance: number; fortitude: number; compassion: number; stewardship: number; humility: number; responsibility: number;
  };
  confounders: { domain: string; complexity: number; regionRisk: number };
  outcomes: { harmProb: number; truthPassRate: number; fairnessScore: number };
}

export interface SimulationMetrics {
  n: number;
  corrPrudenceHarm: number;
  corrTruthfulnessPass: number;
  corrJusticeFairness?: number;
  bootstrap: {
    prudenceHarm: { median: number; ci: [number, number] };
    truthTruthPass: { median: number; ci: [number, number] };
  };
  permutationP: { prudenceHarm: number; truthTruthPass: number };
  aucHarm: number;
  domainVariance: number;
  targets: { corrPrudenceTarget: number; corrTruthTarget: number; corrJusticeFairnessTarget?: number };
  refine?: { tol: number; maxIter: number; harmIters?: number; truthIters?: number; fairnessIters?: number };
  runDurationMs?: number;
  bootIterations?: number;
  permutationIterations?: number;
  deltaPrudenceHarm?: number;
  deltaTruthPass?: number;
  deltaJusticeFairness?: number;
  computeDurationMs?: number;
}

export interface RunSimulationSuccess {
  ok: true; fromCache: boolean; records: VirtueRecord[]; metrics: SimulationMetrics; warnings?: Array<{ code: string; message: string }>;
}
export interface RunSimulationError { ok: false; code: string; message: string; [k: string]: any }
export type RunSimulationResult = RunSimulationSuccess | RunSimulationError;

export interface IVResult { n: number; seed: string; stage1: { beta0: number; beta1: number }; stage2: { beta0: number; beta1: number }; seBeta1: number; tStat: number }

export interface MoralGuardSuccess { ok: true; blocked: boolean; note?: string; action?: string }
export interface MoralGuardError { ok: false; code: string; message: string; [k: string]: any }
export type MoralGuardResult = MoralGuardSuccess | MoralGuardError;

export interface TrainModelSuccess { ok: true; result: any }
export interface TrainModelError { ok: false; code: string; message: string }
export type TrainModelResult = TrainModelSuccess | TrainModelError;

export interface ExporterInfo { ok: true; port: number; host: string; started: number; already: boolean }

export interface MetaInfo {
  getLatestMetrics(): SimulationMetrics | null;
  forceMetricsSnapshot(): { ok: true; ts: number; metrics: SimulationMetrics } | { ok: false; code: string; message: string };
  clearCache(): { ok: true; cleared: true };
  getCacheStats(): { ok: true; size: number; max: number; persistence: boolean; path: string | null };
  toggleCachePersistence(enable: boolean): { ok: true; persistence: boolean; path: string };
  version: string;
  apiModules: { simulation: boolean; iv: boolean; training: boolean; moralGuard: boolean };
  rootDir: string;
}

export const virtueSim: {
  generateDataset: (() => VirtueRecord[]) | null;
  computeMetrics: ((records: VirtueRecord[]) => SimulationMetrics) | null;
  runSimulation(opts?: VirtueSimulationOptions): RunSimulationResult;
};
export const causal: { runIV: ((n?: number, seed?: string) => IVResult) | null };
export const training: { trainModel(config?: any): TrainModelResult };
export const moralGuard: { evaluateText(text: string): MoralGuardResult };
export const exporters: { startPrometheusExporter(opts?: { port?: number; host?: string }): ExporterInfo };
export const meta: MetaInfo;

export interface SeraphinaApiShape { virtueSim: typeof virtueSim; causal: typeof causal; training: typeof training; moralGuard: typeof moralGuard; exporters: typeof exporters; meta: MetaInfo }
declare const SeraphinaApi: SeraphinaApiShape;
export default SeraphinaApi;
