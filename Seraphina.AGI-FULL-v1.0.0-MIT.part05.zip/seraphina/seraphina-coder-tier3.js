// seraphina-coder-tier3.js
// Tier3 Mesh Registry & Link Suggestions.
'use strict';
const crypto = require('crypto');
function hash(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

class MeshRegistry {
  constructor(seed){ this.seed = seed || process.env.SERAPHINA_CODER_SEED || 'coder-mesh-seed'; this.blocks=new Map(); }
  register(id, code){
    const digest = hash(code);
    const tokens = code.split(/[^A-Za-z0-9_]+/).filter(t=>t.length>3);
    const signature = hash(tokens.slice(0,64).join('|'));
    this.blocks.set(id,{ id, digest, signature, tokenCount: tokens.length });
    return { id, digest, signature, tokenCount: tokens.length };
  }
  linkSuggestions(id){
    const base = this.blocks.get(id); if(!base) return { links:[], digest:hash(id+'|none') };
    const links=[];
    for(const [otherId, meta] of this.blocks.entries()){
      if(otherId===id) continue;
      // Similarity via shared prefix of signature digest
      const commonPrefix = sharedPrefix(base.signature, meta.signature);
      if(commonPrefix.length >= 4){
        links.push({ target: otherId, affinity: commonPrefix.length/64, note:`Shared sig prefix length ${commonPrefix.length}` });
      }
    }
    links.sort((a,b)=> b.affinity - a.affinity);
    return { links: links.slice(0,5), digest: hash(JSON.stringify(links)) };
  }
}
function sharedPrefix(a,b){ let i=0; while(i<a.length && i<b.length && a[i]===b[i]) i++; return a.slice(0,i); }

module.exports = { MeshRegistry };
