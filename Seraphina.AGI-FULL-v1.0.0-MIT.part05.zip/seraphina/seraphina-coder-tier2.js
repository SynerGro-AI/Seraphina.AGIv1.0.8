// seraphina-coder-tier2.js
// Tier2 Optimization Heuristic: deterministic quality scoring.
'use strict';
const crypto = require('crypto');
function hash(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

// Quality score factors (0..1)
// - avg line length (target <= 100)
// - comment density (lines with // or #) target >= 0.1
// - todo burden (penalty)
// - complexity proxy: count of 'function'/'=>'/class tokens vs lines
function optimizeHeuristic(code){
  const lines = code.split(/\n/);
  if(!lines.length) return { score:1, details:{ empty:true } };
  let totalLen=0; let commentLines=0; let todoCount=0; let complexityTokens=0;
  lines.forEach(l=>{
    totalLen += l.length;
    if(/(^|\s)(\/\/|#)/.test(l)) commentLines++;
    if(/TODO|FIXME/.test(l)) todoCount++;
    const tokens = (l.match(/function|=>|class\s+[A-Z]/g)||[]).length;
    complexityTokens += tokens;
  });
  const avgLen = totalLen/lines.length;
  const commentDensity = commentLines/lines.length;
  const complexityRatio = complexityTokens/lines.length; // naive
  // Score blend
  let score = 1.0;
  if(avgLen > 100) score -= Math.min(0.4, (avgLen-100)/300); // degrade up to 0.4
  if(commentDensity < 0.1) score -= 0.15;
  if(todoCount > 0) score -= Math.min(0.25, todoCount*0.05);
  if(complexityRatio > 0.3) score -= Math.min(0.2, (complexityRatio-0.3));
  if(score < 0) score = 0;
  const suggestions=[];
  if(avgLen>100) suggestions.push({ type:'line_wrap', note:`Average line length ${avgLen.toFixed(1)} > 100` });
  if(commentDensity<0.1) suggestions.push({ type:'increase_comments', note:`Comment density ${(commentDensity*100).toFixed(1)}% < 10%` });
  if(todoCount) suggestions.push({ type:'resolve_todos', count:todoCount });
  if(complexityRatio>0.3) suggestions.push({ type:'refactor_split', note:`Complexity ratio ${complexityRatio.toFixed(2)} > 0.30` });
  const digest = hash(JSON.stringify({avgLen,commentDensity,todoCount,complexityRatio,suggestions}));
  return { score, avgLen, commentDensity, todoCount, complexityRatio, suggestions, digest };
}

module.exports = { optimizeHeuristic };
