// seraphina-calibration-scheduler.js
// Periodically invokes calibration retrain with safety gating on virtue threshold deltas & accuracy stability.
'use strict';
const fs = require('fs');
const { run: calRun } = require('./seraphina-calibration-retrain');

const INTERVAL_MS = parseInt(process.env.SERAPHINA_CAL_SCHED_INTERVAL || '3600000',10); // default 1h
const THRESH_FILE = process.env.SERAPHINA_VIRTUE_THRESHOLDS || 'seraphina-virtue-thresholds.json';
const GATE_LEDGER = process.env.SERAPHINA_CAL_GATE_LEDGER || 'seraphina-calibration-gate-ledger.jsonl';
const PROMOTION_LEDGER = process.env.SERAPHINA_CAL_PROMOTION_LEDGER || 'seraphina-calibration-promotion-ledger.jsonl';
const PROMOTION_HMAC_KEY = process.env.SERAPHINA_CAL_PROMOTION_HMAC_KEY || '';
const MAX_DELTA_ACCEPT = parseFloat(process.env.SERAPHINA_CAL_GATE_MAX_DELTA || '0.06'); // absolute
const MIN_ACC_IMPROVE = parseFloat(process.env.SERAPHINA_CAL_GATE_MIN_ACC_IMPROVE || '0.0');

function readJSON(p){ try{ return JSON.parse(fs.readFileSync(p,'utf8')); }catch{ return null; } }
function append(entry){ try { fs.appendFileSync(GATE_LEDGER, JSON.stringify(entry)+'\n'); } catch(e){ /* ignore */ } }
function appendPromotion(entry){
  try {
    const crypto = require('crypto');
    const { rotateIfNeeded } = require('./ledger-rotate');
    rotateIfNeeded(PROMOTION_LEDGER, parseInt(process.env.SERAPHINA_CAL_PROMOTION_MAX || '5242880',10));
    let prev='GENESIS';
    if(fs.existsSync(PROMOTION_LEDGER)){
      const lines=fs.readFileSync(PROMOTION_LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
      if(lines.length){ try{ prev=JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; }catch(_){} }
    }
    entry.prevHash=prev; entry.chainHash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    const sigBase = entry.chainHash + ':' + (entry.version||'');
    entry.signature = PROMOTION_HMAC_KEY ? crypto.createHmac('sha256', PROMOTION_HMAC_KEY).update(sigBase).digest('hex') : crypto.createHash('sha256').update(sigBase).digest('hex');
    fs.appendFileSync(PROMOTION_LEDGER, JSON.stringify(entry)+'\n');
  } catch(e){ /* ignore */ }
}

function evaluateGate(oldThresh, newThresh, prevAccs, newAccs){
  let deltas = {}; let passed=true;
  for(const k of Object.keys(newThresh||{})){
    const prev = typeof oldThresh[k]==='number'? oldThresh[k] : 0.4;
    const nd = newThresh[k];
    const d = Math.abs(nd - prev);
    deltas[k]=Number(d.toFixed(6));
    if(d > MAX_DELTA_ACCEPT) passed=false;
  }
  const accImprove = (newAccs.accA - (prevAccs.accA||0));
  if(accImprove < MIN_ACC_IMPROVE) passed=false;
  return { passed, deltas, accImprove: Number(accImprove.toFixed(6)) };
}

async function cycle(){
  const priorThresh = readJSON(THRESH_FILE) || {};
  const priorWeights = readJSON(process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json') || { accA:0, accB:0 };
  const result = calRun();
  if(!result){ append({ ts:Date.now(), event:'skip_no_data' }); return; }
  const newThresh = readJSON(THRESH_FILE) || {};
  const gate = evaluateGate(priorThresh, newThresh, { accA: priorWeights.accA||0 }, { accA: result.accA });
  if(!gate.passed){
    // revert thresholds and weights
    append({ ts:Date.now(), event:'gate_reject', details: gate });
    // restore prior thresholds & weights
    if(Object.keys(priorThresh).length){ fs.writeFileSync(THRESH_FILE, JSON.stringify(priorThresh,null,2)); }
    if(priorWeights && priorWeights.version){ fs.writeFileSync(process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json', JSON.stringify(priorWeights,null,2)); }
  } else {
    append({ ts:Date.now(), event:'gate_accept', details: gate, version: result.version });
    appendPromotion({ ts:Date.now(), version: result.version, accA: result.accA, accB: result.accB, virtueThresholds: newThresh });
  }
}

function start(){
  console.log('[CalScheduler] Starting with interval', INTERVAL_MS);
  cycle();
  setInterval(cycle, INTERVAL_MS).unref();
}

if(require.main===module){ start(); }
module.exports = { start, evaluateGate };