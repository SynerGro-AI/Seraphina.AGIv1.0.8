'use strict';
// seraphina-code-security-heuristics.js
// Scans JS code for potential risky patterns.
// Outputs: { evalCalls, execCalls, base64LargeBlobs, entropyApprox, obfuscatedScore, findings }

function approximateEntropy(str){
  if(!str || !str.length) return 0;
  const freq = new Map();
  for(const c of str){ freq.set(c, (freq.get(c)||0)+1); }
  let H=0; const n=str.length;
  for(const [,count] of freq){ const p=count/n; H -= p*Math.log2(p); }
  return H;
}

function analyzeSecurity(code){
  const findings=[];
  const evalCalls = (code.match(/\beval\s*\(/g)||[]).length;
  if(evalCalls) findings.push('eval');
  const execCalls = (code.match(/\bchild_process\.exec\b|\bexecSync\b|\bspawn\b/g)||[]).length;
  if(execCalls) findings.push('exec');
  const base64Matches = code.match(/[A-Za-z0-9+/]{120,}={0,2}/g)||[];
  const base64LargeBlobs = base64Matches.filter(m=> m.length>200).length;
  if(base64LargeBlobs) findings.push('base64-large');
  // Obfuscation heuristic: high ratio of short var names and hex escapes
  const identMatches = code.match(/\b[a-zA-Z_$][a-zA-Z0-9_$]*\b/g)||[];
  const shortIdents = identMatches.filter(i=> i.length<=2).length;
  const hexEscapes = (code.match(/\\x[0-9A-Fa-f]{2}/g)||[]).length;
  const obfuscatedScore = shortIdents*0.5 + hexEscapes*1.5 + (base64LargeBlobs*3);
  if(obfuscatedScore>50) findings.push('obfuscation-high');
  const entropyApprox = approximateEntropy(code.slice(0, Math.min(code.length, 5000)));
  if(entropyApprox>6.5) findings.push('entropy-high');
  return { evalCalls, execCalls, base64LargeBlobs, entropyApprox:+entropyApprox.toFixed(3), obfuscatedScore, findings };
}

module.exports = { analyzeSecurity };