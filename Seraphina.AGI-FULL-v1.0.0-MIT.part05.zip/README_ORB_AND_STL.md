# Seraphina Orb Processor & STL Geometry Tools (v0.2.4)

This README documents the quantum-inspired packet processor (`lemon_orb_planck_processor.py`) and STL mesh generator (`seraphina_lemon_orb_stl.py`). These tools complement the Seraphina API facade by enabling hardware / physical artifact experimentation ("orb") with hashed packet state transformations.

## Overview
- `lemon_orb_planck_processor.py`: Simulates hybrid processing modes (planck, binary, color, octary) over packet inputs using quantum-inspired transforms (Grover-like amplification + optional Rashba term). Supports per-iteration state normalization.
- `seraphina_lemon_orb_stl.py`: Generates a simplified orb mesh (ellipsoid + spiral overlay) exported as STL for 3D printing or visualization.

## Installation
Python 3.10+ recommended.

Required packages:
```
numpy
matplotlib (optional for plotting)
numpy-stl (for STL generation)
```
Install:
```
pip install numpy matplotlib numpy-stl
```

## Orb Processor Usage
Run with default mode (planck):
```
python lemon_orb_planck_processor.py --input sample_payload.bin
```

### Modes
- `--mode=planck`: Packed float amplitude modulation.
- `--mode=binary`: Bitwise hashing & parity transforms.
- `--mode=color`: RGB channel diffusion & mix (if payload length sufficient).
- `--mode=octary`: Base-8 segmentation with rotational mixing.

### Normalization
Enable state vector normalization each iteration (stabilizes amplitude growth):
```
python lemon_orb_planck_processor.py --input sample.bin --mode=planck --normalize
```
Normalization rescales amplitude array so L2 norm == 1 after each Grover cycle.

### Key Output Metrics
Script prints JSON-like summary including:
- `fidelity`: Approximate similarity measure across transformed states.
- `mean_throb`: Aggregate amplitude fluctuation measure.
- `mode`: Processing mode.
- `iterations`: Applied Grover-like cycles.

### Example
```
python lemon_orb_planck_processor.py --input payload.bin --mode=octary --normalize --iterations=12
```

## STL Generator Usage
Generate orb mesh:
```
python seraphina_lemon_orb_stl.py --out orb_mesh.stl --radialScale=1.0 --spiralTurns=5
```
Options (if implemented in script):
- `--out`: Output STL filename.
- `--radialScale`: Ellipsoid scale factor.
- `--spiralTurns`: Spiral wrap count around orb.

The resulting STL can be loaded into slicer software (e.g., PrusaSlicer, Cura). If spiral geometry is dense, reduce turns or resolution for printability.

## Hardware Integration Notes
Future steps may stream live packet amplitude states over USB to a microcontroller driving addressable LEDs or a coil driver. Current processor outputs JSON metrics suitable for ingestion by the main Node.js facade or logging subsystem.

## Integrity & Reproducibility
- Deterministic transforms seeded by input payload hashing.
- Normalization ensures run-to-run stability when amplitude divergence could occur.

## Troubleshooting
- If `numpy-stl` import fails, ensure Microsoft Visual C++ Build Tools installed on Windows.
- Large payloads may slow processing; consider truncating or sampling input bytes.
- For color mode, payload length should be >= 3 * number of color samples derived.

## Next Enhancements
1. Live WebSocket bridge to facade for real-time visualization.
2. Adaptive iteration depth based on convergence of fidelity metric.
3. LED mapping schema export (radial amplitude -> color intensity).
4. Optional GGUF local model hinting to adjust iteration parameters.

---
Document version aligns with API facade 0.2.4 (confidence histogram + invalid ratio metrics).
