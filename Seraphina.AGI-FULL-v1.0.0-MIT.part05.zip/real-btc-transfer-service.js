/**
 * REAL BTC TRANSFER SERVICE (DAEMON)
 * ------------------------------------------------------------------
 * Watches a mining payout address and (optionally) constructs / signs
 * / broadcasts a transaction to a Kraken deposit address when the
 * confirmed balance >= threshold.
 *
 * IMPORTANT REALISM NOTICE:
 *  - This script performs REAL balance + UTXO lookups over public APIs.
 *  - It can build and SIGN a real Bitcoin transaction ONLY if you supply
 *    the private key (WIF) via environment variable MINING_WIF.
 *  - Broadcasting uses public endpoints (fallback) and may fail / rate-limit.
 *  - For PRODUCTION: run your own Bitcoin full node + use RPC (sendrawtransaction).
 *  - SECURITY: Never hardcode private keys in repo. Use env vars / secrets.
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bitcoin = require('bitcoinjs-lib');
let runProtectedAction = null;
try { ({ runProtectedAction } = require('./triad-consensus-loader')); } catch (e) { /* optional */ }
// Optional mining WebSocket broadcast (reuse if mining service running with feed)
let miningWSPort = parseInt(process.env.MINING_WS_PORT || '0',10);
let wsClient = null;
if (miningWSPort > 0) {
  try {
    const WebSocket = require('ws');
    wsClient = new WebSocket(`ws://localhost:${miningWSPort}`);
  } catch (e) { /* ignore */ }
}

// ---------------- CONFIG (ENV OVERRIDES SUPPORTED) ----------------
const MINING_ADDRESS = process.env.MINING_ADDRESS || '1QF4sh6yqZ4ZgAbTnGXRt1WwCXiVtBFddz';
const KRAKEN_DEPOSIT_ADDRESS = process.env.KRAKEN_BTC_ADDRESS || '34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf';
const MINING_WIF = process.env.MINING_WIF || null; // Provide to enable signing
const AUTO_BROADCAST = (process.env.AUTO_BROADCAST || 'false').toLowerCase() === 'true';
const FORCE_SEND = (process.env.FORCE_SEND || 'false').toLowerCase() === 'true';
const INCLUDE_UNCONFIRMED = (process.env.INCLUDE_UNCONFIRMED || 'false').toLowerCase() === 'true';
const TARGET_FEE_MODE = process.env.FEE_MODE || 'halfHour'; // fastest | halfHour | hour
const THRESHOLD_BTC = parseFloat(process.env.TRANSFER_THRESHOLD_BTC || '0.001');
const SATOSHI = 1;
const BTC = 100_000_000;
const THRESHOLD = Math.floor(THRESHOLD_BTC * BTC);
const POLL_INTERVAL_MS = parseInt(process.env.POLL_INTERVAL_MS || '60000', 10);
const MIN_CONFIRMATIONS = parseInt(process.env.MIN_CONFIRMATIONS || '1', 10);
const BTC_QUEUE_FILE = process.env.BTC_QUEUE_FILE || path.join(__dirname, 'persistent_data', 'btc_incoming_queue.json');
const QUEUE_CONSUME_INTERVAL_MS = parseInt(process.env.BTC_QUEUE_POLL_MS || '45000', 10);
const AUTO_FORCE_AFTER_QUEUE = (process.env.AUTO_FORCE_AFTER_QUEUE || 'true').toLowerCase() === 'true';

// Fallback minimum sats per vbyte if fee API fails
const DEFAULT_FEE_RATE = 12; 

const STATE_FILE = path.join(__dirname, 'persistent_data', 'btc_transfer_state.json');
const LOG_PREFIX = '[BTC-DAEMON]';
let loopActive = false;
let firstRun = true;
let queueProcessing = false;

function httpsGet(host, pathUrl, method = 'GET', body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const options = { host, path: pathUrl, method, headers: { 'User-Agent': 'SeraphinaRealMiner/1.1', ...headers } };
    const req = https.request(options, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        if ((res.statusCode || 0) >= 400) {
          return reject(new Error(`HTTP ${res.statusCode}: ${data.slice(0,120)}`));
        }
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function fetchFeeRate() {
  try {
    const json = await httpsGet('mempool.space', '/api/v1/fees/recommended');
    const map = {
      fastest: json.fastestFee,
      halfHour: json.halfHourFee,
      hour: json.hourFee
    };
    const fee = map[TARGET_FEE_MODE] || json.halfHourFee || DEFAULT_FEE_RATE;
    return fee; // sats/vByte
  } catch (e) {
    console.log(LOG_PREFIX, 'Fee API fallback -> default', e.message);
    return DEFAULT_FEE_RATE;
  }
}

async function fetchUTXOs(address) {
  // Attempt blockchain.info first
  const providers = [
    async () => {
      const urlPath = `/unspent?active=${address}`;
      const json = await httpsGet('blockchain.info', urlPath);
      return json.unspent_outputs.map(u => ({
        txid: u.tx_hash_big_endian,
        vout: u.tx_output_n,
        value: u.value,
        confirmations: u.confirmations,
        scriptPubKey: u.script
      }));
    },
    async () => { // Blockstream
      const list = await httpsGet('blockstream.info', `/api/address/${address}/utxo`);
      // Need scriptPubKey reconstruction for P2PKH
      const p2pkh = bitcoin.payments.p2pkh({ address }).output.toString('hex');
      return list.map(u => ({
        txid: u.txid,
        vout: u.vout,
        value: u.value,
        confirmations: u.status.confirmed ? (u.status.block_height || 1) : 0,
        scriptPubKey: p2pkh
      }));
    }
  ];
  for (const fn of providers) {
    try {
      const utxos = await fn();
      return utxos;
    } catch (e) {
      // Try next provider
    }
  }
  return [];
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { return { lastTx: null }; }
}
function saveState(state) {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2)); } catch {}
}

function estimateFee(numInputs, numOutputs, satPerVByte) {
  const vsize = 148 * numInputs + 34 * numOutputs + 10; // legacy P2PKH approximation
  return vsize * satPerVByte;
}

function buildAndMaybeSign(utxos, toAddress, feeRate, changeAddress = MINING_ADDRESS) {
  const network = bitcoin.networks.bitcoin;
  const totalIn = utxos.reduce((s,u)=>s + u.value, 0);
  // For simplicity: single output (sweep) minus fee (no change if below dust)
  const numInputs = utxos.length;
  const numOutputs = 1; // sweep
  const fee = estimateFee(numInputs, numOutputs, feeRate);
  const sendValue = totalIn - fee;
  if (sendValue <= 546) { // dust threshold
    throw new Error('Resulting output would be dust; aborting');
  }

  if (!MINING_WIF) {
    return {
      unsigned: true,
      inputs: utxos.map(u => ({ txid: u.txid, vout: u.vout, value: u.value })),
      to: toAddress,
      feeSats: fee,
      valueSats: sendValue,
      feeRate,
      note: 'Provide MINING_WIF env var to enable signing',
    };
  }

  const keyPair = bitcoin.ECPair.fromWIF(MINING_WIF, network);
  const psbt = new bitcoin.Psbt({ network });
  utxos.forEach(u => {
    psbt.addInput({
      hash: u.txid,
      index: u.vout,
      nonWitnessUtxo: undefined,
      // For legacy P2PKH we can use witnessUtxo alternative only if we know script & value
      witnessUtxo: {
        script: Buffer.from(u.scriptPubKey, 'hex'),
        value: u.value
      }
    });
  });
  psbt.addOutput({ address: toAddress, value: sendValue });
  psbt.signAllInputs(keyPair);
  psbt.finalizeAllInputs();
  const rawHex = psbt.extractTransaction().toHex();
  const txid = bitcoin.Transaction.fromHex(rawHex).getId();
  return {
    unsigned: false,
    rawHex,
    txid,
    inputs: utxos.length,
    feeSats: fee,
    valueSats: sendValue,
    feeRate
  };
}

async function broadcast(txHex) {
  // Try Blockstream broadcast
  try {
    const body = txHex + '\n';
    const result = await new Promise((resolve, reject) => {
      const req = https.request({ host: 'blockstream.info', path: '/api/tx', method: 'POST', headers: { 'Content-Type': 'text/plain' } }, res => {
        let data='';
        res.on('data', c=>data+=c);
        res.on('end', ()=> {
          if (res.statusCode >= 400) return reject(new Error(`Broadcast HTTP ${res.statusCode}: ${data}`));
          resolve(data.trim());
        });
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
    return { provider: 'blockstream', txid: result };
  } catch (e) {
    console.log(LOG_PREFIX, 'Primary broadcast failed:', e.message);
  }
  throw new Error('All broadcast providers failed');
}

async function mainLoop() {
  if (loopActive) return; // prevent overlapping loops if slow
  loopActive = true;
  if (firstRun) {
    console.log(`${LOG_PREFIX} Daemon started.`);
    console.log(`${LOG_PREFIX} Monitoring address: ${MINING_ADDRESS}`);
    console.log(`${LOG_PREFIX} Threshold: ${THRESHOLD_BTC} BTC | Confirmations >= ${MIN_CONFIRMATIONS}`);
    console.log(`${LOG_PREFIX} Signing: ${MINING_WIF ? 'ENABLED' : 'DISABLED (provide MINING_WIF)'} | Auto-Broadcast: ${AUTO_BROADCAST}`);
    firstRun = false;
  }
  const state = loadState();
  try {
    const utxos = await fetchUTXOs(MINING_ADDRESS);
    const confirmed = utxos.filter(u => u.confirmations >= MIN_CONFIRMATIONS);
    const pending = INCLUDE_UNCONFIRMED ? utxos.filter(u => u.confirmations === 0) : [];
    const balance = confirmed.reduce((s,u)=>s + u.value, 0);
    const pendingSum = pending.reduce((s,u)=>s + u.value, 0);
    console.log(`${LOG_PREFIX} Balance: ${(balance/ BTC).toFixed(8)} BTC (${balance} sats) | Confirmed UTXOs: ${confirmed.length}${INCLUDE_UNCONFIRMED && pending.length ? ` | Pending ${(pendingSum/ BTC).toFixed(8)} BTC (${pending.length} utxo)` : ''}`);
    if ((balance >= THRESHOLD && confirmed.length > 0) || (FORCE_SEND && confirmed.length > 0)) {
      console.log(`${LOG_PREFIX} Threshold reached. Fetching fee rate + preparing transaction...`);
      const feeRate = await fetchFeeRate();
      let txResult;
      try {
        txResult = buildAndMaybeSign(confirmed, KRAKEN_DEPOSIT_ADDRESS, feeRate);
      } catch (e) {
        console.log(LOG_PREFIX, 'Build/sign aborted:', e.message);
        return; // wait next loop
      }
      if (txResult.unsigned) {
        console.log(`${LOG_PREFIX} UNSIGNED TX READY (Provide MINING_WIF to sign automatically)`);
        console.log(`${LOG_PREFIX} Value: ${(txResult.valueSats / BTC).toFixed(8)} BTC | Fee: ${(txResult.feeSats/ BTC).toFixed(8)} BTC | Rate: ${txResult.feeRate} sat/vB`);
      } else {
        console.log(`${LOG_PREFIX} SIGNED TX: ${txResult.txid}`);
        console.log(`${LOG_PREFIX} Value: ${(txResult.valueSats / BTC).toFixed(8)} BTC | Fee: ${(txResult.feeSats/ BTC).toFixed(8)} BTC | Rate: ${txResult.feeRate} sat/vB`);
        if (AUTO_BROADCAST) {
          const attemptBroadcast = async () => {
            const br = await broadcast(txResult.rawHex);
            console.log(`${LOG_PREFIX} BROADCAST SUCCESS via ${br.provider} TXID=${br.txid}`);
            state.lastTx = { txid: br.txid, broadcastAt: new Date().toISOString(), valueBTC: txResult.valueSats / BTC, feeBTC: txResult.feeSats / BTC };
            saveState(state);
            return br;
          };
          try {
            if (runProtectedAction) {
              await runProtectedAction('btc_broadcast', { txid: txResult.txid, fee: txResult.feeSats, value: txResult.valueSats }, async () => {
                if (wsClient && wsClient.readyState === 1) {
                  try { wsClient.send(JSON.stringify({ type:'triad_decision', action:'btc_broadcast', phase:'approved', txid: txResult.txid, ts: Date.now() })); } catch {}
                }
                const r = await attemptBroadcast();
                if (wsClient && wsClient.readyState === 1) {
                  try { wsClient.send(JSON.stringify({ type:'broadcast_result', txid: r.txid, provider: r.provider, ts: Date.now() })); } catch {}
                }
                return r;
              });
            } else {
              await attemptBroadcast();
            }
          } catch (e) {
            console.log(LOG_PREFIX, 'Broadcast failed:', e.message);
            if (wsClient && wsClient.readyState === 1) {
              try { wsClient.send(JSON.stringify({ type:'triad_decision', action:'btc_broadcast', phase:'rejected', error: e.message, ts: Date.now() })); } catch {}
            }
          }
        } else {        
          state.lastTx = { txid: txResult.txid, preparedAt: new Date().toISOString(), valueBTC: txResult.valueSats / BTC, feeBTC: txResult.feeSats / BTC };
          saveState(state);
          const outPath = path.join(__dirname, 'persistent_data', 'last_signed_tx.hex');
          fs.writeFileSync(outPath, txResult.rawHex);
          console.log(`${LOG_PREFIX} Saved signed hex to ${outPath}`);
        }
      }
    }
  } catch (e) {
    console.log(LOG_PREFIX, 'Loop error:', e.message);
  } finally {
    loopActive = false;
    setTimeout(mainLoop, POLL_INTERVAL_MS);
  }
}

mainLoop();

// --------------- QUEUE CONSUMER -----------------
function loadQueue() {
  try { return JSON.parse(fs.readFileSync(BTC_QUEUE_FILE,'utf8')); } catch { return []; }
}
function saveQueue(arr) {
  try { fs.writeFileSync(BTC_QUEUE_FILE, JSON.stringify(arr,null,2)); } catch {}
}

async function processQueue() {
  if (queueProcessing) return;
  queueProcessing = true;
  try {
    let q = loadQueue();
    if (!q.length) return;
    // Filter out already processed (tag field) and items without txid still awaiting confirmations.
    const pending = [];
    const remain = [];
    for (const entry of q) {
      if (entry.processed) { remain.push(entry); continue; }
      // If txid exists, check confirmations to ensure it's safe to consolidate
      if (entry.txid) {
        try {
          const tx = await httpsGet('blockstream.info', `/api/tx/${entry.txid}`);
          if (tx && tx.status && tx.status.confirmed) {
            const tip = await httpsGet('blockstream.info', '/api/blocks/tip/height');
            const tipH = typeof tip === 'number' ? tip : parseInt(tip,10);
            const conf = tipH - tx.status.block_height + 1;
            entry.confirmations = conf;
            if (conf >= MIN_CONFIRMATIONS) {
              pending.push(entry);
              entry.processed = true;
              entry.processedAt = new Date().toISOString();
            } else {
              remain.push(entry);
            }
          } else {
            remain.push(entry); // not confirmed yet
          }
        } catch (e) {
          remain.push(entry); // keep for next cycle
        }
      } else {
        // No txid -> treat as immediate pending consolidation
        pending.push(entry);
        entry.processed = true;
        entry.processedAt = new Date().toISOString();
      }
    }
    // If we have newly eligible entries and auto force enabled, set FORCE_SEND env for one cycle
    if (pending.length && AUTO_FORCE_AFTER_QUEUE) {
      console.log(LOG_PREFIX, `Queue consolidated entries=${pending.length}. Forcing transfer check next loop.`);
      process.env.FORCE_SEND = 'true';
      setTimeout(()=>{ process.env.FORCE_SEND = 'false'; }, POLL_INTERVAL_MS + 5000);
    }
    saveQueue(q);
  } finally {
    queueProcessing = false;
  }
}

setInterval(processQueue, QUEUE_CONSUME_INTERVAL_MS);
