/**
 * RVN → BTC SWAP SERVICE (FOUNDATION)
 * ---------------------------------------------------------
 * Goal: Convert mined Ravencoin (RVN) into Bitcoin (BTC) and route BTC
 *       to your Kraken BTC address.
 *
 * This file lays the groundwork. True on-chain swaps or use of a 3rd-party
 * swap provider (ChangeNOW, SimpleSwap, SwapZone, SideShift, etc.) require
 * their APIs and (sometimes) API keys. We build an adapter pattern so you
 * can plug a real provider in without rewriting everything.
 *
 * CURRENT CAPABILITIES:
 *  - Poll RVN balance via a public explorer API (multiple fallback endpoints)
 *  - Threshold trigger for swap attempt
 *  - Provider adapter interface + a "dryRun" (paper) adapter
 *  - State persistence in persistent_data/rvn_swap_state.json
 *  - Quote acquisition + simulated rate lock (dryRun mode)
 *  - Swap lifecycle: REQUESTED → AWAIT_DEPOSIT → DEPOSIT_CONFIRMED → EXECUTED
 *  - Auto-chaining: once BTC credited (dryRun), can enqueue for BTC transfer daemon
 *
 * NEXT STEPS TO MAKE IT *REAL*:
 *  1. Select a provider that supports RVN→BTC (e.g. SimpleSwap / ChangeNOW / SwapSpace)
 *  2. Implement a real adapter (auth headers, error handling, min amounts)
 *  3. Replace dryRun earnings simulation logic with actual returned amounts
 *  4. Optionally validate deposit txid confirmation count via explorer
 *  5. Integrate success event with real-btc-transfer-service (or skip if BTC arrives directly to Kraken)
 *
 * SECURITY NOTICE:
 *  - Do NOT hardcode API keys. Use environment variables.
 *  - If using direct centralized exchange (CEX) deposit -> ensure address correctness.
 *
 * DISCLAIMER: This code does not perform a real swap yet. It creates the
 *             scaffolding to safely evolve into production.
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
let express = null; // lazy load only if dashboard enabled
// Environment audit & strict config assertion
try { require('./environment-audit').auditEnvironment(); } catch(e){ console.error('[ENV_AUDIT_FAIL]', e.message); process.exit(1); }

// ---------------- CONFIG ----------------
const CFG = {
  RVN_ADDRESS: process.env.RVN_MINING_ADDRESS || 'RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7',
  KRAKEN_BTC_ADDRESS: process.env.KRAKEN_BTC_ADDRESS || '34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf',
  SWAP_THRESHOLD_RVN: parseFloat(process.env.RVN_SWAP_THRESHOLD || '100'), // Start swap at >= RVN
  POLL_INTERVAL_MS: parseInt(process.env.RVN_POLL_MS || '60000', 10),      // 60s
  PROVIDER: process.env.SWAP_PROVIDER || 'dryRun',                         // 'dryRun' | 'simpleSwap'
  DRYRUN_RVN_BTC_RATE: parseFloat(process.env.DRYRUN_RVN_BTC_RATE || '0.00000070'), // Example pseudo-rate
  MIN_RVN: parseFloat(process.env.MIN_RVN || '10'),
  LOG_PREFIX: '[RVN-SWAP]',
  SAVE_FILE: path.join(__dirname, 'persistent_data', 'rvn_swap_state.json'),
  ENABLE_AUTO_SWAP: (process.env.ENABLE_AUTO_SWAP || 'true').toLowerCase() === 'true',
  SIMPLESWAP_API_KEY: process.env.SIMPLESWAP_API_KEY || null,
  SIMPLESWAP_MODE: (process.env.SIMPLESWAP_MODE || 'dryRunThenReal').toLowerCase(), // dryrun | real | dryrunthenreal
  SIMPLESWAP_PAIR: process.env.SIMPLESWAP_PAIR || 'rvn_btc',
  // Dashboard & Alerts
  DASHBOARD_PORT: parseInt(process.env.RVN_SWAP_PORT || '8890', 10),
  ENABLE_DASHBOARD: (process.env.ENABLE_RVN_SWAP_DASHBOARD || 'true').toLowerCase() === 'true',
  ALERT_WEBHOOK_URL: process.env.ALERT_WEBHOOK_URL || null,
  ALERT_ENABLE_BEEP: (process.env.ALERT_ENABLE_BEEP || 'true').toLowerCase() === 'true',
  // BTC confirmation tracking for executed swaps
  TRACK_BTC_CONFIRMATIONS: (process.env.TRACK_BTC_CONFIRMATIONS || 'true').toLowerCase() === 'true',
  BTC_TARGET_CONFIRMATIONS: parseInt(process.env.BTC_TARGET_CONFIRMATIONS || '2', 10),
  // BTC queue integration for transfer daemon
  BTC_QUEUE_FILE: path.join(__dirname, 'persistent_data', 'btc_incoming_queue.json'),
  // Encryption for state persistence
  SWAP_STATE_KEY: process.env.SWAP_STATE_KEY || null // 32-byte hex or base64 key
};

if (process.env.REAL_STRICT === '1' && CFG.PROVIDER === 'dryRun') {
  console.error('[RVN-SWAP] REAL_STRICT forbids dryRun provider. Configure a real swap provider before continuing.');
  process.exit(1);
}

// Extend config for new features
CFG.FORCE_RATE_LIMIT_PER_HOUR = parseInt(process.env.FORCE_RATE_LIMIT_PER_HOUR || '6',10);
CFG.EMAIL_ALERTS = (process.env.EMAIL_ALERTS || 'false').toLowerCase()==='true';
CFG.EMAIL_SMTP_HOST = process.env.EMAIL_SMTP_HOST || '';
CFG.EMAIL_SMTP_PORT = parseInt(process.env.EMAIL_SMTP_PORT || '587',10);
CFG.EMAIL_SMTP_USER = process.env.EMAIL_SMTP_USER || '';
CFG.EMAIL_SMTP_PASS = process.env.EMAIL_SMTP_PASS || '';
CFG.EMAIL_ALERT_TO = process.env.EMAIL_ALERT_TO || '';
CFG.TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || null;
CFG.TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || null;

// -------------- STATE --------------
let state = {
  lastBalance: 0,
  pendingSwap: null, // { id, status, amountRVN, expectedBTC, depositAddress, createdAt, provider }
  history: [],
  _simpleSwapDryCompleted: false,
  confirmationTracker: [], // { txid, addedAt, confirmations, target }
  lastAlert: null,
  forceTokens: null,
  lastForceRefill: null
};

state.forceTokens = state.forceTokens ?? CFG.FORCE_RATE_LIMIT_PER_HOUR;
state.lastForceRefill = state.lastForceRefill ?? Date.now();

function deriveKey() {
  if (!CFG.SWAP_STATE_KEY) return null;
  let keyStr = CFG.SWAP_STATE_KEY.trim();
  if (/^[0-9a-fA-F]{64}$/.test(keyStr)) return Buffer.from(keyStr, 'hex');
  // assume base64
  try { return Buffer.from(keyStr, 'base64'); } catch { return null; }
}
const ENC_KEY = deriveKey();

function encryptState(plain) {
  if (!ENC_KEY) return plain; // plaintext JSON
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({ iv: iv.toString('hex'), tag: tag.toString('hex'), data: enc.toString('hex'), v:1 });
}
function decryptState(raw) {
  if (!ENC_KEY) return raw;
  try {
    const obj = JSON.parse(raw);
    if (!obj.iv || !obj.tag || !obj.data) return raw;
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, Buffer.from(obj.iv,'hex'));
    decipher.setAuthTag(Buffer.from(obj.tag,'hex'));
    const dec = Buffer.concat([decipher.update(Buffer.from(obj.data,'hex')), decipher.final()]);
    return dec.toString('utf8');
  } catch { return raw; }
}

function loadState() {
  try {
    const raw = fs.readFileSync(CFG.SAVE_FILE, 'utf8');
    const plain = decryptState(raw);
    state = JSON.parse(plain);
  } catch { /* ignore */ }
}
function saveState() {
  try {
    const json = JSON.stringify(state, null, 2);
    const out = encryptState(json);
    fs.writeFileSync(CFG.SAVE_FILE, out);
  } catch {/* ignore */}
}

loadState();

// -------------- UTIL HTTP --------------
function httpsGetJson(host, pathUrl, headers = {}) {
  return new Promise((resolve, reject) => {
    const opts = { host, path: pathUrl, method: 'GET', headers: { 'User-Agent': 'Seraphina-RVNSwap/1.0', ...headers } };
    const req = https.request(opts, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        if (res.statusCode >= 400) return reject(new Error(`HTTP ${res.statusCode}: ${data.slice(0,100)}`));
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

// -------------- RVN EXPLORER BALANCE --------------
async function fetchRVNBalance(addr) {
  // Provide multiple fallback explorers (as examples; endpoints may change)
  const explorers = [
    async () => { // Ravencoin network API (placeholder example)
      const json = await httpsGetJson('api.ravencoin.org', `/addr/${addr}/balance`); // Might return raw number
      if (typeof json === 'number') return json / 1e8;
      if (json.balance) return json.balance;
      throw new Error('Unexpected format explorer1');
    },
    async () => { // 2Miners (if supported)
      const json = await httpsGetJson('rvn.2miners.com', `/api/accounts/${addr}`);
      if (json && json.stats && typeof json.stats.balance === 'number') {
        return json.stats.balance / 1e8;
      }
      throw new Error('Unexpected format explorer2');
    }
  ];
  for (const fn of explorers) {
    try {
      return await fn();
    } catch (e) {
      // Try next
    }
  }
  return 0; // Fallback if all fail
}

// Basic RVN address tx fetch (placeholder; may need adjustment for explorer format)
async function fetchRVNTransactions(addr) {
  const candidates = [
    async () => { // Example explorer (may differ in real deployment)
      // If explorer returns array of tx objects with 'txid' and 'valueIn' etc.
      const json = await httpsGetJson('api.ravencoin.org', `/addr/${addr}`); // Placeholder pattern
      if (json && json.transactions) return json.transactions; // adapt as needed
      throw new Error('Unexpected RVN tx format');
    }
  ];
  for (const fn of candidates) {
    try { return await fn(); } catch { /* try next */ }
  }
  return [];
}

// -------------- PROVIDER ADAPTER INTERFACE --------------
class SwapProvider {
  async getQuote(amountRVN) { throw new Error('Not implemented'); }
  async createSwap(amountRVN, destinationBTC) { throw new Error('Not implemented'); }
  async checkStatus(swap) { throw new Error('Not implemented'); }
}

class DryRunProvider extends SwapProvider {
  async getQuote(amountRVN) {
    const expectedBTC = amountRVN * CFG.DRYRUN_RVN_BTC_RATE;
    return { provider: 'dryRun', amountRVN, expectedBTC, rate: CFG.DRYRUN_RVN_BTC_RATE, expiresAt: Date.now() + 10*60*1000 };
  }
  async createSwap(amountRVN, destinationBTC) {
    const q = await this.getQuote(amountRVN);
    return {
      id: 'dry_' + Date.now(),
      status: 'AWAIT_DEPOSIT',
      amountRVN,
      expectedBTC: q.expectedBTC,
      rate: q.rate,
      depositAddress: CFG.RVN_ADDRESS, // In dry run we "self-deposit"
      payoutBTC: destinationBTC,
      createdAt: new Date().toISOString()
    };
  }
  async checkStatus(swap) {
    // Simulate progression after one loop
    if (swap.status === 'AWAIT_DEPOSIT') {
      // Pretend deposit confirmed
      swap.status = 'DEPOSIT_CONFIRMED';
      swap.depositTxid = 'rvn_fake_txid_' + Date.now();
    } else if (swap.status === 'DEPOSIT_CONFIRMED') {
      // Pretend executed after next loop
      swap.status = 'EXECUTED';
      swap.executionTxid = 'btc_fake_txid_' + Date.now();
      swap.executedAt = new Date().toISOString();
    }
    return swap;
  }
}

// ---------------- SIMPLESWAP PROVIDER (EXTERNAL API) ----------------
// API docs: https://simpleswap.io/api
// Endpoints used:
//  - GET /get_pairs
//  - GET /get_estimated?currency_from=rvn&currency_to=btc&amount=XXX
//  - GET /get_min?currency_from=rvn&currency_to=btc
//  - GET /create_exchange?api_key=...&currency_from=rvn&currency_to=btc&amount=...&address=DESTBTC&refund_address=RVNADDR
//  - GET /get_exchange?api_key=...&id=EXCHANGE_ID
class SimpleSwapProvider extends SwapProvider {
  constructor() {
    super();
    if (!CFG.SIMPLESWAP_API_KEY) {
      throw new Error('SimpleSwap API key missing (set SIMPLESWAP_API_KEY)');
    }
    this.apiKey = CFG.SIMPLESWAP_API_KEY;
  }

  async _get(path) {
    return httpsGetJson('api.simpleswap.io', `/v1${path}${path.includes('?') ? '&' : '?'}api_key=${this.apiKey}`);
  }

  async getMin() {
    const [from, to] = CFG.SIMPLESWAP_PAIR.split('_');
    const json = await this._get(`/get_min?currency_from=${from}&currency_to=${to}`);
    if (!json || !json.min) throw new Error('No min amount returned');
    return parseFloat(json.min);
  }

  async getQuote(amountRVN) {
    const [from, to] = CFG.SIMPLESWAP_PAIR.split('_');
    const est = await this._get(`/get_estimated?currency_from=${from}&currency_to=${to}&amount=${amountRVN}`);
    if (!est || !est.estimated_amount) throw new Error('No estimate');
    return { provider: 'simpleSwap', amountRVN, expectedBTC: parseFloat(est.estimated_amount), rate: parseFloat(est.estimated_amount / amountRVN), raw: est };
  }

  async createSwap(amountRVN, destinationBTC) {
    const [from, to] = CFG.SIMPLESWAP_PAIR.split('_');
    const json = await this._get(`/create_exchange?currency_from=${from}&currency_to=${to}&amount=${amountRVN}&address=${destinationBTC}&refund_address=${CFG.RVN_ADDRESS}`);
    if (!json || !json.id || !json.address) throw new Error('Failed to create exchange');
    return {
      id: json.id,
      status: 'AWAIT_DEPOSIT',
      amountRVN,
      rate: null,
      expectedBTC: null, // We keep prior quote if needed
      depositAddress: json.address,
      payoutBTC: destinationBTC,
      createdAt: new Date().toISOString(),
      provider: 'simpleSwap'
    };
  }

  async checkStatus(swap) {
    const json = await this._get(`/get_exchange?id=${swap.id}`);
    // json.status: waiting | confirming | exchanging | sending | finished | failed | refunded
    // map to our internal states
    if (json.status === 'waiting') {
      swap.status = 'AWAIT_DEPOSIT';
    } else if (json.status === 'confirming') {
      swap.status = 'DEPOSIT_CONFIRMED';
    } else if (json.status === 'exchanging' || json.status === 'sending') {
      swap.status = 'PROCESSING';
    } else if (json.status === 'finished') {
      swap.status = 'EXECUTED';
      swap.executionTxid = json.txid_out;
      swap.executedAt = new Date().toISOString();
      swap.expectedBTC = parseFloat(json.amount_to) || swap.expectedBTC;
    } else if (json.status === 'failed' || json.status === 'refunded') {
      swap.status = 'FAILED';
      swap.failedReason = json.status;
    }
    return swap;
  }
}

function getProvider() {
  switch (CFG.PROVIDER) {
    case 'simpleswap':
    case 'simpleSwap':
      if (CFG.SIMPLESWAP_MODE === 'dryrun') return new DryRunProvider();
      // In dryRunThenReal mode we start with dry run until first successful simulated EXECUTED
      if (CFG.SIMPLESWAP_MODE === 'dryrunthenreal') {
        if (!state._simpleSwapDryCompleted) return new DryRunProvider();
      }
      try {
        return new SimpleSwapProvider();
      } catch (e) {
        console.log(CFG.LOG_PREFIX, 'Falling back to dryRun provider:', e.message);
        return new DryRunProvider();
      }
    case 'dryRun':
    default:
      return new DryRunProvider();
  }
}

const provider = getProvider();

// -------------- SWAP LOGIC --------------
async function maybeStartSwap(currentBalance) {
  if (!CFG.ENABLE_AUTO_SWAP) return;
  if (state.pendingSwap) return; // Already in progress
  if (currentBalance < CFG.SWAP_THRESHOLD_RVN) return;
  if (currentBalance < CFG.MIN_RVN) return;

  console.log(CFG.LOG_PREFIX, `Threshold reached: ${currentBalance} RVN >= ${CFG.SWAP_THRESHOLD_RVN}. Requesting quote...`);
  try {
    const quote = await provider.getQuote(currentBalance);
    console.log(CFG.LOG_PREFIX, `Quote: ${quote.amountRVN} RVN → ${quote.expectedBTC.toFixed(8)} BTC @ rate ${quote.rate}`);
    const swap = await provider.createSwap(currentBalance, CFG.KRAKEN_BTC_ADDRESS);
    state.pendingSwap = swap;
    saveState();
    console.log(CFG.LOG_PREFIX, `Swap created id=${swap.id} status=${swap.status}`);
  } catch (e) {
    console.log(CFG.LOG_PREFIX, 'Quote/swap failed:', e.message);
  }
}

async function updateSwapLifecycle() {
  if (!state.pendingSwap) return;
  try {
    state.pendingSwap = await provider.checkStatus(state.pendingSwap);
    // Extra RVN deposit detection (guard): if provider still shows waiting but we see an inbound tx
    if (state.pendingSwap && state.pendingSwap.status === 'AWAIT_DEPOSIT' && state.pendingSwap.depositAddress) {
      try {
        const txs = await fetchRVNTransactions(state.pendingSwap.depositAddress);
        if (txs && txs.length) {
          // Mark as deposit detected (soft flag) - provider will later move to confirming
          state.pendingSwap.localDepositDetected = true;
        }
      } catch { /* ignore */ }
    }
    console.log(CFG.LOG_PREFIX, `Swap ${state.pendingSwap.id} → ${state.pendingSwap.status}`);
    if (state.pendingSwap.status === 'EXECUTED') {
      state.history.push(state.pendingSwap);
      // Optionally: Integrate with BTC transfer aggregator here.
      console.log(CFG.LOG_PREFIX, `EXECUTED: Credited ~${(state.pendingSwap.expectedBTC||0).toFixed(8)} BTC (provider=${state.pendingSwap.provider||'n/a'})`);
      if (CFG.PROVIDER.toLowerCase().includes('simple') && CFG.SIMPLESWAP_MODE === 'dryrunthenreal' && !state._simpleSwapDryCompleted && state.pendingSwap.provider !== 'simpleSwap') {
        state._simpleSwapDryCompleted = true;
        console.log(CFG.LOG_PREFIX, 'Dry-run complete. Next swap will use REAL SimpleSwap API.');
      }
      // Alert
      triggerAlert('SWAP_EXECUTED', state.pendingSwap);
      // BTC confirmation tracking enqueue if txid known
      if (CFG.TRACK_BTC_CONFIRMATIONS && state.pendingSwap.executionTxid) {
        state.confirmationTracker.push({
          txid: state.pendingSwap.executionTxid,
          addedAt: new Date().toISOString(),
          confirmations: 0,
          target: CFG.BTC_TARGET_CONFIRMATIONS
        });
      }
      // Queue integration
      if (state.pendingSwap.expectedBTC) {
        enqueueBTCIncoming({
          source: 'rvn_swap',
          txid: state.pendingSwap.executionTxid || null,
            amountBTC: state.pendingSwap.expectedBTC,
            creditedAt: new Date().toISOString()
        });
      }
      state.pendingSwap = null;
    }
    saveState();
  } catch (e) {
    console.log(CFG.LOG_PREFIX, 'Swap status check failed:', e.message);
  }
}

// ------------ BTC CONFIRMATION TRACKER -------------
async function pollBTCConfirmations() {
  if (!CFG.TRACK_BTC_CONFIRMATIONS) return;
  if (!state.confirmationTracker.length) return;
  try {
    // Get tip height once
    const tip = await httpsGetJson('blockstream.info', '/api/blocks/tip/height');
    // tip is number or parse
    const tipHeight = typeof tip === 'number' ? tip : parseInt(tip,10);
    for (const entry of state.confirmationTracker) {
      if (entry.confirmations >= entry.target) continue;
      try {
        const tx = await httpsGetJson('blockstream.info', `/api/tx/${entry.txid}`);
        if (tx && tx.status && tx.status.confirmed) {
          const conf = tipHeight - tx.status.block_height + 1;
          entry.confirmations = conf;
          if (conf >= entry.target) {
            entry.metAt = new Date().toISOString();
            triggerAlert('BTC_CONFIRMED', { txid: entry.txid, confirmations: conf });
          }
        }
      } catch (e) { /* ignore individual errors */ }
    }
    saveState();
  } catch (e) {
    // ignore
  }
}

setInterval(pollBTCConfirmations, 45_000);

// ------------ ALERTING -------------
function triggerAlert(type, payload) {
  const stamp = new Date().toISOString();
  state.lastAlert = { type, payload, at: stamp };
  saveState();
  if (CFG.ALERT_ENABLE_BEEP) process.stdout.write('\x07');
  if (CFG.ALERT_WEBHOOK_URL) {
    try { sendWebhook(type, payload); } catch {/* ignore */}
  }
  if (CFG.EMAIL_ALERTS) { try { sendEmail(type, payload); } catch {/* ignore */} }
  if (CFG.TELEGRAM_BOT_TOKEN && CFG.TELEGRAM_CHAT_ID) { try { sendTelegram(type, payload); } catch {/* ignore */} }
  console.log(CFG.LOG_PREFIX, `ALERT ${type}`, JSON.stringify(payload||{}, null, 0));
}

function sendWebhook(eventType, payload) {
  try {
    const url = new URL(CFG.ALERT_WEBHOOK_URL);
    const body = JSON.stringify({ event: eventType, payload, ts: Date.now() });
    const opts = { method: 'POST', host: url.hostname, path: url.pathname + (url.search||''), headers: { 'Content-Type': 'application/json','Content-Length': Buffer.byteLength(body) } };
    const req = https.request(opts, res => { res.on('data',()=>{}); });
    req.on('error', ()=>{});
    req.write(body);
    req.end();
  } catch (e) { /* ignore */ }
}

function sendEmail(eventType, payload) {
  if (!CFG.EMAIL_ALERTS || !CFG.EMAIL_SMTP_HOST || !CFG.EMAIL_ALERT_TO) return;
  try {
    const nodemailer = require('nodemailer');
    const transport = nodemailer.createTransport({
      host: CFG.EMAIL_SMTP_HOST,
      port: CFG.EMAIL_SMTP_PORT,
      secure: CFG.EMAIL_SMTP_PORT === 465,
      auth: CFG.EMAIL_SMTP_USER ? { user: CFG.EMAIL_SMTP_USER, pass: CFG.EMAIL_SMTP_PASS } : undefined
    });
    transport.sendMail({
      from: CFG.EMAIL_SMTP_USER || 'seraphina@localhost',
      to: CFG.EMAIL_ALERT_TO,
      subject: `[RVN-SWAP ALERT] ${eventType}`,
      text: JSON.stringify(payload,null,2)
    }, ()=>{});
  } catch {/* ignore */}
}

function sendTelegram(eventType, payload) {
  if (!CFG.TELEGRAM_BOT_TOKEN || !CFG.TELEGRAM_CHAT_ID) return;
  try {
    const body = JSON.stringify({ chat_id: CFG.TELEGRAM_CHAT_ID, text: `[RVN-SWAP] ${eventType}\n${JSON.stringify(payload,null,2)}` });
    const url = new URL(`https://api.telegram.org/bot${CFG.TELEGRAM_BOT_TOKEN}/sendMessage`);
    const opts = { method:'POST', host:url.hostname, path:url.pathname+url.search, headers:{'Content-Type':'application/json','Content-Length': Buffer.byteLength(body)} };
    const req = https.request(opts, res=>{ res.on('data',()=>{}); });
    req.on('error',()=>{}); req.write(body); req.end();
  } catch {/* ignore */}
}

// ------------ BTC QUEUE INTEGRATION -------------
function enqueueBTCIncoming(entry) {
  try {
    let arr = [];
    if (fs.existsSync(CFG.BTC_QUEUE_FILE)) {
      try { arr = JSON.parse(fs.readFileSync(CFG.BTC_QUEUE_FILE,'utf8')); } catch { arr = []; }
    }
    arr.push(entry);
    fs.writeFileSync(CFG.BTC_QUEUE_FILE, JSON.stringify(arr,null,2));
  } catch {/* ignore */}
}

// ------------ MANUAL FORCE SWAP -------------
async function forceSwap(amount) {
  const now = Date.now();
  if (now - state.lastForceRefill > 3600000) { // refill hourly
    state.forceTokens = CFG.FORCE_RATE_LIMIT_PER_HOUR;
    state.lastForceRefill = now;
  }
  if (state.forceTokens <= 0) return { ok:false, reason:'rate_limit_exceeded', remaining:0 };
  if (state.pendingSwap) return { ok:false, reason:'swap_in_progress' };
  try {
    const quote = await provider.getQuote(amount);
    const swap = await provider.createSwap(amount, CFG.KRAKEN_BTC_ADDRESS);
    state.pendingSwap = swap;
    state.forceTokens -= 1;
    saveState();
    return { ok:true, swap, quote, remaining: state.forceTokens };
  } catch (e) { return { ok:false, error:e.message }; }
}

// ------------ DASHBOARD (HTTP API) -------------
function startDashboard() {
  if (!CFG.ENABLE_DASHBOARD) return;
  try { express = require('express'); } catch (e) { console.log(CFG.LOG_PREFIX,'Express not installed'); return; }
  const app = express();
  app.use(express.json());
  app.get('/api/swap/status', (req,res)=>{
    res.json({
      balance: state.lastBalance,
      pending: state.pendingSwap,
      history: state.history.slice(-25),
      confirmations: state.confirmationTracker,
      lastAlert: state.lastAlert,
      mode: CFG.SIMPLESWAP_MODE,
      provider: CFG.PROVIDER
    });
  });
  app.post('/api/swap/force', async (req,res)=>{
    const amount = Number((req.body && req.body.amount) || req.query.amount);
    if (!amount || amount <= 0) return res.status(400).json({ ok:false, error:'invalid_amount'});
    const r = await forceSwap(amount);
    res.json(r);
  });
  app.get('/swap-dashboard', (req,res)=>{
    res.setHeader('Content-Type','text/html');
    res.end(`<!DOCTYPE html><html><head><title>RVN→BTC Swap Dashboard</title><style>body{background:#0b0f17;color:#d8e9ff;font-family:Arial;padding:20px}h1{color:#5cc4ff}pre{background:#111;padding:10px;border-radius:8px;max-height:300px;overflow:auto}button{background:#1d88ff;color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;margin:5px}button:hover{background:#146ed1}</style></head><body><h1>RVN→BTC Swap Dashboard</h1><div id='live'></div><div><h3>Force Swap</h3><input id='amt' placeholder='Amount RVN' style='padding:6px;'/> <button onclick='force()'>Force</button></div><script>async function refresh(){const r=await fetch('/api/swap/status');const j=await r.json();document.getElementById('live').innerHTML='<h3>Status</h3><pre>'+JSON.stringify(j,null,2)+'</pre>';}async function force(){const a=document.getElementById('amt').value;await fetch('/api/swap/force',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:Number(a)})});refresh();}setInterval(refresh,5000);refresh();</script></body></html>`);
  });
  app.listen(CFG.DASHBOARD_PORT, ()=>{
    console.log(CFG.LOG_PREFIX, `Dashboard listening http://localhost:${CFG.DASHBOARD_PORT}/swap-dashboard`);
  });
}

startDashboard();

// -------------- MAIN LOOP --------------
async function loop() {
  try {
    const bal = await fetchRVNBalance(CFG.RVN_ADDRESS);
    state.lastBalance = bal;
    console.log(CFG.LOG_PREFIX, `RVN Balance: ${bal} (threshold=${CFG.SWAP_THRESHOLD_RVN}) provider=${CFG.PROVIDER}`);
    await maybeStartSwap(bal);
    await updateSwapLifecycle();
  } catch (e) {
    console.log(CFG.LOG_PREFIX, 'Loop error:', e.message);
  }
  setTimeout(loop, CFG.POLL_INTERVAL_MS);
}

console.log(CFG.LOG_PREFIX, 'RVN→BTC Swap Service Initializing...');
console.log(CFG.LOG_PREFIX, `Address: ${CFG.RVN_ADDRESS}`);
console.log(CFG.LOG_PREFIX, `Auto-Swap: ${CFG.ENABLE_AUTO_SWAP} | Provider: ${CFG.PROVIDER}`);
console.log(CFG.LOG_PREFIX, `Dashboard: ${CFG.ENABLE_DASHBOARD ? 'ON':'OFF'} Port ${CFG.DASHBOARD_PORT}`);
if (ENC_KEY) console.log(CFG.LOG_PREFIX, 'State Encryption: ENABLED');
loop();
