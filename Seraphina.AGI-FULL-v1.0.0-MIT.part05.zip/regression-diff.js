'use strict';
// regression-diff.js – compares last N effective improvements vs baseline captured at escalation.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const SUMMARY_LEDGER = path.join(__dirname,'ai-learning-summary-ledger.jsonl');
const BASELINE_FILE = path.join(__dirname,'regression-baseline.json');
const DIFF_LEDGER = path.join(__dirname,'regression-diff-ledger.jsonl');
function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }
function loadBaseline(){ if(!fs.existsSync(BASELINE_FILE)) return null; try { return JSON.parse(fs.readFileSync(BASELINE_FILE,'utf8')); } catch(_){ return null; } }
function loadRecent(n){ if(!fs.existsSync(SUMMARY_LEDGER)) return []; const lines = fs.readFileSync(SUMMARY_LEDGER,'utf8').trim().split(/\n+/).slice(-n); return lines.map(l=>{ try{return JSON.parse(l);}catch(_){return null;} }).filter(Boolean); }
function appendDiff(entry){ try { fs.appendFileSync(DIFF_LEDGER, JSON.stringify(entry)+'\n'); } catch(_){ } }
function computeDiff(){
  const windowSize = parseInt(process.env.REGRESSION_WINDOW_SIZE||'10',10);
  const baseline = loadBaseline();
  const recent = loadRecent(windowSize);
  if(!baseline || !recent.length) return null;
  const effs = recent.map(r=> r.improvement?.effectiveImprovement||0);
  const avgEff = effs.reduce((a,b)=>a+b,0)/effs.length;
  const diff = avgEff - (baseline.effectiveImprovement||0);
  const pct = (baseline.effectiveImprovement||0) === 0 ? 0 : diff / baseline.effectiveImprovement;
  const entry = { t:Date.now(), windowSize, avgEff:Number(avgEff.toFixed(6)), baselineEff: baseline.effectiveImprovement, diff:Number(diff.toFixed(6)), pct:Number(pct.toFixed(6)), baselineHash: sha256(baseline) };
  appendDiff(entry);
  return entry;
}
if(require.main === module){ const res = computeDiff(); process.stdout.write(JSON.stringify(res,null,2)+'\n'); }
module.exports = { computeDiff };