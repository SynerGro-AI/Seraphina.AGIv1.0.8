'use strict';
// refactor-name-sample.js
// Deterministic replacement of a given name token (e.g., Eli -> Julian) across a target text file.
// Usage (PowerShell): node refactor-name-sample.js input=synergy_soulblock_sample.txt from=Eli to=Julian
// Writes updated content back and emits a JSON summary.

const fs = require('fs');
const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(typeof x==='string'? x: JSON.stringify(x)).digest('hex'); }

function parseArgs(){
  const args = process.argv.slice(2);
  const kv = {};
  args.forEach(a=>{
    const [k,v] = a.split('=');
    if(k && typeof v !== 'undefined') kv[k]=v;
  });
  return kv;
}

function main(){
  const { input, from, to } = parseArgs();
  if(!input || !from || typeof to === 'undefined'){
    process.stdout.write(JSON.stringify({ error:'missing-args', required:['input','from','to'] })+'\n');
    process.exit(1);
  }
  if(!fs.existsSync(input)){
    process.stdout.write(JSON.stringify({ error:'file-not-found', input })+'\n');
    process.exit(1);
  }
  const original = fs.readFileSync(input,'utf8');
  const originalHash = sha256(original);
  // Replace exact token only (case-sensitive whole word via regex with word boundaries)
  const pattern = new RegExp(`\\b${from}\\b`,'g');
  const updated = original.replace(pattern, to);
  const updatedHash = sha256(updated);
  if(updated !== original){
    fs.writeFileSync(input, updated);
  }
  process.stdout.write(JSON.stringify({ input, from, to, changed: updated!==original, originalHash, updatedHash })+'\n');
}

if(require.main === module){ main(); }
