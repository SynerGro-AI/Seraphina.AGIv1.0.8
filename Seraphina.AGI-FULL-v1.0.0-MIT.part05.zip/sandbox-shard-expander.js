// sandbox-shard-expander.js
// Deterministic shard expansion utility: forks new knowledge shards when thresholds exceeded.
// Criteria (env configurable):
//  SHARD_EXPAND_NOVELTY_MIN (default 0.5)
//  SHARD_EXPAND_INTEGRATION_MIN (default 0.15)
// Adds new shard entries to knowledge-shards.json with derived conceptVector.

'use strict';
const fs = require('fs');
const crypto = require('crypto');

const SHARDS_PATH = process.env.KNOWLEDGE_SHARDS_PATH || 'knowledge-shards.json';
const NOVELTY_MIN = parseFloat(process.env.SHARD_EXPAND_NOVELTY_MIN || '0.5');
const INTEGRATION_MIN = parseFloat(process.env.SHARD_EXPAND_INTEGRATION_MIN || '0.15');

function sha256(x){return crypto.createHash('sha256').update(x).digest('hex');}

function load(){ if(!fs.existsSync(SHARDS_PATH)) return []; return JSON.parse(fs.readFileSync(SHARDS_PATH,'utf8')); }
function save(shards){ fs.writeFileSync(SHARDS_PATH, JSON.stringify(shards,null,2)); }

function deriveConceptVector(parent){
  // Deterministic perturbation using hash of parent id
  const h = sha256(parent.id);
  const bytes = Buffer.from(h,'hex');
  const out=[]; for(let i=0;i<5;i++){ out.push(Number(((bytes[i]/255)*0.6 + parent.conceptVector[i]*0.4).toFixed(6))); }
  return out;
}

function maybeExpand(shards){
  // Compute simple synthetic metrics: novelty as count of unique domains / shardCount, integration as average length of coreFacts root overlap.
  const domains = new Set(shards.map(s=>s.domain));
  const novelty = domains.size / Math.max(1, shards.length);
  // Approx integration: ratio of shared fact roots across domains
  const domainRoots = {};
  for(const s of shards){
    const roots = new Set();
    for(const f of s.coreFacts||[]){ roots.add(f.split('_')[0]); }
    domainRoots[s.domain] = roots;
  }
  let overlapSum=0, pairs=0; const doms=Array.from(domains);
  for(let i=0;i<doms.length;i++){
    for(let j=i+1;j<doms.length;j++){
      pairs++; const a=domainRoots[doms[i]], b=domainRoots[doms[j]]; let ov=0; for(const r of a){ if(b.has(r)) ov++; }
      const denom = Math.max(1, Math.min(a.size,b.size));
      overlapSum += ov/denom;
    }
  }
  const integration = pairs? overlapSum/pairs : 0;
  if(novelty >= NOVELTY_MIN || integration >= INTEGRATION_MIN){
    // Fork last shard deterministically
    const parent = shards[shards.length-1];
    const newId = parent.id+'-fork-'+shards.length;
    const newShard = {
      id: newId,
      domain: parent.domain,
      tags: parent.tags.concat(['fork']),
      coreFacts: parent.coreFacts.map(f=> f+'f'),
      conceptVector: deriveConceptVector(parent)
    };
    shards.push(newShard);
    return { expanded:true, newShard, novelty, integration };
  }
  return { expanded:false, novelty, integration };
}

function main(){
  const shards = load();
  const res = maybeExpand(shards);
  if(res.expanded){ save(shards); }
  process.stdout.write(JSON.stringify(res,null,2)+'\n');
}

if(require.main === module){ main(); }

module.exports = { maybeExpand };
