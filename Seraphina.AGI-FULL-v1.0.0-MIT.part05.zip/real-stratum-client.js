/**
 * REAL STRATUM CLIENT (BTC / RVN SCAFFOLD)
 * --------------------------------------------------------------
 * Provides a foundational Stratum protocol client capable of:
 *  - Connecting to a mining pool (stratum+tcp)
 *  - Subscribing (mining.subscribe)
 *  - Authorizing (mining.authorize)
 *  - Receiving jobs (mining.notify)
 *  - Submitting externally-produced shares (mining.submit)
 *
 * NOTE: This module does NOT implement actual hashing (Proof-of-Work) –
 * heavy hashing must be performed by dedicated mining hardware/software.
 * You can plug an external hasher that consumes the job objects emitted
 * here and POSTs candidate share solutions back into the mining service.
 *
 * Environment Variables (per instance or global overrides):
 *  STRATUM_WORKER=<username.worker>
 *  STRATUM_PASSWORD=<worker_password_or_x>
 *  STRATUM_DEBUG=1 (verbose logging)
 *
 * Events Emitted:
 *  'connected'        -> ({pool})
 *  'subscribed'       -> (subscriptionData)
 *  'authorized'       -> ({worker})
 *  'job'              -> (jobObject)
 *  'shareAccepted'    -> ({jobId, result})
 *  'shareRejected'    -> ({jobId, error})
 *  'error'            -> (err)
 *  'closed'           -> ()
 */

const net = require('net');
const EventEmitter = require('events');
const crypto = require('crypto');
const { kawpowSeedForEpoch } = (()=>{ try { return require('./kawpow-validator'); } catch { return {}; } })();

class RealStratumClient extends EventEmitter {
  constructor(options) {
    super();
    this.host = options.host; // e.g. stratum.antpool.com
    this.port = options.port; // numeric
    this.coin = options.coin; // 'BTC' | 'RVN'
    this.worker = options.worker || process.env.STRATUM_WORKER || 'example.worker';
    this.password = options.password || process.env.STRATUM_PASSWORD || 'x';
    this.socket = null;
    this.jobCounter = 0;
    this.currentJobs = new Map(); // jobId -> job object
    this.subscriptionDetails = null;
    this.extranonce1 = null;
    this.extranonce2Size = null;
    this.debug = !!process.env.STRATUM_DEBUG;
    this._reauthInFlight = null;
  }

  log(...a) { if (this.debug) console.log('[STRATUM]', ...a); }

  connect() {
    return new Promise((resolve, reject) => {
      this.socket = net.createConnection(this.port, this.host);
      this.socket.setKeepAlive(true);
      this.socket.on('connect', () => {
        this.log('Connected', this.host + ':' + this.port);
        this.emit('connected', { pool: this.host, port: this.port, coin: this.coin });
        // Send subscribe
        this.send({ id: 1, method: 'mining.subscribe', params: [ 'Seraphina-Client', null ]});
      });
      this.socket.on('data', d => this._onData(d));
      this.socket.on('error', e => { this.emit('error', e); reject(e); });
      this.socket.on('close', () => this.emit('closed'));
      // Resolve after first connect
      this.once('authorized', () => resolve());
      // Timeout safety
      setTimeout(()=>reject(new Error('Stratum connect timeout')), 20000).unref();
    });
  }

  send(obj) {
    try {
      if (!this.socket || this.socket.destroyed) return;
      const line = JSON.stringify(obj) + '\n';
      if (!this.socket.writable) return;
      this.socket.write(line);
      this.log('>>', line.trim());
    } catch (e) { this.emit('error', e); }
  }

  _onData(buffer) {
    const lines = buffer.toString().split('\n').filter(Boolean);
    for (const line of lines) {
      let msg;
      try { msg = JSON.parse(line); } catch { continue; }
      this.log('<<', line.trim());
      // Emit raw message for consumers (e.g. re-auth promise listeners)
      this.emit('_raw', msg);
      // Handle subscription response
      if (msg.id === 1 && msg.result && Array.isArray(msg.result)) {
        this.subscriptionDetails = msg.result;
        // Common structure: [subscription details, extranonce1, extranonce2_size]
        this.extranonce1 = msg.result[1];
        this.extranonce2Size = msg.result[2];
        this.emit('subscribed', { extranonce1: this.extranonce1, extranonce2Size: this.extranonce2Size });
        // Authorize
        this.send({ id: 2, method: 'mining.authorize', params: [ this.worker, this.password ]});
      }
      if (msg.id === 2 && (msg.result === true)) {
        this.emit('authorized', { worker: this.worker });
      }
      if (msg.id === 2 && msg.error){
        // Authorization failed – typical structure: [code, message, null]
        const errMsg = Array.isArray(msg.error) ? msg.error.join('|') : JSON.stringify(msg.error);
        console.error('[Stratum][AuthorizeError]', errMsg);
        this.emit('error', new Error('AUTHORIZE_FAILED:'+errMsg));
      }
      // Notifications
      if (msg.method === 'mining.notify') {
        const job = this._parseJob(msg.params);
        if (job) {
          this.currentJobs.set(job.jobId, job);
          this.emit('job', job);
        }
      }
      if (msg.method === 'mining.set_difficulty') {
        try {
          const diffVal = Array.isArray(msg.params) ? parseFloat(msg.params[0]) : parseFloat(msg.params);
          if (!isNaN(diffVal)) {
            this.emit('difficulty', { coin: this.coin, difficulty: diffVal });
          }
        } catch(_){ /* ignore parse errors */ }
      }
      // Share submission result
      if (msg.id && msg.result && msg.id.toString().startsWith('share_')) {
        const jobId = msg.id.replace('share_', '');
        this.emit('shareAccepted', { jobId, result: msg.result });
      }
      if (msg.id && msg.error && msg.id.toString().startsWith('share_')) {
        const jobId = msg.id.replace('share_', '');
        this.emit('shareRejected', { jobId, error: msg.error });
      }
    }
  }

  _parseJob(params) {
    // BTC typical params: [ job_id, prevhash, coinb1, coinb2, merkle_branch[], version, nbits, ntime, clean_jobs ]
    // RVN (KawPow) differs; treat generically and pass through.
    if (!params || params.length < 5) return null;
    const jobId = params[0];
    const job = {
      coin: this.coin,
      jobId,
      raw: params,
      prevhash: params[1],
      part1: params[2],
      part2: params[3],
      merkleBranches: Array.isArray(params[4]) ? params[4] : [],
      version: params[5],
      nbits: params[6],
      ntime: params[7],
      clean: params[8]
    };
    // RVN seed/header enrichment (scaffold):
  if (this.coin === 'RVN') {
      // Some pools append height; attempt to locate plausible height (uint32) in trailing params.
      for (let i = params.length - 1; i >= 0; i--) {
        const cand = parseInt(params[i], 10);
        if (!isNaN(cand) && cand > 0 && cand < 100000000) { job.height = cand; break; }
      }
      const epoch = job.height != null ? Math.floor(job.height / 7500) : 0;
      if (typeof kawpowSeedForEpoch === 'function') job.seedHash = kawpowSeedForEpoch(epoch);
      const headerPre = [job.version||'', job.prevhash, job.nbits||'', job.ntime||''].join('');
      job.headerHash = crypto.createHash('sha256').update(headerPre).digest('hex');
    }
    return job;
  }

  submitShare({ jobId, extranonce2, ntime, nonce, mixHash, headerHex }) {
    if (!this.currentJobs.has(jobId)) {
      return { ok: false, error: 'UNKNOWN_JOB' };
    }
    // ID namespaced for mapping acceptance results
    const submitId = 'share_' + jobId + '_' + Date.now();
    // Standard RVN share submit: [ worker, jobId, extranonce2, ntime, nonce ]
    const params = [ this.worker, jobId, extranonce2, ntime, nonce ];
    // Some pools (debug / custom) might allow extended diagnostics; append mixHash/header if configured
    if (process.env.STRATUM_EXTENDED_SUBMIT==='1'){
      if (mixHash) params.push(mixHash);
      if (headerHex) params.push(headerHex);
    }
    this.send({ id: submitId, method: 'mining.submit', params });
    return { ok: true, submitId };
  }

  // Attempt graceful worker change without reconnect (if pool allows multiple authorize calls)
  async setWorker(newWorker, password){
    if (!newWorker || newWorker === this.worker) return false;
    if (this._reauthInFlight) return this._reauthInFlight;
    this.worker = newWorker;
    if (password) this.password = password;
  const { deriveInt } = require('./deterministic-util');
  const authId = 2000 + deriveInt('auth-id', 1000000, user, password, Date.now());
    const p = new Promise((resolve,reject)=>{
      const to = setTimeout(()=>{ cleanup(); reject(new Error('reauth-timeout')); }, 8000).unref();
      const onRaw = (m)=>{
        if (m.id === authId && m.result === true){ cleanup(); resolve(true); }
        if (m.id === authId && m.error){ cleanup(); reject(new Error('reauth-failed')); }
      };
      const onErr = (e)=>{ cleanup(); reject(e); };
      const cleanup = ()=>{ this.removeListener('_raw', onRaw); this.removeListener('error', onErr); clearTimeout(to); this._reauthInFlight=null; };
      this.on('_raw', onRaw); this.on('error', onErr);
    });
    this._reauthInFlight = p;
    try { this.send({ id: authId, method: 'mining.authorize', params:[ this.worker, this.password ]}); } catch(e){ }
    return p;
  }

  close(){
    try {
      if (this.socket){
        this.socket.end();
        this.socket.destroy();
      }
    } catch(_){}
    this.socket = null;
  }
}

module.exports = { RealStratumClient };