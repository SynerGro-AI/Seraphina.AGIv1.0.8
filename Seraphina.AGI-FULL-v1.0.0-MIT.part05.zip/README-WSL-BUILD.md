# WSL Build Guide (OctaLang + Kernel Helper)

## Overview
This guide explains how to perform a safe hybrid OctaLang bridge + kernel build inside WSL (Ubuntu) without hitting NTFS permission issues (e.g., tar extract failures under /mnt/c).

## Prerequisites
1. Install WSL (Ubuntu recommended):
```powershell
wsl --install -d Ubuntu
```
2. Reboot if prompted.
3. Launch Ubuntu from Start Menu and create your user.
4. Update packages:
```bash
sudo apt-get update -y && sudo apt-get upgrade -y
```
5. Optional (OctaLang expansion): Install Node.js and Python if missing (the helper script will auto-install Node if absent).

## Helper Script
`wsl-build-kernel.sh` performs:
- Workdir creation (default `$HOME/octalang-build`).
- OctaLang bridge build (multi-language hashing + η boost metrics).
- Placeholder kernel build (fast/full pending script enhancement).
- Report validation.

## Usage
From repo root inside WSL:
```bash
chmod +x wsl-build-kernel.sh
./wsl-build-kernel.sh --fast --workdir "$HOME/seraphina-octalang" --octalang
```
Flags:
- `--fast` : Skip full kernel build steps (placeholder now).
- `--workdir <path>` : Override build directory (must be inside WSL filesystem for proper permissions).
- `--no-octalang` : Skip OctaLang bridge.
- `--no-validate` : Skip report validation.

## Expected Output
- `octalang-build-report.json` with fields: `etaBoost`, `sampleHashes[]`, `agent` object, `phiSeed`.
- Console logs showing η boost and drift (PHI seeded).

## Troubleshooting
| Symptom | Cause | Fix |
|---------|-------|-----|
| `command not found: node` | Node.js missing | Let script install or run manual NodeSource setup. |
| Validation error (etaBoost range) | Uninitialized prompt or corrupted report | Re-run bridge or delete report before retry. |
| Permission errors under /mnt/c | NTFS metadata restrictions | Choose a workdir under `$HOME` (default). |
| Python stub failure | Python not installed | `sudo apt-get install -y python3` |

## Roadmap Enhancements
- Integrate `build-baremetal.sh --fast --octalang` logic (coming next).
- Artifact archiving (bzImage, initramfs) into `dist/`.
- Optional Prometheus metrics emission for WSL builds.

## PowerShell Wrapper (Windows Host)
Create a simple wrapper to invoke WSL build from Windows. Use the built-in Windows PowerShell (`powershell`) unless you have PowerShell 7 (`pwsh`) installed.
```powershell
# Build-Baremetal-WSL.ps1 (draft)
param(
  [switch]$Fast,
  [string]$Workdir = "$env:USERPROFILE\octalang-wsl",
  [switch]$NoOctaLang,
  [switch]$NoValidate
)
$fastFlag = if($Fast){ '--fast' } else { '' }
$octaFlag = if($NoOctaLang){ '--no-octalang' } else { '--octalang' }
$valFlag = if($NoValidate){ '--no-validate' } else { '' }
wsl bash -c "cd '$($env:USERPROFILE)'/OneDrive/AppData/Documents/mining && ./wsl-build-kernel.sh $fastFlag --workdir '$Workdir' $octaFlag $valFlag"
```
Usage (Windows PowerShell 5.1):
```powershell
powershell -File .\Build-Baremetal-WSL.ps1 -Fast -Workdir "$env:USERPROFILE\seraphina-wsl"
```
Or if PowerShell 7+ (`pwsh`) is installed:
```powershell
pwsh -File .\Build-Baremetal-WSL.ps1 -Fast -Workdir "$env:USERPROFILE\seraphina-wsl"
```
If script execution is blocked, set execution policy for current user:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

## Verification Steps
```bash
cat "$HOME/seraphina-octalang/octalang-build-report.json" | jq '.etaBoost'
```
Ensure value lies in `[1.0, 1.15]`.

---
Maintains deterministic hashing & PHI-seeded drift metrics while avoiding Windows NTFS extraction pitfalls.
