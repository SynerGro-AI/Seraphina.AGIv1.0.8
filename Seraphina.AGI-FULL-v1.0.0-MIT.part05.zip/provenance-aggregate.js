// provenance-aggregate.js
// Aggregates optimization score trends from provenance JSONL
const fs = require('fs');
const path = require('path');

function aggregate(file){
  const lines = fs.readFileSync(file,'utf8').trim().split(/\r?\n/).filter(Boolean);
  let count=0, sum=0, min=Infinity, max=-Infinity;
  for(const l of lines){
    try { const o = JSON.parse(l); if(typeof o.optScore === 'number'){ sum += o.optScore; count++; if(o.optScore < min) min=o.optScore; if(o.optScore > max) max=o.optScore; } } catch(_e){ }
  }
  if(count===0) return { count:0 };
  return { count, avg: +(sum/count).toFixed(4), min:+min.toFixed(4), max:+max.toFixed(4) };
}

function main(){
  const file = process.argv[2] || process.env.SERAPHINA_CODER_PROVENANCE_PATH || 'seraphina-coder-provenance.jsonl';
  if(!fs.existsSync(file)){ console.error('[ERR] provenance file missing', file); process.exit(1); }
  const stats = aggregate(file);
  console.log('[ProvenanceStats]', JSON.stringify({ file, ...stats }));
}

if(require.main === module){ main(); }