// rvn-deterministic-address.js
// Deterministically derive a Ravencoin P2PKH-style address from a seed and index.
// Ravencoin version byte: 0x3c (decimal 60) leading to 'R' base58 prefix typically.
// Usage:
//   node rvn-deterministic-address.js seedString 0
// Environment alternative:
//   RVN_DET_SEED, RVN_DET_INDEX
// Produces JSON: { address, wif }
// WARNING: This is for controlled deterministic testing. Do NOT use generated WIF for mainnet funds.

const crypto = require('crypto');

const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const b58Map = new Map(base58Alphabet.split('').map((c,i)=>[i,c]));
function base58Encode(buf){
  let x = BigInt('0x'+buf.toString('hex'));
  const base = BigInt(58);
  let out = '';
  while(x>0){ const mod = x % base; out = b58Map.get(Number(mod)) + out; x = x / base; }
  // Preserve leading zeros -> '1'
  for (const b of buf){ if (b===0) out = '1'+out; else break; }
  return out || '1';
}
function sha256(b){ return crypto.createHash('sha256').update(b).digest(); }
function ripemd160(b){ return crypto.createHash('ripemd160').update(b).digest(); }

function derive(seed, index){
  const idxBuf = Buffer.alloc(4); idxBuf.writeUInt32BE(index); 
  const keyMaterial = sha256(Buffer.concat([Buffer.from(seed), idxBuf]));
  const privKey = sha256(Buffer.concat([keyMaterial, Buffer.from('rvn-priv')])); // 32 bytes
  const pubKey = crypto.createHash('sha256').update(Buffer.concat([Buffer.from('rvn-pub'), privKey])).digest(); // pseudo pub (not real EC)
  const pubKeyHash = ripemd160(pubKey); // 20 bytes
  const version = Buffer.from([0x3c]);
  const payload = Buffer.concat([version, pubKeyHash]);
  const checksum = sha256(sha256(payload)).subarray(0,4);
  const full = Buffer.concat([payload, checksum]);
  const address = base58Encode(full);
  // WIF (append 0x01 for compressed flag)
  const wifPayload = Buffer.concat([Buffer.from([0x80]), privKey, Buffer.from([0x01])]);
  const wifChecksum = sha256(sha256(wifPayload)).subarray(0,4);
  const wif = base58Encode(Buffer.concat([wifPayload, wifChecksum]));
  return { address, wif };
}

const seed = process.argv[2] || process.env.RVN_DET_SEED || 'aurrelia-rvn-seed';
const index = parseInt(process.argv[3] || process.env.RVN_DET_INDEX || '0',10);
const result = derive(seed, index);
console.log(JSON.stringify(result, null, 2));
