// sbom-generate.js
// Deterministic SBOM generator for Aurrelia miner runtime.
// Enumerates a curated set of source/runtime files, computes SHA256, size, and classification.
// Output: sbom.json with schema { version, generatedTs, files:[{path,sha256,bytes,type}], aggregateSha256 }
// Determinism: ordering is lexical; hashing excludes timestamps; aggregateSha256 is sha256 of concatenated per-file records.
// Environment overrides:
//   SBOM_EXTRA    Comma-separated additional file globs (exact filenames) to include
//   SBOM_OUT      Output path (default sbom.json)
//   SBOM_STRICT=1 Fail if any curated file missing
//   SBOM_SHOW=1   Print JSON to stdout even if file written
//   SBOM_MAX_BYTES  Skip hashing files larger than this (still records size) (default 5_000_000)
//   SBOM_INCLUDE_NODE=1 Include minimal package.json + lock if present
//
// Usage:
//   node sbom-generate.js
//   SBOM_EXTRA="custom-config.json" node sbom-generate.js
//
// Note: For broad manifests use generate-source-manifest.js; SBOM focuses on security-critical & deterministic modules.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256File(p){
  try {
    const data = fs.readFileSync(p);
    return crypto.createHash('sha256').update(data).digest('hex');
  } catch(e){ return null; }
}

function classify(p){
  const ext = path.extname(p).toLowerCase();
  if (ext === '.js') return 'script';
  if (ext === '.json') return 'data';
  if (ext === '.ps1' || ext === '.sh') return 'script';
  if (ext === '.md') return 'doc';
  return 'other';
}

const curated = [
  'aurrelia-pico-mesh-miner.js',
  'final-mining-test.js',
  'system-repro-test.js',
  'system-repro-verify.js',
  'deterministic-ai-core.js',
  'advanced-language-engine.js',
  'verify-rvn-address.js',
  'verify-fren-address.js',
  'verify-btc-address.js',
  'build-production-iso.ps1',
  'ci-deterministic-build.ps1',
  'coin-config.js',
  'seraphina-wallet-companion.js',
  'companion-policy-engine.js',
  'aurrelia-trading-engine.js',
  'README_METRICS.md',
  'PRODUCTION-ISO.md'
  ,'TRADING-ENGINE.md'
  ,'ADAPTIVE-ROADMAP.md'
  ,'GOVERNANCE-ENGINE.md'
  ,'ML-ADVISOR.md'
  ,'governance-engine.js'
  ,'deterministic-ml-advisor.js'
];

if (process.env.SBOM_INCLUDE_NODE === '1'){
  curated.push('package.json');
  if (fs.existsSync(path.join(process.cwd(),'package-lock.json'))) curated.push('package-lock.json');
}

const extra = (process.env.SBOM_EXTRA||'').split(',').map(s=>s.trim()).filter(Boolean);
extra.forEach(e=> curated.push(e));

const unique = Array.from(new Set(curated));
unique.sort((a,b)=> a.localeCompare(b));

const maxBytes = parseInt(process.env.SBOM_MAX_BYTES || '5000000',10);

const files = [];
let missing = [];
for (const rel of unique){
  const abs = path.join(process.cwd(), rel);
  if (!fs.existsSync(abs)){ missing.push(rel); if (process.env.SBOM_STRICT==='1') continue; else continue; }
  const st = fs.statSync(abs);
  let hash = null;
  if (st.size <= maxBytes){ hash = sha256File(abs); }
  files.push({ path: rel, sha256: hash, bytes: st.size, type: classify(rel) });
}
if (process.env.SBOM_STRICT==='1' && missing.length){
  console.error('[SBOM] Missing required files under strict mode:', missing.join(','));
  process.exit(2);
}
// Aggregate hash: concatenation of 'path|sha256|bytes|type\n'
const concat = files.map(f=> `${f.path}|${f.sha256||'NA'}|${f.bytes}|${f.type}\n`).join('');
const aggregateSha256 = crypto.createHash('sha256').update(concat).digest('hex');

const out = {
  version: 'aurrelia-sbom-v1',
  generatedTs: new Date().toISOString(),
  root: path.resolve('.'),
  fileCount: files.length,
  files,
  aggregateSha256,
  missing: missing.length? missing : undefined
};

const outPath = process.env.SBOM_OUT || 'sbom.json';
try { fs.writeFileSync(outPath, JSON.stringify(out, null, 2)); console.log('[SBOM] wrote', outPath, 'files=', files.length, 'aggregateSha256=', aggregateSha256); } catch(e){ console.error('[SBOM] write failed', e.message); process.exit(3); }
if (process.env.SBOM_SHOW === '1'){ console.log(JSON.stringify(out, null, 2)); }
