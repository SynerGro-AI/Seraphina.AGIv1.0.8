# Aurrelia KawPow Python Prototype

This prototype (`aurrelia_kawpow.py`) introduces a Python path for real KawPow hashing (RVN / FREN) using the `kawpow` package.

## Features
- Deterministic octonion math similar to JS miner.
- Real KawPow hashing when `kawpow` package installed (falls back to double SHA256 if missing).
- Simplified mock job loop (replace with stratum integration).
- Adjustable environment variables: `GLOBAL_OCTO_SEED`, `GLOBAL_BURROW_DEPTH`, `GLOBAL_PRUNE_THRESHOLD`, `MULTI_HARMONIC`, `PLANE_AGG_MODE`, `PLANE_WEIGHTED`.

## Install
```powershell
pip install -r requirements.txt
```

## Run
```powershell
python aurrelia_kawpow.py --coin rvn
```
(Use environment variables for tuning; script currently ignores CLI args except via env.)

## Next Steps
- Integrate real stratum (RVN / FREN) via `aiohttp` TCP stream.
- Implement epoch height + seed capture; pass real height/seed to `kawpow_hash`.
- Add share submission and target verification in little-endian form.
- Port advanced metrics & economic scoring.

## Integrity
This path is separate from JS miner. Keep STRICT_INTEGRITY=1 on JS side for production until Python path fully validated.
