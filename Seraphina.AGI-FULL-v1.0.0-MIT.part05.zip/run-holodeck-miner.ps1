<#
Holodeck DNS + Miner Launcher
Sets deterministic holodeck DNS environment and runs aurrelia-pico-mesh-miner.js.
Adjust maps / poison / rate limits as desired for scenario tests.
#>
param(
  [string]$Coin = 'rvn',
  [string]$User = $env:F2POOL_USER,
  [string]$Worker = $env:F2POOL_WORKER,
  [switch]$Tail,
  [switch]$Real,
  [string]$MapFile = 'holo-config/dns-map.json',
  [string]$PoisonMap = '{"*.malware":"<IP>"}',
  [double]$PoisonRate = 0.25,
  [int]$RateLimit = 150,
  [int]$RateWindowMs = 1000,
  [string]$AmpProfile = '{"default":64,"large":512,"dnssec":1024}',
  [string]$AmpMap = '{"*.big":"large","secure.example":"dnssec"}',
  [int]$TraceMax = 300
)

function Info($m){ $ts=(Get-Date).ToString('HH:mm:ss'); Write-Host "[$ts] $m" }

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Error 'Node.js not in PATH'; exit 1 }
if (-not $User) {
  if ($Real) {
    Write-Error 'F2POOL_USER env or -User required when -Real specified'; exit 1
  } else {
    $User = 'demoacct' # Fallback to demo account if no user is provided
    Info 'No -User provided; using sandbox demoacct'
  }
}
if (-not $Worker) { $Worker = '001' }

# Core Holodeck enable
$env:HOLODECK_ENABLE='1'
$env:HOLODECK_DNS_ENABLE='1'
$env:HOLODECK_ROOT='F:/'

# DNS maps (inline + external file override if exists)
$env:HOLODECK_DNS_MAP='{"pool.raven.f2pool.com":"<IP>","*.fast":"<IP>"}'
$env:HOLODECK_DNS_LATENCY_MAP='{"*.fast":5,"*.slow":180}'
$env:HOLODECK_DNS_TTL_MAP='{"*.fast":5000,"pool.raven.f2pool.com":30000}'
$env:HOLODECK_DNS_NEG_TTL='4000'

if (Test-Path (Join-Path $env:HOLODECK_ROOT $MapFile)) {
  $env:HOLODECK_DNS_MAP_FILE=$MapFile
  Info "Using external DNS map file: $MapFile"
} else {
  Info "External DNS map file not found (relative): $MapFile"
}

# Attack simulation controls
$env:HOLODECK_DNS_POISON_MAP=$PoisonMap
$env:HOLODECK_DNS_POISON_RATE=[string]$PoisonRate
$env:HOLODECK_DNS_POISON_HEAL_TTL='60000'
$env:HOLODECK_DNS_RATE_LIMIT=[string]$RateLimit
$env:HOLODECK_DNS_RATE_WINDOW_MS=[string]$RateWindowMs
$env:HOLODECK_DNS_AMP_PROFILE=$AmpProfile
$env:HOLODECK_DNS_AMP_MAP=$AmpMap
$env:HOLODECK_DNS_TRACE_MAX=[string]$TraceMax
$env:HOLODECK_DNS_LOG='1'
 # Write stats / trace snapshots every interval (10s default logging window) to JSON for external inspection
 $env:HOLODECK_DNS_STATS_FILE='holo-dns-stats.json'
 $env:HOLODECK_DNS_TRACE_FILE='holo-dns-trace.json'

# Miner coin + credentials
$env:AUR_COIN=$Coin.ToLower()
$env:F2POOL_USER=$User
$env:F2POOL_WORKER=$Worker
if (-not $env:F2POOL_PASSWORD -or $env:F2POOL_PASSWORD -eq '') { $env:F2POOL_PASSWORD = 'x' }
if ($Real) { $env:REAL_MINING_ENFORCED='1' }

# Metrics (optional)
$env:METRICS='1'
$env:METRICS_INTERVAL='10000'

Info "Launching miner (coin=$Coin user=$User worker=$Worker real=$([bool]$Real))"
Info "DNS poisonRate=$PoisonRate poisonMap=$PoisonMap rateLimit=$RateLimit rateWindowMs=$RateWindowMs ampProfile=$AmpProfile ampMap=$AmpMap traceMax=$TraceMax"
Info "DNS Poison rate=$PoisonRate map=$PoisonMap"
Info "DNS RateLimit=$RateLimit windowMs=$RateWindowMs"
Info "DNS AmpProfile=$AmpProfile"

$proc = Start-Process -FilePath node -ArgumentList 'aurrelia-pico-mesh-miner.js' -PassThru -RedirectStandardOutput output.tmp -RedirectStandardError error.tmp

# After 10s, snapshot DNS stats & tail last lines to verify activity
Start-Job -ScriptBlock {
  Start-Sleep -Seconds 10
  if (Test-Path 'holo-dns-stats.json') {
    $stats = Get-Content 'holo-dns-stats.json' -Raw | ConvertFrom-Json -ErrorAction SilentlyContinue
    if ($stats) { Write-Host "[HolodeckDNS][Snapshot10s] lookups=$($stats.lookups) mapped=$($stats.mapped) synth=$($stats.synthesized) fail=$($stats.failed) poisoned=$($stats.poisoned) rateLimited=$($stats.rateLimited) ampLarge=$($stats.ampLarge)" }
  }
  if (Test-Path 'holo-dns-trace.json') {
    try { $trace = Get-Content 'holo-dns-trace.json' -Raw | ConvertFrom-Json } catch {}
    if ($trace) {
      $last = $trace | Select-Object -Last 5
      Write-Host '[HolodeckDNS][LastEvents]' ($last | ConvertTo-Json -Compress)
    }
  }
} | Out-Null

# After 10s, dump holo DNS stats snapshot (requires process global access via another PowerShell instance)
Start-Job -ScriptBlock {
  Start-Sleep -Seconds 10
  $statsLine = (Get-Content output.tmp | Select-String -Pattern '\[HoloDNS\]\[Stats\]' | Select-Object -Last 1)
  if ($statsLine) { Write-Host "[Snapshot] $($statsLine.Line)" } else { Write-Host '[Snapshot] No stats line yet (maybe low DNS activity)' }
} | Out-Null

if ($Tail) {
  Info 'Tailing output (Ctrl+C to stop)'
  while (-not $proc.HasExited) {
    if (Test-Path output.tmp) { Get-Content output.tmp -Wait }
    Start-Sleep -Seconds 1
  }
} else {
  $proc.WaitForExit()
  Get-Content output.tmp | Select-Object -Last 50 | ForEach-Object { Write-Host $_ }
}

Info "Exit code: $($proc.ExitCode)"
