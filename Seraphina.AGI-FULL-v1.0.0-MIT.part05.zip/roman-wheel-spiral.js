// Roman Wheel Octagonal Spiral Sphere Mining Optimizer (Deterministic Version)
// All stochastic behavior removed. Perturbations derive deterministically from SHA-256 hashing of inputs.
// Author: SynerGroAI / Wilson of Orange (refactored for zero-random integrity compliance)

const crypto = require('crypto');
const TWO_PI = Math.PI * 2;

function octagonalSpiral(rMax = 1, numTurns = 3, numPoints = 100) {
    const theta = Array.from({ length: numPoints }, (_, i) => 0.01 + i * (TWO_PI * numTurns) / (numPoints - 1));
    const r = Array.from({ length: numPoints }, (_, i) => 0.01 + i * (rMax - 0.01) / (numPoints - 1));
    return theta.map((t, i) => {
        const rOct = r[i] * (Math.cos(8 * t) + 1.5) / 2.5;
        return [rOct * Math.cos(t), rOct * Math.sin(t)];
    });
}

function romanWheelSphere({ numPlanes = 6, rSphere = 1, protrude = 0.1, numTurns = 3, numPoints = 100 } = {}) {
    const phi = Array.from({ length: numPlanes }, (_, i) => Math.acos(2 * i / (numPlanes - 1) - 1));
    const theta = Array.from({ length: numPlanes }, (_, i) => TWO_PI * i / numPlanes);
    const normals = phi.map((p, i) => [
        Math.sin(p) * Math.cos(theta[i]),
        Math.sin(p) * Math.sin(theta[i]),
        Math.cos(p)
    ]);
    const points = [];
    for (const normal of normals) {
        const spiral2D = octagonalSpiral(1, numTurns, numPoints);
        let u = cross(normal, [0, 0, 1]);
        if (Math.abs(normal[2]) > 0.999) u = cross(normal, [1, 0, 0]);
        u = normalize(u);
        let v = cross(normal, u);
        v = normalize(v);
        for (const [x, y] of spiral2D) {
            const pt = [
                x * u[0] + y * v[0],
                x * u[1] + y * v[1],
                x * u[2] + y * v[2]
            ];
            let norm = Math.hypot(...pt);
            if (norm < 1e-10) norm = 1e-10;
            let spherePt = pt.map(c => rSphere * c / norm);
            if (protrude > 0) {
                spherePt = spherePt.map((c, i) => c + protrude * normal[i]);
            }
            points.push(spherePt);
        }
    }
    return points;
}

function cross(a, b) {
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    ];
}

function normalize(v) {
    const n = Math.hypot(...v);
    return n < 1e-10 ? [0, 0, 0] : v.map(x => x / n);
}

// Deterministic Multibrot-style gating. No randomness.
// seed: optional external string to influence deterministic perturbations.
function optimizeMining(points, numShares = 10, order = 2, maxIter = 50, seed = 'default') {
    const cBase = [-0.745, 0.113, 0];
    let accepted = 0;
    const sampleCount = Math.min(10, points.length);

    for (let s = 0; s < numShares; s++) {
        // Derive deterministic perturbation vector from hash(seed + share_index)
        const hash = crypto.createHash('sha256').update(seed + ':' + s + ':' + cBase.join(',')).digest();
        const pert = cBase.map((v, idx) => {
            const byte = hash[idx]; // 0..255
            const centered = (byte / 255) - 0.5; // -0.5..0.5
            return v + centered * 0.02; // scale to prior ±0.01 range
        });

        let boundedCount = 0;
        for (let i = 0; i < sampleCount; i++) {
            let z = points[i].slice();
            let escaped = false;
            for (let it = 0; it < maxIter; it++) {
                const norm = Math.hypot(...z);
                if (norm > 2) { escaped = true; break; }
                z = z.map((zi, idx) => {
                    const mag = Math.pow(Math.abs(zi), order);
                    return (zi < 0 ? -mag : mag) + pert[idx % 3];
                });
            }
            if (!escaped) boundedCount++;
        }
        if (boundedCount >= 7) accepted++;
    }
    return accepted / numShares;
}

module.exports = { octagonalSpiral, romanWheelSphere, optimizeMining };
