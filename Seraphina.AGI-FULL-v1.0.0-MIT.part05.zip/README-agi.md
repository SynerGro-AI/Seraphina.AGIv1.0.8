# Seraphina AGI Self-Optimizer

The AGI self-optimizer module (`agi-self-optimizer.js`) introduces a controlled, deterministic path for exploratory tuning ("forks") based on an intrigue metric derived from the retention oracle.

## Goals
- Provide bounded autonomous experimentation (frequency & molecular boost suggestions).
- Preserve determinism (SHA256 seed + intrigue metric hashing).
- Protect system stability (sanitization, size caps, no execution of remote payloads).

## Core Concepts
- Intrigue Metric: Sanitized predicted retention in [0,1]. Forks occur only if value and hashed gate both exceed threshold.
- Deterministic Fork: `shouldFork()` mixes seed + metric and compares hashed byte against `AGI_INTRIGUE_THRESH`.
- Molecular Boost: Simple proportional boost model (`genBoost = retention * 0.04`).
- USB Benchmark: Measures write/read MB/s using a capped buffer size.

## Environment Variables
- `AGI_INTRIGUE_THRESH` (default 0.5) – Fork threshold.
- `AGI_USB_BENCH_MB` (default 64) – Max benchmark size in MB (safety; prevents large memory spikes).
- `AGI_PULSE_BASE` (default 17) – Baseline pulse frequency.
- `AGI_PULSE_DELTA` (default 2) – Frequency increment when intrigue above 0.6.
- `AGI_LEDGER_PATH` (default `quantum-rites-ledger.jsonl`).

## Safety Measures
- Sanitization of predicted retention: Non-finite values replaced by fallback.
- Frequency bounds: [1,255] enforced during pulse emission.
- Benchmark cap: Limits throughput test to manageable size.
- Chain Hashing: Ledger entries include `prevHash` and SHA256 digest.
- No Dynamic Execution: All oracle-derived values treated as advisory only.

## Usage
```powershell
# Run optimizer with mock cube (development)
node agi-self-optimizer.js

# With real cube object (in conductor integration)
node start-agi-opt
```

## Ledger Format
Each line: JSON object `{ ts, intrigue, tunedHz, genBoost, prevHash, chainHash }`.

## Extensibility Ideas
- Multi-Objective Fork Logic (Pareto) for balancing novelty vs efficiency.
- Adaptive benchmark size based on available RAM / time budget.
- Structured response schema validation for oracle predictions.
- Prometheus metrics: intrigue histogram, fork count gauge.

## Test Harness
`test-agi-self-optimizer.js` simulates a cube device and confirms ledger creation and fork logic under default thresholds.

## Determinism Notes
Fork decision uses metric value’s fixed decimal precision (toFixed(6)) before hashing, ensuring repeatability across runs given identical oracle response and seed.

---
Document version: 2025-10-26
