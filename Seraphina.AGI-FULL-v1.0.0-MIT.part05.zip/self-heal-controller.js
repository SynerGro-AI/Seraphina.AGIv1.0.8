#!/usr/bin/env node
// Self-heal controller: detect integrity drift and regenerate manifests (advisory only)
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256(x){ return crypto.createHash('sha256').update(x).digest('hex'); }

function loadJSON(f){ try { return JSON.parse(fs.readFileSync(f,'utf8')); } catch { return null; } }

function fileHash(f){ try { return sha256(fs.readFileSync(f)); } catch { return null; } }

function regenMinimal(){
  try { require('./generate-minimal-runtime-manifest.js'); } catch(e){ console.error('[self-heal] minimal manifest regen failed', e.message); }
}
function regenProvenance(){
  try { require('./generate-provenance.js'); } catch(e){ console.error('[self-heal] provenance regen failed', e.message); }
}

function merkle(leaves){
  if(!leaves || !leaves.length) return null;
  let layer = leaves.slice();
  while(layer.length>1){
    const next=[];
    for(let i=0;i<layer.length;i+=2){
      const left = layer[i];
      const right = layer[i+1] || left; // duplicate last if odd count
      next.push(sha256(left+right));
    }
    layer = next;
  }
  return layer[0];
}

function detectDrift(){
  const provenance = loadJSON(path.join(__dirname,'provenance.json'));
  const minimal = loadJSON(path.join(__dirname,'minimal-runtime-manifest.json'));
  const issues=[];
  if(minimal){
    const recomputed = merkle(minimal.artifacts.map(a=>a.sha256));
    if(recomputed !== minimal.merkleRoot){ issues.push('minimalMerkleRoot recompute mismatch'); }
    if(provenance && provenance.minimalMerkleRoot !== minimal.merkleRoot){ issues.push('provenance.minimalMerkleRoot mismatch'); }
  } else {
    issues.push('minimal-runtime-manifest.json missing');
  }
  return issues;
}

function appendAdvisory(evt){
  const log = path.join(__dirname,'security-alerts.jsonl');
  const prev = (function(){ if(!fs.existsSync(log)) return null; const lines = fs.readFileSync(log,'utf8').trim().split(/\n/).filter(Boolean); if(lines.length===0) return null; try { return JSON.parse(lines[lines.length-1]).chain_hash; } catch { return null; } })();
  const core = { ts: Date.now(), type:'selfheal:advisory', event: evt };
  const coreHash = sha256(JSON.stringify(core));
  const chain_hash = sha256((prev||'')+coreHash);
  fs.appendFileSync(log, JSON.stringify({ ...core, chain_hash })+'\n');
}

function maybeRunAudit(){
  if(process.env.SELFHEAL_RUN_AUDIT !== '1') return null;
  try {
    const { spawnSync } = require('child_process');
    const r = spawnSync('node',['audit-all.js'], { cwd: __dirname, encoding:'utf8' });
    return { status: r.status, stdout: r.stdout.slice(0,4000), stderr: r.stderr.slice(0,2000) };
  } catch(e){ return { error: e.message }; }
}

function main(){
  const issues = detectDrift();
  if(issues.length===0){ console.log('[self-heal] No drift detected'); return; }
  console.log('[self-heal] Drift detected:', issues.join('; '));
  const auditResultBefore = maybeRunAudit();
  appendAdvisory({ issues, auditBefore: auditResultBefore && { status: auditResultBefore.status } });
  regenMinimal();
  regenProvenance();
  const auditResultAfter = maybeRunAudit();
  appendAdvisory({ action:'regen_complete', auditAfter: auditResultAfter && { status: auditResultAfter.status } });
}

if(require.main === module){ main(); }
module.exports = { main };