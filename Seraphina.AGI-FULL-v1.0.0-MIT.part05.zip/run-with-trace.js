#!/usr/bin/env node
// Helper launcher: inject env tracer then run target script with original args.
// Usage: node run-with-trace.js seraphina-REAL-mining.js --arg1=...  (set ENV_TRACE=1 to enable)
process.env.ENV_TRACE = process.env.ENV_TRACE || '1';
require('./env-tracer');

const path = require('path');

if (process.argv.length < 3) {
  console.error('Usage: node run-with-trace.js <script.js> [args]');
  process.exit(1);
}

const target = path.resolve(process.argv[2]);
const args = process.argv.slice(3);
console.log('[RUN_TRACE] Launching', target, 'with args', args.join(' '));
require(target);
