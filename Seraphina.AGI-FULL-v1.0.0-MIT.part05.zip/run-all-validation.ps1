<#
  Seraphina Comprehensive Validation & Security Runner (PowerShell)
  Steps:
    1. Generate minimal runtime manifest
    2. Generate provenance
    3. Verify provenance roots against current file
    4. Optional HMAC seal (if VAULT_PASS env present)
    5. Run audit-all
    6. Run self-heal (with audit pass) if drift occurs
    7. Security suite passive run (short)
    8. Print concise summary

  Usage:
    powershell -ExecutionPolicy Bypass -File .\run-all-validation.ps1
    (Optionally set $env:VAULT_PASS beforehand for HMAC sealing)
    Set $env:SELFHEAL_RUN_AUDIT=1 to include audit before/after in self-heal.
#>
Param(
  [switch]$SkipSecurity,
  [switch]$SkipHeal,
  [switch]$NoSeal
)

function Write-Info($msg){ Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Warn($msg){ Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg){ Write-Host "[ERR]  $msg" -ForegroundColor Red }

Set-Location $PSScriptRoot

Write-Info 'Generating minimal runtime manifest'
node generate-minimal-runtime-manifest.js | Out-Null
if($LASTEXITCODE -ne 0){ Write-Err 'Minimal manifest generation failed'; exit 2 }

Write-Info 'Generating provenance'
node generate-provenance.js | Out-Null
if($LASTEXITCODE -ne 0){ Write-Err 'Provenance generation failed'; exit 3 }

$prov = Get-Content .\provenance.json | ConvertFrom-Json
Write-Info 'Verifying provenance roots'
node provenance-verify.js --miner=$($prov.minerMerkleRoot) --audit=$($prov.minerAuditRoot) --minimal=$($prov.minimalMerkleRoot)
if($LASTEXITCODE -ne 0){ Write-Warn 'Provenance verification mismatch detected' }

if(-not $NoSeal -and $env:VAULT_PASS){
  Write-Info 'Sealing artifact-hashes.json with HMAC'
  node hmac-seal-artifacts.js
  if($LASTEXITCODE -ne 0){ Write-Warn 'HMAC sealing failed' } else { Write-Info 'HMAC seal applied' }
} elseif($NoSeal){
  Write-Info 'Skipping HMAC seal (NoSeal flag)'
} else {
  Write-Warn 'VAULT_PASS not set; skipping HMAC seal'
}

Write-Info 'Running integrity audit-all'
node audit-all.js | Out-Null
if($LASTEXITCODE -ne 0){ Write-Warn 'audit-all reported issues' } else { Write-Info 'audit-all OK' }

if(-not $SkipHeal){
  Write-Info 'Self-heal check'
  if($env:SELFHEAL_RUN_AUDIT -ne '1'){ Write-Info 'Set SELFHEAL_RUN_AUDIT=1 to include pre/post audit in advisories' }
  node self-heal-controller.js
  if($LASTEXITCODE -ne 0){ Write-Warn 'Self-heal script exited with non-zero (review logs)' }
} else { Write-Info 'Skipping self-heal (flag)'}

if(-not $SkipSecurity){
  Write-Info 'Security suite passive run'
  node security/security-suite-runner.js passive | Out-Null
  if($LASTEXITCODE -ne 0){ Write-Warn 'Security suite reported an issue' } else { Write-Info 'Security suite passive run completed' }
} else { Write-Info 'Skipping security suite (flag)'}

# Summary extraction
Write-Info 'Summary:'
$minimal = Get-Content .\minimal-runtime-manifest.json | ConvertFrom-Json
Write-Host "  Minimal Merkle Root: $($minimal.merkleRoot) (count=$($minimal.count))"
Write-Host "  Provenance Miner Root: $($prov.minerMerkleRoot)" 
Write-Host "  Provenance Audit Root: $($prov.minerAuditRoot)" 
Write-Host "  Provenance Minimal Root: $($prov.minimalMerkleRoot)" 
if(Test-Path artifact-hashes.json){
  $artifact = Get-Content artifact-hashes.json | ConvertFrom-Json
  if($artifact.hmacSeal){ Write-Host "  Artifact HMAC Seal: $($artifact.hmacSeal.Substring(0,16))..." } else { Write-Host "  Artifact HMAC Seal: (none)" }
}
if(Test-Path security/security-metrics.prom){
  $metrics = Get-Content security/security-metrics.prom | Select-String seraphina_security_alert_total | ForEach-Object { $_.Line }
  if($metrics){ Write-Host "  Security Alert Metrics:"; $metrics | ForEach-Object { Write-Host "    $_" } } else { Write-Host "  Security Alert Metrics: (none yet)" }
}

Write-Info 'Done.'