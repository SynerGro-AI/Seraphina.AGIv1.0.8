// refresh-artifact-hashes.js
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const TARGET = 'artifact-hashes.json';

function sha256File(path){ return crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex'); }
function listArtifacts(){
  return [
    'seraphina-model-weights.json',
    'seraphina-model-vocab.json',
    'seraphina-model-vocab-ledger.jsonl',
    'seraphina-model-train-ledger.jsonl',
    'seraphina-moral-safety-ledger.jsonl',
    'seraphina-personality-ledger.jsonl',
    'SERAPHINA-MODEL-EVOLUTION.md'
  ].filter(f=> fs.existsSync(f));
}

function run(){
  let obj={ artifacts:[]};
  if(fs.existsSync(TARGET)){
    try{ obj=JSON.parse(fs.readFileSync(TARGET,'utf8')); }catch{}
  }
  const map = new Map();
  (obj.artifacts||[]).forEach(a=> map.set(a.file, a));
  for(const f of listArtifacts()){
    const stat = fs.statSync(f);
    map.set(f, { file:f, size: stat.size, sha256: sha256File(f) });
  }
  obj.artifacts = Array.from(map.values());
  obj.generated = Date.now();
  // Recompute merkleRoot simple hash chain
  const hashes = obj.artifacts.map(a=> a.sha256).sort();
  let root = 'EMPTY';
  if(hashes.length){
    let level = hashes.slice();
    while(level.length>1){
      const next=[]; for(let i=0;i<level.length;i+=2){ if(i+1<level.length) next.push(crypto.createHash('sha256').update(level[i]+level[i+1]).digest('hex')); else next.push(level[i]); }
      level=next;
    }
    root=level[0];
  }
  obj.merkleRoot=root;
  fs.writeFileSync(TARGET, JSON.stringify(obj,null,2));
  console.log('[RefreshArtifacts] Updated', obj.artifacts.length, 'artifacts merkleRoot='+root.slice(0,16));
}

if(require.main===module){ run(); }
module.exports = { run };
