require('./aurrelia-pico-mesh-miner.js');
setTimeout(()=>process.exit(0), 2500);
