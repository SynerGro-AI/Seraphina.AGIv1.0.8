#!/usr/bin/env node
// Verify current provenance.json against expected roots.
const fs = require('fs');
const path = require('path');
let expectedMiner = process.env.EXPECT_MINER_ROOT || null;
let expectedAudit = process.env.EXPECT_AUDIT_ROOT || null;
let expectedMinimal = process.env.EXPECT_MINIMAL_ROOT || null;

// CLI overrides: --miner= --audit= --minimal=
for(const arg of process.argv.slice(2)){
  const m = arg.match(/^--(miner|audit|minimal)=(.+)$/);
  if(m){
    if(m[1]==='miner') expectedMiner = m[2];
    if(m[1]==='audit') expectedAudit = m[2];
    if(m[1]==='minimal') expectedMinimal = m[2];
  }
}

function fail(msg){
  console.error('[provenance-verify] FAIL:', msg);
  process.exitCode = 2;
}

function main(){
  const file = path.join(__dirname,'provenance.json');
  if(!fs.existsSync(file)){ fail('provenance.json missing'); return; }
  const data = JSON.parse(fs.readFileSync(file,'utf8'));
  let ok = true;
  if(expectedMiner && expectedMiner !== data.minerMerkleRoot){ ok=false; fail('minerMerkleRoot mismatch'); }
  if(expectedAudit && expectedAudit !== data.minerAuditRoot){ ok=false; fail('minerAuditRoot mismatch'); }
  if(expectedMinimal && expectedMinimal !== data.minimalMerkleRoot){ ok=false; fail('minimalMerkleRoot mismatch'); }
  if(ok){ console.log('[provenance-verify] OK'); }
}

if(require.main === module){ main(); }
module.exports = { main };