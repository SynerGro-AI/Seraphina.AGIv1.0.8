# Private Python Source Integration

This document outlines adding a locally built Python runtime to the Seraphina / Aurrelia miner environment for a fully auditable stack.

## Goals
- Eliminate reliance on distribution Python packages if deeper audit desired.
- Provide reproducible build steps and signature verification.
- Allow offline / air-gapped installation from the ISO or USB.

## Fetch & Verify (Online Staging)
```bash
bash fetch-verify-python.sh 3.12.5
# Confirms GPG signature and produces python-tarball.sha256
```
Store `Python-3.12.5.tgz` and optionally its `.asc` signature inside the USB or ISO workspace root.

## Offline Build
If the tarball is present on target:
```bash
sudo bash build-python-offline.sh Python-3.12.5.tgz
/opt/python/bin/python3 -V
```
Result: `/opt/python` prefix with isolated runtime.

## Autoinstall Integration
Set environment before ISO build or at boot (cloud-init late-command):
`INSTALL_PYTHON_SOURCE=1 PY_SRC_VERSION=3.12.5`
The modified `install-seraphina.sh` will:
1. Look for `Python-<version>.tgz` in the source directory.
2. Run `build-python-offline.sh` to install into `/opt/python`.
3. Leave system Python untouched (minimal risk).

## Using Custom Python
You can direct scripts or ML extensions to `/opt/python/bin/python3` explicitly. For miner tasks that spawn Python helpers:
```bash
/opt/python/bin/python3 aurrelia_kawpow.py
```
Consider adding to PATH in systemd unit if necessary:
```
Environment=PATH=/opt/python/bin:/usr/bin:/bin
```

## Integrity Checklist
- GPG signature: Good signature message present.
- Tarball SHA256 recorded in `python-tarball.sha256`.
- Built binary hash: `sha256sum /opt/python/bin/python3` stored in `/opt/python/python3.binary.sha256`.
- Compare both on subsequent deployments.

## Security Notes
- Do not embed secrets in Python environment directories.
- Keep build tools minimal; remove temporary `/tmp/pybuild` after success.
- Optionally enable SELinux/AppArmor profiles (future enhancement).

## Removal
```bash
sudo rm -rf /opt/python
sudo sed -i '/python/d' /etc/systemd/system/seraphina-miner.service
systemctl daemon-reload
```

## Next Enhancements
- Add reproducible build flags file capturing `configure` options.
- Introduce hash-based allowlist for bundled stdlib modules.
- Optional cross-compilation for ARM + x86 in one ISO.
