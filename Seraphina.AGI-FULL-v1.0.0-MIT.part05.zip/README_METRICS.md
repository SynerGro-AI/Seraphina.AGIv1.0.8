# Aurrelia Miner Metrics & Adaptive Controls

This document summarizes the Prometheus metrics, adaptive controllers, and economic / gating logic now present in `aurrelia-pico-mesh-miner.js`.

## Core Hash / Share Metrics
- `aurrelia_hashes_snapshot` – Total header hashes attempted (point-in-time).
- `aurrelia_hashrate_ths` – Approximate current TH/s.
- `aurrelia_shares_accepted_snapshot` / `aurrelia_shares_rejected_snapshot` – Share outcomes (point-in-time gauges, avoids counter duplication on restart).
- `aurrelia_share_acceptance_ratio` – Sliding window acceptance ratio.
- `aurrelia_share_accept_ratio_hist` – Histogram distribution of sampled acceptance ratios (buckets 0.00 → 1.0) used for quantile extraction.

## Acceptance Quantiles
- `adaptive_acceptance_p50` – Median acceptance ratio (updated each telemetry flush when enough samples ≥ 20).
- `adaptive_acceptance_p90` – 90th percentile acceptance ratio.
- `adaptive_acceptance_p99` – 99th percentile (tail) acceptance ratio (requires ≥ 50 samples). Used for tail volatility alerting when `p99 > 4× p90`.
- Internal ring buffer: `global.__AUR_ACCEPT_SAMPLES` (max 512) persisted to `accept-samples.json` (configurable via `ACCEPT_SAMPLES_PATH`). Persist interval: `ACCEPT_PERSIST_MS` (default 30s).

### Quantile Usage
- Modulus modulation: If p90 < 0.75 * `ACCEPT_TARGET` → decrement modulus (speed up). If p50 > `ACCEPT_HIGH` → increment modulus (reduce overhead).
- Gating regression: If p90 > `overBand` (default: 1.5× `ACCEPT_HIGH`) → reduce `normThreshold` by `NORM_REGRESS_FACTOR` (default 0.90). If p90 low (< 0.6× high band) → gradual recovery (+`NORM_RECOVER_RATE`, default 0.02) toward base.

## Gating Threshold
- Global threshold variable: `global.__AUR_NORM_THRESHOLD` (base from `NORM_THRESHOLD_BASE`, default 2.50).
- Broadcast to workers when changed via message `{ type: 'NORM_THRESHOLD', value }` (worker shards now implement handler to update their local `workerNormThreshold`).
- Exported as Prometheus gauge `adaptive_norm_threshold`.
- Persisted across restarts inside adaptive state JSON along with latency backoff factor.
- Regression & recovery controlled by environment vars:
  - `NORM_THRESHOLD_BASE` (default 2.50)
  - `NORM_REGRESS_FACTOR` (default 0.90)
  - `NORM_RECOVER_RATE` (default 0.02)
  - `ACCEPT_P90_BAND` (override high tail trigger; default 1.5 × `ACCEPT_HIGH`)

## Latency Backoff Controller
- Global: `global.__AUR_LAT_BACKOFF.factor` adjusts effective work modulus.
- Persisted alongside norm threshold in adaptive state JSON for warm restart continuity.
- Environment:
  - `LAT_TARGET_MS` (default 250) – target fused batch latency.
  - `LAT_BACKOFF_MIN` / `LAT_BACKOFF_MAX` (defaults 0.5 / 2.5).
  - `LAT_ADJ_INTERVAL_MS` (default 15000).
  - `LAT_BACKOFF_LOG=1` for verbose adjustments.

## Adaptive Modulus
- Base: `dynamicModulus` (initial `WORKER_MODULUS` or 6).
- Modified by:
  1. Flush heuristics (batch fullness).
  2. Latency backoff factor.
  3. Acceptance quantile modulation rules.
- Exposed as `adaptiveModulus` in `global.__AUR_WASM_METRICS__`.

## Economic (ECON) Layer
- Fetch cadence: `ECON_INTERVAL_MS` (default 60000 ms).
- Hysteresis: `ECON_HYSTERESIS_CYCLES` (default 3) – required consecutive cycles of a new best coin before switching.
- State fields: price (`ECON.state.price`), difficulty (`ECON.state.diff`), recommendation (`ECON.state.recommend`).
- Prometheus: `coinRecommendation` gauge (mapped numeric code).
- Auto Switch: When `ECON_AUTOSWITCH=1`, miner will apply `ECON.state.recommend` after hysteresis & a cooldown (`ECON_SWITCH_COOLDOWN_MS`, default 300000 ms) by reconfiguring pool target (supports BTC / RVN; others placeholder). Environment variables `BTC_POOL`, `RVN_POOL`, etc., can override pool addresses. Set `ALLOW_DEFAULT_POOLS=1` to permit internal safe defaults.
### Autoswitch Persistence & Metrics
Additional persisted state (adaptive-state.json):
- `lastSwitchTs` – timestamp of most recent economic switch.
- `activeCoin` – coin active after last successful switch (restored on restart to avoid premature flip).

Prometheus additions:
- `aurrelia_econ_switch_total{from_coin,to_coin,reason}` – Successful switches (reason usually `econ`).
- `aurrelia_econ_switch_fail_total{from_coin,to_coin,reason}` – Failed/blocked switch attempts (`low_accept`, `pool_unresponsive`, `preflight_fail`).
- `aurrelia_econ_active_coin{coin}` – Gauge set to numeric code for currently active coin (label `coin` retains string). Codes follow internal ordering (e.g., btc=0, rvn=1, kas=2, fren=3 when implemented).

Environment safety controls:
- `ECON_SWITCH_ACCEPT_FLOOR` – Minimum current acceptance ratio required to permit a switch (prevents fleeing during short transient dips). Default unset (0 disables check).
- `ECON_PREFLIGHT=1` – Enable TCP connect preflight before switching pools.
- `ECON_PREFLIGHT_TIMEOUT_MS` – Preflight socket timeout (default 2000).

Suggested PromQL:
```
rate(aurrelia_econ_switch_total[1h])
sum by (reason)(rate(aurrelia_econ_switch_fail_total[6h]))
changes(aurrelia_econ_active_coin[1h])
```

Alert Recipes:
- Excessive switching (possible hysteresis mis-tuned): `changes(aurrelia_econ_active_coin[1h]) > 3`
- Repeated low-accept blocks: `increase(aurrelia_econ_switch_fail_total{reason="low_accept"}[24h]) > 5`
- Pool instability (unresponsive): `increase(aurrelia_econ_switch_fail_total{reason="pool_unresponsive"}[1h]) > 2`
- Tail volatility + frequent switch (compound risk): `(adaptive_acceptance_p99 > adaptive_acceptance_p90 * 4) and changes(aurrelia_econ_active_coin[30m]) > 1`
- Cooldown extended (rollback recovery period): `aurrelia_econ_switch_cooldown_seconds > (ECON_SWITCH_COOLDOWN_MS/1000) * 1.2`
- Rollback indicator (implicit): `increase(aurrelia_econ_switch_fail_total{reason="rollback"}[30m]) > 0`

## Persistence Artifacts
- `accept-samples.json` – Acceptance ring (max 512 values).
- `fused-agg-hist.json` – Aggregated fused latency histogram.
- Adaptive state JSON (interval configurable via `ADAP_STATE_PERSIST_MS`) now persists:
  - `normThreshold`
  - `latencyBackoffFactor`
  - (Future candidates: last quantiles snapshot)

## Key Environment Variables (Summary)
| Variable | Purpose | Default |
|----------|---------|---------|
| ACCEPT_TARGET | Target acceptance ratio (modulation baseline) | 0.0005 |
| ACCEPT_HIGH | High acceptance threshold | 2× target |
| ACCEPT_PERSIST_MS | Persistence interval for acceptance samples | 30000 |
| ACCEPT_SAMPLES_PATH | Path to acceptance samples file | accept-samples.json |
| NORM_THRESHOLD_BASE | Base gating norm threshold | 2.50 |
| NORM_REGRESS_FACTOR | Multiplier on regression | 0.90 |
| NORM_RECOVER_RATE | Recovery growth rate | 0.02 |
| ACCEPT_P90_BAND | Override p90 hot band trigger | 1.5× high |
| LAT_TARGET_MS | Latency target for backoff controller | 250 |
| LAT_BACKOFF_MIN / MAX | Bounds on backoff factor | 0.5 / 2.5 |
| ECON_HYSTERESIS_CYCLES | Stable cycles before coin switch | 3 |

## Grafana Alert Examples
- Tail Saturation (possible over-pruning needed):
  `adaptive_acceptance_p90 > 0.30`
- Starvation (under-submission):
  `adaptive_acceptance_p50 < 0.01`
- Latency Drift:
  `increase(aurrelia_wasm_ema_latency_ms[5m]) > 50`
- Economic Switch Audit (detect frequent flips – should not exceed hysteresis):
  `changes(coinRecommendation[30m]) > 2`

## Operational Notes
- Quantile computations require ≥20 samples; before that p50/p90 gauges remain unset (0).
- Modulus changes are broadcast only when effective value changes to reduce worker churn.
- Gating threshold regression is multiplicative (compounded) – watch for floor clamp at 0.1.
- Hysteresis prevents rapid ECON flips in volatile price/diff surges.

## Future Extensions (Suggested)
1. Add Prometheus counter `adaptive_tail_volatility_alerts_total` for p99>4×p90 events.
2. Persist last quantile snapshot (p50/p90/p99) for immediate post-restart visibility.
3. Expand auto-switch support to additional coins (LTC / KAS placeholders) with pool schema validation.
4. Expose fused latency quantiles as summary metric for richer SLA tracking.
5. Add ECON switch counter `aurrelia_econ_switch_total` and cooldown remaining gauge.

---
Generated automatically by adaptive metrics enhancement pass.
