# Education & Safety Extensions

## Overview
This module set adds deterministic educational explainers (coding + accounting), moral command gating, virtue/emotion telemetry, and a knowledge exam generator.

## Components
- advanced-language-engine.js
  - listSupportedCodes(): Enumerates supported programming language codes.
  - explainCodingCapabilities(): Describes encryption, detection, translation placeholder, protocol counts.
  - explainAccountingBasics(): Summarizes GST vs corporate tax with deterministic exclusive/inclusive examples (pulls Seraphina financials).
- command-risk-classifier.js
  - Now loads optional custom patterns from command-risk-patterns.json when COMMAND_RISK_PATTERNS_ENABLE=1.
- command-moral-gate.js
  - validateCommands(commands[]): Blocks HIGH risk commands and returns structured report.
- ai-learning-orchestrator.js
  - Emits aurrelia_emotion_virtue_index gauge mapping color-emotion tier to virtue index.
- ai-knowledge-check.js
  - generateExam(): Produces deterministic question set (coding, accounting, virtues, moral gate).
  - evaluateAnswers(submissions): Scores exam deterministically.

## Prometheus Gauges Added
- aurrelia_emotion_virtue_index: Virtue index (0..6) aligned with color-emotion tier.

## Custom Risk Patterns
Create command-risk-patterns.json:
```json
[
  { "risk":"HIGH", "regex":"\\bformat\\s+disk\\b", "reason":"Disk format phrase" },
  { "risk":"MED", "regex":"\\bchgrp\\b", "reason":"Group ownership change" }
]
```
Enable via environment variable:
```
COMMAND_RISK_PATTERNS_ENABLE=1
```

## Running Tests
```
node test-virtue-gauge.js
node test-dynamic-patterns.js
node test-command-moral-gate.js
node ai-knowledge-check.js
```

## Knowledge Exam Usage
```js
const { generateExam, evaluateAnswers } = require('./ai-knowledge-check');
const exam = generateExam();
// Provide answers
const result = evaluateAnswers(exam.questions.map(q=> ({ id:q.id, answer:'...' })));
console.log(result.scorePct);
```

## Safety Notes
- Moral gate never executes commands; purely classifies and blocks HIGH risk.
- Custom patterns appended only after validating structure and risk level.
- Educational examples are deterministic; no external network calls.

## Future Improvements
- Structured remediation suggestions for blocked HIGH risk commands.
- Expansion of accounting examples (multi-rate GST, depreciation).
- Additional exam topics (governance bounds, Pareto optimization heuristics).
