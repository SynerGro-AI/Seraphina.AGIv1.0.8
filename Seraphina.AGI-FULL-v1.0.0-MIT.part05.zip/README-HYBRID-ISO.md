# Hybrid OctaLang + Ubuntu Mining ISO

## Overview
This guide covers building a hybrid installer ISO combining the OctaLang baremetal kernel artifacts with a minimal Ubuntu userland suitable for GPU/CPU mining and JS agent workflows. The resulting ISO provides two GRUB entries:
1. Non-Destructive install (no disk wipe).
2. Wipe-enabled install (requires `WIPE_CONFIRM=YES`).

## Prerequisites
Ubuntu host or WSL2 with the following packages:
```bash
sudo apt-get update
sudo apt-get install -y debootstrap xorriso rsync parted dosfstools jq
```
Build OctaLang kernel beforehand (non-fast for initramfs inclusion):
```bash
bash minimal-os/build-baremetal.sh --octalang
```

## Build ISO
```bash
chmod +x build-ubuntu-mining-preseed.sh
./build-ubuntu-mining-preseed.sh --msi-disk /dev/nvme0n1 --output octalang-mining.iso --nvidia
```
Flags:
- `--msi-disk /dev/nvme0n1` : Sets target disk for optional wipe script.
- `--output <file>` : ISO filename (default `octalang-mining.iso`).
- `--no-wipe` : Skip generating destructive wipe script.
- `--nvidia` : Stage NVIDIA driver (hash verified) and GPU miner stubs.

## Flash to USB
Identify USB (e.g., `/dev/sdb`):
```bash
lsblk
sudo dd if=octalang-mining.iso of=/dev/sdb bs=4M status=progress && sync
sudo eject /dev/sdb
```

## Boot & Install
1. Boot target machine from USB.
2. GRUB menu appears with two options.
3. Choosing the wipe-enabled entry requires kernel env propagating `WIPE_CONFIRM=YES` to allow disk operations.
4. System boots minimal environment with OctaLang kernel and stub miner service.

## Safety (Wipe Protection)
The wipe script (`/usr/local/bin/msi-wipe-build.sh`) checks `WIPE_CONFIRM=YES` before performing destructive operations. If not set, it exits safely.

## Artifacts Embedded
- `bzImage` and `initramfs-seraphina.img` (if full build).
- `octalang-build-report.json` (if available).
- Stub miner: `triad_miner.js` and systemd unit `triad-miner.service`.
- GPU stub: `aurelia_miner.js`, `aurelia-miner.service` (when `--nvidia`).
- First boot installer: `nvidia-install.service` + `nvidia-driver-install.sh` (when `--nvidia`).

## Validation
After ISO build:
```bash
file octalang-mining.iso
isoinfo -d -i octalang-mining.iso | grep -E 'Volume id'
```
Mount and inspect:
```bash
sudo mount -o loop octalang-mining.iso /mnt
ls /mnt/boot /mnt/casper
sudo umount /mnt
```

## Updating Miner Logic
Replace `triad_miner.js` with real implementation and rebuild. Ensure executable bit set.

## Troubleshooting
| Issue | Cause | Fix |
|-------|-------|-----|
| Missing initramfs | Fast mode kernel build used | Re-run build without `--fast`. |
| ISO creation error (xorriso) | Missing package | `sudo apt-get install xorriso`. |
| bzImage not found | Kernel build failed | Check `minimal-os/baremetal-build/out/`. |
| Wipe not executing | `WIPE_CONFIRM` not set | Use wipe-enabled entry or set env in kernel cmd line. |
| NVIDIA hash mismatch | Outdated hash or new driver release | Update `NVIDIA_HASH` in script to official SHA256. |
| No GPU service logs | Driver not yet installed | Check `journalctl -u nvidia-install.service`; may require reboot. |

## Next Enhancements
- Add NVIDIA driver staging & auto-detection.
- Integrate Prometheus node exporter service.
- Embed full OctaLang runtime & miner config manifest.
- Add signature verification for embedded artifacts.

---
Use cautiously; verify target disk before enabling wipe operations.