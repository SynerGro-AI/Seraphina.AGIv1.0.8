# ML Integration Overview

This document summarizes the deterministic ML override integration for the mining pipeline.

## Components
- TensorRT Addon (`tensorrt-addon.cc`): Deserializes a serialized engine (`weights.trt`).
  - Conditional build activated when `TRT_INCLUDE` and `TRT_LIB` env vars are set before build.
  - CUDA buffers allocated once; `enqueueV2` invoked each reinforcement cycle.
  - Deterministic fallback hashing if CUDA/TensorRT execution fails.
- Coral Inference (`coral_infer.py`): Edge TPU or deterministic fallback.
  - Warm server mode: `python coral_infer.py --server coral-ipc.sock`.
  - File-based IPC: request `.req` / response `.res` JSON arrays.
  - Watchdog restarts worker if it exits unexpectedly.

## Feature Vector Ordering
`[ meanEff, eff[0..3], attempts[0..3], accepts[0..3], gapRatio, rashbaGain, hypercubeBlend, subsetIdx, chernProxy ]`
- Length must match ONNX/TensorRT model input shape. Mismatch triggers deterministic fallback.

## Determinism Guarantees
- Fallback uses FNV-1a or SHA-256 hashing of the feature vector to derive stable weights.
- No random number generators used for ML weight overrides.

## Metrics
Prometheus gauges/histograms:
- `aurrelia_ml_latency_ms`
- `aurrelia_ml_latency_hist_ms` and optional `aurrelia_ml_latency_hist_ext_ms` (>2s bucket extension)
- `aurrelia_ml_latency_p50_ms`, `p90_ms`, `p99_ms`
- `aurrelia_ml_model_version`

## Environment Variables
TensorRT:
- `ML_TENSORRT=1`
- `TRT_ENGINE_PATH=weights.trt`
- `TRT_MODEL_VERSION=42`
- `TRT_INCLUDE`, `TRT_LIB` for build

Coral:
- `ML_CORAL=1`
- `CORAL_MODEL_VERSION=7`
- `CORAL_SOCKET_PATH=coral-ipc.sock`
- `CORAL_WARM_SCRIPT=coral_infer.py`
- `CORAL_SINGLE_TIMEOUT_MS=1500`
- `CORAL_WARM_LOG=1` (optional)

General:
- `AUR_PLANE_REINFORCE_MS` (reinforcement interval)
- `ML_LAT_SKIP_LOG=1` (log latency skip events)

## Latency Skip Logic
If last ML latency > 0.8 * reinforcement interval, next cycle bypasses ML override to preserve throughput.

## Extended Histogram Activation
First latency sample > 2000ms triggers creation of `aurrelia_ml_latency_hist_ext_ms` with larger buckets up to 5000ms.

## Test Harness
Run `node test-ml-override.js` to simulate attempts/accepts and exercise ML override logic. Adjust env variables as needed.

## Next Steps (Optional)
1. Implement full ONNX -> TensorRT build pipeline (if not already).
2. Add model input dimensionality assertion logging.
3. Add GPU hash acceleration integration synergy metrics (link weights to batch size adaptation).
4. Record ML decision provenance in a ring buffer for audit.
5. Integrate model signature (SHA256) gauge.
6. Automatic signature refresh on engine change (mtime based).

## Troubleshooting
- Fallback always returns normalized deterministic weights if engine or Coral unavailable.
- Check `aurrelia_ml_latency_ms` for unusually high values; ensure GPU and TPU devices are accessible.
- Use `TRT_LOG_INFO=1` for verbose TensorRT engine log output.

## Security Notes
- No external network calls are made; all IPC/file operations are local.
- Deterministic hashing prevents influence by transient hardware timing differences.

---
End of ML Integration Overview.

## ONNX → TensorRT Conversion Utility

Script: `onnx-to-tensorrt.js`

Usage:
```
node onnx-to-tensorrt.js --onnx=model.onnx --out=weights.engine --workspace=4096 --verbose
```
FP16 enabled by default. Disable with `--no-fp16`.

Outputs:
- Engine file at `--out`
- Timing cache `<out>.tcache`
- JSON summary (includes sha256)
- Optional `.ml-engine-env.json` (contains `TRT_ENGINE_PATH`) unless `--no-env`

Set `TRT_ENGINE_PATH` and miner auto-refreshes `aurrelia_ml_model_signature`.

Determinism Notes:
- FP16 accepted; signature monitors provenance.
- Timing cache hash included if produced.

## Model Signature Gauge
Gauge: `aurrelia_ml_model_signature`
- Numeric shard of SHA256(engine) (first 12 hex -> int mod 1e9).
- Refresh: file mtime change triggers recompute.

## GPU Hash Acceleration & Observability

When the GPU backend (sha256d batch kernel) is active, additional Prometheus metrics are exported.

Batch Performance:
- `aurrelia_gpu_batches_total`
- `aurrelia_gpu_headers_total`
- `aurrelia_gpu_last_batch_ns`
- `aurrelia_gpu_avg_per_header_ns`
- `aurrelia_gpu_batch_per_header_ns` (histogram; label: `batch_size`)

Parity & Integrity:
- `aurrelia_gpu_parity_checks_total`
- `aurrelia_gpu_parity_mismatches_total`
- `aurrelia_gpu_parity_interval_current`
- `aurrelia_gpu_disable_cause` (0=ok,1=parity_fail,2=recovery_exceeded,3=thermal_throttle)

Recovery:
- `aurrelia_gpu_recovery_attempts_total`
- `aurrelia_gpu_reenabled_total`
- `aurrelia_gpu_recovery_failures_total`
- Structured JSONL log at `GPU_RECOVERY_LOG` path.

Speed & Latency Percentiles:
- `aurrelia_gpu_speedup_est`
- `aurrelia_gpu_latency_p50_ns`, `aurrelia_gpu_latency_p90_ns`, `aurrelia_gpu_latency_p99_ns`
- `aurrelia_cpu_per_header_ns` (CPU parity sample histogram)
- `aurrelia_cpu_latency_p50_ns`, `aurrelia_cpu_latency_p90_ns`, `aurrelia_cpu_latency_p99_ns`

Thermals & Power:
- `aurrelia_gpu_temp_c`, `aurrelia_gpu_power_w`, `aurrelia_gpu_throttle`
Source: `nvidia-smi` or NVML addon (`nvml-addon`). Thermal limit breach sets disable cause 3.

State:
- `aurrelia_gpu_enabled`

Key Environment Variables:
```
GPU_BATCH_SIZE, GPU_BATCH_MAX_AGE_MS
GPU_PARITY_INTERVAL, GPU_PARITY_RELAX_AFTER, GPU_PARITY_RELAX_FACTOR
GPU_RECOVERY_ENABLED, GPU_RECOVERY_COOLDOWN_MS, GPU_RECOVERY_MAX_ATTEMPTS
GPU_RECOVERY_FAIL_THRESHOLD, GPU_RECOVERY_BACKOFF_BASE_MS, GPU_RECOVERY_BACKOFF_MAX_MS
GPU_RECOVERY_PARITY_INTERVAL_FACTOR
GPU_BATCH_LATENCY_BUCKETS
GPU_LATENCY_WINDOW
GPU_THERMAL_ENABLED, GPU_THERMAL_POLL_MS, GPU_THERMAL_MAX_TEMP_C
GPU_RECOVERY_LOG
```

Percentile Window:
- Length determined by `GPU_LATENCY_WINDOW` (default 500). Separate windows for GPU per-header and CPU parity samples.

Disable Cause Codes:
1 Parity mismatch integrity failure
2 Excessive failed recovery attempts
3 Thermal throttle / temperature limit breached
4 Driver error (CUDA present but hashing addon unavailable)
5 Misconfiguration (AUR_GPU=1 but no CUDA hints / addon)
Additional GPU Metrics:
- `aurrelia_gpu_utilization_pct`
- `aurrelia_gpu_mem_used_mb`
- `aurrelia_gpu_mem_total_mb`

Example Prometheus Alert Rules (YAML snippet):
```yaml
groups:
  - name: aurrelia-gpu
    rules:
      - alert: AurreliaGpuParityFailSpike
        expr: increase(aurrelia_gpu_parity_mismatches_total[5m]) > 0
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: GPU parity mismatch detected
          description: Parity mismatch has disabled GPU backend.

      - alert: AurreliaGpuThermalThrottle
        expr: aurrelia_gpu_disable_cause == 3
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: GPU thermal throttle
          description: Temperature exceeded GPU_THERMAL_MAX_TEMP_C and backend disabled.

      - alert: AurreliaGpuDriverError
        expr: aurrelia_gpu_disable_cause == 4
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: GPU driver error suspected
          description: CUDA hints present but hashing addon not operational.

      - alert: AurreliaGpuMisconfig
        expr: aurrelia_gpu_disable_cause == 5
        for: 5m
        labels:
          severity: info
        annotations:
          summary: GPU misconfiguration
          description: AUR_GPU=1 without CUDA environment.

      - alert: AurreliaGpuSpeedupDegradation
        expr: aurrelia_gpu_speedup_est < 1.2 and aurrelia_gpu_enabled == 1
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: GPU speedup degraded
          description: Speedup ratio fell below 1.2x; investigate batch size or thermal limits.
``` 

Recovery Log Example:
```
{"t": 1757345678123, "attempt": 3, "success": false, "reason": "parity_validation_fail"}
```

## Future Enhancements
- INT8 calibration dataset ingestion (deterministic sample order).
- Multi-engine ensemble hashing (aggregate XOR of signatures).
- Automatic rollback if signature deviates from expected manifest.
- NVML direct binding performance counters (utilization, memory bandwidth).
- GPU disable cause expansion (4=driver_error, 5=env_misconfig).

---
