/**
 * Ravencoin Node RPC (Skeleton)
 * Environment:
 *  RVN_RPC_URL  (e.g. http://127.0.0.1:8766)
 *  RVN_RPC_USER
 *  RVN_RPC_PASS
 * Currently wraps minimal calls; extend as real integration proceeds.
 */
const { URL } = require('url');
const http = require('http');
const https = require('https');

function cfg(){
  const u = process.env.RVN_RPC_URL; if(!u) return null; try { return new URL(u); } catch { return null; }
}

function rpcCall(method, params=[]) {
  const c = cfg(); if(!c) throw new Error('RVN_RPC_NOT_CONFIGURED');
  const auth = Buffer.from((process.env.RVN_RPC_USER||'')+':' + (process.env.RVN_RPC_PASS||'')).toString('base64');
  const body = JSON.stringify({ jsonrpc:'1.0', id: Date.now(), method, params });
  const isHttps = c.protocol === 'https:';
  const opt = {
    hostname: c.hostname,
    port: c.port || (isHttps?443:80),
    path: c.pathname,
    method: 'POST',
    headers: { 'Content-Type':'application/json','Content-Length':Buffer.byteLength(body),'Authorization':'Basic '+auth },
    rejectUnauthorized:false
  };
  return new Promise((resolve,reject)=>{
    const req=(isHttps?https:http).request(opt,res=>{
      let data='';res.on('data',d=>data+=d);res.on('end',()=>{try{const j=JSON.parse(data);if(j.error) return reject(new Error(j.error.message||'RVN_RPC_ERROR'));resolve(j.result);}catch(e){reject(e);} });
    });
    req.on('error',reject);req.write(body);req.end();
  });
}

async function listUnspentForAddress(address, minConf=1){
  const utxos = await rpcCall('listunspent',[minConf,9999999,[address]]);
  return utxos.map(u=>({ txid:u.txid, vout:u.vout, value: Math.round(u.amount*1e8), scriptPubKey:u.scriptPubKey, confirmations:u.confirmations }));
}

async function sendRawTransaction(hex){ return await rpcCall('sendrawtransaction',[hex]); }

module.exports = { rpcCall, listUnspentForAddress, sendRawTransaction };
