// REAL_ONLY_NEUTRALIZED: real-pool-connector.js
'use strict';
const path = require('path');
const REAL_MINERS = ['proper-antminer-mining.js'];
function locate(){ for(const r of REAL_MINERS){ const p=path.join(__dirname,r); try{require.resolve(p);return p;}catch{}} throw new Error('No real miner found'); }
module.exports = { launchReal(options={}){ const m=require(locate()); const C=m.ProperAntminerMiningProgram||m.default; if(!C) throw new Error('No entry'); const i=new C(options); if(i.connectToF2PoolStratum) i.connectToF2PoolStratum(); return i; }};
if(require.main===module){ if(process.env.REAL_MODE==='1') module.exports.launchReal(); else {console.error('Disabled direct exec. REAL_MODE=1 to run.'); process.exit(1);} }