# Seraphina Sandbox & Intrinsic Motivation (Deterministic Layer)

This sandbox layer introduces *intrinsic* (self-driven) signals that can be blended into the miner's effective improvement acceptance logic **without adding nondeterminism**.

## Components
- `knowledge-shards.json` – Domain shards (physics, QFT, math, …) each carrying:
  - `coreFacts[]` (string IDs for reproducible fact inventory)
  - `conceptVector[]` numeric concept embedding stub (fixed floats)
- `intrinsic-motivation-engine.js` – Computes metrics over shards:
  - `curiosity`: unseen_fact_fraction
  - `novelty`: binary (1 if new diversityHash vs rolling window)
  - `empowerment`: mean variance across concept vector dimensions
  - `integration` & `integrationNorm`: cross-domain linkage density normalized by domain count
- `seraphina-sandbox-env.js` – Runs deterministic self-play session (N steps) aggregating average metrics, ledger chaining to `sandbox-ledger.jsonl` (with caching & integration).
- `sandbox-shard-expander.js` – Deterministic shard forking when novelty & integration thresholds satisfied.
- `pareto-multi-metric-optimizer.js` – Multi-objective front for (imaginationGain, curiosityGain, integrationNorm) and optionally empowermentGain when `PARETO_INCLUDE_EMPOWERMENT=1`.

## Determinism Guarantees
- No randomness APIs; all ordering + diversity hash use SHA256 of stable serialized shard id sequences.
- Rolling window size fixed (12). Caching (planned) will compare diversityHash; identical hash ⇒ safe reuse.

## Effective Improvement Extension
Baseline (without Pareto):
```
Effective = baseImprovement
          + imaginationGain * IMAGINATION_GAIN_WEIGHT
          + avgCuriosity   * CURIOSITY_GAIN_WEIGHT
          + integrationNorm * INTEGRATION_GAIN_WEIGHT
```
With Pareto enabled (`PARETO_ENABLED=1`), representative weights replace governance weights unless `PARETO_REP_MODE=gov-nearest`.

## Metrics (Prometheus)
- `aurrelia_sandbox_avg_curiosity`
- `aurrelia_sandbox_avg_novelty`
- `aurrelia_sandbox_avg_empowerment`
- `aurrelia_sandbox_avg_integration`
- `aurrelia_pareto_front_size`
- `aurrelia_pareto_rep_imagination_weight`
- `aurrelia_pareto_rep_curiosity_weight`
- `aurrelia_pareto_rep_integration_weight`
- `aurrelia_imagination_dimension`

## Rollback Safety
If weighted effective improvement later dips below `GLOBAL_MIN_IMPROVEMENT`, rollback restores prior weights snapshot (sandbox influence cannot silently degrade performance).

## Imagination Adapter

Supports both 3D sphere lattice (Fibonacci shells) and high-dimensional hypercube crystal vectors (48 deterministic normalized points). Dimension set by `IMAGINATION_DIM` (default 3). >3 triggers crystal generation.

Crystal generation: cyclic rotation of a sign pattern base vector with fixed transform; each vector unit-normalized. No randomness.

## Pareto Optimization

`pareto-multi-metric-optimizer.js` enumerates normalized weight grid (resolution `PARETO_GRID_RES`, default 5), filters non-dominated points, selects representative weight vector by `PARETO_REP_MODE`. If `PARETO_INCLUDE_EMPOWERMENT=1`, a fourth objective (empowermentGain) is included.
- `median` (default) – component-wise median (robust)
- `average` – arithmetic mean (legacy)
- `gov-nearest` – closest to governance baseline weights

Ledger: `pareto-front-ledger.jsonl` entries include representative mode for audit.

## Governance & Env Vars
- `SANDBOX_ENABLED` (1/0)
- `IMAGINATION_GAIN_WEIGHT`, `CURIOSITY_GAIN_WEIGHT`, `INTEGRATION_GAIN_WEIGHT`
- `IMAGINATION_DIM` (3 or >3 for crystal)
- `PARETO_ENABLED`, `PARETO_GRID_RES`, `PARETO_REP_MODE`
- Curiosity tuner thresholds: `CURIOSITY_TUNE_LOW_THRESHOLD`, `CURIOSITY_TUNE_HIGH_THRESHOLD`
- Safety valve: `TUNER_MAX_DRAFTS_WINDOW`
 - Dimension escalation: `IMAGINATION_DIM_TARGET`, `IMAGINATION_DIM_STEP_MAX`, `IMAGINATION_DIM_VARIANCE_THRESHOLD`, `IMAGINATION_DIM_PLATEAU_RUNS`, `IMAGINATION_DIM_ESC_COOLDOWN_RUNS`, `IMAGINATION_DIM_COST_LIMIT`
 - Additional gating: `IMAGINATION_DIM_MIN_INTEGRATION`, `IMAGINATION_DIM_MIN_EMPOWERMENT`
 - Empowerment weighting: `EMPOWERMENT_GAIN_WEIGHT` and Pareto toggle `PARETO_INCLUDE_EMPOWERMENT`

### Dimension Escalation Logic
Deterministic escalation (via `dimension-escalator.js`) only occurs if ALL conditions hold:
1. `IMAGINATION_DIM_TARGET` > current dimension.
2. Step (target - current) <= `IMAGINATION_DIM_STEP_MAX`.
3. Variance of last `IMAGINATION_DIM_PLATEAU_RUNS` effective improvements < `IMAGINATION_DIM_VARIANCE_THRESHOLD`.
4. Plateau: absolute difference between mean of first half and last half of that window <= (varianceThreshold / 4).
5. History length >= `IMAGINATION_DIM_PLATEAU_RUNS`.

On success, dimension escalates directly to target (bounded by step constraint) and is persisted in `dimension-state.json` with a `decisionDigest` for audit reproducibility. The next run uses updated `IMAGINATION_DIM` for imagination lattice generation and logs `dimensionEscalation` field in the summary ledger when applied.

### Bootstrap & Rollback
- Bootstrap: set `IMAGINATION_DIM_BOOTSTRAP=1` to allow immediate evaluation using the current run's effective improvement as initial history (useful for test acceleration).
- Rollback safeguard: configure `IMAGINATION_DIM_ROLLBACK_RUNS` (default 5) and if every effective improvement in the last N runs falls below `GLOBAL_MIN_IMPROVEMENT`, the dimension reverts to its previous value and logs `dimensionRollback` in the summary ledger.

### Ramping & Gating
- Ramping: Set `IMAGINATION_DIM_RAMP_STEP` to limit each escalation increment (capped by `IMAGINATION_DIM_STEP_MAX` and the governance target). Prevents sudden high-dimensional jumps.
- Gating thresholds: `IMAGINATION_DIM_MIN_INTEGRATION` and `IMAGINATION_DIM_MIN_EMPOWERMENT` require sandbox metrics to meet or exceed thresholds before escalation is considered.

### Escalation Ledger
All escalation / rollback events append to `dimension-escalation-ledger.jsonl` (hash-chained) for independent audit. Event types: `escalate`, `rollback`, `rollback-proposal`.

### Rollback Proposal Mode
If `DIMENSION_ROLLBACK_PROPOSAL_MODE=1`, underperformance triggers an auto governance draft (`governance-proposal-drafts.jsonl`) proposing a dimension target reduction instead of immediate rollback, allowing operator review.

## Roadmap
1. Adaptive front pruning for very large grids (maintain deterministic ordering).
2. Alternate crystal bases (e.g., Walsh/Hadamard) selectable via env.
3. Governance-proposed dimension shift approval flow & rollback.
4. Structured agent suggestions for dimension escalation (validated by deterministic digest model).
5. Empowerment already integrated; future extended objectives (novelty, empowerment variance stability) pending.
6. Regression analysis automation comparing pre/post escalation snapshots for longer windows.

---
This layer seeds *agency scaffolding* while preserving reproducibility: intrinsic drives remain auditable and hash-verifiable.
