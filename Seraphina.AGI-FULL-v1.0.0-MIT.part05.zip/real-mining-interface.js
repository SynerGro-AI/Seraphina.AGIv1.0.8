// REAL_ONLY_NEUTRALIZED: real-mining-interface.js
'use strict';
module.exports = new Proxy({}, { get(){ throw new Error('real-mining-interface deprecated – use proper-antminer-mining.js'); } });