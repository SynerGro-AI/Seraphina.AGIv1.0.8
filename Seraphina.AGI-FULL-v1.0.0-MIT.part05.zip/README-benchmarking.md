# Seraphina / Direct USB Conductor Benchmarking

This document describes benchmarking scenarios and environment flags for performance evaluation.

## Benchmarks

1. Training Performance (`benchmark-seraphina-train.js`)
   - Compares loop vs vectorized logistic regression.
   - Env: `BENCH_TRAIN_N` controls synthetic dataset size (default 15000).
   - Sets `SERAPHINA_VECTORIZE` for second run; reports speedup and accuracy parity.

2. USB Telemetry Compression (`benchmark-usb-sim.js`)
   - Simulates batched compressed telemetry payloads.
   - Env: `USB_BATCH_SIZE` (default 512), `USB_SIM_ITERS` (default 8000).
   - Reports MB/s throughput estimate independent of real devices.

## Direct USB Conductor (`direct-usb-conductor.js`)

Moves beyond Pi emulation; MSI host talks directly to cube HID endpoints.

Env Vars:
- `MAX_CUBES` limit enumeration (default 35)
- `USB_VID` / `USB_PID` override vendor/product
- `USB_BATCH_SIZE` compressed packet size (default 512)
- `USB_POLL_MS` polling interval (default 10ms)
- `USB_BASE_FREQ` baseline pulse frequency (default 17)
- `USB_RETENTION_DELTA` Hz increment when predicted retention > threshold (default 2)
- `USB_RETENTION_THRESH` threshold for predicted retention (default 0.6)
- `USB_THROUGHPUT_GAUGE=1` updates Prometheus gauge if available (`global.__AUR_METRICS_REG__.gauges.usbThroughput`)
- `USB_DIRECT_LEDGER` custom ledger path

## Dataset Controls
- `MAX_RESERVOIR`: Hard cap on dataset size (deterministic front slice) after sampling.
- `SERAPHINA_VECTORIZE=1`: Enables mathjs vector path for training.
- `SERAPHINA_BINARY_TYPED=1`: Uses Float32Array slicing for binary dataset load.

## Ledger Rotation
- `SERAPHINA_LEDGER_COMPRESS=1` + `SERAPHINA_LEDGER_CHUNK_MB` trigger streaming gzip rotation.

## Running Benchmarks
```powershell
# Training benchmark
node benchmark-seraphina-train.js

# USB telemetry simulation
node benchmark-usb-sim.js
```

Adjust environment variables for scenario exploration:
```powershell
$env:BENCH_TRAIN_N='30000'; node benchmark-seraphina-train.js
$env:USB_BATCH_SIZE='1024'; $env:USB_SIM_ITERS='12000'; node benchmark-usb-sim.js
```

## Interpreting Results
- Training speedup > 3x indicates effective vectorization; parity in `acc_loop` vs `acc_vec` ensures correctness.
- USB simulation MB/s approximates combined compressed in/out; real hardware includes transfer latency and handshake overhead.
- Rotation logs show `[LedgerRotate] compressed=... hash=...`; verify new genesis entry recorded.

## Future Improvements
- Memory-map binary dataset for zero-copy slicing.
- Incremental streaming compression for conductor outbound pulses (reuse gzip context).
- Adaptive poll interval based on throughput and cube thermal feedback.
- Add statistical variance reporting (run benchmark multiple times, compute mean/SD).

## Vectorization Modes

Two selectable batch gradient implementations when `SERAPHINA_VECTORIZE=1`:

- `SERAPHINA_VECTORIZE_MODE=mathjs` (default): Uses mathjs matrices for gradient (`(X^T * err)/N`) each epoch.
- `SERAPHINA_VECTORIZE_MODE=native`: Packs the dataset into a contiguous `Float64Array` and performs fused loop accumulation (manual outer-products) with averaged gradients.

Both apply batch-averaged updates for determinism:
```
w -= (LR/N) * Σ_i err_i * x_i
b -= (LR/N) * Σ_i err_i
```

### Selecting a Mode (PowerShell / CMD)
PowerShell:
```
$env:SERAPHINA_VECTORIZE='1'; $env:SERAPHINA_VECTORIZE_MODE='native'; node benchmark-seraphina-train.js
```
CMD:
```
set SERAPHINA_VECTORIZE=1 && set SERAPHINA_VECTORIZE_MODE=native && node benchmark-seraphina-train.js
```

### Interpreting Accuracy
Loop path performs per-sample stochastic updates; vector modes use full-batch updates. With limited epochs this can yield different convergence (e.g., `acc_loop=1`, `acc_vec≈0.04`). Increase `EPOCHS` or adopt mini-batches to align.

### Example Output Snippet
```
{"loop_ms_mean":52,"native_vector_ms_mean":26,"mathjs_vector_ms_mean":20,"speedup_native":2.0,"speedup_mathjs":1.6}
```

### Planned Enhancements
- Mini-batch vector mode (configurable batch size).
- Optional SIMD / WASM acceleration.
- Convergence-normalized performance metric (time to reach target accuracy).
- In-place transpose cache to reduce mathjs overhead.

## Mini-Batch & Update Mode

Environment flags:

Examples (PowerShell):
```powershell
$env:SERAPHINA_BATCH_SIZE='256'; $env:SERAPHINA_TRAIN_UPDATE_MODE='batch'; node seraphina-model-train.js
$env:SERAPHINA_BATCH_SIZE='128'; $env:SERAPHINA_TRAIN_UPDATE_MODE='stochastic'; node seraphina-model-train.js
```

## Additional Optimization Flags

- `SERAPHINA_VECTOR_CACHE_TRANSPOSE=1`: Cache transpose of full matrix in mathjs full-batch mode to avoid repeated transpose operations.
- `SERAPHINA_BATCH_SCHEDULE`: Adaptive batch sizing. Formats:
   - Simple list: `128,256,0` (epoch0=128, epoch1=256, epoch2+=full batch)
   - Ranged: `64:10;128:30;0:60` (use 64 until epoch<10, 128 until epoch<30, then full batch until epoch<60, then full)
- `SERAPHINA_TRAIN_UPDATE_MODE`: `batch` (averaged gradient) or `stochastic` (unaveraged cumulative gradient) per batch.
- Evaluation file: `seraphina-eval-last.json` written each run with latest metrics `{ acc, accEthical, lossA, lossB, avgProbA, avgProbB }` for tooling.
- Epoch timing: `epochTimes` array now included in `seraphina-eval-last.json` for per-epoch duration analysis (ms).
- `SERAPHINA_LR_SCHEDULE`: Learning rate schedule matching batch schedule formats (e.g. `0.1,0.05,0.01` or `0.1:50;0.05:100;0.01`).
- SIMD-like native acceleration: `SERAPHINA_VECTORIZE_MODE=simd` enables loop-unrolled inner products for potential speed gains without external libs.
- Convergence ledger: `benchmark-seraphina-convergence.js` appends chain-hashed entries to `seraphina-convergence-ledger.jsonl` (override with `SERAPHINA_CONVERGENCE_LEDGER`).

Example adaptive schedule run (PowerShell):
```powershell
$env:SERAPHINA_BATCH_SCHEDULE='128,256,0'; $env:SERAPHINA_VECTORIZE='1'; node seraphina-model-train.js
```

## Convergence Benchmark

Script: `benchmark-seraphina-convergence.js`
Purpose: Finds epochs required for each mode (loop, native, mathjs) to reach target accuracy.
Env Vars:

Run:
```powershell
node benchmark-seraphina-convergence.js
```

Sample Output:
```json
{"targetAcc":0.85,"results":[{"mode":"loop","epochs":180,"acc":0.852,"lossA":0.44,"ms":1234.5},{"mode":"native","epochs":150,"acc":0.851,"lossA":0.45,"ms":978.2},{"mode":"mathjs","epochs":150,"acc":0.850,"lossA":0.46,"ms":1010.7}]}
```

Interpretation: Lower epochs & lower ms indicate faster convergence. Differences in lossA can guide learning rate tuning.

Document version: 2025-10-27 Vector Modes Addendum

---
Document version: 2025-10-26
