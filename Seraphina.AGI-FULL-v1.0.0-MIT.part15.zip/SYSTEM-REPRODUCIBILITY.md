# System Reproducibility Harness

## Purpose
Provides a single command to validate cross-component determinism between:
1. Seraphina Language Engine (strict deterministic mode)
2. Aurrelia Miner (pico mesh miner with cycle limit)

## Script
`system-repro-test.js` runs:
- Language engine smoke test (generating deterministic key/salt + boot hash)
- Miner with `AUR_REPRO_CYCLE_LIMIT` (defaults to 5 cycles) producing a deterministic digest chain
- Ledger chain verification (`ledger-chain-verify.js`) producing a summary file hash (included even if ledger issues detected)
- (Optional) DNS holodeck stats file hash if `HOLODECK_DNS_STATS_FILE` exists
- (Optional) AI memory log file hash if `AI_MEMORY_FILE` exists
- ML advisor weights version hash (external weights file or fallback) for model reproducibility tracking
- Combines all present digests into a final `combinedDigest` (SHA256 of colon-joined parts in deterministic order)

## Usage (PowerShell)
```powershell
$env:SERAPHINA_STRICT_DETERMINISM='1'
$env:SERAPHINA_SEED='system-repro-seed'
$env:AUR_REPRO_CYCLE_LIMIT='5'
node .\system-repro-test.js
```
Example output (with DNS + AI memory digests present):
```json
{
  "languageEngineDigest": "3d5f...",
  "minerDigest": "a4c2...",
  "dnsStatsHash": "9b77...",
  "aiMemoryHash": "55aa...",
  "combinedDigest": "d314..."
}
```
Running the command again with identical environment values should yield the same JSON digests.

## Environment Variables
- `SERAPHINA_STRICT_DETERMINISM=1` (required for language engine determinism)
- `SERAPHINA_SEED` seed string for language engine core (stable key/salt)
- `AUR_REPRO_CYCLE_LIMIT` number of miner cycles before deterministic exit
- `AUR_REPRO_FAST=1` enables ultra-fast synthetic loop (few controlled ticks) for CI speed
- `AUR_REPRO_STATE_IN` path to prior persisted miner repro state (resume)
- `AUR_REPRO_STATE_OUT` path to write new miner repro state at end
- `HOLODECK_DNS_STATS_FILE` path to DNS stats file (if present its SHA256 included)
- `AI_MEMORY_FILE` path to AI memory log (if present its SHA256 included)
- Optional miner seeds: `GLOBAL_OCTO_SEED`, `HOLODECK_ENABLE` (keep at 0/disabled unless validating holodeck determinism)

## Deterministic Artifacts
- Language engine: build timestamp, boot hash, octabit key, quantum salt, combined digest of MATCH lines
- Miner: header digest and per-cycle chain culminating in `[REPRO]` digest, optional resumed state
- Ledger verification summary: hash of `ledger-verify.json` (contains per-ledger ok status and issues)
- ML advisor weights: version + SHA256(version + vector) for reproducible model reference (`mlWeightsVersionHash`)
- DNS stats: SHA256 of stats file contents (if file exists)
- AI memory log: SHA256 of entire log file (append-only hash-chained entries) if exists
- Combined digest: SHA256(languageEngineDigest:minerDigest[:ledgerVerifyHash][:dnsStatsHash][:aiMemoryHash][:mlWeightsVersionHash]) — order preserved exactly

## Verification Script
`system-repro-verify.js` performs two sequential runs of `system-repro-test.js` and asserts equality of `combinedDigest`.

Usage (PowerShell):
```powershell
$env:SERAPHINA_STRICT_DETERMINISM='1'
$env:SERAPHINA_SEED='system-repro-seed'
$env:AUR_REPRO_CYCLE_LIMIT='5'
$env:AUR_REPRO_FAST='1'
# Optional state resume
$env:AUR_REPRO_STATE_IN='repro-state.json'
$env:AUR_REPRO_STATE_OUT='repro-state.json'
# Optional subsystems
$env:HOLODECK_DNS_STATS_FILE='holodeck-dns-stats.json'
$env:AI_MEMORY_FILE='ai-memory.jsonl'
node .\system-repro-verify.js
```

Example verification output:
```json
{
  "pass": true,
  "reason": null,
  "run1": { "combinedDigest": "d314...", "minerDigest": "a4c2..." },
  "run2": { "combinedDigest": "d314...", "minerDigest": "a4c2..." },
  "resumedFromState": true
}
```
Non-zero exit status (2) indicates mismatch or failure; integrate into CI as determinism gate.

## Troubleshooting
- Missing miner digest: ensure cycle limit set and miner reaches pipeline tick; check logs for `[REPRO] cycle limit active`.
- Language engine failures: verify path in script matches workspace structure and that dependencies resolve.
- Variant outputs: confirm no external non-deterministic env vars (e.g., dynamic commit hash) change between runs.

## Extensibility
Future additions could incorporate:
- Progress tracker logical time state hash
- Structured meta digest publishing to Prometheus with numeric fold
- Automated differential alerting if combinedDigest drift detected

---
End of SYSTEM-REPRODUCIBILITY.md
