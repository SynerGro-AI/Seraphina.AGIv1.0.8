#!/usr/bin/env bash
# wsl-build-kernel.sh: WSL-Optimized Kernel + OctaLang Bridge build helper
# Usage: ./wsl-build-kernel.sh [--fast] [--workdir /path] [--octalang] [--no-validate]
# Performs build steps inside native Linux filesystem for permission safety.
set -euo pipefail

FAST_MODE=false
WORKDIR="$HOME/octalang-build"
OCTALANG=true
VALIDATE=true

while [[ $# -gt 0 ]]; do
  case $1 in
    --fast) FAST_MODE=true; shift ;;
    --workdir) WORKDIR="$2"; shift 2 ;;
    --octalang) OCTALANG=true; shift ;;
    --no-octalang) OCTALANG=false; shift ;;
    --no-validate) VALIDATE=false; shift ;;
    *) echo "[ERROR] Unknown flag: $1"; exit 1 ;;
  esac
done

if [[ ! -d "$WORKDIR" ]]; then
  echo "[INFO] Creating workdir: $WORKDIR"
  mkdir -p "$WORKDIR"
fi
cd "$WORKDIR"

# Detect WSL
KREL=$(uname -r || echo '')
if [[ $KREL == *microsoft* ]]; then
  echo "[INFO] WSL kernel detected: $KREL"
else
  echo "[WARN] Not running under WSL (uname -r=$KREL); proceeding anyway"
fi

# Ensure baseline packages
if ! command -v curl >/dev/null 2>&1 || ! command -v git >/dev/null 2>&1; then
  echo "[INFO] Installing base packages (curl git build-essential jq python3-pip)"
  sudo apt-get update -y && sudo apt-get install -y curl git build-essential jq python3-pip
fi

# Python deps (optional; stub uses only stdlib but prepare for future expansion)
if [[ $OCTALANG == true ]]; then
  python3 - <<'PY'
import sys
print('[INFO] Python version:', sys.version)
PY
fi

# Link back to repo root for scripts
REPO_ROOT="$(dirname "$(dirname "$(realpath "$0")") )" || true
# Fallback manual: search for aurrelia-agent-invoke.js
if [[ ! -f "$REPO_ROOT/aurrelia-agent-invoke.js" ]]; then
  REPO_ROOT="$(pwd)" # assume invoked from repo root previously
fi

# Copy minimal scripts into workdir for isolated build to avoid path issues
if [[ $OCTALANG == true ]]; then
  echo "[INFO] Preparing OctaLang bridge scripts"
  cp "$REPO_ROOT/build-octalang-binary.js" . 2>/dev/null || echo "[WARN] build-octalang-binary.js not found"
  cp "$REPO_ROOT/aurrelia-agent-invoke.js" . 2>/dev/null || echo "[WARN] aurrelia-agent-invoke.js not found"
  cp "$REPO_ROOT/validate-reports.js" . 2>/dev/null || echo "[WARN] validate-reports.js not found"
  # Node dependency check
  if ! command -v node >/dev/null 2>&1; then
    echo "[INFO] Installing Node.js (curl + setup script)"
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
  fi
fi

# Run OctaLang bridge
if [[ $OCTALANG == true && -f build-octalang-binary.js ]]; then
  echo "[INFO] Running OctaLang bridge build"
  node build-octalang-binary.js || echo "[WARN] OctaLang bridge build failed"
fi

# Kernel build stub / fast mode placeholder
if [[ $FAST_MODE == true ]]; then
  echo "[INFO] Fast mode enabled: skipping full kernel build (placeholder)"
else
  echo "[INFO] Full kernel build placeholder (enhance build-baremetal.sh soon)"
fi

# Validation
if [[ $VALIDATE == true && -f validate-reports.js ]]; then
  echo "[INFO] Validating build report"
  node validate-reports.js || echo "[WARN] Validation reported issues"
fi

echo "[OK] WSL build helper complete (FAST_MODE=$FAST_MODE OCTALANG=$OCTALANG WORKDIR=$WORKDIR)"