// test-octalang-eta.test.js
// Simple test to ensure Python stub returns etaBoost within expected range and report JSON is produced.
'use strict';
const fs = require('fs');
const { execSync } = require('child_process');

function runBuild(){
  execSync('node build-octalang-binary.js', { stdio: 'inherit' });
}

describe('OctaLang bridge build', () => {
  it('produces build report with etaBoost in range', () => {
    runBuild();
    const raw = fs.readFileSync('octalang-build-report.json','utf8');
    const j = JSON.parse(raw);
    expect(j.etaBoost).toBeGreaterThanOrEqual(1.0);
    expect(j.etaBoost).toBeLessThanOrEqual(1.15);
    expect(Array.isArray(j.sampleHashes)).toBe(true);
    expect(j.sampleHashes.length).toBeGreaterThanOrEqual(5);
  });
});
