// sign-snapshot.js
// Generates detached signature for latest snapshot using SHA256 and optional HMAC.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const DIR = process.env.SERAPHINA_SNAPSHOT_DIR || 'seraphina-snapshots';
const OUT = process.env.SERAPHINA_SNAPSHOT_SIG_DIR || 'seraphina-snapshot-sigs';
if(!fs.existsSync(OUT)) fs.mkdirSync(OUT,{recursive:true});
const HMAC_KEY = process.env.SERAPHINA_SNAPSHOT_HMAC_KEY || '';

function stableHash(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }
function hmacHash(buf){ if(!HMAC_KEY) return null; return crypto.createHmac('sha256', HMAC_KEY).update(buf).digest('hex'); }

function latestSnapshot(){
  if(!fs.existsSync(DIR)) return null;
  const files = fs.readdirSync(DIR).filter(f=> f.startsWith('snapshot-') && f.endsWith('.json')).sort();
  if(!files.length) return null; return DIR+'/'+files[files.length-1];
}

function run(){
  const snapFile = latestSnapshot();
  if(!snapFile){ console.log('[SignSnapshot] No snapshots found'); return; }
  const content = fs.readFileSync(snapFile);
  const sha = stableHash(content);
  const hmac = hmacHash(content);
  const sigObj = { snapshot: snapFile, sha256: sha, hmac: hmac, ts: Date.now() };
  const sigFile = OUT + '/sig-' + sha.slice(0,16) + '.json';
  fs.writeFileSync(sigFile, JSON.stringify(sigObj,null,2));
  console.log('[SignSnapshot] Signature written', sigFile, 'sha='+sha.slice(0,16));
}

if(require.main===module){ run(); }
module.exports = { run };
