// Test script to force EMA median alert high/low and validate /health status
// Assumes seraphina-model-train.js and seraphina-dashboard.js are present.
// Strategy:
// 1. Run a training session with artificially tight high threshold so current delta triggers high alert.
// 2. Start dashboard, fetch /health, assert status 'hot' or 'cold'.
// 3. Output pass/fail summary.

const { spawnSync, spawn } = require('child_process');
const fs = require('fs');

const TRAIN = process.env.TRAIN_SCRIPT || 'seraphina-model-train.js';
const DASH = process.env.DASH_SCRIPT || 'seraphina-dashboard.js';
const ALERT_LEDGER = process.env.SERAPHINA_EMA_MEDIAN_ALERT_LEDGER || 'seraphina-ema-median-alert-ledger.jsonl';

function runTrain(high, low){
  const args = ['node', TRAIN, `--emaMedianThresh=0`, `--alertHigh=${high}`, `--alertLow=${low}`, '--labelFlip=0.15', '--emaAlpha=0.6'];
  console.log('[Test] Running training:', args.join(' '));
  const res = spawnSync(args[0], args.slice(1), { stdio: 'inherit' });
  if(res.status !== 0) throw new Error('Training failed');
}

function startDashboard(){
  console.log('[Test] Starting dashboard');
  const proc = spawn('node', [DASH], { stdio: 'inherit' });
  return proc;
}

function fetchHealth(){
  return new Promise((resolve,reject)=>{
    const http = require('http');
    http.get('http://localhost:8999/health', res => {
      let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ try{ resolve(JSON.parse(data)); }catch(e){ reject(e); } });
    }).on('error', reject);
  });
}

(async function(){
  try {
    // Clean previous alert ledger for deterministic test
    if(fs.existsSync(ALERT_LEDGER)) fs.unlinkSync(ALERT_LEDGER);
    // Choose thresholds so any positive delta will trigger high; negative will trigger low after second run
    runTrain(0.000001, -0.5); // First run may produce delta; high threshold near zero
    const dash = startDashboard();
    // Wait for dashboard to bind
    await new Promise(r=>setTimeout(r,1200));
    const health1 = await fetchHealth();
    console.log('[Health1]', health1);
    if(!health1.ok) throw new Error('Health endpoint not ok');
    console.log('[Status1]', health1.health.status);
    // Second training to try flip status (if delta shifts)
    runTrain(0.5, -0.000001); // flip thresholds to favor low alert
    await new Promise(r=>setTimeout(r,600));
    const health2 = await fetchHealth();
    console.log('[Health2]', health2);
    console.log('[Status2]', health2.health.status);
    dash.kill('SIGINT');
    const alerts = fs.existsSync(ALERT_LEDGER) ? fs.readFileSync(ALERT_LEDGER,'utf8').trim().split(/\n+/) : [];
    if(alerts.length === 0) throw new Error('No alerts recorded');
    console.log('[AlertLedgerEntries]', alerts.length);
    console.log('TEST PASS (alerts & health statuses observed)');
  } catch (e){
    console.error('TEST FAIL', e);
    process.exit(1);
  }
})();
