#!/usr/bin/env bash
# test-micro-init.sh - Integrity / panic code test harness for micro-init-wrapper.sh
# Requires: bash, jq, sha256sum, openssl (optional for seal tests)
set -euo pipefail

WRAPPER=${WRAPPER_PATH:-"./micro-init-wrapper.sh"}
REPORT=seraphina-boot-report.json
PASS=0; FAIL=0

function run_case(){
  local name="$1"; shift
  echo "[CASE] $name" 1>&2
  rm -f manifest.json manifest.seal $REPORT || true
  eval "$@" || true
  if ! bash "$WRAPPER" > wrapper.out 2> wrapper.err; then true; fi
  local code=$(jq -r '.panicCode' < wrapper.out || echo 'N/A')
  echo "panicCode=$code" 1>&2
  case "$name" in
    missing-manifest) [[ "$code" == "20" ]] && ((PASS++)) || ((FAIL++)) ;;
    missing-seal) [[ "$code" == "21" ]] && ((PASS++)) || ((FAIL++)) ;;
    hash-mismatch) [[ "$code" == "22" ]] && ((PASS++)) || ((FAIL++)) ;;
    seal-invalid) [[ "$code" == "23" ]] && ((PASS++)) || ((FAIL++)) ;;
    success) [[ "$code" == "0" ]] && ((PASS++)) || ((FAIL++)) ;;
    *) echo "Unknown case"; ((FAIL++)) ;;
  esac
}

# Case 1: missing manifest
run_case missing-manifest "true"

# Prepare a valid manifest
cat > manifest.json <<'EOF'
{
  "aggregateRoot": "abc123",
  "manifestSha256": "PLACEHOLDER"
}
EOF
# Compute real hash and patch placeholder
REAL_HASH=$(sha256sum manifest.json | awk '{print $1}')
sed -i "s/PLACEHOLDER/$REAL_HASH/" manifest.json

# Case 2: missing seal
run_case missing-seal "true"

# Case 3: hash mismatch (alter file after declared hash)
cp manifest.json manifest.json.bak
sed -i 's/abc123/xyz999/' manifest.json
run_case hash-mismatch "true"
# restore
mv manifest.json.bak manifest.json

# Case 4: seal invalid (create seal with wrong key)
# Derive correct hash already in manifest.json
if command -v openssl >/dev/null; then
  echo "{\"manifestHmac\":\"deadbeef\"}" > manifest.seal
  run_case seal-invalid "VAULT_PASS=correctsecret"
else
  echo "[WARN] openssl not found; skipping seal-invalid case" 1>&2
fi

# Case 5: success (provide valid seal if openssl)
if command -v openssl >/dev/null; then
  hkdf_salt="seraphina.init.v1"
  hkdf_info="manifest:$REAL_HASH"
  key_material=$(printf '%s' "testsecret$hkdf_salt$hkdf_info" | sha256sum | awk '{print $1}')
  key=${key_material:0:64}
  HMAC=$(echo -n "$REAL_HASH" | openssl dgst -sha256 -mac HMAC -macopt hexkey:$key | awk '{print $2}')
  echo "{\"manifestHmac\":\"$HMAC\"}" > manifest.seal
  run_case success "VAULT_PASS=testsecret"
else
  run_case success "true"
fi

TOTAL=$((PASS+FAIL))
echo "[RESULT] PASS=$PASS FAIL=$FAIL TOTAL=$TOTAL" 1>&2

if ((FAIL>0)); then
  echo "Test harness detected failures" 1>&2
  exit 1
fi

echo "All selected micro-init integrity tests passed." 1>&2
