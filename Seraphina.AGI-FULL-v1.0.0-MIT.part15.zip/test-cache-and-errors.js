'use strict';
// test-cache-and-errors.js
// Verifies caching, eviction, and structured error codes.
const api = require('./seraphina-api');

function testCaching(){
  console.log('--- Caching Test ---');
  const baseOpts = { n:800, seed:'cache-seed', corrPrudence:-0.3 };
  const r1 = api.virtueSim.runSimulation(baseOpts);
  if(!r1.ok || r1.fromCache) throw new Error('First run should not be from cache');
  const r2 = api.virtueSim.runSimulation(baseOpts);
  if(!r2.ok || !r2.fromCache) throw new Error('Second identical run should be from cache');
  // Fill cache beyond max to force eviction
  const max = api.meta.getCacheStats().max;
  for(let i=0;i<max+5;i++){
    api.virtueSim.runSimulation({ n:300 + i, seed:'cache-seed-'+i });
  }
  const stats = api.meta.getCacheStats();
  if(stats.size > max) throw new Error('Cache size exceeded max after eviction');
  console.log('Caching OK. size=', stats.size, 'max=', stats.max);
}

function testInvalidArgs(){
  console.log('--- Invalid Args Test ---');
  const bad = api.virtueSim.runSimulation({ n: -5 });
  if(bad.ok) throw new Error('Expected invalid arg range error');
  if(bad.code !== 'INVALID_ARG_RANGE') throw new Error('Expected code INVALID_ARG_RANGE');
  console.log('Invalid args error structure OK');
}

function testModuleUnavailable(){
  console.log('--- Module Unavailable Test ---');
  const d = api.meta.__test_disableSim();
  if(!d.ok) throw new Error('Failed to disable sim');
  const res = api.virtueSim.runSimulation({ n:10 });
  const rstore = api.meta.__test_restoreSim();
  if(!rstore.ok) throw new Error('Failed to restore sim');
  if(res.ok || res.code !== 'MODULE_UNAVAILABLE') throw new Error('Expected MODULE_UNAVAILABLE');
  console.log('Module unavailable error OK');
}

function runAll(){
  try {
    testCaching();
    testInvalidArgs();
    testModuleUnavailable();
    console.log('All cache & error tests passed.');
  } catch(e){
    console.error('Test failure:', e.message);
    process.exit(1);
  }
}

if(require.main === module){ runAll(); }
module.exports = { runAll };