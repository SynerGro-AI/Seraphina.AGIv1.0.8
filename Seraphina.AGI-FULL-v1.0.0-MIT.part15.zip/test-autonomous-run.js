// test-autonomous-run.js
// Manual trigger for autonomous test suite (single run).

'use strict';
const api = require('./seraphina-api.js');

(async () => {
  console.log('[Autotest] Starting single autonomous test run...');
  const report = await api.autotest.runAll();
  if(!report.ok){
    console.error('[Autotest] Run failed', report.error);
    process.exit(1);
  }
  console.log('[Autotest] Digest:', report.digest);
  console.log('[Autotest] Pass/Fail:', report.passCount,'/', report.total);
  for(const r of report.results){
    console.log(` - ${r.name}: ${r.ok? 'OK':'FAIL'} (${r.durationMs} ms)`);
  }
  if(report.failCount>0){
    console.error('[Autotest] Some tests failed');
    process.exit(2);
  }
  console.log('[Autotest] All tests passed');
})();
