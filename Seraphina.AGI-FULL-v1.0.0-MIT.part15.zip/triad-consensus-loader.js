/**
 * TRIAD CONSENSUS LOADER (Dual-Triad 2-of-3 Validation = 6 Validators Total)
 * -------------------------------------------------------------------------
 * Parses OctaLang core files containing triad validator definitions and enforces
 * a double layer consensus: each triad must achieve 2-of-3 validator signatures
 * BEFORE an action is executed. Two triads * 3 validators = 6 validator entities.
 *
 * Files Parsed:
 *  - CORE_FILE.octa (primary triad)
 *  - seraphina-triad-security-core.octa (secondary triad)
 *
 * Usage Example:
 *  const { runProtectedAction } = require('./triad-consensus-loader');
 *  (async () => {
 *     const result = await runProtectedAction('broadcast_btc_tx', { txid: 'abc' }, () => {
 *        // actual sensitive operation
 *        return 'BROADCAST_OK';
 *     });
 *     console.log(result);
 *  })();
 *
 * Environment Overrides:
 *  CONSENSUS_DOMAIN=string            → domain separation salt
 *  TRIAD_FILES=path1;path2;...        → custom triad file list (else defaults)
 *  DISABLE_VALIDATORS=alpha1,beta2    → mark specific validators offline (alpha|beta|gamma + triad index 1..N)
 *  TRIAD_FAIL_MODE=strict|lenient     → strict (default) throws if consensus fails; lenient logs & skips
 *  VALIDATOR_EXTRA_SEED=...           → additional entropy for signatures
 *
 * Security Note: This is a structural / logical integrity gate. It is NOT a
 * cryptographic multi-signature wallet. For real cryptographic security,
 * integrate hardware key material and real signature validation layers.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ---------------- Configuration ----------------
const primaryCore = fs.existsSync(path.join(__dirname,'CORE_FILE.octa'))
  ? path.join(__dirname,'CORE_FILE.octa')
  : (fs.existsSync(path.join(__dirname,'CORE_FILE1.octa')) ? path.join(__dirname,'CORE_FILE1.octa') : path.join(__dirname,'CORE_FILE.octa'));

// If both CORE_FILE.octa and CORE_FILE1.octa exist, load both (treat second as an additional triad layer)
const extraCore = (fs.existsSync(path.join(__dirname,'CORE_FILE.octa')) && fs.existsSync(path.join(__dirname,'CORE_FILE1.octa')))
  ? path.join(__dirname,'CORE_FILE1.octa') : null;

const DEFAULT_TRIAD_FILES = [
  primaryCore,
  path.join(__dirname, 'seraphina-triad-security-core.octa')
].concat(extraCore ? [extraCore] : []);
const TRIAD_FILES = (process.env.TRIAD_FILES ? process.env.TRIAD_FILES.split(/;+/).map(p => path.resolve(__dirname, p.trim())) : DEFAULT_TRIAD_FILES);
const CONSENSUS_DOMAIN = process.env.CONSENSUS_DOMAIN || 'SERAPHINA_DUAL_TRIAD_DOMAIN_V1';
const FAIL_MODE = (process.env.TRIAD_FAIL_MODE || 'strict').toLowerCase();
const DISABLED = new Set((process.env.DISABLE_VALIDATORS || '').split(/[,;\s]+/).filter(Boolean)); // e.g. alpha1,beta2
const EXTRA_SEED = process.env.VALIDATOR_EXTRA_SEED || '';

const LOG_DIR = path.join(__dirname, 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
const CONS_LOG = path.join(LOG_DIR, 'triad-consensus.log');

function log(lineObj) {
  const line = JSON.stringify({ ts: Date.now(), ...lineObj });
  try { fs.appendFileSync(CONS_LOG, line + '\n'); } catch {}
}

// ---------------- Parsing ----------------
// We locate the triad_hash_verification() section and extract the three validator blocks.
function parseTriadFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return { file: filePath, validators: [], error: 'missing_file' };
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const triadSectionMatch = content.match(/triad_hash_verification\(\)[^\{]*\{([\s\S]*?)\n\s*\}/); // heuristic
  if (!triadSectionMatch) {
    return { file: filePath, validators: [], error: 'no_triad_section' };
  }
  const section = triadSectionMatch[1];
  // Extract validator object beginnings
  const validatorRegex = /(seraphina_(alpha|beta|gamma)_validator)\s*:\s*\{([\s\S]*?)\n\s*\}/g;
  const validators = [];
  let m;
  while ((m = validatorRegex.exec(section)) !== null) {
    const name = m[1];
    const body = m[3];
    const lines = body.split(/\n/).map(l => l.trim());
    const props = {};
    for (const line of lines) {
      const kv = line.match(/^([a-zA-Z0-9_]+)\s*:\s*"?([^",]+)"?,?$/);
      if (kv) props[kv[1]] = kv[2];
    }
    validators.push({ name, properties: props });
  }
  return { file: filePath, validators };
}

// Load all triads
const TRIADS = TRIAD_FILES.map(parseTriadFile).filter(t => t.validators.length === 3);

// Assign stable triad index for labeling (1-based)
TRIADS.forEach((t, idx) => { t.index = idx + 1; });

// ---------------- Signature / Consensus ----------------
function sha256Hex(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }

function validatorId(vName, triadIndex) {
  return `${vName}#T${triadIndex}`; // e.g. seraphina_alpha_validator#T1
}

function computeValidatorSignature(vName, triadIndex, actionName, payloadHash) {
  // Domain separated deterministic signature placeholder
  const id = validatorId(vName, triadIndex);
  const seed = sha256Hex(Buffer.from(CONSENSUS_DOMAIN + '::' + id + '::' + EXTRA_SEED));
  return sha256Hex(Buffer.from([seed, actionName, payloadHash].join('::')));
}

function performTriadConsensus(triad, actionName, payloadHash) {
  const approvals = [];
  for (const v of triad.validators) {
    const id = validatorId(v.name, triad.index);
    const shortId = id.replace('seraphina_', ''); // cosmetic
    if (DISABLED.has(v.name.replace('seraphina_', '').split('_')[0] + triad.index) || DISABLED.has(shortId)) {
      approvals.push({ validator: id, status: 'disabled' });
      continue;
    }
    const sig = computeValidatorSignature(v.name, triad.index, actionName, payloadHash);
    approvals.push({ validator: id, status: 'signed', signature: sig });
  }
  const signedCount = approvals.filter(a => a.status === 'signed').length;
  return {
    triadFile: path.basename(triad.file),
    triadIndex: triad.index,
    approvals,
    consensus: signedCount >= 2,
    signedCount
  };
}

// ---------------- Public API ----------------
async function runProtectedAction(actionName, payload, executor) {
  if (typeof executor !== 'function') throw new Error('executor must be a function');
  const payloadCanonical = JSON.stringify(payload || {});
  const payloadHash = sha256Hex(Buffer.from(payloadCanonical));

  if (TRIADS.length < 2) {
    const msg = 'Insufficient triads loaded for dual consensus (need 2).';
    log({ type: 'consensus_aborted', action: actionName, reason: msg });
    if (FAIL_MODE === 'strict') throw new Error(msg);
    return executor();
  }

  const triadResults = TRIADS.map(t => performTriadConsensus(t, actionName, payloadHash));
  const allPassed = triadResults.every(r => r.consensus);

  log({ type: 'consensus_check', action: actionName, allPassed, triads: triadResults });

  if (!allPassed) {
    const failed = triadResults.filter(r => !r.consensus).map(r => `T${r.triadIndex}`).join(',');
    const msg = `Consensus failed in triads: ${failed}`;
    if (FAIL_MODE === 'strict') throw new Error(msg);
    return executor(); // lenient fallback
  }

  // All triads satisfied 2-of-3 => execute
  const started = Date.now();
  let result, error;
  try {
    result = await executor();
  } catch (e) {
    error = e;
  }
  log({ type: 'protected_action_executed', action: actionName, durationMs: Date.now() - started, ok: !error, error: error && error.message });
  if (error) throw error;
  return result;
}

function getConsensusSnapshot() {
  return {
    loadedTriads: TRIADS.length,
    triadFiles: TRIADS.map(t => ({ index: t.index, file: path.basename(t.file) })),
    disabled: Array.from(DISABLED)
  };
}

module.exports = {
  runProtectedAction,
  getConsensusSnapshot,
  _internal: { TRIADS } // exposed for diagnostics/tests
};

// If run directly, perform a self-test
if (require.main === module) {
  (async () => {
    try {
      console.log('[TRIAD] Self-test starting...', getConsensusSnapshot());
      const res = await runProtectedAction('self_test_action', { time: Date.now() }, () => 'SELF_TEST_OK');
      console.log('[TRIAD] Self-test result:', res);
    } catch (e) {
      console.error('[TRIAD] Self-test failed:', e.message);
      process.exitCode = 1;
    }
  })();
}
