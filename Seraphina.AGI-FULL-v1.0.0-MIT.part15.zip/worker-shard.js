// worker-shard.js
// Deterministic shard worker for Aurrelia pipeline
// Receives job snapshot & operates on assigned extranonce2 pattern: extranonce2 = base + workerIndex + loop*workerCount

const { parentPort, workerData } = require('worker_threads');
const crypto = require('crypto');
const MIDSTATE_OPT = process.env.MIDSTATE_OPT === '1';
let midstateModule = null;
if (MIDSTATE_OPT) {
  try { midstateModule = require('./midstate.js'); } catch(_) { /* fallback silently */ }
}
const MIDSTATE_WASM = process.env.MIDSTATE_WASM === '1';
let wasmMid = null;
if (MIDSTATE_WASM) {
  (async ()=> { try { wasmMid = require('./midstate_wasm.js'); await wasmMid.initWasm(); } catch(e){ /* disabled handled */ } })();
}
// Optional fused WASM hashing inside worker for aggregated latency histogram
const WORKER_FUSED = process.env.WORKER_FUSED === '1';
let fusedHash = null;
try { if (WORKER_FUSED){ fusedHash = require('./fused_wasm.js'); fusedHash.initFused && fusedHash.initFused().catch(()=>{}); } } catch(_) { fusedHash = null; }

// -------- Header Buffer Reuse Pool (optional) ---------------------------------
const ENABLE_HEADER_POOL = process.env.HEADER_POOL === '1';
let headerPool = [];
function acquireHeaderBuffer(){
  if (!ENABLE_HEADER_POOL) return Buffer.allocUnsafe(80);
  return headerPool.pop() || Buffer.allocUnsafe(80);
}
function releaseHeaderBuffer(buf){
  if (!ENABLE_HEADER_POOL) return; if (buf && buf.length === 80) headerPool.push(buf);
}
// Convert hex string (160 chars) into provided 80-byte buffer without interim allocations
function writeHexToBuffer(hex, buf){
  // Assume hex length 160
  for (let i=0,j=0;i<160;i+=2,j++){
    buf[j] = parseInt(hex[i] + hex[i+1],16);
  }
  return buf;
}

function reverseBytes(hex) { const b = Buffer.from(hex,'hex'); b.reverse(); return b.toString('hex'); }
function doubleSha256(hex) { const buf = Buffer.from(hex,'hex'); const h1 = crypto.createHash('sha256').update(buf).digest(); const h2 = crypto.createHash('sha256').update(h1).digest(); return h2.toString('hex'); }

function buildCoinbase(coinb1, extranonce1, extranonce2, coinb2) { return coinb1 + extranonce1 + extranonce2 + coinb2; }
function buildMerkleRoot(coinbaseTx, branches) { let m = doubleSha256(coinbaseTx); for (const br of (branches||[])) m = doubleSha256(m + br); return m; }
function buildBlockHeader(job, merkleRoot, nTime, nbits, nonce) {
  const reverse = reverseBytes;
  const ver = reverse(job.version.padStart(8,'0'));
  const prev = reverse(job.prevhash);
  const merk = reverse(merkleRoot);
  const time = reverse(nTime.padStart(8,'0'));
  const bts = reverse(nbits.padStart(8,'0'));
  const non = reverse(nonce.padStart(8,'0'));
  return ver+prev+merk+time+bts+non;
}
function nbitsToTarget(nbits){ const n=parseInt(nbits,16); const exp=n>>>24; const mant=n & 0xffffff; return BigInt(mant) << (8n*(BigInt(exp)-3n)); }

// Minimal octonion helpers (deterministic) — simplified for throughput
function hashToOctonion(str){ const h = crypto.createHash('sha256').update(str).digest('hex'); const coeffs = new Array(8).fill(0); for (let i=0;i<h.length;i+=2){ coeffs[(i/2)%8] += parseInt(h.slice(i,i+2),16)/255; } return coeffs; }

class SimpleOcto { constructor(c){ this.c = c; } norm(){ return Math.sqrt(this.c.reduce((s,v)=>s+v*v,0)); } }

const SYMBOLIC = process.env.SYMBOLIC_NODE_ENGINE === '1';
const SYMBOLIC_VM = process.env.SYMBOLIC_VM === '1'; // rich bytecode interpreter
// (constants replaced below with dynamic tuning block)
const BATCH_ATTEMPTS = parseInt(process.env.WORKER_BATCH || '200',10);
const FAST_PATH = process.env.FAST_PATH === '1'; // diagnostic fast hashing mode
const FAST_MODULUS = parseInt(process.env.FAST_MODULUS || '2',10);
const DIAG_FLUSH_OPP_INTERVAL = parseInt(process.env.DIAG_FLUSH_OPP_INTERVAL || '5000',10);
let WORKER_FUSED_BATCH = parseInt(process.env.WORKER_FUSED_BATCH || '64',10); // target fused batch size (worker-local)
let WORKER_MODULUS = parseInt(process.env.WORKER_MODULUS || '6',10); // frequency gating for work generation (dynamic)
if (FAST_PATH) WORKER_MODULUS = FAST_MODULUS;
let BATCH_FLUSH_INTERVAL_MS = parseInt(process.env.WORKER_BATCH_FLUSH_MS || '80',10); // force flush older fused batch (dynamic)
// New tunables for early warmup and norm gating refinement
const EARLY_FORCE_LIMIT = parseInt(process.env.EARLY_FORCE_LIMIT || '40',10); // total early forced headers before strict gating
const EARLY_FORCE_BATCH_MIN = parseInt(process.env.EARLY_FORCE_BATCH_MIN || '4',10); // minimal micro-batch size before flushing during warmup
let workerNormThreshold = parseFloat(process.env.WORKER_NORM_THRESHOLD || '6.5'); // dynamic norm acceptance threshold (will adapt)
const NORM_TARGET_LOW = parseFloat(process.env.WORKER_NORM_TARGET_LOW || '0.25');
const NORM_TARGET_HIGH = parseFloat(process.env.WORKER_NORM_TARGET_HIGH || '0.40');
const NORM_ADAPT_STEP = parseFloat(process.env.WORKER_NORM_ADAPT_STEP || '0.1');
const NORM_ADAPT_MIN = parseFloat(process.env.WORKER_NORM_ADAPT_MIN || '2.2');
const NORM_ADAPT_MAX = parseFloat(process.env.WORKER_NORM_ADAPT_MAX || '8.0');
const NORM_WARMUP_ATTEMPTS = parseInt(process.env.WORKER_NORM_WARMUP_ATTEMPTS || '200',10);
const NORM_ADAPT_INTERVAL_MS = parseInt(process.env.WORKER_NORM_ADAPT_INTERVAL_MS || '4000',10);
const FUSED_FLUSH_DEBUG = process.env.FUSED_FLUSH_DEBUG === '1'; // enable/disable debug flush logs entirely
let workerFusedEnabled = WORKER_FUSED; // dynamic toggling state
// Removed duplicate constant declarations (consolidated into dynamic vars above)
let fusedDebugCount = 0;
const HEARTBEAT_INTERVAL = parseInt(process.env.HEARTBEAT_INTERVAL || '2000',10); // ms
let lastHeartbeat = Date.now();
let sharedFreq = 432; // cooperative mesh shared frequency seed

let shardIndex = workerData.shardIndex;
let workerCount = workerData.workerCount;
let active = true;
let job = null;
let planeSeeds = [];
let romanSeed = '';
let bindHash = '';
let extranonce1 = '';
let cycleCount = 0; // logical cycles
let startNonceBase = 0; // reset on new job
let midstateVerified = false;
let midstateFailed = false;
// Harmonic partition acceptance stats (symbolic VM partitions h0..h3)
const partitionAcceptCounts = { h0:0, h1:0, h2:0, h3:0 };
const partitionAttemptCounts = { h0:0, h1:0, h2:0, h3:0 };
const partitionDecayFactor = 0.98; // periodic decay to avoid long-run dominance bias
let lastPartitionDecay = Date.now();
// Harmonic weight map (h0..h7 possible future) injected by parent; default equal weights
let harmonicWeights = { h0:1, h1:1, h2:1, h3:1 };
// Deterministic skip gating flag (enabled when parent sends WEIGHT_UPDATE)
let weightSkipActive = false;

// A. Mini-lattice per worker: deterministic lightweight node set for local feedback
const LATTICE_CAP = parseInt(process.env.WORKER_LATTICE_CAP || '128',10);
const lattice = []; // { id, freq, successes, attempts }

function latticeNodeFor(extranonce2){
  const id = extranonce2 % LATTICE_CAP;
  let n = lattice[id];
  if (!n){
    // deterministic initial freq from hash of id+jobId (if job present)
    const seedBase = (job? job.jobId: 'seed') + ':' + id;
    const h = crypto.createHash('sha256').update(seedBase).digest();
    const freq = 400 + (h[0] % 65); // 400..464 deterministic
    n = lattice[id] = { id, freq, successes:0, attempts:0 };
  }
  return n;
}

function latticeFeedback(node, success, sweepSeed){
  node.attempts++;
  if (success) node.successes++;
  if (node.attempts && node.attempts % 32 === 0){
    const rate = node.successes / node.attempts;
    if (rate < 0.01){
      // gentle deterministic modulation using sweepSeed and sharedFreq
      node.freq = (node.freq * 0.9) + ((432 + (sweepSeed % 96)) * 0.1);
    } else if (rate > 0.05){
      node.freq = (node.freq * 0.95) + (sharedFreq * 0.05);
    }
    node.successes = 0; node.attempts = 0;
  }
}

// E. Symbolic VM: deterministic mini-bytecode interpreter for acceptance filtering
let vmProgram = null; // legacy single program
let vmProgramsByHarmonic = new Map(); // harmonic -> ops array
const { adjustVmPrograms, VM_MAX_STEPS } = require('./vm-adaptive.js');

function compileVmProgram(harmonicTag){
  if (!job) return;
  const keySeed = job.jobId + romanSeed + bindHash + (harmonicTag||'base');
  const progSeed = crypto.createHash('sha256').update(keySeed).digest('hex');
  const ops = [];
  for (let i=0;i<progSeed.length && ops.length < VM_MAX_STEPS; i++){
    const nib = parseInt(progSeed[i],16);
    const opcode = nib % 8;
    const cIdx = (i+1) % progSeed.length;
    const cVal = parseInt(progSeed.slice(cIdx, cIdx+2),16) || nib;
    ops.push({ opcode, c: cVal });
  }
  if (!ops.some(o=>o.opcode === 7)) ops[ops.length-1].opcode = 7;
  if (harmonicTag){
    vmProgramsByHarmonic.set(harmonicTag, ops);
  } else {
    vmProgram = ops;
  }
  return ops;
}

function getHarmonicTag(seed){
  // derive a pseudo harmonic partition tag from seed high nibble (0..3)
  const hNib = parseInt(seed[0],16) % 4; // 4 partitions
  return 'h'+hNib;
}

function runVm(seed, nonce){
  if (vmProgramsByHarmonic.size === 0 && !vmProgram){
    // precompile four harmonic partitions
    for (let i=0;i<4;i++) compileVmProgram('h'+i);
  }
  const tag = getHarmonicTag(seed);
  // Deterministic probabilistic skip based on harmonic weight (load shaping)
  if (weightSkipActive){
    // Normalize weight to [0,1]; if weight lower => higher skipProb
    const w = harmonicWeights[tag] != null ? harmonicWeights[tag] : 1;
    // Derive a deterministic pseudo-random fraction from seed + nonce (no Math.random)
    const hDet = crypto.createHash('sha256').update(seed + ':' + nonce.toString(16)).digest();
    const frac = hDet.readUInt32BE(0) / 0xffffffff; // [0,1)
    // skipProb formula: skip when frac > w (so weight 0.3 keeps ~30% of work)
    if (frac > w){
      return false; // skip early before VM ops
    }
  }
  partitionAttemptCounts[tag] = (partitionAttemptCounts[tag]||0)+1;
  let ops = vmProgramsByHarmonic.get(tag);
  if (!ops){ ops = compileVmProgram(tag); }
  const baseHash = crypto.createHash('sha256').update(seed + nonce.toString(16)).digest('hex');
  let h = parseInt(baseHash.slice(0,8),16) >>> 0;
  for (const op of ops){
    switch(op.opcode){
      case 0: { // ROTL
        const r = op.c & 31; h = ((h << r) | (h >>> (32-r))) >>> 0; break; }
      case 1: { // XORC
        h = (h ^ ((op.c * 0x9e37) >>> 0)) >>> 0; break; }
      case 2: { // ADDC
        h = (h + op.c * 65793) >>> 0; break; }
      case 3: { // SUBC
        h = (h - (op.c * 1315423911)) >>> 0; break; }
      case 4: { // MIX
        h ^= h >>> 13; h = (h * 0x85ebca6b) >>> 0; h ^= h >>> 16; break; }
      case 5: { // SLICE
        const hh = crypto.createHash('sha256').update(baseHash + op.c.toString(16)).digest('hex');
        h = parseInt(hh.slice(0,8),16) >>> 0; break; }
      case 6: { // FOLD
        h = ((h & 0xffff) ^ (h >>> 16)) >>> 0; break; }
      case 7: { // MASK (decision)
        const leading = (op.c % 5) + 3; // 3..7 zero bits requirement
        const mask = (1 << leading) - 1;
        const passed = (h & mask) === 0;
        if (passed) partitionAcceptCounts[tag] = (partitionAcceptCounts[tag]||0)+1;
        return passed; }
    }
  }
  return false; // fallback reject if no mask executed
}

function compositeSeed(extranonce2Hex, planeSeed){
  return job.jobId + extranonce2Hex + planeSeed + romanSeed + bindHash;
}

// B. Midstate optimization: if MIDSTATE_OPT enabled, we precompute midstate for the first 64 bytes of the header
// (version|prevhash|merkleRoot first 28 bytes). Because extranonce2 affects merkleRoot, we compute per attempt.
// Still beneficial: we avoid second compression of the first block for double SHA.
function generateNonce(seed, nTimeHex){
  const h = crypto.createHash('sha256').update(seed + nTimeHex).digest();
  const nonce = h.readUInt32BE(0) >>> 0; // first 4 bytes
  const oct = new SimpleOcto(hashToOctonion(seed));
  return { nonce, norm: oct.norm() };
}

parentPort.on('message', (msg)=>{
  if (msg.type === 'JOB'){ // new job snapshot
    job = msg.job;
    planeSeeds = msg.planeSeeds;
    romanSeed = msg.romanSeed;
    bindHash = msg.bindHash;
    extranonce1 = msg.extranonce1;
    startNonceBase = 0;
    cycleCount = 0;
    // Precompute static coinbase prefix/suffix buffers for faster concat
    try {
      job.__coinbPrefix = job.coinb1 + extranonce1; // extranonce2 inserted between prefix and coinb2
      job.__coinbSuffix = job.coinb2;
      job.__merkBranches = (job.merkle_branch || []).slice();
    } catch(_) { job.__coinbPrefix = job.coinb1; job.__coinbSuffix = job.coinb2; job.__merkBranches = job.merkle_branch || []; }
    if (msg.sharedFreq) sharedFreq = msg.sharedFreq; // adopt cooperative frequency
    vmProgram = null; vmProgramsByHarmonic.clear(); // invalidate on new job
  } else if (msg.type === 'MESH_FREQ') {
    // deterministic average blend
    const incoming = msg.freq;
    sharedFreq = (sharedFreq * 3 + incoming) / 4; // soft convergence
  } else if (msg.type === 'STOP') {
    active = false;
  } else if (msg.type === 'TUNE_WORKER') {
    if (typeof msg.modulus === 'number' && msg.modulus >=1 && msg.modulus <= 1000) WORKER_MODULUS = msg.modulus|0;
    if (typeof msg.flushMs === 'number' && msg.flushMs >=5 && msg.flushMs <= 5000) BATCH_FLUSH_INTERVAL_MS = msg.flushMs|0;
    if (typeof msg.normThreshold === 'number' && msg.normThreshold > 0) workerNormThreshold = msg.normThreshold;
  } else if (msg.type === 'FUSED_MODE') {
    if (typeof msg.enabled === 'boolean') {
      workerFusedEnabled = msg.enabled;
    }
  } else if (msg.type === 'WEIGHT_UPDATE') {
    if (msg.weights && typeof msg.weights === 'object'){
      harmonicWeights = { ...harmonicWeights, ...msg.weights };
      weightSkipActive = true;
      // Optional: cap weights to [0,1]
      for (const k of Object.keys(harmonicWeights)){
        let v = harmonicWeights[k];
        if (typeof v !== 'number' || !isFinite(v)) v = 1;
        harmonicWeights[k] = Math.max(0, Math.min(1, v));
      }
      if (global.__AUR_WORKER_TOTAL_FLUSHES < 4){
        console.log(`[Shard ${shardIndex}] weight update received: ${Object.entries(harmonicWeights).map(([k,v])=>k+'='+v.toFixed(2)).join(', ')}`);
      }
    }
  } else if (msg.type === 'NORM_THRESHOLD') {
    if (typeof msg.value === 'number' && isFinite(msg.value) && msg.value > 0){
      const prev = workerNormThreshold;
      workerNormThreshold = msg.value;
      if (Math.abs(prev - workerNormThreshold) > 0.05 && global.__AUR_WORKER_TOTAL_FLUSHES < 8){
        console.log(`[Shard ${shardIndex}] normThreshold broadcast -> ${workerNormThreshold.toFixed(3)}`);
      }
    }
  }
});

async function loop(){
  if (!active) return parentPort.postMessage({ type:'EXIT' });
  if (!job){ setTimeout(loop,25); return; }

  let hashes=0; let shares=[]; let bytes=0;
  const batchHeaders = [];
  const batchMeta = [];// {extranonce2Hex,nTimeHex,nonceHex,target,node}
  let batchAttempted = 0; // constructed this iteration
  let batchOpportunity = 0; // pre-gating iterations (doWork checks) this iteration
  let lastFlushCount = 0;
  // Persistent worker-wide counters (lifetime of worker)
  if (global.__AUR_WORKER_TOTAL_ATTEMPTED == null) global.__AUR_WORKER_TOTAL_ATTEMPTED = 0;
  if (global.__AUR_WORKER_TOTAL_OPP == null) global.__AUR_WORKER_TOTAL_OPP = 0;
  if (global.__AUR_WORKER_TOTAL_FORCED == null) global.__AUR_WORKER_TOTAL_FORCED = 0;
  if (global.__AUR_WORKER_TOTAL_FLUSHES == null) global.__AUR_WORKER_TOTAL_FLUSHES = 0;
  if (global.__AUR_WORKER_LAST_FUSED_FLUSH == null) global.__AUR_WORKER_LAST_FUSED_FLUSH = Date.now();
  if (global.__AUR_WORKER_NORM_ACCEPT == null) global.__AUR_WORKER_NORM_ACCEPT = 0;
  if (global.__AUR_WORKER_NORM_REJECT == null) global.__AUR_WORKER_NORM_REJECT = 0;
  if (global.__AUR_WORKER_SYM_ACCEPT == null) global.__AUR_WORKER_SYM_ACCEPT = 0;
  if (global.__AUR_WORKER_SYM_REJECT == null) global.__AUR_WORKER_SYM_REJECT = 0;
  if (global.__AUR_WORKER_NORM_ACCUM == null) global.__AUR_WORKER_NORM_ACCUM = 0;
  if (global.__AUR_WORKER_NORM_REJ_ACCUM == null) global.__AUR_WORKER_NORM_REJ_ACCUM = 0;
  if (global.__AUR_WORKER_LAST_NORM_ADAPT == null) global.__AUR_WORKER_LAST_NORM_ADAPT = Date.now();
  // NOTE: doWork must be recomputed per iteration (previous static placement caused under-attempting)
  function flushFusedBatch(reason){
    if (!workerFusedEnabled || !fusedHash){
      if (reason === 'diag') console.log(`[Shard ${shardIndex}] diag flush skipped (fused disabled)`);
      return;
    }
    if (!batchHeaders.length){
      if (reason === 'diag') console.log(`[Shard ${shardIndex}] diag flush: no headers accumulated`);
      return; // nothing to hash
    }
    if (batchAttempted && hashes === 0 && (reason === 'early' || reason === 'capacity')){
      if (global.__AUR_WORKER_TOTAL_FLUSHES < 8){
        console.log(`[Shard ${shardIndex}] flushing batch size=${batchHeaders.length} attempted(batch)=${batchAttempted} totalAttempted=${global.__AUR_WORKER_TOTAL_ATTEMPTED} reason=${reason}`);
      }
    }
    const start = process.hrtime.bigint();
    let digests;
    try { digests = fusedHash.doubleSha256Batch(batchHeaders).map(b=> b.toString('hex')); }
    catch(e){ digests = batchHeaders.map(buf=> doubleSha256(buf.toString('hex'))); }
    const end = process.hrtime.bigint();
    const batchNs = Number(end - start);
    const perHeaderNs = batchHeaders.length ? batchNs / batchHeaders.length : 0;
    parentPort.postMessage({ type:'FUSED_STATS', shardIndex, perHeaderNs: Math.round(perHeaderNs), count: batchHeaders.length, totalNs: batchNs });
    if (FUSED_FLUSH_DEBUG){
      // Only first few to avoid spam
      if (global.___flushDbgCount == null) global.___flushDbgCount = 0;
      if (global.___flushDbgCount < 6) { console.log(`[Shard ${shardIndex}] flush size=${batchHeaders.length} reason=${reason||'fill'} ns=${batchNs}`); global.___flushDbgCount++; }
    }
    lastFlushCount = batchHeaders.length;
    global.__AUR_WORKER_LAST_FUSED_FLUSH = Date.now();
    global.__AUR_WORKER_TOTAL_FLUSHES++;
    for (let i=0;i<digests.length;i++){
      const meta = batchMeta[i];
      const headerHash = digests[i];
      const hashInt = BigInt('0x'+ reverseBytes(headerHash));
      bytes += Buffer.byteLength(headerHash,'hex');
      latticeFeedback(meta.nodeRef, hashInt <= meta.target, meta.ex2Base);
      if (hashInt <= meta.target){ shares.push({ extranonce2Hex: meta.extranonce2Hex, nTimeHex: meta.nTimeHex, nonceHex: meta.nonceHex }); }
      hashes++;
    }
    // Return buffers to pool
    for (const hb of batchHeaders) releaseHeaderBuffer(hb);
    batchHeaders.length = 0; batchMeta.length = 0;
  }
  const effectiveLoops = FAST_PATH ? Math.min(64, BATCH_ATTEMPTS) : BATCH_ATTEMPTS;
  for (let i=0;i<effectiveLoops;i++){
    batchOpportunity++;
    const doWork = FAST_PATH || (cycleCount % WORKER_MODULUS) === 0;
    const extranonce2 = startNonceBase + shardIndex + (cycleCount * workerCount);
    const extranonce2Hex = extranonce2.toString(16).padStart((job.extranonce2Size||8)*2,'0');
    // Faster coinbase assembly using precomputed prefix/suffix
    const coinbaseTx = job.__coinbPrefix + extranonce2Hex + job.__coinbSuffix;
    // Merkle root: compute coinbase hash once then fold branches (avoid rebuild array each time)
    let merkleRoot = doubleSha256(coinbaseTx);
    const branches = job.__merkBranches;
    for (let bi=0; bi<branches.length; bi++){
      merkleRoot = doubleSha256(merkleRoot + branches[bi]);
    }
    if (doWork){
      const planeSeed = planeSeeds.length ? planeSeeds[(extranonce2) % planeSeeds.length] : romanSeed;
      const seed = compositeSeed(extranonce2Hex, planeSeed);
      const nTimeHex = (parseInt(job.ntime,16) + extranonce2).toString(16).padStart(8,'0');
      // Mini-lattice integration
      const node = latticeNodeFor(extranonce2);
      // Deterministic modulation with node.freq & sharedFreq
      const freqMix = ((node.freq + sharedFreq) / 2).toFixed(2);
      const modSeed = seed + freqMix;
      const gen = generateNonce(modSeed, nTimeHex);
      const normOk = FAST_PATH ? true : (gen.norm <= workerNormThreshold);
      const forceEarly = global.__AUR_WORKER_TOTAL_ATTEMPTED < EARLY_FORCE_LIMIT;
      if (forceEarly && global.__AUR_WORKER_TOTAL_FORCED < Math.min(10, EARLY_FORCE_LIMIT)){
        global.__AUR_WORKER_TOTAL_FORCED++;
        console.log(`[Shard ${shardIndex}] early-forced header norm=${gen.norm.toFixed(3)} totalForced=${global.__AUR_WORKER_TOTAL_FORCED}`);
      }
      if (normOk || forceEarly){
        if (normOk){
          global.__AUR_WORKER_NORM_ACCEPT++;
          global.__AUR_WORKER_NORM_ACCUM += gen.norm;
        } else {
          // forced acceptance outside norm threshold (warmup)
          global.__AUR_WORKER_NORM_REJECT++; // track as would-be reject
          global.__AUR_WORKER_NORM_REJ_ACCUM += gen.norm;
        }
        let acceptedSymbolic = true;
        if (SYMBOLIC_VM && !FAST_PATH) {
          acceptedSymbolic = runVm(seed, gen.nonce);
        } else if (SYMBOLIC) {
          acceptedSymbolic = symbolicAccept(seed, gen.nonce);
        }
        if (FAST_PATH) acceptedSymbolic = true; // override
        if (forceEarly) acceptedSymbolic = true; // bypass symbolic during warmup
        if (acceptedSymbolic){
          if (!forceEarly) global.__AUR_WORKER_SYM_ACCEPT++; else global.__AUR_WORKER_SYM_ACCEPT++;
          const nonceHex = gen.nonce.toString(16).padStart(8,'0');
          let headerHex = buildBlockHeader(job, merkleRoot, nTimeHex, job.nbits, nonceHex);
          let headerHash;
          if (MIDSTATE_WASM && wasmMid && !midstateFailed){
            try {
              const headerBuf = Buffer.from(headerHex,'hex');
              const first64 = headerBuf.subarray(0,64);
              const tail16 = headerBuf.subarray(64,80);
              const dsha = await wasmMid.doubleSha256MidWasm(first64, tail16);
              headerHash = dsha.toString('hex');
              if (!midstateVerified){
                const ref = doubleSha256(headerHex);
                if (ref !== headerHash){ midstateFailed = true; headerHash = ref; } else midstateVerified = true;
              }
            } catch(e){ headerHash = doubleSha256(headerHex); midstateFailed = true; }
          } else if (MIDSTATE_OPT && midstateModule && !midstateFailed){
            try {
              // First 64 bytes + tail16
              const headerBuf = Buffer.from(headerHex,'hex');
              const first64 = headerBuf.subarray(0,64);
              const tail16 = headerBuf.subarray(64,80);
              const dsha = midstateModule.doubleSha256WithMidstate(first64, tail16);
              headerHash = dsha.toString('hex');
              if (!midstateVerified){
                // Cross-check against full double SHA for integrity once
                const ref = doubleSha256(headerHex);
                if (ref !== headerHash){
                  midstateFailed = true; // disable future use
                  headerHash = ref; // fallback
                } else {
                  midstateVerified = true;
                }
              }
            } catch(e){
              headerHash = doubleSha256(headerHex);
              midstateFailed = true;
            }
          } else {
            headerHash = doubleSha256(headerHex);
          }
          const target = nbitsToTarget(job.nbits);
          if (workerFusedEnabled && fusedHash){
            const hBuf = acquireHeaderBuffer();
            writeHexToBuffer(headerHex, hBuf);
            batchHeaders.push(hBuf);
            batchMeta.push({ extranonce2Hex, nTimeHex, nonceHex, target, nodeRef: node, ex2Base: extranonce2 });
            batchAttempted++;
            global.__AUR_WORKER_TOTAL_ATTEMPTED++;
            bytes += Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(coinbaseTx,'hex');
            if (batchHeaders.length >= WORKER_FUSED_BATCH) flushFusedBatch('capacity');
            else if (forceEarly && batchHeaders.length >= EARLY_FORCE_BATCH_MIN) flushFusedBatch('early');
          } else {
            const hashInt = BigInt('0x' + reverseBytes(headerHash));
            hashes++;
            bytes += Buffer.byteLength(headerHex,'hex') + Buffer.byteLength(headerHash,'hex') + Buffer.byteLength(coinbaseTx,'hex');
            if (hashInt <= target){
              shares.push({ extranonce2Hex, nTimeHex, nonceHex });
              latticeFeedback(node, true, extranonce2);
            } else {
              latticeFeedback(node, false, extranonce2);
            }
            if (FAST_PATH && hashes < 5 && batchAttempted === 0){
              console.log(`[Shard ${shardIndex}] direct-hash fallback headerHash=${headerHash.slice(0,16)}..`);
            }
          }
        } else {
          if (normOk && !forceEarly) global.__AUR_WORKER_SYM_REJECT++;
        }
      }
      else {
        // Direct norm rejection (not early forced)
        global.__AUR_WORKER_NORM_REJECT++;
        global.__AUR_WORKER_NORM_REJ_ACCUM += gen.norm;
      }
    } else {
      bytes += Buffer.byteLength(coinbaseTx,'hex') + 32; // approximate
    }
    cycleCount++;
  }
  // Diagnostic forced flush if many opportunity attempts with zero constructed
  if (FAST_PATH || (batchOpportunity && batchOpportunity % DIAG_FLUSH_OPP_INTERVAL === 0 && batchAttempted === 0)){
    flushFusedBatch('diag');
  }
  if (FAST_PATH && batchAttempted === 0){
    if (cycleCount % 500 === 0){
      console.log(`[Shard ${shardIndex}] FAST_PATH no-attempt yet cycle=${cycleCount} opp=${batchOpportunity}`);
    }
  }
  // Automatic fallback: if we've done many cycles with zero attempted headers, disable fused and force direct hashing
  if (cycleCount > 2000 && batchAttempted === 0 && workerFusedEnabled){
    workerFusedEnabled = false;
    console.log(`[Shard ${shardIndex}] AUTO-DISABLE fused path (no attempted headers after ${cycleCount} cycles)`);
  }
  if (workerFusedEnabled && fusedHash && batchHeaders.length && (Date.now()-global.__AUR_WORKER_LAST_FUSED_FLUSH) >= BATCH_FLUSH_INTERVAL_MS){ flushFusedBatch('age'); }
  if (workerFusedEnabled && fusedHash && batchHeaders.length) flushFusedBatch('tail');
  global.__AUR_WORKER_TOTAL_OPP += batchOpportunity;
  // Adaptive norm threshold: only after warmup & on interval
  const nowAdapt = Date.now();
  const normAttempts = global.__AUR_WORKER_NORM_ACCEPT + global.__AUR_WORKER_NORM_REJECT;
  if (normAttempts > NORM_WARMUP_ATTEMPTS && (nowAdapt - global.__AUR_WORKER_LAST_NORM_ADAPT) >= NORM_ADAPT_INTERVAL_MS){
    const acceptRate = normAttempts ? (global.__AUR_WORKER_NORM_ACCEPT / normAttempts) : 0;
    const prev = workerNormThreshold;
    if (acceptRate > NORM_TARGET_HIGH){
      // too permissive -> tighten
      workerNormThreshold = Math.max(NORM_ADAPT_MIN, workerNormThreshold - NORM_ADAPT_STEP);
    } else if (acceptRate < NORM_TARGET_LOW){
      // too strict -> relax
      workerNormThreshold = Math.min(NORM_ADAPT_MAX, workerNormThreshold + NORM_ADAPT_STEP);
    }
    if (prev !== workerNormThreshold && global.__AUR_WORKER_TOTAL_FLUSHES < 8){
      console.log(`[Shard ${shardIndex}] adapt normThreshold ${prev.toFixed(2)} -> ${workerNormThreshold.toFixed(2)} acceptRate=${(acceptRate*100).toFixed(1)}%`);
    }
    global.__AUR_WORKER_LAST_NORM_ADAPT = nowAdapt;
  }
  parentPort.postMessage({ type:'BATCH', hashes, shares, bytes, cycleCount, sharedFreq, attempted: batchAttempted, oppAttempts: batchOpportunity, lastFlush: lastFlushCount, partitions: { attempts: partitionAttemptCounts, accepts: partitionAcceptCounts }, gating: {
    normAccept: global.__AUR_WORKER_NORM_ACCEPT,
    normReject: global.__AUR_WORKER_NORM_REJECT,
    symAccept: global.__AUR_WORKER_SYM_ACCEPT,
    symReject: global.__AUR_WORKER_SYM_REJECT,
    normAvg: global.__AUR_WORKER_NORM_ACCEPT ? (global.__AUR_WORKER_NORM_ACCUM / global.__AUR_WORKER_NORM_ACCEPT) : 0,
    normRejAvg: global.__AUR_WORKER_NORM_REJECT ? (global.__AUR_WORKER_NORM_REJ_ACCUM / global.__AUR_WORKER_NORM_REJECT) : 0,
    normThreshold: workerNormThreshold,
    weightSkipActive,
    harmonicWeights
  }});
  setImmediate(loop);
}

function symbolicAccept(seed, nonce){
  const sig = crypto.createHash('sha256').update(seed + nonce.toString(16)).digest();
  // Deterministic 1/8 pass probability using first 3 bits but stable
  return (sig[0] & 0x07) === 0;
}

loop();
