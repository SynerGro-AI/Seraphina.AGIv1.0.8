// Tamper-Evident Append-Only Log
// Each line is JSON: { ts, type, data, prevHash, hash }
// hash = sha256( JSON.stringify({ts,type,data,prevHash}) )
// Provides append + verify utilities.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class TamperLog {
  constructor(filename = 'share-log.chain.jsonl') {
    this.dir = path.join(__dirname, 'persistent_data');
    if (!fs.existsSync(this.dir)) fs.mkdirSync(this.dir, { recursive: true });
    this.file = path.join(this.dir, filename);
    this.prevHash = this._loadLastHash();
  }

  _loadLastHash(){
    try {
      if(!fs.existsSync(this.file)) return null;
      const fd = fs.openSync(this.file, 'r');
      const stat = fs.fstatSync(fd);
      const size = stat.size;
      if(size === 0){ fs.closeSync(fd); return null; }
      // Read last 8KB slice to find final line
      const slice = Math.min(size, 8192);
      const buf = Buffer.alloc(slice);
      fs.readSync(fd, buf, 0, slice, size - slice);
      fs.closeSync(fd);
      const lines = buf.toString('utf8').trim().split(/\n+/);
      const lastLine = lines[lines.length - 1];
      const obj = JSON.parse(lastLine);
      return obj.hash || null;
    } catch { return null; }
  }

  append(type, data){
    const entryCore = { ts: Date.now(), type, data, prevHash: this.prevHash };
    const hash = crypto.createHash('sha256').update(JSON.stringify(entryCore)).digest('hex');
    const entry = { ...entryCore, hash };
    fs.appendFileSync(this.file, JSON.stringify(entry) + '\n');
    this.prevHash = hash;
    return entry;
  }

  verify(){
    if(!fs.existsSync(this.file)) return { ok:true, entries:0 };
    const lines = fs.readFileSync(this.file,'utf8').trim().split(/\n+/).filter(Boolean);
    let prev = null; let idx = 0;
    for(const line of lines){
      idx++;
      let obj; try { obj = JSON.parse(line); } catch { return { ok:false, error:'PARSE_FAIL', index: idx }; }
      if(obj.prevHash !== prev) return { ok:false, error:'CHAIN_BREAK', index: idx };
      const core = { ts: obj.ts, type: obj.type, data: obj.data, prevHash: obj.prevHash };
      const h = crypto.createHash('sha256').update(JSON.stringify(core)).digest('hex');
      if(h !== obj.hash) return { ok:false, error:'HASH_MISMATCH', index: idx };
      prev = obj.hash;
    }
    return { ok:true, entries: lines.length, head: prev };
  }
}

function createLogger(name){ return new TamperLog(name); }

module.exports = { TamperLog, createLogger };
