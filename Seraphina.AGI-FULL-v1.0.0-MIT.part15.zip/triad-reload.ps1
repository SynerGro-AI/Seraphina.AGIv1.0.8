<#!
Triad Reload Helper Script
Performs authenticated hot reload of triad consensus loader and optionally fetches diff.
Usage:
  # Set env vars first:
  $env:TRIAD_RELOAD_KEY = "yourKey"; $env:TRIAD_RELOAD_SECRET = "yourSecret"
  # Run reload only
  ./triad-reload.ps1
  # Run reload then diff
  ./triad-reload.ps1 -Diff
Parameters:
  -Url  (default http://localhost:8888)
  -Diff (switch) fetch /api/triad/diff after reload
Falls back to SHARE_API_KEY/SHARE_API_SECRET if TRIAD_RELOAD_* not set.
!#>
param(
  [string]$Url = 'http://localhost:8888',
  [switch]$Diff,
  [switch]$Quiet
)

function Write-Info($msg){ if(-not $Quiet){ Write-Host "[TRIAD] $msg" -ForegroundColor Cyan } }
function Write-Err($msg){ Write-Host "[TRIAD:ERROR] $msg" -ForegroundColor Red }

$key = $env:TRIAD_RELOAD_KEY
$secret = $env:TRIAD_RELOAD_SECRET
if(-not $key){ $key = $env:SHARE_API_KEY }
if(-not $secret){ $secret = $env:SHARE_API_SECRET }
if(-not $key -or -not $secret){ Write-Err "TRIAD_RELOAD_KEY/SECRET (or SHARE_API_KEY/SECRET fallback) not set"; exit 2 }

$ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$msg = "POST:/api/triad/reload:$ts"
try {
  $hmac = New-Object System.Security.Cryptography.HMACSHA256 ([Text.Encoding]::UTF8.GetBytes($secret))
  $hashBytes = $hmac.ComputeHash([Text.Encoding]::UTF8.GetBytes($msg))
  $sig = -join ($hashBytes | ForEach-Object { $_.ToString('x2') })
} catch {
  Write-Err "HMAC generation failed: $($_.Exception.Message)"; exit 3
}
Write-Info "Message=$msg"
Write-Info "Signature=$sig"

$headers = @{ 'x-api-key'=$key; 'x-ts'=$ts; 'x-sign'=$sig }
$reloadUrl = ($Url.TrimEnd('/')) + '/api/triad/reload'
try {
  Write-Info "POST $reloadUrl"
  $resp = Invoke-RestMethod -Uri $reloadUrl -Method Post -Headers $headers -ErrorAction Stop
  Write-Host (ConvertTo-Json $resp -Depth 6) -ForegroundColor Green
} catch {
  Write-Err "Reload request failed: $($_.Exception.Message)"; exit 4
}

if($Diff){
  Start-Sleep -Seconds 1
  $diffUrl = ($Url.TrimEnd('/')) + '/api/triad/diff'
  Write-Info "GET $diffUrl"
  try {
    $d = Invoke-RestMethod -Uri $diffUrl -Method Get -ErrorAction Stop
    # Compact output: list validators and identical flag
    $report = $d.report
    if($report){
      foreach($k in $report.Keys){
        $v = $report[$k]
        Write-Host ("{0}: identical={1} primaryHash={2} altHash={3}" -f $k, $v.identical, $v.primaryHash, $v.alternateHash) -ForegroundColor Yellow
        if(-not $v.identical -and $v.diff){
          Write-Host '--- Unified Diff ---' -ForegroundColor DarkYellow
          Write-Host $v.diff
        }
      }
    } else {
      Write-Host (ConvertTo-Json $d -Depth 6)
    }
  } catch {
    Write-Err "Diff retrieval failed: $($_.Exception.Message)"; exit 5
  }
}
