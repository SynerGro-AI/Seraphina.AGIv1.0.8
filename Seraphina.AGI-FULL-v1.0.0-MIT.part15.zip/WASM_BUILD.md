# SHA256 Midstate WASM Build Guide

This project includes an optimized single-block SHA-256 compression routine (`wasm/sha256_mid.c`) intended to accelerate midstate and full 80-byte Bitcoin block header double-hashing. Your self‑test output:

```
[midstate-wasm] init failed: sha256_mid.wasm missing
{"total":200,"mismatches":0,"wasmAvailable":false,"avgRefNs":28362,"avgFastNs":118087}
```

indicates the WebAssembly module has not been compiled yet. Follow the steps below for both Debian (target install) and Windows (dev box) environments.

---
## 1. Prerequisites

### Debian / Ubuntu (Cinnamon, MSI Python flavored Debian derivative)
Install build essentials and git:
```
sudo apt update
sudo apt install -y build-essential git cmake python3 curl nodejs npm
```
(If your distro ships an older Node, consider installing an LTS from NodeSource.)

### Windows (current dev machine)
Install:
- Latest Node.js (>=18)
- Git for Windows
- (Optional) WSL2 Ubuntu for native build parity

---
## 2. Install Emscripten (emsdk)
Emscripten is required for `emcc` (the compiler invoked by `npm run build:wasm`).

### Debian
```
mkdir -p $HOME/opt && cd $HOME/opt
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
./emsdk install latest
./emsdk activate latest
source ./emsdk_env.sh
```
Add to shell init (`~/.bashrc` or `~/.zshrc`):
```
source "$HOME/opt/emsdk/emsdk_env.sh"
```
Verify:
```
emcc --version
```

### Windows PowerShell (Native)
```
mkdir $HOME\opt; cd $HOME\opt
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
./emsdk install latest
./emsdk activate latest
./emsdk_env.ps1
```
Add to your profile (`notepad $PROFILE`) and append:
```
& "$HOME/opt/emsdk/emsdk_env.ps1"
```
Verify:
```
emcc --version
```

### Windows via WSL (Recommended for parity)
Perform the Debian steps inside WSL.

---
## 3. Build the WASM Module
From the project root (`mining/` directory):
```
npm run build:wasm
```
This runs:
```
emcc wasm/sha256_mid.c -O3 -s STANDALONE_WASM -s EXPORTED_FUNCTIONS='[_sha256_compress,_wasm_malloc,_wasm_free]' -s EXPORTED_RUNTIME_METHODS='[cwrap,ccall]' -o sha256_mid.wasm
```
Expected output: a new file `sha256_mid.wasm` in the project root.

If you see an error like `emcc: command not found`, ensure the environment script (`emsdk_env.sh` or `emsdk_env.ps1`) has been sourced in the current shell.

---
## 4. Re-run Self-Test
```
npm run test:midstate
```
Successful run (example):
```
{"total":200,"mismatches":0,"wasmAvailable":true,"avgRefNs":28362,"avgFastNs":9500}
```
(Your exact timings will differ by CPU.)

If `wasmAvailable` is still `false`:
- Confirm `sha256_mid.wasm` exists in the same directory as `midstate_wasm.js` expects (project root).
- Remove any stale file with size 0 and rebuild.
- Check Node version (must support WebAssembly.instantiate streaming or fallback path).

---
## 5. Optional: Deterministic Rebuild / Cache Busting
If you modify `wasm/sha256_mid.c`, just rebuild:
```
npm run build:wasm
```
To force a clean environment (rarely needed):
```
rm -f sha256_mid.wasm
npm run build:wasm
```

---
## 6. Integrating WASM Hashing Into Main Pipeline (Future Enhancement)
Currently `aurrelia-pico-mesh-miner.js` uses the pure JS `doubleSha256` for block headers. To exploit the WASM path:
1. Import the WASM helper (e.g. `const { doubleHash80 } = require('./midstate_wasm');` if you expose such a function).
2. Replace the pure JS call with the WASM accelerated function when `wasmReady` flag is true.
3. Maintain a fallback guard: if WASM throws or integrity test fails, revert to JS.

If you’d like, I can wire this in for you—just ask.

---
## 7. Troubleshooting
| Symptom | Cause | Fix |
|---------|-------|-----|
| `init failed: sha256_mid.wasm missing` | Module not built or wrong path | Run build, verify presence. |
| `ReferenceError: WebAssembly` | Ancient Node version | Upgrade Node >= 16 (prefer 18+). |
| High `avgFastNs` slower than ref | CPU warm-up / no midstate reuse | Run again; integrate midstate path in main miner. |
| Mismatches > 0 | Build corruption / code change | Rebuild; run `npm run test:midstate` again. |

---
## 8. Systemd Service Example (Debian)
Create `/etc/systemd/system/aurrelia-miner.service`:
```
[Unit]
Description=Aurrelia Deterministic Miner
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/aurrelia/mining
ExecStart=/usr/bin/env METRICS=1 SYMBOLIC_VM=1 MULTI_HARMONIC=1 NODE_ENV=production node aurrelia-pico-mesh-miner.js
Restart=on-failure
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
```
Reload + enable:
```
sudo systemctl daemon-reload
sudo systemctl enable --now aurrelia-miner
```

Prometheus exporter (optional separate service):
```
[Service]
Type=simple
WorkingDirectory=/opt/aurrelia/mining
ExecStart=/usr/bin/env METRICS_LOG=aurrelia-metrics.jsonl node prometheus-exporter.js
Restart=always
```

---
## 9. Scaling Note ("400GB sets of 8 Aurrelia")
If you plan to stage 400 GB of shard data across octets of nodes:
- Use a directory layout: `data/shard-{000..NNN}/plane-{0..3}/partitions/`
- Memory map or stream to avoid GC pressure (consider a native addon or WASM large memory for >2GB sessions).
- Persist telemetry per shard; aggregate via a lightweight sidecar that merges JSONL into Prometheus metrics.
- Consider cgroup CPU pinning: dedicate logical core pairs per 8-node cluster for cache locality.

We can template this out if you supply target shard counts.

---
## 10. Next Steps
- Build the WASM module now.
- (Optional) Ask to integrate WASM into the main hashing loop for actual speed gains.
- Expand Prometheus exporter with WASM availability & fallback counters.

Let me know when you’ve built the module or if you’d like the integration patch.
