PURGED SIMULATION MODULES

The following legacy / simulation / clone-army oriented files were purged on this date (UTC) to enforce REAL-ONLY deterministic mining:

- seraphina-persistent-mining.js
- seraphina-free-chat.js
- seraphina-comprehensive-pool-monitor.js
- seraphina-mining-army.js
- actual-real-miner.js

Replacement policy:
These filenames MUST NOT be recreated with simulation, probabilistic share fabrication, clone-count inflation, artificial hashrate scaling, or UI narratives implying fictitious capacity. Any attempt should fail CI via anti-simulation guard.

Canonical real entry points:
- proper-antminer-mining.js
- zero-simulation-real-miner.js
- real-stratum-client.js

If you need new real functionality, create a new file with a descriptive name (e.g., real-f2pool-monitor.js) and ensure:
1. No Math.random() influences share submission paths.
2. Hashrate derived strictly from counted double-SHA256 evaluations over real job templates.
3. Targets computed from bits field and compared before submit.
4. All shares logged with: timestamp, jobId, nonce, headerHash(HEX), shareHash(HEX), accepted(bool), runningHashChain.

Guardrails:
Implement anti-sim verification using verify-no-simulation.js (add to build/test pipeline) to scan for banned tokens.

BANNED TOKENS (non-exhaustive):
  /50 ?B(illion)?/i
  clone(s)?\b
  MASSIVE DEPLOYMENT
  DEPLOYING .* CLONES
  activeClones
  totalClones
  miningClones
  walletMonitorClones
  chatClones
  neuralClones

Do NOT remove this notice without explicit authorization.

---
Holodeck / Deterministic Environment Variables (New)

HASH_CYCLE_MOD
  Description: Deterministic cycle modulus gating primary hashing loop. Every N cycles a full hashing pass executes.
  Default: 10
  Guidance: Lower for higher deterministic hash density during test; raise to reduce CPU load.

HOLODECK_FALLBACK_HASHES
  Description: Count of deterministic fallback hashes emitted when holodeck enabled but lattice not yet seeded.
  Default: 64
  Production: Set to 0 to ensure only authentic lattice hashing occurs.

HOLODECK_INIT_NODES
  Description: Number of lattice nodes seeded immediately on first stratum job under holodeck to unlock real hashing path.
  Default: 8
  Tuning: Increase if early hashing ramp is too slow.

HOLODECK_FALLBACK_TRACE
  Description: When '1', logs one sample header/hash from fallback hashing for auditing.
  Production: Leave unset to reduce noise once lattice seeding confirmed.

Global Counters
  __HOLO_HASH_COUNT__ – Incremented per deterministic hash (including fallback if enabled).
  __HOLO_BYTES_PROCESSED__ – Total bytes of headers + digests processed in hashing pipeline.

Metric Shift
  TH/s removed. Throughput now expressed deterministically as bytes/sec from actual processed header+digest sizes; no probabilistic scaling.

Recommended Production Settings
  HOLODECK_ENABLE=0
  HOLODECK_FALLBACK_HASHES=0
  HASH_CYCLE_MOD tuned post deterministic benchmark.

Repro Determinism Checklist
  1. All randomness replaced by hash-derived seeds.
  2. Fallback hashing disabled (value 0).
  3. Lattice seeds injected deterministically (HOLODECK_INIT_NODES only for test harness).
  4. Metrics derived from counters only.

Upcoming Documentation Additions
  - Remote attestation & signed update channel env vars.
  - Multi-coin (BTC/RVN/LTC/FREN) deterministic algo switch details.
  - Overlay partition rollback & integrity chain flow.

