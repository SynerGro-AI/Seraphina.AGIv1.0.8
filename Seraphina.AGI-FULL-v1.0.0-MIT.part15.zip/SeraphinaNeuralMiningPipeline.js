
// Real cryptographic mining node: uses SHA-256d for real mining
const crypto = require('crypto');

class RealMiningNode {
  constructor(id) {
    this.id = id;
  }

  // Computes SHA-256d hash for given data and nonce
  computeHash(dataHex, nonce) {
    const data = Buffer.concat([
      Buffer.from(dataHex, 'hex'),
      Buffer.alloc(4)
    ]);
    data.writeUInt32LE(nonce, data.length - 4);
    let hash = crypto.createHash('sha256').update(data).digest();
    hash = crypto.createHash('sha256').update(hash).digest();
    return hash;
  }

  // Returns true if hash meets the target (difficulty)
  meetsTarget(hash, targetHex) {
    // targetHex is a hex string, e.g. "0000000ffffffff..."
    const target = Buffer.from(targetHex, 'hex');
    return Buffer.compare(hash, target) <= 0;
  }
}

// Build a lattice of real mining nodes (for parallel search)
function buildRealMiningLattice(count = 32) {
  const nodes = [];
  for (let i = 0; i < count; i++) nodes.push(new RealMiningNode(i));
  return nodes;
}

module.exports = { RealMiningNode, buildRealMiningLattice };
