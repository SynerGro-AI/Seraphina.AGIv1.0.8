// vm-adaptive.js
// Shared adaptive logic for symbolic VM program length tuning.
// Deterministic adjustments based on acceptance rates.

const VM_MAX_STEPS = 32;

function adjustVmPrograms(vmProgramsByHarmonic, partitionAttemptCounts, partitionAcceptCounts, compileFn){
  for (const [tag, ops] of vmProgramsByHarmonic.entries()){
    const attempts = partitionAttemptCounts[tag]||0;
    const accepts = partitionAcceptCounts[tag]||0;
    const rate = attempts ? (accepts/attempts) : 0;
    if (rate < 0.005 && ops.length > 8){
      vmProgramsByHarmonic.set(tag, ops.slice(0, Math.max(8, Math.floor(ops.length*0.75))));
    } else if (rate > 0.05 && ops.length < VM_MAX_STEPS){
      const extra = compileFn(tag + ':exp');
      if (extra){
        const merged = ops.concat(extra).slice(0, VM_MAX_STEPS);
        vmProgramsByHarmonic.set(tag, merged);
      }
    }
  }
}

module.exports = { adjustVmPrograms, VM_MAX_STEPS };