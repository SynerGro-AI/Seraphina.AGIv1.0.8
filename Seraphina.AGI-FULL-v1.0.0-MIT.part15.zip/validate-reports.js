// validate-reports.js
// Simple validator for octalang-build-report.json and (optionally) runtime/micro-init reports.
'use strict';
const fs = require('fs');

function load(path){
  try { return JSON.parse(fs.readFileSync(path,'utf8')); } catch(e){
    console.error('[Validate] Failed to load', path, e.message); return null;
  }
}

function validateOctaLangReport(obj){
  const errors = [];
  if(!obj || typeof obj !== 'object') return ['Report not an object'];
  if(typeof obj.etaBoost !== 'number') errors.push('etaBoost missing');
  else if(obj.etaBoost < 1.0 || obj.etaBoost > 1.2) errors.push('etaBoost out of expected range');
  if(!Array.isArray(obj.sampleHashes) || obj.sampleHashes.length < 4) errors.push('sampleHashes insufficient');
  if(!obj.agent) errors.push('agent field missing');
  return errors;
}

function main(){
  const report = load('octalang-build-report.json');
  const errs = validateOctaLangReport(report);
  if(errs.length){
    console.error('[Validate] octalang-build-report.json errors:', errs);
    process.exitCode = 1;
  } else {
    console.log('[Validate] OctaLang report OK');
  }
  // Optionally validate other reports if present
  ['micro-init-report.json','runtime-report.json'].forEach(f => {
    if(fs.existsSync(f)){
      try {
        const o = load(f);
        if(o && typeof o === 'object') console.log('[Validate] Found', f, 'keys=', Object.keys(o).length);
      } catch(e){ /* ignore */ }
    }
  });
}

if(require.main === module){
  main();
}
