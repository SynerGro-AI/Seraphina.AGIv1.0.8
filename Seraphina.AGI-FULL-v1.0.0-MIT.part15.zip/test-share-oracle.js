#!/usr/bin/env node
// test-share-oracle.js
'use strict';
const { ShareOracle } = require('./share-oracle-infer');

function mockNodes(n=8){
  const out=[]; for(let i=0;i<n;i++){ out.push({ freq: 432 + i, successes: i%3, attempts: (i%5)+1 }); }
  return out;
}

function main(){
  const oracle = new ShareOracle();
  const nodes = mockNodes();
  const sorted = oracle.sortLattice(nodes.slice());
  // Basic checks
  let probsValid = true;
  if(oracle.loaded){
    for(const node of nodes){
      const freqArr = nodes.map(n=> n.freq);
      const rateArr = nodes.map(n=> (n.successes/(n.attempts||1))||0);
      const diffArr = nodes.map(()=> (global.__AUR_CURRENT_JOB_DIFFICULTY__||0));
      const minF=Math.min(...freqArr), maxF=Math.max(...freqArr); const rF=(maxF-minF)||1;
      const minR=Math.min(...rateArr), maxR=Math.max(...rateArr); const rR=(maxR-minR)||1;
      const minD=Math.min(...diffArr), maxD=Math.max(...diffArr); const rD=(maxD-minD)||1;
      const feat=[(node.freq-minF)/rF,( (node.successes/(node.attempts||1)) -minR)/rR,( (global.__AUR_CURRENT_JOB_DIFFICULTY__||0)-minD)/rD];
      const p=oracle.predict(feat);
      if(!(p>=0 && p<=1)) probsValid=false;
    }
  }
  console.log(JSON.stringify({ ok: probsValid, loaded: oracle.loaded, sortedOrderChanged: oracle.loaded && sorted.some((n,i)=> n!==nodes[i]) }, null, 2));
  if(!probsValid) process.exitCode=1;
}

if(require.main === module){ main(); }
