const fs = require('fs');

// Read the original file
const originalFile = 'c:\\Users\\jmwil\\OneDrive\\AppData\\Documents\\mining\\seraphina-REAL-mining-extended.js';
let content = fs.readFileSync(originalFile, 'utf8');

// Add the data-paths import at the top after other requires
const importLine = "const { getDataFilePath, ensureDataDirectory } = require('./data-paths');\n";
const insertAfter = "let KawpowRealInterface=null; try { ({ KawpowRealInterface } = require('./kawpow-real-interface')); } catch{}\n";
const insertIndex = content.indexOf(insertAfter) + insertAfter.length;
content = content.slice(0, insertIndex) + importLine + content.slice(insertIndex);

// Replace all persistent_data path constructions with getDataFilePath calls
const replacements = [
  // Basic file paths
  {
    from: "path.join(__dirname, 'persistent_data', 'learned_nodes_ext.json')",
    to: "getDataFilePath('learned_nodes_ext.json')"
  },
  {
    from: "path.join(__dirname,'persistent_data','share_history_ext.json')",
    to: "getDataFilePath('share_history_ext.json')"
  },
  {
    from: "path.join(__dirname,'persistent_data','share_history_ext.log')",
    to: "getDataFilePath('share_history_ext.log')"
  },
  {
    from: "path.join(__dirname,'persistent_data','share_log_roots_ext.chain')",
    to: "getDataFilePath('share_log_roots_ext.chain')"
  },
  {
    from: "path.join(__dirname,'persistent_data','share_contributors_ext.json')",
    to: "getDataFilePath('share_contributors_ext.json')"
  },
  {
    from: "path.join(__dirname,'persistent_data','neural-tuner-imported.flag')",
    to: "getDataFilePath('neural-tuner-imported.flag')"
  },
  {
    from: "path.join(__dirname,'persistent_data','real_earnings_ext.json')",
    to: "getDataFilePath('real_earnings_ext.json')"
  },
  {
    from: "path.join(__dirname,'persistent_data','neural_memory_ext.log')",
    to: "getDataFilePath('neural_memory_ext.log')"
  },
  // Directory paths
  {
    from: "const dataDir=path.join(__dirname,'persistent_data');",
    to: "const dataDir=ensureDataDirectory();"
  },
  {
    from: "const logDir=path.join(__dirname,'persistent_data');",
    to: "const logDir=ensureDataDirectory();"
  },
  {
    from: "const dir=path.join(__dirname,'persistent_data','neural-snapshots-ext');",
    to: "const dir=getDataFilePath('neural-snapshots-ext');"
  },
  // Dynamic file paths  
  {
    from: "path.join(__dirname,'persistent_data',`share_history_ext_${Date.now()}.log`)",
    to: "getDataFilePath(`share_history_ext_${Date.now()}.log`)"
  },
  {
    from: "path.join(dir,`neural-${snap.full?'full':'lite'}-${snap.ts}.json`)",
    to: "path.join(dir,`neural-${snap.full?'full':'lite'}-${snap.ts}.json`)" // Keep this one as is since dir is already handled
  },
  {
    from: "path.join(logDir,'neural_memory_ext.log')",
    to: "getDataFilePath('neural_memory_ext.log')"
  }
];

// Apply all replacements
for (const replacement of replacements) {
  content = content.replace(new RegExp(replacement.from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), replacement.to);
}

// Write the updated file
fs.writeFileSync(originalFile, content, 'utf8');
console.log('Updated seraphina-REAL-mining-extended.js with data-paths helper');