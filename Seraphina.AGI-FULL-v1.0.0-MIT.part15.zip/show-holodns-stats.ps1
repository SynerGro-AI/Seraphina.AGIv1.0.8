<#
Reads Holodeck DNS stats and recent trace entries if files are configured.
Usage:
  powershell -File show-holodns-stats.ps1 -StatsFile holo-dns-stats.json -TraceFile holo-dns-trace.json -Last 10
#>
param(
  [string]$StatsFile = 'holo-dns-stats.json',
  [string]$TraceFile = 'holo-dns-trace.json',
  [int]$Last = 10
)
function Info($m){ $ts=(Get-Date).ToString('HH:mm:ss'); Write-Host "[$ts] $m" }

if (Test-Path $StatsFile) {
  try {
    $json = Get-Content $StatsFile -Raw | ConvertFrom-Json
    Info "Stats: lookups=$($json.lookups) mapped=$($json.mapped) synth=$($json.synthesized) fail=$($json.failed) poisoned=$($json.poisoned) rateLimited=$($json.rateLimited) ampLarge=$($json.ampLarge) traceSize=$($json.traceSize)"
  } catch { Write-Warning "Failed to parse stats file: $_" }
} else { Info "Stats file not found: $StatsFile" }

if (Test-Path $TraceFile) {
  $lines = Get-Content $TraceFile -Tail $Last
  Info "Last $Last trace entries:"; $lines | ForEach-Object { Write-Host $_ }
} else { Info "Trace file not found: $TraceFile" }
