#!/usr/bin/env node
// triad_miner.js - placeholder mining script enhanced with Seraphina Triad Manager.
'use strict';

const { TriadManager } = require('./seraphina-triad-manager');
const { CoderTriad } = require('./seraphina-coder-triad.js');
const { TriadHammingMonitor } = require('./seraphina-hamming-monitor.js');
const fs = require('fs');
let codeHealthMeta=null;
try { codeHealthMeta = JSON.parse(fs.readFileSync(process.env.SERAPHINA_CODE_HEALTH_WEIGHTS || 'seraphina-code-health-weights.json','utf8')); } catch(_e){ /* optional */ }
function codeHealthScore(code){
  if(!codeHealthMeta) return null;
  const { extractFromCode, vectorize } = require('./seraphina-code-health-features.js');
  const feats = extractFromCode(code);
  const vec = vectorize(feats);
  const nv = vec.map((v,i)=> codeHealthMeta.maxs[i]===codeHealthMeta.mins[i]?0:(v-codeHealthMeta.mins[i])/(codeHealthMeta.maxs[i]-codeHealthMeta.mins[i]));
  const reg = codeHealthMeta.regressionWeights.reduce((s,w,i)=> s + w*nv[i],0);
  const cls = 1/(1+Math.exp(-codeHealthMeta.classificationWeights.reduce((s,w,i)=> s + w*nv[i],0)));
  return { regScore: reg, needsImprovementProb: cls };
}

const mgr = new TriadManager({ blockId:'triad-miner', sourceKind:'octalang-js' });
mgr.register({ id:'triad-miner', role:'mining-stub', version:'0.0.1-stub' });
// Initialize coder triad (syntax + optimization + mesh) for autonomous code auditing
const coderTriad = new CoderTriad({ seed: process.env.SERAPHINA_CODER_SEED });
const hamMon = new TriadHammingMonitor();
try {
  const selfCode = fs.readFileSync(__filename,'utf8');
  coderTriad.registerBlock('triad-miner', selfCode);
} catch(e){ console.warn('[TriadMiner][coderTriad-register] failed', e.message); }

console.log('[TriadMiner] Stub starting. Triad manager active.');
let iter = 0;
setInterval(()=>{
  process.stdout.write('[TriadMiner] heartbeat '+ (++iter) +' ts='+Date.now()+"\n");
  if(iter % 6 === 0){
    // Periodic syntax audit of this file
    try {
      const code = fs.readFileSync(__filename,'utf8');
      const audit = mgr.syntaxAudit(code);
      if(!audit.ok){
        console.log('[TriadMiner][audit-findings]', audit.findings.map(f=>f.type).join(','));
      }
      // Coder triad cycle (deterministic) each audit interval
    const triadRes = coderTriad.triadCycle({ id:'triad-miner', code });
    hamMon.record(triadRes.digest);
    const health = codeHealthScore(code);
    const avgHam = hamMon.avg();
    const hamHealth = hamMon.health();
    const out = { score: triadRes.optimization.score, syntaxOk: triadRes.syntax.ok, links: triadRes.links.links.length, digest: triadRes.digest, avg_ham:+avgHam.toFixed(6), ham_health: hamHealth };
    if(health){ out.codeHealthReg = +health.regScore.toFixed(6); out.codeHealthProb = +health.needsImprovementProb.toFixed(6); }
    console.log('[TriadMiner][coderTriad]', JSON.stringify(out));
    if(hamHealth === 'critical'){ console.warn('[TriadMiner][ham-alert] divergence detected avg_ham='+avgHam.toFixed(6)); }
      // If optimization score low, attempt external suggestion (without altering digest)
      if(triadRes.optimization.score < 0.8 && typeof global.__AUR_AGENT_INVOKE__ === 'function'){
        (async ()=>{
          try {
            const r = await global.__AUR_AGENT_INVOKE__('geometryRefine', 'Suggest code optimization hint', { score: triadRes.optimization.score, issues: triadRes.syntax.issues.length });
            if(r && !r.blocked){ console.log('[TriadMiner][agent-hint]', r.action || r.text || r.note || 'noop'); }
          } catch(e){ /* ignore */ }
        })();
      }
      // Provenance tail (last 2 lines) if ledger present
      const provPath = process.env.SERAPHINA_CODER_PROVENANCE_PATH || 'seraphina-coder-provenance.jsonl';
      if(fs.existsSync(provPath)){
        try {
          const lines = fs.readFileSync(provPath,'utf8').trim().split(/\r?\n/); const tail = lines.slice(-2).map(l=>{ try { return JSON.parse(l); } catch(_e){ return null; } }).filter(Boolean);
          if(tail.length){
            console.log('[TriadMiner][provenance-tail]', tail.map(t=>({ ts:t.ts, optScore:t.optScore, triadDigest:t.triadDigest.slice(0,16) })));
          }
        } catch(e){ /* ignore */ }
      }
    } catch(e){
      console.log('[TriadMiner][audit-error]', e.message);
    }
  }
}, 10000);

// Example external suggestion request every 9 intervals
setInterval(async ()=>{
  if(iter === 0) return;
  if(iter % 9 === 0){
    const resp = await mgr.externalSuggest('burrowAdapt', 'advise prune delta', { acceptRatio: Math.random() });
    if(!resp.blocked) console.log('[TriadMiner][agent]', JSON.stringify(resp));
  }
}, 10000);
