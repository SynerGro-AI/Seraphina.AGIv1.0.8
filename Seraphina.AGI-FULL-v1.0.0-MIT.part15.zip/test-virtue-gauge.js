// test-virtue-gauge.js
'use strict';
const { computeColorEmotionTier } = require('./color-emotion-map');
function run(){
  const sample = computeColorEmotionTier({ curiosity:0.9, novelty:0.6, empowerment:0.7, integration:0.8, imaginationGain:0.5 });
  console.log(JSON.stringify({ tierIndex: sample.tierIndex, virtue: sample.virtue, emotion: sample.emotion, score: sample.score }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };
