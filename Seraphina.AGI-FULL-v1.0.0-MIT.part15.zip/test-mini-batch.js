// test-mini-batch.js
'use strict';
const { spawn } = require('child_process');
function run(env){
  return new Promise(res=>{
    const p = spawn(process.execPath, ['seraphina-model-train.js'], { env:{...process.env, ...env}, stdio:['ignore','pipe','pipe'] });
    let out='';
    p.stdout.on('data',d=> out+=d.toString());
    p.stderr.on('data',d=> out+=d.toString());
    p.on('exit',code=> res({ code, out }));
  });
}
(async()=>{
  const cases = [
    { name:'full-batch-loop', env:{ SERAPHINA_VECTORIZE:'0', SERAPHINA_BATCH_SIZE:'0' } },
    { name:'mini-batch-loop', env:{ SERAPHINA_VECTORIZE:'0', SERAPHINA_BATCH_SIZE:'64', SERAPHINA_TRAIN_UPDATE_MODE:'batch' } },
    { name:'mini-batch-loop-stochastic', env:{ SERAPHINA_VECTORIZE:'0', SERAPHINA_BATCH_SIZE:'64', SERAPHINA_TRAIN_UPDATE_MODE:'stochastic' } },
    { name:'mini-batch-native', env:{ SERAPHINA_VECTORIZE:'1', SERAPHINA_VECTORIZE_MODE:'native', SERAPHINA_BATCH_SIZE:'128' } },
    { name:'mini-batch-mathjs', env:{ SERAPHINA_VECTORIZE:'1', SERAPHINA_VECTORIZE_MODE:'mathjs', SERAPHINA_BATCH_SIZE:'128' } }
  ];
  let results=[];
  for(const c of cases){
    const r = await run(c.env);
    const accMatch = /\[SeraphinaEval\]\s*\{[^}]*\"acc\":\s*(\d+(?:\.\d+)?)/.exec(r.out);
    results.push({ case:c.name, exitCode:r.code, acc: accMatch? parseFloat(accMatch[1]) : null });
  }
  console.log('[MiniBatchTestResults] '+JSON.stringify(results));
  const failures = results.filter(r=> r.exitCode!==0 || r.acc===null);
  if(failures.length){
    console.error('Mini-batch test failures:', failures);
    process.exit(1);
  }
})();
