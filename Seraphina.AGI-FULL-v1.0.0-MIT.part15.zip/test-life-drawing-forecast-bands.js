#!/usr/bin/env node
'use strict';
const { buildForecast } = require('./life-drawing-forecast');

const f = buildForecast({ horizon: 6, vol: 0.05 });
if(!f.ok){ console.error('Forecast failed: '+f.message); process.exit(1); }
function assert(cond, msg){ if(!cond){ console.error('Assertion failed:', msg); process.exit(1); } }
assert(Array.isArray(f.scoreBands) && f.scoreBands.length===6, 'scoreBands length');
assert(f.scoreBands[0].low < f.scoreBands[0].value && f.scoreBands[0].high > f.scoreBands[0].value, 'scoreBands bounds');
assert(Array.isArray(f.completenessBands) && f.completenessBands.length===6, 'completenessBands length');
assert(Array.isArray(f.fieldOutlook) && f.fieldOutlook.length>0, 'fieldOutlook presence');
assert(f.fieldOutlook[0].bands.length===6, 'fieldOutlook band length');
assert(Array.isArray(f.recommendationOutlook) && f.recommendationOutlook.length>0, 'recommendationOutlook presence');
assert(f.recommendationOutlook[0].bands.length===6, 'recommendationOutlook band length');
console.log(JSON.stringify({ ok:true, horizon: f.horizon, vol: f.vol, fields: f.fieldOutlook.length }, null, 2));
