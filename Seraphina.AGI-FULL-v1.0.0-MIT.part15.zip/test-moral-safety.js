// test-moral-safety.js
// Simple deterministic test for virtue computation and inference integration.
'use strict';
const assert = require('assert');
const { assess } = require('./seraphina-moral-safety.js');
const { infer } = require('./seraphina-model-infer.js');

function fakeEntry(){
  return {
    dialogs: [
      { text: 'We should balance profit with empathy and ethical vision' },
      { text: 'Imagine strategies that grow and adapt safely' }
    ],
    personality: {
      openness: 0.7,
      stability: 0.55,
      strategic_depth: 0.6,
      ethical_alignment: 0.62,
      imagination_intensity: 0.58
    },
    econSignals: { frenRevenueNorm: 0.4, incomeSpread: 0.2, acceptRatio: 0.85 },
    decisions: new Array(12).fill(0)
  };
}

function run(){
  const entry = fakeEntry();
  const res = assess(entry);
  assert(res.virtues.empathy >= 0 && res.virtues.empathy <=1, 'empathy range');
  assert(res.virtues.integrity >= 0 && res.virtues.integrity <=1, 'integrity range');
  const res2 = assess(entry);
  assert.deepStrictEqual(res.virtues, res2.virtues, 'deterministic virtues');
  const inf = infer(entry);
  if (!inf.error){
    assert(inf.virtues, 'virtues included in inference');
    assert(['clear','monitor','elevated'].includes(inf.safetyFlag), 'safetyFlag valid');
  }
  console.log('[TestMoralSafety] PASS', { safetyFlag: inf.safetyFlag, empathy: res.virtues.empathy.toFixed(3) });
}

if (require.main === module){
  run();
}

module.exports = { run };
