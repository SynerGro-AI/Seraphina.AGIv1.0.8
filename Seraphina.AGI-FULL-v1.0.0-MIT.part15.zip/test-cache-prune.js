'use strict';
// test-cache-prune.js
// Verifies pruneCache and CLI prune behavior.
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const api = require('./seraphina-api');

function runProgrammatic(){
  // Populate cache with simulated timestamps
  for(let i=0;i<5;i++){ api.virtueSim.runSimulation({ n:500+i, seed:'prune-'+i }); }
  // Manually age first two entries by mutating persistence file after save
  api.meta.toggleCachePersistence(true, path.join(__dirname,'__prune_cache.json'));
  api.meta.toggleCachePersistence(true); // triggers save
  // Load file and artificially reduce createdTs for first two entries
  const f = path.join(__dirname,'__prune_cache.json');
  const raw = fs.readFileSync(f); let json = JSON.parse(raw.toString('utf8'));
  let i=0; for(const k of Object.keys(json.entries)){ if(i<2){ json.entries[k].createdTs = Date.now() - 7200000; i++; } }
  fs.writeFileSync(f, JSON.stringify(json,null,2));
  // Reload modified file
  api.meta.toggleCachePersistence(true, f);
  const before = api.meta.getCacheStats().size;
  const res = api.meta.pruneCache(3600000); // prune entries older than 1h
  const after = api.meta.getCacheStats().size;
  if(!res.ok || res.pruned < 1) throw new Error('Expected programmatic prune to remove entries');
  console.log('Programmatic prune OK. before', before, 'after', after, 'removed', res.pruned);
}

function runCliPrune(){
  const f = path.join(__dirname,'__prune_cache.json');
  // Ensure CLI prune uses same file
  const out = spawnSync(process.execPath,['seraphina-cache-cli.js','prune','--maxAgeMs=3600000','--pretty=false'],{ cwd: __dirname, encoding:'utf8' });
  if(out.status !== 0) throw new Error('CLI prune failed: '+out.stderr);
  console.log('CLI prune output:', out.stdout.trim());
}

function main(){
  runProgrammatic();
  runCliPrune();
  console.log('Cache prune test passed.');
}

if(require.main === module){
  try { main(); } catch(e){ console.error('Cache prune test failed:', e.message); process.exit(1); }
}
module.exports = { main };
