'use strict';
const assert = require('assert');
const { runPareto } = require('./pareto-multi-metric-optimizer');
function run(){
  process.env.PARETO_GRID_RES='4';
  process.env.PARETO_EPSILON='0.01';
  const metrics = { imaginationGain:0.5, curiosityGain:0.3, integrationNorm:0.2, empowermentGain:0.4, noveltyGain:0.25 };
  process.env.PARETO_INCLUDE_EMPOWERMENT='1';
  process.env.PARETO_INCLUDE_NOVELTY='1';
  const res = runPareto(metrics);
  assert(res.frontSize <= res.originalFrontSize, 'Pruned front should not exceed original size');
  assert(Array.isArray(res.representative), 'Representative must be array');
  assert(res.representative.length === res.dims, 'Representative length must equal dims');
  console.log(JSON.stringify({ ok:true, dims:res.dims, frontSize:res.frontSize }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };