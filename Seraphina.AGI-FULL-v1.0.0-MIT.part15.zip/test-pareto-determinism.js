// test-pareto-determinism.js
// Verifies deterministic Pareto front representative across repeated invocations.
'use strict';
const assert = require('assert');
const { runPareto } = require('./pareto-multi-metric-optimizer');

function runOnce(){
  const metrics = { imaginationGain: 0.1234, curiosityGain: 0.4567, integrationNorm: 0.2222 };
  process.env.PARETO_GRID_RES = '5';
  process.env.PARETO_REP_MODE = 'median';
  return runPareto(metrics);
}

const results = [];
for(let i=0;i<5;i++){ results.push(runOnce()); }

// All representatives must match exactly
const reps = results.map(r=> r.representative.join(','));
for(const r of reps){ assert.strictEqual(r, reps[0], 'Representative weight vector not stable across runs'); }

// Front size stable
const fsizes = results.map(r=> r.frontSize);
for(const f of fsizes){ assert.strictEqual(f, fsizes[0], 'Front size not stable across runs'); }

console.log('[TEST PASS] Pareto determinism stable. Representative:', results[0].representative, 'FrontSize:', fsizes[0]);
