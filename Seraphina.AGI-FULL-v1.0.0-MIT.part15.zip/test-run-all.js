// test-run-all.js
// Discovers test-*.js files in current directory, runs each in a separate process, aggregates outputs.
'use strict';
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

function discoverTests(){
  const dir = __dirname;
  return fs.readdirSync(dir).filter(f=> /^test-.*\.js$/.test(f));
}

function runTest(file){
  const abs = path.join(__dirname,file);
  const proc = spawnSync(process.execPath,[abs],{ encoding:'utf8' });
  return { file, status: proc.status, error: !!proc.error, stdout: proc.stdout.trim(), stderr: proc.stderr.trim() };
}

function aggregate(){
  const tests = discoverTests();
  const results = tests.map(runTest);
  const summary = {
    ts: new Date().toISOString(),
    node: process.version,
    testCount: results.length,
    passed: results.filter(r=> r.status===0 && !r.error).length,
    failed: results.filter(r=> r.status!==0 || r.error).length,
    results
  };
  process.stdout.write(JSON.stringify(summary,null,2)+'\n');
  if(summary.failed > 0){ process.exitCode = 1; }
}

if(require.main === module){ aggregate(); }

module.exports = { discoverTests, runTest, aggregate };