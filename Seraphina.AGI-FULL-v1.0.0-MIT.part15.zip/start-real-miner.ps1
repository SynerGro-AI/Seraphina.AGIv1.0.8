<#!
Start Real Miner Helper
- Launches seraphina-REAL-mining.js in a separate PowerShell window (or same session background)
- Polls /api/real-stats until available
Usage:
  ./start-real-miner.ps1                 # just start & poll
  ./start-real-miner.ps1 -NoWindow       # start in current window background job
  ./start-real-miner.ps1 -Once           # start only, no polling
Environment expected (set beforehand or edit below):
  REAL_STRICT=1, BTC_MINING_ADDRESS, BTC_KRAKEN_ADDRESS, RVN_LOCAL_ADDRESS, BTC_WORKER_NAME=donumdei888, RVN_WORKER_NAME=donumdei888
Optional:
  VAULT_PASS, VAULT_AUTO_SIGN=1, BTC_EXTERNAL_MINER_CMD, BTC_EXTERNAL_MINER_ARGS
!#>
param(
  [switch]$NoWindow,
  [switch]$Once,
  [int]$TimeoutSec = 60,
  [int]$PollIntervalSec = 2
)

$script = Join-Path $PSScriptRoot 'seraphina-REAL-mining.js'
if(!(Test-Path $script)){ Write-Host "[STARTER] Missing seraphina-REAL-mining.js" -ForegroundColor Red; exit 1 }

# Basic required variable check (REAL_STRICT scenario)
$req = 'BTC_MINING_ADDRESS','BTC_KRAKEN_ADDRESS','RVN_LOCAL_ADDRESS','BTC_WORKER_NAME','RVN_WORKER_NAME'
$missing = @()
foreach($r in $req){ if(-not (Get-Item Env:$r -ErrorAction SilentlyContinue)) { $missing += $r } }
if($env:REAL_STRICT -eq '1' -and $missing.Count){
  Write-Host "[STARTER] Missing required vars for REAL_STRICT: $($missing -join ',')" -ForegroundColor Yellow
}

$nodeCmd = "node `"$script`""
Write-Host "[STARTER] Launching: $nodeCmd" -ForegroundColor Cyan

if($NoWindow){
  Start-Job -Name SeraphinaRealMiner -ScriptBlock { param($s) node $s } -ArgumentList $script | Out-Null
} else {
  Start-Process -FilePath "powershell.exe" -ArgumentList "-NoLogo -NoExit -Command node `"$script`"" -WindowStyle Normal | Out-Null
}

if($Once){ exit 0 }

$deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSec)
$statsUrl = 'http://localhost:8888/api/real-stats'
Write-Host "[STARTER] Polling $statsUrl ..." -ForegroundColor Cyan

while([DateTime]::UtcNow -lt $deadline){
  try {
    $resp = Invoke-RestMethod -Uri $statsUrl -Method Get -TimeoutSec 5
    if($resp.success){
      Write-Host "[STARTER] Miner online: activeClones=$($resp.activeClones) measuredHashrateBTC=$($resp.measuredHashrateBTC)" -ForegroundColor Green
      break
    }
  } catch { }
  Start-Sleep -Seconds $PollIntervalSec
}
if([DateTime]::UtcNow -ge $deadline){ Write-Host "[STARTER] Timeout waiting for /api/real-stats" -ForegroundColor Yellow }
