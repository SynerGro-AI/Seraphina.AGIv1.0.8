-- tempo-lua-pipes-examples.lua
-- Collection of safe, performance-conscious Tempo Query Lua pipe examples.
-- Enable via tempo.yaml: query_extensions: { lua_script: "tempo-lua-pipes-examples.lua" }
-- Each function returns true to keep span, false to drop.
-- Use ctx.log(level, msg) for structured diagnostics.

-- BASIC LATENCY BUCKET WITH PCALL GUARD
function pipe_latency_bucket(ctx)
  local ok, err = pcall(function()
    local d = ctx.span.duration or 0
    if d > 2.0 then
      ctx.span.labels.lat_bucket = 'gt_2s'
    elseif d > 1.0 then
      ctx.span.labels.lat_bucket = '1_2s'
    elseif d > 0.5 then
      ctx.span.labels.lat_bucket = '0.5_1s'
    else
      ctx.span.labels.lat_bucket = 'le_0.5s'
    end
  end)
  if not ok then
    ctx.log('error', 'pipe_latency_bucket failure: ' .. tostring(err))
    return false -- drop corrupted span
  end
  return true
end

-- EVENT LATENCY AGGREGATION WITH FALLBACK
function pipe_event_latency_avg(ctx)
  local status, result = xpcall(function()
    local total = 0
    local count = 0
    local events = ctx.span.events
    if events then
      for _, e in ipairs(events) do
        local lat = e.attributes and e.attributes.latency
        if lat then
          total = total + lat
          count = count + 1
        end
      end
    end
    if count > 0 then
      ctx.span.labels.event_latency_avg = total / count
    else
      ctx.span.labels.event_latency_avg = 'na'
    end
  end, function(err)
    ctx.log('warn', 'event_latency_avg error: ' .. tostring(err))
    return 'fallback'
  end)
  if not status then
    ctx.span.labels.event_latency_avg = result
  end
  return true
end

-- SEVERITY CLASSIFICATION USING REGEX
function pipe_severity_classifier(ctx)
  local name = ctx.span.name or ''
  if string.match(name, '^http%..*%.error') then
    ctx.span.labels.severity = 'critical'
  elseif string.match(name, 'db%.query') then
    ctx.span.labels.severity = 'warning'
  else
    ctx.span.labels.severity = 'normal'
  end
  return true
end

-- BATCH EVENT PROCESSING WITH ERROR COLLECTION
function pipe_batch_event_processing(ctx)
  local errors = {}
  local events = ctx.span.events
  if events then
    for _, e in ipairs(events) do
      local ok, perr = pcall(function()
        if e.attributes and e.attributes.a and e.attributes.b then
          e.attributes.sum = e.attributes.a + e.attributes.b
        end
      end)
      if not ok then
        table.insert(errors, perr)
      end
    end
  end
  if #errors > 0 then
    ctx.log('error', 'batch_event_processing errors: ' .. table.concat(errors, '; '))
    ctx.span.labels.event_batch_status = 'partial'
  else
    ctx.span.labels.event_batch_status = 'ok'
  end
  return true
end

-- LATENCY ACCELERATION RATIO (MICRO VS MACRO LABELS PRE-INGESTED)
function pipe_latency_acceleration(ctx)
  local micro = ctx.span.labels and ctx.span.labels.micro_rate
  local macro = ctx.span.labels and ctx.span.labels.macro_rate
  if micro and macro then
    local ok, val = pcall(function()
      local m = tonumber(micro) or 0
      local M = tonumber(macro) or 1
      return m / M
    end)
    if ok then
      ctx.span.labels.accel_ratio = string.format('%.4f', val)
    else
      ctx.span.labels.accel_ratio = 'err'
    end
  end
  return true
end

-- CONDITIONAL DROP FOR SLOW SPANS WITH ERROR LOGGING
function pipe_drop_slow_errors(ctx)
  local d = ctx.span.duration or 0
  if d > 5.0 and (ctx.span.attributes and ctx.span.attributes.error) then
    ctx.log('warn', 'dropping slow error span id=' .. (ctx.span.id or 'nil') .. ' dur=' .. tostring(d))
    return false
  end
  return true
end

-- STRUCTURED JSON LOGGING EXAMPLE
local json = json or nil -- If Tempo exposes a json module; guard for availability.
function pipe_structured_log(ctx)
  local payload = {
    id = ctx.span.id,
    service = ctx.span.service and ctx.span.service.name,
    duration = ctx.span.duration,
    severity = ctx.span.labels and ctx.span.labels.severity
  }
  if json and json.encode then
    ctx.log('info', json.encode(payload))
  else
    ctx.log('info', 'span=' .. tostring(payload.id) .. ' svc=' .. tostring(payload.service) .. ' dur=' .. tostring(payload.duration))
  end
  return true
end

-- MASTER PIPE DISPATCH (OPTIONAL)
function pipe(ctx)
  -- Acceleration ratio validation before other pipes
  local accel = ctx.span.labels and ctx.span.labels.accel_ratio
  if accel then
    local ok, err = pcall(function()
      if type(accel) == 'string' then accel = tonumber(accel) end
      if type(accel) ~= 'number' or accel < 0 or accel > 1 then
        error('accel_ratio out of [0,1] range')
      end
    end)
    if not ok then
      ctx.log('warn', 'PIPE_ERR type=accel_invalid msg=' .. tostring(err) .. ' value=' .. tostring(ctx.span.labels.accel_ratio))
      ctx.span.labels.accel_ratio = nil -- remove invalid label
    end
  end
  if not pipe_latency_bucket(ctx) then return false end
  pipe_severity_classifier(ctx)
  pipe_event_latency_avg(ctx)
  pipe_batch_event_processing(ctx)
  pipe_latency_acceleration(ctx)
  pipe_structured_log(ctx)
  return pipe_drop_slow_errors(ctx)
end
