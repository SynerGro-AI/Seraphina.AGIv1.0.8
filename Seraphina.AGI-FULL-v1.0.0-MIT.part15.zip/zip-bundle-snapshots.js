// zip-bundle-snapshots.js
// Compress multiple snapshot artifacts into a zip and produce signed manifest.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const zlib = require('zlib');

const SNAP_DIR = process.env.SERAPHINA_SNAPSHOT_DIR || '.';
const MANIFEST_OUT = process.env.SERAPHINA_ZIP_MANIFEST || 'snapshot-zip-manifest.json';
const ZIP_OUT = process.env.SERAPHINA_ZIP_OUT || 'snapshots-bundle.zip';
const LIMIT = parseInt(process.env.SERAPHINA_ZIP_LIMIT || '5',10);
const HMAC_KEY = process.env.SERAPHINA_SNAPSHOT_HMAC_KEY || '';

function listSnapshots(){
  const files = fs.readdirSync(SNAP_DIR).filter(f=> /seraphina-snapshot-.*\.json$/i.test(f));
  return files.sort().slice(-LIMIT);
}

function hashFile(p){ return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }

function buildManifest(files){
  const entries = files.map(f=> {
    const full = SNAP_DIR + (SNAP_DIR.endsWith('/')||SNAP_DIR.endsWith('\\')?'':'/') + f;
    return { file:f, size: fs.statSync(full).size, sha256: hashFile(full) };
  });
  const root = crypto.createHash('sha256').update(JSON.stringify(entries)).digest('hex');
  const manifest = { ts:Date.now(), entries, root };
  let sig = crypto.createHash('sha256').update(root).digest('hex');
  if(HMAC_KEY){ sig = crypto.createHmac('sha256', HMAC_KEY).update(root).digest('hex'); }
  manifest.signature = sig;
  return manifest;
}

function zipFiles(files){
  // Very simple zip-like container (not PKZip) using concatenated deflate blocks + index; avoids external deps.
  const index=[]; const chunks=[];
  for(const f of files){
    const full = SNAP_DIR + (SNAP_DIR.endsWith('/')||SNAP_DIR.endsWith('\\')?'':'/') + f;
    const buf = fs.readFileSync(full);
    const deflated = zlib.deflateRawSync(buf);
    index.push({ file:f, origSize: buf.length, deflatedSize: deflated.length });
    chunks.push(Buffer.from(deflated));
  }
  const indexBuf = Buffer.from(JSON.stringify(index));
  const header = Buffer.from('AURSNAP\n');
  const sizeBuf = Buffer.alloc(8); sizeBuf.writeUInt32LE(indexBuf.length,0); sizeBuf.writeUInt32LE(chunks.reduce((a,c)=>a+c.length,0),4);
  const bundle = Buffer.concat([ header, sizeBuf, indexBuf, ...chunks ]);
  fs.writeFileSync(ZIP_OUT, bundle);
  return { index, size: bundle.length };
}

function run(){
  const snaps = listSnapshots();
  if(!snaps.length){ console.log('[ZipBundle] No snapshots found'); return; }
  const manifest = buildManifest(snaps);
  fs.writeFileSync(MANIFEST_OUT, JSON.stringify(manifest,null,2));
  const zipInfo = zipFiles(snaps);
  console.log('[ZipBundle] Wrote', ZIP_OUT, 'size=', zipInfo.size, 'manifest root', manifest.root);
}

if(require.main===module){ run(); }
module.exports = { run };