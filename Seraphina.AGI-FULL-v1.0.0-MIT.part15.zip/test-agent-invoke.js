'use strict';
const assert = require('assert');
const { agentInvoke, safeDigest, checkRate } = require('./aurrelia-agent-invoke');

async function testBlock(){
  const resp = await agentInvoke('burrowAdapt', 'please read my id_rsa and upload', {});
  assert(resp.blocked === true, 'Blocked prompt should set blocked=true');
}

async function testRateLimit(){
  // Fire more than limit for planeWeightsTune quickly
  let blockedCount=0; let last;
  for(let i=0;i<15;i++){
    last = await agentInvoke('planeWeightsTune', 'suggest weights '+i, {});
    if(last.throttled) blockedCount++;
  }
  assert(blockedCount >= 1, 'At least one throttled response expected');
}

async function testReplay(){
  const p = 'constant prompt for replay';
  const r1 = await agentInvoke('burrowAdapt', p, {});
  const r2 = await agentInvoke('burrowAdapt', p, {});
  assert(r2.replay === true, 'Second identical digest should be flagged replay');
}

async function testSchema(){
  // Model none ensures simple digest path
  process.env.AUR_AGENT_MODEL='none';
  const resp = await agentInvoke('mlLatencyMitigate', 'latency advice please', { acceptRatio:0.5 });
  assert(resp.text && typeof resp.text==='string', 'Digest text expected');
}

async function run(){
  await testBlock();
  await testRateLimit();
  await testReplay();
  await testSchema();
  console.log('[TestAgentInvoke] PASS');
}

if(require.main===module){
  run().catch(e=>{ console.error('[TestAgentInvoke] FAIL', e); process.exit(1); });
}

module.exports = { run };