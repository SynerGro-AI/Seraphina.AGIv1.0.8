// trading-performance-scoreboard.js
// Deterministic performance scoreboard for trading strategies A (baseline), B (latency-weighted), and learned (adaptive multiplier + fees).
// Reads structured trading signals (TRADING_STRUCTURED_PATH) and learned state ledger to compute aggregate metrics.
// Usage: node trading-performance-scoreboard.js

'use strict';
const fs = require('fs');
const crypto = require('crypto');

function stableHash(o){ return crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex'); }

const SIG_PATH = process.env.TRADING_STRUCTURED_PATH || 'trading-signals.jsonl';
const LEARNED_PATH = process.env.TRADING_LEARNED_PATH || 'trading-learned-state.jsonl';
const OUT_PATH = process.env.TRADING_SCOREBOARD_OUT || 'trading-scoreboard.json';

function readJsonLines(p, limit){
  if(!fs.existsSync(p)) return [];
  let lines = fs.readFileSync(p,'utf8').trim().split(/\n+/);
  if(limit && lines.length>limit) lines = lines.slice(-limit);
  const out=[]; for(const l of lines){ try { out.push(JSON.parse(l)); } catch(_){} } return out;
}

function computeScore(signals){
  let totalA=0, totalB=0, totalLearned=0; // sum of spreads captured
  let swapsA=0, swapsB=0, swapsLearned=0;
  let missedLearned=0, feeCost=0; // estimated fees
  for(const e of signals){
    const sig = e.signal || {};
    const spread = sig.spread||0;
    const adj = sig.adjustedSpread||0;
    const net = sig.netSpread!=null? sig.netSpread : (adj - (sig.feeRate||0));
    const actionSwap = sig.action === 'swap';
    // Strategy A capture uses raw spread if swap
    if(actionSwap){ totalA += spread; swapsA++; }
    // Strategy B capture if stratBSpread present and action swap
    if(actionSwap && typeof sig.stratBSpread === 'number'){ totalB += sig.stratBSpread; swapsB++; }
    // Learned capture uses net
    if(actionSwap){ totalLearned += net; swapsLearned++; feeCost += (sig.feeRate||0); }
    else if(net > 0 && sig.learnedThreshold && adj >= sig.threshold && adj < sig.learnedThreshold){ missedLearned += net; }
  }
  return {
    totalA:Number(totalA.toFixed(8)), totalB:Number(totalB.toFixed(8)), totalLearned:Number(totalLearned.toFixed(8)),
    swapsA, swapsB, swapsLearned,
    avgGainA: swapsA? Number((totalA/swapsA).toFixed(8)) : 0,
    avgGainLearned: swapsLearned? Number((totalLearned/swapsLearned).toFixed(8)) : 0,
    missedLearned:Number(missedLearned.toFixed(8)), feeCost:Number(feeCost.toFixed(8))
  };
}

function main(){
  const signals = readJsonLines(SIG_PATH, 8000);
  const learned = readJsonLines(LEARNED_PATH, 8000); // for future deeper analysis
  const summary = computeScore(signals);
  const digestSignals = stableHash(signals);
  const digestLearned = stableHash(learned);
  const report = { ts:new Date().toISOString(), summary, signalsCount:signals.length, learnedCount:learned.length, signalsDigest:digestSignals, learnedDigest:digestLearned };
  fs.writeFileSync(OUT_PATH, JSON.stringify(report,null,2));
  console.log(JSON.stringify({ scoreboard: OUT_PATH, totalLearned: summary.totalLearned, improvementVsA: summary.totalA? Number(((summary.totalLearned - summary.totalA)/summary.totalA).toFixed(8)) : null }, null,2));
}

main();
