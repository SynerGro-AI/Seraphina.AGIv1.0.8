'use strict';
const fs = require('fs');
const path = require('path');
const { orchestrate } = require('./ai-learning-orchestrator.js');
process.env.REGRESSION_WINDOW_SIZE = '3';
process.env.PARETO_ENABLED = '0';
// Ensure sandbox disabled to keep metrics simple
process.env.SANDBOX_ENABLED = '0';
// Run three orchestrations; baseline only captured if dimension escalation occurs; force escalation target
process.env.IMAGINATION_DIM_TARGET = '4';
process.env.IMAGINATION_DIM = '3';
process.env.IMAGINATION_DIM_VARIANCE_THRESHOLD = '0';
process.env.IMAGINATION_DIM_PLATEAU_RUNS = '1';
process.env.IMAGINATION_DIM_STEP_MAX = '2';
process.env.IMAGINATION_DIM_RAMP_STEP = '2';
const a = orchestrate();
const b = orchestrate();
const c = orchestrate();
const baselineExists = fs.existsSync(path.join(__dirname,'regression-baseline.json'));
const diffPresent = !!c.regressionDiff;
process.stdout.write(JSON.stringify({ baselineExists, diffPresent },null,2)+'\n');