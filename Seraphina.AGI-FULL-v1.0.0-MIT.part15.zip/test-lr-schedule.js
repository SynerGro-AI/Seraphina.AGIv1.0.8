// test-lr-schedule.js
'use strict';
const fs = require('fs');
const { spawnSync } = require('child_process');

function runOnce(schedule){
  const env = { ...process.env, SERAPHINA_LR_SCHEDULE: schedule, SERAPHINA_VECTORIZE:'1', SERAPHINA_VECTORIZE_MODE:'simd', SERAPHINA_MODEL_EPOCHS:'9' };
  const r = spawnSync(process.execPath, ['seraphina-model-train.js'], { env, encoding:'utf8' });
  return r;
}

function main(){
  const schedule = '0.2,0.1,0.05';
  const r = runOnce(schedule);
  if(r.status !== 0){ console.error('Train failed status', r.status); process.exit(1); }
  if(!fs.existsSync('seraphina-eval-last.json')){ console.error('Missing eval file'); process.exit(1); }
  const data = JSON.parse(fs.readFileSync('seraphina-eval-last.json','utf8'));
  if(!Array.isArray(data.epochTimes) || data.epochTimes.length===0){ console.error('epochTimes missing'); process.exit(1); }
  console.log('[LRScheduleTest] OK epochs='+data.epochTimes.length+' acc='+data.acc);
}
main();
