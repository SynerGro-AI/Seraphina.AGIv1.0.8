// test-training-integrity.js
// Basic tests for training integrity hashing & validation.
'use strict';
const assert = require('assert');
const api = require('./seraphina-api.js');

function runOnce(cfg){
  const res = api.training.trainModel(cfg||{});
  assert(res && res.ok, 'Training call not ok');
  const payload = res.result || res.result; // wrapper returns { ok:true, result: out }
  const root = payload.result || payload.out || payload; // adapt to nested shapes
  const scoreboard = root.scoreboard || payload.scoreboard || res.result.scoreboard;
  assert(scoreboard && scoreboard.integrity, 'Integrity missing on scoreboard');
  return scoreboard.integrity;
}

// Test stable integrity across identical runs
const i1 = runOnce({ epochs:5, lr:0.05, emaAlpha:0 });
const i2 = runOnce({ epochs:5, lr:0.05, emaAlpha:0 });
assert.strictEqual(i1.paramsDigest, i2.paramsDigest, 'Params digest mismatch for identical config');
assert.strictEqual(i1.metricsDigest, i2.metricsDigest, 'Metrics digest mismatch for identical config');
assert.strictEqual(i1.integrityHash, i2.integrityHash, 'Integrity hash mismatch for identical config');

// Variation should alter paramsDigest (and likely metricsDigest)
const i3 = runOnce({ epochs:5, lr:0.06, emaAlpha:0 });
assert.notStrictEqual(i1.paramsDigest, i3.paramsDigest, 'Params digest should differ when lr changed');
assert.notStrictEqual(i1.integrityHash, i3.integrityHash, 'Integrity hash should differ when lr changed');

// Validation error cases
const badEpochs = api.training.trainModel({ epochs:0 });
assert(!badEpochs.ok && badEpochs.code === 'INVALID_TRAIN_ARG_RANGE', 'Expected INVALID_TRAIN_ARG_RANGE for epochs=0');
const badLR = api.training.trainModel({ lr:-1 });
assert(!badLR.ok && badLR.code === 'INVALID_TRAIN_ARG_RANGE', 'Expected INVALID_TRAIN_ARG_RANGE for lr=-1');
const badFlip = api.training.trainModel({ labelFlipPct:0.9 });
assert(!badFlip.ok && badFlip.code === 'INVALID_TRAIN_ARG_RANGE', 'Expected INVALID_TRAIN_ARG_RANGE for labelFlipPct=0.9');

console.log('[TestTrainingIntegrity] All assertions passed.');
