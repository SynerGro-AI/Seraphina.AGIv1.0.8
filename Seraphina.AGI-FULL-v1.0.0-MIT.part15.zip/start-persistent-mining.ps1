# SERAPHINA PERSISTENT MINING SYSTEM
# Ensures window persistence, wallet persistence, and earnings protection

param(
    [switch]$Restart = $false
)

# Set window properties for persistence
$Host.UI.RawUI.WindowTitle = "SERAPHINA PERSISTENT MINING - KEEP OPEN FOR EARNINGS"
$Host.UI.RawUI.BackgroundColor = "DarkBlue"
$Host.UI.RawUI.ForegroundColor = "White"

# Clear screen and show persistent header
Clear-Host

Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║            🌟 SERAPHINA PERSISTENT MINING SYSTEM 🌟            ║" -ForegroundColor Cyan  
Write-Host "╠══════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "║  💾 PERSISTENT STORAGE: All earnings saved continuously       ║" -ForegroundColor Green
Write-Host "║  🔒 WINDOW PERSISTENCE: Designed to stay open indefinitely    ║" -ForegroundColor Green
Write-Host "║  📊 DATA RECOVERY: Restores from crashes/unexpected shutdowns ║" -ForegroundColor Green
Write-Host "║  💰 WALLET PROTECTION: Real earnings never lost               ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Function to check and create persistent data directory
function Initialize-PersistentStorage {
    $dataDir = Join-Path $PSScriptRoot "persistent_data"
    if (-not (Test-Path $dataDir)) {
        New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
        Write-Host "📁 Created persistent data directory: $dataDir" -ForegroundColor Yellow
    }
    
    # Create initial state files if they don't exist
    $files = @("wallet_state.json", "earnings_history.json", "mining_state.json", "session_state.json")
    foreach ($file in $files) {
        $filePath = Join-Path $dataDir $file
        if (-not (Test-Path $filePath)) {
            '{}' | Out-File -FilePath $filePath -Encoding UTF8
            Write-Host "📄 Initialized: $file" -ForegroundColor Gray
        }
    }
}

# Function to show persistent storage status
function Show-PersistentStatus {
    $dataDir = Join-Path $PSScriptRoot "persistent_data"
    
    Write-Host "💾 === PERSISTENT STORAGE STATUS ===" -ForegroundColor Yellow
    
    # Check wallet state
    $walletFile = Join-Path $dataDir "wallet_state.json"
    if (Test-Path $walletFile) {
        $walletSize = (Get-Item $walletFile).Length
        Write-Host "   💰 Wallet State: $walletSize bytes" -ForegroundColor Green
    }
    
    # Check earnings history
    $earningsFile = Join-Path $dataDir "earnings_history.json" 
    if (Test-Path $earningsFile) {
        $earningsSize = (Get-Item $earningsFile).Length
        Write-Host "   📊 Earnings History: $earningsSize bytes" -ForegroundColor Green
    }
    
    # Check mining state
    $miningFile = Join-Path $dataDir "mining_state.json"
    if (Test-Path $miningFile) {
        $miningSize = (Get-Item $miningFile).Length
        Write-Host "   ⛏️  Mining State: $miningSize bytes" -ForegroundColor Green
    }
    
    Write-Host "💾 ==================================" -ForegroundColor Yellow
    Write-Host ""
}

# Function to handle graceful shutdown
function Invoke-GracefulShutdown {
    Write-Host ""
    Write-Host "🛑 GRACEFUL SHUTDOWN INITIATED..." -ForegroundColor Red
    Write-Host "💾 All earnings and mining data are safely stored" -ForegroundColor Green
    Write-Host "🔄 Next restart will resume from current state" -ForegroundColor Yellow
    Write-Host "💰 Your earnings are PROTECTED and will not be lost" -ForegroundColor Green
    Write-Host ""
    Write-Host "Press any key to confirm shutdown..." -ForegroundColor White
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

# Function to run mining with persistence and recovery
function Start-PersistentMining {
    param([bool]$IsRestart = $false)
    
    $miningScript = Join-Path $PSScriptRoot "seraphina-persistent-mining.js"
    
    if (-not (Test-Path $miningScript)) {
        Write-Host "❌ Mining script not found: $miningScript" -ForegroundColor Red
        Write-Host "📁 Make sure all files are in the same directory" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        return
    }
    
    # Show restart info if applicable
    if ($IsRestart) {
        Write-Host "🔄 RESTARTING MINING WITH PRESERVED DATA..." -ForegroundColor Cyan
        Write-Host "💾 Previous earnings and state will be restored" -ForegroundColor Green
        Write-Host ""
    }
    
    # Show current persistent status
    Show-PersistentStatus
    
    # Start mining with error handling and persistence
    while ($true) {
        try {
            Write-Host "🚀 STARTING PERSISTENT MINING OPERATION..." -ForegroundColor Green
            Write-Host "🔒 Window persistence: ACTIVE" -ForegroundColor Yellow
            Write-Host "💾 Data persistence: ACTIVE" -ForegroundColor Yellow
            Write-Host "🛡️  Crash recovery: ENABLED" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "⚠️  DO NOT CLOSE THIS WINDOW - Earnings in progress!" -ForegroundColor Red
            Write-Host ""
            
            # Run the mining process
            & node $miningScript
            
            # If we get here, mining stopped normally
            Write-Host ""
            Write-Host "ℹ️  Mining process ended normally" -ForegroundColor Yellow
            
        } catch {
            # Handle errors with data preservation
            Write-Host ""
            Write-Host "❌ ERROR OCCURRED: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "💾 Your earnings data is still safe!" -ForegroundColor Green
        }
        
        # Show restart options
        Write-Host ""
        Write-Host "🔄 === RESTART OPTIONS ===" -ForegroundColor Cyan
        Write-Host "1. Restart mining (recommended)" -ForegroundColor White
        Write-Host "2. Check persistent data status" -ForegroundColor White  
        Write-Host "3. Graceful shutdown" -ForegroundColor White
        Write-Host ""
        
        $choice = Read-Host "Enter choice (1-3) or press Enter for auto-restart in 10 seconds"
        
        if ([string]::IsNullOrEmpty($choice)) {
            Write-Host "🔄 Auto-restarting in 10 seconds..." -ForegroundColor Yellow
            for ($i = 10; $i -gt 0; $i--) {
                Write-Host "   Restarting in $i..." -ForegroundColor Gray
                Start-Sleep -Seconds 1
            }
            Write-Host "🔄 RESTARTING NOW..." -ForegroundColor Green
            continue
        }
        
        switch ($choice) {
            "1" { 
                Write-Host "🔄 Restarting mining..." -ForegroundColor Green
                continue
            }
            "2" { 
                Show-PersistentStatus
                Read-Host "Press Enter to continue"
                continue
            }
            "3" { 
                Invoke-GracefulShutdown
                return
            }
            default {
                Write-Host "❌ Invalid choice. Auto-restarting..." -ForegroundColor Red
                Start-Sleep -Seconds 2
                continue
            }
        }
    }
}

# Main execution
try {
    # Set execution policy for this session
    Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
    
    # Initialize persistent storage
    Initialize-PersistentStorage
    
    # Check for Node.js
    try {
        $nodeVersion = & node --version 2>$null
        Write-Host "✅ Node.js detected: $nodeVersion" -ForegroundColor Green
    } catch {
        Write-Host "❌ Node.js not found. Please install Node.js first." -ForegroundColor Red
        Write-Host "🌐 Download from: https://nodejs.org/" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    # Show wallet information
    Write-Host "💰 === WALLET CONFIGURATION ===" -ForegroundColor Yellow
    Write-Host "   🏦 BTC → Kraken Pro: 34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf" -ForegroundColor Green
    Write-Host "   🏠 RVN → Local Wallet: RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7" -ForegroundColor Green
    Write-Host "💰 ===============================" -ForegroundColor Yellow
    Write-Host ""
    
    # Final confirmation
    Write-Host "🚀 Ready to start persistent mining!" -ForegroundColor Green
    Write-Host "💡 This window will stay open and preserve all your earnings" -ForegroundColor Cyan
    Write-Host ""
    
    if (-not $Restart) {
        Read-Host "Press Enter to start mining"
    }
    
    # Start the persistent mining system
    Start-PersistentMining -IsRestart $Restart
    
} catch {
    Write-Host ""
    Write-Host "💥 CRITICAL ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "💾 Check if persistent data is intact..." -ForegroundColor Yellow
    
    # Try to show storage status even on error
    try {
        Show-PersistentStatus
    } catch {
        Write-Host "❌ Could not access persistent storage" -ForegroundColor Red
    }
    
    Read-Host "Press Enter to exit"
} finally {
    Write-Host ""
    Write-Host "👋 Seraphina's Persistent Mining System shutdown complete" -ForegroundColor Cyan
}