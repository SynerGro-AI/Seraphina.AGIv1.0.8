// system-repro-verify.js
// Runs system-repro-test.js twice (optionally restoring state) and asserts deterministic equality of combinedDigest.
// Emits a final JSON report with pass/fail plus constituent digests from both runs.
// Env vars influencing behavior:
//  AUR_REPRO_FAST=1 for rapid cycles
//  AUR_REPRO_CYCLE_LIMIT to cap cycles
//  AUR_REPRO_STATE_IN / AUR_REPRO_STATE_OUT for miner state persistence
//  HOLODECK_DNS_STATS_FILE for DNS stats inclusion
//  AI_MEMORY_FILE for memory log inclusion

const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

function runOnce(label){
  const script = path.join(__dirname, 'system-repro-test.js');
  const res = spawnSync(process.execPath, [script], { env: process.env, encoding: 'utf8' });
  if (res.status !== 0){
    return { label, error: res.stderr || res.stdout || ('exit '+res.status) };
  }
  let parsed = null;
  try {
    // Find last JSON block
    const lines = res.stdout.trim().split(/\r?\n/);
    const jsonLine = lines[lines.length-1];
    parsed = JSON.parse(jsonLine);
  } catch(e){
    return { label, error: 'parse-failure '+e.message, raw: res.stdout }; 
  }
  return { label, ...parsed };
}

function main(){
  // Optional clean start: if state in exists, copy to out to simulate resume across runs
  const stateIn = process.env.AUR_REPRO_STATE_IN;
  const stateOut = process.env.AUR_REPRO_STATE_OUT;
  let preState = null;
  if (stateIn && fs.existsSync(stateIn)){
    preState = fs.readFileSync(stateIn, 'utf8');
  }
  const first = runOnce('run1');
  // For second run we allow using state from first if stateOut written
  if (stateOut && fs.existsSync(stateOut)){
    // Promote previous out to next in so second run resumes
    if (stateIn){
      try { fs.copyFileSync(stateOut, stateIn); } catch(e){ /* ignore */ }
    }
  }
  const second = runOnce('run2');
  let pass = false;
  let reason = null;
  if (first.error || second.error){
    reason = 'one-or-both-runs-failed';
  } else if (first.combinedDigest !== second.combinedDigest){
    reason = 'digest-mismatch';
  } else {
    pass = true;
  }
  const report = { pass, reason, run1: first, run2: second, resumedFromState: !!preState };
  console.log(JSON.stringify(report, null, 2));
  process.exit(pass ? 0 : 2);
}

main();