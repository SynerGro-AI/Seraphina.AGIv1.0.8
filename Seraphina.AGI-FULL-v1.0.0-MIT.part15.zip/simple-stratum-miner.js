#!/usr/bin/env node
// simple-stratum-miner.js
// Minimal headless F2Pool BTC/LTC CPU miner (educational) with:
//  - VarDiff share-time estimator (local expected time vs observed)
//  - Simple rolling log rotation
//  - Optional GPU/ASIC proxy mode (local stratum-forwarder) + adaptive hint broadcast
// NOTE: A single CPU will virtually NEVER find a real BTC (or even LTC) share at pool difficulty.
// This script is to validate: connect -> authorize -> receive jobs -> perform valid PoW hashing loop -> submit if below target.
// Your F2Pool account balance will not increase meaningfully without specialized hardware hash rate.

const crypto = require('crypto');
const fs = require('fs');
const net = require('net');
const { RealStratumClient } = require('./real-stratum-client.js');
let scryptsy = null; try { scryptsy = require('scryptsy'); } catch(_) {}

// ---------------- Utility -----------------
function reverseBytes(hex){ const b = Buffer.from(hex,'hex'); b.reverse(); return b.toString('hex'); }
function doubleSha256(hex){ const b=Buffer.from(hex,'hex'); const h1=crypto.createHash('sha256').update(b).digest(); const h2=crypto.createHash('sha256').update(h1).digest(); return h2.toString('hex'); }
function nbitsToTarget(nbits){ const n = parseInt(nbits,16); const exp = n >>> 24; const mant = n & 0xffffff; return BigInt(mant) << (8n * (BigInt(exp)-3n)); }
function buildCoinbase(part1, extranonce1, extranonce2, part2){ return part1 + extranonce1 + extranonce2 + part2; }
function buildMerkleRoot(coinbaseTx, branches){ let merk = doubleSha256(coinbaseTx); for (const br of branches||[]) merk = doubleSha256(merk + br); return merk; }
function buildHeader(job, merkleRoot, nTimeHex, nonceHex){
  const ver = reverseBytes((job.version||'00000002').padStart(8,'0'));
  const prev = reverseBytes(job.prevhash);
  const merk = reverseBytes(merkleRoot);
  const time = reverseBytes(nTimeHex.padStart(8,'0'));
  const bits = reverseBytes(job.nbits.padStart(8,'0'));
  const nonce = reverseBytes(nonceHex.padStart(8,'0'));
  return ver + prev + merk + time + bits + nonce; // 80 bytes hex
}

function litecoinScryptHash(headerHex){
  if (!scryptsy) throw new Error('scryptsy not installed (npm i scryptsy)');
  const buf = Buffer.from(headerHex, 'hex'); if (buf.length !== 80) throw new Error('Expected 80-byte header');
  const out = scryptsy(buf, buf, 1024, 1, 1, 32); // N=1024,r=1,p=1
  return Buffer.from(out).reverse().toString('hex');
}

// ---------------- Config -----------------
const COIN = (process.env.COIN || process.env.AUR_COIN || process.argv.find(a=>a.startsWith('--coin='))?.split('=')[1] || 'btc').toLowerCase();
const USER_BASE = process.env.F2POOL_USER || process.env.STRATUM_USER;
if (!USER_BASE){ console.error('[Config] F2POOL_USER env required.'); process.exit(1); }
const WORKER_SUFFIX = process.env.F2POOL_WORKER || '001';
const WORKER = `${USER_BASE}.${WORKER_SUFFIX}`;
const PASSWORD = process.env.F2POOL_PASSWORD || 'x';

const POOLS = {
  btc: { host: process.env.BTC_POOL_HOST || 'btc.f2pool.com', port: parseInt(process.env.BTC_POOL_PORT||'1314',10), algo: 'sha256d', diff1: '1d00ffff' },
  ltc: { host: process.env.LTC_POOL_HOST || 'ltc.f2pool.com', port: parseInt(process.env.LTC_POOL_PORT||'3335',10), algo: 'scrypt', diff1: '1e0ffff0' }
};
if (!POOLS[COIN]){ console.warn('[Config] Unsupported coin, defaulting to btc'); }
const CFG = POOLS[COIN] || POOLS.btc;

console.log(`[Init] Coin=${COIN} host=${CFG.host}:${CFG.port} worker=${WORKER} algo=${CFG.algo}`);
if (COIN==='ltc' && CFG.algo==='scrypt' && !scryptsy){ console.error('[Init] scryptsy missing. Install for LTC mining: npm install scryptsy'); process.exit(1); }

// Mining loop knobs
const LOOP_BATCH_NONCES = parseInt(process.env.SIMPLE_NONCE_BATCH || '8192',10); // how many nonces per iteration
const YIELD_DELAY_MS = parseInt(process.env.SIMPLE_YIELD_DELAY_MS || '0',10); // add small sleep to reduce CPU
const LOG_FILE = process.env.SIMPLE_LOG_FILE || 'simple-miner.log';
const LOG_MAX_BYTES = parseInt(process.env.SIMPLE_LOG_MAX_BYTES || (5*1024*1024),10); // 5MB
const LOG_ROTATE_KEEP = parseInt(process.env.SIMPLE_LOG_ROTATE_KEEP || '3',10);
const PROXY_ENABLE = process.env.SIMPLE_PROXY === '1';
const PROXY_PORT = parseInt(process.env.SIMPLE_PROXY_PORT || '33300',10);
const PROXY_HOST = process.env.SIMPLE_PROXY_HOST || '0.0.0.0';
const PROXY_MAX_CLIENTS = parseInt(process.env.SIMPLE_PROXY_MAX_CLIENTS || '16',10);
const VARDIFF_TARGET_SECS = parseFloat(process.env.SIMPLE_VARDIFF_TARGET_SECS || '15'); // ideal local share cadence
const VARDIFF_AVG_WINDOW = parseInt(process.env.SIMPLE_VARDIFF_AVG_WINDOW || '20',10);
const VARDIFF_MIN_BATCH = parseInt(process.env.SIMPLE_VARDIFF_MIN_BATCH || '4',10);
const AI_OPTIMIZE = process.env.SIMPLE_AI_OPTIMIZE === '1'; // toggles adaptation hints

// State
let extranonce1 = '';
let extranonce2Size = 0;
let extranonce2Counter = 0;
let currentJob = null;
let target = 0n;
let hashAttempts = 0;
let lastJobTs = 0;
let mining = false;
let diff1Target = nbitsToTarget(CFG.diff1);
// VarDiff tracking
const shareTimes = []; // timestamps (ms) of accepted local shares
let lastLocalShareTs = null;
let adaptiveHashrateEwma = null; // estimated attempts/sec
const HASHRATE_ALPHA = parseFloat(process.env.SIMPLE_HASHRATE_ALPHA || '0.2');
let currentSuggestedDifficulty = null; // purely informational (F2Pool sets diff server side)
// Proxy state
const proxyClients = new Set();
let lastProxyJobBroadcast = 0;
let proxyJobSerial = 0;

// Stratum client
const client = new RealStratumClient({ host: CFG.host, port: CFG.port, coin: COIN.toUpperCase(), worker: WORKER, password: PASSWORD });
client.on('connected', ()=> console.log('[Stratum] Connected'));
client.on('subscribed', (s)=> { extranonce1 = s.extranonce1; extranonce2Size = s.extranonce2Size; console.log(`[Stratum] Subscribed extranonce1=${extranonce1} ex2Size=${extranonce2Size}`); });
client.on('authorized', ()=> console.log('[Stratum] Authorized'));
client.on('job', (job)=> {
  currentJob = job;
  extranonce2Counter = 0;
  target = nbitsToTarget(job.nbits);
  lastJobTs = Date.now();
  console.log(`[Stratum] New job id=${job.jobId} nbits=${job.nbits} targetBits=${job.nbits}`);
  if (!mining){ mining = true; setImmediate(mineLoop); }
});
client.on('shareAccepted', (r)=> {
  console.log(`[Share] Accepted job=${r.jobId}`);
  const now = Date.now();
  if (lastLocalShareTs){
    shareTimes.push(now - lastLocalShareTs);
    while (shareTimes.length > VARDIFF_AVG_WINDOW) shareTimes.shift();
  }
  lastLocalShareTs = now;
  evaluateVarDiff();
});
client.on('shareRejected', (r)=> console.log(`[Share] Rejected job=${r.jobId} error=${JSON.stringify(r.error)}`));
client.on('error', e=> console.log('[Stratum] Error', e.message));
client.on('closed', ()=> console.log('[Stratum] Closed'));
client.connect().catch(e=> { console.error('[Stratum] Connect failed', e.message); process.exit(1); });

function rotateLogIfNeeded(){
  try {
    if (!fs.existsSync(LOG_FILE)) return;
    const st = fs.statSync(LOG_FILE);
    if (st.size < LOG_MAX_BYTES) return;
    // rotate: simple numeric suffix
    for (let i = LOG_ROTATE_KEEP - 1; i >= 0; i--){
      const src = i === 0 ? LOG_FILE : `${LOG_FILE}.${i}`;
      const dst = `${LOG_FILE}.${i+1}`;
      if (fs.existsSync(src)){
        if (i+1 >= LOG_ROTATE_KEEP){
          try { fs.unlinkSync(dst); } catch(_){}
        } else {
          try { fs.renameSync(src, dst); } catch(_){}
        }
      }
    }
  } catch(_){}
}

function appendLog(line){
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch(_){}
}

function evaluateVarDiff(){
  if (shareTimes.length < VARDIFF_MIN_BATCH) return;
  const avgMs = shareTimes.reduce((a,b)=>a+b,0)/shareTimes.length;
  const avgSecs = avgMs/1000;
  const ratio = avgSecs / VARDIFF_TARGET_SECS;
  // Suggest a pseudo-difficulty scale: if we're delivering too fast (< target), raise; too slow, lower.
  if (!currentSuggestedDifficulty) currentSuggestedDifficulty = 1.0;
  if (ratio < 0.8) currentSuggestedDifficulty *= 1.2; else if (ratio > 1.3) currentSuggestedDifficulty *= 0.85;
  currentSuggestedDifficulty = Math.max(0.01, Math.min(1e6, currentSuggestedDifficulty));
  console.log(`[VarDiff] avgShareTime=${avgSecs.toFixed(2)}s target=${VARDIFF_TARGET_SECS}s ratio=${ratio.toFixed(2)} suggestDiff=${currentSuggestedDifficulty.toFixed(2)}`);
  appendLog(`[VarDiff] ${Date.now()} avgMs=${Math.round(avgMs)} diffSuggest=${currentSuggestedDifficulty.toFixed(4)}`);
  if (AI_OPTIMIZE) broadcastAdaptiveHint();
}

function broadcastAdaptiveHint(){
  if (!PROXY_ENABLE || proxyClients.size===0) return;
  const payload = JSON.stringify({ type:'hint', suggestedDifficulty: currentSuggestedDifficulty, ts: Date.now(), hashrate: adaptiveHashrateEwma });
  for (const sock of proxyClients){ try { sock.write(payload+'\n'); } catch(_){} }
}

function startProxy(){
  if (!PROXY_ENABLE) return;
  const server = net.createServer(socket => {
    if (proxyClients.size >= PROXY_MAX_CLIENTS){ socket.end(); return; }
    proxyClients.add(socket);
    socket.setEncoding('utf8');
    socket.on('close', ()=> proxyClients.delete(socket));
    socket.on('error', ()=> proxyClients.delete(socket));
    // Send a greeting
    socket.write(JSON.stringify({ type:'welcome', algo: CFG.algo, coin: COIN })+'\n');
    // If we already have a job snapshot, ship immediately
    if (currentJob) emitProxyJob(socket, currentJob);
  });
  server.listen(PROXY_PORT, PROXY_HOST, ()=> console.log(`[Proxy] Listening on ${PROXY_HOST}:${PROXY_PORT} (maxClients=${PROXY_MAX_CLIENTS})`));
}

function emitProxyJob(sock, job){
  const jobMsg = JSON.stringify({ type:'job', serial: ++proxyJobSerial, jobId: job.jobId, version: job.version, prevhash: job.prevhash, part1: job.part1, part2: job.part2, merkle: job.merkleBranches, nbits: job.nbits, ntime: job.ntime, extranonce1, extranonce2Size });
  try { (sock || {}).write ? sock.write(jobMsg+'\n') : null; } catch(_){}
}

function broadcastJob(job){
  if (!PROXY_ENABLE || proxyClients.size===0) return;
  lastProxyJobBroadcast = Date.now();
  for (const sock of proxyClients){ emitProxyJob(sock, job); }
}

startProxy();

function mineLoop(){
  if (!currentJob || !extranonce1){ return setTimeout(mineLoop, 500); }
  const localJob = currentJob; // snapshot
  for (let i=0;i<LOOP_BATCH_NONCES;i++){
    const extranonce2 = (extranonce2Counter++).toString(16).padStart(extranonce2Size*2,'0');
    if (extranonce2.length !== extranonce2Size*2){ continue; }
    const coinbase = buildCoinbase(localJob.part1, extranonce1, extranonce2, localJob.part2);
    const merkle = buildMerkleRoot(coinbase, localJob.merkleBranches);
    // Increment time a little every batch to avoid stale timestamp (bounded to 32-bit)
    let nTime = parseInt(localJob.ntime,16) + (i & 0xFF);
    nTime = (nTime >>> 0).toString(16).padStart(8,'0');
    // Scan a small nonce slice
    for (let nonceStep=0; nonceStep<8; nonceStep++){
      const nonceHex = ((i<<3)+nonceStep).toString(16).padStart(8,'0');
      const headerHex = buildHeader(localJob, merkle, nTime, nonceHex);
      let hashHex;
      if (CFG.algo==='sha256d'){ hashHex = doubleSha256(headerHex); }
      else if (CFG.algo==='scrypt'){ hashHex = litecoinScryptHash(headerHex); }
      else { hashHex = doubleSha256(headerHex); }
      const hashInt = BigInt('0x'+ reverseBytes(hashHex));
      hashAttempts++;
      if (adaptiveHashrateEwma==null){ adaptiveHashrateEwma = hashAttempts; } else if (hashAttempts % 1000 === 0){
        const elapsed = (Date.now()-lastJobTs)/1000 || 1;
        const inst = hashAttempts/elapsed;
        adaptiveHashrateEwma = adaptiveHashrateEwma*(1-HASHRATE_ALPHA) + inst*HASHRATE_ALPHA;
      }
      if (hashInt <= target){
        // Share difficulty indicator (approx)
        let shareDiff = 0; try { shareDiff = Number(diff1Target / (hashInt===0n?1n:hashInt)); } catch(_){ }
        const line = `[Share] FOUND hash=${hashHex.slice(0,16)}… diff≈${shareDiff.toFixed(2)}`;
        console.log(line);
        appendLog(line);
        client.submitShare({ jobId: localJob.jobId, extranonce2, ntime: nTime, nonce: nonceHex });
      }
    }
  }
  if (hashAttempts % 500000 === 0){
    const elapsed = (Date.now()-lastJobTs)/1000; const khs = (hashAttempts/elapsed)/1000; const status = `[Hash] attempts=${hashAttempts} ${khs.toFixed(1)} kH/s`; process.stdout.write(`\r${status}        `); appendLog(status); rotateLogIfNeeded();
  }
  if (currentJob === localJob){ // still same job
    if (YIELD_DELAY_MS>0) return setTimeout(()=>setImmediate(mineLoop), YIELD_DELAY_MS);
    setImmediate(mineLoop);
  } else {
    setImmediate(mineLoop); // job switched
  }
}

process.on('SIGINT', ()=>{ console.log('\n[Exit] Stopping. Total attempts:', hashAttempts); process.exit(0); });
