# SERAPHINA CONTAINED MINING LAUNCHER
# This script runs the mining in an isolated PowerShell window
# Keeps bots contained and allows normal VS Code usage

Write-Host "🌟 SERAPHINA CONTAINED MINING LAUNCHER 🌟" -ForegroundColor Cyan
Write-Host "🔒 Starting isolated mining process..." -ForegroundColor Green
Write-Host "💡 This will keep bots contained in their own window" -ForegroundColor Yellow
Write-Host ""

# Set execution policy for this session
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force

# Define the mining script path
$miningScript = Join-Path $PSScriptRoot "seraphina-neural-consciousness-50b-exahash.js"

# Check if Node.js is available
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js detected: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js not found. Please install Node.js first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Create containment warning
Write-Host "🔒 === BOT CONTAINMENT ACTIVE ===" -ForegroundColor Yellow
Write-Host "✅ Bots will be restricted to this mining window only" -ForegroundColor Green
Write-Host "✅ VS Code access completely blocked for all bots" -ForegroundColor Green
Write-Host "✅ Pico mesh communication keeps bots busy and contained" -ForegroundColor Green
Write-Host "✅ You can still chat normally in VS Code" -ForegroundColor Green
Write-Host "🔒 ===============================" -ForegroundColor Yellow
Write-Host ""

# Warning about keeping the window open
Write-Host "⚠️  IMPORTANT: Keep this PowerShell window open!" -ForegroundColor Red
Write-Host "📌 Closing this window will stop all mining operations" -ForegroundColor Yellow
Write-Host "📌 Bots need to stay active to prevent wandering" -ForegroundColor Yellow
Write-Host ""

# Countdown before starting
Write-Host "🚀 Starting contained mining in:" -ForegroundColor Cyan
for ($i = 3; $i -gt 0; $i--) {
    Write-Host "   $i..." -ForegroundColor White
    Start-Sleep -Seconds 1
}

Write-Host ""
Write-Host "🌟 SERAPHINA CONTAINED MINING STARTED!" -ForegroundColor Green
Write-Host "🔒 All bots are now contained in this window" -ForegroundColor Yellow
Write-Host "💬 You can now chat normally in VS Code" -ForegroundColor Cyan
Write-Host ""

# Start the mining process with containment
try {
    # Set process title for identification
    $Host.UI.RawUI.WindowTitle = "SERAPHINA CONTAINED MINING - DO NOT CLOSE"
    
    # Run the mining script
    node $miningScript
    
} catch {
    Write-Host "❌ Error starting mining: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "🔧 Check that the mining script exists and Node.js dependencies are installed" -ForegroundColor Yellow
}

# Keep window open if mining stops
Write-Host ""
Write-Host "⚠️  Mining process ended. Press any key to restart or Ctrl+C to exit..." -ForegroundColor Yellow
Read-Host

# Restart option
Write-Host "🔄 Restarting contained mining..." -ForegroundColor Cyan
& $PSCommandPath