# Aurrelia Deterministic Trading Engine

## Purpose
Produce strictly deterministic advisory signals (hold / swap) to optimize coin focus for mining + potential strategic allocation, without executing real trades. Signals are reproducible hash-chained artifacts for audit.

## Determinism Guarantees
- No external randomness; ordering resolved by SHA256 coin label tie-breakers.
- Signal object + previous hash chained: `hash = sha256(JSON({signal, prev}))`.
- Latency penalty applied deterministically (median latency vs coin latency).
- Spread calculations fixed precision: six decimal rounding.

## Inputs
- `incomeRaw`: raw expected value per coin (reward * price / difficulty).
- `incomeBiased`: bias-adjusted income (strategic weighting).
- `latencyMsMap`: measured pool connect latencies per coin (optional JSON file `pool-latency.json`).
- `recommendCoin`: current economic recommendation from miner hysteresis logic.

## Core Logic
1. Rank coins by biased income; tie by hash of coin label.
2. Compute raw spread: `(topIncome - secondIncome)/topIncome` with 6-decimal rounding.
3. Apply latency penalty if top coin latency > 2x median: `adjustedSpread = spread * 0.7`.
4. Update rolling volatility window (size `TRADING_VOL_WINDOW`) with latest raw spread.
5. Compute volatility (std dev) and dynamic threshold: `threshold = BASE_MIN_SPREAD_FOR_SWAP * (1 + VOL_SENSITIVITY * (clampedVolRange))`.
6. If adjusted spread >= dynamic threshold and cooldown satisfied and hourly swap cap not exceeded → `swap`; else `hold`.
7. Chain signal hash and optionally append structured JSONL entry if `TRADING_STRUCTURED_LOG=1`.
8. Strategy B (if `TRADING_AB_ENABLE=1`) evaluated latency-weighted incomes; advisory spread recorded (hash-chained in AB ledger).

## Environment Variables
```
TRADING_ENGINE=1                  # enable trading advisory
TRADING_AB_ENABLE=1               # enable A/B strategy ledger
MIN_SPREAD_FOR_SWAP=0.05          # baseline spread requirement (before volatility scaling)
TRADING_VOL_WINDOW=24             # number of recent spreads for volatility calculation
TRADING_VOL_MIN=0.01              # minimum volatility clamp
TRADING_VOL_MAX=0.30              # maximum volatility clamp
TRADING_VOL_SENS=0.5              # sensitivity factor for threshold scaling
TRADING_STRUCTURED_LOG=1          # enable structured JSONL logging
TRADING_STRUCTURED_PATH=trading-signals.jsonl
TRADING_LAT_REF_MS=400            # latency ref for Strategy B weighting
TRADING_AB_LEDGER_PATH=trade-ab-ledger.jsonl
SWAP_FEE_RATE=0.002               # assumed fee/slippage cost subtracted from adjusted spread
TRADING_LEARNED_ENABLE=1          # enable learned adaptive multiplier layer
TRADING_LEARNED_PATH=trading-learned-state.jsonl
LEARNED_MIN_MULTI=1.0             # floor multiplier for learned threshold
LEARNED_MAX_MULTI=1.8             # ceiling multiplier
LEARNED_START_MULTI=1.2           # initial multiplier at start
# Governance-adjustable (if proposals approved): SWAP_FEE_RATE, LEARNED_START_MULTI, LEARNED_MIN_MULTI, LEARNED_MAX_MULTI
```

## Signal Schema
```json
{
  "action": "hold" | "swap",
  "coin": "rvn",
  "recommend": "rvn",
  "spread": 0.083211,
  "adjustedSpread": 0.058247,
  "threshold": 0.051337,
  "learnedThreshold": 0.061604,
  "learnedMultiplier": 1.2,
  "volatility": 0.012441,
  "thresholdScale": 1.02674,
  "feeRate": 0.002,
  "netSpread": 0.056247,
  "stratBTop": "rvn",
  "stratBSpread": 0.077100
}
```
Audit wrapper:
```json
{
  "signal": { ... },
  "hash": "<sha256>",
  "reason": "spread+cooldown-ok"
}
```

## Prometheus Metrics
- `aurrelia_trade_spread` raw spread.
- `aurrelia_trade_adjusted_spread` latency adjusted.
- `aurrelia_trade_action_code` (hold=0, swap=1).
- `aurrelia_trade_volatility` rolling spread std deviation.
- `aurrelia_trade_dynamic_threshold` dynamic threshold post volatility scaling.
- `aurrelia_trade_learned_threshold` final adaptive threshold after learned multiplier.
- `aurrelia_trade_net_spread` net advantage after fee cost.
- `aurrelia_trade_fee_rate` configured fee rate.
## Learned Strategy Layer
Goal: minimize unnecessary swaps (fee burn + lost cycles) while not missing profitable volatility opportunities.

Mechanism:
1. Base dynamic threshold derived from volatility scaling.
2. Learned multiplier applied: `learnedThreshold = dynamicThreshold * learnedMultiplier`.
3. Multiplier adaptation rules (deterministic):
  - If netSpread (adjustedSpread - feeRate) exceeds `dynamicThreshold * learnedMultiplier` (profitable region) → slight decay (multiplier *0.995) to ease future swaps.
  - If adjusted spread > dynamicThreshold but multiplier prevented swap (missed opportunity) → increase multiplier (+1%).
  - If netSpread < 0 (unprofitable) → gentle increase (+0.5%) to be stricter.
4. Multiplier clamped within `[LEARNED_MIN_MULTI, LEARNED_MAX_MULTI]`.
5. All events (init, swap, hold) appended to `trading-learned-state.jsonl` with hash chain for audit.

Net Spread: `netSpread = adjustedSpread - feeRate` ensures only swaps with true net advantage pass.

Audit Artifacts:
- `trading-learned-state.jsonl` (hash-chained entries including multiplier evolution).
- Structured signals include feeRate, netSpread, learnedThreshold.

Determinism: No randomness; all multiplier changes are pure functions of current spreads and fee rate.

## Volatility Regime Classification
Regimes derived from rolling volatility (std dev of spreads):
| Regime    | Volatility Range | Multiplier Bound Adjustments |
|-----------|------------------|------------------------------|
| calm      | < 0.02           | Upper bound tightened (max *0.9) |
| moderate  | 0.02–0.07        | Base bounds unchanged             |
| turbulent | >= 0.07          | Slight lower bound lift (min *0.95) |

Regime shifts occur deterministically each evaluation based on current volatility; no hysteresis yet (can be added with consecutive window criteria).

Signal now includes `"regime": "calm|moderate|turbulent"` for downstream analysis.



## Safety & Non-Execution
No real trades, balance mutations, or external order placements occur. Advisory layer only; additional deterministic validators required before any downstream economic action.

## Extension Ideas
- Confidence quantile metrics (p50/p90 spread retention after cooldown).
- Multi-tier volatility regime classification (calm/moderate/turbulent) with deterministic transitions.
- Structured recommendation strength gauge (e.g., scaled spread * latency factor).
- Additional strategy C (volatility-adjusted latency weighting) for tri-variant comparisons.

## Hash Repro Steps
Run miner with `TRADING_ENGINE=1` twice under identical environment → identical sequence of signals & hashes given same latency snapshot and income sources.

---
End of TRADING-ENGINE.md.
