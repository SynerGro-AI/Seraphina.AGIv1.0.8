'use strict';
const fs = require('fs');
const path = require('path');
const { autonomousCycle } = require('./autonomy-decision-engine.js');
process.env.AUTONOMY_ENABLED = '1';
process.env.REGRESSION_WINDOW_SIZE = '3';
process.env.GLOBAL_MIN_IMPROVEMENT = '0.6';
process.env.IMAGINATION_GAIN_WEIGHT = '0.5';
// fabricate summary ledger with decline
const ledger = path.join(__dirname,'ai-learning-summary-ledger.jsonl');
const entries = [
  { improvement:{ effectiveImprovement:0.7 } },
  { improvement:{ effectiveImprovement:0.55 }, dimensionCost:50 },
  { improvement:{ effectiveImprovement:0.5 }, dimensionCost:50 }
];
fs.writeFileSync(ledger, entries.map(e=> JSON.stringify(e)).join('\n')+'\n');
const draft = autonomousCycle();
process.stdout.write(JSON.stringify({ draftEmitted: !!draft },null,2)+'\n');