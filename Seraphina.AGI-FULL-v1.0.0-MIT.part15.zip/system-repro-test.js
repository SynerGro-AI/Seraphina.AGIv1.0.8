// system-repro-test.js
// Combined reproducibility harness: runs language engine deterministic init and miner limited cycles.
// Produces final combined digest for cross-component determinism verification.

const { spawnSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');

function runLanguageEngine(){
  const env = { ...process.env, SERAPHINA_STRICT_DETERMINISM:'1', SERAPHINA_SEED: process.env.SERAPHINA_SEED || 'system-repro-seed' };
  const root = process.env.SERAPHINA_ROOT || 'C:/Users/jmwil/Downloads/Seraphina-Smart-Assistant/SynerGro.AI_Client_8.0.1/AI_core';
  const smokePath = root.replace(/\\/g,'/') + '/determinism-smoke-test.js';
  const fs = require('fs');
  if (!fs.existsSync(smokePath)) throw new Error('smoke test not found at '+smokePath+' (set SERAPHINA_ROOT)');
  const r = spawnSync('node', [ smokePath ], { encoding:'utf8', env });
  if (r.status !== 0) throw new Error('language engine smoke failed: '+r.stderr);
  const lines = (r.stdout||'').trim().split(/\r?\n/);
  const matched = lines.filter(l=> l.startsWith('[MATCH]') || l.includes('Determinism smoke test PASSED'));
  const digestLine = lines.find(l=> l.includes('[MATCH] digest'));
  return { raw: r.stdout, matched, digestSource: digestLine };
}

function runMinerCycles(){
  const env = { ...process.env, AUR_REPRO_CYCLE_LIMIT: process.env.AUR_REPRO_CYCLE_LIMIT || '5', DISABLE_DOTENV:'1', AUR_REPRO_FAST:'1' };
  // Provide deterministic seed overrides if desired
  env.GLOBAL_OCTO_SEED = env.GLOBAL_OCTO_SEED || 'octo-repro-seed';
  env.HOLODECK_ENABLE = env.HOLODECK_ENABLE || '0';
  // Supply mock wallets if enforcement flags present to avoid exit
  env.FREN_WALLET = env.FREN_WALLET || 'FMockDeterministicWalletAddr';
  env.RVN_LOCAL_ADDRESS = env.RVN_LOCAL_ADDRESS || 'RMockDeterministicWalletAddr';
  const r = spawnSync('node', [ 'aurrelia-pico-mesh-miner.js' ], { encoding:'utf8', env });
  if (r.status !== 0) throw new Error('miner repro failed code='+r.status+' stderr='+r.stderr);
  const digestMatch = (r.stdout||'').match(/\[REPRO\]\[FAST\] cycles=\d+ digest=([0-9a-f]+)/) || (r.stdout||'').match(/\[REPRO\] limit reached cycles=\d+ digest=([0-9a-f]+)/);
  const digest = digestMatch ? digestMatch[1] : null;
  // Run ledger-chain verification (will produce ledger-verify.json). Skip failure escalation; capture hash only.
  let ledgerSummaryHash = null; let ledgerRaw = null;
  try {
    const lv = spawnSync('node', ['ledger-chain-verify.js'], { encoding:'utf8', env });
    ledgerRaw = (lv.stdout||'') + (lv.stderr||'');
    if (lv.status === 0 || lv.status === 1){ // even if ledgers invalid we include summary file hash
      if (fs.existsSync('ledger-verify.json')){
        const data = fs.readFileSync('ledger-verify.json');
        ledgerSummaryHash = crypto.createHash('sha256').update(data).digest('hex');
      }
    }
  } catch(e){ /* ignore */ }
  return { raw: r.stdout, digest };
}

function main(){
  try {
    const le = runLanguageEngine();
    const miner = runMinerCycles();
    if (!miner.digest) throw new Error('miner digest not found');
    // Optional DNS stats file hash
    const dnsStatsPath = process.env.HOLODECK_DNS_STATS_FILE || 'holodeck-dns-stats.json';
    let dnsHash = null;
    if (fs.existsSync(dnsStatsPath)){
      dnsHash = crypto.createHash('sha256').update(fs.readFileSync(dnsStatsPath)).digest('hex');
    }
    // AI memory log hash (if enabled and file exists)
    const aiMemPath = process.env.AI_MEMORY_FILE || 'ai-memory.jsonl';
    let aiMemHash = null;
    if (fs.existsSync(aiMemPath)){
      aiMemHash = crypto.createHash('sha256').update(fs.readFileSync(aiMemPath)).digest('hex');
    }
    // Combine digests (language engine portion uses matched lines hashed)
    const leDigest = crypto.createHash('sha256').update(le.matched.join('\n')).digest('hex');
    const parts = [leDigest, miner.digest];
    if (dnsHash) parts.push(dnsHash);
    if (aiMemHash) parts.push(aiMemHash);
    // Include ledger summary hash if present
    if (fs.existsSync('ledger-verify.json')){
      const ledgerData = fs.readFileSync('ledger-verify.json');
      const ledgerHash = crypto.createHash('sha256').update(ledgerData).digest('hex');
      parts.push(ledgerHash);
    }
    // ML advisor weights version hash (if module available)
    let mlWeightsHash = null;
    try {
      const ml = require('./deterministic-ml-advisor.js');
      mlWeightsHash = ml.WEIGHTS_VERSION_HASH || null;
      if (mlWeightsHash){ parts.push(mlWeightsHash); }
    } catch(e){ /* ignore */ }
    const combined = crypto.createHash('sha256').update(parts.join(':')).digest('hex');
    console.log(JSON.stringify({ languageEngineDigest: leDigest, minerDigest: miner.digest, dnsStatsHash: dnsHash, aiMemoryHash: aiMemHash, mlWeightsVersionHash: mlWeightsHash, combinedDigest: combined }, null, 2));
    process.exit(0);
  } catch(e){
    console.error('[SYSTEM_REPRO] failure', e.message);
    process.exit(1);
  }
}

main();
