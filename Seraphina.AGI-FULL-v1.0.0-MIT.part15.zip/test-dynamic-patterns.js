// test-dynamic-patterns.js
'use strict';
const fs = require('fs');
const path = require('path');
function writePatterns(){
  const patterns = [ { risk:'HIGH', regex:'\\bformat\\s+disk\\b', reason:'Disk format phrase' }, { risk:'MED', regex:'\\bchgrp\\b', reason:'Group ownership change' } ];
  fs.writeFileSync(path.join(__dirname,'command-risk-patterns.json'), JSON.stringify(patterns,null,2));
}
function run(){
  process.env.COMMAND_RISK_PATTERNS_ENABLE='1';
  writePatterns();
  const { classify } = require('./command-risk-classifier');
  const a = classify('format disk now');
  const b = classify('chgrp users file.txt');
  console.log(JSON.stringify({ formatDisk:a, chgrp:b }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };
