# Seraphina Coder Triad

## Overview
The Seraphina Coder Triad adds autonomous, deterministic code auditing capabilities to OctaLang blocks. It consists of three tiers:

1. Tier1 Syntax (`seraphina-coder-tier1.js`): Lightweight line/token scanner detecting structural issues (long lines, TODO markers, trailing whitespace, bracket balance). Purely deterministic; no execution.
2. Tier2 Optimization (`seraphina-coder-tier2.js`): Heuristic quality scoring (0..1) based on average line length, comment density, TODO burden, and a complexity token ratio. Emits actionable suggestions.
3. Tier3 Mesh (`seraphina-coder-tier3.js`): Maintains a registry of registered code blocks and suggests affinity links based on shared digest signature prefixes.

The orchestrator (`seraphina-coder-triad.js`) combines all tiers, exposing a `triadCycle()` that returns syntax, optimization, and mesh link suggestions together with a deterministic digest for tamper-evident logging.

## Determinism
All scoring and digests use SHA256 hashing; no runtime randomness. Seed can be fixed via `SERAPHINA_CODER_SEED` for stable cross-run signatures.

## Metrics (Optional Prometheus)
If `prom-client` is available at runtime:
- `seraphina_coder_syntax_checks_total`
- `seraphina_coder_optimizations_total`
- `seraphina_coder_mesh_links_total`
- `seraphina_coder_last_quality_score`

## Integration Pattern
```
const { CoderTriad } = require('./seraphina-coder-triad');
const triad = new CoderTriad();
const code = fs.readFileSync(__filename,'utf8');
triad.registerBlock('my-block', code);
const res = triad.triadCycle({ id:'my-block', code });
console.log(res.optimization.score, res.syntax.ok, res.links.links);
```

`triad_miner.js` demonstrates periodic auditing every 6 heartbeats.

## Environment Variables

- `SERAPHINA_CODER_SEED` – Seed for deterministic hashing.
- `SERAPHINA_CODER_MESH_PATH` – Persist mesh registry JSON when set (saved every 5 syntax checks).
- `SERAPHINA_CODER_PROVENANCE_PATH` – Append JSONL provenance record each triad cycle.
- `AUR_TRIAD_AUDIT_PATHS` – Comma-separated file list for Aurelia miner parity auditing.
- `AUR_TRIAD_SEED` – Seed override for Aurelia triad instance.
- `SERAPHINA_CODE_HEALTH_WEIGHTS` – Path to saved code health weights loaded by miner.
- `SERAPHINA_FRAME_CULL_HAM` – Normalized Hamming distance threshold (0..1) below which animation frames are culled (not written as Merkle leaves). Default `0.01`.
- `SERAPHINA_FRAME_CULL_ADAPT` – If set to `1`/`true`, enables adaptive threshold tuning based on rolling median of recent written frame distances (damped toward 70% of median).
- `SERAPHINA_FRAME_FORCE_N` – Positive integer; every Nth frame is force-retained even if under threshold to prevent long silent spans (0 disables).
- `SERAPHINA_FRAME_AGENT_ANNOTATE` – If `1`/`true`, adds an agent annotation Merkle leaf on forced retention frames for audit transparency.
- `SERAPHINA_FRAME_CULL_LOCK` – If `1`/`true`, locks cull threshold after first adaptation event (replay determinism).
- `SERAPHINA_FRAME_CULL_HIST_PATH` – File path to write JSON histogram of recent written frame distances.
- `SERAPHINA_SECURITY_HEURISTICS_PATH` – Path to a JSON file containing latest security heuristics snapshot for correlation leaves.
- `SERAPHINA_METRICS_PORT` – If set and `prom-client` available, starts an HTTP server exposing `/metrics`.
- `SERAPHINA_FRAME_AUTO_SECURITY` – If `1`/`true`, auto-generates a fresh security heuristics snapshot each animation batch (requires heuristics module).
- `SERAPHINA_REPLAY_SPIKE_THRESH` – Replay validator spike escalation threshold (default `0.12`). Any single Hamming distance ≥ this promotes overall health from `healthy` to `caution`.
- `SERAPHINA_REPLAY_METRICS_PORT` – If set, replay validator exports Prometheus metrics (`seraphina_replay_avg_ham`, `seraphina_replay_max_ham`, `seraphina_replay_mismatches`, `seraphina_replay_health_level`).
- `SERAPHINA_CHAIN_HMAC_KEY` – Optional secret key enabling per-line HMAC (`chainHmac`) over rolling provenance chain hash for tamper-evident audit.
- `SERAPHINA_FRAME_VERTEX_DEC` – Base vertex quantization decimals (default 3) controlling projection precision.
- `SERAPHINA_FRAME_VERTEX_DEC_MIN` / `SERAPHINA_FRAME_VERTEX_DEC_MAX` – Bounds for adaptive quantization (defaults 2/6).
- `SERAPHINA_FRAME_VERTEX_DEC_ADAPT` – If `1`/`true`, dynamically adjusts vertex decimals based on rolling distance variance (tightens when variance low, loosens when high).
- `SERAPHINA_FRAME_PROV` – If `1`/`true`, emit per-frame ham provenance records (`frameHam`).
- `SERAPHINA_FRAME_COMPRESS` – If `1`/`true`, aggregate consecutive low-diff frames below threshold into grouped `frameHamGroup` records to reduce JSONL volume.
- `SERAPHINA_FRAME_COMPRESS_HAM` – Hamming distance upper bound for inclusion in compression group (default `0.003`).
- `SERAPHINA_REPLAY_EMA_ALPHA` – Exponential smoothing alpha (0<alpha≤1) for replay health classification; when set, EMA replaces raw average for health thresholds and `seraphina_replay_ema_avg_ham` metric is emitted.
    
### Compression Group Metrics (Prometheus)
When compression enabled and metrics active:
	- `seraphina_frame_group_flush_total` – Total number of flushed `frameHamGroup` batches.
	- `seraphina_frame_group_frames_total` – Cumulative frames represented across all flushed groups.
	- `seraphina_frame_group_last_flush_size` – Size of the most recent flushed group.
	- `seraphina_frame_group_current_size` – Current in-progress buffer size (updated as frames are added before flush).

## Merkle Provenance Ledger

`unified-octalang-gpu.js` introduces a pure JS Merkle ledger (`MerkleLedger`) capturing:
- Grammar tier digests (keywords/emojis/symbols).
- Phase leaf (Golden ratio `phi`).
- Per-frame animation hashes (tesseract projection frames).

Root hash is embedded into generated `.octaml5` as `provenance_root` and broadcast over multiplayer WebSocket for replay integrity verification. Leaves are SHA-256 over JSON payload; odd leaf duplication ensures full binary tree construction. Root stability enables:
1. Collision replay validation (physics states vs recorded frame hash).
2. Agent annotation attestation (additional leaves referencing suggestion digests).
3. Future Merkle chunk rotation (ledger compression + Merkle-of-Merkle layering).

## Hamming Diff Monitoring

`unified-octalang-gpu.js` integrates `HammingMonitor` to track normalized bit flip rates between consecutive SHA-256 digests (frame hashes and evolving Merkle roots). Thresholds:
- `< 5%` average: healthy
- `5% - 12%`: caution
- `> 12%`: critical divergence (potential tamper or unexpected high-variance update)

Broadcast payload includes `health` classification for real-time multiplayer coherence checks. Divergences can trigger frame culling, compression opportunism (skip near-identical frames), or agent review.

### Frame Culling & Compression
`unified-octalang-gpu.js` implements threshold-based frame pruning using environment variable `SERAPHINA_FRAME_CULL_HAM` (default `0.01`). For each projected tesseract frame hash:

1. Compute normalized Hamming distance (`dist`) to last written (non-culled) frame hash.
2. If `dist < threshold`, frame is culled: no Merkle leaf added, but diff monitored under type `frame-cull` for analytics.
3. If `dist >= threshold`, frame hash added as Merkle leaf and becomes new baseline.

Metrics logged:
- `written`: number of frames retained.
- `culled`: number of frames skipped.
- `cullRatio`: `culled / total`.
- `threshold`: effective threshold used.

Rationale: reduces ledger growth and storage/bandwidth overhead when motion is low or near-identical successive frames appear. Integrity maintained as meaningful changes (above threshold) still produce leaves influencing the Merkle root evolution.

Future Enhancements:
- Persist `cullStats` to provenance JSONL for long-run analysis.
- Adaptive threshold tuning guided by average diff distribution (auto-lower during stable epochs, raise when variance spikes).
- Multi-tier culling (soft skip vs hard skip) enabling periodic forced retention to prevent starvation.
- Agent advisory leaves describing cull decisions for audit transparency.
 - Broadcast extended cull statistics with Merkle root for multiplayer synchronization.
 - Dynamic agent suggestion leaves linking optimization hints to retained frames.
	- Replay validator confirms `adaptProof` hashes and cull lock integrity.
	- Metrics endpoint service discovery with scrape interval recommendations.

### Adaptation Integrity & Replay
Each adaptive threshold shift appends an `adaptProof` Merkle leaf containing:
`{ adaptProof: <sha256(sorted distances)>, count: <window size>, median: <median> }`.
Replay validator recomputes sorted distance hash from provenance entries and ensures leaf integrity. When `SERAPHINA_FRAME_CULL_LOCK` is enabled, only the first adaptation modifies threshold; subsequent attempts emit a single `cullLock` leaf.

Rolling Provenance Chain: Each provenance JSONL line now embeds `chainPrev`, `chainDigest`, `chainHash`, and optional `chainHmac` when `SERAPHINA_CHAIN_HMAC_KEY` is set. Construction:
`chainDigest = sha256(rawRecord)`, `chainHash = sha256(chainPrev + ':' + chainDigest)`. Any removal, reordering, or mutation invalidates downstream `chainHash` values enabling linear tamper detection without full Merkle recomputation.

Multi-Series Hamming Separation: Animation provenance records add separate aggregates for `frame` vs `root` vs `cull` Hamming evolution. Final records include arrays in `hamSeriesFinal` for granular replay diagnostics and model guidance (e.g., distinguishing root volatility from frame redundancy).

Adaptive Quantization: When enabled (`SERAPHINA_FRAME_VERTEX_DEC_ADAPT=1`), the engine observes rolling average frame distance; if stable (< threshold/2) it decreases decimals (toward `SERAPHINA_FRAME_VERTEX_DEC_MIN`) to amplify culling effectiveness; if volatile (> threshold*4) it increases decimals (up to `SERAPHINA_FRAME_VERTEX_DEC_MAX`) preserving detail.

Frame Compression Groups: Consecutive frames with Hamming < `SERAPHINA_FRAME_COMPRESS_HAM` are buffered and flushed as `frameHamGroup` summarizing min/max/avg and written count, lowering provenance noise while retaining variance signature.

Chain Verification Utility: `seraphina-chain-verify.js --provenance=<file>` walks JSONL validating `chainDigest` and `chainHash` transitions; optional `--hmacKey` enforces `chainHmac`. Non-zero exit signals integrity failure. Useful for CI gating prior to archival rotation.

Per-Series Gauges: Additional Prometheus metrics:
	- `seraphina_ham_frame_avg`
	- `seraphina_ham_root_avg`
	- `seraphina_ham_cull_avg`
	- `seraphina_vertex_decimals`

### Metrics Endpoint
When `SERAPHINA_METRICS_PORT` and `prom-client` are present, an HTTP server exposes Prometheus-formatted metrics at `/metrics` including current threshold, median, lock status, forced retention count, and adaptation event tally.
Replay Metrics: Running the replay validator with `SERAPHINA_REPLAY_METRICS_PORT` serves `/metrics` containing average and max Hamming, mismatch count, and health classification level for external monitoring & alert routing.
If `SERAPHINA_REPLAY_EMA_ALPHA` is set (>0), an additional `seraphina_replay_ema_avg_ham` gauge exposes the smoothed average used for health classification.

### Security Correlation Leaves
Relative threshold jumps >20% generate a `securityCorrelation` leaf referencing old/new threshold, median, relative jump, and optionally a digest of a security snapshot loaded from `SERAPHINA_SECURITY_HEURISTICS_PATH`. With `SERAPHINA_FRAME_AUTO_SECURITY`, a snapshot can be regenerated per batch.

### CLI Overrides
`unified-octalang-gpu.js` supports flags: `--cull=<num>`, `--adapt`, `--forceN=<int>`, `--lock`, `--hist=<path>`, `--securitySnapshot=<path>` overriding environment values for single-run convenience.

### Triad Miner Integration
`triad_miner.js` now records Hamming distance between consecutive triad digests using `seraphina-hamming-monitor.js`. Exposed metrics per audit log:
- `avg_ham`: average normalized bit flip ratio across stored diffs (0..1).
- `ham_health`: `healthy|caution|critical` classification.

Classification thresholds mirror animation monitor (<0.05 healthy, <0.12 caution, otherwise critical). Digest integrity remains unaffected (Hamming metrics non-digest, advisory only). Critical state can be used to gate external suggestions or trigger deeper security reviews.

## Suggested Extensions
Existing Enhancements Implemented:
- Mesh persistence with optional pre-cycle refresh (`SERAPHINA_CODER_MESH_REFRESH=1`).
- Provenance ledger appending triad digests & metrics.
- Code health regression/classification (`seraphina-code-health-train.js` + inference script) integrated into triad miner logs.
- Security heuristics module (`seraphina-code-security-heuristics.js`) for risky pattern scanning.
- Multi-language AST stubs (`seraphina-multilang-ast.js`) for Python/PowerShell structural counts.

Roadmap:
1. Multi-language deep AST (Python AST via native parse, PowerShell tokenization) with unified complexity metrics.
2. Diff-based temporal labeling (delta features between consecutive provenance entries) feeding adaptive model retraining.
3. Security heuristic expansion (cryptographic misuse flags, dynamic require pattern, suspicious high-entropy cluster mapping).
4. Agent feedback loop integration (structured JSON hints populating auto-tuning queue) without digest contamination.
5. Malware signature bloom filter (digest of known benign blocks vs anomaly threshold).
6. Visual lattice dashboard combining tesseract projection + live optimization probability heatmap.
7. Provenance compaction & rotation (gzip + Merkle root per chunk) for long-term integrity audit.

## Safety
No code execution or mutation; suggestions are advisory only. Wallet logic untouched; modules are standalone additions.

## Deterministic Digest Contract
`triadCycle()` returns `{ digest }` computed over component digests and seed.
Downstream systems can store this digest to detect changes in code quality footprint.

## License
Internal use; ensure any external publishing strips proprietary OctaLang internals.
