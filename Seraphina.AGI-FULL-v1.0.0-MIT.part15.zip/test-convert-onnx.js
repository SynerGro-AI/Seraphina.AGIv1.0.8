// test-convert-onnx.js
// Smoke test for onnx-to-tensorrt wrapper: if trtexec absent, exits gracefully.
const fs = require('fs');
const { spawnSync } = require('child_process');
const path = require('path');

function exists(cmd){
  // naive PATH scan
  const paths = process.env.PATH.split(path.delimiter);
  for (const p of paths){
    try { if (fs.existsSync(path.join(p, cmd))) return true; } catch(_){}
  }
  return false;
}

(function run(){
  const hasTrt = exists(process.platform === 'win32' ? 'trtexec.exe' : 'trtexec');
  if (!hasTrt){
    console.log('[TestConvert] trtexec not found in PATH – skipping conversion test');
    process.exit(0);
  }
  // Create tiny dummy ONNX model placeholder (cannot construct full graph easily here – user supplies real model).
  // We just check parameter validation failure path is handled cleanly.
  const fakePath = 'dummy.onnx';
  fs.writeFileSync(fakePath, Buffer.alloc(128, 0));
  const r = spawnSync('node', ['onnx-to-tensorrt.js', '--onnx='+fakePath, '--out=dummy.engine', '--verbose'], { encoding: 'utf8' });
  console.log('[TestConvert] exitCode', r.status);
  if (r.stdout) console.log('[TestConvert][stdout]', r.stdout.slice(0,400));
  if (r.stderr) console.log('[TestConvert][stderr]', r.stderr.slice(0,400));
})();
