// test-coder-triad.js
'use strict';
const assert = require('assert');
const fs = require('fs');
const { CoderTriad } = require('./seraphina-coder-triad.js');

function run(){
  const triad = new CoderTriad({ seed:'test-seed' });
  const code = "function demo(){\n  // TODO refactor\n  console.log('x');\n}\n";
  triad.registerBlock('demo', code);
  const res1 = triad.triadCycle({ id:'demo', code });
  const res2 = triad.triadCycle({ id:'demo', code });
  assert.strictEqual(res1.digest, res2.digest, 'Deterministic digest mismatch');
  assert.ok(res1.optimization.score >= 0 && res1.optimization.score <= 1, 'Score out of range');
  assert.ok(Array.isArray(res1.links.links), 'Links not array');
  console.log('[TestCoderTriad] PASS digest='+res1.digest+' score='+res1.optimization.score.toFixed(3));
}

if(require.main===module){ run(); }
module.exports = { run };
