#!/usr/bin/env node
// test-swap-flow.js
// Dry-run validation script for swap endpoints, balance credit, and metrics.
// Run: node test-swap-flow.js (ensure SELF_CHECK_HTTP=1 to expose endpoints)

const http = require('http');

function req(method, path, data){
  return new Promise((resolve,reject)=>{
    const opts = { hostname:'127.0.0.1', port: parseInt(process.env.SELF_CHECK_PORT||'9786',10), path, method, headers:{ 'Content-Type':'application/json' } };
    const r = http.request(opts, res=>{ let b=''; res.on('data',c=> b+=c); res.on('end',()=>{ try{ resolve({ status:res.statusCode, json: JSON.parse(b||'{}') }); }catch(e){ resolve({ status:res.statusCode, text:b }); } }); });
    r.on('error', reject);
    if (data) r.write(JSON.stringify(data));
    r.end();
  });
}

(async()=>{
  try {
    // 1. Fetch initial balances
    let bal = await req('GET','/balances');
    console.log('[Test] Initial balances', bal.json);

    // 2. Inject synthetic shares (if enabled)
    if (process.env.DEBUG_SHARE_ADD === '1'){
      const add = await req('GET','/debug/add-shares?delta=25');
      console.log('[Test] Added shares delta=25 ->', add.json);
      bal = await req('GET','/balances');
      console.log('[Test] Post-credit balances', bal.json);
    } else {
      console.log('[Test] DEBUG_SHARE_ADD not enabled; skipping share injection');
    }

    // 3. Quote dry-run rvn->btc
    const q = await req('GET','/swap/quote?from=rvn&to=btc&amount=10');
    console.log('[Test] Quote rvn->btc', q.json);
    const quoteId = q.json?.quote?.id;

    // 4. Execute dry-run swap
    const ex = await req('POST','/swap/execute', { from:'rvn', to:'btc', amount:10, quoteId });
    console.log('[Test] Execute rvn->btc', ex.json);

    // 5. Poll status until settled (dry-run uses deterministic steps)
    const execId = ex.json?.execId;
    for (let i=0;i<8;i++){
      await new Promise(r=> setTimeout(r, 4000));
      const st = await req('GET', `/swap/status?id=${execId}`);
      console.log('[Test] Status poll', i, st.json?.exec?.status, st.json?.exec?.detail?.rawStatus||'dry');
      if (st.json?.exec?.status === 'settled' || st.json?.exec?.status === 'error') break;
    }

    // 6. Fetch metrics (optional)
    const m = await req('GET','/metrics');
    console.log('[Test] Metrics sample length', typeof m.text==='string'? m.text.length : 'n/a');

    console.log('[Test] Completed swap flow test');
  } catch(e){
    console.error('[Test] Error', e);
    process.exit(1);
  }
})();
