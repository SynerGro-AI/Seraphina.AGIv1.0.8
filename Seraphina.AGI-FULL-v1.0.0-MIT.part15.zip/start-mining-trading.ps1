# start-mining-trading.ps1
# Deterministic concurrent launch of miner + trading advisory.
# Usage: powershell -ExecutionPolicy Bypass -File .\start-mining-trading.ps1
# Ensures required environment variables set; launches miner process with trading + companion enabled.

param(
  [string]$Node="node",
  [string]$MinerScript="aurrelia-pico-mesh-miner.js"
)

$env:WALLET_COMPANION = "1"
$env:WALLET_COMPANION_POLICY = "1"
$env:TRADING_ENGINE = "1"
# Set ECON_POLICY_APPLY=1 to allow bias application; leave 0 for audit-only.
if (-not $env:ECON_POLICY_APPLY) { $env:ECON_POLICY_APPLY = "0" }

# Optional runtime bias override file path (loaded internally when implemented)
if (-not $env:ECON_RUNTIME_BIAS_PATH) { $env:ECON_RUNTIME_BIAS_PATH = "econ-runtime-bias.json" }

Write-Host "[Launch] Miner with companion+policy+trading flags active" -ForegroundColor Cyan

& $Node $MinerScript
