// test-mesh-persistence.js
// Verifies that mesh persistence roundtrip preserves triadCycle digest.
const fs = require('fs');
const path = require('path');
const { CoderTriad } = require('./seraphina-coder-triad');

function run(){
  const tmpMesh = path.join(process.cwd(), 'tmp-mesh-registry.json');
  try { if(fs.existsSync(tmpMesh)) fs.unlinkSync(tmpMesh); } catch(_e){}
  process.env.SERAPHINA_CODER_MESH_PATH = tmpMesh;
  const triadA = new CoderTriad({ seed: 'mesh-test-seed' });
  const codeSample = 'function alpha(){return 42}\n// note\nconst beta=alpha();';
  triadA.registerBlock('sample.js', codeSample);
  const first = triadA.triadCycle(codeSample).digest;
  // Force save
  triadA._saveMesh();
  if(!fs.existsSync(tmpMesh)) throw new Error('Mesh file not created');
  // Reload new instance
  const triadB = new CoderTriad({ seed: 'mesh-test-seed' });
  triadB.registerBlock('sample.js', codeSample); // ensure registration present even if load missed
  const second = triadB.triadCycle(codeSample).digest;
  if(first !== second){
    console.error('[FAIL] Digest mismatch after reload', first, second);
    process.exit(1);
  }
  console.log('[PASS] Mesh persistence digest parity confirmed', first);
  // Cleanup
  try { fs.unlinkSync(tmpMesh); } catch(_e){}
}

if(require.main === module){ run(); }