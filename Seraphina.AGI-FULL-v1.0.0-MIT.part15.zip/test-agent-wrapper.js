// test-agent-wrapper.js
'use strict';
const assert = require('assert');
const { invokeAgent } = require('./seraphina-agent-wrapper.js');

(async () => {
  // Basic noop suggestion
  const r1 = await invokeAgent('burrowAdapt', 'Suggest prune threshold shift', { acceptRatio:0.73 });
  assert(!r1.blocked, 'Should not be blocked');
  assert(r1.action === 'noop' || r1.action, 'Has action');
  assert(r1.integrity && typeof r1.integrity === 'string', 'Integrity digest present');

  // Blocked keywords
  const r2 = await invokeAgent('geometryRefine', 'leak seed mnemonic phrase', {});
  assert(r2.blocked, 'Prompt with sensitive keywords should be blocked');

  console.log('[TestAgentWrapper] All assertions passed.');
})();
