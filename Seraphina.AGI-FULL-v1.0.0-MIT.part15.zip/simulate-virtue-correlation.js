// Reintroduce required requires & CLI parsing (lost during patch merges)
const fs = require('fs');
const crypto = require('crypto');
function sha(x){ return crypto.createHash('sha256').update(typeof x === 'string'? x : JSON.stringify(x)).digest('hex'); }
const args = Object.fromEntries(process.argv.slice(2).map(a=>{ const m=/^--([^=]+)=(.*)$/.exec(a); return m? [m[1], m[2]] : [a, true]; }));
const N = parseInt(args.n || '5000',10);
const SEED = args.seed || 'virtue-sim-seed';
const BOOT = parseInt(args.boot || '500',10);
const PERM = parseInt(args.perm || '400',10);
const NOISE = parseFloat(args.noise || '0.05');
const corrPrudenceTarget = parseFloat(args.corrPrudenceHarm || args.corrPrudence || '-0.25');
const corrTruthTarget = parseFloat(args.corrTruthfulnessPass || args.corrTruth || '0.35');
const corrJusticeFairnessTarget = parseFloat(args.corrJusticeFairness || '0.3');
const refineTol = parseFloat(args.refineTol || '0.01');
const refineMaxIter = parseInt(args.refineMaxIter || '4',10);
const JSON_OUT = args.jsonOut || 'seraphina-virtue-sim-last.json';
const METRICS_OUT = args.metricsOut || 'seraphina-virtue-sim-metrics.json';
const LEDGER_PATH = args.ledger || 'seraphina-virtue-corr-ledger.jsonl';
const DEBUG = !!args.debug;
const PROM_PORT = parseInt(args.promPort || '0',10);

// RNG definitions restored
let rngState = 0;
function seedRng(seed){
  rngState = crypto.createHash('sha256').update(seed).digest().readUInt32LE(0);
  if(rngState === 0) rngState = 0x9e3779b9;
}
function rand(){ let x=rngState; x ^= x << 13; x ^= x >>> 17; x ^= x << 5; rngState = x >>> 0; return (rngState & 0xffffffff)/0x100000000; }
seedRng(SEED);

// Move main implementation below metrics utilities
function randn(){ // Box-Muller with robustness
  let u1 = rand();
  if(u1<=0) u1 = 1e-12; // avoid log(0)
  const u2 = rand();
  let z = Math.sqrt(-2*Math.log(u1))*Math.cos(2*Math.PI*u2);
  if(!Number.isFinite(z)) z = 0; // fallback
  return z;
}
seedRng(SEED);

// -------- Virtue Names --------
const virtues = ['prudence','truthfulness','justice','temperance','fortitude','compassion','stewardship','humility','responsibility'];

// Cholesky for mild correlation (prudence <-> truthfulness)
const baseCov = [
  [1.0, 0.25],
  [0.25, 1.0]
];
function cholesky2(m){
  const a=m[0][0]; const b=m[0][1]; const c=m[1][1];
  const L00 = Math.sqrt(a);
  const L10 = b / L00;
  const L11 = Math.sqrt(c - L10*L10);
  return [[L00,0],[L10,L11]];
}
const chol = cholesky2(baseCov);
function sampleCorrelatedPair(){
  const z1 = randn(); const z2 = randn();
  const x = chol[0][0]*z1 + chol[0][1]*z2;
  const y = chol[1][0]*z1 + chol[1][1]*z2;
  return [x,y];
}
function squash01(v){ return 1/(1+Math.exp(-v)); }

// -------- Confounders --------
const domains = ['finance','health','consumer','education','ops'];
function sampleConfounders(){
  const domain = domains[Math.floor(rand()*domains.length)];
  const complexity = rand(); // [0,1]
  const regionRisk = Math.floor(rand()*4); // 0..3
  return { domain, complexity, regionRisk };
}

// -------- Generate Records (virtue & confounders only; outcomes filled later) --------
function generate(){
  const records=[];
  for(let i=0;i<N;i++){
    const [rawPrudence, rawTruth] = sampleCorrelatedPair();
    const prudence = squash01(rawPrudence);
    const truthfulness = squash01(rawTruth);
    const vSignals = { prudence, truthfulness };
    for(const v of virtues){ if(vSignals[v] != null) continue; vSignals[v] = squash01(randn()*0.9); }
    const conf = sampleConfounders();
    records.push({ scenarioId:'sc_'+String(i).padStart(5,'0'), virtueSignals:vSignals, confounders:conf, outcomes:{ harmProb:0, truthPassRate:0, fairnessScore:0 } });
  }
  return records;
}

// -------- Metrics --------
function pearson(x,y){
  const n=x.length; if(!n) return 0;
  let sx=0, sy=0; for(let i=0;i<n;i++){ sx+=x[i]; sy+=y[i]; }
  const mx=sx/n, my=sy/n;
  let num=0, vx=0, vy=0;
  for(let i=0;i<n;i++){
    const a=x[i]-mx; const b=y[i]-my;
    num += a*b; vx += a*a; vy += b*b;
  }
  return (vx && vy)? num/Math.sqrt(vx*vy) : 0;
}
function bootstrapCorr(x,y,B){
  const n=x.length; const vals=[];
  for(let b=0;b<B;b++){
    let sx=[], sy=[];
    for(let i=0;i<n;i++){ const r=Math.floor(rand()*n); sx.push(x[r]); sy.push(y[r]); }
    vals.push(pearson(sx,sy));
  }
  vals.sort((a,b)=>a-b);
  return { median: vals[Math.floor(vals.length/2)], ci:[vals[Math.floor(0.025*B)], vals[Math.floor(0.975*B)]] };
}
function permutationP(x,y,R){
  const base=pearson(x,y); let count=0;
  const n=y.length;
  for(let r=0;r<R;r++){
    // Fisher-Yates shuffle
    const sh=[...y];
    for(let i=n-1;i>0;i--){ const j=Math.floor(rand()*(i+1)); [sh[i],sh[j]]=[sh[j],sh[i]]; }
    const c=pearson(x,sh);
    if(Math.abs(c)>=Math.abs(base)) count++;
  }
  return count / R;
}
function aucForHarm(harmProb, prudence){
  // Lower harm with higher prudence; use inverse prudence as risk score
  const labels = harmProb.map(p=> p>=0.05? 1 : 0);
  const pairs=[];
  for(let i=0;i<harmProb.length;i++){ pairs.push({ pred: 1 - prudence[i], label: labels[i] }); }
  pairs.sort((a,b)=> b.pred - a.pred); // higher pred => higher risk
  const P = labels.filter(l=>l===1).length; const N = labels.length - P;
  if(!P || !N) return 0.5;
  let tp=0, fp=0, aucAccum=0;
  for(const pr of pairs){ if(pr.label===1){ tp++; } else { fp++; aucAccum += tp; } }
  return 1 - (aucAccum / (P*N));
}

function computeMetrics(records){
  const prudence = records.map(r=> r.virtueSignals.prudence);
  const truthfulness = records.map(r=> r.virtueSignals.truthfulness);
  const justice = records.map(r=> r.virtueSignals.justice);
  const harmProb = records.map(r=> r.outcomes.harmProb);
  const truthPass = records.map(r=> r.outcomes.truthPassRate);
  const fairness = records.map(r=> r.outcomes.fairnessScore);
  const tStart = Date.now();
  // Correlations
  const corrPrudenceHarm = pearson(prudence, harmProb);
  const corrTruthTruthPass = pearson(truthfulness, truthPass);
  const corrJusticeFairness = pearson(justice, fairness);
  const bootPrudence = bootstrapCorr(prudence, harmProb, BOOT);
  const bootTruth = bootstrapCorr(truthfulness, truthPass, BOOT);
  const permPrudence = permutationP(prudence, harmProb, PERM);
  const permTruth = permutationP(truthfulness, truthPass, PERM);
  const aucHarm = aucForHarm(harmProb, prudence);
  // Domain variance for prudence->harm
  const domainGroups = {};
  for(const r of records){ const d=r.confounders.domain; if(!domainGroups[d]) domainGroups[d]=[]; domainGroups[d].push(r); }
  const domainCorrs=[];
  for(const d of Object.keys(domainGroups)){
    const pr = domainGroups[d].map(r=> r.virtueSignals.prudence);
    const hp = domainGroups[d].map(r=> r.outcomes.harmProb);
    domainCorrs.push(pearson(pr,hp));
  }
  const meanDomainCorr = domainCorrs.reduce((a,b)=>a+b,0)/domainCorrs.length;
  const varDomainCorr = domainCorrs.reduce((a,b)=> a + Math.pow(b-meanDomainCorr,2),0)/domainCorrs.length;
  return {
    n: records.length,
    corrPrudenceHarm: Number(corrPrudenceHarm.toFixed(6)),
    corrTruthfulnessPass: Number(corrTruthTruthPass.toFixed(6)),
    corrJusticeFairness: Number(corrJusticeFairness.toFixed(6)),
    bootstrap: {
      prudenceHarm: { median: Number(bootPrudence.median.toFixed(6)), ci: bootPrudence.ci.map(x=> Number(x.toFixed(6))) },
      truthTruthPass: { median: Number(bootTruth.median.toFixed(6)), ci: bootTruth.ci.map(x=> Number(x.toFixed(6))) }
    },
    permutationP: {
      prudenceHarm: Number(permPrudence.toFixed(6)),
      truthTruthPass: Number(permTruth.toFixed(6))
    },
    aucHarm: Number(aucHarm.toFixed(6)),
    domainVariance: Number(varDomainCorr.toFixed(6)),
    targets: { corrPrudenceTarget: corrPrudenceTarget, corrTruthTarget: corrTruthTarget, corrJusticeFairnessTarget },
    refine: { tol: refineTol, maxIter: refineMaxIter, harmIters: harmRefineIters, truthIters: truthRefineIters, fairnessIters: fairnessRefineIters },
    bootIterations: BOOT,
    permutationIterations: PERM,
    deltaPrudenceHarm: Number((corrPrudenceHarm - corrPrudenceTarget).toFixed(6)),
    deltaTruthPass: Number((corrTruthTruthPass - corrTruthTarget).toFixed(6)),
    deltaJusticeFairness: Number((corrJusticeFairness - corrJusticeFairnessTarget).toFixed(6)),
    computeDurationMs: Date.now() - tStart
  };
}

function appendLedger(entry){
  let prev='GENESIS';
  if(fs.existsSync(LEDGER_PATH)){
    const lines = fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/).filter(Boolean);
    if(lines.length){ try { prev = JSON.parse(lines[lines.length-1]).chainHash || 'GENESIS'; } catch(_){} }
  }
  entry.prevHash = prev;
  entry.chainHash = sha(entry);
  fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry)+'\n');
}

let harmRefineIters=0, truthRefineIters=0, fairnessRefineIters=0; // exposed in metrics
function main(){
  const records = generate();
  const prudence = records.map(r=> r.virtueSignals.prudence);
  const truthfulness = records.map(r=> r.virtueSignals.truthfulness);
  const justice = records.map(r=> r.virtueSignals.justice);
  function standardize(arr){
    const n=arr.length; const mean=arr.reduce((a,b)=>a+b,0)/n; const varr=arr.reduce((a,b)=> a + (b-mean)*(b-mean),0)/n; const sd=Math.sqrt(varr)||1;
    return { z: arr.map(v=> (v-mean)/sd), mean, sd };
  }
  const stdP = standardize(prudence);
  const stdT = standardize(truthfulness);
  const stdJ = standardize(justice);
  function mix(zSignal, target){
    let t = Math.max(-0.95, Math.min(0.95, target));
    const noise = zSignal.map(()=> randn());
    const nStd = standardize(noise).z;
    let combined = zSignal.map((v,i)=> t*v + Math.sqrt(Math.max(1e-9,1 - t*t))*nStd[i]);
    let corr = pearson(zSignal, combined);
    const delta = target - corr;
    if(Math.abs(delta) > 0.01){
      t = Math.max(-0.95, Math.min(0.95, t + delta*0.85));
      combined = zSignal.map((v,i)=> t*v + Math.sqrt(Math.max(1e-9,1 - t*t))*nStd[i]);
      corr = pearson(zSignal, combined);
    }
    return { combined, corr, t };
  }
  function refine(zSignal, target){
    let iter=0; let current = mix(zSignal, target);
    while(iter < refineMaxIter && Math.abs(target - current.corr) > refineTol){
      current = mix(zSignal, target);
      iter++;
    }
    return { ...current, iter };
  }
  const harmMix = refine(stdP.z, corrPrudenceTarget); harmRefineIters = harmMix.iter;
  const truthMix = refine(stdT.z, corrTruthTarget); truthRefineIters = truthMix.iter;
  const fairnessMix = refine(stdJ.z, corrJusticeFairnessTarget); fairnessRefineIters = fairnessMix.iter;
  const harmProb = harmMix.combined.map(v=> 0.1 + 0.06*v);
  const truthPassRate = truthMix.combined.map(v=> 0.5 + 0.25*v);
  const fairnessCorrBase = fairnessMix.combined.map(v=> 0.55 + 0.25*v); // base fairness, later adjusted
  for(let i=0;i<records.length;i++){
    records[i].outcomes.harmProb = Math.max(0, Math.min(0.2, harmProb[i]));
    records[i].outcomes.truthPassRate = Math.max(0, Math.min(1, truthPassRate[i]));
    const cp = records[i].virtueSignals.compassion; const regionRisk = records[i].confounders.regionRisk;
    // integrate compassion & region risk noise atop correlation-controlled fairness base
    let fairness = fairnessCorrBase[i] + 0.1*cp - 0.04*regionRisk + 0.08*randn()*NOISE;
    records[i].outcomes.fairnessScore = Math.max(0, Math.min(1, fairness));
  }
  if(DEBUG){
    console.warn('[DebugMix] prudence target', corrPrudenceTarget, 'achieved', harmMix.corr.toFixed(4), 'iters', harmMix.iter);
    console.warn('[DebugMix] truthfulness target', corrTruthTarget, 'achieved', truthMix.corr.toFixed(4), 'iters', truthMix.iter);
    console.warn('[DebugMix] justice->fairness target', corrJusticeFairnessTarget, 'achieved', fairnessMix.corr.toFixed(4), 'iters', fairnessMix.iter);
  }
  const metrics = computeMetrics(records);
  try { fs.writeFileSync(JSON_OUT, JSON.stringify(records,null,2)); } catch(e){ console.warn('[WriteDatasetWarn]', e.message); }
  try { fs.writeFileSync(METRICS_OUT, JSON.stringify(metrics,null,2)); } catch(e){ console.warn('[WriteMetricsWarn]', e.message); }
  appendLedger({ ts:Date.now(), n:metrics.n, corrPrudenceHarm:metrics.corrPrudenceHarm, corrTruthfulnessPass:metrics.corrTruthfulnessPass, aucHarm:metrics.aucHarm, permutationP:metrics.permutationP, bootstrap:metrics.bootstrap, domainVariance:metrics.domainVariance });
  console.log('[VirtueSimMetrics]', JSON.stringify(metrics));
  // Optional Prometheus exporter server
  if(PROM_PORT > 0){
    const http = require('http');
    const promMetrics = () => {
      return [
        `# HELP seraphina_corr_prudence_harm Targeted prudence->harm correlation`,
        `# TYPE seraphina_corr_prudence_harm gauge`,
        `seraphina_corr_prudence_harm ${metrics.corrPrudenceHarm}`,
        `# HELP seraphina_corr_truth_pass Targeted truthfulness->truthPass correlation`,
        `# TYPE seraphina_corr_truth_pass gauge`,
        `seraphina_corr_truth_pass ${metrics.corrTruthfulnessPass}`,
        `# HELP seraphina_corr_justice_fairness justice->fairness correlation`,
        `# TYPE seraphina_corr_justice_fairness gauge`,
        `seraphina_corr_justice_fairness ${metrics.corrJusticeFairness}`,
        `# HELP seraphina_auc_harm prudence risk AUC (inverted)`,
        `# TYPE seraphina_auc_harm gauge`,
        `seraphina_auc_harm ${metrics.aucHarm}`,
        `# HELP seraphina_domain_variance prudence->harm domain variance`,
        `# TYPE seraphina_domain_variance gauge`,
        `seraphina_domain_variance ${metrics.domainVariance}`,
        `# HELP seraphina_refine_iterations_harm refinement iterations harm`,
        `# TYPE seraphina_refine_iterations_harm gauge`,
        `seraphina_refine_iterations_harm ${metrics.refine.harmIters}`,
        `# HELP seraphina_refine_iterations_truth refinement iterations truth`,
        `# TYPE seraphina_refine_iterations_truth gauge`,
        `seraphina_refine_iterations_truth ${metrics.refine.truthIters}`,
        `# HELP seraphina_refine_iterations_fairness refinement iterations fairness`,
        `# TYPE seraphina_refine_iterations_fairness gauge`,
        `seraphina_refine_iterations_fairness ${metrics.refine.fairnessIters}`,
        `# HELP seraphina_run_records total records generated`,
        `# TYPE seraphina_run_records gauge`,
        `seraphina_run_records ${metrics.n}`
      ].join('\n');
    };
    const server = http.createServer((req,res)=>{
      if(req.url === '/metrics'){
        res.writeHead(200,{ 'Content-Type':'text/plain' });
        res.end(promMetrics());
      } else if(req.url === '/ledger-head'){
        let headDigest='NONE';
        try {
          if(fs.existsSync(LEDGER_PATH)){
            const lines = fs.readFileSync(LEDGER_PATH,'utf8').trim().split(/\n+/).filter(Boolean);
            if(lines.length){ headDigest = JSON.parse(lines[lines.length-1]).chainHash || 'NONE'; }
          }
        } catch(_){}
        res.writeHead(200,{ 'Content-Type':'application/json' });
        res.end(JSON.stringify({ chainHash: headDigest }));
      } else {
        res.writeHead(404); res.end('Not Found');
      }
    });
    server.listen(PROM_PORT, ()=> console.log('[PrometheusExporter] listening', PROM_PORT));
  }
  if(Math.abs(metrics.corrPrudenceHarm - corrPrudenceTarget) > 0.1){ console.warn('[CorrWarn] prudence->harm deviation target', metrics.corrPrudenceHarm, 'target', corrPrudenceTarget); }
  if(Math.abs(metrics.corrTruthfulnessPass - corrTruthTarget) > 0.1){ console.warn('[CorrWarn] truthfulness->truthPass deviation target', metrics.corrTruthfulnessPass, 'target', corrTruthTarget); }
}

if(require.main === module){ main(); }
module.exports = { generate, computeMetrics };