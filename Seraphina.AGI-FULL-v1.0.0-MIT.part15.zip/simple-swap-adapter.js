// SimpleSwap Adapter (dry-run deterministic + optional live mode)
// Provides: quote(from,to,amount), execute(from,to,amount,quote), poll(id)
// Maintains internal in-memory swap map. Live mode gated by env vars:
//   SIMPLESWAP_LIVE=1 & SIMPLESWAP_ENABLE_LIVE=1 & SIMPLESWAP_API_KEY present.
// Dry-run mode derives deterministic pseudo-rate from SHA256(from->to).
// All functions return plain objects; no side-effects beyond internal map.
// Hash chaining / persistence is handled by caller (main miner file).

const crypto = require('crypto');
const https = require('https');

function isLive(){
  // Holodeck isolation: block live mode unless explicitly allowed
  if (process.env.HOLODECK_ENABLE === '1' && process.env.HOLODECK_ALLOW_SWAP !== '1') return false;
  return process.env.SIMPLESWAP_LIVE === '1' && process.env.SIMPLESWAP_ENABLE_LIVE === '1' && !!process.env.SIMPLESWAP_API_KEY;
}

const SWAPS = new Map(); // id -> { ts, status, detail, from, to, amount, quote }

function deterministicRate(from,to){
  const seed = crypto.createHash('sha256').update(from+'->'+to).digest('hex');
  const base = parseInt(seed.slice(0,6),16)/0xffffff; // 0..1
  return 0.0001 + base * 0.0025; // small spread
}

function quote(from,to,amount){
  return new Promise((resolve,reject)=>{
    try {
      if(!from||!to||!(amount>0)) return reject(new Error('bad_params'));
      const key = `q:${from}:${to}:${amount}`;
      // Simple in-memory cache via SWAPS map for quotes (store minimal entries)
      const cached = SWAPS.get(key);
      if(cached && cached.quote){ return resolve({ ...cached.quote, cached:true }); }
      if(!isLive()){
        const rate = deterministicRate(from,to); const out = amount * rate;
        const q = { id: 'dry_'+crypto.createHash('sha256').update(key).digest('hex').slice(0,10), rate, amountFrom: amount, amountTo: out, live:false };
        SWAPS.set(key,{ quote: q });
        return resolve(q);
      }
      const apiKey = process.env.SIMPLESWAP_API_KEY;
      if(!apiKey) return reject(new Error('missing_api_key'));
      const url = `https://api.simpleswap.io/v2/get_exchange?api_key=${apiKey}&currency_from=${from}&currency_to=${to}&amount=${amount}`;
      https.get(url,r=>{ let d=''; r.on('data',c=> d+=c); r.on('end',()=>{
        try { const resp=JSON.parse(d||'{}'); const q={ id: resp.id || ('live_'+Date.now()), rate: resp.rate||0, amountFrom: amount, amountTo: resp.amount_to||0, live:true }; SWAPS.set(key,{ quote: q }); resolve(q); }
        catch(e){ resolve({ id:'err_'+Date.now(), rate:0, amountFrom:amount, amountTo:0, live:true, error:e.message }); }
      }); r.on('error',err=>{ resolve({ id:'err_'+Date.now(), rate:0, amountFrom:amount, amountTo:0, live:true, error:err.message }); }); });
    } catch(e){ reject(e); }
  });
}

function execute(from,to,amount,quoteObj){
  return new Promise((resolve,reject)=>{
    try {
      if(!from||!to||!(amount>0)) return reject(new Error('bad_params'));
      if(!quoteObj || !quoteObj.id) return reject(new Error('missing_quote'));
  const { deriveId } = require('./deterministic-util');
  const execId = deriveId('swap-exec', Date.now(), pair.from, pair.to, amount);
      const live = isLive();
      let status = 'pending';
      let detail = { live, quoteId: quoteObj.id };
      if(!live){
        // Deterministic synthetic lifecycle
        detail.steps = [
          { t: Date.now(), s:'accepted' },
          { t: Date.now()+5000, s:'broadcast' },
          { t: Date.now()+15000, s:'confirming' },
          { t: Date.now()+30000, s:'settled' }
        ];
        status = 'accepted';
        const rec = { ts: Date.now(), status, detail, from, to, amount, quote: quoteObj };
        SWAPS.set(execId, rec);
        return resolve({ execId, status, live:false });
      }
      // Live create exchange
      try {
        const apiKey = process.env.SIMPLESWAP_API_KEY; if(!apiKey) throw new Error('missing_api_key');
        const body = JSON.stringify({ currency_from: from, currency_to: to, amount, api_key: apiKey, address_to: process.env.BTC_KRAKEN_ADDRESS || process.env.BTC_MINING_ADDRESS || '' });
        const req = https.request('https://api.simpleswap.io/v2/create_exchange',{ method:'POST', headers:{ 'Content-Type':'application/json', 'Content-Length': Buffer.byteLength(body) } }, r=>{
          let d=''; r.on('data',c=> d+=c); r.on('end',()=>{
            try { const resp = JSON.parse(d||'{}'); detail.orderId = resp.id || null; detail.depositAddress = resp.address_from || null; detail.expectedAmountTo = resp.amount_to || 0; detail.rate = resp.rate || quoteObj.rate; status='accepted'; }
            catch(e){ status='error'; detail.error = e.message; }
            const rec = { ts: Date.now(), status, detail, from, to, amount, quote: quoteObj }; SWAPS.set(execId, rec);
            return resolve({ execId, status, live:true });
          }); r.on('error',err=>{ status='error'; detail.error=err.message; const rec={ ts: Date.now(), status, detail, from, to, amount, quote: quoteObj }; SWAPS.set(execId, rec); return resolve({ execId, status, live:true }); });
        }); req.end(body);
      } catch(e){ status='error'; detail.error=e.message; const rec={ ts: Date.now(), status, detail, from, to, amount, quote: quoteObj }; SWAPS.set(execId, rec); return resolve({ execId, status, live:true }); }
    } catch(e){ reject(e); }
  });
}

function poll(execId){
  return new Promise((resolve,reject)=>{
    try {
      const rec = SWAPS.get(execId); if(!rec) return reject(new Error('not_found'));
      if(rec.detail && rec.detail.steps && rec.status!=='settled' && !rec.detail.live){
        const now = Date.now();
        for(const st of rec.detail.steps){ if(!st.done && now>=st.t){ st.done=true; rec.status = st.s; } }
        if(rec.status==='settled') rec.settledTs = Date.now();
        return resolve(rec);
      }
      if(rec.detail && rec.detail.live && rec.detail.orderId && rec.status!=='settled' && rec.status!=='error'){
        const apiKey = process.env.SIMPLESWAP_API_KEY; if(!apiKey) return resolve(rec);
        const url = `https://api.simpleswap.io/v2/get_exchange?api_key=${apiKey}&id=${rec.detail.orderId}`;
        https.get(url,r=>{ let d=''; r.on('data',c=> d+=c); r.on('end',()=>{ try { const sr=JSON.parse(d||'{}'); rec.detail.rawStatus = sr.status || sr.state || null; if(sr.status==='finished'){ rec.status='settled'; rec.settledTs=Date.now(); rec.detail.txid_out = sr.txid_out || null; rec.detail.confirmations = sr.tx_to_confirmations || sr.confirmations || null; } else if(sr.status==='failed' || sr.status==='expired'){ rec.status='error'; rec.detail.error=sr.status; } resolve(rec); } catch(e){ rec.detail.pollError=e.message; resolve(rec); } }); r.on('error',err=>{ rec.detail.pollError=err.message; resolve(rec); }); });
        return; // async path
      }
      return resolve(rec);
    } catch(e){ reject(e); }
  });
}

function listOpen(){
  const out=[]; for(const [id,rec] of SWAPS.entries()){ if(rec && rec.status && ['pending','accepted','broadcast','confirming'].includes(rec.status)) out.push({ id, status: rec.status, from: rec.from, to: rec.to, amount: rec.amount }); }
  return out;
}

module.exports = { quote, execute, poll, listOpen, _SWAPS: SWAPS };
