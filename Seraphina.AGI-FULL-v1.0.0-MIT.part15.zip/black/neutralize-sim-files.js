#!/usr/bin/env node
'use strict';
/**
 * neutralize-sim-files.js
 * -------------------------------------------------------------
 * Purpose: Permanently eliminate legacy simulation / inflated hash modules
 * by overwriting their contents with a thin, REAL delegation harness.
 * No proxies, no fake growth, no Math.random, no artificial share logic.
 *
 * Each target file is replaced with a deterministic wrapper that:
 *   - Imports the canonical real mining implementation(s)
 *   - Immediately exits with an instructional error if executed directly
 *     (to force users toward supported real entry points), OR can optionally
 *     start the proper miner if a REAL_MODE environment flag is set.
 *
 * Canonical real entry points currently in repo:
 *   - proper-antminer-mining.js
 *   - zero-simulation-real-miner.js
 *   - real-stratum-client.js (protocol only)
 *
 * Safe Re-run: This script is idempotent. If a target file already contains
 * the marker header, it is skipped.
 */

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const TARGETS = [
  'massive-bitcoin-miner.js',
  'massive-ehs-miner.js',
  'real-pool-connector.js',
  'real-mining-interface.js',
  'visual-mining-dashboard.js',
  'enhanced-mining-dashboard.js'
];

const HEADER_MARK = '// REAL_ONLY_NEUTRALIZED';

const WRAPPER = (originalName) => `// REAL_ONLY_NEUTRALIZED: ${originalName}\n` +
`// This file has been permanently converted to a real-mining delegation wrapper.\n` +
`// Original simulation / probabilistic or inflated metrics code was removed.\n` +
`// DO NOT restore prior content. All mining must flow through real Stratum +\n` +
`// deterministic hashing loops (see proper-antminer-mining.js or zero-simulation-real-miner.js).\n` +
`\n'use strict';\n\n` +
`const path = require('path');\n` +
`// Preferred real miner modules (must exist).\n` +
`const REAL_MINERS = [\n  'proper-antminer-mining.js',\n  'zero-simulation-real-miner.js'\n];\n\n` +
`function locateRealMiner() {\n  for (const rel of REAL_MINERS) {\n    const p = path.join(__dirname, rel);\n    try { require.resolve(p); return p; } catch (_) {}\n  }\n  throw new Error('No real miner module found among: ' + REAL_MINERS.join(', '));\n}\n\n` +
`// Export a small API to prevent people from re-injecting simulation.\n` +
`module.exports = {\n  launchReal(options = {}) {\n    const minerPath = locateRealMiner();\n    const mod = require(minerPath);\n    // Heuristic: pick a start method if available.\n    const entry = mod.ProperAntminerMiningProgram || mod.ZeroSimulationRealMiner || mod.default || null;\n    if (!entry) throw new Error('Real miner entry point not found in ' + minerPath);\n    const instance = new entry();\n    // If it exposes a known start method, call it.\n    if (instance.startMassiveBitcoinMining) instance.startMassiveBitcoinMining();\n    else if (instance.connectToRealF2Pool) instance.connectToRealF2Pool();\n    else if (instance.connectToF2PoolStratum) instance.connectToF2PoolStratum();\n    else if (instance.startNeuralMiningPipeline) instance.startNeuralMiningPipeline();\n    else if (typeof instance.start === 'function') instance.start();\n    return instance;\n  }\n};\n\n` +
`if (require.main === module) {\n  if (process.env.REAL_MODE === '1') {\n    console.log('[REAL] Launching canonical miner from ${originalName} wrapper');\n    module.exports.launchReal();\n  } else {\n    console.error('Direct execution of ${originalName} is disabled. Set REAL_MODE=1 to delegate to real miner.');\n    process.exit(1);\n  }\n}\n`;

let changed = 0;
for (const rel of TARGETS) {
  const filePath = path.join(ROOT, rel);
  if (!fs.existsSync(filePath)) {
    console.log('[skip] missing', rel);
    continue;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  if (content.startsWith(HEADER_MARK)) {
    console.log('[ok] already neutralized', rel);
    continue;
  }
  fs.writeFileSync(filePath, WRAPPER(rel), 'utf8');
  console.log('[neutralized]', rel);
  changed++;
}

if (!changed) {
  console.log('All target files already neutralized.');
} else {
  console.log(`Neutralization complete (${changed} files updated).`);
}
