// Archived GPU bridge sample.
module.exports = require('../gpu-bridge-sample.js');
