// Deprecated original miner entry moved into black/ archive.
module.exports = { deprecated: true };
