#!/usr/bin/env node
/**
 * Anti-Simulation Guard
 * Fails (exit 1) if banned simulation / clone-army artefacts are detected
 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const BANNED_PATTERNS = [
  /50\s?B(illion)?/i,
  /clone( army| swarm|s)?/i,
  /MASSIVE DEPLOYMENT/i,
  /DEPLOYING .* CLONES/i,
  /activeClones/i,
  /totalClones/i,
  /miningClones/i,
  /walletMonitorClones/i,
  /chatClones/i,
  /neuralClones/i,
];

const ALLOWED_EXT = new Set(['.js', '.mjs', '.cjs', '.ts', '.json', '.html']);

let violations = [];

function scanFile(f){
  const rel = path.relative(ROOT, f);
  if(rel.startsWith('node_modules')) return;
  const ext = path.extname(f);
  if(!ALLOWED_EXT.has(ext)) return;
  const text = fs.readFileSync(f,'utf8');
  BANNED_PATTERNS.forEach(re=>{
    if(re.test(text)){
      violations.push({file: rel, pattern: re.toString()});
    }
  });
}

function walk(dir){
  const entries = fs.readdirSync(dir, {withFileTypes:true});
  for(const e of entries){
    const full = path.join(dir, e.name);
    if(e.isDirectory()) walk(full); else scanFile(full);
  }
}

walk(ROOT);

if(violations.length){
  console.error('\n[ANTI-SIM] VIOLATIONS DETECTED:');
  violations.forEach(v=> console.error(` - ${v.file} matches ${v.pattern}`));
  console.error(`\nTotal: ${violations.length} banned occurrences.`);
  process.exit(1);
}
console.log('[ANTI-SIM] PASS: No banned simulation artefacts detected.');
