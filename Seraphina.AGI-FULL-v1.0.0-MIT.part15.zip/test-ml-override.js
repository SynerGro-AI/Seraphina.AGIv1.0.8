#!/usr/bin/env node
// Minimal deterministic test harness to exercise plane reinforcement + ML override.
// It simulates mining updates to populate attempts/accepts so the reinforcement interval triggers.
// Usage:
//   node test-ml-override.js  (optionally set env vars like ML_TENSORRT=1)
// Ensures feature vector length matches expected and logs final weights.

const path = require('path');
process.env.AUR_PLANE_REINFORCE_MS = process.env.AUR_PLANE_REINFORCE_MS || '3000';
process.env.AUR_PRUNE_TICK_MS = '999999'; // disable prune noise

// Hook into miner core by requiring the main miner file but replacing pipeline.planeReinforce with a mock that still follows structure.
const minerPath = path.join(__dirname, 'aurrelia-pico-mesh-miner.js');

// Create mock pipeline object to attach to global if miner expects it; we load miner which defines pipeline internally.
// We'll simulate updates by pushing attempts/accepts arrays.

let started = Date.now();
console.log('[TestML] starting ML override test');

// Monkey-patch environment for quicker activation.
process.env.AUR_PLANE_REINFORCE_LOG = '1';
process.env.ML_LAT_SKIP_LOG = '1';

// Run miner in a child thread-like style by requiring; it will schedule intervals.
require(minerPath);

// Access global metrics registry if available for final reporting.
function getPipeline(){
  // Try to access pipeline from module cache by scanning exports
  // The miner likely attaches pipeline to closure; we rely on stored references via global metrics registry.
  return global.__AUR_PIPELINE__ || null;
}

// Synthetic reinforcement data injection loop
let injectionInterval = setInterval(()=>{
  const pipe = getPipeline();
  if (!pipe || !pipe.planeReinforce){ return; }
  const pr = pipe.planeReinforce;
  // Populate attempts/accepts to cross threshold
  for (let i=0;i<4;i++){
    const a = Math.floor(10 + i*3 + (Date.now()%5));
    const ok = Math.floor(a * (0.3 + 0.1*i));
    pr.attempts[i] += a;
    pr.accepts[i] += ok;
  }
  if (Date.now() - started > 12000){
    clearInterval(injectionInterval);
    setTimeout(()=>{
      console.log('[TestML] Final weights:', pr.weights.map(x=>x.toFixed(4)).join(','));
      console.log('[TestML] Latency ms:', pipe.lastMlLatencyMs);
      console.log('[TestML] Percentiles ms:', pipe.mlLatencyP50, pipe.mlLatencyP90, pipe.mlLatencyP99);
      process.exit(0);
    }, 3500);
  }
}, 600).unref();
