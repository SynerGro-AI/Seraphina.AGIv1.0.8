<#
 start-proper-btc-miner.ps1
 Launches the Proper Antminer style Seraphina miner pointing at F2Pool for BTC, paying out to Kraken.

 USAGE (PowerShell):
   ./start-proper-btc-miner.ps1 -F2Account yourf2user -WorkerSuffix 001 -PayoutAddress 34X... -Verbose

 Parameters:
   -F2Account       F2Pool account/username (required)
   -WorkerSuffix    Worker name suffix (default: 001)
   -PayoutAddress   BTC payout address (Kraken deposit). Overrides mining-config.json value.
   -EnvFile         Optional path to .env style file with KEY=VALUE lines.
   -Verbose         Enables extra stratum debug logging.

 Example:
   ./start-proper-btc-miner.ps1 -F2Account myf2name -WorkerSuffix rig1 -PayoutAddress 34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf -Verbose

#>
param(
  [Parameter(Mandatory=$true)][string]$F2Account,
  [string]$WorkerSuffix='001',
  [string]$PayoutAddress='',
  [string]$EnvFile='',
  [switch]$Verbose
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

if (Test-Path $EnvFile) {
  Write-Host "[ENV] Loading $EnvFile" -ForegroundColor Cyan
  Get-Content $EnvFile | ForEach-Object {
    if ($_ -match '^[#;]') { return }
    if ($_ -match '^(.*?)=(.*)$') {
      $k=$matches[1].Trim(); $v=$matches[2].Trim();
      if ($k) { $env:$k = $v }
    }
  }
}

$env:F2POOL_ACCOUNT = $F2Account
$env:F2POOL_WORKER_SUFFIX = $WorkerSuffix
if ($PayoutAddress) { $env:BTC_PAYOUT_ADDRESS = $PayoutAddress }
if ($Verbose) { $env:STRATUM_DEBUG = '1' }

# Optional: user can pre-create .env with BTC_RPC_USER / BTC_RPC_PASS if needed.
Write-Host "[CONFIG] Worker: $F2Account.$WorkerSuffix" -ForegroundColor Green
if ($env:BTC_PAYOUT_ADDRESS) { Write-Host "[CONFIG] BTC Payout: $env:BTC_PAYOUT_ADDRESS" -ForegroundColor Green }
Write-Host "[ACTION] Launching proper-antminer-mining.js" -ForegroundColor Yellow

node .\proper-antminer-mining.js --verbose:$Verbose
