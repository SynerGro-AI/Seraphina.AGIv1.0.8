const { expect } = require('chai');
const fs = require('fs');
const path = require('path');

describe('FrameGroupExpand', () => {
  it('expands a synthetic frameHamGroup into frameHam records with optional digest chain', () => {
    const tmpInput = path.join(__dirname, 'tmp-group-prov.jsonl');
    const tmpOutput = path.join(__dirname, 'tmp-group-expanded.jsonl');
    // Create a minimal provenance with one frameHamGroup
    const group = { ts: Date.now(), type:'frameHamGroup', count:5, hamMin:0.0005, hamMax:0.002, hamAvg:0.0014, writtenFrames:3 };
    fs.writeFileSync(tmpInput, JSON.stringify(group)+'\n');
    // Run the expand utility
    require('child_process').execSync(`node seraphina-frame-group-expand.js --input=${tmpInput} --output=${tmpOutput}`);
    const lines = fs.readFileSync(tmpOutput,'utf8').trim().split(/\r?\n/);
    expect(lines.length).to.equal(5);
    const records = lines.map(l=>JSON.parse(l));
    // Check chain fields present
    for(const r of records){
      expect(r).to.have.property('type','frameHam');
      expect(r).to.have.property('syntheticFromGroup', true);
      expect(r).to.have.property('groupCount',5);
      expect(r).to.have.property('chainHash');
    }
    // Ensure ham values within min/max bounds
    const hamVals = records.map(r=>r.ham);
    expect(Math.min(...hamVals)).to.be.at.least(group.hamMin - 1e-6);
    expect(Math.max(...hamVals)).to.be.at.most(group.hamMax + 1e-6);
  });

  it('supports writeOnly flag to include only written frames', () => {
    const tmpInput = path.join(__dirname, 'tmp-group-prov2.jsonl');
    const tmpOutput = path.join(__dirname, 'tmp-group-expanded2.jsonl');
    const group = { ts: Date.now(), type:'frameHamGroup', count:6, hamMin:0.0004, hamMax:0.0018, hamAvg:0.0012, writtenFrames:2 };
    fs.writeFileSync(tmpInput, JSON.stringify(group)+'\n');
    require('child_process').execSync(`node seraphina-frame-group-expand.js --input=${tmpInput} --output=${tmpOutput} --writeOnly`);
    const lines = fs.readFileSync(tmpOutput,'utf8').trim().split(/\r?\n/);
    expect(lines.length).to.equal(2); // only writtenFrames
    const records = lines.map(l=>JSON.parse(l));
    for(const r of records){ expect(r.written).to.equal(true); }
  });
});
