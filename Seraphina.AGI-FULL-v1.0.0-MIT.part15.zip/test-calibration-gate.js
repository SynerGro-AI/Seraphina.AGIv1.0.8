'use strict';
const assert = require('assert');
process.env.SERAPHINA_CAL_GATE_MIN_ACC_IMPROVE='0.001'; // ensure improvement required
const { evaluateGate } = require('./seraphina-calibration-scheduler');

function testGateAccept(){
  const oldT = { empathy:0.45, prudence:0.5 };
  const newT = { empathy:0.47, prudence:0.53 };
  const gate = evaluateGate(oldT, newT, { accA:0.62 }, { accA:0.63 });
  assert(gate.passed, 'Gate should pass small positive deltas & improvement');
}

function testGateRejectDelta(){
  const oldT = { integrity:0.4 };
  const newT = { integrity:0.55 }; // delta 0.15 > default 0.06
  const gate = evaluateGate(oldT, newT, { accA:0.60 }, { accA:0.70 });
  assert(!gate.passed, 'Gate should reject big delta');
}

function testGateRejectNoImprove(){
  const oldT = { justice:0.5 };
  const newT = { justice:0.52 };
  const gate = evaluateGate(oldT, newT, { accA:0.62 }, { accA:0.62 });
  assert(!gate.passed, 'Gate should reject when no improvement and MIN_ACC_IMPROVE > 0');
}

function run(){
  testGateAccept();
  testGateRejectDelta();
  testGateRejectNoImprove();
  console.log('[TestCalibrationGate] PASS');
}

if(require.main===module){ run(); }
module.exports = { run };