#!/usr/bin/env node
// Verifies integrity of ISO staging artifacts: manifest.json, merkle-root.txt, optional hmac.txt
// Recomputes per-file SHA256 (optionally) or trusts manifest entries (fast mode) and rebuilds Merkle tree.
// Usage:
//   node verify-iso-artifacts.js            (fast, trust manifest hashes)
//   node verify-iso-artifacts.js --rehash   (rehash each file in staging for deeper validation)
// Env:
//   VERIFY_HMAC_KEY   If provided, recompute HMAC(manifest.json + merkleRoot) and compare to hmac.txt

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const STAGING = path.join(process.cwd(), 'iso-staging');
function fatal(msg){ console.error('[VERIFY][FATAL]', msg); process.exit(1); }
function log(...a){ console.log('[VERIFY]', ...a); }

if(!fs.existsSync(STAGING)) fatal('Staging directory iso-staging not found. Run build-iso.js first.');
const manifestPath = path.join(STAGING,'manifest.json');
const merklePath = path.join(STAGING,'merkle-root.txt');
if(!fs.existsSync(manifestPath)) fatal('manifest.json missing in staging');
if(!fs.existsSync(merklePath)) fatal('merkle-root.txt missing in staging');

const manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8'));
const recordedRoot = fs.readFileSync(merklePath,'utf8').trim();
const rehash = process.argv.includes('--rehash');
const hmacKey = process.env.VERIFY_HMAC_KEY || null;

function sha256File(p){
  return new Promise((resolve,reject)=>{
    const h = crypto.createHash('sha256');
    const rs = fs.createReadStream(p);
    rs.on('data',d=>h.update(d));
    rs.on('error',reject);
    rs.on('end',()=>resolve(h.digest('hex')));
  });
}

async function recomputeLeaves(){
  const leaves = [];
  for(const entry of manifest){
    const full = path.join(STAGING, entry.path);
    if(!fs.existsSync(full)) fatal('Missing file listed in manifest: '+entry.path);
    let sha = entry.sha256;
    if(rehash){ sha = await sha256File(full); if(sha !== entry.sha256){ fatal('Hash mismatch on '+entry.path+' manifest='+entry.sha256+' actual='+sha); } }
    leaves.push(sha);
  }
  return leaves;
}

function merkleRoot(leaves){
  if(leaves.length === 0) return '';
  let level = leaves.map(h=> Buffer.from(h,'hex'));
  while(level.length > 1){
    const next = [];
    for(let i=0;i<level.length;i+=2){
      if(i+1===level.length){
        next.push(crypto.createHash('sha256').update(Buffer.concat([level[i], level[i]])).digest());
      } else {
        next.push(crypto.createHash('sha256').update(Buffer.concat([level[i], level[i+1]])).digest());
      }
    }
    level = next;
  }
  return level[0].toString('hex');
}

(async ()=>{
  log('Starting verification. Entries:', manifest.length, 'rehash:', rehash);
  const leaves = await recomputeLeaves();
  const recomputedRoot = merkleRoot(leaves);
  log('Recorded root:', recordedRoot);
  log('Recomputed root:', recomputedRoot);
  if(recomputedRoot !== recordedRoot){ fatal('Merkle root mismatch'); }
  log('Merkle root OK');
  if(hmacKey){
    const manifestStr = fs.readFileSync(manifestPath,'utf8');
    const hmacCalc = crypto.createHmac('sha256', hmacKey).update(manifestStr).update(recordedRoot).digest('hex');
    const hmacPath = path.join(STAGING,'hmac.txt');
    if(!fs.existsSync(hmacPath)) fatal('hmac.txt missing but VERIFY_HMAC_KEY provided');
    const hmacRecorded = fs.readFileSync(hmacPath,'utf8').trim();
    log('Recorded HMAC:', hmacRecorded);
    log('Computed HMAC :', hmacCalc);
    if(hmacCalc !== hmacRecorded) fatal('HMAC mismatch');
    log('HMAC OK');
  }
  log('Verification complete: ALL OK');
})();
