'use strict';
// test-simulate-virtue-correlation.js
// Basic validation for simulate-virtue-correlation.js
const { generate, computeMetrics } = require('./simulate-virtue-correlation.js');
// We will run generate() after temporarily adjusting globals via CLI-like args if needed.

function runTests(){
  // For stability request a larger sample by temporarily overriding process args if not set
  if(!process.argv.find(a=> /^--n=/.test(a))){ process.argv.push('--n=2000'); }
  const records = generate();
  const metrics = computeMetrics(records);
  console.log('[TestMetrics]', metrics);
  const targetPrudence = -0.25; // default target from script
  const targetTruth = 0.35;
  const tol = 0.08; // acceptable deviation window
  if(Math.abs(metrics.corrPrudenceHarm - targetPrudence) > tol) throw new Error('prudence->harm correlation out of tolerance');
  if(Math.abs(metrics.corrTruthfulnessPass - targetTruth) > tol) throw new Error('truthfulness->truthPass correlation out of tolerance');
  // Basic bounds
  if(metrics.n !== records.length) throw new Error('n mismatch');
  if(metrics.aucHarm < 0.3 || metrics.aucHarm > 0.9) throw new Error('AUC out of plausible range');
  if(metrics.permutationP.prudenceHarm < 0 || metrics.permutationP.prudenceHarm > 1) throw new Error('Permutation p out of bounds');
  console.log('All tests passed.');
}

if(require.main === module){
  try { runTests(); } catch(e){ console.error('Test failure:', e.message); process.exit(1); }
}
