// test-life-drawing-retention-adaptive.js
'use strict';
process.env.LIFE_DRAWING_RETENTION_DECAY_FACTOR='0.5';
const { computeRetention } = require('./life-drawing-retention');
const rep = computeRetention();
console.log(JSON.stringify(rep,null,2));
if(rep.ok){
  const hasAdaptive = typeof rep.adaptiveFactor === 'number';
  if(!hasAdaptive) throw new Error('adaptiveFactor missing');
}
