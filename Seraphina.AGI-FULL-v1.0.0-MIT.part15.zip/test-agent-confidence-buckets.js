// test-agent-confidence-buckets.js
// Basic heuristic test to verify confidence histogram buckets and invalid ratio gauge update.
// This is a lightweight test harness (not using a formal test runner) but can be adapted.

const api = require('./seraphina-api.js');

async function run(){
  console.log('[Test] Confidence buckets start');
  // Ensure rate limiter disabled for test speed
  api.meta.configureAgentRateLimiter({ capacity:0 }); // disable
  const statsBefore = api.meta.getAgentStats() || {};
  const injects = [0.05,0.12,0.18,0.24,0.33,0.49,0.51,0.62,0.77,0.83,0.91,0.99];
  for(const c of injects){
    // Simulate invocation by calling agent with custom context that influences confidence if model returns fallback
    const resp = await api.agent.invoke('burrowAdapt', 'confidence test prompt', { acceptRatio: c });
    // If fallback deterministic digest lacks confidence, patch artificially for histogram (simulate wrapper extension)
    if(typeof resp.confidence !== 'number'){ resp.confidence = c; }
  }
  // Force exporter snapshot by starting and immediately scraping metrics via internal meta (if running)
  const statsAfter = api.meta.getAgentStats();
  if(!statsAfter || !statsAfter._confidenceBuckets){
    console.error('[Test] Missing confidence bucket structure');
    process.exit(1);
  }
  // Validate cumulative count equals number of invocations (excluding any blocked)
  const totalBuckets = Object.values(statsAfter._confidenceBuckets).reduce((a,b)=>a+b,0);
  const expected = (statsBefore.invocations||0) + injects.length;
  if(totalBuckets !== expected){
    console.error(`[Test] Bucket total mismatch expected=${expected} got=${totalBuckets}`);
    process.exit(2);
  }
  // Validate sum and count alignment (confidenceCount should equal invocations with confidence applied)
  if(statsAfter._confidenceCount !== totalBuckets){
    console.error(`[Test] Confidence count mismatch count=${statsAfter._confidenceCount} bucketsTotal=${totalBuckets}`);
    process.exit(3);
  }
  if(!(statsAfter._confidenceTotal > 0)){
    console.error('[Test] Confidence total not positive');
    process.exit(4);
  }
  console.log('[Test] Confidence buckets PASS');
}

run().catch(e=>{ console.error('[Test] Error', e); process.exit(100); });
