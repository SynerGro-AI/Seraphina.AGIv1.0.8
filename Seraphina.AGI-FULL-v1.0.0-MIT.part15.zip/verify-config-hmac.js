// verify-config-hmac.js
// Recompute CONFIG_HASH from deterministic-config.js and verify HMAC signature.
// Usage: node verify-config-hmac.js --hmac <expected> --key <key>

const crypto = require('crypto');
const fs = require('fs');

function loadConfigHash(){
  const mod = require('./deterministic-config.js');
  return mod.CONFIG_HASH;
}

function parseArgs(){
  const args = process.argv.slice(2);
  const out = {};
  for (let i=0;i<args.length;i++){
    if (args[i] === '--hmac') out.hmac = args[++i];
    else if (args[i] === '--key') out.key = args[++i];
  }
  if (!out.key) out.key = process.env.CONFIG_HMAC_KEY;
  return out;
}

function main(){
  const { hmac: expected, key } = parseArgs();
  const configHash = loadConfigHash();
  if (!key){ console.error('Missing key (pass --key or set CONFIG_HMAC_KEY)'); process.exit(1); }
  const recomputed = crypto.createHmac('sha256', key).update(configHash).digest('hex');
  console.log(JSON.stringify({ configHash, recomputedHmac: recomputed, expected: expected||null, match: expected? (expected.toLowerCase() === recomputed.toLowerCase()): null }, null, 2));
  if (expected && expected.toLowerCase() !== recomputed.toLowerCase()) process.exit(2);
}

if (require.main === module) main();
module.exports = { main };
