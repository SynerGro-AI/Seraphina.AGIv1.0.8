// wallet-platform.js
// Central wallet registry & export scaffolding. Future: integrate signing, transaction building.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { deriveSeed, loadKeystore, ensureMnemonic } = (()=>{ try { return require('./keystore.js'); } catch { return {}; } })();

class WalletPlatform {
  constructor(opts={}){
    this.registryFile = opts.registryFile || 'wallet-registry.json';
    this.state = { wallets: {}, updated: Date.now() };
    this._load();
  }
  _load(){
    try { if (fs.existsSync(this.registryFile)){ this.state = JSON.parse(fs.readFileSync(this.registryFile,'utf8')); } } catch(e){ }
  }
  _persist(){
    this.state.updated = Date.now();
    try { fs.writeFileSync(this.registryFile, JSON.stringify(this.state,null,2)); } catch(e){ }
  }
  addAddress(symbol, address, meta={}){
    if (!symbol || !address) return false;
    if (!this.state.wallets[symbol]) this.state.wallets[symbol] = [];
    if (!this.state.wallets[symbol].some(w=>w.address===address)){
      this.state.wallets[symbol].push({ address, meta, added: Date.now() });
      this._persist();
      return true;
    }
    return false;
  }
  list(symbol){ return (this.state.wallets[symbol]||[]).map(w=>w.address); }
  exportKraken(symbol){
    // Placeholder: In real implementation produce CSV or API call payload.
    const addrs = this.list(symbol);
    const payload = { symbol, addresses: addrs, ts: Date.now() };
    const name = `kraken-export-${symbol}-${Date.now()}.json`;
    try { fs.writeFileSync(name, JSON.stringify(payload,null,2)); } catch(e){ }
    return name;
  }
  deriveTempAddress(symbol){
    // If keystore present and passphrase set, derive pseudo HD child (placeholder path m/44'/0'/0'/0/index)
    try {
      const pass = process.env.KEYSTORE_PASS;
      const ksFile = process.env.KEYSTORE_FILE || 'seed.keystore.json';
      if (pass){ ensureMnemonic(ksFile, pass); const ks = loadKeystore(ksFile); if (ks){ const seed = deriveSeedFromKeystore(ks, pass); const addr = derivePseudoAddressFromSeed(seed, symbol, this.list(symbol).length); this.addAddress(symbol, addr, { hd: true }); return addr; } }
    } catch(e){ /* fallback */ }
    const h = crypto.createHash('sha256').update(symbol+Date.now()).digest('hex');
    const address = symbol.charAt(0) + h.slice(0,33); this.addAddress(symbol, address, { derived: true }); return address;
  }
}

function deriveSeedFromKeystore(ks, pass){
  try { const { decrypt } = require('./keystore.js'); return decrypt(ks, pass); } catch(e){ return null; }
}
function derivePseudoAddressFromSeed(seed, symbol, index){
  // Lightweight deterministic mapping: hash(seed + symbol + index) -> pseudo base58-like string
  const h = crypto.createHash('sha256').update(seed).update(symbol).update(String(index)).digest('hex');
  return symbol.charAt(0).toUpperCase() + h.slice(0,33);
}

module.exports = { WalletPlatform };
