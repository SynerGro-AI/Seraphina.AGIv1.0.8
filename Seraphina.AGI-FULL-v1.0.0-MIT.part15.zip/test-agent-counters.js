// test-agent-counters.js
'use strict';
const assert = require('assert');
const api = require('./seraphina-api.js');

(async ()=>{
  // Start exporter (ephemeral random port 0)
  api.exporters.startPrometheusExporter({ port:0 });
  // Configure generous rate limiter to avoid unintended blocks
  api.meta.configureAgentRateLimiter({ capacity: 100, refillIntervalMs: 60000 });

  // Override global stub to cycle through diverse actions
  const cycleActions = ['adjust_prune','adjust_growth','rotate_geometry','tune_plane_weights','latency_mitigate','noop'];
  let idx = 0;
  global.__AUR_AGENT_INVOKE__ = (role,prompt,context)=>{
    const action = cycleActions[idx % cycleActions.length]; idx++;
    return { action, delta: action==='noop'?0: (action==='adjust_prune'? -0.01 : 0.02), confidence: action==='noop'?0:0.6, note:'cycle', integrity:'digest'+idx };
  };

  // Fire a batch of invocations
  const total = 30;
  for(let i=0;i<total;i++){
    api.agent.invoke('burrowAdapt','cycle',{i});
  }
  await new Promise(r=>setTimeout(r,75));

  const stats = api.meta.getAgentStats();
  assert(stats.invocations === total,'Total invocations mismatch');
  for(const a of cycleActions){
    assert(stats.actions[a] >= 4, 'Expected >=4 occurrences of '+a);
  }
  assert(stats.blocked === 0,'No blocks expected (shield or rate limiter)');

  console.log('[TestAgentCounters] OK actions distribution:', stats.actions);
})();
