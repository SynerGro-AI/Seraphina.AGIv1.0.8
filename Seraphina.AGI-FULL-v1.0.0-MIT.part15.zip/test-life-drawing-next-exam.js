#!/usr/bin/env node
'use strict';
const { generateFocusedExam } = require('./life-drawing-next-exam-recommend');

const exam = generateFocusedExam({ limit: 6 });
if(!exam.focus){
  console.error('No focus section produced.');
  process.exit(1);
}
const { weakFields, fieldsOrdered, scores } = exam.focus;
if(!Array.isArray(weakFields) || !weakFields.length){
  console.error('weakFields missing or empty');
  process.exit(1);
}
if(!Array.isArray(fieldsOrdered) || !fieldsOrdered.length){
  console.error('fieldsOrdered missing or empty');
  process.exit(1);
}
if(!Array.isArray(scores) || !scores.length){
  console.error('scores missing or empty');
  process.exit(1);
}
// Verify fieldsOrdered matches score ordering by descending score
const sortedByScore = [...scores].sort((a,b)=> b.score - a.score).map(s=> s.field);
if(JSON.stringify(sortedByScore) !== JSON.stringify(fieldsOrdered)){
  console.error('fieldsOrdered does not match descending score order');
  console.error('Expected:', sortedByScore, 'Got:', fieldsOrdered);
  process.exit(1);
}
console.log(JSON.stringify({ ok:true, weakFields, fieldsOrdered, scoresCount: scores.length }, null, 2));
