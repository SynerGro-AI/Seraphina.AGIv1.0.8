// tar-bundle-snapshots.js
// Build a POSIX ustar-compatible tar then gzip it for selected snapshot files; produce signed manifest.
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const zlib = require('zlib');

const SNAP_DIR = process.env.SERAPHINA_SNAPSHOT_DIR || '.';
const OUT_TGZ = process.env.SERAPHINA_TARBUNDLE_OUT || 'snapshots-bundle.tgz';
const LIMIT = parseInt(process.env.SERAPHINA_TARBUNDLE_LIMIT || '5',10);
const HMAC_KEY = process.env.SERAPHINA_SNAPSHOT_HMAC_KEY || '';
const MANIFEST = process.env.SERAPHINA_TARBUNDLE_MANIFEST || 'snapshot-tar-manifest.json';

function listSnaps(){
  return fs.readdirSync(SNAP_DIR).filter(f=> /seraphina-snapshot-.*\.json$/i.test(f)).sort().slice(-LIMIT);
}

function sha256(p){ return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }

function buildManifest(files){
  const entries = files.map(f=> { const full= SNAP_DIR + (SNAP_DIR.endsWith('/')||SNAP_DIR.endsWith('\\')?'':'/') + f; return { file:f, size: fs.statSync(full).size, sha256: sha256(full) }; });
  const root = crypto.createHash('sha256').update(JSON.stringify(entries)).digest('hex');
  let signature = crypto.createHash('sha256').update(root).digest('hex');
  if(HMAC_KEY) signature = crypto.createHmac('sha256', HMAC_KEY).update(root).digest('hex');
  return { ts:Date.now(), entries, root, signature };
}

function pad(buf, size){ if(buf.length >= size) return buf.slice(0,size); const out = Buffer.alloc(size); buf.copy(out); return out; }
function oct(n, len){ const s = n.toString(8); return ('000000000000'+s).slice(-len); }
function checksum(hdr){ let sum=0; for(const b of hdr) sum+=b; return oct(sum,6)+ '\0 '; }

function makeHeader(name, size){
  const hdr = Buffer.alloc(512, 0); // POSIX ustar
  pad(Buffer.from(name),100).copy(hdr,0);
  pad(Buffer.from(oct(0,7)+'\0'),8).copy(hdr,100); // mode
  pad(Buffer.from(oct(0,7)+'\0'),8).copy(hdr,108); // uid
  pad(Buffer.from(oct(0,7)+'\0'),8).copy(hdr,116); // gid
  pad(Buffer.from(oct(size,11)+'\0'),12).copy(hdr,124); // size
  const now = Math.floor(Date.now()/1000);
  pad(Buffer.from(oct(now,11)+'\0'),12).copy(hdr,136); // mtime
  // checksum placeholder
  for(let i=148;i<156;i++) hdr[i]=0x20; // spaces
  hdr[156] = '0'.charCodeAt(0); // typeflag
  pad(Buffer.from('ustar\0'),6).copy(hdr,257);
  pad(Buffer.from('00'),2).copy(hdr,263);
  const sumStr = checksum(hdr); pad(Buffer.from(sumStr),8).copy(hdr,148);
  return hdr;
}

function buildTar(files){
  const parts=[];
  for(const f of files){
    const full = SNAP_DIR + (SNAP_DIR.endsWith('/')||SNAP_DIR.endsWith('\\')?'':'/') + f;
    const data = fs.readFileSync(full);
    const hdr = makeHeader(f, data.length);
    parts.push(hdr, data);
    const padLen = (512 - (data.length % 512)) % 512;
    if(padLen) parts.push(Buffer.alloc(padLen));
  }
  parts.push(Buffer.alloc(1024)); // two empty blocks
  return Buffer.concat(parts);
}

function run(){
  const snaps = listSnaps();
  if(!snaps.length){ console.log('[TarBundle] No snapshots'); return; }
  const manifest = buildManifest(snaps);
  fs.writeFileSync(MANIFEST, JSON.stringify(manifest,null,2));
  const tarBuf = buildTar(snaps);
  const gz = zlib.gzipSync(tarBuf, { level:9 });
  fs.writeFileSync(OUT_TGZ, gz);
  console.log('[TarBundle] Wrote', OUT_TGZ, 'bytes=', gz.length, 'root=', manifest.root);
}

if(require.main===module){ run(); }
module.exports = { run };