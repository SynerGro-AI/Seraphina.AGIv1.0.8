// test-life-drawing-weighting.js
'use strict';
const { generateLifeDrawingExam } = require('./life-drawing-exam');
const { startSession, recordResponse, finalizeSession } = require('./life-drawing-session');

function simulate(weightsOverride){
  if(weightsOverride){ process.env.LIFE_DRAWING_WEIGHTS = JSON.stringify(weightsOverride); }
  const exam = generateLifeDrawingExam();
  const session = startSession(exam);
  const q = exam.questions[0];
  // Provide only gestureDirection and centerOfGravity
  recordResponse(session, { questionId: q.id, answers: { gestureDirection:'C', centerOfGravity:'midline' } });
  const result = finalizeSession(session, exam);
  return result.perQuestion[0];
}

function run(){
  delete process.env.LIFE_DRAWING_WEIGHTS;
  const base = simulate();
  const boosted = simulate({ gestureDirection:2.0, centerOfGravity:2.0 });
  console.log(JSON.stringify({ base, boosted }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };
