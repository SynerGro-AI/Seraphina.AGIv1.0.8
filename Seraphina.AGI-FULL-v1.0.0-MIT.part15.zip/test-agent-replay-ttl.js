'use strict';
const assert = require('assert');

async function run(){
  // Set very short TTL (100 ms) then require module fresh
  process.env.AUR_AGENT_REPLAY_TTL='100';
  // Clear require cache to force reload
  delete require.cache[require.resolve('./aurrelia-agent-invoke')];
  const { agentInvoke } = require('./aurrelia-agent-invoke');
  const p='ttl-prompt-example';
  const first = await agentInvoke('burrowAdapt', p, {});
  const second = await agentInvoke('burrowAdapt', p, {});
  assert(second.replay === true, 'Second call before TTL should be replay');
  // Wait past TTL
  await new Promise(r=> setTimeout(r, 150));
  const third = await agentInvoke('burrowAdapt', p, {});
  assert(!third.replay, 'Third call after TTL should not be replay');
  console.log('[TestReplayTTL] PASS');
}

if(require.main===module){ run().catch(e=>{ console.error('[TestReplayTTL] FAIL', e); process.exit(1); }); }
module.exports = { run };