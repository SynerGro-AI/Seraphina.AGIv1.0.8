// test-life-drawing-session.js
'use strict';
const { generateLifeDrawingExam } = require('./life-drawing-exam');
const { startSession, recordResponse, finalizeSession } = require('./life-drawing-session');
const { generateHints } = require('./life-drawing-rubric');

function run(){
  let exam = generateLifeDrawingExam();
  // Fallback if no files found: create synthetic questions
  if(exam.questionCount === 0){
    exam = { questions: [
      { id:'synthetic1', poseFile:'profile_twist_lean.jpg', expectedFields:['gestureDirection','centerOfGravity','dominantMass','balanceAssessment'] },
      { id:'synthetic2', poseFile:'stretch_reach_pose.png', expectedFields:['gestureDirection','centerOfGravity','dominantMass','balanceAssessment','negativeSpace'] }
    ] };
  }
  const session = startSession(exam);
  exam.questions.slice(0,2).forEach((q,i)=>{
    const hints = generateHints(q.poseFile);
    const answers = {
      gestureDirection: 'S-curve',
      centerOfGravity: 'over front foot',
      dominantMass: 'torso leaning forward',
      balanceAssessment: hints.hints[0],
      negativeSpace: i===1 ? 'arm loop clearance' : undefined
    };
    recordResponse(session, { questionId: q.id, answers });
  });
  const result = finalizeSession(session, exam);
  console.log(JSON.stringify({ totalScore: result.totalScore, perQuestion: result.perQuestion }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };
