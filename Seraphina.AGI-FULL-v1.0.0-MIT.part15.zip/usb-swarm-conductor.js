// usb-swarm-conductor.js
// Deterministic USB / Bluetooth cube swarm conductor integrating Aurelia + Seraphina advisory.
// Environment Variables:
//   MAX_CUBES: Cap on cubes (default 35)
//   SWARM_LEDGER: Path to ledger file (default swarm-ledger.jsonl)
//   SERAPHINA_RETENTION_ORACLE: Path to oracle module (default ./aurrelia-retention-infer.js)
//   SWARM_POLL_MS: Interval for re-probe (default 10000)
//   ENABLE_BT_FALLBACK: '1' to attempt noble Bluetooth fallback discovery
//   SWARM_PD_WATTS: PD negotiation watts (default 100)
//   SWARM_PULSE_BASE: Base pulse frequency Hz (default 17)
//   SWARM_TUNE_DELTA: Hz increment when retention above threshold (default 2)
//   SWARM_RETENTION_THRESH: Threshold for retention tuning (default 0.6)
//   SWARM_USB_VID / SWARM_USB_PID: Override VID/PID matching
// Security Notes:
// - Ledger entries are hash chained (prevHash + sha256(entry)). No execution of cube telemetry.
// - Retention tuning advisory only adjusts pulse frequency (bounded small delta). No arbitrary commands.
// - Deterministic ordering via SHA seeded shuffle; seed uses rig id + discovery phase suffix.
//
// Usage:
//   node usb-swarm-conductor.js --rig-id=eternal-forge-2025
//
// Future Enhancements:
// - Gzip ledger rotation (size thresholds)
// - Temperature & power guard adaptive back-off
// - Structured JSON schema validation for oracle predictions
// - Bluetooth selective pairing trust list

const usb = safeRequire('usb');
const noble = safeRequire('noble');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function safeRequire(mod){ try{ return require(mod); } catch(e){ return null; } }

const argvRigIdx = process.argv.findIndex(a => a.startsWith('--rig-id='));
const RIG_ID = argvRigIdx !== -1 ? process.argv[argvRigIdx].split('=')[1] : (process.env.RIG_ID || 'eternal-forge-genesis');
const MAX_CUBES = parseInt(process.env.MAX_CUBES || '35');
const SWARM_LEDGER = process.env.SWARM_LEDGER || 'swarm-ledger.jsonl';
const SERAPHINA_ORACLE = process.env.SERAPHINA_RETENTION_ORACLE || './aurrelia-retention-infer.js';
const SWARM_POLL_MS = parseInt(process.env.SWARM_POLL_MS || '10000');
const PD_WATTS = parseInt(process.env.SWARM_PD_WATTS || '100');
const PULSE_BASE_HZ = parseInt(process.env.SWARM_PULSE_BASE || '17');
const TUNE_DELTA = parseInt(process.env.SWARM_TUNE_DELTA || '2');
const RET_THRESH = parseFloat(process.env.SWARM_RETENTION_THRESH || '0.6');
const USB_VID = process.env.SWARM_USB_VID ? parseInt(process.env.SWARM_USB_VID) : 0x2341;
const USB_PID = process.env.SWARM_USB_PID ? parseInt(process.env.SWARM_USB_PID) : 0x8036;
const ENABLE_BT_FALLBACK = process.env.ENABLE_BT_FALLBACK === '1';

class SwarmConductor {
  constructor(){
    this.seedBase = `seraphina-swarm-${RIG_ID}`;
    this.cubes = [];
    this.chainHash = crypto.createHash('sha256').update(this.seedBase).digest('hex');
    this.ledgerPath = SWARM_LEDGER;
    this.oracleLoaded = false;
    this.oracle = null;
  }

  shaSeedOrder(indices, suffix){
    const seedStr = `${this.seedBase}-${suffix}`;
    const seedHash = crypto.createHash('sha256').update(seedStr).digest();
    return indices.map(i => ({ i, h: seedHash[i % seedHash.length] }))
      .sort((a,b)=> a.h - b.h)
      .map(e=> e.i);
  }

  discoverUSB(){
    if(!usb){ console.warn('[Swarm] usb module unavailable'); return []; }
    const devices = usb.getDeviceList();
    const candidates = devices.filter(d => d && d.deviceDescriptor && d.deviceDescriptor.idVendor === USB_VID && d.deviceDescriptor.idProduct === USB_PID);
    const orderedIdx = this.shaSeedOrder(Array.from({length: candidates.length}, (_,i)=> i), 'usb-discovery');
    return orderedIdx.map(i => candidates[i]).slice(0, MAX_CUBES);
  }

  async discoverBluetooth(){
    if(!noble || !ENABLE_BT_FALLBACK){ return []; }
    return new Promise(resolve => {
      const found = [];
      noble.on('discover', peripheral => {
        if(found.length >= MAX_CUBES) return;
        // Simple VID/PID mimic check by name (placeholder)
        if(/cube/i.test(peripheral.advertisement.localName || '')){
          found.push(peripheral);
        }
      });
      noble.on('stateChange', state => { if(state==='poweredOn'){ noble.startScanning([], true); setTimeout(()=>{ noble.stopScanning(); resolve(found); }, 3000); } else { resolve([]); } });
    });
  }

  openAndChainCube(cube, idx){
    try {
      if(cube.open) cube.open();
      if(cube.controlTransfer){ cube.controlTransfer(0x40, 0x01, 0, 0, Buffer.from([PD_WATTS])); }
      const pulseBuf = Buffer.from([PULSE_BASE_HZ, idx]);
      if(cube.transferOut){ cube.transferOut(1, pulseBuf); }
      let surplusW = null, ths = null;
      if(cube.transferIn){
        try {
          const status = cube.transferIn(1, 8);
          if(status && status.length >= 8){
            surplusW = status.readUInt32LE(0);
            ths = status.readUInt32LE(4) / 1e12;
          }
        } catch(e){ /* ignore telemetry errors */ }
      }
      console.log(`[Swarm] Cube ${idx} active: PD=${PD_WATTS}W baseHz=${PULSE_BASE_HZ} surplus=${surplusW} ths=${ths}`);
      return { idx, surplusW, ths };
    } catch(e){ console.warn(`[Swarm] Cube ${idx} open/chain failed: ${e.message}`); return null; }
  }

  appendLedger(entry){
    entry.prevHash = this.chainHash;
    entry.ts = Date.now();
    entry.rigId = RIG_ID;
    const digest = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    entry.chainHash = digest;
    try {
      fs.appendFileSync(this.ledgerPath, JSON.stringify(entry)+'\n');
      this.chainHash = digest;
    } catch(e){ console.warn('[Swarm] ledger append failed:', e.message); }
  }

  async tuneRetention(){
    if(this.oracleLoaded || !fs.existsSync(path.resolve(SERAPHINA_ORACLE))){ return; }
    try {
      const { RetentionOracle } = require(SERAPHINA_ORACLE);
      this.oracle = new RetentionOracle();
      await this.oracle.load();
      this.oracleLoaded = true;
      const cubeFields = this.cubes.map((c,i)=> ({ idx:i, time_min:5, coverage_pct:0.8, prior_retention:0.6, difficulty:0.7 }));
      const sortedRaw = this.oracle.sortFields ? this.oracle.sortFields(cubeFields) : cubeFields;
      const sanitized = sortedRaw.map(cf => {
        let pr = cf.predicted_retention;
        if(typeof pr !== 'number' || !isFinite(pr)) pr = cf.prior_retention || 0.6;
        // clamp reasonable range [0,1]
        if(pr < 0) pr = 0; if(pr > 1) pr = 1;
        return { ...cf, predicted_retention: pr };
      });
      sanitized.forEach(cf => {
        const tunedHz = PULSE_BASE_HZ + (cf.predicted_retention > RET_THRESH ? TUNE_DELTA : 0);
        // guard pulse boundaries
        const finalHz = Math.max(1, Math.min(255, tunedHz));
        const pulseBuf = Buffer.from([finalHz, cf.idx]);
        const cube = this.cubes[cf.idx];
        if(cube && cube.transferOut){ try { cube.transferOut(1, pulseBuf); } catch(e){ /* ignore */ } }
        console.log(`[Swarm] Cube ${cf.idx} tunedHz=${finalHz} predicted_ret=${cf.predicted_retention}`);
      });
    } catch(e){ console.warn('[Swarm] retention oracle unavailable or failed load:', e.message); }
  }

  async cycle(){
    const usbCubes = this.discoverUSB();
    let btCubes = [];
    if(usbCubes.length === 0){ btCubes = await this.discoverBluetooth(); }
    this.cubes = usbCubes.concat(btCubes).slice(0, MAX_CUBES);
    const telemetry = [];
    for(let i=0;i<this.cubes.length;i++){ const t = this.openAndChainCube(this.cubes[i], i); if(t) telemetry.push(t); }
    this.appendLedger({ cubes: this.cubes.length, telemetry });
    await this.tuneRetention();
  }
}

if(require.main === module){
  const conductor = new SwarmConductor();
  conductor.cycle();
  setInterval(()=> conductor.cycle(), SWARM_POLL_MS);
}

module.exports = { SwarmConductor };