# Seraphina Virtue Correlation Simulator & IV Extension

## Overview
`simulate-virtue-correlation.js` generates a deterministic synthetic dataset of virtue signals, confounders, and outcomes (harm probability, truth pass rate, fairness score) and computes:
- Pearson correlations
- Bootstrap confidence intervals
- Permutation p-values
- AUC (prudence predicting harm risk)
- Domain variance of prudence→harm correlation
- Chain-hashed ledger entry for audit

`seraphina-virtue-iv-extension.js` provides a causal inference stub (two-stage least squares) estimating the effect of truthfulness on truthPassRate via an instrument `infoQualityIndex`.

## Quick Start
```powershell
# Standard run (targets: prudence->harm -0.3, truthfulness->truthPass 0.4)
node .\simulate-virtue-correlation.js --n=5000 --corrPrudence=-0.3 --corrTruth=0.4 --boot=600 --perm=500 --seed=run1

# Smaller diagnostic with debug
node .\simulate-virtue-correlation.js --n=800 --corrPrudence=-0.4 --corrTruth=0.5 --debug --seed=diag1

# Override output paths
node .\simulate-virtue-correlation.js --jsonOut=virtue-dataset.json --metricsOut=virtue-metrics.json --ledger=virtue-ledger.jsonl

# IV causal estimation
node .\seraphina-virtue-iv-extension.js --n=2000 --seed=ivtest
```

## CLI Flags (Simulator)
| Flag | Purpose | Default |
|------|---------|---------|
| `--n` | Number of synthetic scenarios | 5000 |
| `--seed` | Deterministic seed | `virtue-sim-seed` |
| `--boot` / `--perm` | Bootstrap / permutation counts | 500 / 400 |
| `--corrPrudence` / `--corrPrudenceHarm` | Target correlation prudence→harm | -0.25 |
| `--corrTruth` / `--corrTruthfulnessPass` | Target correlation truthfulness→truthPass | 0.35 |
| `--corrJusticeFairness` | Target correlation justice→fairness | 0.30 |
| `--refineTol` | Correlation refinement tolerance | 0.01 |
| `--refineMaxIter` | Max refinement iterations | 4 |
| `--noise` | Fairness noise scale | 0.05 |
| `--jsonOut` | Dataset output path | `seraphina-virtue-sim-last.json` |
| `--metricsOut` | Metrics output path | `seraphina-virtue-sim-metrics.json` |
| `--ledger` | Ledger JSONL path | `seraphina-virtue-corr-ledger.jsonl` |
| `--debug` | Emit mixing correlation diagnostics | off |

## Outputs
1. Dataset JSON: Each record includes virtueSignals, confounders, outcomes.
2. Metrics JSON: Correlations, bootstrap CI, permutation p-values, AUC, domain variance, targets.
3. Ledger Line: Chain-hashed append-only audit of each run.

## Correlation Control
Refinement loop attempts up to `refineMaxIter` iterations; stops early when |Δcorr| < `refineTol`. Achieved iterations reported in `metrics.refine.{harmIters,truthIters,fairnessIters}`.

## Causal IV Extension
`infoQualityIndex` → truthfulness → truthPassRate.
Run 2SLS to estimate causal slope:
```powershell
node .\seraphina-virtue-iv-extension.js --n=3000 --seed=iv-demo
```
Returns JSON with stage1, stage2 coefficients, t-statistic, and naive standard error.

## Reproducibility
- All randomness derives from SHA256-seeded generators.
- Change seed to branch scenarios; ledger line includes chain hash for chronological integrity.
- Avoid editing ledger manually—use append-only semantics.

## Suggested Next Enhancements
1. Multi-iteration correlation refinement for near-exact target.
2. Robust bootstrap median/CI when correlations near boundaries.
3. Heteroskedasticity-robust SE for IV (HC3 estimator).
4. Add fairness causal channel with optional instruments (e.g., `justiceSignalCredibility`).
5. Prometheus exporter for real-time virtue correlation drift.

## Troubleshooting
| Symptom | Cause | Fix |
|---------|-------|-----|
| Correlation off by >0.1 | Target extreme or noise high | Reduce |target| or noise; enable `--debug` |
| AUC ~0.5 unexpectedly | Prudence signal too weak | Increase |corrPrudence| magnitude |
| Ledger missing | Path unwritable | Use full path or verify permissions |

## Minimal Programmatic Use
## Combined API Module
Use `seraphina-api.js` to access functionality without manual CLI arg injection:
```javascript
const api = require('./seraphina-api');
const { records, metrics } = api.virtueSim.runSimulation({ n: 2500, corrPrudence: -0.3, corrTruth: 0.4, corrJusticeFairness: 0.35, refineTol: 0.005 });
console.log(metrics.corrPrudenceHarm, metrics.corrTruthfulnessPass, metrics.corrJusticeFairness);
const ivRes = api.causal.runIV(1800, 'iv-seed');
const guardResp = api.moralGuard.evaluateText('This claim is entirely truthful and prudent.');
```

Prometheus exporter placeholder is exposed at `api.exporters.startPrometheusExporter()` and will throw until implemented.
```javascript
const { generate, computeMetrics } = require('./simulate-virtue-correlation');
const records = generate();
const metrics = computeMetrics(records);
console.log(metrics);
```

---
© Seraphina Synthetic Suite (Deterministic Research Utilities)