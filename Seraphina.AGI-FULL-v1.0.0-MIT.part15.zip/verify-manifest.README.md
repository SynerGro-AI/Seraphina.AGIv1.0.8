# verify-manifest.js

Utility to verify `artifact-hashes.json` integrity on target systems (e.g., Raspberry Pi). It checks:
- Presence of each artifact file.
- SHA256 match per file.
- Recomputed Merkle root equality.
- Optional HMAC seal validity when `USB_MANIFEST_HMAC_KEY` is set.

## Usage
```bash
node verify-manifest.js artifact-hashes.json
```
Return codes:
- 0: Success
- 2: Manifest read failure
- 3: Verification mismatch

Set `USB_MANIFEST_HMAC_KEY` to verify `hmacSeal` if present.
