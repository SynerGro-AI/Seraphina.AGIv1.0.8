// Minimal Stratum Core Client (clean extraction)
// Provides only essential Stratum V1 operations: connect, subscribe, authorize, receive jobs, submit shares.
// No simulation, no narrative, no inflated hashrate claims.
const net = require('net');
const EventEmitter = require('events');

class StratumCoreClient extends EventEmitter {
  constructor({ host, port, worker, password, agent }) {
    super();
    if (!host || !port) throw new Error('StratumCoreClient requires host & port');
    this.host = host;
    this.port = port;
    this.worker = worker || process.env.STRATUM_WORKER || 'worker.example';
    this.password = password || process.env.STRATUM_PASSWORD || 'x';
    this.agent = agent || 'Seraphina-Core';
    this.socket = null;
    this._buffer = '';
    this.extranonce1 = null;
    this.extranonce2Size = null;
    this.jobs = new Map(); // jobId -> job object
    this.debug = !!process.env.STRATUM_DEBUG;
    this._connected = false;
  }

  log(...a){ if (this.debug) console.log('[STRATUM_CORE]', ...a); }

  async connect(timeoutMs = 20000){
    if (this.socket) throw new Error('Already connecting/connected');
    await new Promise((resolve, reject) => {
      const t = setTimeout(()=>{ reject(new Error('Stratum connect timeout')); }, timeoutMs).unref();
      this.socket = net.createConnection(this.port, this.host, () => {
        this._connected = true;
        this.log('Connected', this.host+':'+this.port);
        this.emit('connected', { host: this.host, port: this.port });
        // Send mining.subscribe
        this._send({ id: 1, method: 'mining.subscribe', params: [ this.agent, null ] });
      });
      this.socket.setKeepAlive(true);
      this.socket.on('data', d => this._onData(d));
      this.socket.on('error', e => { if(!this._connected) reject(e); this.emit('error', e); });
      this.socket.on('close', () => { this._connected = false; this.emit('closed'); });
      this.once('authorized', () => { clearTimeout(t); resolve(); });
    });
  }

  close(){ try { this.socket?.end(); } catch {} }

  submitShare({ jobId, extranonce2, ntime, nonce }){
    if (!this.jobs.has(jobId)) return { ok:false, error:'UNKNOWN_JOB' };
    // extranonce2 must match size; caller ensures formatting.
    const id = 'share_'+jobId+'_'+Date.now();
    this._send({ id, method: 'mining.submit', params: [ this.worker, jobId, extranonce2, ntime, nonce ] });
    return { ok:true, id };
  }

  _send(obj){
    try {
      const line = JSON.stringify(obj)+'\n';
      this.socket.write(line);
      this.log('>>', line.trim());
    } catch(e){ this.emit('error', e); }
  }

  _onData(buf){
    this._buffer += buf.toString();
    const lines = this._buffer.split('\n');
    this._buffer = lines.pop();
    for(const line of lines){ this._handleLine(line.trim()); }
  }

  _handleLine(line){
    if(!line) return; let msg; try { msg = JSON.parse(line); } catch { return; }
    this.log('<<', line);
    if (msg.id === 1 && Array.isArray(msg.result)) {
      // subscription response: [ details, extranonce1, extranonce2_size ]
      this.extranonce1 = msg.result[1];
      this.extranonce2Size = msg.result[2];
      this.emit('subscribed', { extranonce1: this.extranonce1, extranonce2Size: this.extranonce2Size });
      // authorize
      this._send({ id: 2, method: 'mining.authorize', params: [ this.worker, this.password ] });
      return;
    }
    if (msg.id === 2 && (msg.result === true)) {
      this.emit('authorized', { worker: this.worker });
      return;
    }
    if (msg.method === 'mining.notify') {
      const job = this._parseJob(msg.params);
      if (job) { this.jobs.set(job.jobId, job); this.emit('job', job); }
      return;
    }
    if (msg.method === 'mining.set_difficulty') {
      this.emit('difficulty', { difficulty: msg.params?.[0] });
      return;
    }
    if (msg.id && msg.id.toString().startsWith('share_')) {
      if (msg.result === true) this.emit('shareAccepted', { id: msg.id });
      else if (msg.error) this.emit('shareRejected', { id: msg.id, error: msg.error });
    }
  }

  _parseJob(params){
    if(!Array.isArray(params) || params.length < 5) return null;
    return {
      jobId: params[0],
      prevhash: params[1],
      coinb1: params[2],
      coinb2: params[3],
      merkleBranches: Array.isArray(params[4]) ? params[4] : [],
      version: params[5],
      nbits: params[6],
      ntime: params[7],
      clean: params[8]
    };
  }
}

module.exports = { StratumCoreClient };
