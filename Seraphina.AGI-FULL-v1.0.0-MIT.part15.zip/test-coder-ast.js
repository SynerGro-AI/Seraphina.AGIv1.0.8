#!/usr/bin/env node
'use strict';
// test-coder-ast.js
// Ensures AST parsing yields deterministic digest and fallback when library absent.
const { CoderTriad } = require('./seraphina-coder-triad.js');

function testDeterminism(){
  const code = 'class Alpha { beta(){ return 1 + 2 } }\nfunction gamma(x){ return x*2 }';
  const triad = new CoderTriad({ seed:'ast-test-seed' });
  triad.registerBlock('test', code);
  const r1 = triad.triadCycle({ id:'test', code });
  const r2 = triad.triadCycle({ id:'test', code });
  if(r1.digest !== r2.digest){
    console.error('[FAIL] Digest drift', r1.digest, r2.digest);
    process.exit(1);
  }
  if(r1.ast.ok && r1.ast.funcCount < 1){
    console.error('[FAIL] AST reported ok but funcCount < 1');
    process.exit(1);
  }
  console.log('[PASS] Deterministic AST digest', r1.digest.slice(0,16), 'astOK=', r1.ast.ok, 'funcs=', r1.ast.funcCount);
}

function testFallback(){
  // Simulate absence by temporarily shadowing require for esprima if not installed.
  // If esprima is installed we still accept ast.ok true; fallback triggers only when missing.
  const code = 'function delta(){ return 42 }';
  const triad = new CoderTriad({ seed:'ast-fallback-seed' });
  triad.registerBlock('fb', code);
  const res = triad.triadCycle({ id:'fb', code });
  if(!res.ast.ok){
    if(res.ast.findings && res.ast.findings[0] !== 'ast_unavailable'){ console.error('[FAIL] Fallback mismatch'); process.exit(1); }
    console.log('[PASS] Fallback path ast_unavailable');
  } else {
    console.log('[INFO] esprima present; fallback not exercised');
  }
}

if(require.main === module){
  testDeterminism();
  testFallback();
}