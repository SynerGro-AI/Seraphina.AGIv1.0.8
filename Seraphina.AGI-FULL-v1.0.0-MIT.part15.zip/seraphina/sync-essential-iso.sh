#!/bin/bash
# sync-essential-iso.sh
# Copy only essential files needed for ISO build to a target directory on ext4.
# Usage: ./sync-essential-iso.sh /mnt/c/Users/user/OneDrive/AppData/Documents/mining ~/octa-iso-work/octa-mining
set -uo pipefail
SRC=${1:-}
DEST=${2:-}
if [[ -z "$SRC" || -z "$DEST" ]]; then
  echo "Usage: $0 <src> <dest>" >&2; exit 1
fi
if [[ ! -d "$SRC" ]]; then
  echo "Source directory not found: $SRC" >&2; exit 1
fi
mkdir -p "$DEST"
# Explicit file whitelist patterns
INCLUDE_FILES=(
  build-ubuntu-mining-preseed.sh
  build-baremetal.sh
  octa-powershell.ps1
  minimal-os/baremetal-build/out/bzImage
  minimal-os/baremetal-build/out/initramfs-seraphina.img
  minimal-os/baremetal-build/out/octalang-build-report.json
  aurelia_miner.js
  triad_miner.js
)
# Rsync base excludes to avoid heavy dirs
EXCLUDES=(
  --exclude '.venv/'
  --exclude 'node_modules/'
  --exclude '.git/'
  --exclude '.github/'
  --exclude '*.iso'
  --exclude 'hybrid-iso-build/'
  --exclude '*.log'
)
# Initial pass copy minimal directories needed (scripts + minimal-os hierarchy) with progress markers.
echo "[SYNC] begin minimal-os stage"
# Background size/progress reporter (guard PID)
PROG_PID=""
(
  while true; do
    du -sh "$DEST" 2>/dev/null | sed 's/^/[SYNC-PROGRESS] /'; sleep 5;
  done
) & PROG_PID=$!
# Correct rsync flags: use --info=progress2 and separate --stats
rsync -a --info=progress2 --stats "${EXCLUDES[@]}" "$SRC/minimal-os/" "$DEST/minimal-os/" 2>&1 | sed 's/^/[SYNC] /'
RSYNC_EXIT=${PIPESTATUS[0]}
if [ "${RSYNC_EXIT}" -ne 0 ]; then
  echo "[SYNC][WARN] minimal-os rsync encountered issues (exit=${RSYNC_EXIT})"
fi
if [ -n "$PROG_PID" ]; then kill "$PROG_PID" 2>/dev/null || true; fi
echo "[SYNC] end minimal-os stage"
# Copy each include file if exists
for f in "${INCLUDE_FILES[@]}"; do
  if [[ -f "$SRC/$f" ]]; then
    mkdir -p "$DEST/$(dirname "$f")"
    if rsync -a "$SRC/$f" "$DEST/$f" 2>/dev/null; then
      echo "[SYNC] copied $f"
    else
      echo "[SYNC][WARN] failed copy $f"
    fi
  else
    echo "[SYNC][MISS] $f not found in source"
  fi
done
# Ensure executable bits
chmod +x "$DEST"/build-ubuntu-mining-preseed.sh 2>/dev/null || true
chmod +x "$DEST"/build-baremetal.sh 2>/dev/null || true
chmod +x "$DEST"/octa-powershell.ps1 2>/dev/null || true

echo "[SYNC] computing size summary"
du -sh "$DEST" 2>/dev/null | sed 's/^/[SYNC-SIZE] /'
echo "[OK] Essential sync complete at $DEST"
core_missing=false
for core in build-ubuntu-mining-preseed.sh build-baremetal.sh octa-powershell.ps1; do
  if [[ ! -f "$DEST/$core" ]]; then
    echo "[WARN] Missing core artifact: $core"
    core_missing=true
  fi
done
if [[ "$core_missing" = false ]]; then
  echo "[OK] Core artifacts present"
fi
