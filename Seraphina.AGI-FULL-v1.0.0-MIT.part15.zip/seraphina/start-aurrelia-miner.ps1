param(
    [string]$Coin = "btc",
    [string]$User = $env:F2POOL_USER,
    [string]$Worker = $env:F2POOL_WORKER,
    [string]$Password = $env:F2POOL_PASSWORD,
    [string]$LogDir = "./logs",
    [switch]$EnforceReal,
    [int]$RestartDelaySeconds = 5,
    [int]$MaxRestarts = 0,   # 0 = unlimited
    [switch]$Tail,
    [switch]$NoColor,
    [int]$HealthTimeoutSec = 120
)

<#
.SYNOPSIS
  Headless PowerShell supervisor for Aurrelia / Seraphina miner.
.DESCRIPTION
  Avoids Electron or bulky packaging. Provides:
    - Environment preparation
    - Optional REAL_MINING enforcement
    - Crash auto‑restart with backoff
    - Log rotation + timestamped session logs
    - Basic health watchdog (looks for job / share lines)
.PARAMETER Coin
  btc (default) or ltc (matches AUR_COIN)
.PARAMETER User / Worker / Password
  F2Pool account worker tuple. If not supplied, reads env.
.PARAMETER EnforceReal
  Sets REAL_MINING_ENFORCED=1 for hard guard.
.PARAMETER MaxRestarts
  Limit restart attempts (0 = unlimited).
.PARAMETER Tail
  Stream log output to console while writing file.
.PARAMETER HealthTimeoutSec
  If no new job/share line within this window, process restarted.
#>

function Write-Info($msg){ $ts = (Get-Date).ToString('HH:mm:ss'); Write-Host "[$ts] $msg" }
function Write-Warn($msg){ $ts = (Get-Date).ToString('HH:mm:ss'); Write-Host "[$ts] WARN  $msg" -ForegroundColor Yellow }
function Write-Err($msg){ $ts = (Get-Date).ToString('HH:mm:ss'); Write-Host "[$ts] ERROR $msg" -ForegroundColor Red }

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Err "Node.js not in PATH"; exit 1 }

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

# Resolve worker naming
if (-not $User) { Write-Err "F2POOL_USER not provided"; exit 1 }
if (-not $Worker) { $Worker = '001' }
$env:F2POOL_USER = $User
$env:F2POOL_WORKER = $Worker
if ($Password) { $env:F2POOL_PASSWORD = $Password }
$env:AUR_COIN = $Coin.ToLower()
if ($EnforceReal) { $env:REAL_MINING_ENFORCED = '1' }

# Optional performance / metrics defaults (safe conservative)
$env:METRICS = '1'
$env:METRICS_INTERVAL = '8000'

# Health tracking
$global:LastPulse = Get-Date

# Simple tailing if requested
function Start-Miner {
    param([string]$SessionLog)
    $argsList = @('aurrelia-pico-mesh-miner.js')
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = 'node'
    $startInfo.Arguments = ($argsList -join ' ')
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $startInfo
    $null = $proc.Start()

    $stdOut = [System.IO.StreamWriter]::new((New-Object System.IO.FileStream($SessionLog, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite)))
    $append = {
        param($data)
        if ($null -ne $data -and $data.Length -gt 0) {
            $line = $data.TrimEnd("`r","`n")
            $stdOut.WriteLine($line)
            $stdOut.Flush()
            if ($Tail) { Write-Host $line }
            if ($line -match 'Stratum] New job id=' -or $line -match 'Share accepted') { $global:LastPulse = Get-Date }
        }
    }
    Register-ObjectEvent -InputObject $proc -EventName OutputDataReceived -Action { $Event.MessageData.Invoke($EventArgs.Data) } -MessageData $append | Out-Null
    Register-ObjectEvent -InputObject $proc -EventName ErrorDataReceived -Action { $Event.MessageData.Invoke($EventArgs.Data) } -MessageData $append | Out-Null
    $proc.BeginOutputReadLine(); $proc.BeginErrorReadLine()
    return $proc
}

$restartCount = 0
$backoff = 2
Write-Info "Starting Aurrelia miner: coin=$Coin worker=$User.$Worker real=$([bool]$EnforceReal)"

while ($true) {
    $sessionStamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
    $sessionLog = Join-Path $LogDir "miner-${Coin}-${sessionStamp}.log"
    Write-Info "Log => $sessionLog"
    $proc = Start-Miner -SessionLog $sessionLog
    $global:LastPulse = Get-Date

    while (-not $proc.HasExited) {
        Start-Sleep -Seconds 5
        $since = (Get-Date) - $global:LastPulse
        if ($since.TotalSeconds -ge $HealthTimeoutSec) {
            Write-Warn "No job/share pulse for $([int]$since.TotalSeconds)s (threshold $HealthTimeoutSec) – restarting miner"
            try { $proc.Kill() } catch {}
            break
        }
    }

    if ($proc.ExitCode -ne 0) { Write-Warn "Miner exited code $($proc.ExitCode)" } else { Write-Warn "Miner exited normally" }
    $restartCount++
    if ($MaxRestarts -gt 0 -and $restartCount -gt $MaxRestarts) { Write-Err "MaxRestarts reached ($MaxRestarts). Halting."; break }
    Write-Info "Restart #$restartCount in ${backoff}s (Ctrl+C to abort)"
    Start-Sleep -Seconds $backoff
    if ($backoff -lt 30) { $backoff = [Math]::Min(30, [Math]::Round($backoff * 1.5)) }
}
