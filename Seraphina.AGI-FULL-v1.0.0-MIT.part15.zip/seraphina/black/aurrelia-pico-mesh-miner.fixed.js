// Archived fixed variant (deterministic patched) - not active in production.
module.exports = require('../aurrelia-pico-mesh-miner.fixed.js');
