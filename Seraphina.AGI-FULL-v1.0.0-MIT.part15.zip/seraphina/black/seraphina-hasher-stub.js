// Archived hasher stub (simulation). Disabled under REAL_STRICT.
module.exports = require('../seraphina-hasher-stub.js');
