// Archived legacy seraphina-REAL-mining.js (purged). Not used in production.
module.exports = { deprecated:true };
