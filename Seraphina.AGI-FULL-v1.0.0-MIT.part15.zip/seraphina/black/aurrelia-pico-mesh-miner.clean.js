// Archived clean variant (deterministic patched) - not active in production.
module.exports = require('../aurrelia-pico-mesh-miner.clean.js');
