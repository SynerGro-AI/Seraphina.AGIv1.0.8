// test-seraphina-model.js
// Verifies deterministic feature extraction + inference stability for Seraphina model.
'use strict';
const assert = require('assert');
const fs = require('fs');
const { extractFeatures } = require('./seraphina-model-features.js');
const { infer } = require('./seraphina-model-infer.js');

function mockEntry(){
  return {
    personality: { openness:0.51, stability:0.62, strategic_depth:0.57, ethical_alignment:0.6, imagination_intensity:0.59 },
    econSignals: { frenRevenueNorm:0.44, incomeSpread:0.18, acceptRatio:0.73 },
    dialogs: [
      { text:'We should explore optimize and balance profit with ethical strategy.' },
      { text:'Imagine ways to adapt and grow with empathy and stability.' }
    ],
    decisions: new Array(22).fill(0).map((_,i)=>({ id:i, kind:'advisory' }))
  };
}

function run(){
  const entry = mockEntry();
  const a = extractFeatures(entry); const b = extractFeatures(JSON.parse(JSON.stringify(entry)));
  assert.deepStrictEqual(a.vector, b.vector, 'Feature vectors must match for identical input');
  assert(a.manifest.vocabMerkle && typeof a.manifest.vocabMerkle === 'string', 'vocabMerkle present');
  assert.strictEqual(a.manifest.vocabMerkle, b.manifest.vocabMerkle, 'vocabMerkle deterministic');
  assert.strictEqual(a.manifest.hash, b.manifest.hash, 'manifest hash deterministic');
  // Range checks
  a.vector.forEach((v,i)=>{ assert(Number.isFinite(v), 'Feature not finite index '+i); });
  // If weights exist, inference is deterministic
  if (fs.existsSync(process.env.SERAPHINA_MODEL_WEIGHTS || 'seraphina-model-weights.json')){
    const r1 = infer(entry);
    const r2 = infer(entry);
    assert.strictEqual(r1.score, r2.score, 'Inference score must be deterministic');
    assert.strictEqual(r1.action, r2.action, 'Inference action must be deterministic');
  } else {
    console.log('[SeraphinaModelTest] Skipped inference (no weights file present)');
  }
  console.log('[SeraphinaModelTest] PASS dims='+a.vector.length+' actionCheck='+(fs.existsSync('seraphina-model-weights.json')?'yes':'no'));
}

if (require.main === module){ run(); }

module.exports = run;