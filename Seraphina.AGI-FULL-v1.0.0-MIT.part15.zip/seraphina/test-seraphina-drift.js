// test-seraphina-drift.js
'use strict';
const assert = require('assert');
const { DriftSentinel } = require('./seraphina-model-drift-sentinel.js');

function run(){
  const d = new DriftSentinel({ window:20, baselineWindow:40 });
  // Feed consistent pattern then sudden shift
  for(let i=0;i<30;i++){ d.record(i%2===0? 'suggest_expand':'suggest_conserve'); }
  const snap1 = d.snapshot();
  assert(snap1.kl >= 0, 'kl non-negative');
  // Introduce new action dominating
  for(let i=0;i<20;i++){ d.record('noop'); }
  const snap2 = d.snapshot();
  assert(snap2.kl >= snap1.kl, 'KL should not decrease after distribution shift (heuristic)');
  console.log('[TestDrift] PASS', { kl1: snap1.kl.toFixed(4), kl2: snap2.kl.toFixed(4) });
}

if(require.main===module){ run(); }

module.exports = { run };
