import math
import hypercube_lattice_v3 as hl


def test_bcd_encode():
    i, f = hl.bcd_encode(42.7)
    assert i == 0x42 and f == 7
    i2, f2 = hl.bcd_encode(0.0)
    assert i2 == 0x00 and f2 == 0
    i3, f3 = hl.bcd_encode(99.9)
    assert i3 == 0x99 and f3 == 9


def test_crc_consistency():
    int_bcd, frac_bcd = hl.bcd_encode(42.7)
    full_word, word_base, crc_val = hl.pack_word(3, int_bcd, frac_bcd, 0, 2, True)
    assert hl.compute_crc4(word_base) == crc_val
    assert full_word.bit_length() <= hl.FULL_WORD_BITS


def test_program_tube_fields():
    r = hl.program_tube(3, 42.7, 0, 2)
    assert r['crc_ok'] is True
    assert r['bit_length'] == hl.FULL_WORD_BITS
    assert r['color'] == 'B'
    assert abs(r['conductance'] - (hl.BASE_CONDUCTANCE + (42.7/100)*hl.CONDUCTANCE_RANGE)) < 1e-9


def test_batch_program_count():
    batch = hl.batch_program()
    assert len(batch) == hl.NUM_TUBES
    # All CRC OK
    assert all(t['crc_ok'] for t in batch)

def test_serialize_word():
    rec = hl.program_tube(3, 42.7, 0, 2)
    ser = hl.serialize_word(rec)
    assert ser['tube']['layer'] == 0 and ser['tube']['point'] == 2
    assert ser['color'] == 'B'
    assert ser['hex'].startswith('0x')

def test_program_sequence():
    seq = [
        {'color':1,'shade':10.0,'layer':0,'point':0},
        {'color':2,'shade':11.5,'layer':0,'point':1},
        {'color':3,'shade':12.3,'layer':0,'point':2},
    ]
    out = hl.program_sequence(seq)
    assert len(out) == 3
    assert out[0]['color'] == 'R' and out[1]['color'] == 'G' and out[2]['color'] == 'B'

def test_sonic_bubble_no_capture():
    nodes, amps, drift, ok = hl.sonic_bubble(duration=0.5, capture_amps=False, drift_threshold=0.2)
    assert amps.size == 0
    assert nodes >= 0
    # Accept higher drift in short duration runs; ensure drift metric computed
    assert drift >= 0.0

def test_export_batch_csv(tmp_path=None):
    batch = hl.batch_program(lambda L,P,I: 10 + I*0.1)
    # Use a temp path if provided else fallback
    path = 'hypercube_batch_test.csv' if tmp_path is None else str(tmp_path / 'hypercube_batch_test.csv')
    hl.export_batch_csv(batch, path)
    # Basic validation: file exists and has lines
    import os
    assert os.path.exists(path)
    with open(path,'r') as f:
        lines = f.readlines()
    assert len(lines) == len(batch) + 1  # header + rows


def test_motion_reasonable():
    spin, v, pos = hl.gradient_motion(duration=2.0)
    assert spin > 0 and v > 0 and pos > 0
    # Rough upper bound sanity
    assert pos < 10.0

if __name__ == '__main__':
    test_bcd_encode(); print('bcd ok')
    test_crc_consistency(); print('crc ok')
    test_program_tube_fields(); print('program ok')
    test_batch_program_count(); print('batch ok')
    test_serialize_word(); print('serialize ok')
    test_program_sequence(); print('sequence ok')
    test_sonic_bubble_no_capture(); print('sonic no-capture ok')
    test_export_batch_csv(); print('csv export ok')
    test_motion_reasonable(); print('motion ok')
    print('All tests passed.')
