#!/usr/bin/env bash
set -euo pipefail

echo "[uninstall] Seraphina miner uninstall starting"
if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo)." >&2
  exit 1
fi

SYSTEMD_UNITS=(seraphina-miner.service seraphina-security.service seraphina-security.timer)
for u in "${SYSTEMD_UNITS[@]}"; do
  if systemctl list-unit-files | grep -q "^$u"; then
    echo "[uninstall] Disabling $u"
    systemctl disable --now "$u" || true
    rm -f "/etc/systemd/system/$u"
  fi
done

echo "[uninstall] Removing AppArmor profiles if present"
for p in seraphina-miner seraphina-security; do
  if [[ -f "/etc/apparmor.d/$p" ]]; then
    apparmor_parser -R "/etc/apparmor.d/$p" || true
    rm -f "/etc/apparmor.d/$p"
  fi
done

echo "[uninstall] Removing installation directory /opt/seraphina/mining"
rm -rf /opt/seraphina/mining || echo "[uninstall] WARN failed to remove directory"

echo "[uninstall] Daemon reload"
systemctl daemon-reload || true

echo "[uninstall] Completed"