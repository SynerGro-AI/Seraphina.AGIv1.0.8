# Seraphina Mining Pool Auto-Setup Script
#
# This script sets up all required environment variables for mining pool software
# (BTC and RVN) using your real wallet addresses and identity, then launches
# both the Node.js and EXE mining cores for full automation.
#
# Usage: Right-click and run with PowerShell, or run in a PowerShell terminal.

# --- User Identity ---
$env:MINER_USERNAME = "donumdei888"

# --- BTC Mining ---
$env:BTC_MINING_ADDRESS = "1QF4sh6yqZ4ZgAbTnGXRt1WwCXiVtBFddz"
$env:BTC_KRAKEN_ADDRESS = "34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf"

# --- RVN Mining ---
$env:RVN_LOCAL_ADDRESS = "RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7"

# --- Launch Mining Cores ---
Write-Host "[Seraphina] Setting up mining environment for DonumDie..." -ForegroundColor Cyan
Write-Host "[Seraphina] BTC Mining Address: $env:BTC_MINING_ADDRESS" -ForegroundColor Yellow
Write-Host "[Seraphina] RVN Local Address: $env:RVN_LOCAL_ADDRESS" -ForegroundColor Yellow
Write-Host "[Seraphina] Username: $env:MINER_USERNAME" -ForegroundColor Yellow

# Launch Node.js mining core (background)
Start-Process -NoNewWindow -FilePath "node" -ArgumentList "seraphina-REAL-mining.js" -WorkingDirectory $PSScriptRoot

# Launch EXE mining core (background, if present)
$exePath = Join-Path $PSScriptRoot "seraphina-REAL-mining.exe"
if (Test-Path $exePath) {
    Start-Process -NoNewWindow -FilePath $exePath -WorkingDirectory $PSScriptRoot
    Write-Host "[Seraphina] EXE mining core launched." -ForegroundColor Green
} else {
    Write-Host "[Seraphina] EXE mining core not found, skipping..." -ForegroundColor DarkYellow
}

Write-Host "[Seraphina] All mining pool environment variables set. Mining cores launched." -ForegroundColor Green
