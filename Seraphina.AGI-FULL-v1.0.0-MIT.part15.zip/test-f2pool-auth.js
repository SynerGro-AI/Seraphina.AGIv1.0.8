const createStratumClient = require('stratum-client');
const client = createStratumClient({
  server: 'btc.f2pool.com',
  port: 1314,
  worker: 'donumdei888.001',
  password: '21235365876986800',
  onAuthorizeSuccess: () => console.log('Worker authorized!'),
  onAuthorizeFail: () => console.log('Authorization failed!'),
  onError: (err) => console.log('Error:', err),
  onConnect: () => console.log('Connected!'),
});