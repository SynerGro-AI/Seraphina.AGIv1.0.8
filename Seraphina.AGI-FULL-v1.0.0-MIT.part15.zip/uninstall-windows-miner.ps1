Param(
  [string]$TargetRoot = "$Env:ProgramFiles/SeraphinaMiner",
  [switch]$Force
)
$ErrorActionPreference = 'Continue'
Write-Host "[Seraphina-Uninstaller] Starting uninstall..." -ForegroundColor Cyan

$taskName = 'SeraphinaMinerAuto'
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
  Write-Host "Removing scheduled task $taskName" -ForegroundColor Yellow
  Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
} else { Write-Host "Scheduled task not found." -ForegroundColor DarkGray }

if (Test-Path $TargetRoot) {
  if ($Force) {
    Write-Host "Removing target root $TargetRoot" -ForegroundColor Yellow
    Remove-Item -Recurse -Force $TargetRoot
  } else {
    Write-Warning "Use -Force to actually delete $TargetRoot";
  }
} else { Write-Host "Target root not found." -ForegroundColor DarkGray }

# Remove desktop shortcut
$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Seraphina Miner.lnk'
if (Test-Path $shortcutPath) { Remove-Item $shortcutPath -Force; Write-Host "Removed desktop shortcut." -ForegroundColor Yellow }

Write-Host "Uninstall complete." -ForegroundColor Green
