// test-cache-integrity-scan.js
'use strict';
const assert = require('assert');
const api = require('./seraphina-api.js');

(function run(){
  // Warm cache with a few simulations (use minimal opts expected by runSimulation)
  for(let i=0;i<5;i++){
    api.virtueSim.runSimulation({ n: 50 + i, targetJusticeFairnessCorr: 0.1 * i });
  }
  const beforeScan = api.meta.scanSimulationCacheIntegrity();
  assert(beforeScan.ok && beforeScan.scanned >= 5,'Pre-corruption scan size unexpected');
  assert(beforeScan.mismatches === 0,'Expect zero mismatches before corruption');

  // Corrupt first entry
  const corruptRes = api.meta.__test_corruptFirstCacheEntry();
  assert(corruptRes.ok,'Failed to corrupt cache entry');

  const afterScan = api.meta.scanSimulationCacheIntegrity();
  assert(afterScan.ok && afterScan.mismatches >= 1,'Expected mismatches after corruption');

  console.log('[TestCacheIntegrityScan] before:', beforeScan, 'after:', afterScan);
})();
