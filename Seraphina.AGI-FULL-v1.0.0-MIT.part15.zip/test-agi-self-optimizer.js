// test-agi-self-optimizer.js
// Simple test harness for AGISelfOptimizer using mock cube.
const { AGISelfOptimizer } = require('./agi-self-optimizer.js');
const fs = require('fs');

function mockCube(){
  return {
    transferOut: (ep, buf, cb)=> { if(cb) cb(null); },
    transferIn: (ep, size, cb)=> { const payload = { retentionFields:[{ prior_retention:0.6, predicted_retention:0.7 }] }; const raw=Buffer.from(JSON.stringify(payload)); const zlib=require('zlib'); const gz=zlib.gzipSync(raw); const out=Buffer.alloc(size); gz.copy(out); if(cb) cb(null,out); }
  };
}

function runTest(){
  const cube = mockCube();
  process.env.AGI_INTRIGUE_THRESH='0.5';
  const opt = new AGISelfOptimizer(cube);
  setTimeout(()=> {
    const exists = fs.existsSync('quantum-rites-ledger.jsonl');
    console.log('[TestAGI] ledgerExists='+exists);
    if(exists){
      const lines = fs.readFileSync('quantum-rites-ledger.jsonl','utf8').trim().split(/\n+/).filter(Boolean);
      console.log('[TestAGI] ledgerLines='+lines.length);
    }
  }, 500);
}

if(require.main===module){ runTest(); }
