'use strict';
// test-cache-persistence.js
// Ensures enabling persistence writes metrics-only cache file and survives reload.
const fs = require('fs');
const path = require('path');
const api = require('./seraphina-api');

function run(){
  const tempPath = path.join(__dirname,'__test_sim_cache.json');
  process.env.SERAPHINA_SIM_CACHE_PATH = tempPath; // override path
  if(fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
  // Ensure persistence disabled then enable
  api.meta.toggleCachePersistence(false, tempPath);
  // Generate multiple simulations before enabling persistence
  for(let i=0;i<3;i++){ const r = api.virtueSim.runSimulation({ n:600+i, seed:'persist-pre-'+i }); if(!r.ok) throw new Error('Pre persistence simulation failed '+i); }
  const preSize = api.meta.getCacheStats().size;
  if(preSize < 3) throw new Error('Expected at least 3 cache entries pre-persistence');
  // Enable persistence (should save existing entries)
  const tgl = api.meta.toggleCachePersistence(true, tempPath);
  if(!tgl.ok || !tgl.persistence) throw new Error('Failed to enable persistence');
  const simPost = api.virtueSim.runSimulation({ n:650, seed:'persist-post' });
  if(!simPost.ok) throw new Error('Post persistence simulation failed');
  // Expect cache file to exist
  if(!fs.existsSync(tempPath)) throw new Error('Cache file not written');
  const sizeBefore = api.meta.getCacheStats().size;
  // Clear in-memory map then reload via enabling persistence again
  api.meta.clearCache();
  const tgl2 = api.meta.toggleCachePersistence(true, tempPath); // should reload with override
  const sizeAfter = api.meta.getCacheStats().size;
  if(sizeAfter === 0) throw new Error('Reload did not repopulate cache metrics');
  // Verify file does not contain marker
  const fileContent = fs.readFileSync(tempPath,'utf8');
  if(fileContent.includes('__marker__')) throw new Error('Marker should not persist in file');
  console.log('Cache persistence test passed. preSize', preSize, 'sizeBeforeSave', sizeBefore, 'sizeAfterReload', sizeAfter);
}

if(require.main === module){
  try { run(); } catch(e){ console.error('Persistence test failed:', e.message); process.exit(1); }
}
module.exports = { run };
