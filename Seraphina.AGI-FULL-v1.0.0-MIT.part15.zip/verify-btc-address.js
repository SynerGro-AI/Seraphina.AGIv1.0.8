// Simple offline Bitcoin Base58Check address validator
// Usage: node verify-btc-address.js [address]
// Defaults to the address from your config if none passed.

const crypto = require('crypto');

const ADDRESS = process.argv[2] || '34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf';
const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const MAP = new Map(ALPHABET.split('').map((c,i)=>[c,i]));

function base58Decode(str){
  let num = 0n;
  for (const ch of str){
    const val = MAP.get(ch);
    if (val == null) throw new Error('Invalid Base58 char: '+ch);
    num = num * 58n + BigInt(val);
  }
  // Convert to bytes
  let hex = num.toString(16);
  if (hex.length % 2) hex = '0'+hex;
  let buf = Buffer.from(hex, 'hex');
  // Add leading zero bytes for each leading '1'
  let leading = 0; for (const ch of str){ if (ch === '1') leading++; else break; }
  if (leading) buf = Buffer.concat([Buffer.alloc(leading), buf]);
  return buf;
}

function validate(addr){
  try {
    const decoded = base58Decode(addr);
    if (decoded.length !== 25) return { ok:false, reason:'Decoded length != 25', decodedLength: decoded.length };
    const version = decoded[0];
    const payload = decoded.slice(0,21);
    const checksum = decoded.slice(21);
    const hash = crypto.createHash('sha256').update(payload).digest();
    const hash2 = crypto.createHash('sha256').update(hash).digest();
    const expected = hash2.slice(0,4);
    const match = expected.equals(checksum);
    return {
      ok: match,
      version,
      type: version === 0x00 ? 'P2PKH/Legacy' : (version === 0x05 ? 'P2SH (multi-sig or nested SegWit)' : 'Unknown/Other'),
      checksumValid: match,
      checksumHex: checksum.toString('hex'),
      expectedHex: expected.toString('hex'),
      payloadHex: payload.slice(1).toString('hex')
    };
  } catch(e){
    return { ok:false, error:e.message };
  }
}

const result = validate(ADDRESS);
console.log(JSON.stringify({ address: ADDRESS, result }, null, 2));
