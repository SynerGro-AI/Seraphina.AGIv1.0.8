const assert = require('assert');
const api = require('./seraphina-api.js');

// Basic rate limiter behavior test
(async function(){
  // Configure small capacity for quick depletion
  api.meta.configureAgentRateLimiter({ capacity: 3, refillIntervalMs: 50 });
  const cfg = api.meta.getAgentRateLimiterConfig();
  assert(cfg.ok && !cfg.disabled && cfg.capacity === 3, 'Rate limiter config failed');

  let blockedCount = 0;
  // Invoke more times than capacity
  for(let i=0;i<5;i++){
    const resp = await api.agent.invoke('burrowAdapt', 'test suggestion', { n:i });
    if(resp && resp.blocked && resp.code === 'RATE_LIMIT') blockedCount++;
  }
  assert(blockedCount >= 1, 'Expected at least one rate limit block');

  // Wait for refill
  await new Promise(r=> setTimeout(r, 60));
  const resp2 = await api.agent.invoke('burrowAdapt', 'post-refill', {});
  assert(!resp2.blocked, 'Invocation should succeed after refill');

  const stats = api.meta.getAgentStats();
  assert(stats.invocations >= 6, 'Stats invocations count mismatch');
  const limiterCfg = api.meta.getAgentRateLimiterConfig();
  assert(limiterCfg.tokens <= limiterCfg.capacity, 'Limiter tokens exceed capacity');

  console.log('[test-agent-rate-limiter] PASS');
})();
