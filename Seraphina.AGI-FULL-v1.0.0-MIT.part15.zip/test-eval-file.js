// test-eval-file.js
'use strict';
const fs = require('fs');
const { spawnSync } = require('child_process');

function runOnce(){
  const r = spawnSync(process.execPath, ['seraphina-model-train.js'], { env:{...process.env, SERAPHINA_VECTORIZE:'0'}, encoding:'utf8' });
  return r;
}

function main(){
  const r = runOnce();
  if(r.status !== 0){ console.error('Train script non-zero exit', r.status); process.exit(1); }
  if(!fs.existsSync('seraphina-eval-last.json')){ console.error('Eval file missing'); process.exit(1); }
  const data = JSON.parse(fs.readFileSync('seraphina-eval-last.json','utf8'));
  const required = ['acc','accEthical','lossA','lossB','avgProbA','avgProbB'];
  for(const k of required){ if(!(k in data)){ console.error('Missing key', k); process.exit(1); } }
  if(typeof data.acc !== 'number' || data.acc < 0 || data.acc > 1){ console.error('Invalid acc value'); process.exit(1); }
  console.log('[EvalFileTest] OK', JSON.stringify(data));
}
main();
