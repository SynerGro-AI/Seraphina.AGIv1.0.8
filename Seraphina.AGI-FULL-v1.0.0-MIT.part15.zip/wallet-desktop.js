#!/usr/bin/env node
// Lightweight local desktop wallet interface (Express + static HTML) focusing on viewing balances & recent ledger entries.
const fs = require('fs');
const path = require('path');
const express = (()=>{ try { return require('express'); } catch(e){ console.error('[WalletDesktop] express not installed. Run: npm install express'); process.exit(1);} })();
const app = express();
const PORT = process.env.WALLET_DESKTOP_PORT || 8123;

function readLedger(file, limit=50){
  if(!fs.existsSync(file)) return [];
  const lines = fs.readFileSync(file,'utf8').trim().split(/\n/).filter(Boolean);
  return lines.slice(-limit).map(l=>{ try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
}

function loadWalletAddresses(){
  const envCandidates = ['BTC_MINING_ADDRESS','LTC_KRAKEN_ADDRESS','BTC_KRAKEN_ADDRESS','RVN_LOCAL_ADDRESS'];
  const out={}; for(const k of envCandidates){ if(process.env[k]) out[k]=process.env[k]; }
  return out;
}

app.get('/api/ledger/:name', (req,res)=>{
  const name = req.params.name;
  const allowed = ['share-ledger.jsonl','swap-ledger.jsonl','parity-ledger.jsonl','econ-realization-ledger.jsonl','price-ledger.jsonl','governance-ledger.jsonl'];
  if(!allowed.includes(name)) return res.status(400).json({ error:'ledger_not_allowed' });
  return res.json({ ledger: name, entries: readLedger(name) });
});

app.get('/api/wallet', (req,res)=>{
  res.json({ addresses: loadWalletAddresses(), ts: Date.now() });
});

app.get('/', (_req,res)=>{
  res.type('html').send(`<!DOCTYPE html><html><head><title>Seraphina Wallet Desktop</title><style>body{font-family:Arial;margin:20px;} table{border-collapse:collapse;} td,th{border:1px solid #ccc;padding:4px;} code{background:#f5f5f5;padding:2px 4px;} .hash{font-size:10px;color:#555;} </style></head><body>
  <h1>Seraphina Wallet Desktop</h1>
  <section id="wallet"></section>
  <h2>Ledgers</h2>
  <div id="ledgers"></div>
  <script>
  async function loadWallet(){ const r=await fetch('/api/wallet'); const j=await r.json(); const el=document.getElementById('wallet'); el.innerHTML='<h2>Addresses</h2><ul>'+Object.entries(j.addresses).map(([k,v])=>'<li><b>'+k+':</b> '+v+'</li>').join('')+'</ul>'; }
  async function loadLedger(name){ const r=await fetch('/api/ledger/'+name); const j=await r.json(); return '<h3>'+name+'</h3><table><tr><th>ts</th><th>type</th><th>data</th><th>hash</th></tr>'+j.entries.map(e=>'<tr><td>'+e.ts+'</td><td>'+(e.type||e.event||e.coin||'')+'</td><td><code>'+JSON.stringify(e).slice(0,120).replace(/</g,'&lt;')+'</code></td><td class="hash">'+(e.chain_hash||'')+'</td></tr>').join('')+'</table>'; }
  async function render(){ await loadWallet(); const names=['share-ledger.jsonl','swap-ledger.jsonl','parity-ledger.jsonl','econ-realization-ledger.jsonl','price-ledger.jsonl','governance-ledger.jsonl']; const out=[]; for(const n of names){ out.push(await loadLedger(n)); } document.getElementById('ledgers').innerHTML=out.join(''); }
  render(); setInterval(render, 60000);
  </script>
  </body></html>`);
});

app.listen(PORT, ()=>{ console.log('[WalletDesktop] listening on', PORT); });
