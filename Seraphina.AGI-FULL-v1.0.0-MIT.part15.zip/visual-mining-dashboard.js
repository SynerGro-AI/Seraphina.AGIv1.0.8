// REAL_ONLY_NEUTRALIZED: visual-mining-dashboard.js
'use strict';
module.exports = new Proxy({}, { get(){ throw new Error('visual dashboard removed (no simulation UIs)'); } });