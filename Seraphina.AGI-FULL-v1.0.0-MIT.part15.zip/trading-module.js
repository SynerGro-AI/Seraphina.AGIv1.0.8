// trading-module.js: Low/No-Fee Swaps for Max Profit (MEXC + 1inch Fallback)
'use strict';
/*
  NOTE: This is an initial scaffold. Live trading requires enabling external
  network calls, robust error handling, nonce + rate limit management, and
  proper key security. Dry run mode (TRADING_DRY_RUN=1) avoids order placement.
*/

let ccxt, CoinGecko, fetch;
try { ccxt = require('ccxt'); } catch { ccxt = null; }
try { CoinGecko = require('coingecko-api'); } catch { CoinGecko = null; }
try { fetch = require('node-fetch'); } catch { fetch = (...a)=>Promise.reject(new Error('node-fetch missing')); }

const CG = CoinGecko ? new CoinGecko() : null;
let lastTradeTs = 0;
const momentumWindow = 12; // last 12 price points (~12 minutes if 1m refresh)
const MIN_TRADE_INTERVAL = 300000; // 5 min

class LowFeeTrader {
  constructor(pipeline){
    this.pipeline = pipeline;
    this.dryRun = process.env.TRADING_DRY_RUN === '1';
    this.feeMaxPct = parseFloat(process.env.MAX_SWAP_FEE_PCT || '0.3');
    this.profitBufferPct = parseFloat(process.env.PROFIT_BUFFER_PCT || '1.0');
    this.minBalance = parseFloat(process.env.MIN_SWAP_BALANCE || '100');
    this.swapTargets = (process.env.SWAP_TARGETS || 'usdt,btc').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
    this.exchanges = {}; // multi-ex support
    this.primary = null;
    this.priceCache = {};
    this.momentum = [];
    this.onChainBalances = { rvn:0, fren:0 };
    this._backoffMs = 0;
    this._initExchanges();
    this._initPriceLoop();
    this._initChainBalanceLoop();
  }
  _initExchanges(){
    if (!ccxt){ console.warn('[Trading] ccxt not installed – install with: npm i ccxt'); return; }
    const list = (process.env.EXCHANGES || 'mexc').split(/[\s,]+/).filter(Boolean);
    for (const ex of list){
      const keyVar = ex.toUpperCase()+"_API_KEY"; const secVar = ex.toUpperCase()+"_SECRET";
      const apiKey = process.env[keyVar]; const secret = process.env[secVar];
      try {
        if (!ccxt[ex]){ console.warn('[Trading] Exchange not in ccxt:', ex); continue; }
        const inst = new ccxt[ex]({ apiKey, secret, enableRateLimit: true });
        if (this.dryRun && inst.setSandboxMode) inst.setSandboxMode(true);
        this.exchanges[ex] = inst;
        if (!this.primary) this.primary = inst;
        console.log('[Trading] Init exchange', ex, 'dryRun='+this.dryRun,'auth='+(apiKey&&secret? 'yes':'no'));
      } catch(e){ console.warn('[Trading] Init fail', ex, e.message); }
    }
    if (!this.primary) console.warn('[Trading] No exchanges initialized (read-only).');
  }
  _initPriceLoop(){
    if (!CG){ console.warn('[Trading] CoinGecko client not installed (npm i coingecko-api)'); return; }
    const refreshMs = parseInt(process.env.PRICE_REFRESH_MS || '60000',10);
    const loop = async ()=>{
      try {
        // CoinGecko id mapping; ensure FREN uses distinct 'frencoin' (was incorrectly ravencoin)
        const idsMap = { rvn:'ravencoin', fren:'frencoin', btc:'bitcoin', usdt:'tether', ltc:'litecoin', kas:'kaspa' };
        const coins = Array.from(new Set([this.pipeline.selectedCoin, ...this.swapTargets])).map(c=>idsMap[c]||'bitcoin');
        const data = await CG.simple.price({ ids: coins, vs_currencies: 'usd' });
        this.priceCache = data?.data || data || {};
        if (process.env.TRADING_PRICE_LOG==='1') console.log('[Trading][Prices]', JSON.stringify(this.priceCache));
        this._updateMomentum();
      } catch(e){ console.warn('[Trading][PricesErr]', e.message); }
      setTimeout(loop, refreshMs).unref();
    };
    loop();
  }
  _selectExchange(marketSymbol){
    // Basic selection: first exchange that lists market; could be enhanced with liquidity metrics.
    for (const name of Object.keys(this.exchanges)){
      const ex = this.exchanges[name];
      if (!ex || !ex.markets) continue;
      if (ex.markets[marketSymbol]) return ex;
    }
    return this.primary;
  }
  async _loadMarkets(){
    for (const name of Object.keys(this.exchanges)){
      try { await this.exchanges[name].loadMarkets(); } catch(e){ /* ignore */ }
    }
  }
  async fetchBalance(sym){
    if (!this.primary){ return 0; }
    try { const b = await this.primary.fetchBalance(); return b.free?.[sym.toUpperCase()] || 0; }
    catch(e){
      this._scheduleBackoff(e);
      console.warn('[Trading][BalErr]', e.message);
      return 0;
    }
  }
  async getQuote(from, to, amountUnits){
    // amountUnits in base asset units
    if (!this.primary){
      const priceFrom = this._priceUsd(from); const priceTo = this._priceUsd(to);
      if (!priceFrom || !priceTo) return null;
      const valueUsd = amountUnits * priceFrom; const feeEst = 0.002;
      return { toAmount: (valueUsd / priceTo) * (1 - feeEst), feeEst };
    }
    await this._loadMarkets();
    const marketSym = `${from.toUpperCase()}/${to.toUpperCase()}`;
    const ex = this._selectExchange(marketSym);
    if (!ex) return null;
    try {
      if (!ex.has['fetchOrderBook']) return null;
      const ob = await ex.fetchOrderBook(marketSym);
      const bid = ob?.bids?.[0]?.[0];
      if (!bid) return null;
      return { toAmount: amountUnits * bid, feeEst: 0, ex: ex.id };
    } catch(e){ this._scheduleBackoff(e); console.warn('[Trading][QuoteErr]', e.message); return null; }
  }
  _priceUsd(sym){
    const idsMap = { rvn:'ravencoin', fren:'frencoin', btc:'bitcoin', usdt:'tether', ltc:'litecoin', kas:'kaspa' };
    const key = idsMap[sym];
    if (!key) return 0;
    const rec = this.priceCache[key];
    if (!rec) return 0;
    return rec.usd || rec.USD || 0;
  }
  async executeSwap(from, to, reason){
    const now = Date.now();
    if (now - lastTradeTs < MIN_TRADE_INTERVAL) return { skipped: 'cooldown' };
    if (this._backoffMs && now - lastTradeTs < this._backoffMs) return { skipped: 'backoff' };
    const bal = await this.fetchBalance(from);
    if (bal < this.minBalance) return { skipped: 'low-balance', bal };
    const amount = bal * 0.9;
    const quote = await this.getQuote(from, to, amount);
    if (!quote) return { error: 'no-quote' };
    const feePct = (quote.feeEst||0) * 100;
    if (feePct > this.feeMaxPct) return { skipped: 'fee-high', feePct };
    const fromUsd = amount * this._priceUsd(from);
    const toUsd = quote.toAmount * this._priceUsd(to);
    const profitPct = ((toUsd / fromUsd)-1)*100;
    if (profitPct < this.profitBufferPct) return { skipped: 'low-profit', profitPct };
    if (this.dryRun || !this.primary){
      console.log('[Trading][DRY]', { from, to, amount, profitPct: profitPct.toFixed(3), reason, ex: quote.ex });
      return { dry:true, profitPct };
    }
    try {
      const market = `${from.toUpperCase()}/${to.toUpperCase()}`;
      const ex = this._selectExchange(market) || this.primary;
      const price = quote.toAmount / amount;
      let order;
      const params = {};
      if (process.env.USE_ADVANCED_ORDERS==='1'){
        // Attempt post-only maker to minimize fees if supported
        params.postOnly = true;
      }
      order = await ex.createOrder(market, 'limit', 'sell', amount, price, params);
      lastTradeTs = now;
      console.log('[Trading][EXEC]', { market, amount, price, profitPct: profitPct.toFixed(3), orderId: order.id, ex: ex.id, reason });
      this._backoffMs = 0; // reset on success
      return { success:true, orderId:order.id, profitPct };
    } catch(e){
      this._scheduleBackoff(e);
      console.error('[Trading][ExecErr]', e.message);
      return { error:e.message };
    }
  }
  async optimize(trigger='periodic'){
    const change = this._momentumBias();
    // Adjust profit buffer dynamically if configured
    if (process.env.MOMENTUM_ADAPT==='1'){
      if (change > 3) this.profitBufferPct = Math.max( this.profitBufferPct * 1.2, this.profitBufferPct + 0.5 );
      else if (change < -2) this.profitBufferPct = Math.max(0.2, this.profitBufferPct * 0.8);
    }
    let bestRes=null; let bestProfit=-Infinity;
    for (const tgt of this.swapTargets){
      const res = await this.executeSwap(this.pipeline.selectedCoin, tgt, `${trigger}-to-${tgt}`);
      if (res && res.profitPct != null && res.profitPct > bestProfit){ bestProfit = res.profitPct; bestRes = { tgt, ...res }; }
    }
    return bestRes || { skipped: 'no-trades' };
  }

  _momentumBias(){
    // Compute simple percentage momentum bias using stored price points
    if (this.momentum.length < 2) return 0;
    const diffs = [];
    for (let i=1;i<this.momentum.length;i++){ diffs.push(this.momentum[i]-this.momentum[i-1]); }
    const avg = diffs.reduce((a,b)=>a+b,0) / diffs.length;
    const base = this.momentum[this.momentum.length-1] || 1;
    return (avg / base) * 100;
  }

  _updateMomentum(){
    const p = this._priceUsd(this.pipeline.selectedCoin);
    if (p > 0){
      this.momentum.push(p);
      if (this.momentum.length > momentumWindow) this.momentum.shift();
    }
  }

  _scheduleBackoff(e){
    // Exponential backoff capped at 30 minutes
    if (!this._backoffMs) this._backoffMs = 60000; else this._backoffMs = Math.min(this._backoffMs * 2, 1800000);
    if (process.env.TRADING_BACKOFF_LOG==='1') console.warn('[Trading][Backoff]', this._backoffMs, e?.message);
  }
}

module.exports = { LowFeeTrader };
