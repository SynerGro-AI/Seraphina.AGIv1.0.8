#!/usr/bin/env node
// train-share-oracle.js
// Deterministic logistic regression trainer (manual gradient descent) for share acceptance.
'use strict';
const fs = require('fs');
const crypto = require('crypto');

function shaSeedInt(str){ return parseInt(crypto.createHash('sha256').update(str).digest('hex').slice(0,8),16); }
function sigmoid(x){ return 1/(1+Math.exp(-x)); }

function loadDataset(path='shares-dataset.json'){
  if(!fs.existsSync(path)) throw new Error('Dataset missing: '+path);
  return JSON.parse(fs.readFileSync(path,'utf8'));
}

function trainLogistic(X, y, opts={}){
  const lr = parseFloat(process.env.SHARE_ORACLE_LR || opts.lr || '0.05');
  const epochs = parseInt(process.env.SHARE_ORACLE_EPOCHS || opts.epochs || '300',10);
  const seed = shaSeedInt(process.env.SHARE_ORACLE_SEED || 'seraphina-oracle-2025');
  let w = [ (seed % 1000)/1000 - 0.5, ((seed>>4)%1000)/1000 -0.5, ((seed>>8)%1000)/1000 -0.5 ];
  let b = ((seed>>12)%1000)/1000 -0.5;
  for(let ep=0; ep<epochs; ep++){
    let gradW = [0,0,0]; let gradB = 0; let loss=0;
    for(let i=0;i<X.length;i++){
      const z = b + w[0]*X[i][0] + w[1]*X[i][1] + w[2]*X[i][2];
      const p = sigmoid(z);
      const yi = y[i];
      loss += -(yi*Math.log(p+1e-12) + (1-yi)*Math.log(1-p+1e-12));
      const dz = (p - yi);
      gradW[0] += dz*X[i][0]; gradW[1] += dz*X[i][1]; gradW[2] += dz*X[i][2]; gradB += dz;
    }
    const n = X.length;
    // Average
    gradW = gradW.map(g=> g/n); gradB /= n; loss /= n;
    // Update
    w = w.map((wi,i)=> wi - lr*gradW[i]); b -= lr*gradB;
    if(ep % 50 === 0){
      process.stdout.write(`[train] epoch ${ep} loss=${loss.toFixed(4)}\n`);
    }
  }
  return { w, b };
}

function evaluate(X, y, w, b){
  let correct=0; let probs=[]; let loss=0;
  for(let i=0;i<X.length;i++){
    const z = b + w[0]*X[i][0] + w[1]*X[i][1] + w[2]*X[i][2];
    const p = sigmoid(z); probs.push(p);
    const yi = y[i];
    loss += -(yi*Math.log(p+1e-12)+(1-yi)*Math.log(1-p+1e-12));
    const pred = p>=0.5?1:0; if(pred===yi) correct++;
  }
  loss /= X.length;
  return { accuracy: correct / X.length, loss };
}

function main(){
  const ds = loadDataset();
  const X_train = ds.train.X; const y_train = ds.train.y;
  if(!X_train.length) throw new Error('Empty training set');
  const { w, b } = trainLogistic(X_train, y_train);
  const evalTrain = evaluate(X_train, y_train, w, b);
  const evalVal = evaluate(ds.val.X, ds.val.y, w, b);
  const weights = { bias: b, w_freq: w[0], w_rate: w[1], w_diff: w[2], trainLoss: evalTrain.loss, trainAcc: evalTrain.accuracy, valLoss: evalVal.loss, valAcc: evalVal.accuracy };
  fs.writeFileSync('share-oracle-weights.json', JSON.stringify(weights,null,2));
  console.log(JSON.stringify({ ok:true, weights }, null, 2));
}

if(require.main === module){ main(); }

module.exports = { trainLogistic };
