'use strict';
// test-exporter-https.js
// Generates a temporary self-signed certificate and ensures exporter starts in HTTPS mode.
const fs = require('fs');
const path = require('path');
const https = require('https');
const selfsigned = require('selfsigned');
const api = require('./seraphina-api');

function makeSelfSigned(tmpDir){
  const attrs = [{ name:'commonName', value:'localhost' }];
  const pems = selfsigned.generate(attrs,{ days:1, keySize:2048 });
  const keyPath = path.join(tmpDir,'metrics-key.pem');
  const certPath = path.join(tmpDir,'metrics-cert.pem');
  fs.writeFileSync(keyPath, pems.private);
  fs.writeFileSync(certPath, pems.cert);
  return { keyPath, certPath };
}

function fetchMetricsHttps(port){
  return new Promise((resolve,reject)=>{
    const req = https.get({ rejectUnauthorized:false, host:'127.0.0.1', port, path:'/metrics' }, res=>{
      let data=''; res.on('data',d=> data+=d); res.on('end',()=> resolve({ status:res.statusCode, body:data }));
    });
    req.on('error',reject);
  });
}

async function run(){
  const tmpDir = fs.mkdtempSync(path.join(require('os').tmpdir(),'seraphina-https-'));
  const creds = makeSelfSigned(tmpDir);
  if(!creds){ throw new Error('Self-signed generation failed'); }
  // Run a simulation to populate metrics
  const sim = api.virtueSim.runSimulation({ n:550, seed:'https-test' });
  if(!sim.ok) throw new Error('Simulation failed');
  const info = api.exporters.startPrometheusExporter({ port: 9125, host:'127.0.0.1', https: creds });
  if(!info.ok) throw new Error('Exporter start failed');
  if(info.protocol !== 'https') throw new Error('Expected https protocol');
  const met = await fetchMetricsHttps(info.port);
  if(met.status !== 200) throw new Error('HTTPS metrics fetch failed');
  if(!met.body.includes('seraphina_exporter_protocol')) throw new Error('Protocol metric missing');
  console.log('HTTPS exporter test passed.');
  api.meta.stopExporter();
}

if(require.main === module){ run().catch(e=>{ console.error('HTTPS exporter test failed:', e.message); process.exit(1); }); }
module.exports = { run };
