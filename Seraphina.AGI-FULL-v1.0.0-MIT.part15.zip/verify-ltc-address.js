// verify-ltc-address.js
// Offline Litecoin address validator (Base58 P2PKH/P2SH + bech32 ltc1)
// Usage: node verify-ltc-address.js <address>

const crypto = require('crypto');
const bech32Chars = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const b58Map = new Map(base58Alphabet.split('').map((c,i)=>[c,i]));
const input = process.argv[2] || process.env.LTC_KRAKEN_ADDRESS || 'LfUXR4jEFBddB33g7fKX9kAj7eKid23LdA';

function decodeBase58(str){
  let num = 0n;
  for(const ch of str){
    const v = b58Map.get(ch); if(v==null) throw new Error('Bad Base58 char '+ch);
    num = num*58n + BigInt(v);
  }
  let hex = num.toString(16);
  if(hex.length % 2) hex = '0'+hex;
  let buf = Buffer.from(hex,'hex');
  let leading = 0; for(const ch of str){ if(ch==='1') leading++; else break; }
  if(leading) buf = Buffer.concat([Buffer.alloc(leading), buf]);
  return buf;
}
function validateBase58(addr){
  const decoded = decodeBase58(addr);
  if(decoded.length !== 25) return { ok:false, reason:'length '+decoded.length };
  const version = decoded[0];
  const body = decoded.slice(0,21);
  const checksum = decoded.slice(21);
  const h1 = crypto.createHash('sha256').update(body).digest();
  const h2 = crypto.createHash('sha256').update(h1).digest();
  const expected = h2.slice(0,4);
  const ok = expected.equals(checksum);
  return {
    ok,
    type: version === 0x30 ? 'P2PKH (L...)' : (version === 0x32 ? 'P2SH (M...)' : 'Unknown version'),
    version,
    checksumValid: ok,
    checksumHex: checksum.toString('hex'),
    expectedHex: expected.toString('hex')
  };
}
// Bech32 (ltc1...) based on BIP-0173
function bech32Polymod(values){
  const GEN = [0x3b6a57b2,0x26508e6d,0x1ea119fa,0x3d4233dd,0x2a1462b3];
  let chk = 1;
  for(const v of values){
    const b = (chk >> 25) & 0xff;
    chk = ((chk & 0x1ffffff) << 5) ^ v;
    for(let i=0;i<5;i++) if((b>>i)&1) chk ^= GEN[i];
  }
  return chk;
}
function bech32HrpExpand(hrp){
  const out=[]; for(let i=0;i<hrp.length;i++) out.push(hrp.charCodeAt(i)>>5);
  out.push(0);
  for(let i=0;i<hrp.length;i++) out.push(hrp.charCodeAt(i)&31);
  return out;
}
function bech32Decode(addr){
  const lower = addr.toLowerCase();
  if(lower !== addr && addr.toUpperCase() === addr) return null; // mixed case invalid
  const pos = addr.lastIndexOf('1');
  if(pos<1 || pos+7>addr.length) return null;
  const hrp = addr.slice(0,pos).toLowerCase();
  const dataPart = addr.slice(pos+1).toLowerCase();
  const data=[]; for(const c of dataPart){ const v = bech32Chars.indexOf(c); if(v===-1) return null; data.push(v); }
  if(!hrp.startsWith('ltc')) return null; // litecoin hrp variants usually 'ltc'
  const hrpExp = bech32HrpExpand(hrp);
  if(bech32Polymod(hrpExp.concat(data)) !== 1) return null;
  return { hrp, data };
}
function classify(addr){
  if(addr.startsWith('L') || addr.startsWith('M')) return { encoding:'base58', details: validateBase58(addr) };
  if(addr.toLowerCase().startsWith('ltc1')){
    const d = bech32Decode(addr); return { encoding:'bech32', details: d ? { ok:true, hrp:d.hrp, dataLength:d.data.length } : { ok:false, reason:'bech32 checksum fail'} };
  }
  return { encoding:'unknown', details:{ ok:false, reason:'pattern not recognized' } };
}

console.log(JSON.stringify({ address: input, validation: classify(input) }, null, 2));
