#!/usr/bin/env node
'use strict';
const { computeTrend } = require('./life-drawing-audit-trend');
const res = computeTrend({ limit: 10, window: 3 });
if(!res.ok){ console.error('Trend unavailable: '+res.message); process.exit(0); }
if(!Array.isArray(res.severities) || !res.severities.length){ console.error('No severities'); process.exit(1); }
const first = res.severities[0];
if(typeof first.slope !== 'number'){ console.error('Slope missing'); process.exit(1); }
if(!Array.isArray(first.rollingAvg) || !first.rollingAvg.length){ console.error('rollingAvg missing'); process.exit(1); }
console.log(JSON.stringify({ ok:true, count: res.count, sample: first }, null, 2));
