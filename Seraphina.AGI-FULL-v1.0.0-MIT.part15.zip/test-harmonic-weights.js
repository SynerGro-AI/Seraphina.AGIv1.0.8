// test-harmonic-weights.js
// Simulation harness to verify probabilistic attempt distribution matches harmonic weights.
// Runs deterministic pseudo-work across synthetic seeds and tallies kept vs skipped per harmonic.

const crypto = require('crypto');

const HARMONICS = ['h0','h1','h2','h3'];
const weights = { h0:0.25, h1:0.50, h2:0.75, h3:1.00 };
const TOTAL = 20000;
const tallies = { h0:{keep:0,skip:0}, h1:{keep:0,skip:0}, h2:{keep:0,skip:0}, h3:{keep:0,skip:0} };

function harmonicTag(seedHex){ return 'h' + (parseInt(seedHex[0],16) % 4); }

for (let i=0;i<TOTAL;i++){
  const seed = crypto.createHash('sha256').update('seed:'+i).digest('hex');
  const tag = harmonicTag(seed);
  const w = weights[tag];
  const hDet = crypto.createHash('sha256').update(seed + ':' + i.toString(16)).digest();
  const frac = hDet.readUInt32BE(0) / 0xffffffff;
  if (frac > w){
    tallies[tag].skip++;
  } else {
    tallies[tag].keep++;
  }
}

console.log('Target Weights (keep probability):', weights);
for (const h of HARMONICS){
  const t = tallies[h];
  const total = t.keep + t.skip;
  const empirical = t.keep / total;
  console.log(`${h} empirical=${empirical.toFixed(4)} target=${weights[h].toFixed(4)} diff=${(empirical-weights[h]).toFixed(4)}`);
}
