// test-dimension-escalation.js
// Verifies deterministic dimension escalation decision.
'use strict';
const assert = require('assert');
const { decideDimensionEscalation } = require('./dimension-escalator');

const history = [0.101,0.102,0.101,0.100,0.101];
const opts = {
  history,
  currentDim: 3,
  targetDim: 12,
  stepMax: 16,
  varianceThreshold: 0.2,
  plateauRuns: 5
};

const res1 = decideDimensionEscalation(opts);
const res2 = decideDimensionEscalation(opts);
assert.deepStrictEqual(res1, res2, 'Decision not deterministic');
assert.strictEqual(res1.escalate, true, 'Expected escalate condition true');
assert.strictEqual(res1.nextDim, 12, 'Next dimension mismatch');
console.log('[TEST PASS] Dimension escalation deterministic:', res1);
