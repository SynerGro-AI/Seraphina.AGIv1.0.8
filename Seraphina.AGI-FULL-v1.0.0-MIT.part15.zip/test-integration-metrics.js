'use strict';
// test-integration-metrics.js
// Integration test: run simulation, start exporter (HTTP), fetch /metrics and assert required gauges present.
const http = require('http');
const api = require('./seraphina-api');

function fetchMetrics(port, host){
  return new Promise((resolve,reject)=>{
    const req = http.get({ host, port, path:'/metrics' }, res=>{
      let data='';
      res.on('data',d=> data+=d);
      res.on('end',()=> resolve({ status: res.statusCode, body:data }));
    });
    req.on('error',reject);
  });
}

async function run(){
  // Run a simulation to populate metrics
  const simRes = api.virtueSim.runSimulation({ n:700, seed:'integration-seed' });
  if(!simRes.ok) throw new Error('Simulation failed: '+simRes.code);
  const expInfo = api.exporters.startPrometheusExporter({ port: 9123, host: '127.0.0.1' });
  if(!expInfo.ok) throw new Error('Exporter start failed');
  const met = await fetchMetrics(expInfo.port, expInfo.host);
  if(met.status !== 200) throw new Error('Metrics HTTP status not 200');
  const required = [
    'seraphina_last_n',
    'seraphina_corr_prudence_harm',
    'seraphina_target_corr_prudence_harm',
    'seraphina_delta_prudence_harm',
    'seraphina_sim_cache_entries'
  ];
  for(const r of required){
    if(!met.body.includes(r)) throw new Error('Missing metric '+r);
  }
  console.log('Integration metrics test passed.');
}

if(require.main === module){
  run().catch(e=>{ console.error('Integration test failed:', e.message); process.exit(1); });
}
module.exports = { run };
