// test-imagination-dimension.js
// Ensures high-dimensional lattice (48D) generation is deterministic.
'use strict';
const assert = require('assert');
const { runImaginationSession } = require('./seraphina-3d-imagination-adapter');

function session(dim){
  process.env.IMAGINATION_DIM = String(dim);
  return runImaginationSession({ lattice: { dim }, scenarios: [ { id:'t1', tradingBiasDelta:0.01, spreadExpectation:0.05, avatarParams:{ scale:1.02, focusShell:2, emphasisAxis:'x' } } ] });
}

// Run multiple times for 48D
const runs = [];
for(let i=0;i<3;i++){ runs.push(session(48)); }

// Lattice digest must be identical (timestamp makes sessionDigest differ)
const digests = runs.map(r=> r.latticeDigest);
for(const d of digests){ assert.strictEqual(d, digests[0], 'Lattice digest unstable for 48D'); }

// Dimension recorded
runs.forEach(r=> assert.strictEqual(r.dim, 48, 'Dimension not recorded as 48'));

console.log('[TEST PASS] 48D lattice deterministic. LatticeDigest:', digests[0]);
