#!/bin/bash
# sync-wsl-iso-source.sh
# Helper to stage mining project into clean WSL ext4 workspace excluding Windows-only & heavy dirs.
# Usage: ./sync-wsl-iso-source.sh /mnt/c/Users/user/OneDrive/AppData/Documents/mining ./octa-mining
set -euo pipefail
SRC=${1:-''}
DEST=${2:-'./octa-mining'}
if [[ -z "$SRC" || ! -d "$SRC" ]]; then
  echo "Source directory missing: $SRC" >&2; exit 1
fi
mkdir -p "$DEST"
# Exclusions: Python venv, node_modules cache, workflow CI configs, build outputs, iso artifacts, temp logs.
rsync -a --delete \
  --exclude '.venv/' \
  --exclude 'node_modules/' \
  --exclude '.github/workflows/' \
  --exclude 'hybrid-iso-build/' \
  --exclude '*.iso' \
  --exclude '*.log' \
  --exclude '*.tmp' \
  "$SRC/" "$DEST/"

echo "[OK] Sync complete to $DEST"
