// test-life-drawing-exam.js
'use strict';
const { generateLifeDrawingExam } = require('./life-drawing-exam');
function run(){
  const exam = generateLifeDrawingExam();
  console.log(JSON.stringify({ questionCount: exam.questionCount, first: exam.questions.slice(0,3) }, null, 2));
}
if(require.main === module){ run(); }
module.exports = { run };