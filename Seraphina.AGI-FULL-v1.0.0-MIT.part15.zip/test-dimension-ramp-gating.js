// test-dimension-ramp-gating.js
// Verifies ramp step cap and gating logic in isolation (pure decision path simulated).
'use strict';
const assert = require('assert');
const { decideDimensionEscalation } = require('./dimension-escalator');

// Simulated history meeting plateau/variance criteria
const history = [0.11,0.11,0.109,0.108,0.11];
// Use targetDim such that (targetDim - currentDim) <= stepMax to satisfy step constraint.
const decision = decideDimensionEscalation({ history, currentDim:3, targetDim:35, stepMax:32, varianceThreshold:0.2, plateauRuns:5 });
assert.ok(decision.escalate, 'Expected escalate true with stable history');
// Apply ramp logic externally (rampStep 10)
const rampStep = 10;
const cappedNext = Math.min(3 + rampStep, decision.nextDim, 35);
assert.strictEqual(cappedNext, 13, 'Ramp step not applied correctly');
console.log('[TEST PASS] Ramping logic simulation ok. Escalate->', decision.nextDim, 'Capped->', cappedNext);
