// test-life-drawing-retention.js
'use strict';
const { computeRetention } = require('./life-drawing-retention');
function assert(c,m){ if(!c) throw new Error('Assertion failed: '+m); }
const report = computeRetention();
console.log(JSON.stringify(report,null,2));
if(report.ok){
  assert(Array.isArray(report.fields), 'fields array');
}
