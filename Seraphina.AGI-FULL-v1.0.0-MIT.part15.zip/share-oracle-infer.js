// share-oracle-infer.js
// Deterministic logistic inference using share-oracle-weights.json.
'use strict';
const fs = require('fs');

function sigmoid(x){ return 1/(1+Math.exp(-x)); }

class ShareOracle {
  constructor(weightsPath='share-oracle-weights.json'){
    this.weightsPath = weightsPath;
    this.loaded=false;
    this.w=null; this.b=null;
    this.meta=null;
    this.load();
  }
  load(){
    if(!fs.existsSync(this.weightsPath)) return;
    const raw = JSON.parse(fs.readFileSync(this.weightsPath,'utf8'));
    this.b = raw.bias; this.w = [raw.w_freq, raw.w_rate, raw.w_diff];
    this.meta = raw; this.loaded=true;
  }
  predict(feat){
    if(!this.loaded) return 0.5; // neutral fallback
    const z = this.b + this.w[0]*feat[0] + this.w[1]*feat[1] + this.w[2]*feat[2];
    return sigmoid(z);
  }
  sortLattice(nodes){
    if(!this.loaded) return nodes; // no reordering
    // Build features normalized relative to min/max in current snapshot for frequencies & success rate & difficulty
    const freqs = nodes.map(n=> n.freq);
    const rates = nodes.map(n=> (n.successes/(n.attempts||1)) || 0);
    const diffs = nodes.map(()=>  (global.__AUR_CURRENT_JOB_DIFFICULTY__||0));
    function norm(v, arr){ const min=Math.min(...arr); const max=Math.max(...arr); const r=(max-min)||1; return (v-min)/r; }
    const enriched = nodes.map(n=> {
      const feat = [ norm(n.freq,freqs), norm((n.successes/(n.attempts||1))||0,rates), norm((global.__AUR_CURRENT_JOB_DIFFICULTY__||0), diffs) ];
      return { node: n, p_accept: this.predict(feat) };
    });
    enriched.sort((a,b)=> b.p_accept - a.p_accept);
    return enriched.map(e=> e.node);
  }
}

module.exports = { ShareOracle };
