'use strict';
// swarm-upload.js
// Stub script for future multi-device firmware distribution.
// Current behavior: computes SHA256 of a provided firmware file, enumerates (mock) serial ports, prints plan.
// Usage: node swarm-upload.js --file=fw.tar.gz

const fs = require('fs');
const crypto = require('crypto');

function parseArgs(){
  const out = {};
  for(const a of process.argv.slice(2)){
    const m = /^--([^=]+)=(.*)$/.exec(a); if(m) out[m[1]] = m[2];
  }
  return out;
}

function computeHash(file){
  const data = fs.readFileSync(file);
  return crypto.createHash('sha256').update(data).digest('hex');
}

function mockSerialEnumeration(){
  // Try real serialport if installed; otherwise fallback mock.
  let realPorts=null;
  try {
    const sp = require('serialport');
    if(sp && sp.SerialPort){ /* legacy */ }
    const listFn = sp.list || sp.SerialPort?.list;
    if(listFn){
      // synchronous wrapper
      return listFn().then(arr=> arr.map(p=> ({ path: p.path, vendor: p.vendorId||'unknown', product: p.productId||'unknown' })) ).catch(()=> fallback());
    }
  } catch(e){ /* ignore */ }
  return fallback();
  function fallback(){
    return [
      { path: 'COM3', vendor: 'MockVendor', product: 'MinerNodeA' },
      { path: 'COM4', vendor: 'MockVendor', product: 'MinerNodeB' }
    ];
  }
}

function main(){
  const args = parseArgs();
  if(!args.file) throw new Error('Missing --file argument');
  if(!fs.existsSync(args.file)) throw new Error('File not found: '+args.file);
  const hash = computeHash(args.file);
  const devicesMaybe = mockSerialEnumeration();
  const handleDevices = (devices)=> {
    console.log('Firmware hash:', hash);
    console.log('Target devices:', devices.length);
    devices.forEach(d=> console.log(' ->', d.path, d.vendor+'/'+d.product));
    console.log('Distribution plan: (stub) send file chunks over serial with integrity ACK.');
  };
  if(Array.isArray(devicesMaybe)){
    handleDevices(devicesMaybe);
  } else if(devicesMaybe && typeof devicesMaybe.then === 'function'){
    devicesMaybe.then(handleDevices).catch(e=>{ console.error('Serial enumeration failed, using mock:', e.message); handleDevices(mockSerialEnumeration()); });
  }
}

if(require.main === module){
  try { main(); } catch(e){ console.error('Swarm upload stub failed:', e.message); process.exit(1); }
}
module.exports = { parseArgs, computeHash, mockSerialEnumeration };
