# Real Wallet Validation & Deterministic Test Addresses

## Purpose
Ensure all mining operations use authentic, chain-valid wallet addresses while still permitting deterministic test scaffolds inside the Holodeck (simulation layer). This document outlines how addresses are validated, how to supply real ones, and how optional deterministic generation is kept segregated from production.

## Validation Layers
1. Base58Check integrity: version byte + payload + double SHA256 checksum (first 4 bytes).
2. Prefix / version constraints per coin:
   - BTC P2PKH: version 0x00 (prefix "1"), P2SH 0x05 (prefix "3").
   - LTC: multiple prefixes (L/M for legacy base58), bech32 (ltc1...) currently pattern-checked.
   - RVN: P2PKH 0x3c (prefix "R"), P2SH 0x7a (prefix starting with lowercase variant) – we enforce 0x3c for mining address.
   - FREN: Placeholder prefix logic (subject to core chain standardization). Current validation asserts Base58Check checksum only.
3. Strict mode (`REAL_MINING_ENFORCED=1`): Miner aborts immediately if any required address is missing or invalid.

## Required Environment Variables
| Coin | Variable | Notes |
|------|----------|-------|
| BTC  | BTC_MINING_ADDRESS | Main payout / mining address. |
| LTC  | LTC_KRAKEN_ADDRESS or LTC_MINING_ADDRESS | Provide at least one valid LTC address. |
| RVN  | RVN_LOCAL_ADDRESS (or RVN_MINING_ADDRESS/PAYOUT) | Must pass checksum, start with R. |
| FREN | FREN_WALLET | Must pass checksum (prefix TBD). |

## Example (PowerShell)
```powershell
$env:REAL_MINING_ENFORCED='1'
$env:BTC_MINING_ADDRESS='1FfmbHfnpaZjKFvyi1okTjJJusN455paPH'
$env:LTC_KRAKEN_ADDRESS='LZz123ExampleLitecoinAddrXYZabc'
$env:RVN_LOCAL_ADDRESS='RExampleRavencoinAddressValid123456'
$env:FREN_WALLET='F7eQqaBnyJAMjzUrJZjRW8Q3ywDXHg7LJw'  # Update when FREN chain spec matures
```

## Deterministic Test Addresses (Holodeck Only)
Script: `rvn-deterministic-address.js` derives pseudo RVN addresses from a seed + index. These:
- Are NOT produced by real secp256k1 keypairs.
- Should NEVER be used for real fund custody.
- Are suitable only when `HOLODECK_ENABLE=1` and `REAL_MINING_ENFORCED!=1`.

To generate for simulation:
```powershell
$addr=(node rvn-deterministic-address.js aurrelia-rvn-seed 0 | ConvertFrom-Json).address
$env:RVN_LOCAL_ADDRESS=$addr
```

## Optional RPC Cross-Check (Future)
A guarded flag `REAL_ADDRESS_CHAIN_CHECK=1` may:
1. Call coin daemon RPC `getaddressinfo` or equivalent.
2. Confirm `isvalid` and network (mainnet vs testnet).
3. Abort if mismatch.
This check is intentionally off by default to preserve determinism in pure Holodeck runs.

## Failure Modes & Exit Codes
| Condition | Exit | Message Prefix |
|-----------|------|----------------|
| Missing required address (strict) | 2 | [ENFORCE] Missing required address |
| Invalid checksum (strict) | 2 | [ENFORCE] Invalid Base58Check address |
| Version/prefix mismatch | 2 | [ENFORCE] Address version byte mismatch |

## Address Rotation Strategy (Recommended)
- Maintain an audited JSON ledger of active payout addresses.
- Rotate RVN & BTC mining addresses quarterly or on risk events.
- Anchor change events in HMAC share ledger for traceability.

## Security Considerations
- Never auto-import private keys from agent output.
- Keep WIF/private keys in a secure vault, not environment variables.
- Use hardware wallet or multisig for large balances; mining payout address may point to a hot wallet with periodic sweep.

## Checklist Before Real Mining
1. REAL_MINING_ENFORCED=1 is set.
2. All required coin address env variables present and validated.
3. No deterministic test addresses in use.
4. DNS virtualization disabled (HOLODECK_DNS_ENABLE=0) unless sim-testing.
5. Share ledger verification passes (`global.__HOLO_LEDGER_STATUS__`).
6. RPC connectivity to target pool host resolves via real DNS.

## Troubleshooting
- If enforcement aborts but address seems valid: verify no hidden whitespace; echo length.
- For RVN, ensure address starts with R and length ~34; verify checksum using an external tool.
- Disable Holodeck for real runs: unset HOLODECK_ENABLE or set to 0.

---
End of WALLET-VALIDATION guide.
