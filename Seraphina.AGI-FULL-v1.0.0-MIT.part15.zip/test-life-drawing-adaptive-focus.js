// test-life-drawing-adaptive-focus.js
'use strict';
const { generateFocusedExam } = require('./life-drawing-next-exam-recommend');
const { startSession, recordResponse, finalizeSession } = require('./life-drawing-session');

function simulate(one){
  const exam = generateFocusedExam({ limit: 4 });
  const session = startSession(exam);
  exam.questions.forEach(q=>{
    // Provide all expected fields to maximize completeness
    const answers={}; q.expectedFields.forEach(f=> answers[f]='ok');
    recordResponse(session, { questionId: q.id, answers });
  });
  const summary = finalizeSession(session, exam);
  return { exam, summary };
}

const run = simulate();
console.log(JSON.stringify(run.summary,null,2));
if(run.exam.focus && run.exam.focus.weakFields){
  console.log('[focus-weak]', run.exam.focus.weakFields);
}
