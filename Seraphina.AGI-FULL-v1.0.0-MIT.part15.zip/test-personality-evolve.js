// test-personality-evolve.js
// Deterministic test for personality trait computation.
const assert = require('assert');
const { computeTraits } = require('./seraphina-personality-evolve.js');

function run(){
  const metrics = {
    imagination:{ curiosity:0.72, novelty:0.41, empowerment:0.63, integration:0.58 },
    emotion:{ calm:0.55, focus:0.62, resolve:0.57, empathy:0.49, wonder:0.66 },
    sandbox:{ cycles:1234, stableRatio:0.74 },
    ethics:{ virtueGauge:0.68 }
  };
  const traitsA = computeTraits(metrics);
  const traitsB = computeTraits(JSON.parse(JSON.stringify(metrics)));
  assert.deepStrictEqual(traitsA, traitsB, 'Traits must be deterministic for identical input');
  for (const [k,v] of Object.entries(traitsA)){
    assert(v >=0 && v <=1, 'Trait '+k+' out of [0,1] range');
  }
  console.log('[TEST personality-evolve] PASS', traitsA);
}

if (require.main === module){ run(); }

module.exports = run;