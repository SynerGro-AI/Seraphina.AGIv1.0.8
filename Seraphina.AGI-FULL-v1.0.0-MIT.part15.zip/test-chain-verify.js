const { expect } = require('chai');
const { verifyChain } = require('./seraphina-chain-verify');
const crypto = require('crypto');
function sha256(d){ return crypto.createHash('sha256').update(d).digest('hex'); }

describe('Chain Verification Utility', () => {
  function buildRecords(count){
    const recs=[]; let prev=null;
    for(let i=0;i<count;i++){
      const core = { ts: Date.now()+i, type:'frameHam', frame:i, ham: i*0.001 };
      const payloadStr = JSON.stringify(core);
      const chainDigest = sha256(payloadStr);
      const chainHash = sha256((prev||'')+ ':' + chainDigest);
      recs.push({ ...core, chainPrev: prev, chainDigest, chainHash, chainHmac: null });
      prev = chainHash;
    }
    return recs;
  }

  it('verifies intact chain successfully', () => {
    const recs = buildRecords(10);
    const result = verifyChain(recs, null, false);
    expect(result.failures.length).to.equal(0);
    expect(result.total).to.equal(10);
  });

  it('detects a single chainHash break', () => {
    const recs = buildRecords(8);
    // Corrupt middle record digest
    recs[4].chainDigest = 'deadbeef';
    const result = verifyChain(recs, null, false);
    expect(result.failures.length).to.be.greaterThan(0);
    expect(result.failures[0].reason).to.equal('digest-mismatch');
  });

  it('flags missing HMAC when key provided', () => {
    const recs = buildRecords(5);
    const result = verifyChain(recs, 'secretKey', false);
    expect(result.failures.length).to.be.greaterThan(0);
    expect(result.failures[0].reason).to.equal('hmac-missing');
  });
});
