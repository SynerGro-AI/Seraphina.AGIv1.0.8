'use strict';
// test-command-risk-classifier.js
// Minimal deterministic tests for command-risk-classifier.
const { classify } = require('./command-risk-classifier.js');

const samples = [
  'echo hello world',
  'sudo apt install htop',
  'rm -rf /var/lib/apt/lists/*',
  'wipefs -a /dev/sda',
  'mount -o loop linux.iso /mnt/iso',
  'systemctl list-timers',
  'init=/bin/bash',
  'sudo passwd root'
];

const results = samples.map(s=> classify(s));
process.stdout.write(JSON.stringify(results,null,2)+'\n');
