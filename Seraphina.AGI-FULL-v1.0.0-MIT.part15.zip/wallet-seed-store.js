/**
 * WALLET SEED STORE (Encrypted Mnemonic Persistence)
 * --------------------------------------------------
 * Persists a BIP39 mnemonic encrypted with AES-256-GCM using a key provided
 * via environment variable WALLET_SEED_KEY (hex or base64). If no key is
 * provided, falls back to plaintext (not recommended for production).
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, 'persistent_data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const SEED_FILE = path.join(DATA_DIR, 'wallet_seed.enc');

function getKey() {
  const raw = process.env.WALLET_SEED_KEY || '';
  if (!raw) return null;
  // Accept 64 hex chars or base64
  if (/^[0-9a-fA-F]{64}$/.test(raw)) return Buffer.from(raw, 'hex');
  try { return Buffer.from(raw, 'base64'); } catch { return null; }
}

function encryptMnemonic(mnemonic) {
  const key = getKey();
  if (!key) return { plaintext: true, data: mnemonic };
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(mnemonic, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { plaintext: false, data: Buffer.concat([Buffer.from('G1'), iv, tag, enc]).toString('base64') };
}

function decryptMnemonic(payload) {
  const key = getKey();
  if (!key) return payload; // treat as plaintext
  const buf = Buffer.from(payload, 'base64');
  if (buf.slice(0,2).toString() !== 'G1') throw new Error('Bad seed header');
  const iv = buf.slice(2,14);
  const tag = buf.slice(14,30);
  const enc = buf.slice(30);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const dec = Buffer.concat([decipher.update(enc), decipher.final()]);
  return dec.toString('utf8');
}

function saveMnemonic(mnemonic) {
  const wrapped = encryptMnemonic(mnemonic);
  const record = { ts: Date.now(), plaintext: wrapped.plaintext, payload: wrapped.data };
  fs.writeFileSync(SEED_FILE, JSON.stringify(record, null, 2));
}

function loadMnemonic() {
  try {
    const json = JSON.parse(fs.readFileSync(SEED_FILE,'utf8'));
    if (json.plaintext) return json.payload; // stored plaintext
    return decryptMnemonic(json.payload);
  } catch { return null; }
}

module.exports = { saveMnemonic, loadMnemonic };