// verify-fren-address.js
// Tentative Frencoin Base58Check validation (assumes Bitcoin-style version bytes; adjust as specs clarify)
// Usage: node verify-fren-address.js FAddress

const crypto = require('crypto');
const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const MAP = {}; for (let i=0;i<ALPHABET.length;i++) MAP[ALPHABET[i]] = i;
function sha256(b){ return crypto.createHash('sha256').update(b).digest(); }

function decodeBase58Check(addr){
  if (!addr || typeof addr !== 'string') return null;
  let x = BigInt(0);
  for (const ch of addr){ const v = MAP[ch]; if (v===undefined) return null; x = x*58n + BigInt(v); }
  let bytes = [];
  while (x>0n){ bytes.push(Number(x % 256n)); x = x / 256n; }
  bytes = bytes.reverse();
  for (const c of addr){ if (c==='1') bytes.unshift(0); else break; }
  if (bytes.length < 5) return null;
  const data = Buffer.from(bytes.slice(0,-4));
  const checksum = Buffer.from(bytes.slice(-4));
  const hash = sha256(sha256(data));
  if (!hash.slice(0,4).equals(checksum)) return null;
  return data;
}

function classify(addr){
  const buf = decodeBase58Check(addr);
  if(!buf) return { valid:false, reason:'checksum' };
  const ver = buf[0];
  // Placeholder assumptions (need authoritative FREN version bytes):
  if (ver===0x23) return { valid:true, type:'P2PKH' }; // hypothetical
  if (ver===0x05) return { valid:true, type:'P2SH' }; // reuse bitcoin legacy for now
  return { valid:false, reason:'version '+ver };
}

if (require.main === module){
  const addr = process.argv[2];
  const res = classify(addr);
  if (res.valid){ console.log('VALID', res.type); process.exit(0); }
  else { console.log('INVALID', res.reason); process.exit(2); }
}

module.exports = { classify };
