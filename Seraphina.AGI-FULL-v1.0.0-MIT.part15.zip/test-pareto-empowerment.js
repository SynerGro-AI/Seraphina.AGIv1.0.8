// test-pareto-empowerment.js
// Ensures empowerment inclusion produces 4-dim representative deterministically.
'use strict';
const assert = require('assert');
process.env.PARETO_INCLUDE_EMPOWERMENT='1';
const { runPareto } = require('./pareto-multi-metric-optimizer');

const metrics = { imaginationGain:0.2, curiosityGain:0.15, integrationNorm:0.1, empowermentGain:0.05 };
const r1 = runPareto(metrics);
const r2 = runPareto(metrics);
assert.strictEqual(r1.dims,4,'Expected 4 dimensions in Pareto result');
assert.deepStrictEqual(r1.representative, r2.representative,'Representative not stable with empowerment included');
console.log('[TEST PASS] Pareto empowerment inclusion deterministic:', r1.representative);
