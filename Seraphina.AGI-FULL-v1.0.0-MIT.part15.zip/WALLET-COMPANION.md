# Seraphina Wallet Companion

Deterministic advisory module that validates wallet configuration and emits optimization suggestions without mutating miner state.

## Objectives
- Deterministic: identical inputs (env + latency snapshot + recommendation) produce identical suggestion set & digest.
- Non-invasive: never auto-executes parameter changes; human or deterministic validator applies changes.
- Extensible: future model-guided advisories can be layered using existing injection shield.

## Enablement
Set:
```
WALLET_COMPANION=1
```
Optional environment:
```
COMPANION_LAT_SAMPLE_PATH=pool-latency.json
COMPANION_INCOME_SOURCE_JSON=<future income summary path>
COMPANION_SUGGEST_MAX=5
COMPANION_STRICT=1   # Fail validation if required wallet invalid or missing
```

## Validation Rules
| Coin | Env Var        | Required | Pattern |
|------|----------------|----------|---------|
| BTC  | WALLET_BTC     | Yes      | Legacy/P2PKH/P2SH regex ^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$ |
| RVN  | WALLET_RVN     | Yes      | ^R[a-km-zA-HJ-NP-Z1-9]{25,34}$ |
| FREN | WALLET_FREN    | Yes      | ^F[a-km-zA-HJ-NP-Z1-9]{20,60}$ |
| KAS  | KAS_WALLET     | No       | ^kaspa:[0-9a-z]{60,70}$ |

Invalid or missing required wallets generate `verify_wallet` suggestions.

## Suggestion Model
Produces array (max `COMPANION_SUGGEST_MAX`). Each element:
```json
{
  "id": "wallet-rvn",
  "type": "verify_wallet",
  "action": "replace_or_fix",
  "confidence": 0.95,
  "note": "Wallet RVN missing/invalid"
}
```

Types:
- `verify_wallet` – address missing/invalid.
- `latency_probe` – one or more pools failed TCP connect.
- `adjust_bias` – propose slight bias increment when strategic coin not active.
- `switch_coin` – reinforcement to maintain high-income focus.
- `noop` – no change recommended.

Digest: HMAC-SHA256 over ordered suggestion JSON using `CONFIG_HMAC_KEY || SERAPHINA_SEED`.

## Determinism Guarantees
- Uses only deterministic inputs: environment, static JSON snapshots, internal pure calculations.
- Tie ordering enforced by fixed priority map, then lexical id ordering.
- HMAC key stable; absence falls back to `seraphina-wallet-companion.js` fixed seed string.

## Miner Integration
When `WALLET_COMPANION=1` miner logs lines like:
```
[COMPANION] digest=<hex> suggestions=wallet-btc:verify_wallet,lat-probe:latency_probe
```
No automatic parameter changes occur.

## Extending
Add new suggestion generator inside `suggest()` with:
1. Deterministic condition.
2. Assigned `type`, `action`, `confidence`.
3. Include in priority map in `rankActions()` if new type.

## Security
- No network calls beyond reading existing snapshots.
- All external model invocation (future) must pass through global `__AUR_AGENT_INVOKE__` with prompt shielding (see AGENTS.md).

## Roadmap Hooks
Future real-time adaptive changes can subscribe to digest stable over N cycles before applying an allowed rule set (e.g., bias delta <= 0.02). See main roadmap for phased plan.

---
End of WALLET-COMPANION.md
