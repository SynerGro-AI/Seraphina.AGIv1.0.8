// traceql-depth-guard.js
// Provides construction utilities for nested TraceQL latency rate queries with
// automatic depth guarding, cost estimation, collapse strategies, and Prometheus
// instrumentation hooks.
//
// Usage Example:
// const { buildNestedRateQuery, guardDepth, registerGuardMetrics } = require('./traceql-depth-guard');
// const query = buildNestedRateQuery({
//   service: 'api', baseRange: '0.05s', windows: [ '0.0075m','0.075m','0.0125h','0.1125h','0.0375d','0.3d','1.875d' ],
//   maxDepth: 16, softDepth: 12
// });
// console.log(query.final); // safe query or collapsed alternative
//
// Integrate counters with Prometheus:
// const client = require('prom-client');
// registerGuardMetrics(client);
// guardDepth({ requestedDepth: windows.length, executedDepth: query.executedDepth, reason: query.reason });

const DEFAULT_SOFT_DEPTH = 16;
const DEFAULT_HARD_DEPTH = 24;
const POLICY_PATH = require('path').join(__dirname, 'config', 'depth-guard-policy.json');
let _policyCache = null;
let _policyLoadedAt = 0;
// Signing & rollback guard for policy integrity
const crypto = require('crypto');
class SigningRollbackGuard {
  constructor(policy){
    this.currentPolicy = policy || {}; this.previousPolicy = null; this.signature = null;
  }
  signInput(query){
    const data = JSON.stringify({ query, timestamp: Date.now(), policyVersion: this.currentPolicy.version });
    this.signature = crypto.createHash('sha256').update(data).digest('hex');
    return this.signature;
  }
  validateSignature(inputSig, query){
    // Recompute without mutating stored signature first
    const recomputed = crypto.createHash('sha256').update(JSON.stringify({ query, timestamp: Date.now(), policyVersion: this.currentPolicy.version })).digest('hex');
    if(inputSig !== recomputed){
      this.rollbackPolicy();
      throw new Error('Signature mismatch—rollback applied');
    }
    return true;
  }
  rollbackPolicy(){
    if(this.previousPolicy){
      this.currentPolicy = this.previousPolicy;
      console.log('Rolled back to policy version:', this.currentPolicy.version);
    }
  }
  updatePolicy(newPolicy){
    this.previousPolicy = this.currentPolicy;
    this.currentPolicy = newPolicy;
  }
}

function loadPolicy() {
  try {
    const now = Date.now();
    if (_policyCache && (now - _policyLoadedAt) < (_policyCache.reloadIntervalSec * 1000)) {
      return _policyCache;
    }
    const raw = require('fs').readFileSync(POLICY_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    _policyCache = parsed;
    _policyLoadedAt = now;
    return _policyCache;
  } catch (e) {
    // Fallback minimal policy
    return { softMaxDepth: DEFAULT_SOFT_DEPTH, hardMaxDepth: DEFAULT_HARD_DEPTH, costCollapseThreshold: DEFAULT_SOFT_DEPTH * 10, accelRatioEnforce: false, reasonsEnabled: [] };
  }
}

function estimateCost({ depth, distinctServices = 1, windowSpanFactor }) {
  // windowSpanFactor ~ log(maxWindow/baseWindow) or custom provided.
  // Simple heuristic: depth * distinctServices * windowSpanFactor
  return depth * distinctServices * (windowSpanFactor || 1);
}

function collapseWindows(windows, targetDepth) {
  if (windows.length <= targetDepth) return windows;
  // Strategy: keep first 2 (micro stabilization), then logarithmically sample rest.
  const preserved = windows.slice(0, 2);
  const remaining = windows.slice(2);
  const need = targetDepth - preserved.length;
  if (need <= 0) return preserved;
  const step = remaining.length / need;
  const sampled = [];
  for (let i = 0; i < need; i++) {
    sampled.push(remaining[Math.floor(i * step)]);
  }
  return preserved.concat(sampled);
}

const { validateAccelRatio } = (() => {
  try { return require('./accel-validator/accel_validator'); } catch (e) { return {}; }
})();

function buildNestedRateQuery({ service, baseRange, windows, maxDepth, softDepth, windowSpanFactor, accelRatio }) {
  const policy = loadPolicy();
  maxDepth = maxDepth || policy.hardMaxDepth || DEFAULT_HARD_DEPTH;
  softDepth = softDepth || policy.softMaxDepth || DEFAULT_SOFT_DEPTH;
  const costCollapseThreshold = policy.costCollapseThreshold || (softDepth * 10);
  const enforceAccel = policy.accelRatioEnforce;
  const reasonsEnabled = Array.isArray(policy.reasonsEnabled) ? policy.reasonsEnabled : [];
  const requestedDepth = windows.length;
  let executedDepth = requestedDepth;
  let reason = 'ok';
  let collapsed = false;

  // Optional accel ratio validation
  if (enforceAccel && typeof accelRatio !== 'undefined' && validateAccelRatio) {
    try {
      validateAccelRatio({ accel_ratio: accelRatio });
    } catch (err) {
      reason = 'accel_ratio_invalid';
      // Do not throw; mark and proceed without using accelRatio further.
      accelRatio = undefined;
    }
  }

  if (requestedDepth > maxDepth) {
    windows = collapseWindows(windows, maxDepth);
    executedDepth = windows.length;
    reason = reason === 'ok' ? 'hard_cap_collapse' : reason;
    collapsed = true;
  } else if (requestedDepth > softDepth) {
    const cost = estimateCost({ depth: requestedDepth, distinctServices: 1, windowSpanFactor });
    if (cost > costCollapseThreshold) {
      windows = collapseWindows(windows, softDepth);
      executedDepth = windows.length;
      reason = reason === 'ok' ? 'soft_cap_collapse' : reason;
      collapsed = true;
    }
  }

  let chain = `unwrap .duration [${baseRange}]`;
  let prev = baseRange;
  for (const w of windows) {
    chain = `rate(${chain}[${w}:${prev}])`;
    prev = w;
  }
  const final = `{ .service = "${service}" } | ${chain}`;

  // If reason is not enabled by policy, normalize to 'ok'
  if (reason !== 'ok' && reasonsEnabled.length && !reasonsEnabled.includes(reason)) {
    reason = 'ok';
  }

  return { final, executedDepth, requestedDepth, collapsed, reason, windows, accelRatioIncluded: typeof accelRatio === 'number', policyVersion: policy.version || 0 };
}

// Prometheus metrics
let depthRequestedCounter;
let depthExecutedCounter;
let depthCollapseCounter;

function registerGuardMetrics(promClient) {
  if (depthRequestedCounter) return; // idempotent
  depthRequestedCounter = new promClient.Counter({
    name: 'trace_query_depth_requested_total',
    help: 'Total requested trace query depths before guard collapse.'
  });
  depthExecutedCounter = new promClient.Counter({
    name: 'trace_query_depth_executed_total',
    help: 'Total executed trace query depths after guard logic.'
  });
  depthCollapseCounter = new promClient.Counter({
    name: 'trace_query_depth_collapses_total',
    help: 'Number of times a query was collapsed by depth guard.',
    labelNames: ['reason']
  });
}

function guardDepth({ requestedDepth, executedDepth, reason }) {
  if (depthRequestedCounter) {
    depthRequestedCounter.inc(requestedDepth);
    depthExecutedCounter.inc(executedDepth);
    if (executedDepth < requestedDepth) {
      depthCollapseCounter.inc({ reason });
    }
  }
}

module.exports = {
  buildNestedRateQuery,
  estimateCost,
  collapseWindows,
  registerGuardMetrics,
  guardDepth,
  loadPolicy
};
module.exports.SigningRollbackGuard = SigningRollbackGuard;
