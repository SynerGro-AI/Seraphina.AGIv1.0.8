// test-success-ledger-ranges.js
// Validates numeric ranges and basic invariants for latest success ledger entry.
'use strict';
const fs = require('fs');
const LEDGER = process.env.SERAPHINA_SUCCESS_RATE_LEDGER || 'seraphina-success-rate-ledger.jsonl';
function fail(msg){ console.error('[RangeTest][FAIL]', msg); process.exitCode = 1; }
function inRange(v,min,max){ return typeof v==='number' && v>=min && v<=max; }
function run(){
  if(!fs.existsSync(LEDGER)){ fail('Ledger missing'); return; }
  const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
  if(!lines.length){ fail('Ledger empty'); return; }
  let last; try{ last = JSON.parse(lines[lines.length-1]); }catch(e){ fail('Parse error: '+e.message); return; }
  const numericFields = ['successRate','successRateEthical','lossA','lossB','smoothAccA','emaAccA','emaAccEthical','windowMedianAcc','emaVsMedianDelta'];
  for(const f of numericFields){ if(typeof last[f] !== 'number') fail('Field not number: '+f); }
  // Probability-like fields 0..1
  ['successRate','successRateEthical','smoothAccA','emaAccA','emaAccEthical','windowMedianAcc'].forEach(f=>{ if(!inRange(last[f],0,1)) fail('Out of [0,1] range: '+f+'='+last[f]); });
  // Loss should be non-negative
  ['lossA','lossB'].forEach(f=>{ if(!(typeof last[f]==='number' && last[f]>=0)) fail('Loss negative or NaN: '+f); });
  // emaVsMedianDelta can be negative but bound by [-1,1]
  if(!inRange(last.emaVsMedianDelta,-1,1)) fail('emaVsMedianDelta out of bounds: '+last.emaVsMedianDelta);
  // Params presence
  if(!last.params || typeof last.params!=='object') fail('Missing params object');
  if(!('EMA_MEDIAN_THRESH' in last.params)) fail('Missing EMA_MEDIAN_THRESH param');
  if(process.exitCode){ return; }
  console.log('[RangeTest][PASS] Numeric ranges validated.');
}
if(require.main === module){ run(); }
module.exports = { run };
