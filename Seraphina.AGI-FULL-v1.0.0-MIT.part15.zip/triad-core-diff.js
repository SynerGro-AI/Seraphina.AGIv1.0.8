/**
 * Triad Core Diff Utility
 * Compares CORE_FILE.octa and CORE_FILE1.octa validator sections for drift.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function readCore(name){
  const p = path.join(__dirname,name);
  if(!fs.existsSync(p)) return null;
  const text = fs.readFileSync(p,'utf8');
  return { name, text };
}

function extractValidators(text){
  const triadMatch = text.match(/triad_hash_verification\(\)[^{]*{([\s\S]*?)\n\s*}/);
  if(!triadMatch) return {};
  const section = triadMatch[1];
  const re = /(seraphina_(alpha|beta|gamma)_validator)\s*:\s*{([\s\S]*?)\n\s*}/g;
  const out={}; let m; while((m=re.exec(section))!==null){ out[m[1]]=m[3].trim(); }
  return out;
}

function hash(str){return crypto.createHash('sha256').update(str,'utf8').digest('hex');}

function unifiedDiff(a,b){
  if(a===b) return null;
  const aLines = a.split(/\r?\n/);
  const bLines = b.split(/\r?\n/);
  let start=0; while(start < aLines.length && start < bLines.length && aLines[start]===bLines[start]) start++;
  let endA=aLines.length-1, endB=bLines.length-1;
  while(endA>=start && endB>=start && aLines[endA]===bLines[endB]) { endA--; endB--; }
  const segA = aLines.slice(start, endA+1);
  const segB = bLines.slice(start, endB+1);
  const lines=[];
  lines.push(`@@ -${start+1},${segA.length} +${start+1},${segB.length} @@`);
  const max = Math.max(segA.length, segB.length);
  for(let i=0;i<max;i++){
    if (segA[i] !== undefined && segB[i] !== undefined) {
      if (segA[i] === segB[i]) { lines.push(' '+segA[i]); continue; }
      if (segA[i] !== segB[i]) {
        if (segA[i]!==undefined) lines.push('-'+segA[i]);
        if (segB[i]!==undefined) lines.push('+'+segB[i]);
        continue;
      }
    } else if (segA[i] !== undefined) {
      lines.push('-'+segA[i]);
    } else if (segB[i] !== undefined) {
      lines.push('+'+segB[i]);
    }
  }
  // Truncate extremely long diffs
  if (lines.length > 400) {
    return lines.slice(0,200).join('\n')+'\n...\n'+lines.slice(-200).join('\n');
  }
  return lines.join('\n');
}

function diffCoreFiles(){
  const base = readCore('CORE_FILE.octa');
  const alt  = readCore('CORE_FILE1.octa');
  if(!base && !alt) return { ok:false, error:'NO_CORE_FILES' };
  if(base && !alt) return { ok:true, note:'ONLY_PRIMARY_PRESENT' };
  if(!base && alt) return { ok:true, note:'ONLY_ALTERNATE_PRESENT' };
  const baseVals = extractValidators(base.text);
  const altVals  = extractValidators(alt.text);
  const validators = ['seraphina_alpha_validator','seraphina_beta_validator','seraphina_gamma_validator'];
  const report = {};
  for(const v of validators){
    const a = baseVals[v]||''; const b = altVals[v]||'';
    const same = a===b && !!a;
    report[v] = {
      primaryPresent: !!a,
      alternatePresent: !!b,
      identical: same,
      primaryHash: a?hash(a):null,
      alternateHash: b?hash(b):null,
      diff: same?null: unifiedDiff(a,b)
    };
  }
  return { ok:true, report };
}

module.exports = { diffCoreFiles };