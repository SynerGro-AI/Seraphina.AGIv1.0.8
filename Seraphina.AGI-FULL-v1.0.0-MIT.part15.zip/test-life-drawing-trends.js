// test-life-drawing-trends.js
'use strict';
const { computeTrends } = require('./life-drawing-trend-report');

function assert(cond,msg){ if(!cond) throw new Error('Assertion failed: '+msg); }

function run(){
  const report = computeTrends({ windowSize:3 });
  console.log('[trend-report]', JSON.stringify(report,null,2));
  if(!report.ok){ console.log('No sessions yet; skipping assertions.'); return; }
  assert(typeof report.scoreSlope === 'number', 'scoreSlope numeric');
  assert(Array.isArray(report.scoreRolling), 'scoreRolling array');
  assert(Array.isArray(report.fieldPracticeGaps), 'fieldPracticeGaps array');
}

run();
