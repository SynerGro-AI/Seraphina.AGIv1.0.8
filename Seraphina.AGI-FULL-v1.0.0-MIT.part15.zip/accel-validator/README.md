# Acceleration Ratio Validator

Validates `accel_ratio` values (micro vs macro latency acceleration) to ensure a bounded numeric range [0,1], preventing metric label cardinality blow-ups.

## Schema
```
accel_ratio: number (0 <= value <= 1)
```
No additional properties permitted.

## Installation
```powershell
npm install ajv@^8.12.0
```
Ajv already added to top-level `package.json` if you are in the mining workspace.

## Usage
```js
const { validateAccelRatio } = require('./accel-validator/accel_validator');

try {
  const ratio = validateAccelRatio({ accel_ratio: 0.73 });
  console.log('Valid ratio:', ratio);
} catch (e) {
  console.error('Validation failed:', e.message);
}
```

## Integration Points
1. Depth Guard (`traceql-depth-guard.js`): Pass `accelRatio` option; invalid ratio sets reason `accel_ratio_invalid`.
2. Tempo Lua Pipes (`tempo-lua-pipes-examples.lua`): Master `pipe` strips invalid label & logs `PIPE_ERR type=accel_invalid`.
3. Prometheus Rules (`prometheus-seraphina-rules.yml`): Alert `SeraphinaInvalidAccelRatio` when invalid occurrences detected.

## Rationale
Unvalidated acceleration ratios can introduce high-cardinality time-series if used directly as labels or produce misleading analytics when out-of-range. Early validation reduces storage and improves dashboard clarity.

## Extension Ideas
- Add histogram bucketing of ratio via metrics-generator or span-to-metric pipeline.
- Include ratio stability score (rolling stddev) for anomaly alerts.

## License
Internal project module – follows root project licensing.
