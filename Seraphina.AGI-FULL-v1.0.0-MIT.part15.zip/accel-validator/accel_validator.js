// accel-validator/accel_validator.js
// Validates acceleration ratio input using Ajv JSON Schema.
// Acceleration ratio must be numeric in [0,1].
// Usage:
//   const { validateAccelRatio } = require('./accel-validator/accel_validator');
//   const value = validateAccelRatio({ accel_ratio: 0.75 });
//   console.log(value);

const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true, useDefaults: true });

const schema = {
  type: 'object',
  properties: {
    accel_ratio: {
      type: 'number',
      minimum: 0,
      maximum: 1,
      description: 'Acceleration ratio must be numeric within [0,1]'
    }
  },
  required: ['accel_ratio'],
  additionalProperties: false
};

const validate = ajv.compile(schema);

function validateAccelRatio(data) {
  if (!validate(data)) {
    const [error] = validate.errors || [];
    const msg = error ? `${error.instancePath || 'accel_ratio'} ${error.message}` : 'validation failed';
    throw new Error(`Invalid accel_ratio: ${msg}; value=${data && data.accel_ratio}`);
  }
  return data.accel_ratio;
}

module.exports = { validateAccelRatio, schema };
