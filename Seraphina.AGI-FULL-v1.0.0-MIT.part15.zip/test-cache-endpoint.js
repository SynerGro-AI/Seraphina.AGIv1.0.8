'use strict';
// test-cache-endpoint.js
// Validates /cache endpoint token auth and warmCache API.
const http = require('http');
const api = require('./seraphina-api');

async function fetchCache(port, token){
  return new Promise((resolve,reject)=>{
    const headers = token? { Authorization: 'Bearer '+token } : {};
    const req = http.request({ port, host:'127.0.0.1', path:'/cache', method:'GET', headers }, res=>{
      let data=''; res.on('data',d=> data+=d); res.on('end',()=> resolve({ status:res.statusCode, body:data }));
    });
    req.on('error',reject); req.end();
  });
}

async function run(){
  // Preload some entries
  api.virtueSim.runSimulation({ n:520, seed:'warm-1' });
  api.virtueSim.runSimulation({ n:521, seed:'warm-2' });
  const info = api.exporters.startPrometheusExporter({ port: 9130, host:'127.0.0.1' });
  if(!info.ok) throw new Error('Exporter failed');
  const tokenMissing = await fetchCache(info.port);
  if(tokenMissing.status !== 403 && process.env.SERAPHINA_CACHE_TOKEN) throw new Error('Expected 403 when token required');
  const warmRes = api.meta.warmCache([{ n:522, seed:'warm-3' }, { n:520, seed:'warm-1' }]);
  if(!warmRes.ok || warmRes.added < 1 || warmRes.hits < 1) throw new Error('Warm cache stats unexpected');
  let token = process.env.SERAPHINA_CACHE_TOKEN;
  if(!token){
    // Temporarily set token for test via env (not re-binding server, but endpoint will check header - token null so skip auth). We only validate success body shape when token not set.
    const noAuth = await fetchCache(info.port);
    if(noAuth.status !== 200) throw new Error('Expected 200 without token when none configured');
    const parsed = JSON.parse(noAuth.body);
    if(!parsed.ok || parsed.size < 3) throw new Error('Cache endpoint body invalid');
  } else {
    const withAuth = await fetchCache(info.port, token);
    if(withAuth.status !== 200) throw new Error('Auth cache fetch failed');
  }
  console.log('Cache endpoint & warmCache test passed.');
}

if(require.main === module){ run().catch(e=>{ console.error('Cache endpoint test failed:', e.message); process.exit(1); }); }
module.exports = { run };
