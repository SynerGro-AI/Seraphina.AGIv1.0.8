# wsl-octalang-iso-build.ps1
# Wrapper to build sealed OctaLang ISO inside WSL Ubuntu root user environment.
# Produces ISO + manifest + seal, copies ISO back to Windows path.
# Usage (PowerShell Admin):
#   pwsh ./wsl-octalang-iso-build.ps1
# Optional Params: -UbuntuDistro 'Ubuntu' -SealKey 'hexkey'

param(
  [string]$UbuntuDistro = 'Ubuntu',
  [string]$SealKey = '<HASH>',
  [switch]$SkipKernel,
  [switch]$VerboseBuild
)

Write-Host "[WSL ISO] Starting wrapper (Distro=$UbuntuDistro SkipKernel=$SkipKernel Verbose=$VerboseBuild)" -ForegroundColor Cyan

${bashBuild} = @'
#!/usr/bin/env bash
set -e
set -o pipefail
export DEBIAN_FRONTEND=noninteractive
echo '[WSL-INNER] Starting build sequence inside WSL root'
echo "[WSL-INNER] uname: $(uname -a)" || true
echo "[WSL-INNER] whoami: $(whoami)"
if ! command -v apt-get >/dev/null 2>&1; then echo '[WSL-INNER][WARN] apt-get not available'; fi
echo '[WSL-INNER] Installing required packages (openssl rsync debootstrap xorriso grub-pc-bin squashfs-tools isolinux syslinux jq)'
apt-get update -y >/dev/null 2>&1 || echo '[WSL-INNER][WARN] apt-get update failed (offline?)'
# Primary install (full set)
if ! apt-get install -y openssl rsync debootstrap xorriso grub-pc-bin squashfs-tools isolinux syslinux jq >/dev/null 2>&1; then
  echo '[WSL-INNER][WARN] initial package install failed; retrying with reduced set (--no-install-recommends, excluding syslinux/isolinux)'
  apt-get install -y --no-install-recommends openssl rsync debootstrap xorriso grub-pc-bin squashfs-tools jq >/dev/null 2>&1 || echo '[WSL-INNER][ERROR] reduced package install also failed; continuing (may break later)'
fi
command -v openssl >/dev/null 2>&1 || echo '[WSL-INNER][ERROR] openssl missing; seal verification will be skipped'
cd ~
rm -rf octa-iso-work 2>/dev/null || true
mkdir -p octa-iso-work
cd octa-iso-work
rm -rf octa-mining 2>/dev/null || true
mkdir -p octa-mining

SRC='/mnt/c/Users/user/OneDrive/AppData/Documents/mining'
ESS="${SRC}/sync-essential-iso.sh"
if [ -f "$ESS" ]; then
  echo "[WSL-INNER] Using sync-essential-iso.sh at $ESS"
  sync_hash=$(sha256sum "$ESS" 2>/dev/null | awk '{print $1}')
  [ -n "$sync_hash" ] && echo "[WSL-INNER] sync-essential-iso.sh sha256=$sync_hash" || echo '[WSL-INNER][WARN] unable to compute sync-essential-iso.sh hash'
  : > ./sync.log
  bash "$ESS" "$SRC" ./octa-mining 2>&1 | sed 's/^/[SYNC] /' | tee -a ./sync.log || echo '[WSL-INNER][WARN] sync-essential script returned non-zero'
else
  echo '[WARN] Missing sync-essential-iso.sh, using fallback rsync excludes'
  : > ./sync.log
  rsync -a --delete \
    --exclude='.venv/' --exclude='node_modules/' --exclude='.git/' --exclude='.github/' \
    --exclude='*.iso' --exclude='hybrid-iso-build/' --exclude='__pycache__/' --exclude='*.pyc' \
    "$SRC/" ./octa-mining/ 2>&1 | sed 's/^/[SYNC] /' | tee -a ./sync.log
fi
echo '[WSL-INNER] Sync log tail (last 15 lines):'
tail -n 15 ./sync.log 2>/dev/null | sed 's/^/[SYNC-TAIL] /' || echo '[SYNC-TAIL] sync.log not found'
mkdir -p <WORKSPACE>/octa-iso-work 2>/dev/null || true
cp ./sync.log <WORKSPACE>/octa-iso-work/sync.log 2>/dev/null || ln -sf /root/octa-iso-work/sync.log <WORKSPACE>/octa-iso-work/sync.log 2>/dev/null || true
echo '[WSL-INNER] Ensured sync.log replication to <WORKSPACE>/octa-iso-work'

echo '[WSL-INNER] Post-sync root listing:'
ls -1 ./octa-mining | sed 's/^/[SYNC-LIST] /'
echo '[WSL-INNER] Checking for build script presence:'
test -f ./octa-mining/build-ubuntu-mining-preseed.sh && echo '[OK] build-ubuntu-mining-preseed.sh found' || echo '[ERROR] build-ubuntu-mining-preseed.sh missing'
echo '[WSL-INNER] Checking minimal-os contents:'
ls -1 ./octa-mining/minimal-os 2>/dev/null | sed 's/^/[SYNC-minimal-os] /' || echo '[WARN] minimal-os directory missing'
if [ ! -f ./octa-mining/build-ubuntu-mining-preseed.sh ]; then
  echo '[WSL-INNER][FALLBACK] Attempting direct copy of build-ubuntu-mining-preseed.sh'
  if [ -f "$SRC/build-ubuntu-mining-preseed.sh" ]; then
    ls -lh "$SRC/build-ubuntu-mining-preseed.sh" | sed 's/^/[SRC-FILE] /'
    head -n 5 "$SRC/build-ubuntu-mining-preseed.sh" | sed 's/^/[SRC-HEAD] /'
    cp "$SRC/build-ubuntu-mining-preseed.sh" ./octa-mining/ 2>/dev/null && echo '[WSL-INNER][FALLBACK] Copy succeeded' || echo '[WSL-INNER][FALLBACK] Copy failed (cp error)'
  else
    echo '[WSL-INNER][FALLBACK] Source build script not found at expected path'
    mount | grep -i "OneDrive" | sed 's/^/[MOUNT] /' || true
  fi
fi

# Normalize line endings for build script to prevent heredoc CRLF termination issues
if [ -f ./octa-mining/build-ubuntu-mining-preseed.sh ]; then
  sed -i 's/\r$//' ./octa-mining/build-ubuntu-mining-preseed.sh || true
fi

cd octa-mining
ls -1 | grep -E 'build-ubuntu-mining-preseed.sh' >/dev/null || { echo '[ERROR] build script missing after sync'; exit 1; }

echo "[WSL-INNER] SkipKernel flag (from wrapper): ${SkipKernelFlag:-unset}" # diagnostic
if [ -f build-baremetal.sh ] && [ "${SkipKernelFlag}" = 'false' ]; then
  echo '[INFO] Building custom kernel (fast mode)'
  bash ./build-baremetal.sh --fast || echo '[WARN] Kernel build failed; Ubuntu fallback will be used.'
else
  echo '[INFO] Skipping custom kernel build.'
fi

if [ ! -f build-ubuntu-mining-preseed.sh ]; then
  echo '[WSL-INNER][FATAL] build-ubuntu-mining-preseed.sh still missing; aborting before build'
  exit 2
fi
echo '[WSL-INNER] Running shellcheck lint (optional)'
if command -v shellcheck >/dev/null 2>&1; then
  shellcheck build-ubuntu-mining-preseed.sh | head -n 40 | sed 's/^/[LINT] /' || true
  shellcheck sync-essential-iso.sh | head -n 20 | sed 's/^/[LINT] /' || true
else
  echo '[LINT][WARN] shellcheck not installed inside WSL environment'
fi
echo '[INFO] Launch ISO build'
if [ "${VerboseBuildFlag}" = 'true' ]; then set -x; fi
echo '[WSL-INNER] Invoking build-ubuntu-mining-preseed.sh'
BUILD_CMD=(bash ./build-ubuntu-mining-preseed.sh --fresh --output octalang-mining.iso --seal --seal-key "$SealKey" --copilot --octaps)
echo "[WSL-INNER] Build command: ${BUILD_CMD[*]}"
"${BUILD_CMD[@]}" |& tee ../iso-build.log || { echo '[WSL-INNER][ERROR] build script failed'; exit 1; }

ISO='hybrid-iso-build/octalang-mining.iso'
SEAL='hybrid-iso-build/iso/iso-manifest.seal.json'
MAN='hybrid-iso-build/iso/iso-manifest.json'

if [ ! -f "$ISO" ]; then echo '[ERROR] ISO not produced'; exit 1; fi
ls -lh "$ISO"
head "$SEAL" || true

if command -v openssl >/dev/null 2>&1; then
  echo '[INFO] Verifying HMAC seal'
  calc=$(openssl dgst -sha256 -hmac "$SealKey" "$MAN" | awk '{print $2}') || calc=''
  if [ -n "$calc" ] && grep -q "$calc" "$SEAL"; then
    echo '[OK] Seal matches'
  else
    echo '[FAIL] Seal mismatch or calc empty'
  fi
else
  echo '[WARN] Skipping seal verification (openssl not installed)'
fi

echo '[INFO] Checking embedded systemd units'
echo '[WSL-INNER] Enumerating expected systemd units'
for u in octa-copilot.service octaps-install.service triad-miner.service aurelia-miner.service; do
  grep -R "$u" hybrid-iso-build/iso/etc/systemd/system >/dev/null 2>&1 && echo "[OK] $u present" || echo "[WARN] $u missing"
done

echo '[INFO] Copying ISO back to Windows path'
cp "$ISO" /mnt/c/Users/user/OneDrive/AppData/Documents/ || echo '[WARN] Failed to copy ISO back to Windows path'
echo '[DONE] ISO build complete.'
'@

# Run update to ensure WSL kernel fresh (optional)
Write-Host '[WSL ISO] Ensuring WSL kernel updated (non-fatal if fails)' -ForegroundColor DarkGray
try { wsl --update | Out-Null } catch {}

Write-Host '[WSL ISO] Injecting build script via base64 (LF normalized)' -ForegroundColor DarkGray
$SkipKernelFlag = if ($SkipKernel) { 'true' } else { 'false' }
$VerboseBuildFlag = if ($VerboseBuild) { 'true' } else { 'false' }
# Inject flags as env exports before script body
$bashBuild = "export SkipKernelFlag=$SkipKernelFlag`nexport VerboseBuildFlag=$VerboseBuildFlag`n$bashBuild"
# Normalize CRLF to LF before encoding
$bashBuildLF = ($bashBuild -replace "`r`n", "`n") -replace "`r", ""
$b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($bashBuildLF))
wsl -d $UbuntuDistro -u root -- bash -lc "echo '$b64' | base64 -d > ~/octa-wsl-build.sh && sed -i 's/\r$//' ~/octa-wsl-build.sh && chmod +x ~/octa-wsl-build.sh"
Write-Host '[WSL ISO] Executing build script inside WSL' -ForegroundColor DarkGray
$start = Get-Date
wsl -d $UbuntuDistro -u root -- bash -lc "bash ~/octa-wsl-build.sh"
$dur = (Get-Date) - $start
Write-Host "[WSL ISO] Build duration: $([int]$dur.TotalMinutes)m $([int]$dur.Seconds)s" -ForegroundColor Cyan

Write-Host '[WSL ISO] To smoke test with QEMU (inside WSL):' -ForegroundColor Yellow
Write-Host "wsl -d $UbuntuDistro -- bash -lc 'cd ~/octa-iso-work/octa-mining; qemu-system-x86_64 -cdrom hybrid-iso-build/octalang-mining.iso -m 1G -nographic -boot d | head -30'"

Write-Host '[WSL ISO] Wrapper complete.' -ForegroundColor Cyan