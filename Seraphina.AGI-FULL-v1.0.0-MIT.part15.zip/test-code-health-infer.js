#!/usr/bin/env node
'use strict';
// test-code-health-infer.js
// Ensures inference stable across runs given fixed weights.
const fs = require('fs');
const { extractFromCode, vectorize } = require('./seraphina-code-health-features.js');
const { execSync } = require('child_process');

function run(){
  const datasetRow = { lineCount:10, avgLineLen:42, funcCount:2, classCount:1, todoDensity:0.0, optimizationScore:0.81 };
  // Build temporary dataset
  const dsFile = 'tmp-code-health-dataset.jsonl';
  fs.writeFileSync(dsFile, JSON.stringify(datasetRow)+'\n');
  // Train
  execSync(`node seraphina-code-health-train.js ${dsFile} tmp-code-health-weights.json`, { stdio:'inherit' });
  const meta = JSON.parse(fs.readFileSync('tmp-code-health-weights.json','utf8'));
  const codeSample = 'class Z{a(){return 1}}\nfunction f(x){return x+1}';
  fs.writeFileSync('tmp-code-sample.js', codeSample);
  const resRaw = execSync(`node seraphina-code-health-infer.js tmp-code-health-weights.json tmp-code-sample.js`).toString('utf8');
  const match = /\[CodeHealthInfer\]\s+(\{.*\})/.exec(resRaw);
  if(!match){ console.error('[FAIL] Inference output not captured'); process.exit(1); }
  const res = JSON.parse(match[1]);
  if(typeof res.regScore !== 'number' || typeof res.needsImprovementProb !== 'number'){ console.error('[FAIL] Missing numeric scores'); process.exit(1); }
  console.log('[PASS] Inference deterministic regScore=', res.regScore.toFixed(6), 'prob=', res.needsImprovementProb.toFixed(6));
  // Cleanup
  ['tmp-code-health-dataset.jsonl','tmp-code-health-weights.json','tmp-code-sample.js'].forEach(f=>{ try{ fs.unlinkSync(f); }catch{} });
}

if(require.main === module){ run(); }