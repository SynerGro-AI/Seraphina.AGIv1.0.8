"use strict";
// Simple test: append sample share records and verify chain integrity.
const { append, verify } = require('./ledger-hmac-chain');
const file = process.env.SHARE_LEDGER_PATH || 'share-ledger-test.jsonl';
for (let i=0;i<5;i++){
  append(file, { t: Date.now(), jobId: 'job'+i, ex2: i.toString(16), real: i%2, sim: (i%2?0:1), norm: i*0.01, rankProxy:1.0+i*0.001, signVar:1.0 });
}
const result = verify(file);
console.log('[LedgerChainTest] verify:', result);
if (!result.ok){ process.exit(2); }