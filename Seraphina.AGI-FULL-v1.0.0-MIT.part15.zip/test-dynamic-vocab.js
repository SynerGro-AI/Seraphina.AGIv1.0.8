// test-dynamic-vocab.js
'use strict';
const assert = require('assert');
const fs = require('fs');
const { addWords } = require('./seraphina-model-vocab-update.js');
const { extractFeatures } = require('./seraphina-model-features.js');

function run(){
  // Clean start
  if(fs.existsSync('seraphina-model-vocab.json')) fs.unlinkSync('seraphina-model-vocab.json');
  if(fs.existsSync('seraphina-model-vocab-ledger.jsonl')) fs.unlinkSync('seraphina-model-vocab-ledger.jsonl');
  addWords(['innovation','collaborate']);
  const vocabData = JSON.parse(fs.readFileSync('seraphina-model-vocab.json','utf8'));
  assert(vocabData.words.includes('innovation'), 'innovation added');
  const entry = { dialogs:[{text:'We explore and collaborate to innovate with ethical vision'}], personality:{}, econSignals:{}, decisions:[] };
  const { manifest } = extractFeatures(entry);
  assert(manifest.vocab.includes('innovation'), 'manifest includes new word');
  assert(manifest.vocabMerkle, 'merkle root present');
  console.log('[TestDynamicVocab] PASS', manifest.vocabMerkle.slice(0,16));
}

if(require.main===module){ run(); }

module.exports = { run };
