// test-validator.js (Mocha/Chai)
// Validates ReplayValidator behavior across stable, divergent, and empty provenance scenarios.
const { expect } = require('chai');
const ReplayValidator = require('./seraphina-cull-replay-validate');
const crypto = require('crypto');

describe('ReplayValidator Unit Tests', () => {
  let frames = [];
  beforeEach(() => {
    frames = Array.from({ length: 100 }, (_, i) => ({
      ts: 1763158363014 + i * 1000,
      type: 'frame',
      digest: 'ba743da9b9731eeef54a2a406615774789f91a84994a589d2b77b2d0dd8887c7',
      ham: i % 10 === 0 ? 0.15 : 0.00,
      health: i % 10 === 0 ? 'critical' : 'healthy'
    }));
  });

  function buildAdaptProofProvenance(base){
    const prov = [];
    for(let i=0;i<base.length;i++){
      prov.push(base[i]);
      // treat each index as an adaptation checkpoint for synthetic test
      const subset = base.slice(0,i+1).map(e=> e.ham);
      const sorted = [...subset].sort((a,b)=>a-b);
      const proof = crypto.createHash('sha256').update(JSON.stringify(sorted.map(x=> Number(x.toFixed(12))))).digest('hex');
      prov.push({ ts: base[i].ts+1, type:'adaptProof', adaptProof: proof, distances: sorted });
    }
    return prov;
  }

  it('Validates stable provenance (no spikes) with zero mismatches', () => {
    const stableFrames = frames.filter(f=> f.ham === 0.00);
    const prov = buildAdaptProofProvenance(stableFrames);
    const result = new ReplayValidator(prov).validate();
    expect(result.mismatches).to.equal(0);
    expect(result.health).to.equal('healthy');
    expect(result.avgHam).to.be.closeTo(0.00, 0.0001);
    expect(result.adaptProofCount).to.equal(stableFrames.length);
  });

  it('Reports caution when spike present even if avgHam < threshold', () => {
    // Build provenance mixing frame + adaptProof events where some frames have ham >= spike threshold (0.15 > 0.12)
    const prov = buildAdaptProofProvenance(frames);
    const result = new ReplayValidator(prov).validate();
    expect(result.mismatches).to.equal(0);
    // avgHam ~0.015 is <0.05 but spike escalation should promote to caution
    expect(result.health).to.equal('caution');
    expect(result.avgHam).to.be.closeTo(0.015, 0.002);
    expect(result.maxHam).to.be.greaterThan(0.12);
    expect(result.adaptProofCount).to.equal(frames.length);
  });

  it('Handles empty provenance gracefully', () => {
    const result = new ReplayValidator([]).validate();
    expect(result.mismatches).to.equal(0);
    expect(result.health).to.equal('pending');
    expect(Number.isNaN(result.avgHam)).to.equal(true);
    expect(result.adaptProofCount).to.equal(0);
  });

  it('Detects mismatched adaptProof integrity', () => {
    const stableFrames = frames.filter(f=> f.ham === 0.00).slice(0,10);
    const prov = [];
    // Build 10 valid adaptProof events
    for(let i=0;i<stableFrames.length;i++){
      prov.push(stableFrames[i]);
      const subset = stableFrames.slice(0,i+1).map(e=> e.ham);
      const sorted = [...subset].sort((a,b)=>a-b);
      const proof = crypto.createHash('sha256').update(JSON.stringify(sorted.map(x=> Number(x.toFixed(12))))).digest('hex');
      prov.push({ ts: stableFrames[i].ts+1, type:'adaptProof', adaptProof: proof, distances: sorted });
    }
    // Corrupt one adaptProof
    const corruptIndex = prov.findIndex(p=> p.type==='adaptProof' && p.distances.length===5);
    prov[corruptIndex].adaptProof = 'deadbeef'+prov[corruptIndex].adaptProof.slice(8); // force mismatch
    const result = new ReplayValidator(prov).validate();
    expect(result.mismatches).to.equal(1);
    // Health should remain healthy (no ham spikes) but mismatch count surfaces integrity issue
    expect(result.health).to.equal('healthy');
    expect(result.adaptProofCount).to.equal(10);
  });
});
