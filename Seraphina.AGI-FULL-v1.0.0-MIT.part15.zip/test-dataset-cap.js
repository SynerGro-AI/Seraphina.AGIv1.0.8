// test-dataset-cap.js
// Minimal test harness for MAX_RESERVOIR cap enforcement.
// Usage: node test-dataset-cap.js

const fs = require('fs');
const { run } = require('./seraphina-model-train.js');

function makeDummyDataset(path, total){
  const lines=[];
  for(let i=0;i<total;i++){
    lines.push(JSON.stringify({ personality:{ ethical_alignment: 0.5, empathy:0.5 }, econSignals:{ frenRevenueNorm: Math.random(), marketVolatility:0.1, demandIndex:0.2 }, vector:[0.1,0.2,0.3,0.4,0.5,0.6] }));
  }
  fs.writeFileSync(path, lines.join('\n'));
}

function testCap(){
  const datasetPath = 'test-cap-dataset.jsonl';
  makeDummyDataset(datasetPath, 2000);
  process.env.SERAPHINA_DATASET_PATH = datasetPath;
  process.env.MAX_RESERVOIR = '500';
  const res = run();
  if(!res || !res.scoreboard){ console.error('FAIL: no scoreboard produced'); process.exit(1); }
  const sc = res.scoreboard;
  const passedLen = sc.datasetSize === 500;
  const flagCorrect = sc.reservoirCap === true;
  if(passedLen && flagCorrect){
    console.log('PASS dataset cap enforced size=500 flag='+sc.reservoirCap);
  } else {
    console.error('FAIL size='+sc.datasetSize+' flag='+sc.reservoirCap);
    process.exit(1);
  }
}

if(require.main === module){
  testCap();
}
