// verify-rvn-address.js
// Lightweight Ravencoin Base58Check address validator (P2PKH/P2SH)
// Usage: node verify-rvn-address.js RAddress

const crypto = require('crypto');

const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
const MAP = {}; for (let i=0;i<ALPHABET.length;i++) MAP[ALPHABET[i]] = i;

function sha256(b){ return crypto.createHash('sha256').update(b).digest(); }

function decodeBase58Check(addr){
  if (!addr || typeof addr !== 'string') return null;
  let x = BigInt(0);
  for (const ch of addr){
    const v = MAP[ch]; if (v===undefined) return null; x = x*BigInt(58) + BigInt(v);
  }
  let bytes = [];
  while (x>0){ bytes.push(Number(x % BigInt(256))); x = x / BigInt(256); }
  bytes = bytes.reverse();
  // leading zeros
  for (const c of addr){ if (c==='1') bytes.unshift(0); else break; }
  if (bytes.length < 5) return null;
  const data = Buffer.from(bytes.slice(0, -4));
  const checksum = Buffer.from(bytes.slice(-4));
  const hash = sha256(sha256(data));
  if (!hash.slice(0,4).equals(checksum)) return null;
  return data; // version + payload
}

function classify(addr){
  const buf = decodeBase58Check(addr);
  if(!buf) return { valid:false, reason:'checksum' };
  const ver = buf[0];
  // Ravencoin P2PKH = 0x3c (R), P2SH = 0x7a historically; new bech32 rvn1 forms not handled here.
  if (ver===0x3c) return { valid:true, type:'P2PKH' };
  if (ver===0x7a) return { valid:true, type:'P2SH' };
  return { valid:false, reason:'version '+ver };
}

if (require.main === module){
  const addr = process.argv[2];
  const res = classify(addr);
  if (res.valid){ console.log('VALID', res.type); process.exit(0); }
  else { console.log('INVALID', res.reason); process.exit(2); }
}

module.exports = { classify };
