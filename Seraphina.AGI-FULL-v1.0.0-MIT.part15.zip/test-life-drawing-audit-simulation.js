#!/usr/bin/env node
// test-life-drawing-audit-simulation.js
// Ensures audit simulation produces non-zero slope for at least one severity (typically 'high').
'use strict';
const { computeTrend } = require('./life-drawing-audit-trend');
const path = require('path');
const fs = require('fs');

function runSimulationIfNeeded(){
  const histPath = path.join(__dirname,'life-drawing-audit-history.jsonl');
  let lines = [];
  if(fs.existsSync(histPath)){
    lines = fs.readFileSync(histPath,'utf8').trim().split(/\n+/).filter(Boolean);
  }
  // If fewer than 8 entries, invoke simulator for deterministic enrichment.
  if(lines.length < 8){
    const simPath = path.join(__dirname,'life-drawing-audit-simulate.js');
    if(fs.existsSync(simPath)){
      const out = require(simPath).runSimulation? require(simPath).runSimulation(): null;
      return { simulated:true, result: out };
    }
  }
  return { simulated:false };
}

function main(){
  const sim = runSimulationIfNeeded();
  const trend = computeTrend();
  const high = trend.ok? trend.severities.find(s=> s.severity === 'high') : null;
  const passed = !!(high && typeof high.slope === 'number' && high.slope !== 0);
  const resp = { ok: trend.ok && passed, simulated: sim.simulated, slope: high? high.slope: null, entries: trend.count };
  if(!passed){
    console.error('[FAIL] Expected non-zero high severity slope');
    process.exitCode = 1;
  } else {
    console.log('[PASS] Non-zero high severity slope');
  }
  console.log(JSON.stringify(resp,null,2));
}

if(require.main === module){
  main();
}

module.exports = { main };