// test-ledger-rotate.js
// Verifies streaming ledger rotation creates .gz and resets ledger genesis marker.
// Usage: SERAPHINA_LEDGER_COMPRESS=1 SERAPHINA_LEDGER_CHUNK_MB=1 node test-ledger-rotate.js

const fs = require('fs');
const path = require('path');
const { rotateTrainLedgerIfNeeded } = require('./seraphina-model-train-ledger-rotate');

async function makeLedger(pathName, approxBytes){
  const line = JSON.stringify({ ts:Date.now(), acc:Math.random(), chainHash:'x' });
  const lines = [];
  const perLine = Buffer.byteLength(line+'\n');
  const count = Math.ceil(approxBytes / perLine);
  for(let i=0;i<count;i++){ lines.push(line); }
  fs.writeFileSync(pathName, lines.join('\n')+'\n');
}

async function testRotation(){
  const ledgerPath = 'rotate-test-ledger.jsonl';
  await makeLedger(ledgerPath, 2*1024*1024); // 2MB
  process.env.SERAPHINA_LEDGER_COMPRESS='1';
  process.env.SERAPHINA_LEDGER_CHUNK_MB='1';
  const rotated = await rotateTrainLedgerIfNeeded(ledgerPath);
  if(!rotated){ console.error('FAIL: rotation not triggered'); process.exit(1); }
  const files = fs.readdirSync('.');
  const gzFile = files.find(f => f.startsWith(ledgerPath+'.') && f.endsWith('.gz'));
  if(!gzFile){ console.error('FAIL: gz file not found'); process.exit(1); }
  const genesis = fs.readFileSync(ledgerPath,'utf8').split(/\n+/)[0];
  let genesisObj=null; try { genesisObj = JSON.parse(genesis); } catch(e){ }
  if(!genesisObj || !genesisObj.rotated){ console.error('FAIL: ledger genesis not marked rotated'); process.exit(1); }
  console.log('PASS ledger rotation gz='+gzFile+' compressedHash='+genesisObj.compressedHash);
}

if(require.main === module){
  testRotation();
}
