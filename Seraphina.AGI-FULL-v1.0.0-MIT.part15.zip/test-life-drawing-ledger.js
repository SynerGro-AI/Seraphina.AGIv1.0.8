// test-life-drawing-ledger.js
'use strict';
const { inspect } = require('./life-drawing-ledger-inspect');
function run(){
  const result = inspect({ minScore:0, sinceMs: Date.now() - 24*3600000, limit:5 });
  console.log(JSON.stringify(result,null,2));
}
if(require.main === module){ run(); }
module.exports = { run };
