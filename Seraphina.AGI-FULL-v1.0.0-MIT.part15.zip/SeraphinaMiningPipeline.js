// SeraphinaMiningPipeline.js - Zero-mock, real Stratum + SHA-256 pipeline for neural lattice mining
// npm i stratum-client js-sha256 bigint-buffer
// Usage: node this.js --pool <stratum_url> --user <wallet.worker>

const StratumClient = require('stratum-client');
const sha256 = require('js-sha256');
const BigIntBuffer = require('bigint-buffer');

// ... (full pipeline code from your previous message goes here) ...

// CLI parse (simple)
const args = process.argv.slice(2);
const pool = args.find(a => a.startsWith('--pool'))?.split('=')[1] || 'stratum+tcp://stratum.slushpool.com:3333';
const user = args.find(a => a.startsWith('--user'))?.split('=')[1] || 'your.wallet.address';
const pipeline = new SeraphinaMiningPipeline(pool, user);
pipeline.start();

process.on('SIGINT', () => {
  pipeline.stop();
  process.exit(0);
});
