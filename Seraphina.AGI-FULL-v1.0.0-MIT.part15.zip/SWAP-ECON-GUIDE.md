# Swap & Economic Engine Guide

## 1. Overview
The economic subsystem (ECON) blends external price + difficulty data to guide coin selection and provide valuation for swap PnL accounting. The swap subsystem converts mined non-target assets (e.g. RVN) into a strategic asset (e.g. BTC) with deterministic integrity logging and risk controls.

## 2. Data Sources
- Coingecko simple price (USD) – baseline.
- Kraken public ticker (optional) – overrides / supplements where live and plausible.
- Network difficulty endpoints per coin.
- Fallback deterministic pricing (Kraken hash fallback) ensures continuity if providers fail.

## 3. Hysteresis & Recommendation
Scores = price[c] / diff[c]. Hysteresis requires N consecutive cycles (`ECON_HYSTERESIS_CYCLES`) of the same best coin before switching recommendation to reduce churn.

## 4. Swap Flow
1. Threshold Check: For each route coin->target if balance >= threshold.
2. Quote: Adapter retrieves deterministic dry-run rate (hash-based) or live SimpleSwap rate.
3. Execute: On success ledger entries: share-ledger unaffected; swap-ledger records `auto_execute`.
4. Status Poll: Updates swap-ledger with `status` transitions; settlement triggers econ realization entry.

## 5. Ledgers Involved
| Ledger | Purpose |
|--------|---------|
| share-ledger.jsonl | Proof of accepted shares & estimated credits. |
| parity-ledger.jsonl | Normalized difficulty cross-coin comparability. |
| swap-ledger.jsonl | Lifecycle events of quotes/executions/status. |
| econ-realization-ledger.jsonl | PnL snapshots for executed & settled swaps. |
| price-ledger.jsonl (opt) | Auditable blended price snapshots. |

Each ledger: hash chain + optional HMAC, enabling tamper detection.

## 6. Risk Controls
- Rate Limiting: SWAP_MAX_WINDOW_COUNT within SWAP_RISK_WINDOW_MS.
- Failure Circuit: SWAP_FAIL_LIMIT triggers circuit open; optional auto-reset via SWAP_CIRCUIT_AUTO_RESET_MS.
- Manual Controls: SWAP_CIRCUIT_FORCE_OPEN / FORCE_CLOSE.

## 7. Valuation & PnL
- Pre-swap USD value = amountFrom * usdFrom.
- Realized USD value (at settlement) = (amountFrom * rateUsed) * usdTo.
- PnL delta = realizedUSD - preCreditUSD; recorded at settlement.
- Negative PnL indicates slippage or adverse rate movement.

## 8. Deterministic Fallback Philosophy
- When live data unavailable, hash-derived synthetic numbers keep system moving without randomness.
- All fallback computations are reproducible given the same seed and input strings.

## 9. Configuration Summary
| Variable | Role |
|----------|------|
| RVN_SWAP_THRESHOLD | Balance trigger (RVN). |
| SIMPLESWAP_MODE / SIMPLESWAP_LIVE | Auto mode & live enable flag. |
| SIMPLESWAP_API_KEY | Live swap credential. |
| SWAP_RISK_WINDOW_MS / SWAP_MAX_WINDOW_COUNT | Rate limit window & count. |
| SWAP_FAIL_LIMIT | Circuit open threshold on consecutive fails. |
| SWAP_AUTO_INTERVAL_MS | Evaluation interval. |
| KRAKEN_FEED_ENABLED | Enables Kraken blending. |
| ECON_INTERVAL_MS | Price/diff refresh cadence. |

## 10. Operational Monitoring
Check endpoints:
- `/report/summary` – balances, scores, PnL aggregate.
- `/report/pnl` – detailed PnL entries.
- `/readiness` – ledger integrity + circuit state.

Alert Conditions:
- readiness.ok false.
- circuitOpen true > X minutes.
- PnL cumulative negative beyond risk tolerance.

## 11. Scaling & Multi-Coin Strategy
Run separate rigs focusing on best coin; aggregated parity & PnL across rigs yields global optimization. A central orchestrator can feed consolidated recommendation if governance approves.

## 12. Future Enhancements
- Slippage tolerance enforcement (pre-quote vs execution delta guard).
- Median-of-providers price feed with quorum threshold.
- Adaptive threshold raising under high failure or volatility.

---
End Swap & Econ Guide.
