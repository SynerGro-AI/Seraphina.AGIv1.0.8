#!/usr/bin/env bash
# validate-hybrid-iso.sh: Basic validation for hybrid mining ISO artifacts.
# Usage: ./validate-hybrid-iso.sh octalang-mining.iso
set -euo pipefail
ISO="${1:-octalang-mining.iso}"
if [[ ! -f "$ISO" ]]; then echo "[ERROR] ISO not found: $ISO" >&2; exit 1; fi

VOL_ID=$(isoinfo -d -i "$ISO" 2>/dev/null | awk -F': ' '/Volume id:/ {print $2}') || VOL_ID="UNKNOWN"
SIZE=$(stat -c %s "$ISO")
echo "[INFO] Volume ID: $VOL_ID"; echo "[INFO] ISO Size: $SIZE bytes"

TMPDIR=$(mktemp -d)
mount -o loop "$ISO" "$TMPDIR" || { echo "[ERROR] Failed to mount ISO"; exit 1; }
MISSING=()
for f in boot/bzImage boot/initramfs-seraphina.img boot/octalang/triad_miner.js preseed.cfg; do
  if [[ ! -f "$TMPDIR/$f" ]]; then MISSING+=("$f"); fi
  done
if (( ${#MISSING[@]} > 0 )); then
  echo "[WARN] Missing files: ${MISSING[*]}"
else
  echo "[OK] All expected files present"
fi
umount "$TMPDIR" || true
rm -rf "$TMPDIR"

if [[ $SIZE -lt 200000000 ]]; then
  echo "[WARN] ISO unusually small (<200MB)."
fi
if [[ $SIZE -gt 5000000000 ]]; then
  echo "[WARN] ISO unusually large (>5GB)."
fi

echo "[INFO] Validation complete."