# SERAPHINA OCTALANG PERSISTENT MINING LAUNCHER
# Compatible with OctaLang compiler and text-based emoji format

param(
    [switch]$Restart = $false,
    [switch]$OctaLang = $false
)

# Set window properties for persistence
$Host.UI.RawUI.WindowTitle = "SERAPHINA OCTALANG PERSISTENT MINING - KEEP OPEN FOR EARNINGS"
$Host.UI.RawUI.BackgroundColor = "DarkBlue"
$Host.UI.RawUI.ForegroundColor = "White"

# Clear screen and show persistent header
Clear-Host

Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║         [STAR] SERAPHINA OCTALANG MINING SYSTEM [STAR]        ║" -ForegroundColor Cyan  
Write-Host "╠══════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "║  [FLOPPY_DISK] PERSISTENT STORAGE: All earnings saved         ║" -ForegroundColor Green
Write-Host "║  [LOCK] WINDOW PERSISTENCE: Designed to stay open             ║" -ForegroundColor Green
Write-Host "║  [BAR_CHART] DATA RECOVERY: Restores from crashes             ║" -ForegroundColor Green
Write-Host "║  [MONEY_BAG] WALLET PROTECTION: Real earnings never lost      ║" -ForegroundColor Green
Write-Host "║  [GEAR] OCTALANG COMPATIBLE: Text emoji format [CHECK_MARK]   ║" -ForegroundColor Yellow
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Function to check for OctaLang compiler
function Test-OctaLangCompiler {
    $compilerPaths = @(
        (Join-Path $PSScriptRoot "octalang.exe"),
        (Join-Path $PSScriptRoot "compiler" "octalang.exe"),
        (Join-Path $PSScriptRoot "bin" "octalang.exe")
    )
    
    foreach ($path in $compilerPaths) {
        if (Test-Path $path) {
            Write-Host "[CHECK_MARK] OctaLang compiler found: $path" -ForegroundColor Green
            return $path
        }
    }
    
    # Check if in PATH
    try {
        $null = Get-Command "octalang" -ErrorAction Stop
        Write-Host "[CHECK_MARK] OctaLang compiler found in PATH" -ForegroundColor Green
        return "octalang"
    } catch {
        Write-Host "[WARNING] OctaLang compiler not found" -ForegroundColor Yellow
        Write-Host "[INFO] Will run with Node.js instead" -ForegroundColor Cyan
        return $null
    }
}

# Function to compile OctaLang if available
function Invoke-OctaLangCompile {
    param([string]$CompilerPath, [string]$SourceFile)
    
    try {
        Write-Host "[GEAR] Compiling with OctaLang..." -ForegroundColor Yellow
        
        $outputFile = [System.IO.Path]::ChangeExtension($SourceFile, ".octa")
        
        if ($CompilerPath -eq "octalang") {
            $result = & octalang compile $SourceFile -o $outputFile 2>&1
        } else {
            $result = & $CompilerPath compile $SourceFile -o $outputFile 2>&1
        }
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[CHECK_MARK] OctaLang compilation successful" -ForegroundColor Green
            return $outputFile
        } else {
            Write-Host "[CROSS_MARK] OctaLang compilation failed: $result" -ForegroundColor Red
            return $null
        }
    } catch {
        Write-Host "[CROSS_MARK] OctaLang compilation error: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# Function to check and create persistent data directory
function Initialize-PersistentStorage {
    $dataDir = Join-Path $PSScriptRoot "persistent_data"
    if (-not (Test-Path $dataDir)) {
        New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
        Write-Host "[FOLDER] Created persistent data directory: $dataDir" -ForegroundColor Yellow
    }
    
    # Create initial state files if they don't exist
    $files = @("wallet_earnings.json", "wallet_backup.json", "session_log.json")
    foreach ($file in $files) {
        $filePath = Join-Path $dataDir $file
        if (-not (Test-Path $filePath)) {
            '{}' | Out-File -FilePath $filePath -Encoding UTF8
            Write-Host "[PAGE_FACING_UP] Initialized: $file" -ForegroundColor Gray
        }
    }
}

# Function to show persistent storage status
function Show-PersistentStatus {
    $dataDir = Join-Path $PSScriptRoot "persistent_data"
    
    Write-Host "[FLOPPY_DISK] === PERSISTENT STORAGE STATUS ===" -ForegroundColor Yellow
    
    # Check wallet state
    $walletFile = Join-Path $dataDir "wallet_earnings.json"
    if (Test-Path $walletFile) {
        $walletSize = (Get-Item $walletFile).Length
        Write-Host "   [MONEY_BAG] Wallet Earnings: $walletSize bytes" -ForegroundColor Green
    }
    
    # Check backup
    $backupFile = Join-Path $dataDir "wallet_backup.json" 
    if (Test-Path $backupFile) {
        $backupSize = (Get-Item $backupFile).Length
        Write-Host "   [SHIELD] Backup File: $backupSize bytes" -ForegroundColor Green
    }
    
    # Check session log
    $sessionFile = Join-Path $dataDir "session_log.json"
    if (Test-Path $sessionFile) {
        $sessionSize = (Get-Item $sessionFile).Length
        Write-Host "   [CLIPBOARD] Session Log: $sessionSize bytes" -ForegroundColor Green
    }
    
    Write-Host "[FLOPPY_DISK] ==================================" -ForegroundColor Yellow
    Write-Host ""
}

# Function to run mining with OctaLang or Node.js
function Start-PersistentMining {
    param([bool]$IsRestart = $false)
    
    $miningScript = Join-Path $PSScriptRoot "seraphina-persistent-mining.js"
    
    if (-not (Test-Path $miningScript)) {
        Write-Host "[CROSS_MARK] Mining script not found: $miningScript" -ForegroundColor Red
        Write-Host "[FOLDER] Make sure all files are in the same directory" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        return
    }
    
    # Check for OctaLang compiler
    $octaCompiler = Test-OctaLangCompiler
    $compiledScript = $null
    
    if ($octaCompiler -and $OctaLang) {
        $compiledScript = Invoke-OctaLangCompile -CompilerPath $octaCompiler -SourceFile $miningScript
    }
    
    # Show restart info if applicable
    if ($IsRestart) {
        Write-Host "[ARROWS_COUNTERCLOCKWISE] RESTARTING MINING WITH PRESERVED DATA..." -ForegroundColor Cyan
        Write-Host "[FLOPPY_DISK] Previous earnings and state will be restored" -ForegroundColor Green
        Write-Host ""
    }
    
    # Show current persistent status
    Show-PersistentStatus
    
    # Start mining with error handling and persistence
    while ($true) {
        try {
            Write-Host "[ROCKET] STARTING PERSISTENT MINING OPERATION..." -ForegroundColor Green
            Write-Host "[LOCK] Window persistence: ACTIVE" -ForegroundColor Yellow
            Write-Host "[FLOPPY_DISK] Data persistence: ACTIVE" -ForegroundColor Yellow
            Write-Host "[SHIELD] Crash recovery: ENABLED" -ForegroundColor Yellow
            
            if ($compiledScript) {
                Write-Host "[GEAR] Running compiled OctaLang version" -ForegroundColor Cyan
                & $octaCompiler run $compiledScript
            } else {
                Write-Host "[GLOBE_WITH_MERIDIANS] Running with Node.js" -ForegroundColor Cyan
                & node $miningScript
            }
            
            # If we get here, mining stopped normally
            Write-Host ""
            Write-Host "[INFO] Mining process ended normally" -ForegroundColor Yellow
            
        } catch {
            # Handle errors with data preservation
            Write-Host ""
            Write-Host "[CROSS_MARK] ERROR OCCURRED: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "[FLOPPY_DISK] Your earnings data is still safe!" -ForegroundColor Green
        }
        
        # Show restart options
        Write-Host ""
        Write-Host "[ARROWS_COUNTERCLOCKWISE] === RESTART OPTIONS ===" -ForegroundColor Cyan
        Write-Host "1. Restart mining (recommended)" -ForegroundColor White
        Write-Host "2. Check persistent data status" -ForegroundColor White  
        Write-Host "3. Toggle OctaLang compilation" -ForegroundColor White
        Write-Host "4. Graceful shutdown" -ForegroundColor White
        Write-Host ""
        
        $choice = Read-Host "Enter choice (1-4) or press Enter for auto-restart in 10 seconds"
        
        if ([string]::IsNullOrEmpty($choice)) {
            Write-Host "[ARROWS_COUNTERCLOCKWISE] Auto-restarting in 10 seconds..." -ForegroundColor Yellow
            for ($i = 10; $i -gt 0; $i--) {
                Write-Host "   Restarting in $i..." -ForegroundColor Gray
                Start-Sleep -Seconds 1
            }
            Write-Host "[ARROWS_COUNTERCLOCKWISE] RESTARTING NOW..." -ForegroundColor Green
            continue
        }
        
        switch ($choice) {
            "1" { 
                Write-Host "[ARROWS_COUNTERCLOCKWISE] Restarting mining..." -ForegroundColor Green
                continue
            }
            "2" { 
                Show-PersistentStatus
                Read-Host "Press Enter to continue"
                continue
            }
            "3" {
                $script:OctaLang = -not $OctaLang
                $status = if ($OctaLang) { "ENABLED" } else { "DISABLED" }
                Write-Host "[GEAR] OctaLang compilation: $status" -ForegroundColor Yellow
                continue
            }
            "4" { 
                Write-Host "[FLOPPY_DISK] Graceful shutdown initiated..." -ForegroundColor Yellow
                return
            }
            default {
                Write-Host "[CROSS_MARK] Invalid choice. Auto-restarting..." -ForegroundColor Red
                Start-Sleep -Seconds 2
                continue
            }
        }
    }
}

# Main execution
try {
    # Set execution policy for this session
    Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force
    
    # Initialize persistent storage
    Initialize-PersistentStorage
    
    # Check for Node.js
    try {
        $nodeVersion = & node --version 2>$null
        Write-Host "[CHECK_MARK] Node.js detected: $nodeVersion" -ForegroundColor Green
    } catch {
        Write-Host "[CROSS_MARK] Node.js not found. Please install Node.js first." -ForegroundColor Red
        Write-Host "[GLOBE_WITH_MERIDIANS] Download from: https://nodejs.org/" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    # Show wallet information
    Write-Host "[MONEY_BAG] === WALLET CONFIGURATION ===" -ForegroundColor Yellow
    Write-Host "   [BANK] BTC -> Kraken Pro: 34XctrDk5T32VxMB12nbTDbZhCNcnhZLzf" -ForegroundColor Green
    Write-Host "   [HOUSE] RVN -> Local Wallet: RN8pfAiHrggo4YcfPzE8MuntvFVZqmYQy7" -ForegroundColor Green
    Write-Host "[MONEY_BAG] ===============================" -ForegroundColor Yellow
    Write-Host ""
    
    # Final confirmation
    Write-Host "[ROCKET] Ready to start persistent mining!" -ForegroundColor Green
    Write-Host "[BULB] This window will stay open and preserve all your earnings" -ForegroundColor Cyan
    Write-Host "[GEAR] OctaLang mode: $($OctaLang)" -ForegroundColor Yellow
    Write-Host ""
    
    if (-not $Restart) {
        Read-Host "Press Enter to start mining"
    }
    
    # Start the persistent mining system
    Start-PersistentMining -IsRestart $Restart
    
} catch {
    Write-Host ""
    Write-Host "[BOOM] CRITICAL ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "[FLOPPY_DISK] Check if persistent data is intact..." -ForegroundColor Yellow
    
    # Try to show storage status even on error
    try {
        Show-PersistentStatus
    } catch {
        Write-Host "[CROSS_MARK] Could not access persistent storage" -ForegroundColor Red
    }
    
    Read-Host "Press Enter to exit"
} finally {
    Write-Host ""
    Write-Host "[WAVING_HAND] Seraphina's Persistent Mining System shutdown complete" -ForegroundColor Cyan
}