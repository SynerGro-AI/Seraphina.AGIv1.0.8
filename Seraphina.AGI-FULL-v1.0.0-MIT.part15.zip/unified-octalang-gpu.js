#!/usr/bin/env node
'use strict';
// unified-octalang-gpu.js
// Unified OctaLang build + visualization + Merkle provenance ledger (pure JS, no external deps).
// NOTE: WebGL operations are stubbed for Node environment; browser execution would supply a real canvas.
// CLI Flags:
//   --cull=<num>          Set initial frame cull threshold
//   --adapt               Enable adaptive threshold tuning
//   --forceN=<int>        Force retain every Nth frame
//   --lock                Lock threshold after first adaptation
//   --hist=<path>         Write frame distance histogram JSON
//   --securitySnapshot=<path>  Path for security heuristics snapshot digest correlation
//   --no-ws               Disable WebSocket multiplayer entirely
//   --wsPort=<port>       Custom WebSocket port (default 8080)
//   --frames=<N>          Override animation frame count (default 32)
//   --frameProv           Enable per-frame ham provenance records (JSONL)
// Example provenance generation without WS conflict:
//   $env:SERAPHINA_CODER_PROVENANCE_PATH="provenance-cull.jsonl"
//   node .\unified-octalang-gpu.js --adapt --lock --no-ws --frames=48

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
let WebSocketServer = null; try { WebSocketServer = require('ws').Server; } catch(_e){ /* optional */ }
let PromClient = null; try { PromClient = require('prom-client'); } catch(_e){ /* optional metrics */ }

// Pure JS SHA-256 helper (sync) using Node crypto
function sha256(data){ return crypto.createHash('sha256').update(data).digest('hex'); }

class MerkleLedger {
  constructor(){
    this.leaves = []; // array of leaf hashes (hex)
    this.levels = []; // levels[0] = leaves, last = root level
    this.root = null;
  }
  addLeaf(payload){
    const leafHash = sha256(typeof payload === 'string'? payload : JSON.stringify(payload));
    this.leaves.push(leafHash);
    this.rebuild();
    return leafHash;
  }
  rebuild(){
    let level = this.leaves.slice();
    const levels = [ level ];
    while(level.length > 1){
      const next = [];
      for(let i=0;i<level.length;i+=2){
        const left = level[i];
        const right = level[i+1] || left; // duplicate last if odd
        next.push(sha256(left + right));
      }
      levels.push(next);
      level = next;
    }
    this.levels = levels;
    this.root = level[0] || null;
  }
  verifyRoot(root){ return this.root === root; }
  size(){ return this.leaves.length; }
}

class HammingMonitor {
  constructor(){
    this.prevDigest = null; // previous hex digest
    this.diffLedger = []; // { ts, hamming, type, note, prev, curr }
  }
  // Convert hex digests to BigInt and compute normalized bit distance over 256 bits
  hamming256(aHex, bHex){
    if(!aHex || !bHex) return 0;
    const a = BigInt('0x'+aHex);
    const b = BigInt('0x'+bHex);
    let xor = a ^ b;
    let dist = 0n;
    while(xor){ dist += xor & 1n; xor >>= 1n; }
    const bits = 256n; // SHA-256 length
    return Number(dist) / Number(bits);
  }
  monitor(digest, type='frame', note=''){ if(this.prevDigest){ const h = this.hamming256(this.prevDigest, digest); this.diffLedger.push({ ts:Date.now(), hamming:h, type, note, prev:this.prevDigest, curr:digest }); if(h > 0.12) console.warn('[HammingMonitor][DIVERGENCE]', h.toFixed(4), type, note); else console.log('[HammingMonitor][diff]', type, h.toFixed(4), note||'stable'); } this.prevDigest = digest; return this.diffLedger.slice(-12); }
  health(){ if(!this.diffLedger.length) return 'init'; const avg = this.diffLedger.reduce((s,d)=> s + d.hamming,0)/this.diffLedger.length; if(avg < 0.05) return 'healthy'; if(avg < 0.12) return 'caution'; return 'critical'; }
}

class UnifiedOctaLangGPU {
  constructor(options={}){
    this.projectDir = options.projectDir || process.cwd();
    this.domain = options.domain || 'localhost';
    this.appName = options.appName || 'OctaApp';
    this.octaml5File = 'octalang_scene.octaml5';
    this.frameRoots = []; // per-frame leaf hashes
    this.ledger = new MerkleLedger();
    this.wsServer = null;
    this.lattice = this.initLattice();
    this.phi = (1 + Math.sqrt(5)) / 2;
    this.hammingMonitor = new HammingMonitor();
    // Frame culling threshold (normalized hamming distance 0..1). Read from env or options.
    this.frameCullThreshold = this.resolveFrameCullThreshold(options.frameCullThreshold);
    this.cullStats = { total:0, written:0, culled:0, threshold:this.frameCullThreshold, ratio:0 };
    this.provenancePath = process.env.SERAPHINA_CODER_PROVENANCE_PATH || null;
    // Adaptive & retention controls
    this.adaptEnabled = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_CULL_ADAPT || '');
    this.forceInterval = parseInt(process.env.SERAPHINA_FRAME_FORCE_N || '0',10); // 0 disables forced retention
    this.agentAnnotate = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_AGENT_ANNOTATE || '');
    this.recentWrittenDistances = []; // rolling window for adaptive median calculations
    this.cullLockEnabled = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_CULL_LOCK || '');
    this.cullLocked = false; // becomes true after first adaptation if lock enabled
    this.securityHeuristicsPath = process.env.SERAPHINA_SECURITY_HEURISTICS_PATH || null; // optional heuristics snapshot file
    this.histPath = process.env.SERAPHINA_FRAME_CULL_HIST_PATH || null; // histogram output path
    this.forcedRetentionHits = 0;
    this.lastMedian = null;
    this.lastThresholdBeforeAdapt = this.frameCullThreshold;
  // Rolling provenance integrity chain
  this.chainPrev = null; // previous chain hash
  this.chainHmacKey = process.env.SERAPHINA_CHAIN_HMAC_KEY || null;
  // Multi-series hamming separation accumulators
  this.hamSeries = { frame: [], root: [], cull: [] };
  // Frame-level provenance opt-in & vertex quantization (adaptive ready)
  this.frameProvEnabled = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_PROV || '');
  this.vertexDecimals = parseInt(process.env.SERAPHINA_FRAME_VERTEX_DEC || '3',10);
  if(!Number.isFinite(this.vertexDecimals) || this.vertexDecimals < 0 || this.vertexDecimals > 12) this.vertexDecimals = 3;
  this.vertexDecMin = parseInt(process.env.SERAPHINA_FRAME_VERTEX_DEC_MIN || '2',10);
  this.vertexDecMax = parseInt(process.env.SERAPHINA_FRAME_VERTEX_DEC_MAX || '6',10);
  if(this.vertexDecMin < 0) this.vertexDecMin = 0; if(this.vertexDecMax > 12) this.vertexDecMax = 12;
  if(this.vertexDecMin > this.vertexDecMax) this.vertexDecMin = this.vertexDecMax;
  this.vertexDecAdapt = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_VERTEX_DEC_ADAPT || '');
  this.vertexVarWindow = [];
  // Compression config
  this.compressEnabled = /^(1|true)$/i.test(process.env.SERAPHINA_FRAME_COMPRESS || '');
  this.compressHamThresh = parseFloat(process.env.SERAPHINA_FRAME_COMPRESS_HAM || '0.003');
  if(!Number.isFinite(this.compressHamThresh) || this.compressHamThresh < 0) this.compressHamThresh = 0.003;
  this.compressBuffer = []; // grouped low-diff frames
  // Adapt proof gating flags
  this.lockLeafAdded = false;
  this.adaptProofDisabled = false;
    // Prometheus metrics (optional)
    if(PromClient){
      this.metricThreshold = new PromClient.Gauge({ name:'seraphina_frame_cull_threshold', help:'Current frame cull threshold' });
      this.metricMedian = new PromClient.Gauge({ name:'seraphina_frame_cull_median', help:'Rolling median of written frame distances' });
      this.metricForcedRetentions = new PromClient.Counter({ name:'seraphina_frame_forced_retentions_total', help:'Total forced retained frames' });
      this.metricCullLocked = new PromClient.Gauge({ name:'seraphina_frame_cull_locked', help:'Cull threshold locked (1/0)' });
      this.metricAdaptEvents = new PromClient.Counter({ name:'seraphina_frame_cull_adapt_events_total', help:'Adaptation events counted' });
      this.metricHamFrameAvg = new PromClient.Gauge({ name:'seraphina_ham_frame_avg', help:'Average hamming distance of frame series' });
      this.metricHamRootAvg = new PromClient.Gauge({ name:'seraphina_ham_root_avg', help:'Average hamming distance of root series' });
      this.metricHamCullAvg = new PromClient.Gauge({ name:'seraphina_ham_cull_avg', help:'Average hamming distance of culled frame series' });
      this.metricVertexDecimals = new PromClient.Gauge({ name:'seraphina_vertex_decimals', help:'Current vertex quantization decimals' });
      this.metricThreshold.set(this.frameCullThreshold);
      this.metricCullLocked.set(0);
      this.metricVertexDecimals.set(this.vertexDecimals);
    }
    this.metricsPort = parseInt(process.env.SERAPHINA_METRICS_PORT || '0',10);
    if(PromClient && this.metricsPort > 0){
      try {
        const http = require('http');
        http.createServer((req,res)=>{
          if(req.url === '/metrics'){
            res.writeHead(200, { 'Content-Type':'text/plain' });
            res.end(PromClient.register.metrics());
          } else {
            res.writeHead(404); res.end('not found');
          }
        }).listen(this.metricsPort);
        console.log('[Metrics] Prometheus endpoint on port', this.metricsPort);
      } catch(e){ console.warn('[Metrics][WARN]', e.message); }
    }
  }
  initLattice(){
    return Array.from({ length: 8 }, (_, i) => ({
      component: ['parser','geometry','physics','neural','compiler','runtime','package','docs'][i],
      status: 'pending',
      idx: i
    }));
  }
  resolveFrameCullThreshold(override){
    if(typeof override === 'number' && override >= 0) return override;
    const envVal = process.env.SERAPHINA_FRAME_CULL_HAM;
    if(envVal){
      const v = parseFloat(envVal);
      if(Number.isFinite(v) && v >= 0 && v <= 1) return v;
    }
    return 0.01; // default small diff threshold
  }
  getFrameCullThreshold(){ return this.frameCullThreshold; }
  frameDistance(prevHash, currHash){
    if(!prevHash) return 1; // ensure first frame always written
    return this.hammingMonitor.hamming256(prevHash, currHash);
  }
  appendProvenance(record){
    if(!this.provenancePath) return;
    try {
      // Inject rolling chain fields
      const payloadStr = JSON.stringify(record);
      const chainDigest = sha256(payloadStr);
      const chainHash = sha256((this.chainPrev||'') + ':' + chainDigest);
      let chainHmac = null;
      if(this.chainHmacKey){
        try { chainHmac = crypto.createHmac('sha256', this.chainHmacKey).update(chainHash).digest('hex'); } catch(_e){ /* ignore */ }
      }
      const chainedRecord = { ...record, chainPrev: this.chainPrev, chainDigest, chainHash, chainHmac };
      fs.appendFileSync(this.provenancePath, JSON.stringify(chainedRecord) + '\n');
      this.chainPrev = chainHash;
    } catch(e){ console.warn('[UnifiedOctaLangGPU][provenance][WARN]', e.message); }
  }
  setupMultiplayer(){
    if(!WebSocketServer){ console.warn('[MerkleWS] ws module not installed; skipping multiplayer'); return; }
    const port = this.wsPort || 8080;
    try {
      this.wsServer = new WebSocketServer({ port });
      this.wsServer.on('connection', ws => {
        ws.send(JSON.stringify({ type:'welcome', app:this.appName, merkleRoot: this.ledger.root }));
      });
      console.log('[MerkleWS] Server running ws://'+this.domain+':'+port);
      this.wsServer.on('error', err => {
        if(err && err.code === 'EADDRINUSE'){
          console.warn('[MerkleWS][WARN] Port', port, 'in use. Disabling multiplayer for this run.');
          try { this.wsServer.close(); } catch(_e){}
          this.wsServer = null;
        } else {
          console.warn('[MerkleWS][ERROR]', err.message);
        }
      });
    } catch(e){
      if(e.code === 'EADDRINUSE'){
        console.warn('[MerkleWS][WARN] Port', port, 'in use at startup. Skipping multiplayer.');
        this.wsServer = null;
      } else {
        console.warn('[MerkleWS][ERROR] Failed to start WS:', e.message);
        this.wsServer = null;
      }
    }
  }
  broadcastRoot(){
    if(!this.wsServer) return;
    const health = this.hammingMonitor.health();
    for(const client of this.wsServer.clients){
      try { client.send(JSON.stringify({ type:'merkleRoot', root:this.ledger.root, leaves:this.ledger.size(), health, cull:this.cullStats })); } catch(_e){}
    }
  }
  // Simple 4D vertices (tesseract) for deterministic projection
  tesseractVertices(){
    const base = [-1,1]; const verts=[];
    for(const a of base) for(const b of base) for(const c of base) for(const d of base) verts.push([a,b,c,d]);
    return verts;
  }
  project4D(angle=0){
    const c=Math.cos(angle), s=Math.sin(angle);
    const rot=[[c,-s,0,0],[s,c,0,0],[0,0,1,0],[0,0,0,1]];
    const verts = this.tesseractVertices();
    return verts.map(v=>{
      const r=[0,0,0,0];
      for(let i=0;i<4;i++){ for(let k=0;k<4;k++) r[i]+= v[k]*rot[i][k]; }
      const w = r[3] + 1e-8;
      return [r[0]/w, r[1]/w, r[2]/w];
    });
  }
  frameHash(frameIndex, proj){
    // Hash a compact string of projected vertices
    const data = proj.map(p=> p.map(x=> x.toFixed(this.vertexDecimals)).join(',')).join('|');
    return sha256(frameIndex+':'+data);
  }
  async ledgerOcta(input){
    // Process tiers from input (simplified token analysis)
    const tiers = {
      keywords: (input.match(/\b(parser|geometry|physics|neural|compiler|runtime)\b/g)||[]),
      emojis: (input.match(/[\u{1F300}-\u{1F6FF}]/gu)||[]),
      symbols: (input.match(/=>|->|\{\}|\(|\)/g)||[])
    };
    for(const [tier,data] of Object.entries(tiers)){
      this.ledger.addLeaf({ tier, count:data.length, digest: sha256(data.join('|')) });
    }
    // Color phase leaf (phi-based deterministic value)
    const phaseLeaf = { phase: 'phi', value: this.phi.toFixed(12) };
    this.ledger.addLeaf(phaseLeaf);
    console.log('[MerkleLedger] Root after grammar encode:', this.ledger.root);
    this.broadcastRoot();
    this.hammingMonitor.monitor(this.ledger.root, 'root', 'grammar encode');
    return this.ledger.root;
  }
  generateOctaml5(rootHash){
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<octaml5 provenance_root="${rootHash}">\n  <app name="${this.appName}" phi="${this.phi.toFixed(12)}"/>\n  <merkle leaves="${this.ledger.size()}" root="${rootHash}"/>\n</octaml5>`;
    fs.writeFileSync(path.join(this.projectDir, this.octaml5File), xml);
    console.log('[OctaML5] Wrote', this.octaml5File);
  }
  async buildAnimation(totalFrames=24){
    let prevWrittenHash = null;
    for(let f=0; f<totalFrames; f++){
      const angle = f * (Math.PI*2/totalFrames);
      const proj = this.project4D(angle);
      const h = this.frameHash(f, proj);
      this.cullStats.total++;
      const dist = this.frameDistance(prevWrittenHash, h);
      const forceRetain = this.forceInterval > 0 && (f % this.forceInterval === 0);
      const shouldCull = !forceRetain && (prevWrittenHash !== null) && dist < this.frameCullThreshold;
      if(shouldCull){
        this.cullStats.culled++;
        this.frameRoots.push({ frame:f, hash:h, culled:true, dist });
        console.log('[FrameCull] culled frame', f, 'dist=', dist.toFixed(6), '< threshold', this.frameCullThreshold);
        // Even if culled, still monitor digest evolution for analytics (type frame-cull)
        const diffFrameCull = this.hammingMonitor.monitor(h, 'frame-cull', 'culled frame diff');
        const diffRootCull = this.hammingMonitor.monitor(this.ledger.root, 'root', 'post-frame-cull');
        // Capture series distances
        const lastFrameCull = diffFrameCull.slice(-1)[0];
        const lastRootCull = diffRootCull.slice(-1)[0];
        if(lastFrameCull) this.hamSeries.cull.push(lastFrameCull.hamming);
        if(lastRootCull) this.hamSeries.root.push(lastRootCull.hamming);
      } else {
        this.cullStats.written++;
        this.frameRoots.push({ frame:f, hash:h, culled:false, dist, forced: forceRetain || undefined });
        this.ledger.addLeaf({ frame:f, hash:h });
        if(this.agentAnnotate && forceRetain){
          this.ledger.addLeaf({ agent:'forced-retention', frame:f, note:'Periodic retention to avoid starvation', dist });
        }
        if(forceRetain) this.forcedRetentionHits++;
        prevWrittenHash = h;
  const diffFrame = this.hammingMonitor.monitor(h, 'frame', 'tesseract projection');
  const diffRoot = this.hammingMonitor.monitor(this.ledger.root, 'root', 'post-frame');
  const lastFrame = diffFrame.slice(-1)[0];
  const lastRoot = diffRoot.slice(-1)[0];
  if(lastFrame) this.hamSeries.frame.push(lastFrame.hamming);
  if(lastRoot) this.hamSeries.root.push(lastRoot.hamming);
        // Adaptive threshold logic: update after a written (non-first) frame when enabled
        if(prevWrittenHash && dist !== 1){
          this.recentWrittenDistances.push(dist);
          if(this.recentWrittenDistances.length > 64) this.recentWrittenDistances.shift();
          // Adaptive quantization variance tracking
          if(this.vertexDecAdapt){
            this.vertexVarWindow.push(dist);
            if(this.vertexVarWindow.length > 32) this.vertexVarWindow.shift();
            const varAvg = this.vertexVarWindow.reduce((s,v)=>s+v,0)/(this.vertexVarWindow.length||1);
            // Simple heuristic: if average diff < threshold/2 tighten decimals downward, else if > threshold*4 widen decimals upward
            if(varAvg < this.frameCullThreshold/2 && this.vertexDecimals > this.vertexDecMin){ this.vertexDecimals--; if(PromClient){ this.metricVertexDecimals.set(this.vertexDecimals); } }
            else if(varAvg > this.frameCullThreshold*4 && this.vertexDecimals < this.vertexDecMax){ this.vertexDecimals++; if(PromClient){ this.metricVertexDecimals.set(this.vertexDecimals); } }
          }
          if(this.adaptEnabled && this.recentWrittenDistances.length >= 8){
            const sorted = [...this.recentWrittenDistances].sort((a,b)=>a-b);
            const mid = Math.floor(sorted.length/2);
            const median = sorted.length % 2 ? sorted[mid] : (sorted[mid-1]+sorted[mid])/2;
            const target = median * 0.7;
            const old = this.frameCullThreshold;
            this.lastMedian = median;
            this.lastThresholdBeforeAdapt = old;
            // Integrity proof leaf before shift (hash of sorted distances)
            if(!this.cullLocked && !this.adaptProofDisabled){
              const proofArray = sorted.map(x=> Number.isFinite(x)? Number(x.toFixed(12)) : x);
              const proofPayload = { adaptProof: sha256(JSON.stringify(proofArray)), count: sorted.length, median: median };
              this.ledger.addLeaf(proofPayload);
              this.appendProvenance({ ts: Date.now(), type:'adaptProof', adaptProof: proofPayload.adaptProof, count: proofPayload.count, median: proofPayload.median, distances: sorted });
            }
            // Lock check
            if(!this.cullLocked){
            this.frameCullThreshold = Math.min(0.5, Math.max(0.0001, old * 0.9 + target * 0.1));
            if(Math.abs(this.frameCullThreshold - old) > 1e-6){
              console.log('[FrameCull][ADAPT] median=', median.toFixed(6), 'oldThresh=', old.toFixed(6), 'newThresh=', this.frameCullThreshold.toFixed(6));
              if(PromClient){ this.metricAdaptEvents.inc(); }
              // Correlate security heuristics snapshot if threshold jump > 20% relative
              const relJump = (this.frameCullThreshold - old) / (old || 1);
              if(relJump > 0.2){
                let securitySnapshot = null;
                if(this.securityHeuristicsPath){
                  try { securitySnapshot = JSON.parse(fs.readFileSync(this.securityHeuristicsPath,'utf8')); } catch(e){ securitySnapshot = { readError: e.message }; }
                }
                this.ledger.addLeaf({ securityCorrelation:{ relJump, old, new:this.frameCullThreshold, median, snapshotDigest: securitySnapshot? sha256(JSON.stringify(securitySnapshot)) : null } });
              }
            }
            if(this.cullLockEnabled){ this.cullLocked = true; if(PromClient){ this.metricCullLocked.set(1); } }
            if(this.cullLocked && !this.lockLeafAdded){
              this.ledger.addLeaf({ cullLock:{ threshold: this.frameCullThreshold, median } });
              this.lockLeafAdded = true;
              this.adaptProofDisabled = true; // gate future adaptProof leaves
            }
            if(PromClient){ this.metricMedian.set(median); this.metricThreshold.set(this.frameCullThreshold); }
            } else {
              // Locked: threshold frozen, record lock event leaf once
              if(!this.lockLeafAdded){ this.ledger.addLeaf({ cullLock:{ threshold: this.frameCullThreshold, median } }); this.lockLeafAdded = true; }
            }
          }
        }
      }
      // Compression grouping of low-diff frames (even culled ones) if enabled
      if(this.compressEnabled){
        if(dist < this.compressHamThresh){
          this.compressBuffer.push({ frame:f, ham:dist, written: !shouldCull });
          if(PromClient){
            if(!this.metricGroupCurrentSize){
              this.metricGroupCurrentSize = new PromClient.Gauge({ name:'seraphina_frame_group_current_size', help:'Current size of in-progress frameHamGroup buffer' });
            }
            this.metricGroupCurrentSize.set(this.compressBuffer.length);
          }
        } else if(this.compressBuffer.length){
          // Flush group
          const hamVals = this.compressBuffer.map(x=>x.ham);
          const groupRecord = { ts:Date.now(), type:'frameHamGroup', count:this.compressBuffer.length, hamMin:Math.min(...hamVals), hamMax:Math.max(...hamVals), hamAvg: hamVals.reduce((s,v)=>s+v,0)/hamVals.length, writtenFrames: this.compressBuffer.filter(x=>x.written).length };
          this.appendProvenance(groupRecord);
          if(PromClient){
            if(!this.metricGroupFlushTotal){ this.metricGroupFlushTotal = new PromClient.Counter({ name:'seraphina_frame_group_flush_total', help:'Total number of frameHamGroup flush events' }); }
            if(!this.metricGroupFramesTotal){ this.metricGroupFramesTotal = new PromClient.Counter({ name:'seraphina_frame_group_frames_total', help:'Cumulative frames contained in all flushed groups' }); }
            if(!this.metricGroupLastFlushSize){ this.metricGroupLastFlushSize = new PromClient.Gauge({ name:'seraphina_frame_group_last_flush_size', help:'Size of most recently flushed frameHamGroup' }); }
            this.metricGroupFlushTotal.inc();
            this.metricGroupFramesTotal.inc(groupRecord.count);
            this.metricGroupLastFlushSize.set(groupRecord.count);
            if(this.metricGroupCurrentSize){ this.metricGroupCurrentSize.set(0); }
          }
          this.compressBuffer = [];
        }
      }
      // Frame-level provenance record
      if(this.frameProvEnabled){
        try {
          const snapshotDigest = this.securityHeuristicsPath && fs.existsSync(this.securityHeuristicsPath)
            ? sha256(fs.readFileSync(this.securityHeuristicsPath,'utf8')) : null;
          this.appendProvenance({ ts:Date.now(), type:'frameHam', frame:f, ham:dist, written: !shouldCull, forced: !!forceRetain, threshold:this.frameCullThreshold, locked:this.cullLocked, snapshotDigest });
        } catch(e){ console.warn('[FrameProv][WARN]', e.message); }
      }
      if(f % 6 === 0) this.broadcastRoot();
    }
    this.cullStats.ratio = this.cullStats.total ? (this.cullStats.culled / this.cullStats.total) : 0;
  this.appendProvenance({ ts: Date.now(), type:'cullStats', cull: this.cullStats, merkleRoot: this.ledger.root, hamSeries: { frameAvg: avg(this.hamSeries.frame), rootAvg: avg(this.hamSeries.root), cullAvg: avg(this.hamSeries.cull) } });
    // Add summary leaf for root attestation (will slightly change final Merkle root)
    this.ledger.addLeaf({ cull: { written: this.cullStats.written, culled: this.cullStats.culled, ratio: this.cullStats.ratio, threshold: this.cullStats.threshold } });
    // Enhanced summary leaf including median & forced retention hits
    this.ledger.addLeaf({ cullSummary: { threshold: this.frameCullThreshold, median: this.lastMedian, forcedRetentions: this.forcedRetentionHits, locked: this.cullLocked } });
    // Auto security heuristics snapshot generation (if module present and env flag)
    if(/^(1|true)$/i.test(process.env.SERAPHINA_FRAME_AUTO_SECURITY || '') && this.securityHeuristicsPath){
      try {
        let heurModule = null;
        try { heurModule = require('./seraphina-code-security-heuristics.js'); } catch(_e){ /* optional */ }
        let snapshot = {};
        if(heurModule && heurModule.scanCode){
          // Aggregate over current project dir *.js files (simplified)
          const files = fs.readdirSync(this.projectDir).filter(f=>f.endsWith('.js')).slice(0,50);
          const agg = { evalCalls:0, execCalls:0, base64Chunks:0, entropyAlerts:0 };
            for(const file of files){
              try {
                const code = fs.readFileSync(path.join(this.projectDir,file),'utf8');
                const res = heurModule.scanCode(code);
                agg.evalCalls += res.evalCalls||0;
                agg.execCalls += res.execCalls||0;
                agg.base64Chunks += res.base64Chunks||0;
                agg.entropyAlerts += res.entropyAlerts||0;
              } catch(_e){ }
            }
          snapshot = { ts:Date.now(), aggregate: agg };
        } else {
          snapshot = { ts:Date.now(), note:'heuristics module not available' };
        }
        fs.writeFileSync(this.securityHeuristicsPath, JSON.stringify(snapshot,null,2));
        this.appendProvenance({ ts: Date.now(), type:'securitySnapshot', digest: sha256(JSON.stringify(snapshot)), aggregate: snapshot.aggregate });
      } catch(e){ console.warn('[SecuritySnapshot][WARN]', e.message); }
    }
    // Write histogram if requested
    if(this.histPath){
      const buckets = [0,0,0,0,0]; // 0-0.01,0.01-0.02,0.02-0.05,0.05-0.1,>0.1
      for(const d of this.recentWrittenDistances){
        if(d < 0.01) buckets[0]++; else if(d < 0.02) buckets[1]++; else if(d < 0.05) buckets[2]++; else if(d < 0.1) buckets[3]++; else buckets[4]++;
      }
      try { fs.writeFileSync(this.histPath, JSON.stringify({ ts:Date.now(), buckets, total:this.recentWrittenDistances.length }) ); } catch(e){ console.warn('[FrameCull][HIST][WARN]', e.message); }
    }
    // Flush any remaining compression group
    if(this.compressEnabled && this.compressBuffer.length){
      const hamVals = this.compressBuffer.map(x=>x.ham);
      const groupRecord = { ts:Date.now(), type:'frameHamGroup', count:this.compressBuffer.length, hamMin:Math.min(...hamVals), hamMax:Math.max(...hamVals), hamAvg: hamVals.reduce((s,v)=>s+v,0)/hamVals.length, writtenFrames: this.compressBuffer.filter(x=>x.written).length };
      this.appendProvenance(groupRecord);
      if(PromClient){
        if(!this.metricGroupFlushTotal){ this.metricGroupFlushTotal = new PromClient.Counter({ name:'seraphina_frame_group_flush_total', help:'Total number of frameHamGroup flush events' }); }
        if(!this.metricGroupFramesTotal){ this.metricGroupFramesTotal = new PromClient.Counter({ name:'seraphina_frame_group_frames_total', help:'Cumulative frames contained in all flushed groups' }); }
        if(!this.metricGroupLastFlushSize){ this.metricGroupLastFlushSize = new PromClient.Gauge({ name:'seraphina_frame_group_last_flush_size', help:'Size of most recently flushed frameHamGroup' }); }
        this.metricGroupFlushTotal.inc();
        this.metricGroupFramesTotal.inc(groupRecord.count);
        this.metricGroupLastFlushSize.set(groupRecord.count);
        if(this.metricGroupCurrentSize){ this.metricGroupCurrentSize.set(0); }
      }
      this.compressBuffer = [];
    }
    // Update per-series gauges
    if(PromClient){
      if(this.hamSeries.frame.length) this.metricHamFrameAvg.set(avg(this.hamSeries.frame));
      if(this.hamSeries.root.length) this.metricHamRootAvg.set(avg(this.hamSeries.root));
      if(this.hamSeries.cull.length) this.metricHamCullAvg.set(avg(this.hamSeries.cull));
    }
    console.log('[MerkleLedger] Root after cull summary leaf:', this.ledger.root);
    console.log('[Animation] Frames processed=', totalFrames, 'written=', this.cullStats.written, 'culled=', this.cullStats.culled, 'cullRatio=', this.cullStats.ratio.toFixed(4), 'threshold=', this.frameCullThreshold, 'MerkleRoot=', this.ledger.root);
    console.log('[HammingMonitor] finalHealth=', this.hammingMonitor.health(), 'avgDiff=', (this.hammingMonitor.diffLedger.reduce((s,d)=>s+d.hamming,0)/ (this.hammingMonitor.diffLedger.length||1)).toFixed(6));
    // Emit final ham series provenance record
    this.appendProvenance({ ts: Date.now(), type:'hamSeriesFinal', hamSeries: { frame: this.hamSeries.frame, root: this.hamSeries.root, cull: this.hamSeries.cull } });
  }
  async run(input){
    if(!this.disableWs){ this.setupMultiplayer(); }
    const grammarRoot = await this.ledgerOcta(input);
    const frameCount = this.framesOverride || 32;
    await this.buildAnimation(frameCount);
    this.generateOctaml5(this.ledger.root);
    console.log('[UnifiedOctaLangGPU] Final Merkle root:', this.ledger.root, 'grammarRoot:', grammarRoot);
  }
}

// CLI usage: node unified-octalang-gpu.js <inputFile>
if(require.main === module){
  // Basic flag parsing
  const args = process.argv.slice(2);
  let inputFile = __filename;
  const opts = {};
  let disableWs = false; let wsPort = null; let framesOverride = null; let frameProvFlag = false;
  for(const a of args){
    if(a.startsWith('--cull=')) opts.frameCullThreshold = parseFloat(a.split('=')[1]);
    else if(a === '--adapt') process.env.SERAPHINA_FRAME_CULL_ADAPT = '1';
    else if(a.startsWith('--forceN=')) process.env.SERAPHINA_FRAME_FORCE_N = a.split('=')[1];
    else if(a === '--lock') process.env.SERAPHINA_FRAME_CULL_LOCK = '1';
    else if(a.startsWith('--hist=')) process.env.SERAPHINA_FRAME_CULL_HIST_PATH = a.split('=')[1];
    else if(a.startsWith('--securitySnapshot=')) process.env.SERAPHINA_SECURITY_HEURISTICS_PATH = a.split('=')[1];
    else if(a === '--no-ws') disableWs = true;
    else if(a.startsWith('--wsPort=')) wsPort = parseInt(a.split('=')[1],10);
  else if(a.startsWith('--frames=')) framesOverride = parseInt(a.split('=')[1],10);
  else if(a === '--frameProv') frameProvFlag = true;
    else if(!a.startsWith('--')) inputFile = a;
  }
  let input='';
  try { input = fs.readFileSync(inputFile,'utf8'); } catch(e){ console.error('[UnifiedOctaLangGPU] Failed to read input', e.message); process.exit(1); }
  const engine = new UnifiedOctaLangGPU({ projectDir: process.cwd(), appName: 'TesseractApp', ...opts });
  engine.disableWs = disableWs;
  engine.wsPort = wsPort;
  engine.framesOverride = framesOverride;
  if(frameProvFlag) engine.frameProvEnabled = true;
  engine.run(input).catch(e=>{ console.error('[UnifiedOctaLangGPU][ERROR]', e); process.exit(1); });
}

module.exports = { UnifiedOctaLangGPU, MerkleLedger };
// Helper: average
function avg(arr){ return arr && arr.length? arr.reduce((s,v)=>s+v,0)/arr.length : null; }