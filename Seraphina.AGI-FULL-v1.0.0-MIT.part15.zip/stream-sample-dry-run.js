#!/usr/bin/env node
'use strict';
// stream-sample-dry-run.js: Simulate streaming chunk read & reservoir / probabilistic sampling without training.
// Reports expected sampled/reservoir size given current env configuration.
// Env vars used:
//  SERAPHINA_LARGE_DATASET_PATH - path to large NDJSON dataset
//  SERAPHINA_STREAM_BATCH_MAX - cap for probabilistic sampled lines
//  SERAPHINA_STREAM_SAMPLE_PCT - probability per line (0..1) when reservoir disabled
//  SERAPHINA_STREAM_RESERVOIR_SIZE - reservoir target size (enables reservoir when >0)
//  SERAPHINA_STREAM_CHUNK_SIZE - chunk size bytes (default 1MB)
// Optional CLI overrides: --reservoirSize=15000 --samplePct=0.25 --batchMax=120000 --chunkSize=1048576

const fs = require('fs');

const LARGE_PATH = process.env.SERAPHINA_LARGE_DATASET_PATH || process.env.SERAPHINA_LARGE_DATASET || 'seraphina-model-dataset-large.jsonl';
let STREAM_BATCH_MAX = parseInt(process.env.SERAPHINA_STREAM_BATCH_MAX || '150000',10);
let STREAM_SAMPLE_PCT = parseFloat(process.env.SERAPHINA_STREAM_SAMPLE_PCT || '1');
let STREAM_RESERVOIR_SIZE = parseInt(process.env.SERAPHINA_STREAM_RESERVOIR_SIZE || '0',10);
let STREAM_CHUNK_SIZE = parseInt(process.env.SERAPHINA_STREAM_CHUNK_SIZE || (1024*1024).toString(),10);

for(const arg of process.argv.slice(2)){
  const m=/^--([^=]+)=(.+)$/.exec(arg); if(!m) continue; const k=m[1]; const v=m[2];
  if(k==='reservoirSize') STREAM_RESERVOIR_SIZE = parseInt(v,10);
  else if(k==='samplePct') STREAM_SAMPLE_PCT = parseFloat(v);
  else if(k==='batchMax') STREAM_BATCH_MAX = parseInt(v,10);
  else if(k==='chunkSize') STREAM_CHUNK_SIZE = parseInt(v,10);
}
if(!fs.existsSync(LARGE_PATH)){
  console.error('[DryRun] Large dataset path missing:', LARGE_PATH);
  process.exit(1);
}

function simulate(){
  const useReservoir = STREAM_RESERVOIR_SIZE>0;
  const fd = fs.openSync(LARGE_PATH,'r');
  const CHUNK_SIZE = STREAM_CHUNK_SIZE>0? STREAM_CHUNK_SIZE : 1024*1024;
  let buffer = Buffer.alloc(CHUNK_SIZE);
  let leftover='';
  let bytesRead=0; let seen=0; let sampled=0;
  const reservoir=[];
  while(true){
    bytesRead = fs.readSync(fd, buffer, 0, CHUNK_SIZE, null);
    if(bytesRead<=0) break;
    let chunkStr = leftover + buffer.slice(0,bytesRead).toString('utf8');
    const parts = chunkStr.split(/\n/);
    leftover = parts.pop();
    for(const line of parts){
      if(!line.trim()) continue;
      seen++;
      if(useReservoir){
        if(reservoir.length < STREAM_RESERVOIR_SIZE){ reservoir.push(1); }
        else {
          const r = Math.floor(Math.random()*seen);
          if(r < STREAM_RESERVOIR_SIZE){ /* replacement occurs */ }
        }
      } else {
        if(sampled < STREAM_BATCH_MAX && Math.random() <= STREAM_SAMPLE_PCT){ sampled++; }
      }
    }
    if(useReservoir && seen>=STREAM_RESERVOIR_SIZE*5) {
      if(seen > STREAM_RESERVOIR_SIZE && reservoir.length===STREAM_RESERVOIR_SIZE) break;
    }
    if(!useReservoir && sampled>=STREAM_BATCH_MAX) break;
  }
  if(leftover){
    seen++;
    if(useReservoir){
      if(reservoir.length < STREAM_RESERVOIR_SIZE){ reservoir.push(1); }
      else {
        const r = Math.floor(Math.random()*seen);
        if(r < STREAM_RESERVOIR_SIZE){ /* replace */ }
      }
    } else if(sampled < STREAM_BATCH_MAX && Math.random() <= STREAM_SAMPLE_PCT){ sampled++; }
  }
  fs.closeSync(fd);
  const result = useReservoir ? { mode:'reservoir', reservoirSize: reservoir.length, target: STREAM_RESERVOIR_SIZE, seen } : { mode:'probabilistic', sampled, samplePct: STREAM_SAMPLE_PCT, batchMax: STREAM_BATCH_MAX, seen };
  console.log('[DryRunResult]', JSON.stringify(result));
}

if(require.main===module){ simulate(); }
