'use strict';
// test-exporter-protocol.js
// Verifies HTTPS downgrade fallback when invalid cert paths provided.
const api = require('./seraphina-api');
const fs = require('fs');

function run(){
  // Provide bogus paths
  const info = api.exporters.startPrometheusExporter({ port: 9124, host: '127.0.0.1', https: { keyPath: '__no_key.pem', certPath: '__no_cert.pem' } });
  if(!info.ok) throw new Error('Exporter failed to start');
  if(info.protocol !== 'http') throw new Error('Expected protocol http fallback when certs invalid');
  console.log('Exporter protocol fallback test passed. protocol:', info.protocol);
  api.meta.stopExporter();
}

if(require.main === module){
  try { run(); } catch(e){ console.error('Exporter protocol test failed:', e.message); process.exit(1); }
}
module.exports = { run };
