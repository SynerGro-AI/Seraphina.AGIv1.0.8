<#
 set-env.ps1 - Convenience script to configure environment variables for REAL mining session.
 Usage (PowerShell):
   . .\set-env.ps1   # Note the leading dot to import into current session
 Adjust values below before sourcing.
#>

$env:BITCOIN_RPC_URL = "http://<IP>:8332"
$env:BITCOIN_RPC_USER = "user"
$env:BITCOIN_RPC_PASS = "pass"
$env:RVN_RPC_URL = "http://<IP>:8766"
$env:RVN_RPC_USER = "user"
$env:RVN_RPC_PASS = "pass"
$env:BTC_AUTO_BROADCAST = "1"          # Auto-broadcast payout txs
$env:REAL_STRICT = "1"                  # Enforce real hashing/validation
$env:KAWPOW_MINER_AUTO = "1"            # Auto-start external KawPow miner
$env:KAWPOW_MINER = "kawpowminer"       # External miner executable name
$env:BTC_FEE_RATE = ""                  # Leave blank to use dynamic fee estimation
$env:PAYOUT_THRESHOLD_BTC = "0.00005"
$env:PAYOUT_THRESHOLD_RVN = "5"

Write-Host "[ENV] Core mining environment variables loaded into current session." -ForegroundColor Cyan
Write-Host "[ENV] To persist across sessions use setx (one by one) or keep using this script." -ForegroundColor DarkCyan