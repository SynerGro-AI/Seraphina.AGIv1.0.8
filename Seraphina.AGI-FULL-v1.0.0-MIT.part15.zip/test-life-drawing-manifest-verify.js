#!/usr/bin/env node
'use strict';
const { verify } = require('./life-drawing-manifest-verify');
const res = verify();
if(!res.ok){ console.error('Verification failed: '+res.message); process.exit(1); }
console.log(JSON.stringify({ ok:true, digest: res.digest.slice(0,16), ts: res.ts }, null, 2));
