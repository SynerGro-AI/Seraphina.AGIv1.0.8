// test-adaptive-virtue-thresholds.js
'use strict';
const assert = require('assert');
const { assess } = require('./seraphina-moral-safety.js');

function makeEntry(eAlign, imagine, profitWord){
  return {
    personality: { ethical_alignment: eAlign, imagination_intensity: imagine, openness:0.5, stability:0.5, strategic_depth:0.5 },
    dialogs: [{ text: `profit ${profitWord>0.3?'profit':''} empathy ethical balance imagine` }],
    decisions: []
  };
}

function run(){
  let lastLow=null; let lastProfitThr=null; let increased=false; let decreased=false;
  for(let i=0;i<60;i++){
    const entry = makeEntry(0.55 + Math.sin(i/10)*0.05, 0.5, i<30?0.2:0.5);
    const res = assess(entry);
    if(lastLow!=null){ if(res.virtues.adaptive.lowVirtueThreshold !== lastLow){ increased = increased || res.virtues.adaptive.lowVirtueThreshold>lastLow; decreased = decreased || res.virtues.adaptive.lowVirtueThreshold<lastLow; }
    }
    lastLow = res.virtues.adaptive.lowVirtueThreshold;
    lastProfitThr = res.virtues.adaptive.profitDominanceThreshold;
  }
  assert(lastLow>=0.35 && lastLow<=0.6, 'adaptive low threshold bounds');
  assert(lastProfitThr>=0.3 && lastProfitThr<=0.6, 'profit dominance threshold bounds');
  console.log('[TestAdaptiveVirtueThresholds] PASS', { finalLow:lastLow, finalProfit:lastProfitThr, changed: (increased||decreased) });
}

if(require.main===module){ run(); }
module.exports = { run };
