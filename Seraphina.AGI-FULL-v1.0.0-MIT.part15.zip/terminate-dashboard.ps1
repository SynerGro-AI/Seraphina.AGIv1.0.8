param(
  [int]$Port = 8999
)
Write-Host "Scanning for process listening on port $Port..."
# Use netstat to find PID
$net = netstat -ano | Select-String ":$Port\s"
if(!$net){ Write-Warning "No process found on port $Port"; exit 0 }
$procIds = @()
foreach($line in $net){
  $parts = ($line.ToString() -replace '\s+', ' ').Split(' ')
  $candidate = $parts[-1]
  if($candidate -match '^\d+$'){ $procIds += [int]$candidate }
}
$procIds = $procIds | Sort-Object -Unique
if($procIds.Count -eq 0){ Write-Warning "No PID parsed"; exit 0 }
Write-Host "Found PIDs: $($procIds -join ', ')"
foreach($procId in $procIds){
  try {
    Write-Host "Stopping PID $procId"; Stop-Process -Id $procId -Force -ErrorAction Stop; Write-Host "Stopped $procId"
  } catch {
    Write-Warning ("Failed to stop {0}: {1}" -f $procId, $_)
  }
}
