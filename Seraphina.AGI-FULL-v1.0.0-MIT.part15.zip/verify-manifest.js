#!/usr/bin/env node
// Verify artifact-hashes.json against current files.
const fs = require('fs');
const crypto = require('crypto');

function usage(){
  console.error('Usage: node verify-manifest.js <artifact-hashes.json>');
  process.exit(1);
}
if(process.argv.length <3) usage();
const manifestPath = process.argv[2];
let manifest;
try { manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8')); } catch(e){
  console.error('Failed to read manifest', e.message); process.exit(2);
}

function sha256(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }
let ok=true;
for(const art of manifest.artifacts){
  try {
    const data = fs.readFileSync(art.file);
    const hash = sha256(data);
    if(hash !== art.sha256){
      console.error('[MISMATCH]', art.file, 'expected', art.sha256, 'got', hash);
      ok=false;
    }
  } catch(e){
    console.error('[MISSING]', art.file);
    ok=false;
  }
}
// recompute Merkle
let layer = manifest.artifacts.map(a=> a.sha256);
while(layer.length>1){
  const next=[];
  for(let i=0;i<layer.length;i+=2){
    const left=layer[i]; const right= layer[i+1] || left;
    next.push(sha256(Buffer.from(left+right)));
  }
  layer=next;
}
const recomputedRoot = layer.length? layer[0]: null;
if(recomputedRoot !== manifest.merkleRoot){
  console.error('[MERKLE-ROOT-MISMATCH] expected', manifest.merkleRoot, 'got', recomputedRoot);
  ok=false;
}
if(manifest.hmacSeal && process.env.USB_MANIFEST_HMAC_KEY){
  const hmac = crypto.createHmac('sha256', process.env.USB_MANIFEST_HMAC_KEY).update(manifest.merkleRoot).digest('hex');
  if(hmac !== manifest.hmacSeal){
    console.error('[HMAC-MISMATCH] expected', manifest.hmacSeal, 'got', hmac);
    ok=false;
  }
} else if(manifest.hmacSeal && !process.env.USB_MANIFEST_HMAC_KEY){
  console.warn('[WARN] Manifest has hmacSeal but USB_MANIFEST_HMAC_KEY not set for verification');
}
if(ok){
  console.log('[OK] Manifest verified successfully');
  process.exit(0);
} else {
  console.error('[FAIL] Manifest verification failed');
  process.exit(3);
}
