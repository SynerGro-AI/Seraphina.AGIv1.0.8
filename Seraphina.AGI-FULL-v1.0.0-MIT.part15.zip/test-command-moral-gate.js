// test-command-moral-gate.js
'use strict';
const { validateCommands } = require('./command-moral-gate');
function run(){
  const commands = [ 'echo hello', 'rm -rf /var/lib/apt/lists/*', 'sudo apt install htop', 'passwd root' ];
  const report = validateCommands(commands);
  console.log(JSON.stringify(report,null,2));
}
if(require.main === module){ run(); }
module.exports = { run };
