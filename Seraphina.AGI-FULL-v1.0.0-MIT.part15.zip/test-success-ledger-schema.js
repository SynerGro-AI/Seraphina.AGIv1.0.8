// test-success-ledger-schema.js
// Simple schema assertion for latest success ledger entry.
'use strict';
const fs = require('fs');
const LEDGER = process.env.SERAPHINA_SUCCESS_RATE_LEDGER || 'seraphina-success-rate-ledger.jsonl';
const REQUIRED_FIELDS = [
  'ts','version','successRate','successRateEthical','lossA','lossB','smoothAccA','emaAccA','emaAccEthical','params','windowMedianAcc','emaVsMedianDelta'
];
function fail(msg){ console.error('[SchemaTest][FAIL]', msg); process.exitCode = 1; }
function run(){
  if(!fs.existsSync(LEDGER)){ fail('Ledger file missing: '+LEDGER); return; }
  const lines = fs.readFileSync(LEDGER,'utf8').trim().split(/\n+/).filter(Boolean);
  if(!lines.length){ fail('Ledger empty'); return; }
  let last;
  try { last = JSON.parse(lines[lines.length-1]); } catch(e){ fail('Last line JSON parse error: '+e.message); return; }
  for(const f of REQUIRED_FIELDS){
    if(!(f in last)) fail('Missing field: '+f);
  }
  if(typeof last.params !== 'object') fail('params field not object');
  if(!('SMOOTH_WINDOW' in last.params) || !('EMA_ALPHA' in last.params) || !('LABEL_FLIP_PCT' in last.params)) fail('params missing required keys');
  if(typeof last.emaAccA !== 'number' || typeof last.windowMedianAcc !== 'number') fail('numeric fields type check failed');
  if(process.exitCode){ return; }
  console.log('[SchemaTest][PASS] Latest success ledger entry contains required fields.');
}
if(require.main === module){ run(); }
module.exports = { run };
