// Simple health endpoint schema test
const http = require('http');

function fetch(url){
  return new Promise((resolve,reject)=>{
    http.get(url, res=>{ let data=''; res.on('data',d=>data+=d); res.on('end',()=>{ try{ resolve(JSON.parse(data)); }catch(e){ reject(e); } }); }).on('error',reject);
  });
}

(async function(){
  try {
    const health = await fetch('http://localhost:8999/health');
    if(!health.ok) throw new Error('ok flag false');
    const h = health.health;
    if(!h) throw new Error('missing health root');
    if(!['normal','hot','cold'].includes(h.status)) throw new Error('unexpected status');
    if(!h.noise) throw new Error('missing noise');
    if(typeof h.noise.labelFlipPct !== 'number') throw new Error('labelFlipPct not number');
    if(!h.histogram) throw new Error('missing histogram');
    if(h.histogram && (typeof h.histogram.p50 !== 'number' && h.histogram.p50 !== null)) throw new Error('p50 invalid');
    if(h.histogram && (typeof h.histogram.p90 !== 'number' && h.histogram.p90 !== null)) throw new Error('p90 invalid');
    console.log('HEALTH TEST PASS');
  } catch (e){
    console.error('HEALTH TEST FAIL', e);
    process.exit(1);
  }
})();
